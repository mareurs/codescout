"""Protocol integrity controls; synthetic records are not experiment results."""
import copy
import json
import pathlib
import unittest
from verify import InvalidRun, load_cases, verify

ROOT = pathlib.Path(__file__).parent

class ProtocolTests(unittest.TestCase):
    def setUp(self):
        self.cases = load_cases(ROOT / "cases.json")
        self.records = []
        for c in self.cases:
            scope = c["referent_scope"] if c["operation"] == "approve" and c["symlink"] else c["entry_scope"]
            self.records.append(dict(
                case_id=c["case_id"], expected_guard=c["expected_guard"],
                witness_ok=True, witness_scope=scope, witness_error=None,
                observed_guard=c["expected_guard"],
                observed_scope=None if c["expected_guard"] else scope,
                effect_ok=True, other_error=None, session_unchosen=True))

    def log(self, records=None, failed=0, summary=True):
        rows = self.records if records is None else records
        lines = ["OPERATION_CASE " + json.dumps(r) for r in rows]
        if summary:
            lines.append("OPERATION_SUMMARY " + json.dumps(dict(scenarios=120, passed=120-failed, failed=failed)))
        lines.append("test operation_contract_matrix ... " + ("FAILED" if failed else "ok"))
        lines.append("test result: " + ("FAILED" if failed else "ok") + ". " +
                     str(0 if failed else 1) + " passed; " + str(1 if failed else 0) +
                     " failed; 0 ignored; 0 measured; 0 filtered out; finished in 1.00s")
        return "\n".join(lines)

    def test_complete_success(self):
        result = verify(self.cases, self.log(), 0)
        self.assertEqual((result["scenarios"], result["passed"], result["failed"]), (120,120,0))

    def test_missing_record_with_retained_success_footer(self):
        with self.assertRaises(InvalidRun):
            verify(self.cases, self.log(self.records[:-1]), 0)

    def test_duplicate_replacing_missing_record(self):
        with self.assertRaises(InvalidRun):
            verify(self.cases, self.log(self.records[:-1]+[self.records[0]]), 0)

    def test_tampered_oracle(self):
        rows=copy.deepcopy(self.records)
        rows[0]["expected_guard"] = not rows[0]["expected_guard"]
        with self.assertRaises(InvalidRun):
            verify(self.cases, self.log(rows), 0)

    def test_false_success_footer_for_observed_failure(self):
        rows=copy.deepcopy(self.records)
        rows[0]["observed_guard"] = not rows[0]["expected_guard"]
        with self.assertRaises(InvalidRun):
            verify(self.cases, self.log(rows), 0)

    def test_no_records_compile_failure(self):
        with self.assertRaises(InvalidRun):
            verify(self.cases, "error[E0000]: did not compile", 101)

    def test_missing_witness(self):
        rows=copy.deepcopy(self.records)
        rows[0]["witness_ok"] = False
        with self.assertRaises(InvalidRun):
            verify(self.cases, self.log(rows, failed=1), 101)

    def test_duplicate_summary(self):
        text=self.log()+"\nOPERATION_SUMMARY "+json.dumps(dict(scenarios=120,passed=120,failed=0))
        with self.assertRaises(InvalidRun):
            verify(self.cases, text, 0)

    def test_unexpected_exit_code(self):
        with self.assertRaises(InvalidRun):
            verify(self.cases, self.log(), -9)

    def test_wrong_field_type(self):
        rows=copy.deepcopy(self.records)
        rows[0]["effect_ok"] = 1
        with self.assertRaises(InvalidRun):
            verify(self.cases, self.log(rows), 0)

    def test_negative_case_is_scored_when_population_complete(self):
        rows=copy.deepcopy(self.records)
        rows[0]["observed_guard"] = False
        rows[0]["observed_scope"] = self.cases[0]["entry_scope"]
        result=verify(self.cases, self.log(rows,failed=1),101)
        self.assertEqual(result["failed"], 1)
        self.assertEqual(result["failed_ids"],[rows[0]["case_id"]])

    def test_manifest_rejects_policy_change_and_missing_case(self):
        import tempfile
        for change in ("policy","missing"):
            cases=copy.deepcopy(self.cases)
            if change == "policy":
                cases[0]["expected_guard"] = not cases[0]["expected_guard"]
            else:
                cases.pop()
            with tempfile.TemporaryDirectory() as directory:
                path=pathlib.Path(directory)/"cases.json"
                path.write_text(json.dumps(dict(schema_version=1,cases=cases)))
                with self.assertRaises(InvalidRun):
                    load_cases(path)

if __name__ == "__main__":
    unittest.main()
