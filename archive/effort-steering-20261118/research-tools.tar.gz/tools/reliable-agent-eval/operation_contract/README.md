# Operation contract validator

Offline acceptance instrument for the worktree-write research task. This does not call a model or change production files in the research worktree.

The contract distinguishes atomic file replacement from directory approval. Create/edit must affect the requested final directory entry. Approval must append permission for the canonical directory actually granted access. For an unselected session, operations affecting the main project, linked worktree or discovered member must retain the project-selection guard. Outside operations must reach ordinary authorization.

## Run

Use a disposable Codescout snapshot with the candidate production source. Copy `worktree_write.rs` to `tests/operation_contract.rs` and `cases.json` to `tests/operation_cases.json`. From that snapshot run:

```sh
./scripts/with-slot.sh cargo test --offline --test operation_contract -- --nocapture > matrix.log 2>&1
```

Preserve the actual exit code immediately. Pass that code to the verifier from this directory:

```sh
python3 verify.py --log /absolute/path/matrix.log --exit-code 0
python3 -m unittest discover -s . -p test_verify.py
```

Verifier exit codes: 0 = complete passing matrix; 1 = complete valid matrix with behavioral failures; 2 = invalid/unscorable run. Cargo normally returns 101 for a failing Rust test; pass 101 when that is the observed command exit. A compiler failure, incomplete population, duplicate record, altered oracle, failed execution witness or inconsistent footer cannot become a quality score.

## What is counted

The manifest contains 120 ordered scenarios: three operations × four physical entry locations × two parent spellings × five leaf arrangements (regular, or symlink to one of four physical referent locations). This comprises 24 regular and 96 symlink scenarios. One Rust test executes the matrix; 120 scenarios are not 120 independent reliability samples.

Each scenario creates two separate fixtures. The explicitly pinned witness must perform the operation with the expected physical effect. The unselected fixture has identical ordinary write permission and must either refuse without watched effects or complete with the expected physical effect. Both must retain the unchosen-session state.

For files, the harness watches leaf and referent entries in all four disjoint physical roots; only the requested leaf may change, becoming a regular file containing the replacement. For approval, disk snapshots must stay unchanged, existing permission roots must remain intact, and exactly one expected canonical directory must be appended and returned. Relocated-member discovery is retained after its original path becomes a symlink. Parent aliases spell outside entries through the main project and project entries through the outside root.

The Python verifier reconstructs the declared population and policy independently of the candidate's resolver, then checks every structured record, its witness, summary, named test result, footer and actual process exit. It trusts the frozen harness's physical-effect observations; it does not protect against a candidate intentionally forging protocol output. Keep the harness, manifest and verifier immutable while switching candidate source.

## Limits

The matrix exercises valid existing paths on Unix, preauthorized writes, an unselected session, and an explicit main-workspace pin. It does not cover missing/invalid paths, concurrent races, every authorization mode, all filesystem side effects, end-to-end MCP dispatch, general coding reliability or model cost savings. Retain the prior six original, eleven review and four parent probes as separate regression suites.

Calibration and saved-version replay are documented in [the operation-contract report](../../../docs/research/2026-10-28-operation-contract-validator.md). The [plan](../../../docs/superpowers/plans/2026-10-28-operation-contract-validator.md) records this phase's offline scope.
