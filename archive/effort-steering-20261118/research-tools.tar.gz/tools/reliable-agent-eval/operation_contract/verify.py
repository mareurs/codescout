"""Strict offline verifier for operation-contract test output."""
import argparse
import itertools
import json
import pathlib
import re

SCOPES = ("main", "linked", "member", "outside")


def _json(text):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise InvalidRun("duplicate JSON key: " + key)
            result[key] = value
        return result
    try:
        return json.loads(text, object_pairs_hook=unique)
    except (ValueError, TypeError) as exc:
        raise InvalidRun("invalid JSON: " + str(exc)) from exc


def _validate_cases(cases):
    expected = []
    for operation, entry, alias in itertools.product(("create", "edit", "approve"), SCOPES, (False, True)):
        for referent in (None, *SCOPES):
            symlink = referent is not None
            scope = referent if operation == "approve" and symlink else entry
            expected.append(dict(
                case_id=f"{operation}:{'symlink' if symlink else 'regular'}:{entry}:{referent or '-'}:{'alias' if alias else 'direct'}",
                operation=operation, entry_scope=entry, referent_scope=referent,
                alias=alias, symlink=symlink, expected_guard=scope != "outside"))
    # JSON equality preserves the distinction between true and 1.
    if json.dumps(cases, sort_keys=True) != json.dumps(expected, sort_keys=True):
        raise InvalidRun("manifest differs from declared ordered 120-case contract")

class InvalidRun(ValueError):
    pass

def load_cases(path):
    document = _json(path.read_text())
    if not isinstance(document, dict) or set(document) != {"schema_version", "cases"} or type(document["schema_version"]) is not int or document["schema_version"] != 1:
        raise InvalidRun("unsupported manifest")
    _validate_cases(document["cases"])
    return document["cases"]

def verify(cases, text, exit_code):
    """Return measured scenario outcomes, or reject an unscorable run."""
    _validate_cases(cases)
    if type(exit_code) is not int or exit_code not in (0, 101):
        raise InvalidRun("unexpected process exit")
    records, summaries = [], []
    for line in text.splitlines():
        if line.startswith("OPERATION_CASE "):
            records.append(_json(line.removeprefix("OPERATION_CASE ")))
        elif line.startswith("OPERATION_SUMMARY "):
            summaries.append(_json(line.removeprefix("OPERATION_SUMMARY ")))
    ids = [r.get("case_id") if isinstance(r, dict) else None for r in records]
    expected_ids = [c["case_id"] for c in cases]
    if ids != expected_ids:
        raise InvalidRun("missing, duplicate, reordered or unknown case records")
    keys = {"case_id", "expected_guard", "witness_ok", "witness_scope", "witness_error",
            "observed_guard", "observed_scope", "effect_ok", "other_error", "session_unchosen"}
    failed = []
    for case, record in zip(cases, records):
        if set(record) != keys:
            raise InvalidRun("unexpected record fields")
        for field in ("expected_guard", "witness_ok", "observed_guard", "effect_ok", "session_unchosen"):
            if type(record[field]) is not bool:
                raise InvalidRun("nonboolean " + field)
        for field in ("witness_scope", "observed_scope"):
            if record[field] is not None and record[field] not in SCOPES:
                raise InvalidRun("unknown affected scope")
        for field in ("witness_error", "other_error"):
            if record[field] is not None and type(record[field]) is not str:
                raise InvalidRun("invalid error field")
        scope = case["referent_scope"] if case["operation"] == "approve" and case["symlink"] else case["entry_scope"]
        if record["expected_guard"] != case["expected_guard"]:
            raise InvalidRun("oracle field altered")
        if not record["witness_ok"] or record["witness_scope"] != scope or record["witness_error"] is not None:
            raise InvalidRun("operation witness failed: " + case["case_id"])
        passed = (
            record["other_error"] is None and record["effect_ok"]
            and record["session_unchosen"]
            and record["observed_guard"] == case["expected_guard"]
            and (record["observed_scope"] is None if record["observed_guard"] else record["observed_scope"] == scope)
        )
        if not passed:
            failed.append(case["case_id"])
    expected_summary = dict(scenarios=len(cases), passed=len(cases)-len(failed), failed=len(failed))
    if len(summaries) != 1 or json.dumps(summaries[0],sort_keys=True) != json.dumps(expected_summary,sort_keys=True):
        raise InvalidRun("summary disagrees with observed population")
    footers = re.findall(
        r"^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in [^\n]+$",
        text, re.MULTILINE)
    expected_footer = ("FAILED", "0", "1", "0", "0", "0") if failed else ("ok", "1", "0", "0", "0", "0")
    if footers != [expected_footer] or exit_code != (101 if failed else 0):
        raise InvalidRun("libtest result or process exit disagrees with case outcomes")
    if re.findall(r"^test operation_contract_matrix \.\.\. (ok|FAILED)$", text, re.MULTILINE) != [expected_footer[0]]:
        raise InvalidRun("missing or inconsistent named Rust test result")
    return dict(expected_summary, failed_ids=failed, rust_tests=1)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cases", type=pathlib.Path, default=pathlib.Path(__file__).with_name("cases.json"))
    parser.add_argument("--log", type=pathlib.Path, required=True)
    parser.add_argument("--exit-code", type=int, required=True)
    args = parser.parse_args()
    try:
        result = verify(load_cases(args.cases), args.log.read_text(), args.exit_code)
    except InvalidRun as exc:
        print(json.dumps(dict(status="invalid", reason=str(exc))))
        return 2
    print(json.dumps(dict(status="valid", **result), indent=2))
    return 1 if result["failed"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
