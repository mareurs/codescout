//! Copy beside operation_cases.json into a disposable snapshot's tests/ directory.
#![cfg(unix)]

use codescout::agent::Agent;
use codescout::lsp::LspManager;
use codescout::tools::approve_write::ApproveWrite;
use codescout::tools::create_file::CreateFile;
use codescout::tools::edit_file::EditFile;
use codescout::tools::{Tool, ToolContext};
use serde::Deserialize;
use serde_json::{json, Value};
use std::collections::BTreeSet;
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex};
use tempfile::{tempdir, TempDir};

const SCOPES: [&str; 4] = ["main", "linked", "member", "outside"];

#[derive(Clone, Deserialize)]
struct Case {
    case_id: String,
    operation: String,
    entry_scope: String,
    referent_scope: Option<String>,
    alias: bool,
    symlink: bool,
    expected_guard: bool,
}

impl Case {
    fn effect_scope(&self) -> &str {
        if self.operation == "approve" && self.symlink {
            self.referent_scope.as_deref().unwrap()
        } else {
            &self.entry_scope
        }
    }
}

fn scope_index(scope: &str) -> usize {
    SCOPES.iter().position(|value| *value == scope).unwrap()
}

#[derive(Debug, PartialEq)]
enum EntryState {
    Missing,
    Link(PathBuf),
    File(Vec<u8>),
    Directory(Option<Vec<u8>>),
    Unreadable(String),
}

fn state(path: &Path) -> EntryState {
    match std::fs::symlink_metadata(path) {
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => EntryState::Missing,
        Err(error) => EntryState::Unreadable(error.to_string()),
        Ok(meta) if meta.file_type().is_symlink() => match std::fs::read_link(path) {
            Ok(link) => EntryState::Link(link),
            Err(error) => EntryState::Unreadable(error.to_string()),
        },
        Ok(meta) if meta.is_dir() => {
            EntryState::Directory(std::fs::read(path.join("sentinel")).ok())
        }
        Ok(_) => match std::fs::read(path) {
            Ok(bytes) => EntryState::File(bytes),
            Err(error) => EntryState::Unreadable(error.to_string()),
        },
    }
}

struct Fixture {
    context: ToolContext,
    roots: Vec<PathBuf>,
    watched: Vec<PathBuf>,
    target: PathBuf,
    expected_approval: PathBuf,
    _temp: TempDir,
}

impl Fixture {
    async fn new(case: &Case, pinned: bool) -> Self {
        let temp = tempdir().unwrap();
        let main = temp.path().join("main");
        let linked = temp.path().join("linked");
        let outside = temp.path().join("outside");
        let member = main.join("member");
        for path in [&main, &linked, &outside, &member, &main.join(".codescout")] {
            std::fs::create_dir_all(path).unwrap();
        }
        std::fs::write(
            member.join("Cargo.toml"),
            "[package]\nname='member'\nversion='0.1.0'\n",
        )
        .unwrap();
        let git_entry = main.join(".git/worktrees/linked");
        std::fs::create_dir_all(&git_entry).unwrap();
        std::fs::write(
            git_entry.join("gitdir"),
            format!("{}/.git\n", linked.display()),
        )
        .unwrap();
        let agent = Agent::new(Some(main.clone())).await.unwrap();
        assert!(!agent.is_project_chosen_this_session().await);
        assert!(agent
            .discovered_projects()
            .await
            .iter()
            .any(|project| project.relative_root == Path::new("member")));
        let moved_member = temp.path().join("moved-member");
        std::fs::rename(&member, &moved_member).unwrap();
        std::os::unix::fs::symlink(&moved_member, &member).unwrap();
        assert!(agent
            .discovered_projects()
            .await
            .iter()
            .any(|project| project.relative_root == Path::new("member")));
        let roots: Vec<PathBuf> = [main.clone(), linked, moved_member, outside]
            .iter()
            .map(|path| std::fs::canonicalize(path).unwrap())
            .collect();
        // Both matched fixtures have the same ordinary write permission.
        agent
            .add_session_write_root_for(None, temp.path().to_path_buf())
            .await;
        let context = ToolContext {
            agent,
            lsp: LspManager::new_arc(),
            output_buffer: Arc::new(codescout::tools::output_buffer::OutputBuffer::new(20)),
            progress: None,
            peer: None,
            section_coverage: Arc::new(Mutex::new(
                codescout::tools::section_coverage::SectionCoverage::new(),
            )),
            guide_hints_emitted: Arc::new(parking_lot::Mutex::new(Default::default())),
            workspace_override: if pinned { Some(main) } else { None },
        };
        let directory = case.operation == "approve";
        let leaf_name = if directory { "leaf-dir" } else { "leaf.txt" };
        let ref_name = if directory { "ref-dir" } else { "ref.txt" };
        let mut watched = Vec::new();
        for root in &roots {
            for name in [leaf_name, ref_name] {
                let path = root.join(name);
                if directory {
                    std::fs::create_dir_all(&path).unwrap();
                    std::fs::write(path.join("sentinel"), "before").unwrap();
                } else {
                    std::fs::write(&path, "before").unwrap();
                }
                watched.push(path);
            }
        }
        let entry_index = scope_index(&case.entry_scope);
        let physical_leaf = roots[entry_index].join(leaf_name);
        let expected_approval = if case.symlink {
            let referent =
                roots[scope_index(case.referent_scope.as_deref().unwrap())].join(ref_name);
            if directory {
                std::fs::remove_dir_all(&physical_leaf).unwrap();
            } else {
                std::fs::remove_file(&physical_leaf).unwrap();
            }
            std::os::unix::fs::symlink(&referent, &physical_leaf).unwrap();
            referent
        } else {
            physical_leaf.clone()
        };
        let target = if case.alias {
            // Spell an outside parent inside the project, and a project parent outside it.
            let alias = if entry_index == 3 {
                roots[0].join("outside-parent-alias")
            } else {
                roots[3].join("project-parent-alias")
            };
            std::os::unix::fs::symlink(&roots[entry_index], &alias).unwrap();
            alias.join(leaf_name)
        } else {
            physical_leaf
        };
        Self {
            context,
            roots,
            watched,
            target,
            expected_approval,
            _temp: temp,
        }
    }

    fn states(&self) -> Vec<EntryState> {
        self.watched.iter().map(|path| state(path)).collect()
    }

    fn observed_scope(&self, path: &Path) -> Option<String> {
        let matches: Vec<usize> = self
            .roots
            .iter()
            .enumerate()
            .filter_map(|(index, root)| path.starts_with(root).then_some(index))
            .collect();
        (matches.len() == 1).then(|| SCOPES[matches[0]].to_string())
    }
}

struct Observation {
    guarded: bool,
    other_error: Option<String>,
    effect_ok: bool,
    affected_scope: Option<String>,
    session_unchosen: bool,
}

async fn observe(case: &Case, pinned: bool) -> Observation {
    let fixture = Fixture::new(case, pinned).await;
    let before = fixture.states();
    let roots_before = fixture
        .context
        .agent
        .session_write_roots_snapshot_for(fixture.context.workspace_override.as_deref())
        .await;
    let input = match case.operation.as_str() {
        "create" => json!({"path": fixture.target, "content": "after", "overwrite": true}),
        "edit" => json!({"path": fixture.target, "old_string": "before", "new_string": "after"}),
        "approve" => json!({"path": fixture.target}),
        _ => unreachable!(),
    };
    let result = match case.operation.as_str() {
        "create" => CreateFile.call(input, &fixture.context).await,
        "edit" => EditFile.call(input, &fixture.context).await,
        "approve" => ApproveWrite.call(input, &fixture.context).await,
        _ => unreachable!(),
    };
    let after = fixture.states();
    let roots_after = fixture
        .context
        .agent
        .session_write_roots_snapshot_for(fixture.context.workspace_override.as_deref())
        .await;
    let guarded = result
        .as_ref()
        .err()
        .is_some_and(|error| error.to_string().contains("worktrees detected"));
    let other_error = result
        .as_ref()
        .err()
        .filter(|_| !guarded)
        .map(ToString::to_string);
    let (effect_ok, affected_scope) = if guarded {
        (before == after && roots_before == roots_after, None)
    } else if let Ok(value) = result {
        if case.operation == "approve" {
            let appended = roots_after.len() == roots_before.len() + 1
                && roots_after[..roots_before.len()] == roots_before[..];
            let added = appended.then(|| roots_after.last().unwrap().clone());
            let ok = before == after
                && added.as_ref() == Some(&fixture.expected_approval)
                && value.get("approved").and_then(Value::as_str)
                    == added.as_ref().and_then(|path| path.to_str());
            let scope = added.and_then(|path| fixture.observed_scope(&path));
            (ok, scope)
        } else {
            let changed: Vec<usize> = before
                .iter()
                .zip(&after)
                .enumerate()
                .filter_map(|(index, (left, right))| (left != right).then_some(index))
                .collect();
            let expected_index = scope_index(&case.entry_scope) * 2;
            let ok = changed == [expected_index]
                && after[expected_index] == EntryState::File(b"after".to_vec())
                && roots_before == roots_after;
            let scope = (changed.len() == 1)
                .then(|| fixture.observed_scope(&fixture.watched[changed[0]]))
                .flatten();
            (ok, scope)
        }
    } else {
        (false, None)
    };
    Observation {
        guarded,
        other_error,
        effect_ok,
        affected_scope,
        session_unchosen: !fixture.context.agent.is_project_chosen_this_session().await,
    }
}

#[tokio::test]
async fn operation_contract_matrix() {
    let manifest: Value = serde_json::from_str(include_str!("operation_cases.json")).unwrap();
    let cases: Vec<Case> = serde_json::from_value(manifest["cases"].clone()).unwrap();
    assert_eq!(cases.len(), 120);
    assert_eq!(
        cases
            .iter()
            .map(|case| &case.case_id)
            .collect::<BTreeSet<_>>()
            .len(),
        120
    );
    let mut failures = Vec::new();
    for case in &cases {
        let witness = observe(case, true).await;
        let actual = observe(case, false).await;
        let witness_ok = !witness.guarded
            && witness.other_error.is_none()
            && witness.effect_ok
            && witness.affected_scope.as_deref() == Some(case.effect_scope())
            && witness.session_unchosen;
        let effect_scope_ok =
            actual.guarded || actual.affected_scope.as_deref() == Some(case.effect_scope());
        let passed = witness_ok
            && actual.other_error.is_none()
            && actual.effect_ok
            && actual.session_unchosen
            && actual.guarded == case.expected_guard
            && effect_scope_ok;
        println!(
            "OPERATION_CASE {}",
            json!({
                "case_id": case.case_id,
                "expected_guard": case.expected_guard,
                "witness_ok": witness_ok,
                "witness_scope": witness.affected_scope,
                "witness_error": witness.other_error,
                "observed_guard": actual.guarded,
                "observed_scope": actual.affected_scope,
                "effect_ok": actual.effect_ok,
                "other_error": actual.other_error,
                "session_unchosen": actual.session_unchosen
            })
        );
        if !passed {
            failures.push(case.case_id.clone());
        }
    }
    println!(
        "OPERATION_SUMMARY {}",
        json!({"scenarios": cases.len(), "failed": failures.len(), "passed": cases.len() - failures.len()})
    );
    assert!(failures.is_empty(), "operation cases failed: {failures:?}");
}
