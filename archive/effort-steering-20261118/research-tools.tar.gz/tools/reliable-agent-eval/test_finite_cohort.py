"""Admission consumer tests: each malformed row otherwise admits the next slot."""
import copy,hashlib,importlib.util,json,tempfile,types,unittest
from pathlib import Path
P=Path(__file__).with_name("finite_cohort.py")
def subject():
    if not P.exists():return types.SimpleNamespace()
    spec=importlib.util.spec_from_file_location("finite_subject",P);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def settled(cost="0.20"):
    raw=json.dumps({"session_id":"session-one","total_cost_usd":cost}).encode()
    return {"start":{"session_id":"session-one"},"raw_bytes":raw,
            "spend":{"session_id":"session-one","client_reported_usd":cost,"raw_sha256":hashlib.sha256(raw).hexdigest()},
            "outcome":{"valid":True,"accepted":False}}
class Admission(unittest.TestCase):
    def function(self,name):
        fn=getattr(subject(),name,None);self.assertTrue(callable(fn),"missing "+name);return fn
    def admit(self,slots=None,label="T-S",**kw):
        options=dict(order=("T-L","T-S","T-X"),slots={"T-L":settled()} if slots is None else slots,
                     next_slot=label,prior="24.269845199999999810",phase_cap="7.20",cap="0.80",reserve="0.40",total_cap="40")
        options.update(kw);return self.function("admit")(**options)
    def test_settled_behavioral_miss_still_counts_cost_and_admits(self):
        self.assertEqual(self.admit(),{"phase_spent":"0.20","reservation":"1.20","cumulative_reserved":"25.669845199999999810"})
    def test_exact_phase_and_cumulative_boundaries(self):
        self.assertEqual(self.admit(slots={},label="T-L",prior="38.80",phase_cap="1.20")["cumulative_reserved"],"40.00")
        for change in ({"phase_cap":"1.19"},{"prior":"38.81"}):
            with self.subTest(change=change),self.assertRaises(ValueError):
                self.admit(slots={},label="T-L",**change)
    def test_unknown_charges_and_unfinished_outcome_block_real_consumer(self):
        for missing in ("raw_bytes","spend","outcome"):
            row=settled();del row[missing]
            with self.subTest(missing=missing),self.assertRaises(ValueError):self.admit({"T-L":row})
        row=settled();row["outcome"]["valid"]=False
        with self.assertRaises(ValueError):self.admit({"T-L":row})
    def test_malformed_cost_is_not_zero(self):
        for bad in (None,True,"NaN","Infinity","-0.01"):
            row=settled()
            raw=json.dumps({"session_id":"session-one","total_cost_usd":bad}).encode()
            row["raw_bytes"]=raw;row["spend"]["raw_sha256"]=hashlib.sha256(raw).hexdigest();row["spend"]["client_reported_usd"]=bad
            with self.subTest(cost=bad),self.assertRaises(ValueError):self.admit({"T-L":row})
        row=settled();row["raw_bytes"]=b'{"session_id":"session-one"}';row["spend"]["raw_sha256"]=hashlib.sha256(row["raw_bytes"]).hexdigest()
        with self.assertRaises(ValueError):self.admit({"T-L":row})
    def test_session_hash_and_saved_amount_are_consumed(self):
        mutations=(lambda r:r["start"].update(session_id="other"),
                   lambda r:r["spend"].update(session_id="other"),
                   lambda r:r["spend"].update(raw_sha256="0"*64),
                   lambda r:r["spend"].update(client_reported_usd="0.21"))
        for i,mutate in enumerate(mutations):
            row=settled();mutate(row)
            with self.subTest(mutation=i),self.assertRaises(ValueError):self.admit({"T-L":row})
    def test_wrong_order_orphans_and_already_started_are_rejected(self):
        cases=({"T-S":settled()},{"T-L":settled(),"T-S":{"start":{"session_id":"two"}}},
               {"unknown":settled()},{"T-L":{"spend":settled()["spend"]}})
        for i,rows in enumerate(cases):
            with self.subTest(case=i),self.assertRaises(ValueError):self.admit(rows)
        with self.assertRaises(ValueError):self.admit(label="T-X")
        with self.assertRaises(ValueError):self.admit(order=("T-L","T-L"))
    def test_observed_prior_overrun_stops_next_call(self):
        with self.assertRaises(ValueError):self.admit({"T-L":settled("0.81")})
    def test_fingerprint_empty_missing_symlink_and_drift(self):
        fn=self.function("verify_files")
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"fixture";p.write_bytes(b"original")
            identity={str(p):hashlib.sha256(b"original").hexdigest()}
            fn(identity)
            p.write_bytes(b"changed")
            with self.assertRaises(ValueError):fn(identity)
            with self.assertRaises(ValueError):fn({})
            with self.assertRaises(ValueError):fn({str(Path(d)/"missing"):"0"*64})
            target=Path(d)/"target";target.write_bytes(b"original");p.unlink();p.symlink_to(target)
            with self.assertRaises(ValueError):fn(identity)
    def test_endpoint_requires_every_nonempty_component(self):
        fn=self.function("endpoint");counts={"passed":1,"failed":0,"ignored":0}
        good={"kind":"behavior","accepted":True,"full":counts,"required":counts}
        self.assertTrue(fn([good,copy.deepcopy(good)]));self.assertFalse(fn([]))
        for bad in ({"kind":"compile"},dict(good,accepted=False),dict(good,full={**counts,"passed":0}),
                    dict(good,required={**counts,"ignored":1}),dict(good,full={**counts,"failed":1})):
            with self.subTest(bad=bad):self.assertFalse(fn([good,bad]))
if __name__=="__main__":unittest.main()
