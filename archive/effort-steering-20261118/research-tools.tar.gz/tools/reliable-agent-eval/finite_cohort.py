"""Fail-closed admission and fixed-component verdicts for a finite pilot."""
import hashlib
import json
from decimal import Decimal, InvalidOperation
from pathlib import Path


def money(value):
    if isinstance(value, bool) or not isinstance(value, (str, int, Decimal)):
        raise ValueError("missing or invalid cost")
    try:
        result = Decimal(value)
    except InvalidOperation as exc:
        raise ValueError("invalid cost") from exc
    if not result.is_finite() or result < 0:
        raise ValueError("nonfinite or negative cost")
    return result


def receipt_cost(row):
    try:
        start, spend, outcome = row["start"], row["spend"], row["outcome"]
        raw_bytes = row["raw_bytes"]
        raw = json.loads(raw_bytes, parse_float=Decimal)
        sid = start["session_id"]
        if not isinstance(sid, str) or not sid:
            raise ValueError("missing session identity")
        if raw["session_id"] != sid or spend["session_id"] != sid:
            raise ValueError("session mismatch")
        if hashlib.sha256(raw_bytes).hexdigest() != spend["raw_sha256"]:
            raise ValueError("raw receipt changed")
        cost = money(raw["total_cost_usd"])
        if cost != money(spend["client_reported_usd"]):
            raise ValueError("saved charge mismatch")
        if outcome["valid"] is not True:
            raise ValueError("invalid prior outcome")
        return cost
    except (KeyError, TypeError, json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise ValueError("unsettled or malformed receipt") from exc


def admit(*, order, slots, next_slot, prior, phase_cap, cap, reserve, total_cap):
    if not order or any(not isinstance(x, str) or not x for x in order):
        raise ValueError("invalid slot order")
    if len(set(order)) != len(order) or next_slot not in order:
        raise ValueError("ambiguous slot order")
    position = order.index(next_slot)
    if not isinstance(slots, dict) or set(slots) != set(order[:position]):
        raise ValueError("orphan, gap, future or already-started slot")
    prior, phase_cap, cap, reserve, total_cap = map(
        money, (prior, phase_cap, cap, reserve, total_cap)
    )
    phase_spent = Decimal("0.00")
    for label in order[:position]:
        cost = receipt_cost(slots[label])
        if cost > cap:
            raise ValueError("observed per-session overrun")
        phase_spent += cost
    reservation = cap + reserve
    cumulative_reserved = prior + phase_spent + reservation
    if phase_spent + reservation > phase_cap or cumulative_reserved > total_cap:
        raise ValueError("budget admission refused")
    return {
        "phase_spent": str(phase_spent),
        "reservation": str(reservation),
        "cumulative_reserved": str(cumulative_reserved),
    }


def verify_files(mapping):
    if not isinstance(mapping, dict) or not mapping:
        raise ValueError("empty fingerprint population")
    for name, expected in mapping.items():
        path = Path(name)
        if path.is_symlink() or not path.is_file():
            raise ValueError("missing or linked frozen input: " + str(path))
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError("frozen input changed: " + str(path))


def endpoint(components):
    if not components:
        return False
    for component in components:
        if component.get("kind") != "behavior" or component.get("accepted") is not True:
            return False
        for key in ("full", "required"):
            counts = component.get(key, {})
            if any(type(counts.get(k)) is not int for k in ("passed", "failed", "ignored")):
                return False
            if counts["passed"] <= 0 or counts["failed"] != 0 or counts["ignored"] != 0:
                return False
    return True
