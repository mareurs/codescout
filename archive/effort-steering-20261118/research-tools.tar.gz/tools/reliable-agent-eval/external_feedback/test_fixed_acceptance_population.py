"""Actual consuming population/binding contracts; Docker is tested separately."""
import hashlib,importlib.util,json,tempfile,unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parent
def module(name):
    s=importlib.util.spec_from_file_location("fct_population_"+name,ROOT/(name+".py"))
    m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
subject=module("fixed_acceptance")
real_adapter=module("adapter")
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open("x") as f:json.dump(value,f)
def listing(names):return "".join(name+": test\n" for name in names)+f"\n{len(names)} tests, 0 benchmarks\n"
def report(rows):
    failed=sum(status=="FAILED" for _,status in rows)
    lines="".join(f"test {name} ... {status}\n" for name,status in rows)
    return f"running {len(rows)} tests\n"+lines+f"\ntest result: {'FAILED' if failed else 'ok'}. {len(rows)-failed} passed; {failed} failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s\n"

class AdapterFixture:
    def __init__(self,root,names=("fixed_f","fixed_p","new_case"),rows=None,corrupt=None,list_compile=False):
        self.names=names;self.rows=rows if rows is not None else [(name,"ok") for name in names]
        self.corrupt=corrupt;self.list_compile=list_compile
        self.capture=root/"capture";self.capture.mkdir()
        (self.capture/"candidate.patch").write_text("candidate patch")
        write(self.capture/"candidate.json",{"patch_sha256":digest(self.capture/"candidate.patch"),"files":{"src/lib.rs":"current-source"}})
        self.config={"full_args":["test","--package","example","--lib","--","state"],"full_names":["fixed_f","fixed_p"]}
    sha=staticmethod(digest)
    save=staticmethod(write)
    classify=staticmethod(real_adapter.classify)
    def evaluate(self,config,capture,args,out,oracle=False,author_artifacts=False):
        if not oracle or author_artifacts:raise AssertionError("fixed stages must use oracle only")
        out=Path(out);out.mkdir(parents=True)
        listed="--list" in args
        if listed:
            text="error: could not compile example (lib test)\n" if self.list_compile else listing(self.names)
            code=101 if self.list_compile else 0
        else:text=report(self.rows);code=101 if any(s=="FAILED" for _,s in self.rows) else 0
        (out/"cargo.log").write_text(text)
        cap=json.loads((Path(capture)/"candidate.json").read_text())
        proc={"exit_code":code,"timed_out":False,"argv":["docker","exec","fixture","cargo",*args],"oracle":True,"patch_sha256":cap["patch_sha256"],"log_sha256":digest(out/"cargo.log")}
        binding={"expected":cap["files"],"actual":cap["files"],"patch_sha256":cap["patch_sha256"]}
        if listed and self.corrupt:
            if self.corrupt=="oracle":proc["oracle"]=False
            elif self.corrupt=="command":proc["argv"][-1]="other-target"
            elif self.corrupt=="log":proc["log_sha256"]="wrong"
            elif self.corrupt=="patch":proc["patch_sha256"]="wrong"
            elif self.corrupt=="source":binding["actual"]={}
            elif self.corrupt=="timeout":proc["timed_out"]=True
            elif self.corrupt=="capture":(Path(capture)/"candidate.patch").write_text("changed after capture")
        write(out/"source-binding.json",binding);write(out/"process.json",proc)
        return proc

class PopulationTests(unittest.TestCase):
    def fn(self,name):
        self.assertTrue(callable(getattr(subject,name,None)),"missing fixed-acceptance feature: "+name)
        return getattr(subject,name)

    def test_retained_axum_eight_case_log_keeps_seven_required_and_one_additional(self):
        fn=self.fn("evaluate_fixed")
        data=ROOT/"test_data";meta=json.loads((data/"axum1730-added-test.json").read_text())
        fixture=data/"axum1730-added-test.log"
        self.assertEqual(digest(fixture),meta["log_sha256"])
        class RecordedFixture(AdapterFixture):
            def evaluate(self,config,capture,args,out,**kwargs):
                result=super().evaluate(config,capture,args,out,**kwargs)
                if Path(out).name=="execution":
                    log=Path(out)/"cargo.log";log.write_bytes(fixture.read_bytes())
                    path=Path(out)/"process.json";value=json.loads(path.read_text());value["log_sha256"]=digest(log);path.write_text(json.dumps(value))
                return result
        with tempfile.TemporaryDirectory(prefix="fct-real-log-") as tmp:
            root=Path(tmp);a=RecordedFixture(root,names=tuple(meta["required"]+meta["additional"]))
            a.config["full_names"]=meta["required"]
            result=fn(a,a.config,a.capture,root/"grade")
            self.assertTrue(result["accepted"])
            self.assertEqual(result["full"]["passed"],8)
            self.assertEqual(result["required"]["passed"],7)
            self.assertEqual(result["additional"]["passed"],1)

    def test_legitimate_added_case_passes_without_inflating_required_count(self):
        fn=self.fn("evaluate_fixed")
        with tempfile.TemporaryDirectory(prefix="fct-pop-") as tmp:
            root=Path(tmp);a=AdapterFixture(root);out=root/"grade"
            result=fn(a,a.config,a.capture,out)
            self.assertTrue(result["accepted"])
            self.assertEqual(result["full"]["passed"],3)
            self.assertEqual(result["required"]["passed"],2)
            self.assertEqual(result["additional"]["passed"],1)
            self.assertEqual(result["additional"]["results"],{"new_case":"ok"})
            self.assertEqual(json.loads((out/"grade.json").read_text()),result)
            with self.assertRaises(FileExistsError):fn(a,a.config,a.capture,out)
    def test_missing_required_case_cannot_be_replaced_by_an_extra(self):
        fn=self.fn("evaluate_fixed")
        with tempfile.TemporaryDirectory(prefix="fct-pop-") as tmp:
            root=Path(tmp);a=AdapterFixture(root,names=("fixed_f","new_case"))
            result=fn(a,a.config,a.capture,root/"grade")
            self.assertFalse(result["accepted"])
            self.assertEqual(result["kind"],"missing_required")
            self.assertEqual(result["missing_required"],["fixed_p"])
            self.assertFalse((root/"grade/execution").exists())
    def test_added_failure_rejects_whole_workflow_even_when_fixed_cases_pass(self):
        fn=self.fn("evaluate_fixed")
        with tempfile.TemporaryDirectory(prefix="fct-pop-") as tmp:
            root=Path(tmp);a=AdapterFixture(root,rows=[("fixed_f","ok"),("fixed_p","ok"),("new_case","FAILED")])
            result=fn(a,a.config,a.capture,root/"grade")
            self.assertFalse(result["accepted"])
            self.assertEqual(result["required"]["passed"],2)
            self.assertEqual(result["required"]["failed"],0)
            self.assertEqual(result["additional"]["failed"],1)
    def test_population_drift_between_listing_and_execution_is_rejected(self):
        fn=self.fn("evaluate_fixed")
        with tempfile.TemporaryDirectory(prefix="fct-pop-") as tmp:
            root=Path(tmp);a=AdapterFixture(root,rows=[("fixed_f","ok"),("fixed_p","ok")])
            with self.assertRaises(ValueError):fn(a,a.config,a.capture,root/"grade")
    def test_consuming_path_rejects_bad_source_command_oracle_bytes_and_timeout(self):
        fn=self.fn("evaluate_fixed")
        for defect in ("oracle","command","log","patch","source","timeout","capture"):
            with self.subTest(defect=defect),tempfile.TemporaryDirectory(prefix="fct-pop-") as tmp:
                root=Path(tmp);a=AdapterFixture(root,corrupt=defect)
                with self.assertRaises(ValueError):fn(a,a.config,a.capture,root/"grade")


    def test_empty_duplicate_or_invalid_required_population_cannot_accept_extras(self):
        fn=self.fn("evaluate_fixed")
        for names in ([],["fixed_f","fixed_f"],[""],["fixed_f",1],"fixed_f"):
            with self.subTest(names=names),tempfile.TemporaryDirectory(prefix="fct-pop-") as tmp:
                root=Path(tmp);a=AdapterFixture(root);a.config["full_names"]=names
                with self.assertRaises(ValueError):fn(a,a.config,a.capture,root/"grade")

    def test_metadata_and_config_changes_are_rejected_even_if_source_binding_matches(self):
        fn=self.fn("evaluate_fixed")
        for defect in ("metadata","config"):
            class ChangingIdentity(AdapterFixture):
                def evaluate(self,config,capture,args,out,**kwargs):
                    result=super().evaluate(config,capture,args,out,**kwargs)
                    if Path(out).name=="listing":
                        if defect=="metadata":
                            path=Path(capture)/"candidate.json";value=json.loads(path.read_text());value["head"]="changed";path.write_text(json.dumps(value))
                        else:config["full_args"].append("--ignored")
                    return result
            with self.subTest(defect=defect),tempfile.TemporaryDirectory(prefix="fct-pop-") as tmp:
                root=Path(tmp);a=ChangingIdentity(root)
                with self.assertRaises(ValueError):fn(a,a.config,a.capture,root/"grade")

    def test_execution_receipt_is_checked_as_well_as_listing_receipt(self):
        fn=self.fn("evaluate_fixed")
        for defect in ("oracle","command","log","source","timeout"):
            class ChangingExecution(AdapterFixture):
                def evaluate(self,config,capture,args,out,**kwargs):
                    result=super().evaluate(config,capture,args,out,**kwargs)
                    if Path(out).name=="execution":
                        path=Path(out)/("source-binding.json" if defect=="source" else "process.json")
                        value=json.loads(path.read_text())
                        if defect=="source":value["actual"]={}
                        elif defect=="oracle":value["oracle"]=False
                        elif defect=="command":value["argv"][-1]="wrong-target"
                        elif defect=="log":value["log_sha256"]="wrong"
                        else:value["timed_out"]=True
                        path.write_text(json.dumps(value))
                    return result
            with self.subTest(defect=defect),tempfile.TemporaryDirectory(prefix="fct-pop-") as tmp:
                root=Path(tmp);a=ChangingExecution(root)
                with self.assertRaises(ValueError):fn(a,a.config,a.capture,root/"grade")

    def test_fixed_fixture_bytes_cannot_change_between_stages(self):
        fn=self.fn("evaluate_fixed")
        class ChangingFixture(AdapterFixture):
            def evaluate(self,config,capture,args,out,**kwargs):
                result=super().evaluate(config,capture,args,out,**kwargs)
                if Path(out).name=="listing":
                    Path(config["test_patch"]).write_text("changed fixed oracle")
                return result
        with tempfile.TemporaryDirectory(prefix="fct-pop-") as tmp:
            root=Path(tmp);a=ChangingFixture(root)
            fixture=root/"fixed.patch";fixture.write_text("fixed oracle")
            a.config["test_patch"]=str(fixture)
            with self.assertRaises(ValueError):fn(a,a.config,a.capture,root/"grade")

    def test_expected_source_inventory_is_checked_independently_at_both_stages(self):
        fn=self.fn("evaluate_fixed")
        for stage in ("listing","execution"):
            class WrongExpected(AdapterFixture):
                def evaluate(self,config,capture,args,out,**kwargs):
                    result=super().evaluate(config,capture,args,out,**kwargs)
                    if Path(out).name==stage:
                        path=Path(out)/"source-binding.json"
                        value=json.loads(path.read_text())
                        value["expected"]={"src/unrelated.rs":"different-source"}
                        path.write_text(json.dumps(value))
                    return result
            with self.subTest(stage=stage),tempfile.TemporaryDirectory(prefix="fct-pop-") as tmp:
                root=Path(tmp);a=WrongExpected(root)
                with self.assertRaisesRegex(ValueError,"byte binding failed"):
                    fn(a,a.config,a.capture,root/"grade")

    def test_second_fixture_patch_bytes_cannot_change_at_either_stage(self):
        fn=self.fn("evaluate_fixed")
        for stage in ("listing","execution"):
            class ChangingSecondFixture(AdapterFixture):
                def evaluate(self,config,capture,args,out,**kwargs):
                    result=super().evaluate(config,capture,args,out,**kwargs)
                    if Path(out).name==stage:
                        Path(config["fixture_patch"]).write_text("changed prerequisite fixture")
                    return result
            with self.subTest(stage=stage),tempfile.TemporaryDirectory(prefix="fct-pop-") as tmp:
                root=Path(tmp);a=ChangingSecondFixture(root)
                oracle=root/"oracle.patch";oracle.write_text("fixed oracle")
                fixture=root/"fixture.patch";fixture.write_text("fixed prerequisite")
                a.config.update(test_patch=str(oracle),fixture_patch=str(fixture))
                with self.assertRaisesRegex(ValueError,"fixed fixtures or configuration changed"):
                    fn(a,a.config,a.capture,root/"grade")

    def test_compile_failure_does_not_invent_passing_or_empty_test_counts(self):
        fn=self.fn("evaluate_fixed")
        with tempfile.TemporaryDirectory(prefix="fct-pop-") as tmp:
            root=Path(tmp);a=AdapterFixture(root,list_compile=True)
            result=fn(a,a.config,a.capture,root/"grade")
            self.assertFalse(result["accepted"])
            self.assertEqual(result["kind"],"compile")
            self.assertIsNone(result["full"])
            self.assertIsNone(result["required"])
            self.assertFalse((root/"grade/execution").exists())
    def test_listing_command_preserves_target_and_one_separator(self):
        fn=self.fn("listing_args")
        self.assertEqual(fn(["test","--lib","--","state"]),["test","--lib","--","state","--list"])
        self.assertEqual(fn(["test","--test","sync","--no-fail-fast"]),["test","--test","sync","--no-fail-fast","--","--list"])
        for args in ([],["check"],["test","--lib","--","--list"],["test","--","--","state"]):
            with self.subTest(args=args),self.assertRaises(ValueError):fn(args)
    def test_list_requires_one_complete_unique_nonbenchmark_population(self):
        fn=self.fn("parse_listing")
        self.assertEqual(fn("warning: note\nf: test\np: test\n\n2 tests, 0 benchmarks\n",0),["f","p"])
        bad=["f: test\nf: test\n2 tests, 0 benchmarks\n","f: test\n2 tests, 0 benchmarks\n","f: test\n1 test, 1 benchmark\n","f: test\n1 test, 0 benchmarks\n1 test, 0 benchmarks\n","0 tests, 0 benchmarks\n"]
        for text in bad:
            with self.subTest(text=text),self.assertRaises(ValueError):fn(text,0)
        with self.assertRaises(ValueError):fn("f: test\n1 test, 0 benchmarks\n",101)

if __name__=="__main__":unittest.main()
