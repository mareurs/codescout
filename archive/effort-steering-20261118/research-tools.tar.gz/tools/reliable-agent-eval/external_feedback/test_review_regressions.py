import importlib.util
from pathlib import Path
import unittest

s=importlib.util.spec_from_file_location('review_adapter',Path(__file__).parent/'adapter.py')
a=importlib.util.module_from_spec(s)
s.loader.exec_module(a)


class ReviewRegressions(unittest.TestCase):
    def test_failed_active_calibration_cannot_be_called_inactive(self):
        self.assertIsNone(a.next_label({'C1':{'valid':True,'accepted':True,'active':False,'feedback_blocks':1}}))

    def test_block_count_limits_feedback_even_when_hook_active_false(self):
        self.assertEqual(a.decision('G',{'kind':'behavior','failed':1},1,False),'allow')

    def test_invalid_holdout_g_stops_x(self):
        self.assertIsNone(a.next_label({'C1':{'valid':True,'accepted':True,'active':True},'G':{'valid':False,'accepted':False,'active':False}}))
