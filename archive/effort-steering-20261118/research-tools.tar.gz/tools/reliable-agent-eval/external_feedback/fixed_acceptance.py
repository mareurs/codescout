"""Source-bound fixed acceptance with candidate-added tests; no model calls."""
import copy
import json
from pathlib import Path
import re


def listing_args(args):
    """Keep the configured target; add libtest enumeration after one separator."""
    args = list(args)
    if not args or args[0] != "test" or args.count("--") > 1 or "--list" in args:
        raise ValueError("Unsupported or already-enumerated Cargo target")
    return args + (["--list"] if "--" in args else ["--", "--list"])


def parse_listing(text, exit_code):
    """One complete libtest binary listing, not a sample of named tests."""
    names = re.findall(r"^(.+): test$", text, re.M)
    footers = re.findall(r"^(\d+) tests?, (\d+) benchmarks?$", text, re.M)
    if (type(exit_code) is not int or exit_code != 0 or len(footers) != 1
            or int(footers[0][1]) != 0 or int(footers[0][0]) != len(names)
            or not names or len(names) != len(set(names))):
        raise ValueError("Incomplete, duplicate or unsupported test listing")
    return sorted(names)


def _read(path):
    return json.loads(Path(path).read_text())


def _identity(adapter, capture):
    capture = Path(capture)
    candidate = _read(capture / "candidate.json")
    if (not isinstance(candidate.get("files"), dict)
            or adapter.sha(capture / "candidate.patch") != candidate.get("patch_sha256")):
        raise ValueError("Capture patch or inventory metadata changed")
    return dict(candidate_sha256=adapter.sha(capture / "candidate.json"),
                patch_sha256=candidate["patch_sha256"], files=candidate["files"])


def validate_binding(adapter, config, capture, execution, args):
    """Validate actual process/log/source evidence, not only evaluator return values."""
    capture, execution = Path(capture), Path(execution)
    identity = _identity(adapter, capture)
    process = _read(execution / "process.json")
    binding = _read(execution / "source-binding.json")
    suffix = ["cargo", *args]
    if (process.get("oracle") is not True or process.get("timed_out") is not False
            or process.get("argv", [])[-len(suffix):] != suffix
            or process.get("patch_sha256") != identity["patch_sha256"]
            or process.get("log_sha256") != adapter.sha(execution / "cargo.log")
            or binding.get("patch_sha256") != identity["patch_sha256"]
            or binding.get("expected") != identity["files"]
            or binding.get("actual") != identity["files"]):
        raise ValueError("Fixed acceptance source, command, oracle or byte binding failed")
    return process


def _fixture_identity(adapter, config):
    return {str(config[key]): adapter.sha(Path(config[key]))
            for key in ("test_patch", "fixture_patch") if config.get(key)}


def _subset(results, names):
    selected = {name: results[name] for name in names}
    return dict(results=selected, passed=sum(value == "ok" for value in selected.values()),
                failed=sum(value == "FAILED" for value in selected.values()),
                ignored=sum(value == "ignored" for value in selected.values()))


def evaluate_fixed(adapter, config, capture, out):
    """Enumerate and run the same fixed-fixture candidate; keep denominators separate."""
    config = copy.deepcopy(config)
    args = list(config["full_args"])
    required = config["full_names"]
    if (not isinstance(required, list) or not required
            or any(not isinstance(name, str) or not name for name in required)
            or len(required) != len(set(required))):
        raise ValueError("Required fixed population must be unique and nonempty")
    required = sorted(required)
    list_args = listing_args(args)
    capture, out = Path(capture), Path(out)
    identity = _identity(adapter, capture)
    fixture_identity = _fixture_identity(adapter, config)
    configuration = json.dumps(config, sort_keys=True)
    out.mkdir(parents=True, exist_ok=False)

    def stable():
        if (_identity(adapter, capture) != identity
                or _fixture_identity(adapter, config) != fixture_identity
                or json.dumps(config, sort_keys=True) != configuration):
            raise ValueError("Capture, fixed fixtures or configuration changed across stages")

    def run(stage, command):
        destination = out / stage
        stable()
        adapter.evaluate(config, capture, command, destination, oracle=True)
        process = validate_binding(adapter, config, capture, destination, command)
        stable()
        return process, (destination / "cargo.log").read_text()

    def finish(kind, accepted=False, full=None, fixed=None, additional=None, **extra):
        result = dict(kind=kind, accepted=accepted, full=full, required=fixed,
                      additional=additional, source=identity,
                      fixed_input_sha256=fixture_identity, **extra)
        adapter.save(out / "grade.json", result)
        return result

    listed, text = run("listing", list_args)
    if listed["exit_code"] != 0:
        classified = adapter.classify(text, listed["exit_code"], required)
        if classified["kind"] == "compile":
            return finish("compile", failed_stage="listing")
        raise ValueError("Listing did not return a complete test population")
    names = parse_listing(text, listed["exit_code"])
    missing = sorted(set(required) - set(names))
    extra_names = sorted(set(names) - set(required))
    population = dict(required_names=required, enumerated_names=names,
                      additional_names=extra_names, source=identity,
                      fixed_input_sha256=fixture_identity,
                      listing_process_sha256=adapter.sha(out / "listing/process.json"))
    adapter.save(out / "population.json", population)
    if missing:
        return finish("missing_required", missing_required=missing, population=population)

    executed, text = run("execution", args)
    full = adapter.classify(text, executed["exit_code"], names)
    if full["kind"] == "compile":
        return finish("compile", failed_stage="execution", population=population)
    fixed = _subset(full["results"], required)
    additional = _subset(full["results"], extra_names)
    accepted = full["failed"] == 0 and fixed["passed"] == len(required)
    return finish("behavior", accepted, full, fixed, additional, population=population,
                  execution_process_sha256=adapter.sha(out / "execution/process.json"))
