import importlib.util
import pathlib
import tempfile
import unittest

HERE = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('external_adapter', HERE / 'adapter.py')
a = importlib.util.module_from_spec(spec)
if (HERE / 'adapter.py').exists(): spec.loader.exec_module(a)


def report(status='ok', name='behavior', extra=''):
    failed = int(status == 'FAILED')
    return f'running 1 test\ntest {name} ... {status}\n\n{extra}test result: {"FAILED" if failed else "ok"}. {1-failed} passed; {failed} failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s\n'


class Contracts(unittest.TestCase):
    def test_complete_behavior_and_compile_are_distinct(self):
        self.assertEqual(a.classify(report('FAILED'), 101, ['behavior'])['kind'], 'behavior')
        self.assertEqual(a.classify(report(), 0, ['behavior'])['kind'], 'behavior')
        self.assertEqual(a.classify('error[E0425]: missing\nerror: could not compile `x` due to previous error\n', 101, ['behavior'])['kind'], 'compile')

    def test_incomplete_process_and_resource_reports_are_invalid(self):
        for text, code in [(report(),101),(report(),137),(report(name='different'),0),('running 1 test\ntest behavior ... ok\n',0),(report(extra='error: could not compile `other`\n'),101),('error: could not compile `x`\nCaused by: process terminated (signal: 9, SIGKILL)\n',101)]:
            with self.subTest(text=text, code=code):
                with self.assertRaises(ValueError): a.classify(text,code,['behavior'])

    def test_decision_only_blocks_once_on_complete_behavioral_failure(self):
        failed={'kind':'behavior','failed':1}
        self.assertEqual(a.decision('G',failed,0,False),'block')
        self.assertEqual(a.decision('G',failed,1,True),'allow')
        self.assertEqual(a.decision('X',failed,0,False),'allow')
        self.assertEqual(a.decision('G',{'kind':'compile'},0,False),'allow')
        with self.assertRaises(ValueError):a.decision('G',failed,-1,False)

    def test_calibration_and_holdout_stops_differ(self):
        self.assertEqual(a.next_label({'C1':{'valid':True,'accepted':True,'active':False}}),'C2')
        self.assertEqual(a.next_label({'C1':{'valid':True,'accepted':True,'active':True}}),'G')
        self.assertIsNone(a.next_label({'C1':{'valid':True,'accepted':False,'active':True}}))
        self.assertIsNone(a.next_label({'C1':{'valid':False,'accepted':True,'active':True}}))
        self.assertIsNone(a.next_label({'C1':{'valid':True,'accepted':True,'active':False},'C2':{'valid':True,'accepted':True,'active':False}}))
        self.assertEqual(a.next_label({'C1':{'valid':True,'accepted':True,'active':True},'G':{'valid':True,'accepted':False,'active':True}}),'X')

    def test_fidelity_observes_deletion_addition_and_mode(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp)
            a.git(root,'init','-q');a.git(root,'config','user.email','test@example.invalid');a.git(root,'config','user.name','test')
            (root/'source').write_text('before');(root/'.gitignore').write_text('ignored\n');a.git(root,'add','.');a.git(root,'commit','-qm','base')
            before=a.inventory(root)
            (root/'source').unlink();(root/'ignored').write_text('new');(root/'executable').write_text('hi');(root/'executable').chmod(0o755)
            got=a.capture(root,root.parent/(root.name+'-capture'))
            self.assertNotIn('source',got['files']);self.assertIn('ignored',got['files']);self.assertNotEqual(got['files'],before)
            self.assertIn(b'ignored', (pathlib.Path(got['directory'])/'candidate.patch').read_bytes())
            old=a.inventory(root);(root/'executable').chmod(0o644);self.assertNotEqual(old,a.inventory(root))

    def test_patch_binding_and_anchor_admission_fail_closed(self):
        self.assertEqual(a.reserve('15.741437499999999835',[],['.45','.45','.60','1.70']),'19.941437499999999835')
        for prior,charges in [('19',[0]),('NaN',[]),('15',[-1])]:
            with self.assertRaises(ValueError):a.reserve(prior,charges,['.45','.45','.60','1.70'])
        with tempfile.TemporaryDirectory() as tmp:
            p=pathlib.Path(tmp)/'artifact';p.write_bytes(b'first');a.verify_files({str(p):a.sha(p)})
            p.write_bytes(b'second')
            with self.assertRaises(ValueError):a.verify_files({str(p):'a'*64})


if __name__=='__main__':unittest.main()
