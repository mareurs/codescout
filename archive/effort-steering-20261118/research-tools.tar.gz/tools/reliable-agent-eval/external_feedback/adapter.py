"""Bounded external behavioral checks. No model invocation or paid action on import."""
import contextlib
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import time
import uuid

sys.path.insert(0, str(Path(__file__).resolve().parent))
import snapshot_artifacts

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'compile_mechanism'))
from mechanism import parse_cargo, reserve_block


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')


def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args])


def inventory(root):
    root = Path(root)
    names = git(root, 'ls-files', '--cached', '--others', '-z').decode().strip('\0').split('\0')
    result = {}
    for name in sorted(set(names) - {''}):
        p = root / name
        if not p.exists() and not p.is_symlink():
            continue
        mode = p.lstat().st_mode
        if stat.S_ISLNK(mode):
            result[name] = 'symlink:' + str(p.readlink())
        elif stat.S_ISREG(mode):
            result[name] = str(mode & 0o111) + ':' + sha(p)
        else:
            raise ValueError('Nonregular source path: ' + name)
    return result


def capture(root, directory):
    root, directory = Path(root), Path(directory)
    directory.mkdir(parents=True, exist_ok=False)
    files = inventory(root)
    patch = git(root, 'diff', '--binary', 'HEAD')
    extra = git(root, 'ls-files', '--others', '-z').decode().strip('\0').split('\0')
    for name in sorted(set(extra) - {''}):
        p = subprocess.run(['git', 'diff', '--no-index', '--binary', '--', '/dev/null', name], cwd=root, capture_output=True)
        if p.returncode not in (0, 1):
            raise ValueError(p.stderr.decode(errors='replace'))
        patch += p.stdout
    (directory / 'candidate.patch').write_bytes(patch)
    result = {'files': files, 'patch_sha256': sha(directory / 'candidate.patch'), 'workspace': str(root), 'directory': str(directory), 'head': git(root, 'rev-parse', 'HEAD').decode().strip()}
    save(directory / 'candidate.json', result)
    return result


def classify(text, exit_code, expected):
    if type(exit_code) is not int or exit_code not in (0, 101):
        raise ValueError('Invalid Cargo process status')
    if re.search(r'SIGKILL|SIGABRT|signal: [69]|out of memory|No space left|IO Safety violation|failed to download|failed to get .*dependency|failed to write', text, re.I):
        raise ValueError('Resource/environment failure')
    reports = re.search(r'^running \d+ tests?$', text, re.M)
    compile_error = re.search(r'^error(?:\[E\d+\])?: could not compile ', text, re.M)
    if exit_code == 101 and compile_error and not reports:
        return {'kind': 'compile', 'passed': 0, 'failed': 0, 'results': {}}
    if compile_error:
        raise ValueError('Mixed compile and behavioral report')
    return dict(kind='behavior', **parse_cargo(text, exit_code, expected))


def decision(arm, result, blocked, active):
    if arm not in ('G', 'X') or type(blocked) is not int or blocked not in (0, 1) or type(active) is not bool:
        raise ValueError('Invalid gate state')
    return 'block' if arm == 'G' and not blocked and not active and result['kind'] == 'behavior' and result['failed'] else 'allow'


def next_label(outcomes):
    for name in ('C1', 'C2'):
        if name not in outcomes:
            return name
        o = outcomes[name]
        if not o['valid'] or not o['accepted']:
            return None
        if o['active']:
            break
        if o.get('feedback_blocks', 0):
            return None
    else:
        return None
    if 'G' not in outcomes:
        return 'G'
    if not outcomes['G']['valid']:
        return None
    return 'X' if 'X' not in outcomes else None


def reserve(prior, charges, pending):
    return reserve_block(prior, charges, pending, cap='20.00', reserve='1.00')


def verify_files(files):
    for name, digest in files.items():
        if sha(name) != digest:
            raise ValueError('Frozen input changed: ' + name)


@contextlib.contextmanager
def container(config, evidence):
    evidence = Path(evidence)
    evidence.mkdir(parents=True, exist_ok=False)
    argv = ['docker', 'create', '--label', 'codescout.phase=external-feedback-20261029', '--network', 'none', '--cpus', '4', '--memory', '4g', '--pids-limit', '512', '--entrypoint', '/bin/sh', config['image_id'], '-c', 'sleep 86400']
    cid = subprocess.check_output(argv, text=True).strip()
    save(evidence / 'container.json', {'id': cid, 'argv': argv})
    try:
        subprocess.run(['docker', 'start', cid], check=True, capture_output=True)
        def checked(*args, input=None):
            return subprocess.run(['docker', 'exec', '-i', '-w', '/testbed', cid, *args], input=input, capture_output=True, check=True).stdout
        base = checked('git', 'rev-parse', 'HEAD').decode().strip()
        if base != config['base_commit']:
            raise ValueError('Image base mismatch')
        checked('git', 'reset', '--hard', base)
        checked('git', 'clean', '-fd')
        checked('mv', '/testbed/target', '/tmp/external-target')
        tracked = checked('git', 'ls-files', '-z')
        for name, path in config.get('extra_files', {}).items():
            if name != 'Cargo.lock':
                raise ValueError('Unsupported image dependency fixture')
            checked('sh', '-c', 'cat > Cargo.lock', input=Path(path).read_bytes())
            tracked += name.encode() + b'\0'
        checked('sh', '-c', 'cat > /tmp/external-base-paths', input=tracked)
        checked('rm', '-rf', '/testbed/.git')
        checked('git', 'init', '-q')
        checked('git', 'config', 'user.name', 'external-eval')
        checked('git', 'config', 'user.email', 'external-eval@example.invalid')
        if config.get('fixture_patch'):
            checked('git', 'apply', '-', input=Path(config['fixture_patch']).read_bytes())
        checked('git', 'add', '-f', '--pathspec-from-file=/tmp/external-base-paths', '--pathspec-file-nul')
        checked('git', 'commit', '-qm', 'Frozen task source')
        yield cid, checked
    finally:
        p = subprocess.run(['docker', 'rm', '-f', cid], capture_output=True)
        save(evidence / 'cleanup.json', {'exit_code': p.returncode, 'stderr': p.stderr.decode(errors='replace')})


def remote_inventory(checked):
    # Execute exactly the host inventory algorithm inside the disposable container.
    import inspect
    source = 'import hashlib,stat,subprocess\nfrom pathlib import Path\n' + inspect.getsource(sha) + '\n' + inspect.getsource(git) + '\n' + inspect.getsource(inventory) + '\nimport json\nprint(json.dumps(inventory(Path("/testbed")),sort_keys=True))\n'
    return json.loads(checked('python3', '-c', source))


def evaluate(config, snapshot, args, out, oracle=False, author_artifacts=False):
    if oracle and author_artifacts:
        raise ValueError('Independent oracle cannot export author artifacts')
    snapshot, out = Path(snapshot), Path(out)
    captured = json.loads((snapshot / 'candidate.json').read_text())
    if sha(snapshot / 'candidate.patch') != captured['patch_sha256']:
        raise ValueError('Candidate patch changed')
    if not args or args[0] not in ('test', 'check'):
        raise ValueError('Only Cargo test/check supported')
    began = time.monotonic()
    with container(config, out) as (cid, checked):
        patch = (snapshot / 'candidate.patch').read_bytes()
        if patch:
            checked('git', 'apply', '-', input=patch)
        actual = remote_inventory(checked)
        save(out / 'source-binding.json', {'expected': captured['files'], 'actual': actual, 'patch_sha256': captured['patch_sha256']})
        if actual != captured['files']:
            raise ValueError('Container source differs from exact captured source')
        if oracle:
            for name, exists_at_base in config['test_paths'].items():
                if exists_at_base:
                    checked('git', 'checkout', 'HEAD', '--', name)
                else:
                    checked('rm', '-f', '--', name)
            checked('git', 'apply', '-', input=Path(config['test_patch']).read_bytes())
        argv = ['docker', 'exec', '-w', '/testbed', '-e', 'RUSTFLAGS=-Awarnings', '-e', 'CARGO_BUILD_JOBS=2', '-e', 'CARGO_NET_OFFLINE=true', '-e', 'CARGO_TARGET_DIR=/tmp/external-target', cid, 'cargo', *args]
        timed_out = False
        try:
            p = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=600)
            data, code = p.stdout, p.returncode
        except subprocess.TimeoutExpired as exc:
            data, code, timed_out = exc.stdout or b'', None, True
        (out / 'cargo.log').write_bytes(data)
        result = {'exit_code': code, 'timed_out': timed_out, 'wall_s': time.monotonic() - began, 'argv': argv, 'log_sha256': sha(out / 'cargo.log'), 'patch_sha256': captured['patch_sha256'], 'oracle': oracle}
        if author_artifacts and not timed_out:
            result['author_artifacts'] = snapshot_artifacts.collect_snapshots(checked, captured, out)
        save(out / 'process.json', result)
    return result


def shim(config_path, args):
    config = json.loads(Path(config_path).read_text())
    root, trace = Path(config['workspace']), Path(config['trace']) / str(uuid.uuid4())
    capture(root, trace / 'source')
    result = evaluate(config, trace / 'source', args, trace / 'execution', author_artifacts=True)
    sys.stdout.buffer.write((trace / 'execution/cargo.log').read_bytes())
    if result.get('author_artifacts') is not None:
        captured = json.loads((trace / 'source/candidate.json').read_text())
        paths = snapshot_artifacts.publish_snapshots(
            root, captured, trace / 'execution/author-snapshots', trace.name, inventory)
        if paths:
            text = '\nGenerated author snapshots (read these files to update expected snapshots):\n'
            text += ''.join(str(path) + '\n' for path in paths)
            sys.stdout.buffer.write(text.encode())
    return result['exit_code'] if result['exit_code'] is not None else 124


def stop(config_path, event):
    config = json.loads(Path(config_path).read_text())
    root, checks = Path(config['workspace']), Path(config['checks'])
    checks.mkdir(parents=True, exist_ok=True)
    record = {'event': event, 'arm': config['arm']}
    try:
        if Path(event['cwd']).resolve() != root.resolve():
            raise ValueError('Hook cwd mismatch')
        active = event.get('stop_hook_active', False)
        blocked = int((checks / 'blocked').read_text()) if (checks / 'blocked').exists() else 0
        index = len(list(checks.glob('stop-*.json')))
        snap = checks / f'source-{index}'
        capture(root, snap)
        result = evaluate(config, snap, config['f2p_args'], checks / f'execution-{index}', oracle=True)
        data = (checks / f'execution-{index}/cargo.log').read_bytes()
        parsed = classify(data.decode(errors='replace'), result['exit_code'], config['f2p_names'])
        action = decision(config['arm'], parsed, blocked, active)
        if len(data) > 65536:
            raise ValueError('Complete feedback exceeds64KiB')
        record.update(decision=action, result=parsed, snapshot=str(snap), execution=result)
        if action == 'block':
            (checks / 'blocked').write_text('1\n')
            payload = {'decision': 'block', 'reason': 'Before finishing: the upstream behavioral check failed. Read the complete output, fix the behavior, and finish again.\n\n' + data.decode(errors='replace')}
            save(checks / f'feedback-{index}.json', payload)
            record['feedback_sha256'] = hashlib.sha256(payload['reason'].encode()).hexdigest()
            print(json.dumps(payload))
    except Exception as exc:
        record.update(decision='invalid', error=str(exc))
    save(checks / f'stop-{len(list(checks.glob("stop-*.json")))}.json', record)


if __name__ == '__main__':
    if sys.argv[1] == 'cargo':
        raise SystemExit(shim(sys.argv[2], sys.argv[3:]))
    if sys.argv[1] == 'stop':
        stop(sys.argv[2], json.load(sys.stdin))
