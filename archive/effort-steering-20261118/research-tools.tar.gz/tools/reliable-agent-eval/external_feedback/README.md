# External behavioral-feedback adapter

This diagnostic adapter checks an exact saved patch in a new container made from a pinned official SWE-bench Multilingual image. Importing it never invokes a model. Private experiment orchestration, raw receipts and registration remain in the external-feedback-20261029 evidence root; this directory provides the reusable source/feedback instrument.

`adapter.py cargo CONFIG ...` runs Cargo through the Docker adapter and retains the source patch, complete inventory, actual arguments, output and exit status. `adapter.py stop CONFIG` reads a Claude Stop event from stdin, captures the source, grafts the parent upstream tests and runs the frozen fail-to-pass target. Arm G can deliver one complete failure log; X observes silently. Compiler failure has its own category and never counts as completed behavioral failure. Unknown/incomplete/ignored populations are rejected.

Configuration declares immutable `image_id`, `base_commit`, `test_patch`, explicit `test_paths` with base-existence flags, `f2p_args`/`f2p_names`, `full_args`/`full_names`, and runtime `workspace`, `trace`, `checks`, `arm`. Optional `fixture_patch` is applied identically before the initial commit. Optional `extra_files` supports a frozen image `Cargo.lock` as an explicit source/dependency input. Inputs and exact named populations must pass independent base/gold controls before registration.

Each execution creates its own network-disabled container with CPU, memory and PID limits. It moves the image build cache outside source, replaces the original Git history with one initial commit, applies the exact saved patch and compares complete inventories including ignored additions, deletions, symlinks and executable modes. Parent evaluation restores only declared upstream test paths before grafting tests. Results are never reused across candidate patches. Only that newly created container is removed afterward.

Run the standalone contracts:

```sh
python3 -m unittest discover -s tools/reliable-agent-eval/external_feedback -p 'test_*.py' -v
```

The real Docker rejection regression is opt-in because it requires the locally pinned public fixture. Set `EF29_PROTOCOL_ROOT` to the retained external-feedback-20261029 evidence root and run the same command. Without that environment variable, the Docker test is explicitly skipped; a default green suite alone does not verify Docker fidelity.

The independent review originally applied eight guard mutations: six survived the initial suite. After adding direct bad-input regressions and a real Docker source-binding check, the same eight mutations are all rejected with assertion failures. These are eight selected mutants, not a complete coverage measure. The private controller additionally tests raw session/cost binding, immutable budget anchors, semantic-review admission and observed repair attribution.

See the [fixed experiment design](../../../docs/superpowers/specs/2026-10-29-external-feedback-design.md). This is an amended diagnostic subset using upstream tests, not an official benchmark score or a claim of general low/xhigh equivalence.

## Generated author snapshots

The author Cargo entry point returns regular `.snap.new` files associated with regular `.snap` files in the exact captured source. An output already present in that capture is returned only when its content hash changed; rewriting identical bytes is excluded. It prints readable paths under `.git/codescout-cargo-artifacts/<run>/`. Read a generated file there to update its expected snapshot with the normal edit tool. Expected snapshots are not automatically replaced, and the artifact store stays outside source capture.

Transport limits are 64 files, 1 MiB per file and 8 MiB total, independently checked by the collector and host consumer. Patch, hashes, sizes and paths are checked; links and nonregular files are rejected. Directory handles remain open through writes, and delivery checks that the returned directory still names the same object. Host inventory is compared at entry, after artifact verification and after data writes. These comparisons detect changes at those boundaries; they do not provide atomicity against arbitrary concurrent writers. Authors must serialize source edits and Cargo checks. A previous run is never overwritten. It requires a real private `.git` directory and POSIX descriptor-relative filesystem support, as used by the isolated Linux experiment authors.

Artifact export is explicitly enabled only by `adapter.py cargo`. Independent oracle evaluation rejects export. Timeouts do not publish partial artifacts. Ordinary Cargo failures still return their original status and generated snapshots. Caller environment such as `INSTA_UPDATE` is not forwarded.

The real author snapshot regression uses a pinned input directory containing `base.tar`, `config.json` and optional `image-Cargo.lock`:

```sh
AUTHOR_ARTIFACT_INPUT_DIR=/path/to/pinned/task-input python3 -m unittest discover -s tools/reliable-agent-eval/external_feedback -p 'test_snapshot_artifacts.py' -v
```

The fixture runs a dependency-free Rust test in the pinned image, writes a new snapshot, intentionally exits101, then checks readable returned bytes, original expected snapshot, complete unchanged source inventory and the source-bound manifest. Default tests explicitly skip this Docker case when the fixture is absent. No model is invoked, and these checks establish artifact transport rather than a model quality or spending improvement.
