"""Snapshot-artifact contracts; real Docker fixture is explicit and contains no model."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('snapshot_adapter', HERE / 'adapter.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)


@unittest.skipUnless(os.environ.get('AUTHOR_ARTIFACT_INPUT_DIR'), 'requires pinned source/image fixture and Docker')
class AuthorSnapshotDocker(unittest.TestCase):
    def test_failed_cargo_returns_snapshot_without_changing_source(self):
        inputs = Path(os.environ['AUTHOR_ARTIFACT_INPUT_DIR'])
        config = json.loads((inputs / 'config.json').read_text())
        with tempfile.TemporaryDirectory(prefix='author-snapshot-contract-') as temporary:
            base = Path(temporary)
            root = base / 'author'
            root.mkdir()
            with tarfile.open(inputs / 'base.tar') as archive:
                archive.extractall(root, filter='data')
            lock = inputs / 'image-Cargo.lock'
            if lock.exists():
                (root / 'Cargo.lock').write_bytes(lock.read_bytes())
            for args in (('init', '-q'), ('config', 'user.name', 'artifact-contract'),
                         ('config', 'user.email', 'artifact-contract@example.invalid'),
                         ('add', '-f', '--all'), ('commit', '-qm', 'Frozen source fixture')):
                a.git(root, *args)
            crate = root / 'visibility-probe'
            (crate / 'src').mkdir(parents=True)
            (crate / 'Cargo.toml').write_text(
                '[package]\nname="visibility-probe"\nversion="0.1.0"\nedition="2021"\n[workspace]\n')
            (crate / 'proof.snap').write_text('old expected snapshot\n')
            (crate / 'src/lib.rs').write_text(
                '#[test]\nfn emits_snapshot() {\n'
                'std::fs::write("proof.snap.new", "new generated snapshot\\n").unwrap();\n'
                'panic!("intentional snapshot mismatch");\n}\n')
            before = a.inventory(root)
            config.update(workspace=str(root), trace=str(base / 'traces'))
            config_path = base / 'config.json'
            a.save(config_path, config)
            process = subprocess.run(
                [sys.executable, str(HERE / 'adapter.py'), 'cargo', str(config_path),
                 'test', '--manifest-path', 'visibility-probe/Cargo.toml', '--', '--nocapture'],
                cwd=root, capture_output=True, text=True, timeout=180)
            self.assertEqual(process.returncode, 101, process.stdout + process.stderr)
            artifacts = list((root / '.git/codescout-cargo-artifacts').glob('*/visibility-probe/proof.snap.new'))
            self.assertEqual(len(artifacts), 1, process.stdout + process.stderr)
            self.assertEqual(artifacts[0].read_text(), 'new generated snapshot\n')
            self.assertIn(str(artifacts[0]), process.stdout)
            self.assertEqual((crate / 'proof.snap').read_text(), 'old expected snapshot\n')
            self.assertFalse((crate / 'proof.snap.new').exists())
            self.assertEqual(a.inventory(root), before)
            manifests = list((root / '.git/codescout-cargo-artifacts').glob('*/manifest.json'))
            self.assertEqual(len(manifests), 1)
            manifest = json.loads(manifests[0].read_text())
            captures = list((base / 'traces').glob('*/source/candidate.json'))
            self.assertEqual(len(captures), 1)
            self.assertEqual(manifest['patch_sha256'], json.loads(captures[0].read_text())['patch_sha256'])
            self.assertEqual(manifest['files'][0]['sha256'], a.sha(artifacts[0]))
