"""Filesystem and consuming call-site contracts for bounded snapshot transport."""
import base64
import contextlib
import importlib.util
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch, Mock
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import snapshot_artifacts as artifacts
spec = importlib.util.spec_from_file_location('transport_adapter', HERE / 'adapter.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)


class SnapshotTransport(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='snapshot-transport-')
        self.addCleanup(self.temporary.cleanup)
        self.base = Path(self.temporary.name)
        self.root = self.base / 'author'
        self.root.mkdir()
        for args in (('init', '-q'), ('config', 'user.name', 'snapshot-test'),
                     ('config', 'user.email', 'snapshot@example.invalid')):
            a.git(self.root, *args)
        (self.root / 'case.snap').write_bytes(b'old expected')
        self.captured = dict(files=a.inventory(self.root), patch_sha256='source-patch')
        self.output = self.base / 'execution'
        self.output.mkdir()

    def checked(self, *args, input=None):
        arguments = [str(self.root) if value == '/testbed' else value for value in args]
        result = subprocess.run(arguments, input=input, capture_output=True, check=True, timeout=5)
        return result.stdout

    def collect(self, content=b'new generated'):
        (self.root / 'case.snap.new').write_bytes(content)
        return artifacts.collect_snapshots(self.checked, self.captured, self.output)

    def test_collection_receipt_is_consumed_by_publication_and_store_is_not_source(self):
        manifest = self.collect()
        (self.root / 'case.snap.new').unlink()  # Only the container had this generated file.
        paths = artifacts.publish_snapshots(self.root, self.captured, self.output / 'author-snapshots', 'run-one', a.inventory)
        self.assertEqual([p.read_bytes() for p in paths], [b'new generated'])
        self.assertEqual(paths[0], self.root / '.git/codescout-cargo-artifacts/run-one/case.snap.new')
        self.assertEqual((self.root / 'case.snap').read_bytes(), b'old expected')
        self.assertEqual(a.inventory(self.root), self.captured['files'])
        receipt = json.loads((paths[0].parent / 'manifest.json').read_text())
        self.assertEqual(receipt['patch_sha256'], self.captured['patch_sha256'])
        self.assertEqual(receipt['files'][0]['sha256'], a.sha(paths[0]))
        self.assertEqual(manifest['files'][0]['bytes'], len(b'new generated'))

    def test_unassociated_generated_file_is_not_exported(self):
        (self.root / 'other.snap.new').write_bytes(b'unassociated')
        manifest = artifacts.collect_snapshots(self.checked, self.captured, self.output)
        self.assertEqual(manifest['files'], [])

    def test_collection_rejects_generated_symlink(self):
        outside = self.base / 'secret'
        outside.write_bytes(b'outside')
        (self.root / 'case.snap.new').symlink_to(outside)
        with self.assertRaises((ValueError, OSError)):
            artifacts.collect_snapshots(self.checked, self.captured, self.output)

    def test_collection_rejects_symlink_directory(self):
        (self.root / 'nested').mkdir()
        (self.root / 'nested/a.snap').write_bytes(b'old')
        captured = dict(files=a.inventory(self.root), patch_sha256='source-patch')
        (self.root / 'nested/a.snap').unlink()
        (self.root / 'nested').rmdir()
        outside = self.base / 'outside'
        outside.mkdir()
        (outside / 'a.snap').write_bytes(b'old')
        (outside / 'a.snap.new').write_bytes(b'outside')
        (self.root / 'nested').symlink_to(outside, target_is_directory=True)
        with self.assertRaises((ValueError, OSError)):
            artifacts.collect_snapshots(self.checked, captured, self.output)

    def test_collection_enforces_file_size_limit(self):
        (self.root / 'case.snap.new').write_bytes(b'x' * (1024 * 1024 + 1))
        with self.assertRaises((ValueError, subprocess.CalledProcessError)):
            artifacts.collect_snapshots(self.checked, self.captured, self.output)

    def test_collection_enforces_aggregate_limit(self):
        for index in range(9):
            (self.root / (str(index) + '.snap')).write_bytes(b'old')
        captured = dict(files=a.inventory(self.root), patch_sha256='source-patch')
        for index in range(9):
            (self.root / (str(index) + '.snap.new')).write_bytes(b'x' * (1024 * 1024))
        with self.assertRaises((ValueError, subprocess.CalledProcessError)):
            artifacts.collect_snapshots(self.checked, captured, self.output)

    def test_collection_enforces_count_limit(self):
        for index in range(65):
            (self.root / (str(index) + '.snap')).write_bytes(b'old')
        captured = dict(files=a.inventory(self.root), patch_sha256='source-patch')
        for index in range(65):
            (self.root / (str(index) + '.snap.new')).write_bytes(b'x')
        with self.assertRaises((ValueError, subprocess.CalledProcessError)):
            artifacts.collect_snapshots(self.checked, captured, self.output)

    def test_publication_rejects_stale_source(self):
        self.collect()
        (self.root / 'case.snap.new').unlink()
        (self.root / 'case.snap').write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError, 'source'):
            artifacts.publish_snapshots(self.root, self.captured, self.output / 'author-snapshots', 'run', a.inventory)
        self.assertFalse((self.root / '.git/codescout-cargo-artifacts/run').exists())

    def test_publication_rejects_changed_artifact_bytes_and_patch_binding(self):
        self.collect()
        (self.root / 'case.snap.new').unlink()
        directory = self.output / 'author-snapshots'
        (directory / 'case.snap.new').write_bytes(b'changed')
        with self.assertRaises(ValueError):
            artifacts.publish_snapshots(self.root, self.captured, directory, 'run', a.inventory)
        (directory / 'case.snap.new').write_bytes(b'new generated')
        changed = dict(self.captured, patch_sha256='other-patch')
        with self.assertRaises(ValueError):
            artifacts.publish_snapshots(self.root, changed, directory, 'run', a.inventory)

    def test_publication_rejects_linked_store_ancestor(self):
        self.collect()
        (self.root / 'case.snap.new').unlink()
        outside = self.base / 'outside'
        outside.mkdir()
        (self.root / '.git/codescout-cargo-artifacts').symlink_to(outside, target_is_directory=True)
        with self.assertRaises((ValueError, OSError)):
            artifacts.publish_snapshots(self.root, self.captured, self.output / 'author-snapshots', 'run', a.inventory)
        self.assertEqual(list(outside.iterdir()), [])

    def test_publication_refuses_duplicate_run_directory(self):
        self.collect()
        (self.root / 'case.snap.new').unlink()
        directory = self.output / 'author-snapshots'
        first = artifacts.publish_snapshots(self.root, self.captured, directory, 'same', a.inventory)
        with self.assertRaises((ValueError, FileExistsError)):
            artifacts.publish_snapshots(self.root, self.captured, directory, 'same', a.inventory)
        self.assertEqual(first[0].read_bytes(), b'new generated')

    def test_collection_rejects_absolute_and_traversing_inventory(self):
        for name in ('../case.snap', '/case.snap', 'nested/../../case.snap'):
            with self.subTest(name=name), self.assertRaises((ValueError, subprocess.CalledProcessError)):
                artifacts.collect_snapshots(self.checked, dict(self.captured, files={name: '0:digest'}), self.output)

    def test_oracle_export_is_refused_before_container_and_file_access(self):
        with patch.object(a, 'container') as container:
            with self.assertRaisesRegex(ValueError, 'oracle'):
                a.evaluate({}, self.base / 'missing-source', ['test'], self.output, oracle=True, author_artifacts=True)
            container.assert_not_called()
    def test_exact_limits_are_allowed(self):
        for index in range(64):
            (self.root / (str(index) + '.snap')).write_bytes(b'old')
        captured = dict(files=a.inventory(self.root), patch_sha256='source-patch')
        for index in range(64):
            (self.root / (str(index) + '.snap.new')).write_bytes(
                b'x' * (1024 * 1024) if index < 8 else b'')
        manifest = artifacts.collect_snapshots(self.checked, captured, self.output)
        self.assertEqual(len(manifest['files']), 64)
        self.assertEqual(sum(row['bytes'] for row in manifest['files']), 8 * 1024 * 1024)

    def test_nonregular_fifo_is_rejected_without_waiting_for_a_writer(self):
        os.mkfifo(self.root / 'case.snap.new')
        with self.assertRaises(ValueError):
            artifacts.collect_snapshots(self.checked, self.captured, self.output)

    def test_publication_rejects_traversing_manifest_and_linked_artifact(self):
        self.collect()
        (self.root / 'case.snap.new').unlink()
        directory = self.output / 'author-snapshots'
        manifest_path = directory / 'manifest.json'
        manifest = json.loads(manifest_path.read_text())
        manifest['files'][0]['path'] = '../escape.snap.new'
        manifest_path.write_text(json.dumps(manifest))
        with self.assertRaises(ValueError):
            artifacts.publish_snapshots(self.root, self.captured, directory, 'run', a.inventory)
        manifest['files'][0]['path'] = 'case.snap.new'
        manifest_path.write_text(json.dumps(manifest))
        artifact = directory / 'case.snap.new'
        artifact.unlink()
        outside = self.base / 'outside'
        outside.write_bytes(b'new generated')
        artifact.symlink_to(outside)
        with self.assertRaises((ValueError, OSError)):
            artifacts.publish_snapshots(self.root, self.captured, directory, 'run', a.inventory)
        self.assertEqual(outside.read_bytes(), b'new generated')
class AdapterArtifactCallsites(unittest.TestCase):
    setUp = SnapshotTransport.setUp
    checked = SnapshotTransport.checked

    def evaluate_fixture(self):
        snapshot = self.base / 'snapshot'
        snapshot.mkdir()
        (snapshot / 'candidate.patch').write_bytes(b'')
        captured = dict(files=a.inventory(self.root), patch_sha256=a.sha(snapshot / 'candidate.patch'))
        a.save(snapshot / 'candidate.json', captured)
        test_patch = self.base / 'test.patch'
        test_patch.write_bytes(b'')
        return snapshot, captured, dict(test_paths={}, test_patch=str(test_patch))

    def test_default_and_oracle_evaluate_never_collect_author_files(self):
        snapshot, captured, config = self.evaluate_fixture()

        @contextlib.contextmanager
        def container(config, out):
            Path(out).mkdir()
            yield 'cid', Mock(return_value=b'')

        with patch.object(a, 'container', container), patch.object(a, 'remote_inventory', return_value=captured['files']), patch.object(a.subprocess, 'run', return_value=SimpleNamespace(stdout=b'failure', returncode=101)), patch.object(a.snapshot_artifacts, 'collect_snapshots') as collect:
            for oracle in (False, True):
                result = a.evaluate(config, snapshot, ['test'], self.base / str(oracle), oracle=oracle)
                self.assertEqual(result['exit_code'], 101)
                self.assertNotIn('author_artifacts', result)
            collect.assert_not_called()

    def test_author_collection_runs_inside_container_after_failing_cargo(self):
        snapshot, captured, config = self.evaluate_fixture()
        alive = []
        checked = Mock()

        @contextlib.contextmanager
        def container(config, out):
            Path(out).mkdir()
            alive.append(True)
            try:
                yield 'cid', checked
            finally:
                alive.pop()

        manifest = dict(patch_sha256=captured['patch_sha256'], files=[])

        def collect(actual_checked, actual_capture, out):
            self.assertEqual(alive, [True])
            self.assertIs(actual_checked, checked)
            self.assertEqual(actual_capture, captured)
            return manifest

        with patch.object(a, 'container', container), patch.object(a, 'remote_inventory', return_value=captured['files']), patch.object(a.subprocess, 'run', return_value=SimpleNamespace(stdout=b'failure', returncode=101)), patch.object(a.snapshot_artifacts, 'collect_snapshots', side_effect=collect) as collection:
            result = a.evaluate(config, snapshot, ['test'], self.base / 'execution-call', author_artifacts=True)
        collection.assert_called_once()
        self.assertEqual(result['exit_code'], 101)
        self.assertEqual(result['author_artifacts'], manifest)
        self.assertEqual(alive, [])

    def test_timeout_does_not_publish_partial_artifacts(self):
        snapshot, captured, config = self.evaluate_fixture()

        @contextlib.contextmanager
        def container(config, out):
            Path(out).mkdir()
            yield 'cid', Mock()

        with patch.object(a, 'container', container), patch.object(a, 'remote_inventory', return_value=captured['files']), patch.object(a.subprocess, 'run', side_effect=subprocess.TimeoutExpired('cargo', 600, output=b'partial')), patch.object(a.snapshot_artifacts, 'collect_snapshots') as collection:
            result = a.evaluate(config, snapshot, ['test'], self.base / 'timeout', author_artifacts=True)
        self.assertTrue(result['timed_out'])
        self.assertIsNone(result['exit_code'])
        self.assertNotIn('author_artifacts', result)
        collection.assert_not_called()

    def run_actual_shim_with_fixture_cargo(self, drift=False):
        a.git(self.root, 'add', '--all')
        a.git(self.root, 'commit', '-qm', 'baseline')
        config = self.base / 'config.json'
        a.save(config, dict(workspace=str(self.root), trace=str(self.base / 'traces')))

        def evaluate(config, snapshot, args, out, **options):
            self.assertTrue(options['author_artifacts'])
            Path(out).mkdir()
            (Path(out) / 'cargo.log').write_bytes(b'fixture Cargo failure\n')
            captured = json.loads((snapshot / 'candidate.json').read_text())
            (self.root / 'case.snap.new').write_bytes(b'generated by Cargo')
            manifest = artifacts.collect_snapshots(self.checked, captured, out)
            (self.root / 'case.snap.new').unlink()
            if drift:
                (self.root / 'case.snap').write_bytes(b'concurrent source change')
            return dict(exit_code=101, author_artifacts=manifest)

        output = io.BytesIO()
        with patch.object(a, 'evaluate', side_effect=evaluate), contextlib.redirect_stdout(SimpleNamespace(buffer=output)):
            code = a.shim(config, ['test'])
        return code, output.getvalue().decode()

    def test_actual_shim_requests_export_and_returns_readable_path_with_failure(self):
        code, output = self.run_actual_shim_with_fixture_cargo()
        paths = list((self.root / '.git/codescout-cargo-artifacts').glob('*/case.snap.new'))
        self.assertEqual(code, 101)
        self.assertEqual(len(paths), 1)
        self.assertEqual(paths[0].read_bytes(), b'generated by Cargo')
        self.assertIn(str(paths[0]), output)
        self.assertIn('fixture Cargo failure', output)
        self.assertEqual((self.root / 'case.snap').read_bytes(), b'old expected')

    def test_actual_shim_refuses_delivery_after_source_drift(self):
        with self.assertRaisesRegex(ValueError, 'source'):
            self.run_actual_shim_with_fixture_cargo(drift=True)
        self.assertFalse((self.root / '.git/codescout-cargo-artifacts').exists())

class SnapshotReviewRegressions(unittest.TestCase):
    setUp = SnapshotTransport.setUp
    checked = SnapshotTransport.checked
    collect = SnapshotTransport.collect

    def test_store_replaced_before_write_cannot_redirect_publication(self):
        self.collect()
        (self.root / 'case.snap.new').unlink()
        outside = self.base / 'outside'
        (outside / 'run').mkdir(parents=True)
        original = artifacts._write_new
        swapped = False

        def swap_then_write(root, name, data):
            nonlocal swapped
            if not swapped:
                store = self.root / '.git/codescout-cargo-artifacts'
                store.rename(self.root / '.git/displaced-store')
                store.symlink_to(outside, target_is_directory=True)
                swapped = True
            return original(root, name, data)

        with patch.object(artifacts, '_write_new', side_effect=swap_then_write):
            with self.assertRaises((OSError, ValueError)):
                artifacts.publish_snapshots(
                    self.root, self.captured, self.output / 'author-snapshots', 'run', a.inventory)
        self.assertTrue(swapped)
        self.assertEqual(list(outside.rglob('*.new')), [])

    def test_stale_source_is_refused_before_reading_artifact_inputs(self):
        (self.root / 'case.snap').write_bytes(b'stale source')
        with self.assertRaisesRegex(ValueError, 'source'):
            artifacts.publish_snapshots(
                self.root, self.captured, self.base / 'missing-artifacts', 'run', a.inventory)

    def test_source_changed_during_artifact_verification_is_refused(self):
        self.collect()
        (self.root / 'case.snap.new').unlink()
        original = artifacts._read_regular

        def change_after_read(root, name, limit):
            data = original(root, name, limit)
            if name == 'manifest.json':
                (self.root / 'case.snap').write_bytes(b'concurrent source change')
            return data

        with patch.object(artifacts, '_read_regular', side_effect=change_after_read):
            with self.assertRaisesRegex(ValueError, 'source'):
                artifacts.publish_snapshots(
                    self.root, self.captured, self.output / 'author-snapshots', 'run', a.inventory)
        self.assertFalse((self.root / '.git/codescout-cargo-artifacts/run').exists())

    def test_unchanged_source_carried_snapshot_is_not_exported(self):
        (self.root / 'case.snap.new').write_bytes(b'stale from an earlier run')
        captured = dict(files=a.inventory(self.root), patch_sha256='source-patch')
        manifest = artifacts.collect_snapshots(self.checked, captured, self.output)
        self.assertEqual(manifest['files'], [])
        paths = artifacts.publish_snapshots(
            self.root, captured, self.output / 'author-snapshots', 'run', a.inventory)
        self.assertEqual(paths, [])

    def test_changed_source_carried_snapshot_is_exported(self):
        (self.root / 'case.snap.new').write_bytes(b'previous output')
        captured = dict(files=a.inventory(self.root), patch_sha256='source-patch')
        (self.root / 'case.snap.new').write_bytes(b'updated output')
        manifest = artifacts.collect_snapshots(self.checked, captured, self.output)
        self.assertEqual([record['path'] for record in manifest['files']], ['case.snap.new'])
        self.assertEqual((self.output / 'author-snapshots/case.snap.new').read_bytes(), b'updated output')

    def test_same_length_publication_corruption_is_refused(self):
        self.collect()
        (self.root / 'case.snap.new').unlink()
        directory = self.output / 'author-snapshots'
        (directory / 'case.snap.new').write_bytes(b'bad generated')
        self.assertEqual(len(b'bad generated'), len(b'new generated'))
        with self.assertRaisesRegex(ValueError, 'hash'):
            artifacts.publish_snapshots(self.root, self.captured, directory, 'run', a.inventory)
        self.assertFalse((self.root / '.git/codescout-cargo-artifacts').exists())

    def test_encoded_transport_with_wrong_hash_is_refused(self):
        record = dict(path='case.snap.new', bytes=3, sha256='0' * 64,
                      data=base64.b64encode(b'new').decode())
        with self.assertRaisesRegex(ValueError, 'hash'):
            artifacts.collect_snapshots(
                lambda *args, **kwargs: json.dumps([record]).encode(), self.captured, self.output)
        self.assertFalse((self.output / 'author-snapshots').exists())

    def test_host_rejects_independent_over_limit_receipts(self):
        for count, size in ((65, 0), (9, 1024 * 1024)):
            with self.subTest(count=count, size=size):
                records = []
                files = {}
                for index in range(count):
                    source = str(index) + '.snap'
                    files[source] = '0:' + '1' * 64
                    records.append(dict(path=source + '.new', bytes=size, sha256=hashlib.sha256(b'x' * size).hexdigest(),
                                        data=base64.b64encode(b'x' * size).decode()))
                captured = dict(files=files, patch_sha256='source-patch')
                payload = json.dumps(records).encode()
                with self.assertRaisesRegex(ValueError, 'count|aggregate'):
                    artifacts.collect_snapshots(lambda *args, **kwargs: payload, captured, self.output)
                directory = self.base / ('forged-' + str(count))
                directory.mkdir()
                metadata = [{key: value for key, value in record.items() if key != 'data'}
                            for record in records]
                (directory / 'manifest.json').write_text(json.dumps(
                    dict(patch_sha256='source-patch', files=metadata)))
                with self.assertRaisesRegex(ValueError, 'count|aggregate'):
                    artifacts.publish_snapshots(
                        self.root, captured, directory, 'run', lambda root: files)

    def test_remote_refuses_over_limit_output_before_host_validation(self):
        for count, size in ((65, 0), (9, 1024 * 1024)):
            with self.subTest(count=count, size=size):
                directory = self.base / ('remote-' + str(count))
                directory.mkdir()
                files = {}
                for index in range(count):
                    source = str(index) + '.snap'
                    (directory / source).write_bytes(b'expected')
                    (directory / (source + '.new')).write_bytes(b'x' * size)
                    files[source] = '0:' + '1' * 64
                observed_remote_refusal = False

                def checked(*args, input=None):
                    nonlocal observed_remote_refusal
                    arguments = [str(directory) if value == '/testbed' else value for value in args]
                    try:
                        return subprocess.run(arguments, input=input, capture_output=True,
                                              check=True, timeout=5).stdout
                    except subprocess.CalledProcessError:
                        observed_remote_refusal = True
                        raise

                with self.assertRaisesRegex(ValueError, 'count|aggregate'):
                    artifacts.collect_snapshots(
                        checked, dict(files=files, patch_sha256='source-patch'), self.output)
                self.assertTrue(observed_remote_refusal, 'host refusal concealed unbounded remote output')
