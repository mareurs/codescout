"""Opt-in real Docker regression; EF29_PROTOCOL_ROOT names the private fixed fixture."""
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import unittest

s=importlib.util.spec_from_file_location('docker_binding_adapter',Path(__file__).parent/'adapter.py')
a=importlib.util.module_from_spec(s)
s.loader.exec_module(a)


@unittest.skipUnless(os.environ.get('EF29_PROTOCOL_ROOT'),'requires pinned local upstream fixture and Docker')
class DockerBinding(unittest.TestCase):
    def test_real_container_rejects_changed_expected_source(self):
        protocol=Path(os.environ['EF29_PROTOCOL_ROOT']);task='burntsushi__ripgrep-2576'
        cfg=json.loads((protocol/'inputs'/task/'config.json').read_text())
        original=json.loads((protocol/'adapter-controls'/task/'base-source/candidate.json').read_text())
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);snap=d/'snapshot';snap.mkdir();(snap/'candidate.patch').write_bytes(b'')
            original['files']['README.md']='0:deliberately-different-source'
            original['patch_sha256']=a.sha(snap/'candidate.patch')
            (snap/'candidate.json').write_text(json.dumps(original))
            with self.assertRaisesRegex(ValueError,'Container source differs'):
                a.evaluate(cfg,snap,['check','--offline','--package','ripgrep'],d/'execution')
