"""Bounded author snapshot transport. Independent oracle files are never exported."""
import base64
import contextlib
import hashlib
import inspect
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess

MAX_FILE_BYTES = 1024 * 1024
MAX_TOTAL_BYTES = 8 * 1024 * 1024
MAX_FILES = 64


def _relative(name):
    if not isinstance(name, str) or not name or "\\" in name or any(ord(c) < 32 for c in name):
        raise ValueError("Invalid artifact path")
    path = PurePosixPath(name)
    if path.is_absolute() or ".." in path.parts or path.as_posix() != name:
        raise ValueError("Invalid artifact path")
    return path


@contextlib.contextmanager
def _directory_fd(root, parts=(), create=False):
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    current = os.dup(root) if isinstance(root, int) else os.open(root, flags)
    try:
        for part in parts:
            if create:
                try:
                    os.mkdir(part, mode=0o700, dir_fd=current)
                except FileExistsError:
                    pass
            child = os.open(part, flags, dir_fd=current)
            os.close(current)
            current = child
        yield current
    finally:
        os.close(current)


@contextlib.contextmanager
def _regular_reader(root, name):
    path = _relative(name)
    with _directory_fd(root, path.parts[:-1]) as parent:
        descriptor = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
    with os.fdopen(descriptor, "rb") as stream:
        if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
            raise ValueError("Nonregular artifact")
        yield stream


def _read_regular(root, name, limit):
    with _regular_reader(root, name) as stream:
        if os.fstat(stream.fileno()).st_size > limit:
            raise ValueError("Snapshot artifact size exceeded")
        data = stream.read(limit + 1)
    if len(data) > limit:
        raise ValueError("Snapshot artifact size exceeded")
    return data


def _source_snapshots(source_files):
    result = set()
    for name, value in source_files.items():
        if name.endswith(".snap") and isinstance(value, str) and not value.startswith("symlink:"):
            _relative(name)
            result.add(name)
    return result


def read_snapshots(root, source_files):
    records = []
    total = 0
    for source in sorted(_source_snapshots(source_files)):
        name = source + ".new"
        try:
            data = _read_regular(root, name, MAX_FILE_BYTES)
        except FileNotFoundError:
            continue
        with _regular_reader(root, source):
            pass
        digest = hashlib.sha256(data).hexdigest()
        previous = source_files.get(name)
        if isinstance(previous, str) and previous.partition(":")[2] == digest:
            continue
        if len(records) >= MAX_FILES:
            raise ValueError("Snapshot artifact count exceeded")
        total += len(data)
        if total > MAX_TOTAL_BYTES:
            raise ValueError("Snapshot artifact aggregate size exceeded")
        records.append(dict(path=name, bytes=len(data), sha256=digest,
                            data=base64.b64encode(data).decode("ascii")))
    return records


def _validated(records, source_files, encoded):
    if not isinstance(records, list) or len(records) > MAX_FILES:
        raise ValueError("Snapshot artifact count exceeded")
    allowed = _source_snapshots(source_files)
    seen = set()
    result = []
    total = 0
    for record in records:
        name = record["path"]
        _relative(name)
        if not name.endswith(".snap.new") or name[:-4] not in allowed or name in seen:
            raise ValueError("Unassociated or duplicate snapshot artifact")
        seen.add(name)
        size = record["bytes"]
        if type(size) is not int or not 0 <= size <= MAX_FILE_BYTES:
            raise ValueError("Snapshot artifact size exceeded")
        total += size
        if total > MAX_TOTAL_BYTES:
            raise ValueError("Snapshot artifact aggregate size exceeded")
        if encoded:
            text = record["data"]
            if not isinstance(text, str) or len(text) > 4 * ((MAX_FILE_BYTES + 2) // 3):
                raise ValueError("Snapshot artifact encoding size exceeded")
            data = base64.b64decode(text, validate=True)
            if len(data) != size or hashlib.sha256(data).hexdigest() != record["sha256"]:
                raise ValueError("Snapshot artifact hash or size changed")
            result.append((dict(path=name, bytes=size, sha256=record["sha256"]), data))
        else:
            result.append(record)
    return result


def _write_new(root, name, data):
    path = _relative(name)
    with _directory_fd(root, path.parts[:-1], create=True) as parent:
        descriptor = os.open(path.name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                             0o600, dir_fd=parent)
    with os.fdopen(descriptor, "wb") as stream:
        stream.write(data)


@contextlib.contextmanager
def _new_directory(root, name):
    path = _relative(name)
    with _directory_fd(root, path.parts[:-1], create=True) as parent:
        os.mkdir(path.name, mode=0o700, dir_fd=parent)
        with _directory_fd(parent, (path.name,)) as descriptor:
            yield descriptor


def collect_snapshots(checked, captured, out):
    functions = (_relative, _directory_fd, _regular_reader, _read_regular,
                 _source_snapshots, read_snapshots)
    program = ("import base64,contextlib,hashlib,json,os,stat,sys\n"
               "from pathlib import Path,PurePosixPath\n"
               f"MAX_FILE_BYTES={MAX_FILE_BYTES}\nMAX_TOTAL_BYTES={MAX_TOTAL_BYTES}\nMAX_FILES={MAX_FILES}\n"
               + "\n".join(inspect.getsource(function) for function in functions)
               + "\njson.dump(read_snapshots(sys.argv[1],json.load(sys.stdin)),sys.stdout)\n")
    try:
        payload = checked("python3", "-c", program, "/testbed",
                          input=json.dumps(captured["files"]).encode())
    except subprocess.CalledProcessError as error:
        raise ValueError("Snapshot artifact collection failed: " +
                         error.stderr.decode(errors="replace")) from error
    records = _validated(json.loads(payload), captured["files"], encoded=True)
    manifest = dict(patch_sha256=captured["patch_sha256"], files=[])
    with _new_directory(out, "author-snapshots") as descriptor:
        for metadata, data in records:
            _write_new(descriptor, metadata["path"], data)
            manifest["files"].append(metadata)
        _write_new(descriptor, "manifest.json", (json.dumps(manifest, sort_keys=True) + "\n").encode())
    return manifest


def publish_snapshots(workspace, captured, artifact_dir, run_id, inventory_fn):
    workspace, artifact_dir = Path(workspace), Path(artifact_dir)
    if inventory_fn(workspace) != captured["files"]:
        raise ValueError("Author source changed before artifact delivery")
    if len(_relative(run_id).parts) != 1:
        raise ValueError("Invalid artifact run identifier")
    manifest = json.loads(_read_regular(artifact_dir, "manifest.json", 1024 * 1024))
    if manifest["patch_sha256"] != captured["patch_sha256"]:
        raise ValueError("Artifact source patch changed")
    records = _validated(manifest["files"], captured["files"], encoded=False)
    verified = []
    for metadata in records:
        data = _read_regular(artifact_dir, metadata["path"], MAX_FILE_BYTES)
        if len(data) != metadata["bytes"] or hashlib.sha256(data).hexdigest() != metadata["sha256"]:
            raise ValueError("Snapshot artifact hash or size changed")
        verified.append((metadata, data))
    # Verify again after reading artifact bytes, immediately before creating the store.
    if inventory_fn(workspace) != captured["files"]:
        raise ValueError("Author source changed before artifact delivery")
    if not records:
        return []
    parts = (".git", "codescout-cargo-artifacts", run_id)
    directory = workspace.joinpath(*parts)
    # Keep descriptors pinned through writes; never reopen the run by its absolute path.
    with _directory_fd(workspace, (".git",)) as git_descriptor:
        with _new_directory(git_descriptor, "codescout-cargo-artifacts/" + run_id) as descriptor:
            for metadata, data in verified:
                _write_new(descriptor, metadata["path"], data)
            if inventory_fn(workspace) != captured["files"]:
                raise ValueError("Author source changed during artifact delivery")
            _write_new(descriptor, "manifest.json", (json.dumps(manifest, sort_keys=True) + "\n").encode())
            with _directory_fd(workspace, parts) as named_descriptor:
                actual, named = os.fstat(descriptor), os.fstat(named_descriptor)
                if (actual.st_dev, actual.st_ino) != (named.st_dev, named.st_ino):
                    raise ValueError("Artifact store changed during delivery")
    return [directory / metadata["path"] for metadata, data in verified]
