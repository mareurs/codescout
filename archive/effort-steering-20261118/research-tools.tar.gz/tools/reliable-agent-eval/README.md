# Completion validation hook

`verify_stop.py` runs configured commands when Claude Code asks to stop. A failed check blocks completion while the configured repair allowance remains. Every invocation checks the current workspace again. This is the corrected hook used in the2026-10-27 transfer diagnostic; it is not installed automatically.

The event directory may be the configured repository root or an existing canonical descendant. An outside directory or escaping symlink is rejected. Commands always run at the configured root. Configuration supplies `commands` (argument arrays), `timeout_seconds`, `max_repairs`, `cwd`, and a writable `state_dir`.

Run `python3 verify_stop.py hook --config CONFIG.json` with a JSON event on stdin. The event requires `session_id` and `cwd`. The command writes a per-session state record. Check failures request repair at most `max_repairs` times; exhausting that allowance is not a pass. Hook errors can be nonblocking in the CLI, so consumers must require a final state with `status: passed` and independently grade the extracted candidate. A successful command exit alone does not establish adequate test coverage.

Run regression tests with:

```sh
python3 -m unittest discover -s tools/reliable-agent-eval -p 'test_*.py'
```

See [the diagnostic report](../../docs/research/2026-10-27-verified-effort-transfer.md) and [the correction plan](../../docs/superpowers/plans/2026-10-27-nested-stop-cwd-correction.md). Frozen earlier harnesses and private model-run evidence are retained separately.
