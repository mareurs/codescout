"""Bounded Claude Stop verification and an independent final validation command."""
import argparse
import fcntl
import json
import math
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import sys
import tempfile
import time


def configuration(path):
    config = json.loads(Path(path).read_text())
    commands = config.get('commands')
    if not isinstance(commands, list) or not commands:
        raise ValueError('at least one validation command is required')
    if any(not isinstance(cmd, list) or not cmd or any(not isinstance(x, str) or not x for x in cmd)
           for cmd in commands):
        raise ValueError('validation commands must be nonempty argument lists')
    timeout = config.get('timeout_seconds')
    if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or not math.isfinite(timeout) or timeout <= 0:
        raise ValueError('timeout must be finite and positive')
    limit = config.get('max_repairs')
    if type(limit) is not int or not 0 <= limit <= 3:
        raise ValueError('max_repairs must be an integer between zero and three')
    for key in ['cwd', 'state_dir']:
        if not isinstance(config.get(key), str) or not Path(config[key]).is_absolute():
            raise ValueError(f'{key} must be absolute')
    return config


def check_commands(config):
    started = time.monotonic()
    for index, argv in enumerate(config['commands']):
        with tempfile.TemporaryFile() as output:
            try:
                process = subprocess.Popen(argv, cwd=config['cwd'], stdout=output,
                                           stderr=subprocess.STDOUT, start_new_session=True)
            except OSError as error:
                return {'status': 'error', 'check_exit': None, 'failed_check': index,
                        'timed_out': False, 'output_tail': str(error)}
            timed_out = False
            try:
                process.wait(timeout=config['timeout_seconds'])
            except subprocess.TimeoutExpired:
                timed_out = True
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait()
            output.seek(0, os.SEEK_END)
            size = output.tell()
            output.seek(max(0, size - 6000))
            tail = output.read().decode('utf8', errors='replace')
            if timed_out or process.returncode != 0:
                return {'status': 'error' if timed_out else 'failed',
                        'check_exit': process.returncode, 'failed_check': index,
                        'timed_out': timed_out, 'output_tail': tail,
                        'elapsed_ms': round((time.monotonic() - started) * 1000)}
    return {'status': 'passed', 'check_exit': 0, 'failed_check': None,
            'timed_out': False, 'output_tail': '',
            'elapsed_ms': round((time.monotonic() - started) * 1000)}


def evaluate(event, config, operation):
    session = event.get('session_id')
    if not isinstance(session, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,128}', session):
        raise ValueError('invalid session identifier')
    workspace = Path(config['cwd']).resolve()
    hook_directory = Path(event.get('cwd', '')).resolve()
    if not hook_directory.is_dir() or not hook_directory.is_relative_to(workspace):
        raise ValueError('hook workspace does not match configured workspace')
    directory = Path(config['state_dir'])
    directory.mkdir(parents=True, exist_ok=True)
    if directory.absolute() != directory.resolve():
        raise ValueError('state directory cannot contain symlinks')
    path = directory / (session + '.json')
    fd = os.open(path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
    with os.fdopen(fd, 'r+', encoding='utf8') as state_file:
        if not stat.S_ISREG(os.fstat(state_file.fileno()).st_mode):
            raise ValueError('state must be a regular file')
        fcntl.flock(state_file, fcntl.LOCK_EX)
        raw = state_file.read()
        state = json.loads(raw) if raw else {'session_id': session, 'repairs_requested': 0, 'events': []}
        if state.get('session_id') != session or type(state.get('repairs_requested')) is not int:
            raise ValueError('invalid persisted verification state')
        count = state['repairs_requested']
        if not 0 <= count <= config['max_repairs']:
            raise ValueError('invalid persisted repair count')
        # Never infer success from an earlier Stop event: always validate the current workspace.
        result = check_commands(config)
        block = operation == 'hook' and result['status'] == 'failed' and count < config['max_repairs']
        if block:
            count += 1
            result['status'] = 'repair_required'
        result.update(session_id=session, repairs_requested=count, mode=operation,
                      **{'pass': result['status'] == 'passed'})
        events = state['events'] + [{key: result[key] for key in
                ['status', 'check_exit', 'failed_check', 'timed_out', 'repairs_requested', 'mode']}]
        state_file.seek(0)
        state_file.write(json.dumps(result | {'events': events}, indent=2) + '\n')
        state_file.truncate()
        state_file.flush()
        os.fsync(state_file.fileno())
    if block:
        return {'decision': 'block',
                'reason': 'Required validation failed. Repair the code without weakening the checks, then verify again.\n'
                          + result['output_tail']}, result
    return {}, result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('operation', choices=['hook', 'final'])
    parser.add_argument('--config', required=True)
    args = parser.parse_args()
    try:
        config = configuration(args.config)
        event = json.load(sys.stdin)
        decision, result = evaluate(event, config, args.operation)
        print(json.dumps(decision if args.operation == 'hook' else result), flush=True)
        if args.operation == 'hook':
            return 1 if result['status'] == 'error' else 0
        return 0 if result['pass'] else 2 if result['status'] == 'error' else 1
    except Exception as error:
        print(f'verification error: {error}', file=sys.stderr)
        return 2 if args.operation == 'final' else 1


if __name__ == '__main__':
    raise SystemExit(main())
