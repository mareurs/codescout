#!/usr/bin/env python3
"""Preserve Cargo streams/status and log actual completed invocation, not command text."""
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from mechanism import inventory


def main():
 root=Path.cwd();run=Path(os.environ['MECH_RUN']);started=time.monotonic()
 entry={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'origin':os.environ.get('MECH_ORIGIN','author'),'argv':sys.argv[1:],'cwd':str(root),'pid':os.getpid()}
 try:
  entry['source_before']=inventory(Path(os.environ['MECH_ROOT']))
  result=subprocess.run([os.environ['MECH_REAL_CARGO'],*sys.argv[1:]])
  entry['exit_code']=result.returncode
 except OSError as exc:entry.update(exit_code=127,error=str(exc))
 entry['elapsed_s']=time.monotonic()-started
 run.mkdir(parents=True,exist_ok=True)
 # One append write per completed command; source hashes can exceed PIPE_BUF.
 with (run/f'cargo-{os.getpid()}-{time.time_ns()}.json').open('x') as f:json.dump(entry,f)
 code=entry['exit_code']
 if code<0:os.kill(os.getpid(),-code)
 return code

if __name__=='__main__':sys.exit(main())
