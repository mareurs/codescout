"""Same silent Stop check for all arms; one actual compiler-feedback block for G."""
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from mechanism import capture,gate_decision


class CheckCancelled(Exception):
 pass


def run_check(args,root,env,timeout,log):
 import signal
 process=None
 previous={}
 def interrupted(signum,frame):raise CheckCancelled('Observer cancelled by signal '+str(signum))
 for signum in (signal.SIGTERM,signal.SIGINT):previous[signum]=signal.signal(signum,interrupted)
 try:
  process=subprocess.Popen(args,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
  try:
   stdout,stderr=process.communicate(timeout=timeout)
  except subprocess.TimeoutExpired:
   os.killpg(process.pid,signal.SIGTERM)
   try:stdout,stderr=process.communicate(timeout=2)
   except subprocess.TimeoutExpired:
    os.killpg(process.pid,signal.SIGKILL);stdout,stderr=process.communicate()
   log.write_bytes(stdout+stderr)
   raise subprocess.TimeoutExpired(args,timeout,output=stdout,stderr=stderr)
  log.write_bytes(stdout+stderr)
  return subprocess.CompletedProcess(args,process.returncode,stdout,stderr)
 finally:
  if process is not None and process.poll() is None:
   os.killpg(process.pid,signal.SIGTERM)
   try:stdout,stderr=process.communicate(timeout=2)
   except subprocess.TimeoutExpired:
    os.killpg(process.pid,signal.SIGKILL);stdout,stderr=process.communicate()
   log.write_bytes(stdout+stderr)
  for signum,handler in previous.items():signal.signal(signum,handler)

def main():
 run=Path(os.environ['MECH_RUN']);root=Path(os.environ['MECH_ROOT']);arm=os.environ['MECH_ARM'];run.mkdir(parents=True,exist_ok=True)
 started=time.monotonic();record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'arm':arm}
 def finish():
  record['elapsed_s']=time.monotonic()-started
  with (run/'stop.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
 try:
  event=json.load(sys.stdin)
  if not isinstance(event,dict) or not isinstance(event.get('cwd'),str) or Path(event['cwd']).resolve()!=root.resolve():raise ValueError('Unexpected hook input/cwd')
  active=event.get('stop_hook_active',False)
  if type(active) is not bool:raise ValueError('Invalid stop_hook_active')
  if not (run/'first-stop').exists():capture(root,run/'first-stop')
  count=run/'blocked';blocked=int(count.read_text()) if count.exists() else 0
  index=len((run/'stop.jsonl').read_text().splitlines()) if (run/'stop.jsonl').exists() else 0
  env=os.environ.copy();env['MECH_ORIGIN']='stop_hook'
  log=run/f'check-{index}.log';record['log']=str(log)
  result=run_check([os.environ['MECH_CARGO'],'check','--offline','--all-targets'],root,env,float(os.environ.get('MECH_CHECK_TIMEOUT','600')),log)
  output=result.stdout+result.stderr
  decision=gate_decision(arm,result.returncode,blocked,active)
  if len(output)>65536:decision='invalid';record['error']='Compiler feedback exceeds complete-output bound'
  record.update(exit_code=result.returncode,decision=decision,blocked_before=blocked,stop_hook_active=active,output_bytes=len(output),log_sha256=__import__('hashlib').sha256(output).hexdigest())
  if decision=='block':
   count.write_text('1\n')
   reason='Before finishing: cargo check --offline --all-targets failed. Fix these compiler errors and finish again. The complete compiler output follows.\n\n'+output.decode(errors='replace')
   record['feedback_sha256']=__import__('hashlib').sha256(reason.encode()).hexdigest()
   payload={'decision':'block','reason':reason};(run/f'feedback-{index}.json').write_text(json.dumps(payload)+'\n')
   print(json.dumps(payload))
 except (OSError,ValueError,subprocess.TimeoutExpired,CheckCancelled) as exc:
  record.update(decision='invalid',exit_code=None,error=str(exc))
 finish()

if __name__=='__main__':main()
