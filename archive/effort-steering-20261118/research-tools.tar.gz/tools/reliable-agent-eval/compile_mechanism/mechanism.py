"""Measured populations, one-shot compiler feedback, exact patch capture and reservation."""
import hashlib
import json
from pathlib import Path
import re
import stat
import subprocess
from decimal import Decimal, InvalidOperation


def sha(path):
 return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def git(root,*args):
 return subprocess.check_output(['git','-C',str(root),*args])


def inventory(root):
 root=Path(root);names=git(root,'ls-files','-z').decode().strip('\0').split('\0')
 names+=git(root,'ls-files','--others','--exclude-standard','-z').decode().strip('\0').split('\0')
 result={}
 for name in sorted(set(names)-{''}):
  p=root/name
  if not p.exists() and not p.is_symlink():continue
  mode=p.lstat().st_mode
  if stat.S_ISLNK(mode):result[name]='symlink:'+str(p.readlink())
  elif stat.S_ISREG(mode):result[name]=sha(p)
  else:raise ValueError('Nonregular tracked/new path: '+name)
 return result


def capture(root,directory):
 root=Path(root);directory=Path(directory);directory.mkdir(parents=True,exist_ok=False)
 files=inventory(root)
 changed=git(root,'diff','--name-only','-z','HEAD').decode().strip('\0').split('\0')
 extra=git(root,'ls-files','--others','--exclude-standard','-z').decode().strip('\0').split('\0')
 patch=git(root,'diff','--binary','HEAD')
 for name in filter(None,extra):
  p=subprocess.run(['git','-C',str(root),'diff','--no-index','--binary','--','/dev/null',name],capture_output=True)
  if p.returncode not in (0,1):raise ValueError(p.stderr.decode(errors='replace'))
  patch+=p.stdout
 (directory/'candidate.patch').write_bytes(patch)
 result={'files':files,'changed':sorted(set(changed+extra)-{''}),'patch_sha256':sha(directory/'candidate.patch'),'workspace':str(root)}
 (directory/'candidate.json').write_text(json.dumps(result,indent=2)+'\n')
 return result


def gate_decision(arm,exit_code,blocked,active,error=None):
 if arm not in ('L','I','G','X') or error is not None or exit_code not in (0,101):return 'invalid'
 return 'block' if arm=='G' and exit_code==101 and blocked==0 and not active else 'allow'


def reserve_block(prior,charges,pending,cap='20',reserve='1'):
 def money(value):
  try:n=Decimal(str(value))
  except InvalidOperation as e:raise ValueError('Invalid charge') from e
  if not n.is_finite() or n<0:raise ValueError('Invalid charge')
  return n
 total=money(prior)+sum((money(x) for x in charges),Decimal(0))+sum((money(x) for x in pending),Decimal(0))+money(reserve)
 if total>money(cap):raise ValueError('Whole block plus reserve exceeds cap: '+str(total))
 return str(total)


def parse_cargo(text,exit_code,expected):
 expected=tuple(expected)
 if not expected or len(set(expected))!=len(expected) or type(exit_code) is not int or exit_code not in (0,101):raise ValueError('Invalid population or process')
 text=re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',text)
 results={};in_failures=False;declared=None;segment=[];footers=0
 for line in text.splitlines():
  header=re.fullmatch(r'running (\d+) tests?',line)
  if header:
   if declared is not None:raise ValueError('Unclosed libtest report')
   declared=int(header[1]);segment=[];in_failures=False;continue
  if line=='failures:':in_failures=True
  footer=re.fullmatch(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in .+',line)
  if footer:
   state,p,f,i,measured,filtered=footer.groups();p,f,i=int(p),int(f),int(i)
   actual=[segment.count(x) for x in ('ok','FAILED','ignored')]
   if declared is None or declared!=len(segment) or actual!=[p,f,i] or int(measured)!=0 or state!=('FAILED' if f else 'ok'):raise ValueError('Header/footer/population disagreement')
   footers+=1;declared=None;segment=[];continue
  if in_failures:continue
  match=re.fullmatch(r'test (.+?) \.\.\. (ok|FAILED|ignored)(?:[ ,].*)?',line)
  if match:
   if declared is None:raise ValueError('Report outside libtest run')
   name=re.sub(r' - (?:should panic|compile fail|compile)$','',match[1])
   if name in results:raise ValueError('Duplicate report: '+name)
   results[name]=match[2];segment.append(match[2])
 if declared is not None or set(results)!=set(expected) or not footers:raise ValueError('Incomplete or unknown test population')
 counts={state:list(results.values()).count(state) for state in ('ok','FAILED','ignored')}
 if counts['ignored'] or exit_code!=(101 if counts['FAILED'] else 0):raise ValueError('Process/population disagreement')
 return dict(passed=counts['ok'],failed=counts['FAILED'],ignored=0,results=results)
