import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from decimal import Decimal

HERE=Path(__file__).parent

class MechanismTests(unittest.TestCase):
 def setUp(self):
  self.assertTrue((HERE/'mechanism.py').exists(),'Mechanism instrument absent')
  spec=importlib.util.spec_from_file_location('tested_mechanism',HERE/'mechanism.py');self.m=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.m)
 def text(self,statuses=('ok','ok')):
  passed=statuses.count('ok');failed=statuses.count('FAILED');ignored=statuses.count('ignored');state='FAILED' if failed else 'ok'
  return '\n'.join(['running 2 tests',*[f'test {n} ... {s}' for n,s in zip(('alpha','beta'),statuses)],f'test result: {state}. {passed} passed; {failed} failed; {ignored} ignored; 0 measured; 27 filtered out; finished in 0.1s'])
 def test_complete_measured_population(self):
  self.assertEqual(self.m.parse_cargo(self.text(),0,('alpha','beta')),{'passed':2,'failed':0,'ignored':0,'results':{'alpha':'ok','beta':'ok'}})
 def test_complete_assertion_failure_is_scorable(self):
  self.assertEqual(self.m.parse_cargo(self.text(('ok','FAILED')),101,('alpha','beta'))['failed'],1)
 def test_missing_duplicate_unknown_and_ignored_cannot_pass(self):
  variants=[self.text().replace('test beta ... ok\n',''),self.text()+'\ntest alpha ... ok',self.text().replace('beta','gamma'),self.text(('ok','ignored'))]
  for text in variants:
   with self.subTest(text=text),self.assertRaises(ValueError):self.m.parse_cargo(text,0,('alpha','beta'))
 def test_process_footer_and_population_must_agree(self):
  for text,code in [(self.text(),101),(self.text(),124),(self.text().replace('2 passed','9 passed'),0),(self.text().rsplit('\n',1)[0],0)]:
   with self.subTest(code=code),self.assertRaises(ValueError):self.m.parse_cargo(text,code,('alpha','beta'))
 def test_failure_stdout_cannot_spoof_named_success(self):
  text=self.text(('ok','FAILED'))+'\nfailures:\n---- beta stdout ----\ntest beta ... ok\n'
  self.assertEqual(self.m.parse_cargo(text,101,('alpha','beta'))['results']['beta'],'FAILED')
 def test_gate_controls_once_and_invalid_checks(self):
  for arm,code,blocked,active,error,want in [('G',101,0,False,None,'block'),('L',101,0,False,None,'allow'),('I',101,0,False,None,'allow'),('X',101,0,False,None,'allow'),('G',0,0,False,None,'allow'),('G',101,1,False,None,'allow'),('G',101,0,True,None,'allow'),('G',124,0,False,None,'invalid'),('G',None,0,False,'spawn','invalid')]:
   with self.subTest(arm=arm,code=code,blocked=blocked):self.assertEqual(self.m.gate_decision(arm,code,blocked,active,error),want)
 def test_block_budget_counts_all_pending_and_reserve(self):
  self.assertEqual(self.m.reserve_block('10.49884',[],['1','1','1.5','2'],'20','1'),'16.99884')
  with self.assertRaises(ValueError):self.m.reserve_block('13.50001',[],['1','1','1.5','2'],'20','1')
  self.assertEqual(self.m.reserve_block('13.5',[],['1','1','1.5','2'],'20','1'),'20.0')
 def test_invalid_costs_do_not_get_silently_dropped(self):
  for cost in ('-1','NaN','Infinity'):
   with self.subTest(cost=cost),self.assertRaises(ValueError):self.m.reserve_block('10',[cost],['1'],'20','1')
 def test_capture_reproduces_tracked_and_new_source(self):
  with tempfile.TemporaryDirectory() as temp:
   root=Path(temp)/'root';root.mkdir();(root/'src').mkdir();(root/'src/a.rs').write_text('old\n')
   for args in (['init','-q'],['add','--all'],['-c','user.name=Test','-c','user.email=t@x','-c','core.hooksPath=/dev/null','commit','-qm','base']):subprocess.run(['git','-C',str(root),*args],check=True)
   (root/'src/a.rs').write_text('new\n');(root/'src/b.rs').write_text('added\n');out=Path(temp)/'out';result=self.m.capture(root,out)
   self.assertEqual(set(result['changed']),{'src/a.rs','src/b.rs'})
   subprocess.run(['git','-C',str(root),'checkout','--','src/a.rs'],check=True);(root/'src/b.rs').unlink();subprocess.run(['git','-C',str(root),'apply','--binary',str(out/'candidate.patch')],check=True)
   self.assertEqual((root/'src/a.rs').read_text(),'new\n');self.assertEqual((root/'src/b.rs').read_text(),'added\n')
 def test_gate_script_executes_real_process_and_blocks_only_once(self):
  self.assertTrue((HERE/'gate.py').exists(),'Gate script absent')
  with tempfile.TemporaryDirectory() as temp:
   root=Path(temp)/'root';root.mkdir();(root/'src').mkdir();(root/'src/a.rs').write_text('x\n');run=Path(temp)/'run';run.mkdir()
   for args in (['init','-q'],['add','--all'],['-c','user.name=Test','-c','user.email=t@x','-c','core.hooksPath=/dev/null','commit','-qm','base']):subprocess.run(['git','-C',str(root),*args],check=True)
   fake=Path(temp)/'cargo';fake.write_text('#!'+sys.executable+'\nimport sys\nprint("error[E0063]: missing field progress")\nsys.exit(101)\n');fake.chmod(0o700)
   env=os.environ.copy();env.update(MECH_ROOT=str(root),MECH_RUN=str(run),MECH_ARM='G',MECH_CARGO=str(fake),MECH_CHECK_TIMEOUT='10')
   call=lambda:subprocess.run([sys.executable,str(HERE/'gate.py')],input=json.dumps({'cwd':str(root),'stop_hook_active':False}),env=env,capture_output=True,text=True,check=True)
   first=call();self.assertEqual(json.loads(first.stdout)['decision'],'block');self.assertIn('E0063',json.loads(first.stdout)['reason']);self.assertEqual(call().stdout,'')
   events=[json.loads(x) for x in (run/'stop.jsonl').read_text().splitlines()];self.assertEqual([e['decision'] for e in events],['block','allow']);self.assertEqual([e['exit_code'] for e in events],[101,101])

 def hook_fixture(self,temp):
  root=Path(temp)/'root';root.mkdir();(root/'src').mkdir();(root/'src/a.rs').write_text('original\n');run=Path(temp)/'run'
  for args in (['init','-q'],['add','--all'],['-c','user.name=Test','-c','user.email=t@x','-c','core.hooksPath=/dev/null','commit','-qm','base']):subprocess.run(['git','-C',str(root),*args],check=True)
  fake=Path(temp)/'cargo'
  env=os.environ.copy();env.update(MECH_ROOT=str(root),MECH_RUN=str(run),MECH_ARM='G',MECH_CARGO=str(fake),MECH_CHECK_TIMEOUT='0.05')
  return root,run,fake,env

 def test_real_controls_and_active_hook_stay_silent(self):
  for arm,active in [('L',False),('I',False),('X',False),('G',True)]:
   with self.subTest(arm=arm,active=active),tempfile.TemporaryDirectory() as temp:
    root,run,fake,env=self.hook_fixture(temp);env.update(MECH_ARM=arm,MECH_CHECK_TIMEOUT='5')
    fake.write_text('#!'+sys.executable+'\nimport sys\nprint("actual compiler failure")\nsys.exit(101)\n');fake.chmod(0o700)
    p=subprocess.run([sys.executable,str(HERE/'gate.py')],input=json.dumps({'cwd':str(root),'stop_hook_active':active}),env=env,capture_output=True,text=True,check=True)
    self.assertEqual(p.stdout,'');event=json.loads((run/'stop.jsonl').read_text());self.assertEqual((event['decision'],event['exit_code']),('allow',101));self.assertFalse((run/'blocked').exists())
    self.assertEqual(json.loads((run/'first-stop/candidate.json').read_text())['files'],self.m.inventory(root))

 def test_real_hook_rejects_missing_process_timeout_and_malformed_input(self):
  for kind in ['missing','timeout','bad-json','wrong-cwd','bad-active']:
   with self.subTest(kind=kind),tempfile.TemporaryDirectory() as temp:
    root,run,fake,env=self.hook_fixture(temp)
    if kind!='missing':
     fake.write_text('#!'+sys.executable+'\nimport time\ntime.sleep(1)\n');fake.chmod(0o700)
    event={'cwd':str(root),'stop_hook_active':False}
    if kind=='wrong-cwd':event['cwd']=str(Path(temp))
    if kind=='bad-active':event['stop_hook_active']='false'
    p=subprocess.run([sys.executable,str(HERE/'gate.py')],input='not json' if kind=='bad-json' else json.dumps(event),env=env,capture_output=True,text=True,check=True)
    self.assertEqual(p.stdout,'');record=json.loads((run/'stop.jsonl').read_text());self.assertEqual(record['decision'],'invalid');self.assertIsNone(record['exit_code']);self.assertFalse((run/'blocked').exists())

 def test_cargo_shim_executes_actual_arguments_and_preserves_exit_and_output(self):
  with tempfile.TemporaryDirectory() as temp:
   root,run,fake,env=self.hook_fixture(temp)
   fake.write_text('#!'+sys.executable+'\nimport sys\nprint("executed:"+repr(sys.argv[1:]))\nprint("stderr-marker",file=sys.stderr)\nsys.exit(101)\n');fake.chmod(0o700)
   env.update(MECH_REAL_CARGO=str(fake),MECH_ORIGIN='author')
   p=subprocess.run([sys.executable,str(HERE/'cargo_shim.py'),'check','--offline','--all-targets'],cwd=root,env=env,capture_output=True,text=True)
   self.assertEqual(p.returncode,101);self.assertIn("['check', '--offline', '--all-targets']",p.stdout);self.assertIn('stderr-marker',p.stderr)
   records=list(run.glob('cargo-*.json'));self.assertEqual(len(records),1);record=json.loads(records[0].read_text())
   self.assertEqual(record['argv'],['check','--offline','--all-targets']);self.assertEqual(record['origin'],'author');self.assertEqual(record['exit_code'],101);self.assertEqual(record['source_before'],self.m.inventory(root))

 def test_run_headers_are_required_and_match_each_report(self):
  cases=[self.text().replace('running 2 tests\n',''),self.text().replace('running 2 tests','running 3 tests'),self.text().replace('running 2 tests','running 1 test')]
  for text in cases:
   with self.subTest(text=text),self.assertRaises(ValueError):self.m.parse_cargo(text,0,('alpha','beta'))

 def test_timeout_kills_compiler_descendants_and_retains_partial_log(self):
  import time
  with tempfile.TemporaryDirectory() as temp:
   root,run,fake,env=self.hook_fixture(temp);env['MECH_CHECK_TIMEOUT']='0.2';marker=Path(temp)/'survived'
   child='import time;from pathlib import Path;time.sleep(0.7);Path('+repr(str(marker))+').write_text("survived")'
   fake.write_text('#!'+sys.executable+'\nimport subprocess,sys,time\nprint("partial compiler output",flush=True)\nsubprocess.Popen([sys.executable,"-c",'+repr(child)+'])\ntime.sleep(10)\n');fake.chmod(0o700)
   p=subprocess.run([sys.executable,str(HERE/'gate.py')],input=json.dumps({'cwd':str(root)}),env=env,capture_output=True,text=True,check=True)
   self.assertEqual(p.stdout,'');self.assertEqual(json.loads((run/'stop.jsonl').read_text())['decision'],'invalid')
   time.sleep(0.8);self.assertFalse(marker.exists(),'Compiler descendant outlived cancelled check')
   self.assertIn('partial compiler output',(run/'check-0.log').read_text())

 def test_outer_session_cancellation_closes_separate_checker_group(self):
  import signal,time
  with tempfile.TemporaryDirectory() as temp:
   root,run,fake,env=self.hook_fixture(temp);env['MECH_CHECK_TIMEOUT']='10';ready=Path(temp)/'ready';marker=Path(temp)/'leaked'
   fake.write_text('#!'+sys.executable+'\nimport time\nfrom pathlib import Path\nPath('+repr(str(ready))+').write_text("ready")\ntime.sleep(0.8)\nPath('+repr(str(marker))+').write_text("leaked")\ntime.sleep(5)\n');fake.chmod(0o700)
   process=subprocess.Popen([sys.executable,str(HERE/'gate.py')],env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
   process.stdin.write(json.dumps({'cwd':str(root)}));process.stdin.close();process.stdin=None
   deadline=time.monotonic()+5
   while not ready.exists() and time.monotonic()<deadline:time.sleep(0.02)
   self.assertTrue(ready.exists(),'Checker fixture failed to start');os.killpg(process.pid,signal.SIGTERM);process.communicate(timeout=5)
   time.sleep(0.9);self.assertFalse(marker.exists(),'Checker escaped outer session cancellation')
   self.assertEqual(json.loads((run/'stop.jsonl').read_text())['decision'],'invalid')

 def test_outer_cancellation_kills_term_ignoring_checker_inside_parent_grace(self):
  import signal,time
  with tempfile.TemporaryDirectory() as temp:
   root,run,fake,env=self.hook_fixture(temp);env['MECH_CHECK_TIMEOUT']='30';ready=Path(temp)/'ready'
   fake.write_text('#!'+sys.executable+'\nimport os,signal,time\nfrom pathlib import Path\nsignal.signal(signal.SIGTERM,signal.SIG_IGN)\nPath('+repr(str(ready))+').write_text(str(os.getpid()))\ntime.sleep(20)\n');fake.chmod(0o700)
   process=subprocess.Popen([sys.executable,str(HERE/'gate.py')],env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
   try:
    process.stdin.write(json.dumps({'cwd':str(root)}));process.stdin.close();process.stdin=None
    deadline=time.monotonic()+5
    while not ready.exists() and time.monotonic()<deadline:time.sleep(0.02)
    self.assertTrue(ready.exists());pid=int(ready.read_text());began=time.monotonic();os.killpg(process.pid,signal.SIGTERM);process.communicate(timeout=5)
    self.assertLess(time.monotonic()-began,5)
    with self.assertRaises(ProcessLookupError):os.kill(pid,0)
    self.assertEqual(json.loads((run/'stop.jsonl').read_text())['decision'],'invalid')
   finally:
    if process.poll() is None:os.killpg(process.pid,signal.SIGKILL);process.communicate()

 def test_shim_records_hook_origin_and_root_when_cwd_is_nested(self):
  with tempfile.TemporaryDirectory() as temp:
   root,run,fake,env=self.hook_fixture(temp)
   fake.write_text('#!'+sys.executable+'\n');fake.chmod(0o700);env.update(MECH_REAL_CARGO=str(fake),MECH_ORIGIN='stop_hook')
   p=subprocess.run([sys.executable,str(HERE/'cargo_shim.py'),'check'],cwd=root/'src',env=env,capture_output=True,text=True,check=True)
   record=json.loads(next(run.glob('cargo-*.json')).read_text());self.assertEqual(record['origin'],'stop_hook');self.assertEqual(record['cwd'],str(root/'src'));self.assertEqual(record['source_before'],self.m.inventory(root))

if __name__=='__main__':unittest.main()
