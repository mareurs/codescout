# Compiler-check mechanism diagnostic

This instrument separates a prompt asking an author to check its work from a compiler check that actually runs and returns feedback. The prospective matched pilot is specified in [the design](../../../docs/superpowers/specs/2026-10-29-compile-mechanism-design.md) and [the plan](../../../docs/superpowers/plans/2026-10-29-compile-mechanism.md).

## Components

- mechanism.py captures exact Git/source inventories and reconstructable patches, enforces complete named libtest reports, decides one-block feedback eligibility and reserves a whole pending block with Decimal arithmetic.
- gate.py is the same Stop observer for all arms. Only G can receive one failed-check feedback block. Malformed input, process failure, timeout or incomplete oversized output records an invalid observer.
- cargo_shim.py executes the actual Cargo command, preserving its streams and exit code. Each record identifies author versus hook, actual arguments and the source inventory before execution.
- test_mechanism.py exercises subprocess and Git behavior as well as parser and budget boundaries.

Run the offline tests:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 tools/reliable-agent-eval/compile_mechanism/test_mechanism.py
```

The private controller, preparation, frozen inputs, original receipts and traces are retained under the shared project evidence directory .codescout/resident-private/compile-mechanism-20261029. Tests above never launch a model. A shell launcher pointing at cargo_shim.py must keep this module's sibling mechanism.py importable.

## Measurement limits

A command in a transcript is an intention; a shim record is an observed execution. An explicit absolute Cargo path can bypass PATH instrumentation. A passing first Stop does not exercise feedback. Compilation failure executes no behavioral tests. The nineteen named behavioral checks are a task contract, not evidence of general coding quality.

The known cs-p20 historical base archive already contains its evaluator test body and graft. Preparation retains the original archive, then removes those exact bytes before initializing the author-visible Git history. The parent restores the frozen evaluator only for acceptance. This is setup/tool isolation on a shared host, with no adversarial OS isolation claim. Shared Cargo cache and host contention limit latency comparisons.
