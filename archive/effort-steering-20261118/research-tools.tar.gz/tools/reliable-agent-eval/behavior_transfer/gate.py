"""Bounded behavioral Stop feedback. Old compiler evidence remains read-only."""
from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, time

OLD=Path(__file__).resolve().parents[1]/'compile_mechanism'
sys.path.insert(0,str(OLD))
from mechanism import capture, parse_cargo
from gate import run_check, CheckCancelled

TESTS=('server::transfer_checks::oversized','server::transfer_checks::fifo')
ARGS=['test','--offline','--lib','server::transfer_checks::','--','--test-threads=1']
PREFIX='Before finishing: the developer behavioral checks failed. Fix the behavior while preserving both runtime switches, defaults, overrides and existing tests; then finish again. The complete test output follows.\n\n'

def require_resources(text):
    signatures=('Disk quota exceeded (os error 122)','No space left on device (os error 28)','Cannot allocate memory (os error 12)','Resource temporarily unavailable (os error 11)')
    if any(signature in text for signature in signatures):
        raise ValueError('Observed infrastructure resource failure; not candidate quality')

def classify(text,code):
    require_resources(text)
    return parse_cargo(text,code,TESTS)

def decision(arm,failed,blocked,active):
    if arm not in ('L','G','X') or failed not in (0,1) or blocked not in (0,1) or type(active) is not bool:
        raise ValueError('Malformed gate state')
    return 'block' if arm=='G' and failed and not blocked and not active else 'allow'

def main():
    run=Path(os.environ['MECH_RUN']);root=Path(os.environ['MECH_ROOT']);arm=os.environ['MECH_ARM']
    run.mkdir(parents=True,exist_ok=True);began=time.monotonic()
    event_record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'arm':arm}
    try:
        event=json.load(sys.stdin)
        if not isinstance(event,dict) or not isinstance(event.get('cwd'),str) or Path(event['cwd']).resolve()!=root.resolve():raise ValueError('Unexpected hook cwd')
        active=event.get('stop_hook_active',False)
        if type(active) is not bool:raise ValueError('Malformed active flag')
        if not (run/'first-stop').exists():capture(root,run/'first-stop')
        blocked=int((run/'blocked').read_text()) if (run/'blocked').exists() else 0
        index=len((run/'stop.jsonl').read_text().splitlines()) if (run/'stop.jsonl').exists() else 0
        log=run/f'check-{index}.log';env=os.environ.copy();env['MECH_ORIGIN']='stop_hook'
        result=run_check([os.environ['MECH_CARGO'],*ARGS],root,env,float(os.environ.get('MECH_CHECK_TIMEOUT','600')),log)
        output=result.stdout+result.stderr
        if len(output)>65536:raise ValueError('Test feedback exceeds complete-output limit')
        parsed=classify(output.decode(errors='replace'),result.returncode)
        action=decision(arm,int(parsed['failed']>0),blocked,active)
        event_record.update(exit_code=result.returncode,decision=action,blocked_before=blocked,stop_hook_active=active,log=str(log),log_sha256=hashlib.sha256(output).hexdigest(),output_bytes=len(output),tests=parsed)
        if action=='block':
            (run/'blocked').write_text('1\n')
            reason=PREFIX+output.decode(errors='replace')
            payload={'decision':'block','reason':reason}
            (run/f'feedback-{index}.json').write_text(json.dumps(payload)+'\n')
            event_record['feedback_sha256']=hashlib.sha256(reason.encode()).hexdigest()
            print(json.dumps(payload))
    except (OSError,ValueError,KeyError,subprocess.TimeoutExpired,CheckCancelled) as exc:
        event_record.update(decision='invalid',exit_code=None,error=str(exc))
    event_record['elapsed_s']=time.monotonic()-began
    with (run/'stop.jsonl').open('a') as f:f.write(json.dumps(event_record)+'\n')

if __name__=='__main__':main()
