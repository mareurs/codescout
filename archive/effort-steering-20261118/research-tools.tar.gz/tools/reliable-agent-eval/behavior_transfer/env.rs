// Parent-only environment probes, each in its own Cargo test child process.
use super::librarian_enabled_at_runtime;

fn file(enabled: bool) -> tempfile::TempDir {
    let dir = tempfile::tempdir().unwrap();
    std::fs::create_dir_all(dir.path().join(".codescout")).unwrap();
    std::fs::write(
        dir.path().join(".codescout/project.toml"),
        format!("[librarian]\nenabled = {enabled}\n"),
    )
    .unwrap();
    dir
}

#[test]
fn enabled_override() {
    assert_eq!(std::env::var("LIBRARIAN_ENABLED").unwrap(), "on");
    let dir = file(false);
    assert!(librarian_enabled_at_runtime(dir.path().to_str()));
}

#[test]
fn disabled_override() {
    assert_eq!(std::env::var("LIBRARIAN_ENABLED").unwrap(), "0");
    let dir = file(true);
    assert!(!librarian_enabled_at_runtime(dir.path().to_str()));
}

#[test]
fn unknown_override_uses_file() {
    assert_eq!(std::env::var("LIBRARIAN_ENABLED").unwrap(), "banana");
    let dir = file(false);
    assert!(!librarian_enabled_at_runtime(dir.path().to_str()));
}
