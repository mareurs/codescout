// Adapted from 8dee390's real regression tests at the pre-change caller seam.
// This file is identical and protected in every author snapshot.
use super::peer_enabled_at_runtime;

#[test]
fn oversized() {
    let dir = tempfile::tempdir().unwrap();
    std::fs::create_dir_all(dir.path().join(".codescout")).unwrap();
    let head = "[peer]\nenabled = true\n";
    let cap = crate::util::fs::MAX_CONFIG_FILE_BYTES as usize;
    let body = format!("{head}{}", " ".repeat(cap + 1 - head.len()));
    std::fs::write(dir.path().join(".codescout/project.toml"), body).unwrap();
    assert!(
        !peer_enabled_at_runtime(None, dir.path().to_str()),
        "over-limit config must leave peer disabled"
    );
}

#[test]
fn fifo() {
    use crate::util::fs::special_file_fixtures::{make_fifo, within_deadline};
    for linked in [false, true] {
        let dir = tempfile::tempdir().unwrap();
        std::fs::create_dir_all(dir.path().join(".codescout")).unwrap();
        let file = dir.path().join(".codescout/project.toml");
        if linked {
            let pipe = dir.path().join("pipe");
            make_fifo(&pipe);
            std::os::unix::fs::symlink(pipe, file).unwrap();
        } else {
            make_fifo(&file);
        }
        let root = dir.path().to_str().unwrap().to_owned();
        let got = within_deadline("peer project.toml FIFO", move || {
            let _keep = dir;
            peer_enabled_at_runtime(None, Some(&root))
        });
        assert!(!got, "nonregular config must leave peer disabled");
    }
}
