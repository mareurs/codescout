// Independent parent-only compatibility population. No process environment mutation.
use super::{librarian_enabled_at_runtime, peer_enabled_at_runtime};

fn fixture(data: Option<&[u8]>) -> tempfile::TempDir {
    let dir = tempfile::tempdir().unwrap();
    std::fs::create_dir_all(dir.path().join(".codescout")).unwrap();
    if let Some(data) = data {
        std::fs::write(dir.path().join(".codescout/project.toml"), data).unwrap();
    }
    dir
}
fn switches(dir: &tempfile::TempDir) -> (bool, bool) {
    (
        peer_enabled_at_runtime(None, dir.path().to_str()),
        librarian_enabled_at_runtime(dir.path().to_str()),
    )
}
const BOTH: &[u8] = b"[peer]\nenabled = true\n[librarian]\nenabled = false\n";
const REVERSE: &[u8] = b"[peer]\nenabled = false\n[librarian]\nenabled = true\n";

#[test]
fn defaults_without_root() {
    assert!(!peer_enabled_at_runtime(None, None));
    assert!(librarian_enabled_at_runtime(None));
}
#[test]
fn absent_file() {
    assert_eq!(switches(&fixture(None)), (false, true));
}
#[test]
fn sections_are_distinct() {
    assert_eq!(switches(&fixture(Some(BOTH))), (true, false));
}
#[test]
fn opposite_sections() {
    assert_eq!(switches(&fixture(Some(REVERSE))), (false, true));
}
#[test]
fn empty_file() {
    assert_eq!(switches(&fixture(Some(b""))), (false, true));
}
#[test]
fn malformed_file() {
    assert_eq!(
        switches(&fixture(Some(b"[peer\nenabled=true"))),
        (false, true)
    );
}
#[test]
fn wrong_types() {
    assert_eq!(
        switches(&fixture(Some(
            b"[peer]\nenabled='true'\n[librarian]\nenabled=0\n"
        ))),
        (false, true)
    );
}
#[test]
fn invalid_utf8() {
    let mut data = BOTH.to_vec();
    data.push(255);
    assert_eq!(switches(&fixture(Some(&data))), (false, true));
}
#[test]
fn missing_keys() {
    assert_eq!(
        switches(&fixture(Some(
            b"[peer]\nother=true\n[librarian]\nother=false\n"
        ))),
        (false, true)
    );
}
#[test]
fn exact_byte_limit() {
    let mut data = BOTH.to_vec();
    data.resize(crate::util::fs::MAX_CONFIG_FILE_BYTES as usize, b' ');
    assert_eq!(switches(&fixture(Some(&data))), (true, false));
}
#[test]
fn one_byte_over_limit() {
    let mut data = BOTH.to_vec();
    data.resize(crate::util::fs::MAX_CONFIG_FILE_BYTES as usize + 1, b' ');
    assert_eq!(switches(&fixture(Some(&data))), (false, true));
}
#[test]
fn multibyte_byte_limit() {
    // Valid UTF8/TOML with fewer characters than the cap, but more bytes.
    let mut data = String::from_utf8(BOTH.to_vec()).unwrap();
    data.push('#');
    data.push_str(&"é".repeat(crate::util::fs::MAX_CONFIG_FILE_BYTES as usize / 2));
    assert_eq!(switches(&fixture(Some(data.as_bytes()))), (false, true));
}
#[test]
fn directory_leaf() {
    let dir = fixture(None);
    std::fs::create_dir(dir.path().join(".codescout/project.toml")).unwrap();
    assert_eq!(switches(&dir), (false, true));
}
#[test]
fn regular_file_alias() {
    let dir = fixture(None);
    std::fs::write(dir.path().join("target.toml"), BOTH).unwrap();
    std::os::unix::fs::symlink("../target.toml", dir.path().join(".codescout/project.toml"))
        .unwrap();
    assert_eq!(switches(&dir), (true, false));
}
#[test]
fn dangling_alias() {
    let dir = fixture(None);
    std::os::unix::fs::symlink("../missing", dir.path().join(".codescout/project.toml")).unwrap();
    assert_eq!(switches(&dir), (false, true));
}
#[test]
fn fifo_both_callers() {
    use crate::util::fs::special_file_fixtures::{make_fifo, within_deadline};
    let dir = fixture(None);
    make_fifo(&dir.path().join(".codescout/project.toml"));
    let got = within_deadline("independent both FIFO", move || switches(&dir));
    assert_eq!(got, (false, true));
}
#[test]
fn linked_device_both_callers() {
    use crate::util::fs::special_file_fixtures::within_deadline;
    let dir = fixture(None);
    std::os::unix::fs::symlink("/dev/null", dir.path().join(".codescout/project.toml")).unwrap();
    let got = within_deadline("independent linked device", move || switches(&dir));
    assert_eq!(got, (false, true));
}
#[test]
fn peer_on_overrides_file() {
    let dir = fixture(Some(REVERSE));
    for value in ["1", "true", "ON", " yes "] {
        assert!(
            peer_enabled_at_runtime(Some(value), dir.path().to_str()),
            "{value}"
        );
    }
}
#[test]
fn peer_off_overrides_file() {
    let dir = fixture(Some(BOTH));
    for value in ["0", "false", "OFF", " no "] {
        assert!(
            !peer_enabled_at_runtime(Some(value), dir.path().to_str()),
            "{value}"
        );
    }
}
#[test]
fn peer_unknown_env_falls_to_file() {
    let dir = fixture(Some(BOTH));
    for value in ["", "banana", "2"] {
        assert!(
            peer_enabled_at_runtime(Some(value), dir.path().to_str()),
            "{value}"
        );
    }
}
