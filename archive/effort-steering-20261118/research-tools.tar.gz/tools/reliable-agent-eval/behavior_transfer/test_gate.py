"""Gate tests use actual child processes; no model calls."""
import importlib.util, json, os, subprocess, sys, tempfile, unittest
from pathlib import Path

ASSET=Path(__file__).resolve().parent

class GateTests(unittest.TestCase):
    def test_strict_developer_population(self):
        spec=importlib.util.spec_from_file_location('behavior_gate',ASSET/'gate.py')
        g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
        good='running 2 tests\ntest server::transfer_checks::oversized ... ok\ntest server::transfer_checks::fifo ... ok\ntest result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 3 filtered out; finished in 0.01s\n'
        self.assertEqual(g.classify(good,0)['passed'],2)
        for text,code in [(good.replace('running 2','running 1'),0),(good,101),(good.replace('fifo','other'),0),(good.replace(' ... ok',' ... ignored',1),0),('error[E0001]: compilation failed\n',101)]:
            with self.subTest(text=text,code=code):
                with self.assertRaises(ValueError):g.classify(text,code)

    def test_feedback_bounds(self):
        spec=importlib.util.spec_from_file_location('behavior_gate',ASSET/'gate.py')
        g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
        self.assertEqual(g.decision('G',1,0,False),'block')
        for arm,blocked,active in [('L',0,False),('X',0,False),('G',1,False),('G',0,True)]:
            self.assertEqual(g.decision(arm,1,blocked,active),'allow')
        self.assertEqual(g.decision('G',0,0,False),'allow')
    def test_resource_error_is_not_a_quality_result(self):
        spec=importlib.util.spec_from_file_location('behavior_gate',ASSET/'gate.py')
        g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
        text='running 2 tests\ntest server::transfer_checks::oversized ... FAILED\ntest server::transfer_checks::fifo ... FAILED\nfailures:\ncalled unwrap on Err: Disk quota exceeded (os error 122)\ntest result: FAILED. 0 passed; 2 failed; 0 ignored; 0 measured; 3 filtered out; finished in 0.01s\n'
        with self.assertRaises(ValueError):g.classify(text,101)

if __name__=='__main__':unittest.main()
