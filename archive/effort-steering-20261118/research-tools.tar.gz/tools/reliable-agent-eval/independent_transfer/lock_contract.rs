//! Parent-only lock-leaf contract. Mutations: follow leaf links, return FIFO, truncate reused locks.
pub use codescout::tools;
// The production module's old unit tests compile alongside this seam.
// Their crate-private fixture helpers are not exported by the dependency library.
pub mod util {
    pub mod fs {
        pub use codescout::util::fs::*;
        pub mod special_file_fixtures {
            pub fn make_fifo(path: &std::path::Path) {
                use std::os::unix::ffi::OsStrExt;
                let name = std::ffi::CString::new(path.as_os_str().as_bytes()).unwrap();
                assert_eq!(unsafe { libc::mkfifo(name.as_ptr(), 0o600) }, 0);
            }
            pub fn within_deadline<T: Send + 'static>(
                what: &str,
                f: impl FnOnce() -> T + Send + 'static,
            ) -> T {
                let (tx, rx) = std::sync::mpsc::channel();
                let handle = std::thread::spawn(move || {
                    let _ = tx.send(f());
                });
                match rx.recv_timeout(std::time::Duration::from_secs(15)) {
                    Ok(value) => value,
                    Err(std::sync::mpsc::RecvTimeoutError::Timeout) => {
                        panic!("{what}: fixture deadline")
                    }
                    Err(std::sync::mpsc::RecvTimeoutError::Disconnected) => match handle.join() {
                        Err(payload) => std::panic::resume_unwind(payload),
                        Ok(()) => panic!("{what}: worker returned no result"),
                    },
                }
            }
        }
    }
}

#[allow(dead_code)]
#[path = "../src/agent/write_guard.rs"]
mod candidate;

use serde_json::json;
use std::ffi::CString;
use std::fs;
use std::io::{Read, Seek, SeekFrom, Write};
use std::os::unix::ffi::OsStrExt;
use std::os::unix::fs::{symlink, FileTypeExt, MetadataExt};
use std::os::unix::net::UnixListener;
use std::panic::{catch_unwind, AssertUnwindSafe};

const CASES: &[&str] = &[
    "fresh-root",
    "fresh-directory",
    "existing-empty",
    "existing-payload",
    "unicode-root",
    "link-outside-existing",
    "link-outside-missing",
    "link-inside-existing",
    "link-inside-missing",
    "self-link",
    "fifo-leaf",
    "socket-leaf",
    "directory-leaf",
    "parent-alias",
    "root-alias",
    "flock-reuse",
];

#[test]
fn transfer_contract() {
    let mut failed = 0;
    for &id in CASES {
        let temp = tempfile::tempdir().unwrap();
        let real_root = temp.path().join(if id == "unicode-root" {
            "proiect α cu spații"
        } else {
            "project"
        });
        fs::create_dir(&real_root).unwrap();
        let outside = temp.path().join("outside");
        fs::create_dir(&outside).unwrap();
        let mut root = real_root.clone();
        if id == "root-alias" {
            root = temp.path().join("root-alias");
            symlink(&real_root, &root).unwrap();
            assert!(fs::symlink_metadata(&root)
                .unwrap()
                .file_type()
                .is_symlink());
        }
        let config = root.join(".codescout");
        if id == "parent-alias" {
            symlink(&outside, &config).unwrap();
            assert!(fs::symlink_metadata(&config)
                .unwrap()
                .file_type()
                .is_symlink());
        } else if id != "fresh-root" {
            fs::create_dir(&config).unwrap();
        }
        let lock = config.join("write.lock");
        let payload = b"original lock payload\n";
        let mut target = None;
        let mut listener = None;
        let refused = matches!(
            id,
            "link-outside-existing"
                | "link-outside-missing"
                | "link-inside-existing"
                | "link-inside-missing"
                | "self-link"
                | "fifo-leaf"
                | "socket-leaf"
                | "directory-leaf"
        );
        match id {
            "link-outside-existing"
            | "link-outside-missing"
            | "link-inside-existing"
            | "link-inside-missing" => {
                let p = if id.starts_with("link-outside") {
                    outside.join("target")
                } else {
                    root.join("target")
                };
                let exists = id.ends_with("-existing");
                if exists {
                    fs::write(&p, payload).unwrap();
                }
                symlink(&p, &lock).unwrap();
                assert!(fs::symlink_metadata(&lock)
                    .unwrap()
                    .file_type()
                    .is_symlink());
                assert_eq!(p.exists(), exists);
                target = Some((p, exists));
            }
            "self-link" => {
                symlink("write.lock", &lock).unwrap();
                assert!(fs::symlink_metadata(&lock)
                    .unwrap()
                    .file_type()
                    .is_symlink());
            }
            "fifo-leaf" => {
                let p = CString::new(lock.as_os_str().as_bytes()).unwrap();
                assert_eq!(unsafe { libc::mkfifo(p.as_ptr(), 0o600) }, 0);
                assert!(fs::symlink_metadata(&lock).unwrap().file_type().is_fifo());
            }
            "socket-leaf" => {
                listener = Some(UnixListener::bind(&lock).unwrap());
                assert!(fs::symlink_metadata(&lock).unwrap().file_type().is_socket());
            }
            "directory-leaf" => {
                fs::create_dir(&lock).unwrap();
                fs::write(lock.join("marker"), payload).unwrap();
            }
            "existing-empty" => fs::write(&lock, []).unwrap(),
            "existing-payload" | "unicode-root" | "parent-alias" | "root-alias" | "flock-reuse" => {
                fs::write(&lock, payload).unwrap()
            }
            _ => {}
        }
        let before = fs::symlink_metadata(&lock).ok().map(|m| (m.dev(), m.ino()));
        let expected_payload: &[u8] = if matches!(
            id,
            "existing-payload" | "unicode-root" | "parent-alias" | "root-alias" | "flock-reuse"
        ) {
            payload
        } else {
            b""
        };
        let observed = catch_unwind(AssertUnwindSafe(|| -> Result<(), String> {
            let result = candidate::open_lock_file(&root);
            if refused {
                let err = result.err().ok_or("accepted a refused lock leaf")?;
                let after = fs::symlink_metadata(&lock).map_err(|e| e.to_string())?;
                if Some((after.dev(), after.ino())) != before {
                    return Err("leaf replaced or removed".into());
                }
                if matches!(
                    id,
                    "link-outside-existing"
                        | "link-outside-missing"
                        | "link-inside-existing"
                        | "link-inside-missing"
                        | "self-link"
                        | "fifo-leaf"
                ) && !err.to_string().contains(&lock.display().to_string())
                {
                    return Err("refusal does not name lock path".into());
                }
                if let Some((p, existed)) = &target {
                    if p.exists() != *existed {
                        return Err("target existence changed".into());
                    }
                    if *existed && fs::read(p).map_err(|e| e.to_string())? != payload {
                        return Err("target bytes changed".into());
                    }
                }
                if id == "directory-leaf" && fs::read(lock.join("marker")).unwrap() != payload {
                    return Err("directory marker changed".into());
                }
            } else {
                let file = result.map_err(|e| e.to_string())?;
                if !file.metadata().map_err(|e| e.to_string())?.is_file() {
                    return Err("nonregular descriptor".into());
                }
                if let Some(identity) = before {
                    let m = fs::symlink_metadata(&lock).map_err(|e| e.to_string())?;
                    if (m.dev(), m.ino()) != identity {
                        return Err("existing lock replaced".into());
                    }
                }
                if fs::read(&lock).map_err(|e| e.to_string())? != expected_payload {
                    return Err("payload truncated".into());
                }
                let mut fd = file.try_clone().map_err(|e| e.to_string())?;
                fd.seek(SeekFrom::Start(0)).map_err(|e| e.to_string())?;
                let mut bytes = Vec::new();
                fd.read_to_end(&mut bytes).map_err(|e| e.to_string())?;
                if bytes != expected_payload {
                    return Err("descriptor reads a different object".into());
                }
                fd.write_all(b"+").map_err(|e| e.to_string())?;
                let mut wanted = expected_payload.to_vec();
                wanted.push(b'+');
                if fs::read(&lock).map_err(|e| e.to_string())? != wanted {
                    return Err("descriptor is not writable".into());
                }
                if id == "flock-reuse" {
                    fs4::fs_std::FileExt::try_lock_exclusive(&*file).map_err(|e| e.to_string())?;
                    let second = candidate::open_lock_file(&root).map_err(|e| e.to_string())?;
                    if fs4::fs_std::FileExt::try_lock_exclusive(&*second).is_ok() {
                        return Err("independent open bypassed held flock".into());
                    }
                    fs4::fs_std::FileExt::unlock(&*file).map_err(|e| e.to_string())?;
                    fs4::fs_std::FileExt::try_lock_exclusive(&*second)
                        .map_err(|e| e.to_string())?;
                    fs4::fs_std::FileExt::unlock(&*second).map_err(|e| e.to_string())?;
                }
                if id == "parent-alias"
                    && !fs::symlink_metadata(&config)
                        .unwrap()
                        .file_type()
                        .is_symlink()
                {
                    return Err("parent alias replaced".into());
                }
            }
            Ok(())
        }));
        let error = match observed {
            Ok(Ok(())) => None,
            Ok(Err(e)) => Some(e),
            Err(_) => Some("candidate panicked".to_string()),
        };
        let passed = error.is_none();
        failed += usize::from(!passed);
        println!(
            "\nTRANSFER_CASE {}",
            json!({"case_id":id,"passed":passed,"error":error})
        );
        drop(listener);
    }
    println!(
        "TRANSFER_SUMMARY {}",
        json!({"scenarios":CASES.len(),"passed":CASES.len()-failed,"failed":failed})
    );
    assert_eq!(failed, 0, "lock contract failed");
}
