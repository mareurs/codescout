"""Strict parent-side measurement of complete transfer-contract output."""
import json
import re

CASES = {
    "lock-leaf": ("fresh-root", "fresh-directory", "existing-empty", "existing-payload",
        "unicode-root", "link-outside-existing", "link-outside-missing",
        "link-inside-existing", "link-inside-missing", "self-link", "fifo-leaf",
        "socket-leaf", "directory-leaf", "parent-alias", "root-alias", "flock-reuse"),
    "registry-limit": ("missing", "empty-registry", "small-preserves-fields", "above-old-limit",
        "below-limit", "at-limit", "one-over-limit", "malformed-small",
        "malformed-above-old-limit", "empty-file", "invalid-utf8", "oversize-invalid-utf8",
        "directory", "fifo", "link-regular", "link-fifo"),
}

class InvalidRun(ValueError):
    pass

def unique_json(text):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise InvalidRun("duplicate JSON key: " + key)
            result[key] = value
        return result
    try:
        return json.loads(text, object_pairs_hook=unique)
    except (ValueError, TypeError) as exc:
        raise InvalidRun("invalid JSON: " + str(exc)) from exc

def verify(task, text, exit_code):
    if task not in CASES or type(exit_code) is not int or exit_code not in (0, 101):
        raise InvalidRun("unregistered task or unexpected process exit")
    records, summaries = [], []
    for line in text.splitlines():
        if line.startswith("TRANSFER_CASE "):
            records.append(unique_json(line.removeprefix("TRANSFER_CASE ")))
        elif line.startswith("TRANSFER_SUMMARY "):
            summaries.append(unique_json(line.removeprefix("TRANSFER_SUMMARY ")))
    if [r.get("case_id") if isinstance(r,dict) else None for r in records] != list(CASES[task]):
        raise InvalidRun("missing, duplicate, reordered or unknown case")
    failed = []
    for record in records:
        if set(record) != {"case_id", "passed", "error"} or type(record["passed"]) is not bool:
            raise InvalidRun("invalid case fields or types")
        error = record["error"]
        if (record["passed"] and error is not None) or (not record["passed"] and (type(error) is not str or not error)):
            raise InvalidRun("case boolean/error disagreement")
        if not record["passed"]:
            failed.append(record["case_id"])
    result = dict(scenarios=len(CASES[task]), passed=len(CASES[task])-len(failed), failed=len(failed))
    if len(summaries) != 1 or json.dumps(summaries[0],sort_keys=True) != json.dumps(result,sort_keys=True):
        raise InvalidRun("summary disagrees with complete outcomes")
    state = "FAILED" if failed else "ok"
    footers = re.findall(r"^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in [^\n]+$", text, re.MULTILINE)
    want = (state, "0" if failed else "1", "1" if failed else "0", "0", "0")
    if len(footers) != 1 or footers[0][:5] != want or exit_code != (101 if failed else 0):
        raise InvalidRun("libtest footer/process disagree")
    if re.findall(r"^test transfer_contract \.\.\. (ok|FAILED)$", text, re.MULTILINE) != [state]:
        raise InvalidRun("missing or inconsistent named test")
    return dict(result, failed_ids=failed, rust_tests=1)
