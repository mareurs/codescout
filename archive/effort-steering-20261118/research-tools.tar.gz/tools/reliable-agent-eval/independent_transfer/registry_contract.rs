//! Parent-only registry contract. Mutations: old cap, cap+1, malformed JSON defaults empty.
use codescout::library::registry::LibraryRegistry;
use serde_json::json;
use std::ffi::CString;
use std::fs;
use std::os::unix::ffi::OsStrExt;
use std::os::unix::fs::{symlink, FileTypeExt};
use std::panic::{catch_unwind, AssertUnwindSafe};

const LIMIT: usize = 16 * 1024 * 1024;
const CASES: &[&str] = &[
    "missing",
    "empty-registry",
    "small-preserves-fields",
    "above-old-limit",
    "below-limit",
    "at-limit",
    "one-over-limit",
    "malformed-small",
    "malformed-above-old-limit",
    "empty-file",
    "invalid-utf8",
    "oversize-invalid-utf8",
    "directory",
    "fifo",
    "link-regular",
    "link-fifo",
];

fn registry_json() -> Vec<u8> {
    serde_json::to_vec(&json!({"entries":[{
        "name":"lib-α","path":"/tmp/example-library","language":"rust",
        "version":"2.3","version_indexed":"2.2","db_file":"lib.sqlite",
        "nudge_dismissed":true,"discovered_via":"manual","indexed":true,"source_available":true
    }]}))
    .unwrap()
}

#[test]
fn transfer_contract() {
    let mut failed = 0;
    for &id in CASES {
        let temp = tempfile::tempdir().unwrap();
        let path = temp.path().join("libraries.json");
        let original = registry_json();
        let wants_entry = matches!(
            id,
            "small-preserves-fields"
                | "above-old-limit"
                | "below-limit"
                | "at-limit"
                | "link-regular"
        );
        let wants_error = matches!(
            id,
            "malformed-small" | "malformed-above-old-limit" | "empty-file" | "invalid-utf8"
        );
        match id {
            "missing" => {}
            "directory" => {
                fs::create_dir(&path).unwrap();
            }
            "fifo" | "link-fifo" => {
                let actual = if id == "fifo" {
                    path.clone()
                } else {
                    temp.path().join("fifo-target")
                };
                let name = CString::new(actual.as_os_str().as_bytes()).unwrap();
                assert_eq!(unsafe { libc::mkfifo(name.as_ptr(), 0o600) }, 0);
                assert!(fs::symlink_metadata(&actual).unwrap().file_type().is_fifo());
                if id == "link-fifo" {
                    symlink(&actual, &path).unwrap();
                }
            }
            "link-regular" => {
                let actual = temp.path().join("registry-target.json");
                fs::write(&actual, &original).unwrap();
                symlink(&actual, &path).unwrap();
                assert!(fs::symlink_metadata(&path)
                    .unwrap()
                    .file_type()
                    .is_symlink());
            }
            "empty-registry" => {
                fs::write(&path, br#"{"entries":[]}"#).unwrap();
            }
            "empty-file" => {
                fs::write(&path, []).unwrap();
            }
            "invalid-utf8" => {
                fs::write(&path, [0xff]).unwrap();
            }
            "oversize-invalid-utf8" => {
                fs::write(&path, vec![0xff; LIMIT + 1]).unwrap();
            }
            "malformed-small" => {
                fs::write(&path, b"{").unwrap();
            }
            "malformed-above-old-limit" => {
                let mut b = vec![b' '; 1024 * 1024 + 1];
                b[0] = b'{';
                fs::write(&path, b).unwrap();
            }
            _ => {
                let size = match id {
                    "above-old-limit" => 1024 * 1024 + 1,
                    "below-limit" => LIMIT - 1,
                    "at-limit" => LIMIT,
                    "one-over-limit" => LIMIT + 1,
                    _ => original.len(),
                };
                let mut b = original.clone();
                b.resize(size, b' ');
                fs::write(&path, &b).unwrap();
                assert_eq!(fs::metadata(&path).unwrap().len(), size as u64);
            }
        }
        let before = if path.is_file() {
            Some(fs::read(&path).unwrap())
        } else {
            None
        };
        let observed = catch_unwind(AssertUnwindSafe(|| -> Result<(), String> {
            let result = LibraryRegistry::load(&path);
            if wants_error {
                if result.is_ok() {
                    return Err("malformed readable registry did not error".into());
                }
            } else {
                let registry = result.map_err(|e| e.to_string())?;
                if wants_entry {
                    let actual = serde_json::to_value(&registry).map_err(|e| e.to_string())?;
                    let expected: serde_json::Value = serde_json::from_slice(&original).unwrap();
                    if actual != expected {
                        return Err("registry entry or fields were lost".into());
                    }
                } else if !registry.all().is_empty() {
                    return Err("refused/missing registry was not empty".into());
                }
            }
            if let Some(bytes) = &before {
                if fs::read(&path).map_err(|e| e.to_string())? != *bytes {
                    return Err("load changed input bytes".into());
                }
            }
            if id.starts_with("link-")
                && !fs::symlink_metadata(&path)
                    .unwrap()
                    .file_type()
                    .is_symlink()
            {
                return Err("load replaced link".into());
            }
            if id == "missing" && path.exists() {
                return Err("load created absent registry".into());
            }
            Ok(())
        }));
        let error = match observed {
            Ok(Ok(())) => None,
            Ok(Err(e)) => Some(e),
            Err(_) => Some("candidate panicked".to_string()),
        };
        let passed = error.is_none();
        failed += usize::from(!passed);
        println!(
            "\nTRANSFER_CASE {}",
            json!({"case_id":id,"passed":passed,"error":error})
        );
    }
    println!(
        "TRANSFER_SUMMARY {}",
        json!({"scenarios":CASES.len(),"passed":CASES.len()-failed,"failed":failed})
    );
    assert_eq!(failed, 0, "registry contract failed");
}
