import importlib.util
import json
import pathlib
import unittest

HERE = pathlib.Path(__file__).parent

class VerifierTests(unittest.TestCase):
    def setUp(self):
        self.assertTrue((HERE / "verify.py").exists(), "Transfer verifier is not implemented")
        spec = importlib.util.spec_from_file_location("transfer_verify", HERE / "verify.py")
        self.v = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.v)

    def output(self, task="lock-leaf", failed=()):
        ids = self.v.CASES[task]
        lines = ["TRANSFER_CASE " + json.dumps(dict(case_id=x, passed=x not in failed,
                 error=None if x not in failed else "wrong behavior")) for x in ids]
        lines.append("TRANSFER_SUMMARY " + json.dumps(dict(scenarios=len(ids),passed=len(ids)-len(failed),failed=len(failed))))
        state = "FAILED" if failed else "ok"
        lines += [f"test transfer_contract ... {state}",
            f"test result: {state}. {0 if failed else 1} passed; {1 if failed else 0} failed; 0 ignored; 0 measured; 24 filtered out; finished in 0.20s"]
        return "\n".join(lines)

    def test_complete_pass_is_measured(self):
        self.assertEqual(self.v.verify("lock-leaf", self.output(), 0)["passed"], 16)

    def test_complete_behavior_failure_is_scorable(self):
        got = self.v.verify("registry-limit", self.output("registry-limit", ("at-limit",)), 101)
        self.assertEqual(got["failed_ids"], ["at-limit"])

    def test_missing_reordered_or_duplicate_case_is_invalid(self):
        lines = self.output().splitlines()
        for changed in (lines[1:], [lines[1],lines[0],*lines[2:]], [lines[0],*lines]):
            with self.subTest(changed=changed[:1]):
                with self.assertRaises(self.v.InvalidRun):
                    self.v.verify("lock-leaf", "\n".join(changed), 0)

    def test_dishonest_summary_is_invalid(self):
        text = self.output(failed=("fifo-leaf",)).replace('"passed": 15, "failed": 1','"passed": 16, "failed": 0')
        with self.assertRaises(self.v.InvalidRun):
            self.v.verify("lock-leaf", text, 101)

    def test_summary_booleans_are_not_integer_counts(self):
        text = self.output().replace('"failed": 0}', '"failed": false}')
        with self.assertRaises(self.v.InvalidRun):
            self.v.verify("lock-leaf", text, 0)

    def test_case_boolean_and_error_must_agree(self):
        for text in (self.output().replace('"passed": true','"passed": 1',1),
                     self.output().replace('"error": null','"error": "hidden failure"',1)):
            with self.assertRaises(self.v.InvalidRun):
                self.v.verify("lock-leaf",text,0)

    def test_duplicate_json_key_is_invalid(self):
        text=self.output().replace('"passed": true','"passed": false, "passed": true',1)
        with self.assertRaises(self.v.InvalidRun):
            self.v.verify("lock-leaf",text,0)

    def test_real_process_exit_and_footer_must_agree(self):
        for text,code in ((self.output(),101),(self.output(),124),
            (self.output().replace("1 passed; 0 failed","2 passed; 0 failed"),0),
            (self.output().replace("test transfer_contract ... ok","test wrong ... ok"),0)):
            with self.assertRaises(self.v.InvalidRun):
                self.v.verify("lock-leaf",text,code)

    def test_truncated_footer_and_extra_summary_are_invalid(self):
        for text in ("\n".join(self.output().splitlines()[:-1]),
                     self.output()+"\nTRANSFER_SUMMARY {}"):
            with self.assertRaises(self.v.InvalidRun):
                self.v.verify("lock-leaf",text,0)

    def test_task_manifest_mismatch_is_invalid(self):
        with self.assertRaises(self.v.InvalidRun):
            self.v.verify("registry-limit",self.output(),0)

if __name__ == "__main__":
    unittest.main()
