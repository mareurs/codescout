# Independent effort-transfer contracts

Parent-side acceptance assets for two historical tasks selected before paid author outcomes. Each contract emits sixteen ordered TRANSFER_CASE records and one TRANSFER_SUMMARY. The trusted Python verifier checks the full population, types, summary, named Rust result and actual process exit.

Copy the task's Rust asset into a clean task snapshot as tests/transfer_contract.rs and run:

```sh
./scripts/with-slot.sh cargo test --offline --test transfer_contract transfer_contract -- --exact --nocapture
./scripts/with-slot.sh cargo check --offline --all-targets
```

lock_contract.rs compiles the actual src/agent/write_guard.rs at its existing private module seam. A test-only wrapper supplies the crate-private fixture helpers required to compile its legacy embedded tests; --exact executes only the new parent contract. It tests real filesystem objects and descriptors. It does not validate all server activation paths or prove race freedom.

registry_contract.rs calls the public library registry loader and checks byte-size boundaries, retained fields, malformed inputs and special-file behavior.

The assets are stored outside tests, so format them without resolving their future transplanted module path:

```sh
rustfmt --edition 2021 --config skip_children=true lock_contract.rs registry_contract.rs
python3 -m unittest discover -s tools/reliable-agent-eval/independent_transfer -p 'test_*.py'
```

The model authors do not receive these acceptance sources. Complete failure logs can become repair feedback after a valid scorable low failure. Parent grading applies the exact saved patch to a fresh base, injects the frozen contract, and preserves protected/source hashes.

See the [design](../../../docs/superpowers/specs/2026-10-28-independent-effort-transfer-design.md) and [plan](../../../docs/superpowers/plans/2026-10-28-independent-effort-transfer.md). Private evidence and receipts live under independent-transfer-20261028 in the main repository's .codescout/resident-private directory.
