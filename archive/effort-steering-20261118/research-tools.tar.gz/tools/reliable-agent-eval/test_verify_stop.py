import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest

SCRIPT = Path(__file__).with_name('verify_stop.py')


class VerificationGateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.config = self.root / 'config.json'
        self.state = self.root / 'state'
        self.event = {'session_id': 'session-a', 'cwd': str(self.root), 'stop_hook_active': False}
        self.write_config([sys.executable, '-c',
                           "from pathlib import Path; import sys; print('acceptance defect'); sys.exit(0 if Path('fixed').exists() else 1)"])

    def write_config(self, command, **changes):
        config = {'cwd': str(self.root), 'commands': [command], 'timeout_seconds': 3,
                  'max_repairs': 1, 'state_dir': str(self.state)}
        config.update(changes)
        self.config.write_text(json.dumps(config))

    def call(self, operation='hook', event=None):
        return subprocess.run([sys.executable, str(SCRIPT), operation, '--config', str(self.config)],
                              input=json.dumps(event or self.event), text=True, stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, timeout=8)

    def report(self, session='session-a'):
        return json.loads((self.state / (session + '.json')).read_text())

    def test_failure_blocks_once_and_repair_is_validated(self):
        first = self.call()
        self.assertEqual(first.returncode, 0, first.stderr)
        self.assertEqual(json.loads(first.stdout)['decision'], 'block')
        self.assertIn('acceptance defect', json.loads(first.stdout)['reason'])
        self.assertEqual(self.report()['repairs_requested'], 1)
        (self.root / 'fixed').touch()
        second = self.call(event=self.event | {'stop_hook_active': True})
        self.assertEqual(second.returncode, 0, second.stderr)
        self.assertNotIn('decision', json.loads(second.stdout))
        self.assertEqual(self.report()['status'], 'passed')
        self.assertEqual(self.call('final').returncode, 0)

    def test_exhausted_repairs_do_not_become_success(self):
        self.call()
        again = self.call(event=self.event | {'stop_hook_active': True})
        self.assertEqual(again.returncode, 0, again.stderr)
        self.assertNotIn('decision', json.loads(again.stdout))
        self.assertEqual(self.report()['status'], 'failed')
        self.assertEqual(self.report()['repairs_requested'], 1)
        final = self.call('final')
        self.assertEqual(final.returncode, 1)
        self.assertFalse(json.loads(final.stdout)['pass'])

    def test_final_check_does_not_reuse_stale_success(self):
        for operation in ['hook', 'final']:
            with self.subTest(operation=operation):
                (self.root / 'fixed').touch()
                self.assertEqual(self.call().returncode, 0)
                (self.root / 'fixed').unlink()
                result = self.call(operation)
                if operation == 'hook':
                    self.assertEqual(json.loads(result.stdout)['decision'], 'block')
                    self.assertEqual(self.report()['status'], 'repair_required')
                else:
                    self.assertEqual(result.returncode, 1)
                    self.assertFalse(self.report()['pass'])

    def test_every_configured_check_must_pass(self):
        self.write_config([sys.executable, '-c', 'raise SystemExit(0)'],
                          commands=[[sys.executable, '-c', 'raise SystemExit(0)'],
                                    [sys.executable, '-c', "print('second check failed'); raise SystemExit(1)"]])
        result = self.call('final')
        self.assertEqual(result.returncode, 1)
        self.assertEqual(self.report()['failed_check'], 1)
        self.assertIn('second check failed', self.report()['output_tail'])

    def test_unavailable_command_is_an_error_and_never_a_pass(self):
        self.write_config(['/does/not/exist'])
        result = self.call('final')
        self.assertEqual(result.returncode, 2)
        self.assertEqual(self.report()['status'], 'error')
        self.assertFalse(json.loads(result.stdout)['pass'])

    def test_timeout_kills_the_check_process_group(self):
        marker = self.root / 'escaped-child'
        child = "import time; from pathlib import Path; time.sleep(1); Path(" + repr(str(marker)) + ").touch()"
        parent = 'import subprocess,sys,time; subprocess.Popen([sys.executable,"-c",' + repr(child) + ']); time.sleep(10)'
        self.write_config([sys.executable, '-c', parent], timeout_seconds=0.15)
        result = self.call('final')
        self.assertEqual(result.returncode, 2)
        self.assertEqual(self.report()['status'], 'error')
        self.assertTrue(self.report()['timed_out'])
        time.sleep(1.1)
        self.assertFalse(marker.exists())

    def test_sessions_do_not_share_the_repair_counter(self):
        self.call()
        other = self.call(event=self.event | {'session_id': 'session-b'})
        self.assertEqual(json.loads(other.stdout)['decision'], 'block')
        self.assertEqual(self.report('session-b')['repairs_requested'], 1)

    def test_wrong_workspace_is_rejected(self):
        (self.root / 'fixed').touch()
        result = self.call('final', self.event | {'cwd': str(self.root / 'other')})
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('workspace', result.stderr)

    def test_nested_cwd_validates_at_configured_root(self):
        nested = self.root / "crate"
        nested.mkdir()
        self.event["cwd"] = str(nested)
        (self.root / "fixed").touch()
        result = self.call("hook")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), {})
        self.assertTrue(self.report()["pass"])

    def test_nested_cwd_failure_blocks_and_retains_one_repair_limit(self):
        nested = self.root / "crate"
        nested.mkdir()
        self.event["cwd"] = str(nested)
        first = self.call("hook")
        self.assertEqual(first.returncode, 0, first.stderr)
        self.assertEqual(json.loads(first.stdout)["decision"], "block")
        self.assertEqual(self.report()["repairs_requested"], 1)
        second = self.call("hook")
        self.assertEqual(second.returncode, 0, second.stderr)
        self.assertEqual(json.loads(second.stdout), {})
        self.assertFalse(self.report()["pass"])
        self.assertEqual(self.report()["repairs_requested"], 1)

    def test_existing_outside_workspace_is_rejected(self):
        (self.root / "fixed").touch()
        with tempfile.TemporaryDirectory() as outside:
            result = self.call("hook", self.event | {"cwd": outside})
        self.assertEqual(result.returncode, 1)
        self.assertIn("workspace", result.stderr)
        self.assertFalse(self.state.exists())

    def test_symlink_escape_is_rejected(self):
        (self.root / "fixed").touch()
        with tempfile.TemporaryDirectory() as outside:
            alias = self.root / "escape"
            alias.symlink_to(outside, target_is_directory=True)
            result = self.call("hook", self.event | {"cwd": str(alias)})
        self.assertEqual(result.returncode, 1)
        self.assertIn("workspace", result.stderr)
        self.assertFalse(self.state.exists())

    def test_empty_checks_and_invalid_limits_cannot_vacuously_pass(self):
        for changes in [{'commands': []}, {'timeout_seconds': 0}, {'timeout_seconds': float('nan')},
                        {'max_repairs': True}, {'max_repairs': -1}, {'max_repairs': 20}]:
            with self.subTest(changes=changes):
                self.write_config([sys.executable, '-c', 'raise SystemExit(0)'], **changes)
                self.assertNotEqual(self.call('final').returncode, 0)

    def test_corrupted_state_is_not_reset_to_grant_more_repairs(self):
        self.state.mkdir()
        (self.state / 'session-a.json').write_text('not json')
        result = self.call()
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual((self.state / 'session-a.json').read_text(), 'not json')

    def test_session_path_and_symlink_cannot_clobber_another_file(self):
        target = self.root / 'host-file'
        original = json.dumps({'session_id': 'session-a', 'repairs_requested': 0, 'events': []})
        target.write_text(original)
        self.state.mkdir()
        (self.state / 'session-a.json').symlink_to(target)
        self.assertNotEqual(self.call().returncode, 0)
        self.assertEqual(target.read_text(), original)
        self.assertNotEqual(self.call(event=self.event | {'session_id': '../host-file'}).returncode, 0)
        self.assertEqual(target.read_text(), original)

    def test_persisted_session_and_count_are_not_trusted(self):
        self.state.mkdir()
        for change in [{'session_id': 'other'}, {'repairs_requested': -1},
                       {'repairs_requested': 4}, {'repairs_requested': True}]:
            with self.subTest(change=change):
                state = {'session_id': 'session-a', 'repairs_requested': 0, 'events': []} | change
                (self.state / 'session-a.json').write_text(json.dumps(state))
                self.assertNotEqual(self.call().returncode, 0)
                self.assertEqual(self.report(), state)
