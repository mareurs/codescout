# Producer-status contract

A frozen public-surface validator for the historical RunCommand producer-status task. It executes 38 deterministic scenarios inside one Rust test. It does not call a model.

## Use

In a disposable Codescout snapshot, copy [contract.rs](contract.rs) to tests/producer_status_contract.rs and [cases.json](cases.json) to tests/producer_cases.json. Preserve the complete command log and its actual exit code:

```sh
./scripts/with-slot.sh cargo test --offline --test producer_status_contract -- --nocapture
./scripts/with-slot.sh cargo check --offline --all-targets
```

From this asset directory, verify the captured matrix log and run protocol-integrity checks:

```sh
python3 verify_producer.py --log "$MATRIX_LOG" --exit-code "$MATRIX_EXIT"
python3 -m unittest discover -s . -p test_verify_producer.py
```

Verifier exit 0 means a complete passing matrix; 1 means complete, scorable behavioral failures; 2 means invalid/unscorable output. Compiler failures and truncated, duplicate or inconsistent result populations never become passing grades. Compile checks are a separate gate.

## Contract and observations

Ordinary captured producers report their own status in producer_exit_code. The pipeline keeps its existing exit_code, including the host's active pipefail behavior. Explicit success is zero. Compound producers keep their existing capture without invented status; plain commands have no producer field. A multiline/comment spelling already uncaptured by the base is an unchanged-execution/no-capture control.

Each fixture independently executes its producer script in the native shell, verifies its status and streams, and resets the witness effects before invoking RunCommand.call. The observed call must execute once, preserve cwd and command-prefix effects, return the expected stdout/stderr and expose the actual prefilter bytes through OutputBuffer. Large response cases require the status to survive Generic/Test/Build summarization. Fixture executables named cargo emit controlled bytes; they do not run nested Cargo builds.

The matrix contains 24 crossed producer-status/filter/prefix cases and 14 additional cases for chains, quoted Unicode, three summary modes, plain and four compound forms, empty stdout, the unchanged multiline spelling and two active pipefail cases. These are scenario outcomes, not independent reliability samples.

The Python verifier independently reconstructs the ordered manifest and expected status policy, recomputes every case result, and requires consistent summaries, the named Rust test result, footer and actual process exit. The harness and verifier must remain trusted and unchanged during candidate execution.

## Scope

This covers the declared controlled Unix shell forms and public API observations. It does not cover every shell grammar, all failure modes, races, all filesystem effects, malicious forged output or every repository regression. The reference control includes the original change's required private unit-test API migration; candidates start from the original base and may migrate their own helpers. Protected external checks are identical.

Calibration, applied mutation results and prospective pilot outcomes: [research report](../../../docs/research/2026-10-28-fresh-producer-status-pilot.md). The [plan](../../../docs/superpowers/plans/2026-10-28-fresh-producer-status-pilot.md) records the fixed decision and spending limits.
