"""Synthetic protocol corruption controls, not model-task measurements."""
import copy
import json
import pathlib
import tempfile
import unittest
from verify_producer import InvalidRun, load_cases, verify
ROOT=pathlib.Path(__file__).parent

class ProducerProtocolTests(unittest.TestCase):
    def setUp(self):
        self.cases=load_cases(ROOT/"cases.json")
        self.rows=[dict(case_id=c["case_id"],producer_exit_code=c["expected_producer_status"],
                        exit_code=c["expected_exit"],stdout_ok=True,stderr_ok=True,
                        capture_ok=True,side_effect_ok=True,cwd_ok=True,summary_ok=True,error=None)
                   for c in self.cases]

    def log(self,rows=None,failed=0):
        rows=self.rows if rows is None else rows
        lines=["PRODUCER_CASE "+json.dumps(r) for r in rows]
        lines.append("PRODUCER_SUMMARY "+json.dumps(dict(scenarios=38,passed=38-failed,failed=failed)))
        state="FAILED" if failed else "ok"
        lines.append("test producer_status_contract ... "+state)
        lines.append(f"test result: {state}. {0 if failed else 1} passed; {1 if failed else 0} failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.00s")
        return "\n".join(lines)

    def test_full_success(self):
        self.assertEqual(verify(self.cases,self.log(),0)["passed"],38)

    def test_missing_record_retained_green_footer(self):
        with self.assertRaises(InvalidRun):
            verify(self.cases,self.log(self.rows[:-1]),0)

    def test_duplicate_replaces_missing_record(self):
        with self.assertRaises(InvalidRun):
            verify(self.cases,self.log(self.rows[:-1]+[self.rows[0]]),0)

    def test_fabricated_success_summary(self):
        rows=copy.deepcopy(self.rows);rows[0]["capture_ok"]=False
        with self.assertRaises(InvalidRun):
            verify(self.cases,self.log(rows),0)

    def test_failed_effect_is_scored(self):
        rows=copy.deepcopy(self.rows);rows[0]["side_effect_ok"]=False
        result=verify(self.cases,self.log(rows,failed=1),101)
        self.assertEqual(result["failed_ids"],[rows[0]["case_id"]])

    def test_no_compile_records(self):
        with self.assertRaises(InvalidRun):
            verify(self.cases,"error: could not compile",101)

    def test_status_boolean_is_not_an_integer(self):
        rows=copy.deepcopy(self.rows);rows[0]["producer_exit_code"]=False
        with self.assertRaises(InvalidRun):
            verify(self.cases,self.log(rows),0)

    def test_duplicate_json_key(self):
        text=self.log().replace('"case_id":', '"case_id": "other", "case_id":',1)
        with self.assertRaises(InvalidRun):
            verify(self.cases,text,0)

    def test_missing_named_test_footer(self):
        text=self.log().replace("test producer_status_contract ... ok\n","")
        with self.assertRaises(InvalidRun):
            verify(self.cases,text,0)

    def test_altered_oracle_manifest(self):
        cases=copy.deepcopy(self.cases);cases[0]["expected_producer_status"]=99
        with tempfile.TemporaryDirectory() as directory:
            path=pathlib.Path(directory)/"cases.json"
            path.write_text(json.dumps(dict(schema_version=1,cases=cases)))
            with self.assertRaises(InvalidRun):
                load_cases(path)

    def test_duplicate_summary(self):
        text=self.log()+"\nPRODUCER_SUMMARY "+json.dumps(dict(scenarios=38,passed=38,failed=0))
        with self.assertRaises(InvalidRun):
            verify(self.cases,text,0)

if __name__=="__main__":
    unittest.main()
