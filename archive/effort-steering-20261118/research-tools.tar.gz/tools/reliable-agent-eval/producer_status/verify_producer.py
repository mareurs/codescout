"""Verify frozen producer-status case records."""
import json
import argparse
import pathlib
import re

FIELDS = ("stdout_ok", "stderr_ok", "capture_ok", "side_effect_ok", "cwd_ok", "summary_ok")

def expected_cases():
    def case(name, command, code, status, exit_code, **options):
        result = dict(case_id=name, command=command, producer_exit=code,
            expected_producer_status=status, expected_exit=exit_code,
            payload="small", filter="match", expect_capture=True, expect_summary=False,
            expected_type=None, cwd_work=False, prefix_once=False)
        result.update(options)
        return result
    prefixes = {
        "direct": "printf P >> prefix-count; sh ./producer.sh",
        "and": "printf P >> prefix-count && cd work && sh ../producer.sh",
        "or": "printf P >> prefix-count; false || sh ./producer.sh",
        "noclobber": "set -C; printf P >> prefix-count; sh ./producer.sh",
    }
    rows = []
    for prefix, command in prefixes.items():
        for code in (0,7,23):
            for mode in ("match","miss"):
                rows.append(case(f"{prefix}:{code}:{mode}", command+" | grep "+("keep" if mode=="match" else "absent"),
                    code, code, 0 if mode=="match" else 1,
                    cwd_work=prefix=="and", prefix_once=True, filter=mode))
    rows.append(case("chain","sh ./producer.sh | grep keep | head -1",19,19,0))
    rows.append(case("unicode","LABEL='é|x' sh ./producer.sh | grep keep",9,9,0))
    for kind, code in (("generic",17),("test",18),("build",19)):
        command="sh ./producer.sh | grep keep" if kind=="generic" else f"./cargo {kind} | grep keep"
        rows.append(case("summary_"+kind,command,code,code,0,
            payload="large", expect_summary=True, expected_type=kind))
    rows.append(case("plain","sh ./producer.sh",13,None,13,expect_capture=False,filter="plain"))
    for name, command in (
        ("subshell","(sh ./producer.sh)"),("brace","{ sh ./producer.sh; }"),
        ("conditional","if true; then sh ./producer.sh; fi"),
        ("loop","for n in 1; do sh ./producer.sh; done")):
        rows.append(case(name,command+" | grep keep",11,None,0))
    rows.append(case("empty","sh ./producer.sh | grep keep",9,9,1,
        payload="empty",filter="miss",expect_capture=False))
    rows.append(case("multiline","true\nsh ./producer.sh | grep keep # trailing comment",
        6,None,0,expect_capture=False))
    rows.append(case("pipefail_match","set -o pipefail; sh ./producer.sh | grep keep",7,7,7))
    rows.append(case("pipefail_miss","set -o pipefail; sh ./producer.sh | grep absent",
        23,23,1,filter="miss"))
    return rows

def _json(text):
    def unique(pairs):
        result={}
        for key,value in pairs:
            if key in result:
                raise InvalidRun("duplicate JSON key")
            result[key]=value
        return result
    try:
        return json.loads(text,object_pairs_hook=unique)
    except (ValueError,TypeError) as exc:
        raise InvalidRun(str(exc)) from exc

def _validate_cases(cases):
    if json.dumps(cases,sort_keys=True) != json.dumps(expected_cases(),sort_keys=True):
        raise InvalidRun("manifest differs from declared 38-case contract")

class InvalidRun(ValueError):
    pass

def load_cases(path):
    doc=_json(path.read_text())
    if not isinstance(doc,dict) or set(doc)!={"schema_version","cases"} or type(doc["schema_version"]) is not int or doc["schema_version"]!=1:
        raise InvalidRun("unsupported manifest")
    _validate_cases(doc["cases"])
    return doc["cases"]

def verify(cases, text, exit_code):
    _validate_cases(cases)
    if type(exit_code) is not int or exit_code not in (0,101):
        raise InvalidRun("unexpected process exit")
    rows=[]; summaries=[]
    for line in text.splitlines():
        if line.startswith("PRODUCER_CASE "):
            rows.append(_json(line.removeprefix("PRODUCER_CASE ")))
        elif line.startswith("PRODUCER_SUMMARY "):
            summaries.append(_json(line.removeprefix("PRODUCER_SUMMARY ")))
    if [r.get("case_id") if isinstance(r,dict) else None for r in rows] != [c["case_id"] for c in cases]:
        raise InvalidRun("incomplete, duplicate, reordered or unknown case population")
    keys={"case_id","producer_exit_code","exit_code","error",*FIELDS}
    failed=[]
    for case,row in zip(cases,rows):
        if set(row)!=keys:
            raise InvalidRun("unexpected record fields")
        if any(type(row[field]) is not bool for field in FIELDS):
            raise InvalidRun("nonboolean effect observation")
        for field in ("producer_exit_code","exit_code"):
            if row[field] is not None and type(row[field]) is not int:
                raise InvalidRun("invalid status type")
        if row["error"] is not None and type(row["error"]) is not str:
            raise InvalidRun("invalid error type")
        passed=(row["producer_exit_code"]==case["expected_producer_status"]
            and row["exit_code"]==case["expected_exit"] and row["error"] is None
            and all(row[field] for field in FIELDS))
        if not passed:
            failed.append(case["case_id"])
    summary=dict(scenarios=len(cases),passed=len(cases)-len(failed),failed=len(failed))
    if len(summaries)!=1 or json.dumps(summaries[0],sort_keys=True)!=json.dumps(summary,sort_keys=True):
        raise InvalidRun("summary inconsistent with observed cases")
    state="FAILED" if failed else "ok"
    footers=re.findall(r"^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in [^\n]+$",text,re.MULTILINE)
    want=(state,"0" if failed else "1","1" if failed else "0","0","0","0")
    if footers!=[want] or exit_code!=(101 if failed else 0):
        raise InvalidRun("test footer/exit inconsistent with cases")
    if re.findall(r"^test producer_status_contract \.\.\. (ok|FAILED)$",text,re.MULTILINE)!=[state]:
        raise InvalidRun("named Rust test result missing or inconsistent")
    return dict(summary,failed_ids=failed,rust_tests=1)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cases",type=pathlib.Path,default=pathlib.Path(__file__).with_name("cases.json"))
    parser.add_argument("--log",type=pathlib.Path,required=True)
    parser.add_argument("--exit-code",type=int,required=True)
    args=parser.parse_args()
    try:
        result=verify(load_cases(args.cases),args.log.read_text(),args.exit_code)
    except InvalidRun as exc:
        print(json.dumps(dict(status="invalid",reason=str(exc))))
        return 2
    print(json.dumps(dict(status="valid",**result),indent=2))
    return 1 if result["failed"] else 0

if __name__=="__main__":
    raise SystemExit(main())
