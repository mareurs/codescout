//! Public-surface checks; copy beside producer_cases.json in a disposable tests/ directory.
#![cfg(unix)]
use codescout::agent::Agent;
use codescout::lsp::LspManager;
use codescout::tools::run_command::RunCommand;
use codescout::tools::{Tool, ToolContext};
use serde::Deserialize;
use serde_json::{json, Value};
use std::collections::BTreeSet;
use std::os::unix::fs::PermissionsExt;
use std::path::Path;
use std::sync::{Arc, Mutex};

#[derive(Deserialize)]
struct Case {
    case_id: String,
    command: String,
    producer_exit: i32,
    expected_producer_status: Option<i64>,
    expected_exit: i64,
    payload: String,
    filter: String,
    expect_capture: bool,
    expect_summary: bool,
    expected_type: Option<String>,
    cwd_work: bool,
    prefix_once: bool,
}

fn payload(case: &Case) -> String {
    match case.payload.as_str() {
        "small" => "keep|line\nother\n".into(),
        "large" => format!("keep{}\nother\n", "x".repeat(16000)),
        "empty" => String::new(),
        _ => panic!("unknown payload"),
    }
}

fn expected_stdout(case: &Case, bytes: &str) -> String {
    match case.filter.as_str() {
        "match" => bytes
            .lines()
            .next()
            .map(|line| format!("{line}\n"))
            .unwrap_or_default(),
        "miss" => String::new(),
        "plain" => bytes.to_string(),
        _ => panic!("unknown filter"),
    }
}

fn file_bytes(path: &Path) -> Option<Vec<u8>> {
    std::fs::read(path).ok()
}

async fn observe(case: &Case) -> Value {
    let temp = tempfile::tempdir().unwrap();
    let root = temp.path();
    std::fs::create_dir(root.join(".codescout")).unwrap();
    std::fs::create_dir(root.join("work")).unwrap();
    let bytes = payload(case);
    std::fs::write(root.join("payload.dat"), &bytes).unwrap();
    let script = format!(
        "#!/bin/sh\nprintf x >> '{}/marker-count'\npwd > '{}/observed-cwd'\ncat '{}/payload.dat'\nprintf 'diag\\n' >&2\nexit {}\n",
        root.display(), root.display(), root.display(), case.producer_exit
    );
    std::fs::write(root.join("producer.sh"), &script).unwrap();
    std::fs::write(root.join("cargo"), &script).unwrap();
    std::fs::set_permissions(root.join("cargo"), std::fs::Permissions::from_mode(0o755)).unwrap();
    // An independent shell execution establishes that the fixture really produces these bytes/status.
    let witness = std::process::Command::new("sh")
        .arg("./producer.sh")
        .current_dir(root)
        .output()
        .unwrap();
    assert_eq!(witness.status.code(), Some(case.producer_exit));
    assert_eq!(witness.stdout, bytes.as_bytes());
    assert_eq!(witness.stderr, b"diag\n");
    assert_eq!(file_bytes(&root.join("marker-count")), Some(b"x".to_vec()));
    std::fs::remove_file(root.join("marker-count")).unwrap();
    std::fs::remove_file(root.join("observed-cwd")).unwrap();
    let agent = Agent::new(Some(root.to_path_buf())).await.unwrap();
    agent
        .add_session_write_root_for(None, root.to_path_buf())
        .await;
    let ctx = ToolContext {
        agent,
        lsp: LspManager::new_arc(),
        output_buffer: Arc::new(codescout::tools::output_buffer::OutputBuffer::new(20)),
        progress: None,
        peer: None,
        section_coverage: Arc::new(Mutex::new(
            codescout::tools::section_coverage::SectionCoverage::new(),
        )),
        guide_hints_emitted: Arc::new(parking_lot::Mutex::new(Default::default())),
        workspace_override: Some(root.to_path_buf()),
    };
    let result = RunCommand.call(json!({
        "command": case.command, "effect": "write", "acknowledge_risk": true, "timeout_secs": 10
    }), &ctx).await;
    let expected = expected_stdout(case, &bytes);
    let expected_cwd = if case.cwd_work {
        root.join("work")
    } else {
        root.to_path_buf()
    };
    let cwd_ok = std::fs::read_to_string(root.join("observed-cwd")).ok()
        == Some(format!("{}\n", expected_cwd.display()));
    let side_effect_ok = file_bytes(&root.join("marker-count")) == Some(b"x".to_vec())
        && file_bytes(&root.join("prefix-count")) == case.prefix_once.then(|| b"P".to_vec());
    match result {
        Err(error) => json!({
            "case_id": case.case_id, "producer_exit_code": null, "exit_code": null,
            "stdout_ok": false, "stderr_ok": false, "capture_ok": false,
            "side_effect_ok": side_effect_ok, "cwd_ok": cwd_ok, "summary_ok": false,
            "error": error.to_string()
        }),
        Ok(value) => {
            let output_id = value.get("output_id").and_then(Value::as_str);
            let buffered = output_id.and_then(|id| ctx.output_buffer.get(id));
            let stdout = buffered
                .as_ref()
                .map(|entry| entry.stdout.as_str())
                .or_else(|| value.get("stdout").and_then(Value::as_str))
                .unwrap_or("");
            let stderr = buffered
                .as_ref()
                .map(|entry| entry.stderr.as_str())
                .or_else(|| value.get("stderr").and_then(Value::as_str))
                .unwrap_or("");
            let capture = value.get("unfiltered_output").and_then(Value::as_str);
            let capture_ok = if case.expect_capture {
                capture
                    .and_then(|id| ctx.output_buffer.get(id))
                    .is_some_and(|entry| entry.stdout == bytes)
            } else {
                capture.is_none()
            };
            let summary_ok = if case.expect_summary {
                output_id.is_some()
                    && value.get("type").and_then(Value::as_str) == case.expected_type.as_deref()
            } else {
                output_id.is_none()
            };
            json!({
                "case_id": case.case_id,
                "producer_exit_code": value.get("producer_exit_code"),
                "exit_code": value.get("exit_code"),
                "stdout_ok": stdout == expected, "stderr_ok": stderr == "diag\n",
                "capture_ok": capture_ok, "side_effect_ok": side_effect_ok,
                "cwd_ok": cwd_ok, "summary_ok": summary_ok, "error": null
            })
        }
    }
}

fn passed(case: &Case, row: &Value) -> bool {
    row["producer_exit_code"] == json!(case.expected_producer_status)
        && row["exit_code"] == json!(case.expected_exit)
        && row["error"].is_null()
        && [
            "stdout_ok",
            "stderr_ok",
            "capture_ok",
            "side_effect_ok",
            "cwd_ok",
            "summary_ok",
        ]
        .iter()
        .all(|field| row[field].as_bool() == Some(true))
}

#[tokio::test]
async fn producer_status_contract() {
    let manifest: Value = serde_json::from_str(include_str!("producer_cases.json")).unwrap();
    let cases: Vec<Case> = serde_json::from_value(manifest["cases"].clone()).unwrap();
    assert_eq!(cases.len(), 38);
    assert_eq!(
        cases
            .iter()
            .map(|case| &case.case_id)
            .collect::<BTreeSet<_>>()
            .len(),
        38
    );
    let mut failed = Vec::new();
    for case in &cases {
        let row = observe(case).await;
        if !passed(case, &row) {
            failed.push(case.case_id.clone());
        }
        println!("PRODUCER_CASE {row}");
    }
    println!(
        "PRODUCER_SUMMARY {}",
        json!({"scenarios": cases.len(), "failed": failed.len(), "passed": cases.len()-failed.len()})
    );
    assert!(failed.is_empty(), "contract failures: {failed:?}");
}
