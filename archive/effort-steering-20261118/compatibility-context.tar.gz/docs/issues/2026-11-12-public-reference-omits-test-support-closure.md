---
id: '5994a7a432e63a20'
kind: bug
status: mitigated
title: Implementation-only reference omits benchmark test-support files required by public all-targets compilation
tags:
- cluster/unclassified
- effort-steering
- evaluation
closed: 2026-11-12
no_fix_commit: Corrected constructor/mandatory-reader source is isolated WIP; publication withheld and exact source capsules preserve it. Uniform controlled references/receipts have independent closure; parent gate/review remain open.
opened: 2026-11-12
owner: marius
severity: medium
unverified: All4complete-reference sources and16public command receipts independently pass. Parent full gate/strongest applied review and exact actor qualification remain open; the fix is uncommitted WIP.
---

# BUG: Public reference and benchmark test-support input closure differ

## Summary

Ironclaw baseline ordinary/broader public checks pass, and implementation-only reference ordinary passes, but reference broader is a valid compiler failure(E0583): crates/ironclaw_memory/src/test_support.rs is absent. The original benchmark test_patch supplies that support file; actual private grading installs canonical tests/support and both reference controls pass590selected labels. These statements concern different input closures.

## Class fit

This is unclassified experiment reference construction, not candidate failure or infrastructure invalidity. It differs from missing runtime tools because the compiler correctly reports an absent source module in the reference. Adding private assertion data to the actor would change the experiment and is not the remedy being assumed.

## Symptom (Effect)

final-public-reference-v1 ordinary exits0; broader completes with resource_valid true and exit101. Its raw stderr reports E0583 at crates/ironclaw_memory/src/lib.rs:22 and suggests creating the module file. The broader public baseline exits0. Pure implementation reference and original actor inputs stay immutable; no result is relabeled.

## Root cause

The current public reference is public baseline plus record.patch only. The benchmark splits implementation and official test/support inputs into patch and test_patch. Private evaluation supplies test_patch; public reference qualification does not. Read the module declaration and canonical support file before attributing the entire failure or selecting a policy correction.

## Evidence

final-public-reference-v1/broader contains actual owned execution registration, complete raw streams and exit101receipt. Ironclaw private-v4 independent audit shows reference/repeat590/590selectedpass under canonical test/support restoration. No actor/model attempt has run on this cohort.

## Fix

Use a separate private fixture-complete reference for every task: original public baseline plus the entire unchanged original implementation and test/support patches. The actor baseline stays unchanged; both public commands stay unchanged. The [reference closure plan](../trackers/effort-steering/plans/2026-11-12-reference-input-closure.md) implements a versioned constructor plus mandatory prospective reader. The reader replays both patches independently, verifies canonical protected inputs, and refuses any reference/actor source overlap before credential authorization. Historical implementation-only and support-only failures remain intact.

## Tests added

Eight constructor tests cover full original patch composition, unchanged source/records, role/patch/archive drift, alias/overlap refusal, production bytes, empty-directory modes, internal links and official fixture deletion. A replay-equality mutant actually survived the initial test, then failed all three new production/mode/untracked subcases. Two new consuming-admission tests plus seven updated public-control tests pass; the paid authority constructor refuses wrong actor role, omitted closure and broader exit101 before credentials. Full protocol:615tests OK,68explicit runtime skips; existing HTTP ResourceWarnings retained.

## Resume

Support-only diagnostic is terminal/resource-valid/exit101, not admissible. The first E0583is resolved, but compilation then reports E0407(retrieve_context no longer in MemoryService) and E0061(missing MemoryDescriptor argument) in original public crates/ironclaw_host_runtime/tests/memory_prompt_context.rs. That file is also updated by the original test_patch. Thus the single support file is not sufficient; do not infer otherwise or keep adding guessed stubs.

A distinct v2private diagnostic composes the unchanged implementation-only reference with the complete original official test/support patch, as private evaluation does. It retains original failed controls, guards original actor/pure-reference hashes, runs the same broader command/profile, and stays explicitly admissible_for_paid false. No assertions enter actor inputs or prompts. Its result will inform an explicit reference/input-closure policy decision; it does not itself amend eligibility or authorize paid work.


Terminal full-fixture diagnostic: complete=true, resource_valid=true, exit0. The support-only101 and pure-reference101 are retained. New uniform constructor succeeded for all four tasks and independently checked212/1018/706/553canonical entries, respectively. Real baseline/reference × ordinary/broader controls now run under readonly producers at fixture-complete-controls-v1; they do not admit paid work until all receipts, roles and cleanup independently qualify. No actor/model call, no assertion exposure to actor source/context.


All4uniform complete references now pass both exact public scopes, alongside unchanged original actor baselines(16commands total). Auditor19c is terminal0 and independently consumes the current mandatory reader, exact canonical entry counts212/1018/706/553,82source-binding files and16distinct freshly absent containers. Evidence: docs/trackers/effort-steering/evidence/native-feedback-preparation-20261112/fixture-complete-controls-v1-audit.json. New rule is implemented in WIP with regression tests and source custody; parent gate/review remain open. Earlier101diagnostics are retained.
