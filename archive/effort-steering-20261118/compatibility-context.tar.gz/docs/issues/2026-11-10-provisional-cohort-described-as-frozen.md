---
id: '7505ec3b5deec0b5'
kind: bug
status: investigating
title: Evaluator handoff calls provisional projects a frozen two-task cohort
tags:
- cluster/unclassified
- effort-steering
- evaluation
opened: 2026-11-10
---

# BUG: Handoff overstates task cohort freeze

## Summary

The latest evaluator handoff says to qualify the already frozen two-task cohort, but the actual provisional-selection-v1.json contains selected:[] and earlier pending candidates. The selection rule/universe/seed is frozen; final task identities have not been selected. Lean and Obscura have prepared public corpora, not final selection authority.

## Class fit

Unclassified: preparation and a frozen selection rule were treated as final cohort admission.

## Evidence

Fresh reads of evidence-cohort-20261110/provisional-selection-v1.json and qualification-status-v1.json show Lean pending, then DataFusion21121 and delta-rs4358 pending before Obscura421. campaign.selection_report explicitly blocks later selection while earlier qualification is pending. The declared rule allows only public source/runtime/adapter eligibility, not actor outcomes/private test counts.

## Public-only correction checkpoint — 2026-11-10

The production cargo-v1 validator accepts the otherwise-valid inspection and refuses the added /testbed/mnt_tmp volume for both earlier candidates. Actual registry configurations for DataFusion21121 and delta-rs4358 declare that volume. Metadata-only refusal is now recorded in a new public-selection-v3 receipt and status map under the grader tree's .superpowers/sdd/2026-11-10-grader-stream-capture. Original v1 files are hash-checked unchanged. The first v2 helper was refused because it sent the auxiliary public evidence field into the strict selector; the corrected helper explicitly projects eligible/reason and retains the failed helper/inputs.

The regenerated selection still contains selected:[] and complete:false: Lean and Obscura remain publicly unqualified. No private records or outcomes were read. Canonical README, stream report, cohort handoff and local ledger now distinguish frozen rules from provisional task identities. Final cohort qualification remains open.

A proposed 900-second public Lean request through the observation executor was refused as unsupported_timeout before any container was created (the production bound is300). It is retained separately. A standalone public runtime control, using the same cargo-v1 resource validator and literal original command, has its own900-second registration; it does not alter or masquerade as a protocol observation receipt.

## Root cause

The resumable handoff carried the convenient prepared pair forward without re-reading the final selection state. No private model outcome or candidate grade was started in this continuation.

## Fix

Canonical handoff/index/ledger wording was corrected before private controls. Final public-only eligibility and cohort freeze now exist in docs/trackers/effort-steering/evidence/public-cohort-20261110/registration.json: selector complete:true, selected Lean1168/Obscura421 in the original order, public failures retained. Original v1 remains unchanged and preserved. No private/model outcome was read. The local freeze helper checks actual selector completion, but the live campaign/private-oracle admission guard is not wired yet, so recurrence prevention remains open.

## Resume

Use the new actual public-cohort registration, not the original provisional result or a handoff's named pair. Bind and enforce selection_complete plus exact identities before any private oracle/model launch in the missing campaign controller. F-10 useful-observation budget remains a separate open admission issue.
