---
id: '9e4d2a12f64644cc'
kind: bug
status: taken
title: External Lean public OCLA replay fails a ledger-isolation assertion
tags:
- effort-steering
- external-evaluation
- cluster/unclassified
topic: effort-steering
claimed_at: 2026-11-11
claimed_by: 01a15ca9-f939-7603-acb5-01c6b02f68e2
opened: 2026-11-11
owner: marius
severity: medium
unverified: Candidate nondeterminism reproduced on a fixed3default/2serial matrix:1default failure,2default passes,2serial passes. Baseline3default/2serial all pass. Existing noncooperating optimizer-writer path is source-confirmed; exact baseline failure/root-cause intervention not reproduced, so no baseline-regression exclusion or permanent fix claim.
---

# BUG: External Lean public OCLA replay fails a ledger-isolation assertion

## Summary

A real public challenge replay on the frozen Lean P candidate exits101:222OCLA-filtered lib tests pass and1fails, delegates_to_verified_ledger in core::ocla::builtin::savings_ledger. This is an observed external-task test failure; candidate-regression versus baseline/environment/test-order behavior is not yet established.

## Class fit

Unclassified external experimental test-validity issue. The controlled public replay has a concrete assertion failure and differs from the actor's all-pass declaration. It is not a private-grade/parser failure or a confirmed resource failure, and no root cause is inferred from the test's name alone.

## Symptom (Effect)

Raw stdout: expected last ledger event tool ocla_savings, observed proxy_response_optimizer, at src/core/ocla/builtin/savings_ledger.rs:190. Summary222passed/1failed/8386filteredout. Actual receipt says resource_validtrue, source before/after equal48f6c2ec89e34e80b4570244f44a32dd37c0dd80de29154ce4935b7a9cdc4f54, OOMKilledfalse, capture/cleanuptrue. Common public cargo check passed.

## Reproduction

Existing exact replay: /var/tmp/ep11-01a15/paid-campaign-headroom-v3/attempts/02-P/challenge/protocol/commands/challenge--lib-ocla. Command cargo test --offline --manifest-path rust/Cargo.toml --lib ocla. Raw stdout/stderr and receipt are retained. Do not edit the frozen candidate or rerun the paid controller.

## Environment

External task yvgude__lean-ctx-1168, candidate48f6c2ec, immutable native image b72f902d24c0a54516e4ef242d8218805f0ea3dc1d26ac809140979ba1f51d56. Public replay profile cargo-v2 has4CPU/8GiB, networknone, source/runtime hashes and cgroup evidence. This public-probe profile is distinct from the native actor owner's32GiB limit. No memory attribution follows; this was an ordinary assertion failure.

## Root cause
**Actor-claim provenance checked:** Its native stream contains a real mcp__codescout__run_command call for cargo test --lib ocla piped to tail15. The model-visible result has exit_code0, producer_exit_code0, and summary223passed/0failed/8386filteredout. Its7-pass integration claim is also supported by a real tool result. The all-pass statement was supported by that prior execution; the later isolated replay differs. Do not call this a fabricated test result. Native actor and isolated public-probe execution profiles differ, so identical execution conditions have not been established.


Unconfirmed runtime attribution. Source readback finds the ledger test holds test_env_lock while temporarily redirecting process-global data-dir environment, and three builtin response-optimizer tests call the proxy measurement path without acquiring that lock. The measurement path obtains its ledger path from the same process-global configuration. This permits cross-test contamination in principle; it does not yet identify the writer in the recorded failed execution. The ledger test file is byte-identical in baseline and P candidate(SHA25625647e01c120d763dd3a4369064bc75b3a7908d6730e6a05dc6d718e98ea38b8). Actual CLI provenance is already verified above; no fabrication claim.

## Fix

No source correction. Preserve public evidence first, finish the frozen actor batch, then compare exact baseline/candidate public replays if still needed. No private outcome, paid retry, current prompt change or silent grade edit.

## Tests added

None. Existing actual public replay provides the failure; a new test before causal classification would risk pinning the wrong mechanism.

## Resume

**Independent closure completed:** bg7cexit0 reparses all10actual stdout logs with the qualified frozen parser, exact status-count/name agreement. Audit SHA256b31008d066d87b0d1cdc869cf366baa11118eace8588b45211aff0d7ab5ba1eb. Capsule docs/trackers/effort-steering/evidence/public-ledger-diagnosis-20261111/evidence.tar.gz:29137865bytes,SHA25621eb2a0a69fd1b199f994425c7140201c8bc9cee6905b3f2574a9a8c4150e5f6, all6072selected entries reopened and unchanged at closure; independent GNU digest agrees. Source snapshots, commands, all inner outcomes, runtime evidence and helpers retained; compiler caches untouched. Report: docs/trackers/effort-steering/reports/2026-11-11-public-ledger-diagnosis.md. Baseline causal attribution and a permanent source fix remain unclaimed.

**Fixed matrix completed(bg77exit0):** Baseline3/3default and2/2serial suites pass(222tests). Candidate default outcomes in registered order:1fail,2pass; the failure is the same ledger assertion, observed proxy_response_optimizer versus expected ocla_savings, with222pass/1fail. Candidate2/2serial suites pass223tests. All10process results and raw logs exist; no retries were added. Both Docker observations close with exit0 for the diagnostic harness, resource_valid/complete true and cleanup verified; this outer success does not erase the one inner test-process exit101. Original frozen sources/inputs remain unchanged. This establishes candidate nondeterminism under the measured setup; it does not establish a baseline failure rate, prove the patch caused the race, or justify treating the original failing observation as success. Archive/read-only independent status reparse pending.

2026-11-11 after primary closure: all8private grades completed valid; registered version NO-GO. Started fixed public-only diagnostic bg77, output /var/tmp/ep11-01a15/public-ledger-diagnosis-v1. Each source(baseline and frozen P candidate) gets3default libtest and2serial processes in a preregistered interleaving, same immutable image/cargo-v2profile. Compilation is reused within each source container; actual commands/exit codes/full logs and source bindings are retained. No provider call, primary regrade, prompt tuning, source alteration or retry-to-success. Outcome pending; default thread count is not assumed.

2026-11-11: filed immediately after raw log inspection. P is already incomplete for the independent recorded reason final uncertainty cannot be marked complete. Do not attribute that protocol state to this failing probe. The frozen8-attempt batch continues; private outcomes remain unrevealed.
