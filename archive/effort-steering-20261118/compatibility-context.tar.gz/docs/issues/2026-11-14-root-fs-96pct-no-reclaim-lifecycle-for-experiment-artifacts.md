---
id: db0811b084ccb409
kind: bug
status: open
title: 'BUG: the root filesystem is 96% full again and no component owns the reclaim lifecycle of experiment artifacts (Docker images, resident caches, worktrees, gate pool, untracked evidence)'
tags:
- cluster/unclassified
- storage
- evaluation
- disk-full
opened: 2026-11-14
related:
- docs/issues/2026-11-06-experiment-caches-retained-by-home-snapshots.md
- docs/issues/archive/2026-09-24-mutation-probe-worktrees-are-never-reclaimed.md
- docs/issues/archive/2026-09-24-residual-detect-unregistered-worktree-dirs.md
severity: high
---

# BUG: the root filesystem is 96% full again and no component owns the reclaim lifecycle of experiment artifacts

## Summary

On 2026-11-14 the operator reported "out of disk space again". The root btrfs filesystem is 96% full, with 76.67 GiB free and 7.02 GiB unallocated. This is the second disk-pressure event in 8 days. The first one (2026-11-06) is recorded in the codescout memory `research/setup-ab-enospc-20261106`, and it poisoned a gate result.

The experiment pipeline creates large artifacts and records no manifest, no owner and no closed state for them. Because of that, nobody can say which artifacts are still needed. This report records the measurements so a later fix can start from facts. **Nothing was deleted or changed while the first pass of this report was written.** The operator said explicitly: do not remove anything. Later the same day the operator asked for more measurement and then authorised two actions (a milvus log fix and a 3-day Docker prune). Section "Second measurement pass and actions" records both, and it corrects one claim of the first pass (E1).

This file is a report, not a cleanup. Section "Do not touch" lists what a cleanup must respect.

## Class fit

A storage-lifecycle gap. Artifacts have creators (harness stages, the mutation probe, the gate, Docker builds) but no recorded owner, no retention class and no reclaim step. The sibling reports closed single leaks (per-session gate target dirs, mutation-probe worktrees, unregistered worktree dirs). This report shows the class again at larger scale. It also adds two measurement traps that made earlier cleanups look smaller than they were: nested btrfs subvolumes and reflinks.

## Symptom (Effect)

Measured 2026-11-14, between about 12:30 and 15:00 local time (+02:00), on Arch Linux, kernel 7.2.15-zen1, btrfs on `/dev/nvme0n1p2`.

`btrfs filesystem usage -h /`:

| Item | Value |
|---|---|
| Device size | 1.82 TiB |
| Device allocated | 1.81 TiB |
| Device unallocated | 7.02 GiB |
| Used | 1.73 TiB |
| Free (estimated) | 76.67 GiB (min 73.16 GiB) |
| Data, single | size 1.75 TiB, used 1.68 TiB (96.11%) |
| Metadata, DUP | size 32.51 GiB, used 24.03 GiB (73.92%), 65.02 GiB raw |
| System, DUP | 32 MiB |

History:

- 2026-11-06: disk full for about 1 minute (memory `research/setup-ab-enospc-20261106`). Free space was about 63 GB before and 71-78 GB after.
- 2026-11-08: the host incident record (system repo, entry 023) deleted 13 snapper snapshots and 11 atop log files (about 16 GB). Free space rose from 65 GB to about 155 GB. Snapshots are disabled now.
- 2026-11-14: 76.67 GiB free. That is about 78 GB consumed in 6 days, net. The operator also ran a Docker cleanup earlier on 2026-11-14, before the first measurement here. Its size is not recorded, so gross growth was larger.

Snapshots are gone: `btrfs subvolume list -s /` is empty. A deletion now frees space at once, except where extents are shared (see "Measurement traps").

## Measurement traps (read before trusting any number)

1. **`du -x` does not enter nested btrfs subvolumes.** The root filesystem has these nested subvolumes: `@home/marius/.cache/codescout-gate`, `@home/marius/work/claude/codescout/target`, `@home/marius/.cache/cc-tmp`, `@home/marius/.local/share/langfuse`, plus `var/lib/portables`, `var/lib/machines`, `swap`, and the empty `.snapshots` pair. `stat` shows `codescout/target` on `dev=66` and its parent on `dev=42`. My first scans used `du -x` and missed 96 GiB (`target`), about 121 GiB (gate pool), 114 GiB (langfuse) and 59 GiB (cc-tmp). Any cleanup script that sizes things with `du -x` has the same blind spot.
2. **`du` over-counts shared extents.** The `du` sums reached about 1.8 TB, but only 1.73 TiB is used. `btrfs filesystem du -s` separates `Exclusive` (freed if the path is deleted), `Set shared` (shared inside the measured set) and the rest (shared with paths outside it).
3. **Docker `docker images` sizes are apparent sizes.** Images share layers, so the sizes are not additive. The `disk_cleanup.py` figure "Unused images (37): 1.1 TB" has the same flaw. The real containerd footprint is 630G (see below).
4. **A reflink copy keeps extents alive.** Deleting one reference frees nothing while another reference exists. This is the same retention class as `docs/issues/2026-11-06-experiment-caches-retained-by-home-snapshots.md`, now through reflinks instead of snapshots.

`du -h` and `btrfs` print binary units (G = GiB).

## Evidence

### E1. An unrotated container log grows without limit (active right now)

Container `ie-milvus-sandbox` (image `milvusdb/milvus:v2.4.0`, up 3 days):

- Log file `/var/lib/docker/containers/aec4f350a556…/…-json.log` was 74,597,001,579 bytes at the first `ls` and 74,629,373,577 bytes at 12:56:19.
- Growth in a 10 s window (12:56:09.580 to 12:56:19.685): 3,436,794 bytes, about 340 KB/s, about 29 GB/day. Average since creation (2026-11-10T21:09:30Z to 2026-11-14T10:56Z, 308,809 s): about 242 KB/s, about 21 GB/day. One 10 s sample is a small window.
- Content: `[INFO]` lines from `datacoord/handler.go`, `datacoord/services.go` (`GetQueryVChanPositions`, `datacoord append channelInfo in GetRecoveryInfo`), many per second.
- `docker inspect` shows `HostConfig.LogConfig = {json-file map[]}`: no `max-size`. `/etc/docker/daemon.json` holds only the `nvidia` runtime, with no `log-opts`.
- Attribution: this container has **no compose project label** and no working-dir label. It was started with `docker run` (restart policy `no`). Who started it is **not established**. Do not assume it belongs to codescout.
- Two more large logs, same driver: `codescout-dense-amd` 6,195,850,609 bytes (compose project `codescout-retrieval`, working dir `/home/marius/work/claude/code-explorer`, created 2026-05-20) and `tor` 2,228,123,051 bytes (compose project `ai-infra`, `researcher/infra`, created 2026-07-05). I checked `LogConfig` only for `ie-milvus-sandbox`; the other two follow the same daemon default.
- `/var/lib/docker/containers` totals 81G, of which this one directory is 70G.

**Corrected in the second pass: this log is not the main cause.** The sizes above are logical bytes. The filesystem uses `compress=zstd:1`, and removing this 76.6 GB log freed only 5.83 GB of physical space. See P1 and P6.

### E2. Docker state (`docker system df`, 2026-11-14, after the operator's cleanup)

| Type | Total | Active | Size | Reclaimable |
|---|---|---|---|---|
| Images | 55 | 24 | 480.4 GB (apparent) | 149 GB |
| Containers | 31 | 26 | 889.9 MB | 0 B |
| Local Volumes | 246 | 20 | 105.4 GB | 35.6 GB (226 dangling) |
| Build Cache | 75 | 0 | 250.6 GB | 51.63 GB |

Real on-disk sizes (`du -xsh`): `/var/lib/containerd` **630G** (overlayfs snapshots 526G, content blobs 105G) and `/var/lib/docker` 163G (logs 81G, volumes 82G). Docker uses the containerd snapshotter (`Storage Driver: overlayfs`, `driver-type: io.containerd.snapshotter.v1`), so image layers are in `/var/lib/containerd`, not in `/var/lib/docker`. Largest volumes: `marius-fixes_phoenix_data` 24G, `buildx_buildkit_eduplanner-builder0_state` 9.4G, `codescout-retrieval_qdrant_storage` 5.3G, `avatar_hf-cache` 3.3G.

Experiment images: 27 tags on 21 image IDs match `*feedback*` (`ep-feedback-*`, `effort-feedback-*`). All were created on 2026-11-12 between 00:11 and 16:35 (+02:00). Largest apparent sizes: 123 GB (`77aecd5d793b`), 88 GB (`e8a3c129742b`), 57.6 GB (`bb989260a839`), 57.2 GB (`b7cfc6b2bddd`), 53.8 GB (`a31828e798ff`, `fe010055c558`), 39.4 GB (`08a11ce65408`), 38.3 GB (`5248bed949d8`).

**No container uses any of these images.** The images used by any container (running or stopped) are the 24 normal service images plus two IDs: `02108f5d322d` (`python:3.12-slim`, used by `effort-protocol-8780…` exited 3 days ago and `effort-protocol-33e3…` in state Created) and `1434a21ec501` (untagged, created 2026-11-07, used by `hfa-native-48062c6d…`, exited with code 1, 6 days ago). "Not used by a container" is not the same as "not needed": a later stage may rebuild from them as a cache.

### E3. `~/.cache/codescout-resident/codescout`

`btrfs filesystem du -s`: Total 310.88 GiB, Exclusive 259.36 GiB, Set shared 6.59 GiB. `du` says 316G.

| Directory | du | Last file write |
|---|---|---|
| `native-feedback-preparation-20261112` | 235G | within 3 days, not within 1 day |
| `evidence-cohort-20261110` | 29G | within 7 days, not within 3 days |
| `native-env-admission-20261104` | 8.6G | none within 7 days |
| `differential-oracle-20261107` | 4.1G | within 7 days, not within 3 days |
| `common-preparation-20261109` | 2.9G | within 7 days, not within 3 days |
| `complete-workflow-action-budget-20261105` | 2.6G | none within 7 days |
| `compile-mechanism-r2-20261029` | 2.5G | none within 7 days |
| `semantic-contract-runtime-20261106` | 2.4G | none within 7 days |
| `complete-workflow-cold-recovery-20261105` | 2.4G | none within 7 days |
| `independent-transfer-20261028` | 1.2G | none within 7 days |

Method: `find <dir> -type f -newermt "<now minus N days>" -print -quit`. It tests file mtimes only. The directory count was not measured; more directories exist below the ten listed (for example `semantic-contract-wire-20261106` 2.3G and `complete-workflow-calibration-20261105` 2.2G).

Inside `native-feedback-preparation-20261112` (235G): `nearai__ironclaw-6724` 81G, `DioxusLabs__dioxus-5384` 69G, `fixture-complete-controls-v1` 58G, `apache__arrow-rs-7783` 16G, `skim-rs__skim-1044` 13G. The four `native-feedback-qualification-v*-registration` directories are 0.8-1.7 MB each, and the `trusted-container-control-v*` directories are under 50 KB.

Process check: `ps -eo pid,etimes,user,args` filtered for `codescout-resident`, `native-feedback`, `effort-feedback`, `hce-data`, `s5-work`, `setup-ab`, `mutation-slot`, `buildx build`, `docker build` returned **no match**. This checks command lines only. A process whose working directory is inside a tree would not match.

### E4. Worktrees, targets and branches (codescout repo)

`btrfs filesystem du -s`:

| Path | du | Total | Exclusive | Set shared |
|---|---|---|---|---|
| `codescout/.worktrees` | 32G | 30.45 GiB | 28.99 GiB | 0.71 GiB |
| `codescout.worktrees` | 39G | 38.48 GiB | 21.95 GiB | 16.31 GiB |
| `~/.codex/worktrees` | 14G | 13.68 GiB | 13.26 GiB | 0.21 GiB |
| `codescout/target` (own subvolume) | not seen by `du -x` | 96.14 GiB | 95.16 GiB | 0.43 GiB |

- 32 directories sit under `codescout/.worktrees/` and `codescout.worktrees/`. `git worktree list` shows 39 entries, which include the main checkout and 6 trees under `~/.codex/worktrees` (13 directories exist there; the others may belong to other repos).
- `target/` inside first-level worktrees (`du`): 11 trees in `.worktrees` hold 20.6G (2.6, 2.5, 1.9 and eight of 1.7); `codescout.worktrees/mutation-slot-0` 17G and `mutation-slot-1` 5.4G; four trees under `~/.codex/worktrees` hold 1.2G, 2.0G, 2.8G and 0.5M. The nested `*.worktrees/mutation-slot-*` pools measured 160-464 MB each (nine measured). My first guess, that nested pools multiply the cost, was wrong.
- 13 worktrees have uncommitted changes to tracked files (`git status --porcelain -uno`): `.worktrees/atomic-write-door-20261114`, `ecc-bfs-final-mutations-20261110`, `ecc-bfs-integrated-20261110`, `ecc-bfs-review-20261110`, `ecc-callgraph-identity-review`, `ecc-create-finalization-review`, `ecc-observation-diagnostic-20261110`, `grader-stream-provenance-01a15ca9`; `codescout.worktrees/mutation-slot-0`, `mutation-slot-1`; and `~/.codex/worktrees/2aa6`, `add2`, `cf66`. Untracked files were not counted.
- `git for-each-ref refs/heads` lists 50 local branches. **47 have no upstream.** `experiments` is `[ahead 420]` of `origin/experiments`. `fix/windows-native-test-suite-bugs` has an upstream marked `[gone]`. Only `master` tracks a live remote branch without being ahead. The commits live in the main `.git`, so removing a worktree directory does not delete a branch, but it does delete uncommitted and untracked files.

### E5. 16 GiB of untracked, non-ignored evidence inside the tracked `docs/` tree

- `docs/trackers/effort-steering/evidence` is 16G (`du`). `btrfs filesystem du`: `codescout/docs` total 16.34 GiB, exclusive 209.68 MiB, set shared 16.14 GiB.
- Largest children: `persistent-native-admission-20261111` 6.6G, `headroom-admission-20261111` 4.7G, `closed-paid-pilot-20261111` 2.5G, `disk-runtime-checkpoint-20261111` 1.3G, `paid-budget-stop-20261111` 480M, `contract-resources-20261111` 288M, `shared-public-runtime-20261110` 244M.
- `git check-ignore -v docs/trackers/effort-steering` exits 1: the path is **not ignored**. `git ls-files` lists 163 tracked files under `effort-steering`. `git status --porcelain` lists 20 entries, one modified `README.md` and 19 untracked paths, including all of `evidence/`.
- Consequence not measured: a `git add -A` or `git add docs` would stage 16G.

### E6. `mutation-slot-0` holds a reflink copy of that evidence

- `codescout.worktrees/mutation-slot-0` is 33G: `target/` 17G and `docs/` 17G. `mutation-slot-1` is 5.6G, with `docs/` at 82M.
- `scripts/mutation-probe.sh:265-269` copies **every untracked, non-ignored file** of the invoking checkout into the isolated worktree: `done < <(git -C "$ROOT" ls-files --others --exclude-standard -z)` with `cp "$ROOT/$f" "$TREE/$f"`. The loop has no size limit. The comment at lines 243-245 explains why (a new module has no HEAD version). `cp --version` is GNU coreutils 9.12, which defaults to `--reflink=auto`.
- `btrfs filesystem du -s` on the evidence tree: in `mutation-slot-0` Total 15.93 GiB, **Exclusive 0.00 B**, Set shared 15.93 GiB. In the main checkout Total 15.95 GiB, Exclusive 10.95 MiB, Set shared 15.93 GiB.
- So the slot copy costs about no extra physical space while the main copy exists, and the reverse also holds. Deleting `evidence/` from the main checkout alone frees about nothing while `mutation-slot-0` exists. The probe copy keeps the extents alive, in the same way a snapshot did in the 2026-11-06 report.

### E7. Gate pool and other subvolumes

- `~/.cache/codescout-gate` (own subvolume): 121G (`du -sh`): `slot-0` 38G, `slot-1` 44G, `slot-2` 39G. A RAM-backed pool is mounted separately (`/var/cache/codescout-gate-ram`, zram, ext4, 43G size, 21.3G used); it does not use the NVMe.
- `~/.cache/cc-tmp` (own subvolume): 59G. `~/.local/share/langfuse` (own subvolume): 114G. Neither was analysed further; they are not codescout artifacts as far as I know.

### E8. Sibling directories under `~/work/claude` (not in the codescout repo)

`btrfs filesystem du -s`, plus last-write check as in E3:

| Path | Total | Exclusive | Set shared | Last file write |
|---|---|---|---|---|
| `hce-data` | 165.29 GiB | 121.50 GiB | 3.36 GiB | `runs/`: none within 7 days, some within 14 |
| `s5-work` | 66.35 GiB | 22.69 GiB | 32.63 GiB | none within 14 days |
| `s5-work-v2` | 51.69 GiB | 232.61 MiB | 32.06 GiB | none within 14 days |
| `s5-work-r1` | 40.66 GiB | 409.68 MiB | 31.70 GiB | none within 14 days |
| `setup-ab-data` | 44.78 GiB | 43.89 GiB | 513.45 MiB | within 7 days |
| `claude-plugins/.codescout` | 79.39 GiB | 77.69 GiB | 820.15 MiB | within 1 day (active) |

The three `s5-work*` trees share about 32 GiB with each other. Each was measured separately, so the combined size was not measured. If the three 32 GiB sets are the same extents (not verified), the combined cost is about 55 GiB, not the 159G that `du` sums to. `claude-plugins/.codescout` is 77G inside `harness-identity-pool`, and it was written within the last day, so it is active. `claude-plugins` has a clean `main...origin/main` status; `codex` is `ahead 2, behind 442` with one modified file; `researcher` is on branch `fix-open-issues` with no upstream shown.

### E9. Host context (not codescout artifacts, listed for completeness)

`~/.cache/sccache` 21G, `~/.cache/uv` 20G, `~/.gradle` 21G, `~/.codex` 20G, `~/models` 17G, `~/.thunderbird` 11G, `~/.android` 9.4G, `~/work/claude/codex` 36G, `researcher/target` 20G, `rule-tell-rocm/.venv` 15G, `~/work/personal` 326G (of which `home/ha` 198G). `maintenance/disk_cleanup.py --dry-run` (system repo) reports 126.9 GB SAFE, 36.5 GB MEDIUM and "1.1 TB" HIGH. The HIGH figure is the apparent-size trap (3 above).

## Second measurement pass and actions (2026-11-14, same day)

This section was added after the first pass. The operator asked to "measure until you find everything", then said "lets fix milvus log", then "lets cleanup the docker build images at leave only 3 days max". Each measurement below names its command or source. This section overrides E1's conclusion.

### P1. Every size in this report is logical, not physical

- The root filesystem mounts with `compress=zstd:1` (`findmnt -t btrfs`, `/etc/fstab`). `stat` and `du` report logical bytes. `du` also counts a shared reflink extent once for each file that references it.
- Proof by experiment: removing the 76.6 GB milvus log raised `df` available space on `/` from 75,427,966,976 B to 81,262,034,944 B, which is +5,834,067,968 B. The ratio is about 13:1. Other writers were active, so the figure is approximate.
- `du -x` totals add up to more than the disk: `/home/marius` 1,977,862,901,760 B, `/` 1,023,051,939,840 B, `/var/log` 11,764,195,328 B and `/var/cache/pacman/pkg` 2,970,554,368 B give about 3.0 TB logical, against 1,854,061,158,400 B of data used.
- `compsize` was not installed at first. The operator then approved installing it (package `compsize 1.5-2` from `extra`, 9 KiB, depends on `glibc` only). The pacman snapper hook created no snapshot (`btrfs subvolume list -s /` is empty). Section P10 holds the physical sizes. Every figure outside P10 and P1 is logical, and a ranking by logical size differs from the ranking by physical size.
- Physical anchors from `btrfs filesystem usage -b /` (2026-11-14 12:46Z): device 1,999,323,004,928 B; allocated 1,995,006,017,536 B; unallocated 4,316,987,392 B; data size 1,925,128,912,896 B, used 1,854,061,158,400 B (96.31%); metadata DUP size 34,904,997,888 B, used 25,832,439,808 B (74.01%, so 51.7 GB raw); estimated free 75,384,741,888 B. Data chunks hold 71.1 GB of free space inside already allocated chunks.
- Free space fell from 76.67 GiB (first pass) to 70.2 GiB (this pass) while the measurements ran. The cause of that fall was not isolated.
- Fixed costs: `/swap/swapfile` is 34,359,738,368 B. `/.snapshots/3135` and `/home/.snapshots/2842` are empty directories (0 B).

### P2. Logical sizes by region (`du -x -B1`, second pass)

`du -x` does not enter nested subvolumes (`codescout-gate`, `codescout/target`, `cc-tmp`, `langfuse`); pass one measured those.

- `/` (`@`): 1,023,051,939,840 B.
  - `/var`: 953,871,843,328 B. `lib/containerd` 676,063,420,416 B (overlayfs snapshotter 563,758,477,312 B; content store 112,256,798,720 B). `lib/docker` 176,731,602,944 B (containers 88,614,993,920 B; volumes 88,026,906,624 B). `tmp` 97,482,629,120 B.
  - `/opt`: 40,562,286,592 B (`rocm` 30,781,775,872 B; `cuda` 5,586,223,104 B). `/usr`: 28,574,576,640 B.
- `/var/log` (`@log`): 11,764,195,328 B (`atop` 5,712,003,072 B; `journal` 4,362,801,152 B).
- `/var/cache/pacman/pkg` (`@pkg`): 2,970,554,368 B.
- `/home/marius` (`@home`): 1,977,862,901,760 B. Top level: `work` 1,375,596,007,424 B (an earlier scan gave 1,360,227,905,536 B; files changed between scans), `.cache` 390,737,649,664 B, `.config` 31.9 GB, `.codex` 20.8 GB, `.gradle` 20.3 GB, `models` 17.6 GB, `.thunderbird` 11.7 GB, `agents` 10.3 GB (`llm-proxy` 6.6 GB), `.android` 10.0 GB, `.claude` 8.9 GB, `backups` 8.7 GB, `Android` 7.8 GB, `.local` 7.5 GB, `.rustup` 6.8 GB, `.claude-kat` 6.1 GB, `.claude-sdd` 5.1 GB, `.sync-backups` 4.9 GB, `.cargo` 4.7 GB.
  - `work/claude` 744,583,196,672 B: `hce-data` 181.3 GB, `claude-plugins` 87.7 GB, `s5-work` 71.7 GB, `codescout` 66.7 GB, `s5-work-v2` 56.4 GB, `setup-ab-data` 49.4 GB, `s5-work-r1` 43.9 GB, `codescout.worktrees` 41.4 GB, `codex` 38.2 GB, `researcher` 25.4 GB, `rule-tell-rocm` 15.8 GB, `es-stage0` 9.2 GB, `g10-wr-T` 9.1 GB, `s5-work-v2d` 8.8 GB, `g1-wr` 7.1 GB, `jevk5` 6.0 GB, `s5-work-v2p` 5.7 GB.
  - `work/personal` 349.0 GB (operator's own data, not codescout artifacts): `home/ha` 210.5 GB (includes the Home Assistant recovery dump named in the host notes), `ai/me-clone` 54.2 GB, `misc/avatar` 45.4 GB, `phone/media` 23.5 GB, `media/video` 8.3 GB.
  - `work/stefanini` 171.3 GB: `southpole` 94.0 GB (`MRV-poc` 49.2 GB, `tools` 34.1 GB), `utils/stefanini-mcp` 38.1 GB, `invest-europe` 21.4 GB, `old` 11.5 GB.
  - `work/mirela` 96.4 GB: `backend-kotlin` 81.5 GB (`python-services` 61.8 GB, `.local-iel` 10.5 GB), `eduplanner-mobile-expo58` 8.8 GB (`node_modules` 8.2 GB). `work/prosus` 8.5 GB. `work/interviews` 3.6 GB.
  - `.cache` 390.7 GB: `codescout-resident` 338.4 GB, `sccache` 21.6 GB, `uv` 5.3 GB, `yay` 2.8 GB, `cs-review` 2.6 GB, `huggingface` 2.5 GB, `codescout` 2.3 GB, `BraveSoftware` 2.2 GB, `codescout-hardening-review-lsp-20261014` 2.0 GB.
- Not counted (permission denied for the non-root `du`): `work/personal/home/ha/recovery/bose-voice-test-20261026/.esphome/**` and `work/mirela/deployment/prod/volumes/postgres/pgdata`.

### P3. `/var/tmp` holds 97.5 GB of experiment trees (missing from the first pass)

Total: 97,482,629,120 B logical. `/var/tmp` is on the root filesystem. Only `/tmp` is a tmpfs (32 GB, 3.0 GB used), so these trees survive a reboot. None of them has a manifest or an owner.

- `ep11-01a15`: 79,042,711,552 B (mtime 2026-11-11 20:42). Children: `paid-campaign-headroom-v3` 40,350,306,304 B; `public-ledger-diagnosis-v1` 11,695,665,152 B; `headroom-native-qualification-v1` 10,338,893,824 B; `full-native-campaign-v1` 10,338,430,976 B; `public-compilation` 3,047,710,720 B; `paid-campaign-path-v2` 801,345,536 B.
- `native-feedback-qualified-v3-01a15` 3,887,751,168 B (11-12 21:49) and `-v2-01a15` 2,153,279,488 B (11-12 20:19).
- `native-feedback-readiness-buffers-v1/v2/v3-01a15`: 2,660,175,872 B, 2,660,175,872 B and 2,660,450,304 B (11-12 20:48, 20:57, 21:08). Each holds a `nearai__ironclaw-6724` directory of about 1.74 GB. Whether the three are copies of each other was not checked.
- `codescout-bt29-20261029` 3,351,318,528 B (2026-10-29). `ep9-01a15` 628,129,792 B. `stock-obs-support-check-01a1b59b` 168,755,200 B. About 330 smaller entries (`rust-analyzer*`, `proc-macro-srv*`, `.tmp*`, `codescout-bg-*.log`).

### P4. atop runs again although SYS-023 disabled it

- `systemctl is-enabled` reports `disabled` for `atop.service`, `atopacct.service` and `atop-rotate.timer`. `systemctl is-active` reports `atop.service` active, `atop-rotate.timer` active and `atopacct.service` inactive.
- Cause, verified: the package `atop 2.13.0-1` ships the symlink `/usr/lib/systemd/system/timers.target.wants/atop-rotate.timer` (`pacman -Qo`). The service `atop-rotate.service` runs `systemctl restart atop.service`, and that starts atop although the unit is disabled. The journal shows "Started Daily atop restart" at boot (2026-11-11T08:58:35+02:00) and restarts at 11-12 00:00, 11-13 00:00 and 11-14 08:07:54.
- Effect: `/var/log/atop` holds 5,712,003,072 B in six files. Sizes: `atop_20261109` 1,745,762,302 B; `atop_20261110` 1,282,245,668 B; `atop_20261111` 25,571,578 B; `atop_20261112` 1,262,846,207 B; `atop_20261113` 1,027,848,613 B; `atop_20261114` 368,159,678 B (still written). That is about 1.3 GB/day logical. The host notes declare 28-day retention, so the steady state would be about 36 GB logical. SYS-023 deleted about 16 GB of these logs, and the mitigation does not hold.
- Not changed: the timer is not masked.

### P5. Docker, second pass

- `docker system df`: images 55 (24 active) 480.4 GB, reclaimable 149 GB; containers 31 (26 active) 892.2 MB; volumes 246 (20 active) 105.5 GB, reclaimable 35.6 GB; build cache 75 (0 active) 250.6 GB, reclaimable 51.63 GB. Docker 29.9.3, containerd image store, `live-restore=false` (a daemon restart stops all containers).
- 31 images are unused (149.0 GB unique size). Of the 29 images whose build date is older than 72 h, 24 are used by containers. Five are unused: `home-assistant:2026.11.0` (3.49 GB) and four `starryzhang/sweb.eval.*` base images (22.0, 11.5, 55.8 and 23.9 GB logical). All five arrived locally between 2026-11-11 22:00Z and 2026-11-12 06:58Z (`Metadata.LastTagTime`).
- All 75 build cache entries were created and last used less than 3 days ago (last used 46 to 47 hours ago or "2 days ago" at 14:56 EET).
- Volumes: 226 are unused (35.6 GB), among them 19 `sab-tpl-*` volumes (29.3 GB) and `avatar_hf-cache` (3.5 GB). `marius-fixes_phoenix_data` (25.4 GB) is **in use** by the running container `ie-phoenix`. Treat it as live data, not as an orphan. The six `marius-fixes_*` volumes total 27.8 GB (compose project `marius-fixes`, working dir `/home/marius/work/stefanini/invest-europe/ie-pal-engine`).
- Container logs (all `json-file`): `codescout-dense-amd` 6,196,666,068 B and `tor` 2,228,124,080 B, both logical and unrotated. The compose container `ie-milvus` has `max-size=500m, max-file=7` and a 56,265,735 B log.

### P6. milvus log: observed cause and fix (action taken)

- Observed: `ie-milvus-sandbox` holds 482 collections named `<uuid>_doc_file_<n>_text` (`POST /v2/vectordb/collections/list`). It uses embedded etcd and local storage in the volume `ie-milvus-sandbox-data` (2.78 GB logical). The log lines are per channel INFO lines (`writebuffer/write_buffer.go:238`, "checkpoint from latest consumed msg"). Growth was 297,280 B/s over 60 s at 12:47Z (about 25.7 GB/day logical). A causal link between the collection count and the log rate is plausible but was not proven. The compose sibling `ie-milvus` has log rotation and a 56 MB log; its collection count was not compared.
- Who started the container is still unknown. No launcher script exists under `~/work`, `~/invest-europe`, `~/agents` or `~/bin`.
- Fix, applied 2026-11-14 about 12:53Z on the operator's instruction ("lets fix milvus log"):
  1. Checked that no client was connected: `/proc/net/tcp` and `/proc/net/tcp6` inside the container show only connections from the container to itself.
  2. Saved `docker inspect` and the last 300 log lines to the session scratchpad.
  3. `docker stop -t 60`, then `docker rename` to `ie-milvus-sandbox-old`.
  4. `docker run -d --name ie-milvus-sandbox --log-driver json-file --log-opt max-size=500m --log-opt max-file=3 --restart no -p 127.0.0.1:19531:19530 -p 127.0.0.1:9092:9091 -v ie-milvus-sandbox-data:/var/lib/milvus -e ETCD_USE_EMBED=true -e ETCD_DATA_DIR=/var/lib/milvus/etcd -e COMMON_STORAGETYPE=local milvusdb/milvus:v2.4.0 milvus run standalone`.
  5. Verified: `/healthz` returns OK, the REST API lists the 482 collections, the new log has 0 `[ERROR]`, `[PANIC]` or `[FATAL]` lines, and `docker inspect` shows the same image, command, environment, ports and volume as before. Only `LogConfig` differs.
  6. `docker rm ie-milvus-sandbox-old`. The volume stays.
- Result: free space rose by 5.83 GB (P1). The new log is capped at 1.5 GB (3 x 500 MB). In the first 20 s after the restart it grew at 849,719 B/s (replay burst).
- Not changed: the log level (still INFO), the logs of `codescout-dense-amd` and `tor`, and `/etc/docker/daemon.json`. A daemon-wide `log-opts` default needs a Docker restart, and `live-restore` is off.

### P7. 3-day Docker prune: nothing was eligible

- `docker builder prune -f --filter until=72h` returned `Total: 0B`. `docker image prune -a -f --filter until=72h` returned `Total reclaimed space: 0B`.
- Reason: every local build artifact and the five unused older images are less than 72 h old by Docker's clock. The sweb `arrow-rs` base becomes eligible at about 2026-11-14 22:00Z. The other four unused images follow by about 11-15 07:00Z. Build cache entries and the `ep-feedback-*`/`effort-feedback-*` images age out one by one from about 2026-11-15. A rerun of the same two commands then reclaims space.
- No recurring prune is installed.

### P8. Corrections to the first pass

- E1 and "Root cause": the claim that the milvus log is "of the same order as the net growth" is wrong for physical space. The log was about 6 GB physical. The net growth since 2026-11-08 (about 78 GB) is mostly unexplained by it.
- Artifacts dated 2026-11-11 to 2026-11-13 are the strongest candidates: Docker images and build cache (480.4 GB and 250.6 GB logical), `/var/tmp` experiment trees (97.5 GB logical) and resident data. This is a correlation by date, not a measured attribution.
- `marius-fixes_phoenix_data` is in use (P5).
- The "1.1 TB reclaimable" figure of `disk_cleanup.py` stays an apparent (logical) size.

### P9. Additional proposals (not implemented)

1. Done: `compsize` is installed and P10 re-ranks the consumers. Size any cleanup with `compsize` (column "Disk Usage"), not with `du` or `stat`.
2. Mask `atop-rotate.timer`, or add a drop-in, if atop must stay off. SYS-023 does not hold today.
3. Put `log-opts` (`max-size`, `max-file`) in `/etc/docker/daemon.json`. Plan a Docker restart window because `live-restore` is off.
4. Bring the `/var/tmp` experiment trees (P3) into the lifecycle scope of the fix: they have no manifest and no closed state.
5. Add a recurring `until=72h` Docker prune only after the owner confirms which images a running campaign needs.

### P10. Physical sizes (`compsize -b -x`, column "Disk Usage"), 2026-11-14

"Disk Usage" is the physical size of the extents under one path, with each shared extent counted once inside that run. "Referenced" is the logical sum. Two runs over different paths count a shared extent in each run, so the rows do not add up exactly. The jobs wrote to `cs-sys.txt`, `cs-home.txt`, `cs-claude.txt` and `cs-resident.txt` in the session scratchpad.

Ranking by physical size (bytes physical / bytes referenced):

| Rank | Path | Physical | Referenced |
|---|---|---|---|
| 1 | `/var/lib/containerd` (images and build cache) | 323,236,312,730 | 702,904,080,575 |
| 2 | `~/.cache/codescout-resident` | 180,790,871,381 | 357,396,083,322 |
| 3 | `~/work/personal` (operator data) | 169,845,155,637 | 368,885,010,705 |
| 4 | `~/work/stefanini` (operator data) | 105,864,050,291 | 177,088,412,051 |
| 5 | `work/claude/hce-data` | 99,218,294,934 | 227,302,868,984 |
| 6 | `~/.cache/codescout-gate` (gate pool) | 97,345,727,021 | 417,444,729,991 |
| 7 | `~/.local/share/langfuse` | 84,716,450,111 | 121,582,728,254 |
| 8 | `codescout/target` | 78,950,467,215 | 109,959,081,139 |
| 9 | `/var/lib/docker/volumes` | 64,716,985,627 | 87,761,537,980 |
| 10 | `work/claude/claude-plugins` | 61,546,730,742 | 114,299,375,301 |

Further rows, physical bytes: `work/claude/codescout` 50,514,373,322 (referenced 71,276,629,979); `work/mirela` 42,505,441,285; `work/claude/s5-work` 40,762,839,712; `~/.cache/cc-tmp` 36,227,970,766; `/swap` 34,359,738,368; `/var/tmp` 32,936,288,018 (referenced 107,013,662,890); `codescout.worktrees` 31,663,592,699; `work/claude/codex` 30,844,922,164; `s5-work-v2` 26,461,082,951; `setup-ab-data` 26,356,273,112; `s5-work-r1` 26,192,881,318; `~/.config` 24,118,154,600; `~/.cache/sccache` 21,311,264,042; `/opt` 17,753,260,853; `~/models` 17,641,656,320; `/usr` 15,182,823,466; `work/claude/researcher` 12,441,723,954; `~/.codex` 12,388,256,839; `~/.gradle` 11,402,431,653; `/var/log` 8,092,559,243; `rule-tell-rocm` 7,685,312,423; `~/backups` 6,120,736,439; `g10-wr-T` 6,206,602,706; `g1-wr` 4,963,808,453; `s5-work-v2d` 4,873,120,954; `~/.thunderbird` 4,794,240,794; `~/agents` 4,646,819,836; `es-stage0` 4,492,240,806; `jevk5` 3,851,159,743; `rule-tell-runs` 3,543,041,561; `s5-work-v2p` 2,955,256,483; `/var/cache/pacman/pkg` 2,969,867,276; `measurement-corpora` 1,184,971,669.

Breakdown of the two largest items:

- `/var/lib/containerd`: overlayfs snapshotter 210,968,652,721 B physical (590,600,275,569 B referenced); content store 112,220,207,794 B (112,255,701,546 B referenced, 99% incompressible). Per-image physical size was not measured.
- `~/.cache/codescout-resident/codescout` (129 directories): `native-feedback-preparation-20261112` is 155,370,619,705 B physical (268,244,459,450 B referenced). That is 86% of the resident cache. `evidence-cohort-20261110` is 12,505,874,563 B. The other 127 directories total about 12.9 GB. The next largest are `compile-mechanism-r2-20261029` 1,510,436,441 B and `native-env-admission-20261104` 1,316,338,625 B.

Other physical figures: `/var/lib/docker/containers` is 1,516,171,855 B (referenced 12,538,770,923 B) after the milvus fix. btrfs metadata uses 25,832,439,808 B per copy (51.7 GB raw, DUP).

Reconciliation: the measured physical regions sum to about 1,877 GB, against 1,854 GB of data used (btrfs). The sum overshoots by about 1.2% although about 25 to 50 GB of home dot-directories were not measured. That implies roughly 50 to 75 GB of extents are shared between two measured trees and so counted twice. The 4 to 1 gap between referenced and physical size of the gate pool (417 GB against 97 GB) is reflink sharing.

What the physical data changes:

- Three Nov 11 to Nov 13 campaign artifacts are identified at physical size: `native-feedback-preparation-20261112` 155.4 GB, `evidence-cohort-20261110` 12.5 GB and the `/var/tmp` trees 32.9 GB. That is 200.8 GB. The Docker images and build cache from the same dates are inside the 323.2 GB of `/var/lib/containerd`, but their share was not measured.
- Operator data (`work/personal`, `work/stefanini`, `work/mirela`) is 318 GB physical and is not a codescout artifact.
- Logs are no longer a concern: all container logs together are 1.5 GB physical.
- Nothing in this section was deleted or changed.

### P11. What creates the three largest trees, and what reclaims them

The operator asked about `~/.cache/codescout-resident`, `codescout/target` and `claude-plugins`. Each item below names the file or command that was read. Sizes are physical bytes from P10 unless the text says logical.

**A. `~/.cache/codescout-resident` (180,790,871,381 B physical, 129 directories)**

- Creator: `scripts/resident-scratch.sh <name>`. It runs `mkdir -p <root>/<repo>/<name>` and prints the path. It writes nothing else and removes nothing. The convention is `docs/conventions/resident-scratch-location.md` (id `9e199abce9e9ef3f`, status `draft`). Reason it exists: rust-analyzer's file watcher walked in-tree scratch and kept `documentSymbol` answering null (bug `35bcf086deeb7cbe`). The directories themselves are filled by experiment and campaign sessions.
- Distribution: `native-feedback-preparation-20261112` is 155,370,619,705 B (86%). Its children: `nearai__ironclaw-6724` 56,744,561,380 B; `fixture-complete-controls-v1` 42,350,764,286 B; `DioxusLabs__dioxus-5384` 40,767,687,211 B; `apache__arrow-rs-7783` 9,898,533,605 B; `skim-rs__skim-1044` 5,726,315,046 B. These four task names match the four `starryzhang/sweb.eval.*` images of P5. `evidence-cohort-20261110` is 12,505,874,563 B. The other 127 directories total about 12.9 GB.
- Reclaim rule: none. The script header and the convention say the root is deliberately **outside** the gate pools, so that `slot_tend` cannot delete it. The convention has no retention rule, no manifest and no expiry. `scripts/resident-scratch-migrate.sh` only moves closed directories from the repository into this root, and the convention says a sealed directory is not moved.
- What reclaims it today is an ad hoc cleanup campaign per incident. Each campaign is saved as its own resident directory with a script and before/after `df` files:
  - `docker-cleanup-20261031b` (2026-10-31): 15 `image-rm-*.log` files. Its `result.json` was not read.
  - `run-storage-cleanup-20261101` (2026-11-01 15:03Z): removed `debug` from gate `slot-1` and `slot-2`, 87,200,849,920 B allocated. Available space rose from 171,039,059,968 B to 240,330,420,224 B (+69,291,360,256 B). Companions: `docker-cache-cleanup-20261101` and `worktree-cleanup-20261101`.
  - `disk-cleanup-20261106` and `disk-cleanup-followup-20261106` (2026-11-06): removed 63,952,125,952 B of allocation (gate cache 26,512,560,128 B and closed caches 37,439,565,824 B), 24 cache directories, 6 closed project copies and 75 empty anonymous volumes. Available space rose only from 64,705,466,368 B to 66,350,931,968 B (+1,645,465,600 B) because four snapshots (2794, 2795, 3085, 3086) were preserved (related issue `2026-11-06-experiment-caches-retained-by-home-snapshots`).
  - 2026-11-08: SYS-023 deleted the snapshots and available space rose from 65 GB to 155 GB. On 2026-11-14 it was 75.4 GB again. So the cycle between full disk and cleanup is about 6 to 8 days.
- A deletion for the current campaign is prepared and not approved: `native-feedback-preparation-20261112/closed-ledger-cache-inventory-v1.json` (5,043,502 B, 2026-11-12 22:27) starts with `"approval_received": false`, `"deleted": false` and `"historical_build_tree_reverification_after_deletion": "not available without original cache bytes"`. Its `inventories` map is keyed by build trees such as `/var/tmp/ep11-01a15/public-ledger-diagnosis-v1/commands/baseline/build/target`, with a sha256 per file. I read the first 1,500 bytes only.

**B. `codescout/target` (78,950,467,215 B physical, nested btrfs subvolume 4569)**

- Creators, all writing into the main checkout's default cargo target directory: `cargo rb` (alias in `.cargo/config.toml`: `build --release --features server-stack`; `~/.cargo/bin/codescout` is a symlink to `target/release/codescout`), `cargo test`, rust-analyzer flycheck (`flycheck0`), `scripts/build-windows.sh` (target `x86_64-pc-windows-gnu`; a wine test suite exists in `tools/wine-repro/cycle.sh`), and `tests/cli_doc.rs` (`pinned_binary()` makes `target/debug/.cli_doc-pin-<pid>`).
- Physical breakdown: `debug` 58,771,243,319 B (`deps` 48,379,880,010 B; `examples` 3,976,104,603 B; `incremental` 3,685,896,845 B; `build` 2,324,331,961 B; two `.cli_doc-pin-*` files 443,596,800 B each; `codescout` 445,075,456 B; `sync_project` 320,061,440 B), `x86_64-pc-windows-gnu` 13,255,118,935 B, `release` 6,899,717,165 B.
- `debug/deps` holds 418 test executables of 54.57 GB logical (66.9 GB logical in all). For 37 test names the newest variant was written in 2026-09, and for `codescout` in 2026-10. **No** variant of these 38 names was written in November. Variants per name: `codescout` 39 (9.48 GB logical), `sync_project` 25 (4.79 GB), `e2e_tests` 14 (3.32 GB), most integration tests 12 (2.2 to 2.9 GB each). By file mtime, `debug/deps` holds 22.81 GB (2026-08), 31.51 GB (2026-09), 0.92 GB (2026-10) and 10.98 GB (2026-11, `.rlib` and `.rmeta` only), all logical. The gate pool replaced per-session trees on 2026-09-24, which fits the last test-binary writes here. An old mtime does not prove a file is unused, because cargo does not rewrite an up-to-date artifact. The files were not proven stale.
- Reclaim rule: none for this directory. `scripts/slot-pool.sh` says "Cargo never garbage-collects a target dir", and its bounds (ceiling 49,152 MB per slot, `KEEP` count, idle 3 days) apply to leased pool slots only. `target/` is not a slot. `src/agent/build_check.rs:382` already records that `target/` was 97 GB on a disk 91% full.
- `.cli_doc-pin-898236` and `.cli_doc-pin-950991` date from 2026-09-20 (55 days). `pinned_binary()` sweeps pins older than 6 h, but only when `cli_doc` runs again with that directory as the binary's parent. The gate uses pool slots, so `target/debug` has not run `cli_doc` since 2026-09-20 and the pins stay. Neither process id exists.
- Why `target` is a nested subvolume was not established here.

**C. `claude-plugins` (61,546,730,742 B physical)**

- 59,814,848,594 B (97%) of it is `.codescout/harness-identity-pool`. The rest of the repository is about 1.7 GB.
- That directory is a **codescout gate pool**, created 2026-10-11 18:29. The review documents `docs/reviews/2026-10-10-harness-neutral-session-identity.md` (in worktrees `ecc-codex-codescout` and `effort-toggle-b`, lines 103 and 199) record the command `CODESCOUT_GATE_POOL=/home/marius/work/claude/claude-plugins/.codescout/harness-identity-pool ./scripts/gate.sh --check`. A gate run started from the claude-plugins checkout pointed the pool into that repository. `slot-0` and `slot-1` hold codescout cargo trees (`debug`, `release`, `flycheck0`).
- Both `.codescout-lessee` stamps are **2026-11-07 20:24**, which is 7 days old, against `SLOT_IDLE_DAYS_DEFAULT=3`. Both slots still exist. Reading `slot_tend` in `scripts/slot-pool.sh` explains it: the function runs on every lease ("applies both on every lease"), so a pool that nobody leases from is never tended. No lease has happened since 2026-11-07. This is concluded from the code and the stamps. `slot_tend` was not run, because running it would delete.
- For comparison, the default pool `~/.cache/codescout-gate` (97,345,727,021 B physical) has slots 0 to 2 with stamps 2026-11-14 15:13, 11-12 16:21 and 11-12 11:22, all inside 3 days. Its 13 lock files (slots 0 to 12) show how many slots existed at some time.

**D. Common pattern: reclaim follows use, and only the RAM tier has a timer**

- `slot_tend` runs at lease. The `cli_doc` pin sweep runs at test start. The `/tmp` gate tmp sweep (`scripts/gate.sh:189`, `-mmin +720`) runs at gate start. Each rule needs a new run in the same place, so an abandoned place keeps its data: the idle pool (7 days), the pins (55 days), `/var/tmp` and the resident cache (no rule).
- All timers found (`systemctl list-timers --all`, system and user; `crontab` is not installed): user `codescout-gate-ram-evict.timer` (every 10 min, runs `scripts/gate-ram-evict.sh`, "Empty idle slots of the codescout gate RAM tier"); system `tmp-guard.timer` (15 min, frees stale entries from the RAM-backed `/tmp`, SYS-014); `btrfs-balance-weekly.timer` (Monday 00:45, `btrfs balance start -dusage=30 -dlimit=20 /`, SYS-012; the journal holds no run of the service since 2026-10-01, only the timer start at boot on 11-11, and its coverage of earlier boots was not checked); `paccache.timer`. None of them covers the disk gate pools, `target/`, the resident cache or `/var/tmp`.

**E. Proposals (not implemented)**

1. A time-driven reaper for disk pools, in the shape of `codescout-gate-ram-evict.timer`: it applies the `slot_tend` rules to every registered pool. A pool is registered when it is created, including a `CODESCOUT_GATE_POOL` override, because the claude-plugins pool is invisible from this repository.
2. A manifest for every resident directory, written by `resident-scratch.sh`: owner session, purpose, creation date, keep-until date, sealed flag. Add a report-only listing of expired directories. The archived fix `2026-09-24-residual-detect-unregistered-worktree-dirs` is the precedent for a report-only check. The `approval_received` and `deleted` fields of `closed-ledger-cache-inventory-v1.json` show the approval step the manifest needs.
3. Main `target/`: report its size and the number of variants per test name in `doctor`, and decide on a documented prune or on moving main-checkout builds into a pool slot. Move the `cli_doc` pin sweep into the gate so that it covers every target directory, or put the pin outside `target/`.
4. Replace the per-incident cleanup scripts with one standing, reviewed script that has a dry-run mode.

### P12. Deletion of the September-or-older test binaries in `codescout/target` (action taken)

The operator said "hai sa stergem cele din sept sau mai vechi", after P11-B. The scope was read as the files of `codescout/target` last written on or before 2026-09-30. Nothing outside `target/debug/deps` and `target/debug/.cli_doc-pin-*` was touched.

- Before deleting, the following were checked. No process runs a binary from `target/debug` or `target/debug/deps`. The 20+ processes that run `target/release/codescout` are live MCP servers, and `release/` was left alone. The two running cargo processes build elsewhere: `CARGO_TARGET_DIR=/var/cache/codescout-gate-ram/pool/slot-0` for `cargo test`, and a worktree-local target for `cargo check`.
- Dry-run, 345 files, 43,204,812,544 B logical: 104 files from 2026-08 (16.38 GB) and 241 from 2026-09 (26.82 GB). Every file is a hash-suffixed executable in `target/debug/deps` with one hard link and an mtime before 2026-10-01. The list is in the session scratchpad as `delete-candidates.txt`.
- Executed: `find target/debug/deps -maxdepth 1 -type f -links 1 ! -newermt 2026-10-01 -regex '.*/[A-Za-z0-9_]+-[0-9a-f]{16}' -delete`. Then `rm` of the two stale pins `.cli_doc-pin-898236` and `.cli_doc-pin-950991` (both 443,595,376 B, 2026-09-20) and of `deps/codescout-35319e42be9e9c0e`, which is the same inode (66905, two links) as pin 950991.
- Result: available space on `/` rose from 79,099,777,024 B to 121,960,476,672 B (+42,860,699,648 B). `compsize` on `target` fell from 78,950,467,215 B to 34,856,375,951 B physical (-44.09 GB); referenced size fell from 109,959,081,139 B to 65,422,871,731 B. The two measurements agree.
- Left in place on purpose: 4,874 files from 2026-09 or older in `debug/deps`, 9.41 GB logical (737 `.rlib` 5.86 GB, 1,824 `.rmeta` 2.08 GB, 61 `.so` 0.69 GB, 2 executables 0.77 GB, `.d` files). They may be current third-party dependencies, and an old mtime does not prove otherwise. The two executables are hard-linked into `target/debug/` (`codescout-e16e82de99db5770`, `sync_project-305e6a18a06d6659`). Also untouched: `target/release` (live binary, written 2026-11-14 12:28; `~/.cargo/bin/codescout` still points to it) and `target/x86_64-pc-windows-gnu`.
- Cost: the next `cargo test` in the main `target/` rebuilds the deleted test binaries. The gate uses pool slots, so no recurring cost is expected. Cargo marks a unit stale when its output file is missing, so no repair step is needed. This was not tested with a run.
- Not restorable: the files were deleted, not moved. The scratchpad list keeps names, sizes and dates only.

### P13. Old dependency artifacts in `target/debug/deps` and the `harness-identity-pool` (action taken)

The operator answered "da, sterge" to two explicit questions: delete the old `.rlib`/`.rmeta` files of `target/debug/deps`, and delete the `harness-identity-pool`. A third item (`native-feedback-preparation-20261112` and the `/var/tmp` trees) was left to the operator as a decision and was **not** deleted.

- Checks before deleting: no process references `codescout/target/debug` or the pool (`pgrep`, `/proc/*/cwd`); both pool locks were free (`flock -n slot-N.lock true`). `rustc` was running, but in `/var/cache/codescout-gate-ram/pool/slot-0`.
- `target/debug/deps`: 4,858 files with one hard link, mtime before 2026-10-01, extension `.rlib` (736 files, 5.56 GB logical), `.rmeta` (1,824, 2.08 GB), `.so` (61, 0.69 GB) or `.d` (2,237, 0.01 GB): 8.35 GB logical in all. Deleted with `find ... -delete`. The list is in the session scratchpad (`delete-candidates-2.txt`). Physical effect: `target` fell from 34,856,375,951 B to 32,130,286,225 B (-2.73 GB).
- `claude-plugins/.codescout/harness-identity-pool`: `slot-0` and `slot-1` removed with `flock -n slot-N.lock rm -rf slot-N`, the way `slot_tend` removes a slot, so a slot leased in between would have been refused. The two `slot-N.lock` files stay, because `slot-pool.sh` says lock files are never unlinked. `compsize` of `claude-plugins` fell from 61,546,730,742 B to 2,245,557,372 B (-59.30 GB). The next gate run that uses this pool recreates a slot and builds cold.
- Result: available space on `/` rose from 122,890,883,072 B to 184,555,458,560 B (+61,664,575,488 B). The two `compsize` differences add up to 62.03 GB; the 0.4 GB gap is concurrent writing.
- Still in place: 16 files of 2026-09 or older with two hard links in `debug/deps`, `target/release`, `target/x86_64-pc-windows-gnu`, the resident cache and the `/var/tmp` trees.
- Cost: the next debug build or `cargo check` in the main `target/` recompiles the deleted dependency units. Cargo treats a missing output as stale. This was not tested with a run.

## Root cause

Established:

- No harness stage records a manifest of what it creates, and none records a closed state. The evidence is the experiment-named Docker images and resident directories, which carry dates in their names and nothing else. Whether a stage that still needs them exists cannot be read from the disk.
- The Docker log driver has no size limit on at least one container (E1).
- `scripts/mutation-probe.sh` copies unbounded untracked content into every slot (E6).
- Measurement with `du -x` hides nested subvolumes, so cleanups were sized wrongly (trap 1).
- Every reclaim rule in the code is triggered by activity in the same location, and no timer covers the disk locations (P11-D). A location that nobody uses again is never reclaimed.
- `~/.cache/codescout-resident` has no reclaim rule at all by design (P11-A).

Not established:

- Who started `ie-milvus-sandbox`, and why it logs at INFO level at this rate.
- Whether the `ep-feedback-*` and `effort-feedback-*` images, the 235G `native-feedback-preparation-20261112` directory and the `hce-data/runs` and `s5-work*` trees are still needed. File ages are evidence of idleness, not of staleness.
- Why btrfs metadata is 24.03 GiB used (65 GiB raw). A large file count (targets, worktrees, node and Python trees) is plausible but was not measured.
- Whether a balance is needed: data chunks are 96.11% used and only 7.02 GiB is unallocated.
- How much of the net growth since 2026-11-08 each consumer caused.
- The directory count and per-directory exclusivity of `codescout-resident` below the ten listed.
- The `docker images` real exclusive size per image.

## Do not touch (constraints for any cleanup)

- The operator said not to remove anything. This report changed nothing.
- 47 of 50 local branches in the codescout repo were never pushed, and `experiments` is 420 commits ahead of its upstream. No garbage collection of worktrees, branches or `.git` may run without a push or bundle first.
- 13 worktrees have uncommitted tracked changes (E4). Their untracked files were not counted. A worktree removal loses them.
- The registration directories inside `native-feedback-preparation-20261112` and the `evidence/` tree hold experiment records. Delete only after the operator confirms a retention decision.
- `claude-plugins/.codescout/harness-identity-pool` was written within the last day. Treat it as active.
- Reflinks (E6): removing one copy frees nothing. Plan the removal of all references together.
- Sizing: use `btrfs filesystem du`, never `du -x` alone.

## Proposed directions (proposals, not designs, not implemented)

1. A read-only inventory in `doctor` (like `unregistered_worktree_dir`, `docs/issues/archive/2026-09-24-residual-detect-unregistered-worktree-dirs.md`) that groups artifacts by owner, last write and **exclusive** bytes, flags nested subvolumes, and never deletes.
2. A manifest per campaign: paths, image IDs and tags, volumes, worktrees, and a state (open or closed). Label Docker artifacts with the campaign id at creation, so a later cleanup works from a manifest and not from name patterns.
3. A free-space preflight before heavy stages that checks both `df` free space and btrfs unallocated space. It extends rule 2 of the memory `research/setup-ab-enospc-20261106` (at least 45 GB before a nushell build or grade).
4. In `scripts/mutation-probe.sh`: bound the untracked-copy loop (size cap, or an exclusion for known evidence directories), and decide what the probe should do with evidence trees.
5. A log limit (`--log-opt max-size`, `max-file`) for every container the harness starts, and in the `codescout-retrieval` compose file. The operator identifies the origin of `ie-milvus-sandbox`.
6. Decide whether `docs/trackers/effort-steering/evidence/` is ignored or committed. Today it is 16G untracked inside a tracked tree.

## Acceptance (for a future fix)

- A read-only report lists every group in E1-E8 with exclusive bytes within 5% of `btrfs filesystem du`, and names the nested subvolumes.
- A harness-started container cannot write an unbounded log.
- A heavy stage refuses to start when free or unallocated space is below a stated threshold, and records the refusal as an infrastructure result, never as a gate failure.
- A closed campaign's artifacts can be listed from its manifest without name matching.

## Workaround

None applied. Manual relief, subject to the operator's decision and to "Do not touch": truncating the three large container logs (about 83 GB) does not stop any container. It loses log content. A log limit needs a container recreation.

## Resume

Report only, filed 2026-11-14. Nothing claimed. The next step is an operator decision on E2, E3, E4 and E8 retention, then a design for directions 1-3.

## References

- `docs/issues/2026-11-06-experiment-caches-retained-by-home-snapshots.md`: same retention class through snapshots.
- `docs/issues/archive/2026-09-24-mutation-probe-worktrees-are-never-reclaimed.md`: sibling for the probe worktrees.
- `docs/issues/archive/2026-09-24-residual-detect-unregistered-worktree-dirs.md`: precedent for a report-only doctor check.
- `scripts/mutation-probe.sh:243-245` and `:265-269`: the untracked-copy loop.
- Codescout memory `research/setup-ab-enospc-20261106`: the earlier disk-full event.
- Host incident record, system repo, `SYSTEM_ISSUES_TRACKER.md`, entry 023 (snapshot deletion, 2026-11-08).
