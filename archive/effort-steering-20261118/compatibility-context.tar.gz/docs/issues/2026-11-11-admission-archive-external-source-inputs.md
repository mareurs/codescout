---
id: afaa9e16642a8da9
kind: bug
status: taken
title: Admission archive assumes every verified source/input is inside the worktree
tags:
- effort-steering
- evidence-custody
- cluster/unclassified
topic: effort-steering
claimed_at: 2026-11-11
claimed_by: 01a15ca9-f939-7603-acb5-01c6b02f68e2
opened: 2026-11-11
owner: marius
severity: medium
unverified: Local research helper is uncommitted. Its corrected bytes, original failure and full archive round-trip evidence are preserved; no shared product integration is claimed.
---

# BUG: Admission archive assumes every verified source/input is inside the worktree

## Summary

New preservation helper seal_headroom_admission.py exited1 before creating its archive directory. It applies Path.relative_to(WORK) to every input in the192-entry verification manifest, although99are frozen external evaluator inputs.

## Class fit

Local research-instrument path assumption, not actor/evaluator/admission logic. An external frozen input is a valid verified input, but the archive naming scheme assumes all inputs are worktree descendants.

## Symptom (Effect)

Actual bg61 log raises ValueError on /var/tmp/ep11-01a15/private-package/evaluator/source/tools/setup-ab-eval/PROVENANCE.json. No archive directory or payload was created. Original inputs are unchanged; final preflight and paid pilot are separate, and the pilot is not relaunched.

## Reproduction

Run the helper against actual headroom-verification-v4/verification.json. Actual population scan:192bound inputs,93inside cf66,99outside, all external paths belong to the frozen99-file evaluator package. Original error log: /home/marius/.cache/cc-tmp/codescout-bg-qqasIq.log.

## Environment

cf66 research worktree at d7236b843 plus WIP; archive helper is an uncommitted standalone preservation script, excluded from the frozen192-source/input census. Final independent report and seven-proof admission are already closed.

## Root cause

The archive-relative name was derived from a single worktree root, despite the consuming verification contract binding both local code and the separately exported evaluator package.

## Fix

Replaced the single-root relative naming with a collision-free absolute-input namespace under bound-inputs/. The original helper and actual failure log are preserved at archive-path-correction-v1 and inside the completed capsule. No actor, admission, prompt or evaluator changes; no paid rerun.

Corrected archive bg63exited0:4951515050bytes, SHA2d115e5e6092fe3dcceaa146a82ef567b608e6876ecbbecee86ecb01e8be7948,162973payload entries/141270regular payloads. Every selected payload was reopened and every selected original file/link remained unchanged. Live paid outputs are excluded.

## Tests added

Actual complete archive round trip succeeds. A separate consumer bg64exited0: GNUsha256sum matches the compressed archive digest; the independent tar stream has exactly all192expected input members and hashes each directly against the consuming verification manifest, including99external evaluator inputs. It also checks duplicate/absolute/traversal member names and absence of the live paid output and credential-file member. Consumer evidence lives in MAIN docs/trackers/effort-steering/evidence/headroom-admission-20261111/independent-consumer-check.json. No unit test merely restates the path expression.

## Resume
**Current2026-11-11:** Corrected preservation and independent192-input consumer verification pass. The original failure remains archived. Helper is local/uncommitted; shared-product integration is not claimed. Earlier pending statements describe the initial filing checkpoint.


2026-11-11: filed immediately in MAIN. No archive bytes existed at failure. Preserve original failure evidence; do not call an unclosed archive preserved.
