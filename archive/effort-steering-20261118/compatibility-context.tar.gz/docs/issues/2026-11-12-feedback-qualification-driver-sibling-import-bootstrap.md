---
id: e01e69346e46e7bc
kind: bug
status: mitigated
title: Feedback qualification standalone entry misses sibling runtime import bootstrap
tags:
- cluster/unclassified
- effort-steering
- qualification
closed: 2026-11-12
no_fix_commit: Versioned ignored qualification drivers only; no product code commit.
opened: 2026-11-12
owner: marius
severity: medium
unverified: Standalone v2 pause probe passes; actual native entry/preflight and full16qualification still pending.
---

# BUG: Standalone feedback qualification imports a sibling runtime before bootstrapping it

## Summary

The first real16 qualification driver fails at module import before preflight because it imports external after adding only tools/effort_protocol to sys.path. The runtime actually lives in sibling tools/agent_lifecycle. No actor, provider call, reservation or evaluator started.

## Class fit

Unclassified preparation-instrument dependency ordering: a new standalone driver assumed the sibling import setup performed indirectly by other protocol modules. Unlike a runtime grader defect, this is confined to the ignored qualification producer and is caught before any execution.

## Symptom (Effect)

probe_qualification_pause_v1.py ends with ModuleNotFoundError: No module named external while loading qualify_native_feedback_campaign_v1.py. Original successful sixteen-slot registration remains unadmitted and unchanged.

## Reproduction

Run the standalone pause probe with python3 -B, without caller-supplied PYTHONPATH. The first import fails before its five simulated transport events.

## Environment

Research worktree2aa6, Python3.14, actual CLI qualification producer versions1/2; main checkout only holds producer/evidence/bug records.

## Root cause

The entry imported external before importing the native modules that normally add sibling runtime folders. A fresh interpreter therefore differs from an already populated test interpreter.

## Evidence

Actual probe traceback points to driver line12 import external. Preparation job212011/@bg_000001b4 exited0 and produced sixteen-slot inputs, but no qualification actor was started.

## Hypotheses tried

No runtime/model or task diagnosis was attempted; failure occurs during host Python import.

## Fix

Version2 explicitly bootstraps effort_protocol, agent_lifecycle and hint_authority_pilot before loading unchanged version1 implementation as a SHA-bound dependency. New version2 preparation retains version1 registration and emits a separate final registration naming the actual version2 entry and both dependencies.

## Tests added

Standalone version1 probe reproduced the missing external import before any CLI/provider call. Version2 explicit bootstrap then ran the original five-event probe successfully: end_turn/stage1, tool_use/stage2, end_turn/stage3, tool_use/stage4, final end_turn/stage4; original plan preserved and five HTTP200 emissions. This only tests the simulated model-side turn adapter. Actual real16 qualification and gate/review remain pending.

## Workarounds

Do not rely on ambient PYTHONPATH or an earlier import. Never replace the failed source under an already registered SHA.

## Resume

Run standalone version2 pause probe, prepare new immutable registration, then actual native qualification with upstream forwarding forbidden. Keep this issue mitigated until actual entry/preflight is observed; whole project gate/review remains required.

## References

Blinded assertion boundary and native public-feedback implementation plans in docs/trackers/effort-steering/plans/.
