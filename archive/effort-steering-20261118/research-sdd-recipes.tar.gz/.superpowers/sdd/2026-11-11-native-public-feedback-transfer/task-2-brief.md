### Task 2: Wire explicit repair-only native dispatch and admission

**Files:** feedback_admission.py/test_feedback_admission.py; campaign_native.py/test_campaign_native.py; native_executor.py/test_native_executor.py; native_campaign.py/test_native_campaign.py.
**Interfaces:** `FeedbackAdmission(registration: dict, token_path: str)` validates only the new policy; `authorize(request: dict) -> None` binds exact task/attempt/phase/config/output/resource/source/cap. Existing native entry receives an explicit verified policy, never arm relabelling or an object forged as legacy PaidAdmission.

- [ ] Read actual changed contracts and callers before edits. Add failing tests: new P/R call ordinary backend once and never run_phase/submission contract; legacy P/R still three phases; legacy2continuation guard remains; new policy permits exactly4.
- [ ] Add failing tests for scope/text/effort/config mismatch, moved output, duplicate invocation, source drift, fake authorization and old proof/schedule reused as sixteen-attempt admission. All fail before transport.
- [ ] Run those direct tests and retain observed failures. Add the smallest explicit policy/version branch to existing launch/execution, sharing native launch/capture/context/runtime code. No separate feedback engine or permissive fallback.
- [ ] Preserve native result fields for actual lifecycle completion/public result as well as cost/capture/context/cleanup; tests distinguish a fully accepted public check from cutoff/incomplete/invalid.
- [ ] Run all directly affected suites. Preserve source diff/checkpoint; no publication.

