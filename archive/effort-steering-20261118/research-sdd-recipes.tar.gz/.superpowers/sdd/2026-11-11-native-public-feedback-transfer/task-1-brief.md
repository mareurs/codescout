### Task 1: Preserve baseline and implement the pure prospective policy

**Files:** create feedback_policy.py/test_feedback_policy.py in revision workspace; baseline manifest/archive and focused-test output in dated evidence.
**Interfaces:** `condition_spec(arm: str, workspace: str) -> dict` returns schema/arm/effort/phase/max_continuations/plan/check-scope; `balanced_schedule(task_ids: list[str], seed: int) -> list[dict]`; `development_screen(rows: list[dict]) -> dict`. Schema literal: `native-public-feedback-v1`; this is distinct from the closed generic-evidence policy.

- [ ] Preserve the actual cf66 qualified source inventory with hashes, own WIP patch/new files and original base identity; reopen all members. Create a separate native-managed worktree from that exact base and transplant only owned runtime files, preserving relative imports. Do not copy provenance counters or peer changes. Record initial affected-suite result.
- [ ] Add failing tests for condition dispatch: L/R ordinary scope, P/X all-target scope, added text absent only L, repair only, continuations4, X effort xhigh and others low; reject unknown arms and invalid workspace paths.
- [ ] Add failing tests for deterministic sixteen-row balanced schedule on four distinct task IDs and for development selection: gain over L with no loss, all candidate workflows closed, all16interpretable, accepted count>=X and total client cost<X; cheaper R/P wins, equal-cost tie selects R. Test unknown cost, incomplete and duplicate rows rejection.
- [ ] Run `python3 -m unittest discover -s tools/effort_protocol -p test_feedback_policy.py` and retain the observed failing result before implementation.
- [ ] Implement the three functions with exact Decimal accounting, immutable policy copy/text and source-qualified command dispatch. Run the same test command; retain output and a source snapshot.

