### Task 3: Sixteen-attempt closure, ledger and selection

**Files:** feedback_runner.py/test_feedback_runner.py; feedback_admission.py/test_feedback_admission.py; dated accounting driver/evidence.
**Interfaces:** `preflight(registration: dict, backend) -> dict`; `run_campaign(registration: dict, backend) -> dict`; `analyze(registration: dict, root: str) -> dict`. Backend invoke/grade preserve the existing request/output/capture contract; schedule comes from Task1.

- [ ] Add failing fixture tests proving all16actors/costs/captures freeze before the first grade, incomplete actors are graded, unknown charge retains reserve, source drift stops, and no existing invocation restarts.
- [ ] Add failing tests for all paired R-L/P-L/P-R/candidate-X descriptions even when selection is NO-GO. Preserve separate hidden acceptance, public/lifecycle completion, operational cutoff and invalidity.
- [ ] Run fixture failures, implement orchestration using existing source/cost/evaluator primitives, then rerun. Do not loosen old runner's cardinality or overwrite its closed result.
- [ ] Reopen original32historical native receipts plus actual16new raw receipts and normalized mappings. Reconcile48unique client sessions, opening-balance source, every current charge and the old unknown4USDhold. Test duplicate/missing/drifted/unknown records. Report invoice/root/embedding/CPU limitations.
- [ ] Produce a new source-bound reconciliation and112USDallocation proof. Decimal sums must equal185.375358899999998524USD commitment if inputs remain unchanged; otherwise stop/reconcile the actual difference. Preserve the current ledger, write a new revision.

