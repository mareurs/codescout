"""Archive concrete prepared registration, capacity refusal and reviewed growth guard."""
import hashlib
import io
import json
from pathlib import Path
import tarfile
MAIN = Path("/home/marius/work/claude/codescout")
BASE = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
OUT = MAIN / "docs/trackers/effort-steering/evidence/native-feedback-preparation-20261112"
def main():
    selected = {}
    for path in (BASE / "native-feedback-qualification-v4-registration").iterdir():
        assert path.is_file() and not path.is_symlink()
        selected["registration/" + path.name] = path
    selected["cache-decision/inventory.json"] = BASE / "closed-ledger-cache-inventory-v1.json"
    scripts = MAIN / ".superpowers/sdd/2026-11-11-native-public-feedback-transfer"
    for name in ("qualification-growth-boundaries-v1.log", "closed-ledger-cache-inventory-v1.log"):
        selected["verification/" + name] = scripts / name
    review = Path("/tmp/native-qualification-growth-review-90duaqlt")
    for path in review.iterdir():
        if path.is_file() and path.suffix in (".json", ".log", ".diff", ".py"):
            selected["review/" + path.name] = path
    selected["producer/" + Path(__file__).name] = Path(__file__).resolve()
    selected["producers-v27-manifest.json"] = OUT / "producers-v27-manifest.json"
    assert all(path.is_file() and not path.is_symlink() for path in selected.values())
    contents = {name: path.read_bytes() for name, path in sorted(selected.items())}
    archive = OUT / "fresh-qualification-preparation-v1.tar.gz"
    with tarfile.open(archive, "x:gz") as tar:
        for name, content in contents.items():
            entry = tarfile.TarInfo(name)
            entry.size, entry.mode = len(content), 0o644
            tar.addfile(entry, io.BytesIO(content))
    with tarfile.open(archive) as tar:
        assert tar.getnames() == list(contents)
        assert all(tar.extractfile(name).read() == content for name, content in contents.items())
    assert all(selected[name].read_bytes() == content for name, content in contents.items())
    sha = lambda content: hashlib.sha256(content).hexdigest()
    result = {"schema": "fresh-qualification-preparation-custody-v1", "archive": str(archive),
              "archive_bytes": archive.stat().st_size, "archive_sha256": sha(archive.read_bytes()),
              "member_count": len(contents),
              "members": {name: {"path": str(selected[name]), "bytes": len(content), "sha256": sha(content)}
                          for name, content in contents.items()},
              "all_members_reopened": True, "scope": "Prepared unlaunched registration, scoped cache decision inventory and guard review only.",
              "cleanup_performed": False, "paid_admission": False, "efficacy_claim": None}
    with (OUT / "fresh-qualification-preparation-v1.json").open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({key: value for key, value in result.items() if key != "members"}))
if __name__ == "__main__":
    main()
