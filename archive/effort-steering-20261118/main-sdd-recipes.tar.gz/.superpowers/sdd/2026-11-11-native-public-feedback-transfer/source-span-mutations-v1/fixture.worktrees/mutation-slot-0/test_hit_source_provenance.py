"""Tests for literal source spans and explicitly declared continuation context."""
from pathlib import Path
import tempfile
import unittest
from hit_source_provenance import verify_hit, SourceProvenanceError

SOURCE = """fn app() -> Element {
    let initial = 0;
    let later = initial + 1;
    later
}

fn other() {}
"""


class HitSourceProvenanceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / "project"
        self.root.mkdir()
        (self.root / "src").mkdir()
        (self.root / "src/main.rs").write_text(SOURCE)
        self.hit = {"file_path": "src/main.rs", "start_line": 3, "end_line": 4, "source": "stack",
            "content": "fn app() -> Element {\n    // ... (continued)\n    let later = initial + 1;\n    later"}

    def test_literal_span_is_verified_without_augmentation(self):
        hit = dict(self.hit, content="    let later = initial + 1;\n    later")
        result = verify_hit(self.root, hit)
        self.assertEqual(result["mode"], "literal-source-span")
        self.assertEqual(result["source_range"], [3, 4])
        self.assertTrue(result["source_span_text_verified"])
        self.assertIsNone(result["prefix_source_ranges"])

    def test_continuation_body_and_earlier_prefix_are_both_checked(self):
        result = verify_hit(self.root, self.hit)
        self.assertEqual(result["mode"], "source-span-with-declared-continuation")
        self.assertEqual(result["prefix_source_ranges"], [[1, 1]])
        self.assertTrue(result["source_span_text_verified"])
        self.assertFalse(result["ast_ownership_verified"])

    def test_wrong_body_or_range_cannot_be_hidden_by_a_real_prefix(self):
        variants = [
            dict(self.hit, content=self.hit["content"].replace("initial + 1", "initial + 999")),
            dict(self.hit, start_line=4, end_line=5),
        ]
        for hit in variants:
            with self.subTest(hit=hit), self.assertRaises(SourceProvenanceError):
                verify_hit(self.root, hit)

    def test_missing_fake_later_or_multiple_context_is_rejected(self):
        variants = [
            self.hit["content"].replace("fn app() -> Element {", "fn invented() {"),
            self.hit["content"].replace("fn app() -> Element {", "fn other() {}"),
            self.hit["content"].replace("    // ... (continued)", "    // unknown rendering"),
            self.hit["content"].replace("    // ... (continued)", "    // ... (continued)\n    // ... (continued)"),
            "\n    // ... (continued)\n    let later = initial + 1;\n    later",
            "fn app() -> Element {\n    // ... (continued)\n",
        ]
        for content in variants:
            with self.subTest(content=content), self.assertRaises(SourceProvenanceError):
                verify_hit(self.root, dict(self.hit, content=content))

    def test_full_line_bounds_and_integer_types_are_enforced(self):
        literal = dict(self.hit, content="    later")
        for field, value in [("start_line", 0), ("start_line", True), ("end_line", 999), ("end_line", "4")]:
            with self.subTest(field=field, value=value), self.assertRaises(SourceProvenanceError):
                verify_hit(self.root, dict(literal, **{field: value}))

    def test_file_path_scope_symlinks_and_source_kind_are_checked(self):
        outside = Path(self.temp.name) / "outside.rs"
        outside.write_text(SOURCE)
        (self.root / "link.rs").symlink_to(outside)
        for hit in [dict(self.hit, file_path="../outside.rs"), dict(self.hit, file_path="link.rs"),
                    dict(self.hit, file_path=str(outside)), dict(self.hit, source="other")]:
            with self.subTest(hit=hit), self.assertRaises(SourceProvenanceError):
                verify_hit(self.root, hit)

    def test_whitespace_body_and_non_object_payload_are_rejected(self):
        with self.assertRaises(SourceProvenanceError):
            verify_hit(self.root, dict(self.hit, content="  "))
        for value in (None, [], "x"):
            with self.subTest(value=value), self.assertRaises(SourceProvenanceError):
                verify_hit(self.root, value)


if __name__ == "__main__":
    unittest.main()
