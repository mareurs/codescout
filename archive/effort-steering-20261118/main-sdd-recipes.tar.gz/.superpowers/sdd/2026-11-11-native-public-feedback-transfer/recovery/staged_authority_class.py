class FeedbackAdmission:
    """Separate authority type; cannot be substituted for the legacy three-phase policy."""
    def __init__(self, registration, token_path):
        self.registration = copy.deepcopy(registration)
        validate_registration(self.registration)
        self.proof = verify_paid(self.registration)
        _require(isinstance(self.proof, dict) and self.proof.get("ready") is True,
                 "concrete repair-only evidence did not pass")
        self.token_path = self.registration["admission"]["credential_path"]
        _credential(self.token_path, token_path)
        self.fingerprint = _identity(self.registration)
        self.used = set()

    def authorize(self, request, out, public, token_path):
        _require(_identity(self.registration) == self.fingerprint, "admission registration changed")
        root=Path(self.registration["output_root"])
        _require(not any((root/name).exists() or (root/name).is_symlink()
                         for name in ("ledger-final.json","actor-batch-closed.json","result.json")),
                 "terminal campaign cannot start another actor")
        _credential(self.token_path, token_path)
        for name, digest in self.registration["bindings"].items():
            legacy._bound_path(self.registration, {"path": name, "sha256": digest})
        identity = validate_invocation(self.registration, request, out, public)
        _require(identity not in self.used, "repair-only authorization is single-use")
        self.used.add(identity)
        return {"authorized_invocation": identity}
