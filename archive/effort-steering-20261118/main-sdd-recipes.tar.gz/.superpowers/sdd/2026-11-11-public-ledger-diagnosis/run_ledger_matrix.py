"""One fixed public-only baseline/candidate diagnostic, no provider calls."""
import hashlib
import json
from pathlib import Path
import shutil
import sys

MAIN = Path('/home/marius/work/claude/codescout')
WORK = Path('/home/marius/.codex/worktrees/cf66/codescout')
OLD = Path('/var/tmp/ep11-01a15/paid-campaign-headroom-v3')
ROOT = Path('/var/tmp/ep11-01a15/public-ledger-diagnosis-v1')
sys.path.insert(0, str(WORK / 'tools/effort_protocol'))
from executor import execute_observation
from receipts import input_digest
from runner import _verify_closed


def read(path):
    return json.loads(Path(path).read_bytes())


def main():
    reg, closed = read(OLD / 'registration.json'), read(OLD / 'actor-batch-closed.json')
    _verify_closed(reg, OLD, closed)
    assert read(OLD / 'result.json')['status'] == 'completed'
    candidate = Path(closed['attempts'][2]['candidate'])
    baseline = Path(reg['tasks']['yvgude__lean-ctx-1168']['source'])
    assert input_digest(baseline) == 'b0842438b7ff5beee3bbb6ef25e78ba0291a062b6362c6c31267a1437becbe30'
    assert input_digest(candidate) == '48f6c2ec89e34e80b4570244f44a32dd37c0dd80de29154ce4935b7a9cdc4f54'
    original_digests = {str(p): input_digest(p) for p in (baseline, candidate)}
    probe = Path(__file__).with_name('ledger_matrix_probe.py')
    assert probe.is_file()
    orders = {'baseline': ['default', 'serial', 'default', 'serial', 'default'],
              'candidate': ['serial', 'default', 'serial', 'default', 'default']}
    ROOT.mkdir(exist_ok=False)
    registration = {'purpose': 'Public ledger-isolation diagnosis; no primary regrade or actor adaptation.',
        'hypothesis': 'Parallel noncooperating optimizer tests can write into the ledger directory temporarily selected by the isolated ledger test.',
        'original_source_digests': original_digests, 'orders': orders,
        'process_counts_per_source': {'default': 3, 'serial': 2},
        'provider_calls': 0, 'client_model_cost_usd': '0',
        'probe_sha256': hashlib.sha256(probe.read_bytes()).hexdigest(),
        'image': 'sha256:b72f902d24c0a54516e4ef242d8218805f0ea3dc1d26ac809140979ba1f51d56',
        'execution_profile': 'cargo-v2',
        'limits': ['Fixed diagnostic repeats are not independent task samples or replacements for primary trials.',
            'Compilation is reused within each source container; test suites run as separate processes.',
            'Default means the original libtest default, without an assumed thread count.',
            'A bounded failure-free run does not prove absence of a race.']}
    (ROOT / 'registration.json').write_text(json.dumps(registration, indent=2) + '\n')
    results = []
    for label, original in (('baseline', baseline), ('candidate', candidate)):
        assert shutil.disk_usage(ROOT).free > 85 * 1024**3
        source = ROOT / 'sources' / label
        source.parent.mkdir(exist_ok=True)
        shutil.copytree(original, source, symlinks=True)
        assert input_digest(source) == original_digests[str(original)]
        target = source / 'diagnostics/ledger_matrix_probe.py'
        target.parent.mkdir(exist_ok=True)
        shutil.copy2(probe, target)
        request = {'id': label, 'run_id': 'public-ledger-diagnosis-v1', 'phase': 'challenge',
            'kind': 'observation', 'image': registration['image'], 'execution_profile': 'cargo-v2',
            'argv': ['python3', '-I', 'diagnostics/ledger_matrix_probe.py', ','.join(orders[label])],
            'cwd': '.', 'timeout_s': 900, 'max_log_bytes': 64 * 1024**2,
            'test_files': ['rust/src/core/ocla/builtin/savings_ledger.rs',
                'rust/src/core/ocla/builtin/response_optimizer.rs', 'diagnostics/ledger_matrix_probe.py'],
            'production_files': ['rust/src/core/savings_ledger/mod.rs', 'rust/src/core/data_dir.rs',
                'rust/src/proxy/response_optimizer.rs', 'rust/src/proxy/forward/mod.rs',
                'rust/src/proxy/ocla_cache_bridge.rs', 'rust/src/core/ocla/response_cache.rs']}
        (ROOT / (label + '-request.json')).write_text(json.dumps(request, indent=2) + '\n')
        print(json.dumps({'starting_source': label, 'fixed_processes': len(orders[label])}), flush=True)
        receipt = execute_observation(request, source, ROOT / 'commands')
        assert receipt['exit_code'] == 0 and receipt['complete'] and receipt['resource_valid']
        results_path = ROOT / 'commands' / label / 'build/ledger-diagnostic-results/results.json'
        rows = read(results_path)['processes']
        assert [row['mode'] for row in rows] == orders[label]
        results.append({'source': label, 'processes': rows, 'receipt': receipt})
        assert input_digest(original) == original_digests[str(original)]
        print(json.dumps({'completed_source': label, 'outcomes': [{k: row[k] for k in
            ('mode', 'returncode', 'passed', 'failed', 'failed_tests')} for row in rows]}), flush=True)
    _verify_closed(reg, OLD, closed)
    assert all(input_digest(Path(p)) == digest for p, digest in original_digests.items())
    (ROOT / 'results.json').write_text(json.dumps({'results': results,
        'all_original_sources_unchanged': True, 'provider_calls': 0, 'client_model_cost_usd': '0'}, indent=2) + '\n')


if __name__ == '__main__':
    main()
