"""Independently reparse and preserve the fixed public diagnostic, no reruns."""
import collections
import hashlib
import io
import json
import os
from pathlib import Path
import sys
import tarfile

MAIN = Path('/home/marius/work/claude/codescout')
WORK = Path('/home/marius/.codex/worktrees/cf66/codescout')
ROOT = Path('/var/tmp/ep11-01a15/public-ledger-diagnosis-v1')
OLD = Path('/var/tmp/ep11-01a15/paid-campaign-headroom-v3')
PACKAGE = Path('/var/tmp/ep11-01a15/private-package/evaluator/source/tools/setup-ab-eval')
DEST = MAIN / 'docs/trackers/effort-steering/evidence/public-ledger-diagnosis-20261111'
sys.path[:0] = [str(WORK / 'tools/effort_protocol'), str(PACKAGE)]
from runner import _verify_closed
from receipts import input_digest
from multilang_grade import run_parser


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def main():
    registration, result = read(ROOT / 'registration.json'), read(ROOT / 'results.json')
    reg, closed = read(OLD / 'registration.json'), read(OLD / 'actor-batch-closed.json')
    _verify_closed(reg, OLD, closed)
    assert result['all_original_sources_unchanged'] is True
    assert all(input_digest(Path(p)) == digest for p, digest in registration['original_source_digests'].items())
    record_path = Path('/var/tmp/ep11-01a15/private-package/lean/native-controls/full-record.json')
    parser_src = read(record_path)['log_parser']
    observed, payload = [], {}
    for path in (ROOT / 'registration.json', ROOT / 'results.json',
                 ROOT / 'baseline-request.json', ROOT / 'candidate-request.json'):
        payload[path.relative_to(ROOT).as_posix()] = path
    for cell in result['results']:
        label = cell['source']
        directory = ROOT / 'commands' / label
        receipt = read(directory / 'receipt.json')
        assert receipt['cleanup_complete'] and receipt['capture_complete'] and receipt['resource_valid']
        assert receipt['source_before'] == receipt['source_after'] == cell['receipt']['source_digest']
        assert input_digest(directory / 'input') == receipt['source_before']
        assert receipt['final_container_state']['OOMKilled'] is False
        assert receipt['final_container_state']['Status'] == 'exited'
        for row in cell['processes']:
            stdout = directory / 'build/ledger-diagnostic-results' / f"{row['index']}-{row['mode']}.stdout"
            stderr = stdout.with_suffix('.stderr')
            assert sha(stdout) == row['stdout_sha256'] and sha(stderr) == row['stderr_sha256']
            statuses = run_parser(parser_src, stdout.read_text())
            counts = collections.Counter(statuses.values())
            assert len(statuses) == row['parsed_status_count']
            assert counts['pass'] == row['passed'] and counts['fail'] == row['failed']
            assert counts['skip'] == row['ignored']
            assert sorted(k for k, v in statuses.items() if v == 'fail') == sorted(row['failed_tests'])
            observed.append({'source': label, **row, 'independent_parser_counts': dict(counts),
                'independent_status_map_sha256': hashlib.sha256(json.dumps(statuses, sort_keys=True).encode()).hexdigest()})
        for path in sorted(directory.iterdir()):
            if path.is_file():
                payload[path.relative_to(ROOT).as_posix()] = path
        for subtree in (directory / 'input', directory / 'build/ledger-diagnostic-results'):
            for path in (subtree, *sorted(subtree.rglob('*'))):
                payload[path.relative_to(ROOT).as_posix()] = path
    assert len(observed) == 10
    assert collections.Counter((r['source'], r['mode']) for r in observed) == {
        ('baseline', 'default'): 3, ('baseline', 'serial'): 2,
        ('candidate', 'default'): 3, ('candidate', 'serial'): 2}
    assert sum(r['failed'] > 0 for r in observed) == 1
    failure = next(r for r in observed if r['failed'])
    assert failure['source'] == 'candidate' and failure['mode'] == 'default'
    assert failure['failed_tests'] == ['core::ocla::builtin::savings_ledger::tests::delegates_to_verified_ledger']
    summary = []
    for label in ('baseline', 'candidate'):
        for mode in ('default', 'serial'):
            rows = [r for r in observed if (r['source'], r['mode']) == (label, mode)]
            summary.append({'source': label, 'mode': mode, 'suite_processes': len(rows),
                'passing_suite_processes': sum(r['returncode'] == 0 for r in rows),
                'failing_suite_processes': sum(r['returncode'] != 0 for r in rows)})
    DEST.mkdir(exist_ok=False)
    parser_path = DEST / 'parser.py'
    parser_path.write_text(parser_src)
    audit = {'schema': 'public-ledger-independent-audit-v1', 'rows': observed, 'summary': summary,
        'qualified_parser_record': {'path': str(record_path), 'sha256': sha(record_path)},
        'parser_sha256': sha(parser_path), 'all_ten_raw_status_censuses_match': True,
        'all_original_sources_unchanged': True, 'provider_calls': 0, 'client_model_cost_usd': '0',
        'limits': ['Repeat units are public test-suite processes, not independent repair tasks.',
            'Candidate nondeterminism established; baseline failure not observed in the bounded matrix.',
            'Shared-path noncooperating writers are source-confirmed, not an instrumented attribution of the original writer.',
            'Serial observations support a prospective workaround, not a permanent source fix.',
            'Primary model results, charges and original failing public receipt remain unchanged.']}
    audit_path = DEST / 'audit.json'
    audit_path.write_text(json.dumps(audit, indent=2) + '\n')
    payload['audit.json'], payload['parser.py'] = audit_path, parser_path
    helpers = Path(__file__).parent
    for path in sorted(helpers.rglob('*')):
        if path.is_file():
            payload['helpers/' + path.relative_to(helpers).as_posix()] = path
    manifest = {}
    for name, path in payload.items():
        manifest[name] = ({'type': 'symlink', 'target': os.readlink(path)} if path.is_symlink()
            else {'type': 'directory'} if path.is_dir()
            else {'type': 'file', 'bytes': path.stat().st_size, 'sha256': sha(path)})
    archive = DEST / 'evidence.tar.gz'
    with tarfile.open(archive, 'x:gz', format=tarfile.PAX_FORMAT, compresslevel=1) as target:
        for name, path in payload.items():
            item = manifest[name]
            member = tarfile.TarInfo(name)
            member.mode = 0o600
            if item['type'] == 'directory':
                member.type = tarfile.DIRTYPE
                target.addfile(member)
            elif item['type'] == 'symlink':
                member.type, member.linkname = tarfile.SYMTYPE, item['target']
                target.addfile(member)
            else:
                member.size = item['bytes']
                with path.open('rb') as stream:
                    target.addfile(member, stream)
        raw = json.dumps(manifest, indent=2, sort_keys=True).encode()
        member = tarfile.TarInfo('manifest.json')
        member.size = len(raw)
        target.addfile(member, io.BytesIO(raw))
    seen = set()
    with tarfile.open(archive, 'r:gz') as source:
        for member in source:
            if member.name == 'manifest.json':
                assert json.load(source.extractfile(member)) == manifest
                continue
            assert member.name not in seen
            seen.add(member.name)
            item = manifest[member.name]
            if item['type'] == 'file':
                assert member.isfile()
                data = source.extractfile(member).read()
                assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
            elif item['type'] == 'symlink':
                assert member.issym() and member.linkname == item['target']
            else:
                assert member.isdir()
    assert seen == set(manifest)
    assert all(sha(path) == manifest[name]['sha256'] for name, path in payload.items()
               if manifest[name]['type'] == 'file')
    _verify_closed(reg, OLD, closed)
    closure = {'archive': str(archive), 'archive_bytes': archive.stat().st_size,
        'archive_sha256': sha(archive), 'payload_entries': len(payload),
        'all_selected_payloads_reopened': True, 'all_selected_originals_unchanged_at_closure': True,
        'scope': 'Both full actual input snapshots, ten process logs, two closed runtime receipts/inspections, audit/parser/helper sources; compiler caches omitted and untouched.'}
    (DEST / 'closure.json').write_text(json.dumps(closure, indent=2) + '\n')
    print(json.dumps({'summary': summary, 'audit_sha256': sha(audit_path), 'closure': closure}))


if __name__ == '__main__':
    main()
