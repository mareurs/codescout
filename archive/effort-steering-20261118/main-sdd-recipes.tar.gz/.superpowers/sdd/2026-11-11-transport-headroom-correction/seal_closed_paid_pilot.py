"""Seal closed paid evidence, explicitly omitting verified command build caches."""
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import sys
import tarfile

MAIN = Path('/home/marius/work/claude/codescout')
WORK = Path('/home/marius/.codex/worktrees/cf66/codescout')
ROOT = Path('/var/tmp/ep11-01a15/paid-campaign-headroom-v3')
DEST = MAIN / 'docs/trackers/effort-steering/evidence/closed-paid-pilot-20261111'
sys.path.insert(0, str(WORK / 'tools/effort_protocol'))
from runner import _verify_closed


def read(path):
    return json.loads(Path(path).read_bytes())


def sha(path, secret=None):
    digest, previous = hashlib.sha256(), b''
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            if secret is not None:
                assert secret not in previous + block, 'credential bytes in selected file: ' + str(path)
                previous = block[-len(secret):]
            digest.update(block)
    return digest.hexdigest()


def main():
    result, reg, closed = (read(ROOT / name) for name in
                           ('result.json', 'registration.json', 'actor-batch-closed.json'))
    assert result['status'] == 'completed' and len(result['attempts']) == 8
    assert all(row['grade']['valid'] is True for row in result['attempts'])
    assert not Path('/proc/633049').exists(), 'original controller still present; inspect before custody'
    _verify_closed(reg, ROOT, closed)
    # Exclude only exact per-command writable build mounts. Source snapshots,
    # probes, all logs/receipts and before/after container inspections are kept.
    omitted = {}
    for path in sorted(ROOT.glob('attempts/*/*/protocol/commands/*/build')):
        assert path.is_dir() and not path.is_symlink()
        before = read(path.parent / 'container-before.json')
        mounts = before['HostConfig']['Mounts']
        assert any(m['Source'] == str(path) and m['Target'] == '/build' for m in mounts)
        assert 'CARGO_TARGET_DIR=/build/target' in before['Config']['Env']
        omitted[path] = {'path': str(path), 'role': 'verified writable compiler/scratch build mount',
                         'metadata': str(path.parent / 'container-before.json')}
    entries = {}

    def add_tree(root, prefix):
        entries[prefix] = root
        for directory, dirs, files in os.walk(root, followlinks=False):
            current = Path(directory)
            dirs[:] = sorted(name for name in dirs if current / name not in omitted)
            for name in dirs + sorted(files):
                path = current / name
                entries[prefix + '/' + path.relative_to(root).as_posix()] = path

    add_tree(ROOT, 'paid-campaign-headroom-v3')
    for name in ('closed-campaign-audit-20261111', 'paired-pilot-results-20261111',
                 'public-process-audit-20261111'):
        add_tree(MAIN / 'docs/trackers/effort-steering/evidence' / name, 'derived/' + name)
    entries['helpers/seal_closed_paid_pilot.py'] = Path(__file__)
    for name in ('2026-11-11-closed-generic-repair-pilot.md',
                 '2026-11-11-prospective-public-process-audit.md'):
        entries['reports/' + name] = MAIN / 'docs/trackers/effort-steering/reports' / name
    credential_path = Path(reg['admission']['credential_path'])
    assert not credential_path.is_relative_to(ROOT)
    secret = credential_path.read_bytes().strip()
    assert len(secret) >= 16
    manifest = {}
    for name, path in entries.items():
        assert credential_path != path
        if path.is_symlink():
            item = {'type': 'symlink', 'target': os.readlink(path)}
        elif path.is_dir():
            item = {'type': 'directory'}
        elif path.is_file():
            item = {'type': 'file', 'bytes': path.stat().st_size, 'sha256': sha(path, secret)}
        else:
            raise ValueError('special artifact: ' + str(path))
        manifest[name] = item
    secret = None
    selected_bytes = sum(item.get('bytes', 0) for item in manifest.values())
    assert shutil.disk_usage(MAIN).free > selected_bytes + 82 * 1024**3
    provenance = {'schema': 'effort-closed-paid-custody-v1',
        'scope': 'Closed eight-attempt paid pilot, all non-build payloads, exact derived audits and report snapshots.',
        'excluded_build_mounts': list(omitted.values()), 'omitted_builds_deleted': False,
        'credential_literal_scan': 'all selected regular files scanned; no credential bytes matched',
        'limits': ['Compiler/scratch mount contents omitted; original directories untouched.',
            'Symlink target strings retained; external referents not implicitly embedded.',
            'Docker images, external runtime binaries and prior-series evidence remain referenced by hashes.',
            'Report snapshots may retain pending-custody text from before this archive closed.',
            'No provider calls, score changes, reruns or cleanup.']}
    DEST.mkdir(exist_ok=False)
    archive = DEST / 'evidence.tar.gz'
    print(json.dumps({'selected_payload_entries': len(entries), 'selected_regular_bytes': selected_bytes,
                      'excluded_build_mounts': len(omitted)}), flush=True)
    with tarfile.open(archive, 'x:gz', format=tarfile.PAX_FORMAT, compresslevel=1) as target:
        for name, path in entries.items():
            item = manifest[name]
            member = tarfile.TarInfo(name)
            member.mode = 0o600
            if item['type'] == 'directory':
                member.type, member.mode = tarfile.DIRTYPE, 0o700
                target.addfile(member)
            elif item['type'] == 'symlink':
                member.type, member.linkname = tarfile.SYMTYPE, item['target']
                target.addfile(member)
            else:
                member.size = item['bytes']
                with path.open('rb') as stream:
                    target.addfile(member, stream)
        for name, value in (('manifest.json', manifest), ('provenance.json', provenance)):
            raw = json.dumps(value, indent=2, sort_keys=True).encode()
            member = tarfile.TarInfo(name)
            member.mode, member.size = 0o600, len(raw)
            target.addfile(member, io.BytesIO(raw))
    seen = set()
    with tarfile.open(archive, 'r:gz') as source:
        for member in source:
            if member.name in ('manifest.json', 'provenance.json'):
                expected = manifest if member.name == 'manifest.json' else provenance
                assert json.load(source.extractfile(member)) == expected
                continue
            assert member.name not in seen
            seen.add(member.name)
            item = manifest[member.name]
            if item['type'] == 'file':
                assert member.isfile()
                digest, size = hashlib.sha256(), 0
                with source.extractfile(member) as stream:
                    for block in iter(lambda: stream.read(1024 * 1024), b''):
                        digest.update(block)
                        size += len(block)
                assert size == item['bytes'] and digest.hexdigest() == item['sha256']
            elif item['type'] == 'symlink':
                assert member.issym() and member.linkname == item['target']
            else:
                assert member.isdir()
    assert seen == set(manifest)
    assert all(sha(path) == manifest[name]['sha256'] for name, path in entries.items()
               if manifest[name]['type'] == 'file')
    assert all(os.readlink(path) == manifest[name]['target'] for name, path in entries.items()
               if manifest[name]['type'] == 'symlink')
    _verify_closed(reg, ROOT, closed)
    closure = {'schema': 'effort-closed-paid-closure-v1', 'archive': str(archive),
        'archive_bytes': archive.stat().st_size, 'archive_sha256': sha(archive),
        'payload_entries': len(entries), 'regular_payloads': sum(v['type'] == 'file' for v in manifest.values()),
        'selected_regular_bytes': selected_bytes, 'omitted_build_mounts': len(omitted),
        'all_selected_payloads_reopened': True, 'all_selected_originals_unchanged': True,
        'original_build_caches_untouched': True, 'credential_bytes_absent_from_selected_payloads': True}
    (DEST / 'closure.json').write_text(json.dumps(closure, indent=2) + '\n')
    print(json.dumps(closure), flush=True)


if __name__ == '__main__':
    main()
