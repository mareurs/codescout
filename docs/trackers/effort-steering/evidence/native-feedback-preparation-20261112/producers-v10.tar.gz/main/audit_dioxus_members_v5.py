"""Reopen every configured Dioxus member checkpoint; no index/onboarding/model call."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
sys.dont_write_bytecode = True
import index_prepared_members_v2 as engine
from hit_source_provenance import verify_hit

root = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/DioxusLabs__dioxus-5384/common-preparation-v1")
out = root / "configured-member-qualification-v5"
load = lambda p: json.loads(p.read_bytes())
reg = load(out / "registration.json")
result = load(out / "result.json")
prep = load(root / "preparation.json")
members = [r for r in prep["configured_projects"] if r["root"] != "."]
assert len(members) == len({r["id"] for r in members}) == 114
assert reg["members"] == sorted(members, key=lambda e: (e["id"] == Path(e["root"]).name, e["root"], e["id"]))
assert all(engine.sha(path) == digest for path, digest in reg["bindings"].items())
assert result["all_configured_members_checked"] and len(result["members"]) == len(members)
assert {r["id"]:r["root"] for r in result["members"]} == {r["id"]:r["root"] for r in members}
assert engine._public_digest(root / "project") == reg["public_source_sha256"] == prep["template_public_sha256"]
hits = 0
for member in result["members"]:
    directory = out / "members" / member["id"]
    assert load(directory / "result.json") == member
    assert engine.sha(directory / "semantic.json") == member["semantic_sha256"]
    assert engine.sha(directory / "source-provenance.json") == member["provenance_sha256"]
    state = root / "project" / member["root"] / ".codescout/index-state.json"
    assert load(state) == load(directory / "index-state.json")
    assert load(state)["indexed_with_model"] == "CodeRankEmbed"
    if member["index_reused"]:
        reused = load(directory / "reused-index.json")
        assert engine.sha(reused["prior_command"]) == reused["prior_command_sha256"]
        assert load(Path(reused["prior_command"]))["returncode"] == 0
        assert engine.sha(state) == reused["state_sha256"]
        assert engine.sha(reused["prior_state"]) == reused["prior_state_sha256"]
    else:
        assert load(directory / "command.json")["returncode"] == 0
    response = load(directory / "semantic.json")
    payload = json.loads(response["result"]["content"][0]["text"])
    checked = [verify_hit(root / "project" / member["root"], hit) for hit in payload["results"]]
    assert checked == load(directory / "source-provenance.json")
    assert len(checked) == member["returned_hits_checked"]
    hits += len(checked)
native = load(out / "native/cleanup.json")
embedding = load(out / "embedding/cleanup.json")
assert native["cleanup_complete"] and embedding["complete"]
absence = []
for kind, identity in (("container", native["container"]), ("container", embedding["proxy"]),
                       ("network", embedding["network_id"])):
    process = subprocess.run(["docker", kind, "inspect", identity], capture_output=True, text=True, timeout=30)
    assert process.returncode != 0 and "No such" in process.stderr, (kind, identity, process.stderr)
    absence.append({"kind":kind, "id":identity, "returncode":process.returncode,
                    "stderr_sha256":hashlib.sha256(process.stderr.encode()).hexdigest()})
audit = {"schema":"dioxus-member-checkpoint-audit-v1", "configured_nonroot_count":len(members),
         "reopened_member_results":len(result["members"]), "reopened_returned_hits":hits,
         "new_explicit_index_cli_calls":sum(not r["index_reused"] for r in result["members"]),
         "reused_index_commands":sum(r["index_reused"] for r in result["members"]),
         "all_bindings_and_source_unchanged":True, "fresh_absence":absence,
         "client_model_calls":0, "onboarding_calls":0, "paid_ready":False,
         "scope":"Payload text/namespace/custody only; no relevance, AST ownership, author context or repair-quality conclusion."}
target = Path("docs/trackers/effort-steering/evidence/native-feedback-preparation-20261112/dioxus-members-v5-audit.json")
with target.open("x") as stream:
    json.dump(audit, stream, sort_keys=True, indent=2)
print(json.dumps(audit, sort_keys=True))
