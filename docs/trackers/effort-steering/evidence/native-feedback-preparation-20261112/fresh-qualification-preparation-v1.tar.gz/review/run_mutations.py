from pathlib import Path
import difflib,hashlib,json,os,re,shutil,subprocess
root=Path(__file__).parent
mutations=[
 {'id':'G01','file':'qualify_native_feedback_campaign_v4.py','area':'normal launch growth headroom','old':'minimum = floor + 12 * 1024**3','new':'minimum = floor'},
 {'id':'G02','file':'qualify_native_feedback_resume_v5.py','area':'resume control copied growth headroom','old':'minimum = next(iter(floors)) + 12 * 1024**3','new':'minimum = next(iter(floors))'},
 {'id':'G03','file':'qualify_native_feedback_resume_v5.py','area':'resume cannot lower original registered80GiBfloor','old':'assert floors == {80 * 1024**3} and len(roots) == 1','new':'assert len(floors) == 1 and len(roots) == 1'}
]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(root/'mutations.json').write_text(json.dumps(mutations,indent=2)+'\n');results=[]
for m in mutations:
 dst=root/m['id'];shutil.copytree(root/'baseline',dst)
 p=dst/m['file'];old=p.read_text();mode=p.stat().st_mode&0o777;assert old.count(m['old'])==1
 new=old.replace(m['old'],m['new']);p.chmod(mode|0o200);p.write_text(new);p.chmod(mode)
 diff=root/(m['id']+'.diff');diff.write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+m['file'],tofile='b/'+m['file'])))
 log=root/(m['id']+'.log');env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TMPDIR='/var/tmp',PYTHONPATH=str(dst/'tools/effort_protocol'))
 with log.open('w') as out:
  run=subprocess.run(['python3','-B','-m','unittest','-v','test_qualification_growth_v4','test_resume_qualification_v5'],cwd=dst,env=env,stdout=out,stderr=subprocess.STDOUT)
 text=log.read_text();counts=re.findall(r'^Ran (\d+) tests? in ([0-9.]+)s$',text,re.M);ending=re.findall(r'^(?:OK|FAILED)(?: .*|$)',text,re.M)
 valid=bool(counts) and int(counts[-1][0])==14 and bool(ending)
 row={k:v for k,v in m.items() if k not in ('old','new')};row.update(exit=run.returncode,tests=int(counts[-1][0]) if counts else None,summary=ending[-1] if ending else None,verdict=('SURVIVED' if run.returncode==0 else 'KILLED') if valid else 'INCONCLUSIVE',mode=oct(mode),log=str(log),log_sha256=sha(log),diff=str(diff),diff_sha256=sha(diff),mutant_sha256=sha(p),baseline_sha256=hashlib.sha256(old.encode()).hexdigest())
 results.append(row);(root/(m['id']+'.json')).write_text(json.dumps(row,indent=2)+'\n')
(root/'mutation-results.json').write_text(json.dumps(results,indent=2)+'\n')
compiled=[]
for p in (root/'baseline').glob('*.py'):
 compile(p.read_bytes(),str(p),'exec');compiled.append(p.name)
(root/'compiled-scripts.json').write_text(json.dumps(compiled,indent=2)+'\n')
print(json.dumps({'results':results,'counts':{'killed':sum(r['verdict']=='KILLED' for r in results),'survived':sum(r['verdict']=='SURVIVED' for r in results),'inconclusive':sum(r['verdict']=='INCONCLUSIVE' for r in results)}},indent=2))
