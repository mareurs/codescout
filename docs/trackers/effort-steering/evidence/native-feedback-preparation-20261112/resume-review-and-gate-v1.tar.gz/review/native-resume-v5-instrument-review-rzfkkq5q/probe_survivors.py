from pathlib import Path
import json,subprocess,sys,tempfile
root=Path(__file__).parent;which,case=sys.argv[1:]
sys.path[:0]=[str(root/which),str(root/which/'tools/effort_protocol')]
from resume_qualification_instruments_v5 import ProcessObservation,frozen_inputs
from test_resume_qualification_v5 import SnapshotControls
if case=='reentry':
 observer=ProcessObservation(set(),{'/bin/true'})
 with observer:subprocess.run(['/bin/true','--session-id','initial-probe'],check=True)
 observer.phase='resume'
 with observer:subprocess.run(['/bin/true','--session-id','resume-probe'],check=True)
 result={'copy':which,'case':case,'rows':observer.rows()}
else:
 with tempfile.TemporaryDirectory(prefix='v5-link-probe-',dir='/var/tmp') as directory:
  base=Path(directory);initial,receipt,audit=SnapshotControls().fixture(base)
  alternate=audit.parent/'alternate.json';alternate.write_bytes(audit.read_bytes())
  link=audit.parent/'existing-link';link.symlink_to('descriptor.json')
  before=frozen_inputs(base,initial)
  link.unlink();link.symlink_to('alternate.json')
  after=frozen_inputs(base,initial)
  result={'copy':which,'case':case,'retarget_detected':before!=after,'before':before['entries'][str(link)],'after':after['entries'][str(link)]}
print(json.dumps(result))
