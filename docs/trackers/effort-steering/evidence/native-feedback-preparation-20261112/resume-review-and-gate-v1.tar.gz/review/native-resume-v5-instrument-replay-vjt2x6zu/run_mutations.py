from pathlib import Path
import difflib,hashlib,json,os,re,shutil,subprocess
root=Path(__file__).parent
mutations=[
 {'id':'V01','area':'phase identity captured at actual process launch','old':'self.processes.append((self.phase, kind, list(command), process))','new':'self.processes.append(("initial", kind, list(command), process))'},
 {'id':'V02','area':'audit descriptor tree in frozen snapshot','old':'for tree in (root / "attempts", root / "audits"):','new':'for tree in (root / "attempts",):'},
 {'id':'V03','area':'actual process completion status','old':'"returncode": process.poll()','new':'"returncode": 0'},
 {'id':'V04','area':'observer reentered for resume phase','old':'        self.patcher.start()','new':'        if not self.processes:\n            self.patcher.start()'},
 {'id':'V05','area':'existing evidence symlink target identity','old':'target=os.readlink(path)','new':'target="<ignored>"'}
]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(root/'mutations.json').write_text(json.dumps(mutations,indent=2)+'\n')
results=[]
for m in mutations:
 dst=root/m['id'];shutil.copytree(root/'baseline',dst)
 p=dst/'resume_qualification_instruments_v5.py';old=p.read_text();assert old.count(m['old'])==1
 new=old.replace(m['old'],m['new']);p.write_text(new)
 diff=root/(m['id']+'.diff');diff.write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/resume_qualification_instruments_v5.py',tofile='b/resume_qualification_instruments_v5.py')))
 log=root/(m['id']+'.log')
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TMPDIR='/var/tmp',PYTHONPATH=str(dst/'tools/effort_protocol'))
 with log.open('w') as out:
  run=subprocess.run(['python3','-B','-m','unittest','-v','test_resume_qualification_v5'],cwd=dst,env=env,stdout=out,stderr=subprocess.STDOUT)
 text=log.read_text();counts=re.findall(r'^Ran (\d+) tests? in ([0-9.]+)s$',text,re.M);ending=re.findall(r'^(?:OK|FAILED)(?: .*|$)',text,re.M)
 valid=bool(counts) and int(counts[-1][0])==7 and bool(ending)
 row={'id':m['id'],'area':m['area'],'exit':run.returncode,'tests':int(counts[-1][0]) if counts else None,'summary':ending[-1] if ending else None,'verdict':('SURVIVED' if run.returncode==0 else 'KILLED') if valid else 'INCONCLUSIVE','log':str(log),'log_sha256':sha(log),'diff':str(diff),'diff_sha256':sha(diff),'mutant_sha256':sha(p),'baseline_sha256':hashlib.sha256(old.encode()).hexdigest()}
 results.append(row);(root/(m['id']+'.json')).write_text(json.dumps(row,indent=2)+'\n')
(root/'mutation-results.json').write_text(json.dumps(results,indent=2)+'\n')
compiled=[]
for p in (root/'baseline').glob('*.py'):
 compile(p.read_bytes(),str(p),'exec');compiled.append(p.name)
(root/'compiled-scripts.json').write_text(json.dumps(compiled,indent=2)+'\n')
print(json.dumps({'results':results,'compiled':compiled,'counts':{'killed':sum(x['verdict']=='KILLED' for x in results),'survived':sum(x['verdict']=='SURVIVED' for x in results),'inconclusive':sum(x['verdict']=='INCONCLUSIVE' for x in results)}},indent=2))
