from pathlib import Path
import hashlib,json,re
root=Path(__file__).parent;old=Path('/tmp/native-resume-v5-instrument-review-rzfkkq5q')
scripts=Path('/home/marius/work/claude/codescout/.superpowers/sdd/2026-11-11-native-public-feedback-transfer')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((root/'custody-before.json').read_text());custody={'scratch_baseline_changes':[],'instrument_original_changes':[],'final_script_sha256':{}}
for name,value in manifest.items():
 p=root/'baseline'/name
 if not p.exists() or sha(p)!=value:custody['scratch_baseline_changes'].append(name)
 if '/' not in name:
  p=scripts/name;custody['final_script_sha256'][name]=sha(p)
  if sha(p)!=value:custody['instrument_original_changes'].append(name)
(root/'custody-after.json').write_text(json.dumps(custody,indent=2)+'\n')
results=json.loads((root/'mutation-results.json').read_text())
failures={r['id']:re.findall(r'^(?:FAIL|ERROR): .*$',Path(r['log']).read_text(),re.M) for r in results}
(root/'failure-sites.json').write_text(json.dumps(failures,indent=2)+'\n')
report={
 'scope':'V5 qualifier and process/snapshot instruments only. Read-only originals; scratch applied mutations and real harmless local subprocess/filesystem controls. No original evaluator, author CLI, Docker, provider or qualification launched.',
 'baseline':json.loads((root/'baseline-result.json').read_text()),
 'final_mutation_counts':{'applied':5,'killed':5,'survived':0,'inconclusive':0,'tests_per_mutant':7},
 'pre_regression_counts':{'baseline_tests':5,'applied':5,'killed':3,'survived':2,'inconclusive':0,'evidence':str(old/'mutation-results.json')},
 'resolved_findings':[
  {'id':'V04','category':'Important calibration test gap','file':'resume_qualification_instruments_v5.py','line':44,'observed_before':'Starting observer only in first with context left5tests green and missed an actual second /bin/true process in a separate resume context.','resolution':'New consuming two-context regression kills exact mutation with7tests; original helper was correct.'},
  {'id':'V05','category':'Important calibration test gap','file':'resume_qualification_instruments_v5.py','line':79,'observed_before':'Replacing link targets by constant left5tests green and missed retargeting an existing audit symlink between same-byte files.','resolution':'New existing-link retarget regression kills exact mutation with7tests; original helper was correct.'},
  {'id':'fresh-backend-authorization','category':'Important driver correctness defect, found by root','file':'qualify_native_feedback_resume_v5.py','line':87,'observed_before':'Independent fresh-constructor probe reproduces AttributeError from direct authorization read before restore. Constructor initializes registration/identity/invocations/audit_inputs only.','resolution':'V5 now checks registration is None and getattr(authorization,None) is None before restore; explicit authorization None and closed_only True checks remain after restore. Probe confirms corrected precondition. V4 retains original defect and remains unrun.'}
 ],
 'api_validation':[
  'Actual production session.run_session calls parent subprocess.Popen; private grade subprocess.run calls that same seam. Registered CLI path originates in public.runtime.files.cli.path and production argv includes --session-id. Private grade uses exact six-element sys.executable,-I,-B,entry,request,out argv matched by observer.',
  'Observer saves phase, kind, argv and actual Popen object; rows obtain real PID and poll returncode. It retains history across two context entries; driver calibrates initial CLI PID population against lifecycle receipts and requires no initial private entries/no resumed CLI.',
  'V5 snapshot records files/directories/symlinks, modes, byte hashes and link targets under attempts and audits; full candidate input_digest remains separate. Only three native working-cache trees are excluded.',
  'Driver currently compares exact complete snapshots, not an originals-only subset; added attempts/audits evidence is refused. Separate grades/final root outputs are excluded. Current resume code reuses recorded audit descriptors, so no identified API mismatch follows.',
  'All three V5 scripts plus unchanged v1 transport dependency compile without importing or running the actual qualifier.'
 ],
 'measurement_limits':[
  'Observer is scoped to registered launch shapes through this Python parent Popen seam; it is not machine-wide or descendant-process census. Successful spawns are measured, not all possible attempted process creations.',
  'Local calibration uses /bin/true and harmless temporary Python scripts; matching actual registered author CLI and evaluator PIDs remains part of unexecuted runtime control.',
  'Registration/dependency hashes, readonly freeze, resource admission and full qualification execution are future separate work outside this review.'
 ],
 'declined_to_judge':[
  'Preregistration readiness or actual sixteen-attempt/resume qualification success; neither bound nor executed by reviewer.',
  'Normal v3 stopped-resource result, current host resource availability or gate status; parent owns these observations.',
  'Original U04 production regression closure; previously demonstrated survivor, root is handling tests separately.',
  'Efficacy, provider behavior, actual private evaluation and total/root/review/CPU/embedding cost; no such run and unknown cost is not zero.'
 ],
 'verdict':'Focused V5 instrument/code review passes after the constructor correction and exact survivor regressions. No open Important finding remains in this reviewed instrument delta. This is not a preregistration, launch, full-runtime, merge, or efficacy verdict.',
 'preserved_evidence':{'pre_regression_probes':str(old/'consumer-probe-results.json'),'constructor_probe':str(old/'constructor-probe.json'),'pre_regression_mutations':str(old/'mutation-results.json')},
 'custody':custody
}
(root/'review-report.json').write_text(json.dumps(report,indent=2)+'\n')
evidence={p.name:sha(p) for p in root.iterdir() if p.is_file() and p.name!='evidence-manifest.json'}
(root/'evidence-manifest.json').write_text(json.dumps(evidence,indent=2)+'\n')
print(json.dumps({'report':str(root/'review-report.json'),'report_sha256':sha(root/'review-report.json'),'manifest_sha256':sha(root/'evidence-manifest.json'),'custody':custody,'failure_sites':failures},indent=2))
