from pathlib import Path
import hashlib,json
root=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
results=json.loads((root/'mutation-results.json').read_text())
report={
 'scope':'Unrun qualification-only resume v4 preparer/driver, plan12a40a83ebe82821 new section, actual production resume/rehydration/audit/grade API call sites; no source or script originals changed',
 'baseline':json.loads((root/'baseline-result.json').read_text()),
 'mutations':{'applied':len(results),'killed':sum(r['verdict']=='KILLED' for r in results),'survived':sum(r['verdict']=='SURVIVED' for r in results),'inconclusive':0,'tests_per_mutant':70,'modules':json.loads((root/'test-modules.json').read_text())},
 'findings':[
  {'severity':'Important','category':'qualification instrumentation defect','file':'.superpowers/sdd/2026-11-11-native-public-feedback-transfer/qualify_native_feedback_resume_v4.py','line':137,'title':'Pre-resume private-process zero is unmeasured','evidence':'private_processes_before_resume is literal0; measured subprocess.run wrapper is installed only around resume at104-117, after initial run_campaign. No-grades-directory and null-grade assertions observe artifacts, not process entry.','effect':'Control cannot substantiate the planned zero private executions before the all-audit barrier; an early evaluator execution with suppressed/elsewhere output would not be observed.','status':'Parent acknowledged; v4 remains unrun/unbound and planned version5 will measure both phases.'},
  {'severity':'Important','category':'qualification snapshot scope defect','file':'.superpowers/sdd/2026-11-11-native-public-feedback-transfer/qualify_native_feedback_resume_v4.py','line':31,'title':'Original audit descriptor bytes are outside frozen snapshot','evidence':'Applied scratch probe changes existing root/audits/opaque/descriptor.json and frozen_inputs stays identical. Final analyze checks stored index but does not reopen all descriptor bytes after final evaluator.','effect':'Cannot support all original integrity evidence unchanged through resume. Native receipt byte changes and captured candidate mode changes were detected in calibration.','limitation':'Native evidence modes/new symlinks also not represented; regular-file byte custody is narrower than full input_digest custody. No current production mutation or exploit claimed.'},
  {'severity':'Important','category':'production regression gap','file':'tools/effort_protocol/native_campaign.py','line':205,'title':'Rehydration invocation receipt binding can disappear with70tests green','mutation':'U04 removes standalone invocation SHA and parsed-content equality checks at restore_closed consuming call site.','evidence':'Pristine restores reject invocation.json invocation_id changed to different-actor-identity; mutant restores all16 and closed_only=True. Both probes process exit0.','status':'Current production checks are correct; no test/fix written by reviewer.'}
 ],
 'verified_strengths':[
  'Preparer requires completed16 v3 terminal summary plus runtime-qualification closure/provider0 before constructing v4 registration; uses new root, binds scripts/dependencies/prior evidence and retains source bindings.',
  'Deliberately defers only returned final audit proof after concrete backend has produced its real descriptor; original descriptor is retained.',
  'Fresh concrete backend starts without authorization; resume calls actual restore_closed, all-audit barrier and grade entry. Poison counters cover invoke/verify/external launch/reserve/upstream during resume even if exceptions are swallowed.',
  'Measured_run argv matcher agrees with actual production six-element evaluator invocation and records return codes during resume; duplicate resume is attempted under same observer.',
  'Candidate input_digest includes file modes, symlink targets and empty directories; attempted native artifact byte hashes catch receipt edits.',
  'U01 authority revocation, U02 unresolved-audit barrier and U03 fresh restore invocation each killed by a specific consuming assertion in test_feedback_audit_resume.'
 ],
 'snapshot_exclusions':'native actor/native-home/public-build-state working state excluded; candidate input_digest separately covers full captured source. Root audits omission and native artifact metadata limitations are distinct from these deliberate cache exclusions.',
 'declined_to_judge':[
  'Actual v4 positive runtime behavior: no v4 actor, private evaluator or provider launch performed by reviewer.',
  'Running real16 v3 outcome, live subprocess/container/subnet state: not polled or modified.',
  'Version5 observer design/calibration: not yet reviewed or executed in this report.',
  'Full Rust gate failures and full659/68-skipped suite: outside focused control review;70targeted tests executed here only.',
  'Efficacy, total financial/review/CPU/embedding costs: no positive claim and unknown costs not zero.'
 ],
 'verdict':'V4 orchestration uses compatible production APIs but is NOT READY to establish the stated runtime evidence: versioned instrumentation correction and original-audit snapshot closure required. Production resume checks remain intact; U04 is an observed Important regression gap. Actual control and required project gate remain outstanding.',
 'custody':json.loads((root/'custody-after.json').read_text()),
 'evidence':{'restore_probe':'restore-probe-results.json','snapshot_probe':'snapshot-probe-results.json','mutant_results':'mutation-results.json','failure_sites':'failure-sites.json'}
}
(root/'review-report.json').write_text(json.dumps(report,indent=2)+'\n')
manifest={p.name:sha(p) for p in root.iterdir() if p.is_file() and p.name!='evidence-manifest.json'}
(root/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'report':str(root/'review-report.json'),'report_sha256':sha(root/'review-report.json'),'manifest_sha256':sha(root/'evidence-manifest.json')},indent=2))
