from pathlib import Path
import json,sys
root=Path(__file__).parent;which=sys.argv[1]
sys.path[:0]=[str(root/which/'tools'/name) for name in ('effort_protocol','agent_lifecycle','hint_authority_pilot')]
import feedback_runner
from native_campaign import NativeCampaignBackend
from test_feedback_audit_resume import AuditBatchTests
case=AuditBatchTests();case.setUp();case.pending_at=15
try:
 initial=feedback_runner.run_campaign(case.fixture.reg,case.fixture.backend)
 row=initial['attempts'][0]
 path=case.fixture.out/'attempts'/(str(row['attempt_index']).zfill(2)+'-'+row['arm'])/'repair'/'invocation.json'
 value=json.loads(path.read_text());original=value['invocation_id'];value['invocation_id']='different-actor-identity'
 path.write_text(json.dumps(value))
 backend=NativeCampaignBackend(mode='scripted')
 try:
  backend.restore_closed(case.fixture.reg,case.fixture.out)
  result={'accepted':True,'restored_invocations':len(backend.invocations),'closed_only':backend.closed_only}
 except Exception as exc:result={'accepted':False,'error':type(exc).__name__+': '+str(exc)}
 result.update(copy=which,original_invocation_id=original,altered_invocation_id=value['invocation_id'])
 print(json.dumps(result))
finally:case.doCleanups()
