from pathlib import Path
import ast,hashlib,json,os,sys,tempfile
root=Path(__file__).parent
sys.path[:0]=[str(root/'baseline/tools'/name) for name in ('effort_protocol','agent_lifecycle','hint_authority_pilot')]
from receipts import input_digest
script=root/'scripts/qualify_native_feedback_resume_v4.py'
tree=ast.parse(script.read_text());functions=[node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name in ('sha','frozen_inputs')]
namespace={'Path':Path,'hashlib':hashlib,'input_digest':input_digest};exec(compile(ast.Module(body=functions,type_ignores=[]),str(script),'exec'),namespace)
with tempfile.TemporaryDirectory(prefix='resume-snapshot-probe-',dir='/var/tmp') as temp:
 base=Path(temp)
 for name in ('registration.json','actor-batch-closed.json','ledger-final.json','ledger-reserved.json','result.json','integrity-audits.json'):(base/name).write_text('{}')
 native=base/'attempts/00-L/repair/native';native.mkdir(parents=True)
 receipt=native/'receipt.json';receipt.write_text('{}');receipt.chmod(0o644)
 candidate=base/'attempts/00-L/repair/candidate';candidate.mkdir();source=candidate/'source.rs';source.write_text('fn main() {}');source.chmod(0o644)
 audit=base/'audits/opaque/descriptor.json';audit.parent.mkdir(parents=True);audit.write_text('{}')
 initial={'attempts':[{'candidate':str(candidate)}]}
 before=namespace['frozen_inputs'](base,initial);results=[]
 audit.write_text('{"changed":true}');results.append({'change':'existing audit descriptor bytes','snapshot_detected':namespace['frozen_inputs'](base,initial)!=before});audit.write_text('{}')
 receipt.chmod(0o600);results.append({'change':'native evidence file mode only','snapshot_detected':namespace['frozen_inputs'](base,initial)!=before});receipt.chmod(0o644)
 receipt.write_text('{"changed":true}');results.append({'change':'native receipt bytes','snapshot_detected':namespace['frozen_inputs'](base,initial)!=before});receipt.write_text('{}')
 source.chmod(0o600);results.append({'change':'captured candidate file mode only','snapshot_detected':namespace['frozen_inputs'](base,initial)!=before});source.chmod(0o644)
 (native/'extra-link').symlink_to('receipt.json');results.append({'change':'new native evidence symlink','snapshot_detected':namespace['frozen_inputs'](base,initial)!=before});(native/'extra-link').unlink()
 actor=native/'actor';actor.mkdir();(actor/'cache').write_text('new');results.append({'change':'excluded actor workspace cache','snapshot_detected':namespace['frozen_inputs'](base,initial)!=before})
 (root/'snapshot-probe-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
