from pathlib import Path
import json
root=Path(__file__).parent
mutations=[
 {'id':'U01','file':'native_campaign.py','area':'permanent actor revocation after rehydration','old':'self.authorization, self.closed_only = None, True','new':'self.authorization, self.closed_only = None, False'},
 {'id':'U02','file':'feedback_runner.py','area':'all audits settled before resumed grading','old':'legacy._require(audited["complete"], "integrity audit remains unresolved; resume did not grade")','new':'legacy._require(True, "integrity audit remains unresolved; resume did not grade")'},
 {'id':'U03','file':'feedback_runner.py','area':'fresh backend must rehydrate closed evidence','old':'    restore(registered, root)\n    audited = _audit_batch','new':'    # omitted closed restore\n    audited = _audit_batch'},
 {'id':'U04','file':'native_campaign.py','area':'rehydrated invocation bytes and content bound to closure','old':'or _sha(path) != decision["receipt_sha256"]\n                    or json.loads(path.read_bytes()) != decision["record"]','new':'or False'}
]
for m in mutations:
 data=(root/'baseline/tools/effort_protocol'/m['file']).read_text()
 assert data.count(m['old'])==1,(m['id'],data.count(m['old']))
(root/'mutations.json').write_text(json.dumps(mutations,indent=2)+'\n')
old=Path('/tmp/native-feedback-framing-replay-zerv3f20/run_mutations.py').read_text()
(root/'run_mutations.py').write_text(old.replace('==120','==70'))
print('prepared',len(mutations),'mutations')
