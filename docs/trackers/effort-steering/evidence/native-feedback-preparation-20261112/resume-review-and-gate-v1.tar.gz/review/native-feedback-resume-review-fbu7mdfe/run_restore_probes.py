from pathlib import Path
import json,os,subprocess
root=Path(__file__).parent;results=[]
for which in ('baseline','U04'):
 run=subprocess.run(['python3','-B',str(root/'probe_restore.py'),which],env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TMPDIR='/var/tmp'),capture_output=True,text=True)
 result={'process_exit':run.returncode,'stderr':run.stderr}
 try:result.update(json.loads(run.stdout))
 except ValueError:result['stdout']=run.stdout
 results.append(result)
(root/'restore-probe-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
