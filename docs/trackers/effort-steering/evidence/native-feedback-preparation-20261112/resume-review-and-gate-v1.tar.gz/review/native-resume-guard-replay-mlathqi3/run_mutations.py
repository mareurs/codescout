from pathlib import Path
import concurrent.futures,difflib,hashlib,json,os,re,shutil,subprocess,time
root=Path(__file__).parent
selected=json.loads((root/'mutations.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(m):
    ident=m['id']; dst=root/ident
    shutil.copytree(root/'baseline',dst)
    file=dst/'tools/effort_protocol'/m['file']; before=file.read_text()
    assert before.count(m['old'])==1
    after=before.replace(m['old'],m['new']); file.write_text(after)
    diff=root/(ident+'.diff');diff.write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/tools/effort_protocol/'+m['file'],tofile='b/tools/effort_protocol/'+m['file'])))
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TMPDIR='/var/tmp')
    log=root/(ident+'.log'); start=time.monotonic()
    cmd=['python3','-B','-m','unittest',*json.loads((root/'test-modules.json').read_text())]
    with log.open('w') as out:
        proc=subprocess.run(cmd,cwd=dst/'tools/effort_protocol',env=env,stdout=out,stderr=subprocess.STDOUT,timeout=300)
    text=log.read_text(); counts=re.findall(r'^Ran (\d+) tests? in ([0-9.]+)s$',text,re.M); ending=re.findall(r'^(?:OK|FAILED)(?: .*|$)',text,re.M)
    valid=bool(counts) and int(counts[-1][0])==72 and bool(ending)
    result={k:v for k,v in m.items() if k not in ('old','new')}
    result.update(exit=proc.returncode,tests=int(counts[-1][0]) if counts else None,summary=ending[-1] if ending else None,verdict=('SURVIVED' if proc.returncode==0 else 'KILLED') if valid else 'INCONCLUSIVE',seconds=round(time.monotonic()-start,3),log=str(log),log_sha256=sha(log),diff=str(diff),diff_sha256=sha(diff),mutant_sha256=sha(file),baseline_sha256=hashlib.sha256(before.encode()).hexdigest())
    (root/(ident+'.json')).write_text(json.dumps(result,indent=2))
    print(json.dumps(result),flush=True)
    return result
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    results=list(pool.map(run,selected))
(root/'mutation-results.json').write_text(json.dumps(results,indent=2))
print(json.dumps({'candidates':len(results),'killed':sum(r['verdict']=='KILLED' for r in results),'survived':sum(r['verdict']=='SURVIVED' for r in results),'inconclusive':sum(r['verdict']=='INCONCLUSIVE' for r in results)}),flush=True)
