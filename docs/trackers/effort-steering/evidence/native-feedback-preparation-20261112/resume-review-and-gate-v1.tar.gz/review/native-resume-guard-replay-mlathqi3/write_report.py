from pathlib import Path
import hashlib,json,re
root=Path(__file__).parent;src=Path('/home/marius/.codex/worktrees/2aa6/codescout')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((root/'custody-before.json').read_text());custody={'scratch_baseline_changes':[],'original_changes':[]}
for name,value in manifest.items():
 for folder,key in ((root/'baseline','scratch_baseline_changes'),(src,'original_changes')):
  p=folder/name
  if not p.exists() or sha(p)!=value:custody[key].append(name)
(root/'custody-after.json').write_text(json.dumps(custody,indent=2)+'\n')
results=json.loads((root/'mutation-results.json').read_text())
failures={r['id']:re.findall(r'^(?:FAIL|ERROR): .*$',Path(r['log']).read_text(),re.M) for r in results}
(root/'failure-sites.json').write_text(json.dumps(failures,indent=2)+'\n')
report={
 'scope':'Exact U04 restore_closed survivor replay plus independent SHA-only U05 after two new concrete restore regressions; production code unchanged',
 'baseline':json.loads((root/'baseline-result.json').read_text()),
 'mutation_counts':{'applied':2,'killed':2,'survived':0,'inconclusive':0,'tests_per_mutant':72},
 'results':results,
 'test_quality':'Both tests first create an actual16-slot filesystem pending fixture, then call concrete NativeCampaignBackend.restore_closed after altering standalone invocation.json. Identity-change case rejects changed parsed evidence; whitespace-only case proves exact original byte binding independent of parsed equality. Failure postconditions assert fresh registration None/invocations empty, not a nonexistent constructor authorization field.',
 'finding_status':'Original U04 Important test gap closed by observed exact-mutant failure. Separate SHA-only mutation also killed. No production guard edit required or performed.',
 'v5_instrument_review':{'status':'focused instrument delta passes','baseline_tests':7,'applied_mutations':5,'killed':5,'survived':0,'inconclusive':0,'report':'/tmp/native-resume-v5-instrument-replay-vjt2x6zu/review-report.json','report_sha256':'cdd72cf17141cd56c531547d7cccb6fa9b30920ec6d2d3852fb92d0431c44f8f'},
 'declined_to_judge':['Actual bound qualification or runtime resume success: neither executed.','Root full effort-suite count and project gate: not independently rerun here; no expected count reported as observed.','CLI version calibration mentioned by root: not independently read in this report.','Provider/private evaluator behavior, efficacy and unknown aggregate compute costs.'],
 'verdict':'Focused restore regression closure verified; no outstanding U04 test gap. Together with the separate V5 instrument review, reviewed code/instrument corrections pass. No preregistration/full-runtime/efficacy verdict.',
 'custody':custody
}
(root/'review-report.json').write_text(json.dumps(report,indent=2)+'\n')
evidence={p.name:sha(p) for p in root.iterdir() if p.is_file() and p.name!='evidence-manifest.json'}
(root/'evidence-manifest.json').write_text(json.dumps(evidence,indent=2)+'\n')
print(json.dumps({'report':str(root/'review-report.json'),'report_sha256':sha(root/'review-report.json'),'manifest_sha256':sha(root/'evidence-manifest.json'),'custody':custody,'failure_sites':failures},indent=2))
