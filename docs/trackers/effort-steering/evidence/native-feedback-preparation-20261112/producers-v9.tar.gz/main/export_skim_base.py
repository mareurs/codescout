"""Export only canonical Git base bytes from the second frozen public candidate."""
import datetime
import hashlib
import json
import pathlib
import subprocess
import sys
import tarfile
import uuid

MAIN = pathlib.Path("/home/marius/work/claude/codescout")
ROOT = pathlib.Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
POP = MAIN / "docs/trackers/effort-steering/evidence/native-feedback-population-20261111"
OWNER = "codex:01a15ca9-f939-7603-acb5-01c6b02f68e2"
IMAGE_REF = "starryzhang/sweb.eval.x86_64.skim-rs_1776_skim-1044@sha256:742c9be8ac121a72073d8b83f1b56628c7db10765f1fd4b441506816e4795620"

def sha(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()

def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")

def main():
    frozen = json.loads((POP / "freeze.json").read_bytes())
    for name, digest in frozen["payload_sha256"].items():
        assert sha(POP / name) == digest, name
    metadata = json.loads((POP / "original-metadata.json").read_bytes())
    # This file contains public fields only; no full dataset/private patches are read.
    rows = metadata["tasks"]
    task = next(row for row in rows if row["id"] == "skim-rs__skim-1044")
    assert task["base_commit"] == "e531182a2bf132d3d2aa085a7557580f76ecc578"
    image = json.loads(subprocess.check_output(["docker", "image", "inspect", IMAGE_REF]))[0]
    assert not image["Config"].get("Volumes"), "image volumes require explicit handling"
    assert image["Id"] == "sha256:742c9be8ac121a72073d8b83f1b56628c7db10765f1fd4b441506816e4795620"
    ROOT.mkdir(parents=True, exist_ok=True)
    out = ROOT / task["id"]
    out.mkdir()
    command = ["docker", "create", "--name", "ep-feedback-source-" + uuid.uuid4().hex,
        "--label", "effort-feedback-owner=" + OWNER, "--network", "none", "--read-only",
        "--cap-drop", "ALL", "--security-opt", "no-new-privileges", "--memory", "2g",
        "--memory-swap", "2g", "--cpus", "2", "--pids-limit", "128", "--entrypoint", "git",
        image["Id"], "-c", "safe.directory=/testbed", "-C", "/testbed",
        "archive", "--format=tar", task["base_commit"]]
    save(out / "registration.json", {"schema": "native-feedback-public-base-export-v1",
        "recorded_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "argv": command, "task": task, "image_id": image["Id"], "image_size_bytes": image["Size"],
        "exporter_sha256": sha(__file__), "population_freeze_sha256": sha(POP / "freeze.json"),
        "model_calls": 0, "private_patch_read": False, "paid_ready": False})
    save(out / "image.json", image)
    cid = subprocess.check_output(command, text=True).strip()
    save(out / "created.json", {"cid": cid})
    report = {"id": task["id"], "cid": cid, "paid_ready": False}
    try:
        before = json.loads(subprocess.check_output(["docker", "inspect", cid]))[0]
        assert before["Config"]["Labels"]["effort-feedback-owner"] == OWNER
        assert before["Image"] == image["Id"]
        save(out / "inspect-before.json", before)
        with (out / "public-baseline.tar").open("xb") as stream, (out / "archive.stderr").open("xb") as error:
            code = subprocess.run(["docker", "start", "-a", cid], stdout=stream, stderr=error,
                timeout=180).returncode
        after = json.loads(subprocess.check_output(["docker", "inspect", cid]))[0]
        save(out / "inspect-after.json", after)
        report.update(archive_exit=code, container_exit=after["State"]["ExitCode"],
            oom_killed=after["State"]["OOMKilled"])
        assert code == 0 and after["State"]["ExitCode"] == 0 and not after["State"]["OOMKilled"]
        source = out / "source"
        source.mkdir()
        with tarfile.open(out / "public-baseline.tar") as archive:
            members = archive.getmembers()
            assert all(not pathlib.PurePosixPath(m.name).is_absolute()
                and ".." not in pathlib.PurePosixPath(m.name).parts for m in members)
            assert all(m.isfile() or m.isdir() or m.issym() or m.islnk() for m in members)
            archive.extractall(source, filter="data")
        files, links = {}, {}
        for path in source.rglob("*"):
            rel = path.relative_to(source).as_posix()
            if path.is_symlink():
                links[rel] = str(path.readlink())
            elif path.is_file():
                files[rel] = {"bytes": path.stat().st_size, "sha256": sha(path)}
        save(out / "public-source-manifest.json", {"files": files, "links": links,
            "archive_sha256": sha(out / "public-baseline.tar")})
        report.update(regular_paths=len(files), link_paths=len(links),
            cargo_manifest=(source / "Cargo.toml").is_file(),
            source_manifest_sha256=sha(out / "public-source-manifest.json"))
    except BaseException as error:
        report.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        facts = json.loads(subprocess.check_output(["docker", "inspect", cid]))[0]
        assert facts["Id"] == cid and facts["Config"]["Labels"]["effort-feedback-owner"] == OWNER
        if facts["State"]["Running"]:
            subprocess.run(["docker", "stop", "-t", "3", cid], check=True, capture_output=True)
        subprocess.run(["docker", "rm", "--volumes", cid], check=True, capture_output=True)
        absence = subprocess.run(["docker", "ps", "-a", "--no-trunc", "--filter", "id=" + cid,
            "--format", "{{.ID}}"], capture_output=True, text=True)
        report["cleanup_complete"] = absence.returncode == 0 and not absence.stdout.strip()
        save(out / "result.json", report)
    print(json.dumps(report), flush=True)

if __name__ == "__main__":
    main()
