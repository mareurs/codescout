"""Prepare public repository guidance once; indexing is a separate resumable step."""
import hashlib
import json
import pathlib
import re
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent
OLD = pathlib.Path("/home/marius/.cache/codescout-resident/codescout/common-preparation-20261109")
sys.path[:0] = [str(OLD), "/home/marius/.codex/worktrees/cf66/codescout/tools/effort_protocol"]
import prepare_native
from native_executor import _public_digest
from receipts import input_digest

def save(path, value):
    with path.open("x") as f:
        json.dump(value, f, indent=2)
        f.write("\n")

def seed(project, message):
    subprocess.run(["git", "config", "--local", "core.autocrlf", "false"], cwd=project, check=True)
    paths = sorted(str(p.relative_to(project)) for p in project.rglob("*")
                   if p.is_file() and p.relative_to(project).parts[0] not in {".git", ".codescout"})
    assert all("\n" not in name and "\r" not in name for name in paths)
    subprocess.run(["git", "add", "--force", "--", *paths], cwd=project, check=True)
    result = subprocess.run(["git", "ls-files", "--stage", "-z"], cwd=project, check=True,
                            capture_output=True).stdout
    index = {}
    for entry in result.split(b"\0"):
        if entry:
            header, path = entry.split(b"\t", 1)
            mode, digest, stage = header.split()
            assert stage == b"0", "unmerged Git seed"
            index[path.decode()] = digest.decode()
    assert sorted(index) == paths, "Git seed differs from public source inputs"
    physical = subprocess.run(["git", "hash-object", "--no-filters", "--stdin-paths"],
                              cwd=project, check=True, capture_output=True, text=True,
                              input="\n".join(json.dumps(name, ensure_ascii=False) for name in paths) + "\n")
    hashes = physical.stdout.splitlines()
    assert len(hashes) == len(paths)
    assert all(index[name] == digest for name, digest in zip(paths, hashes)), "Git index changes public source bytes"
    subprocess.run(["git", "-c", "user.name=Source-only preparation", "-c",
                    "user.email=offline@invalid", "commit", "--allow-empty", "-qm", message],
                   cwd=project, check=True)

def main(stem):
    assert re.fullmatch(r"[a-z0-9-]+", stem)
    source = ROOT / (stem + "-public-v1/source")
    image = json.loads((ROOT / (stem + "-derived-image-receipt-v1.json")).read_text())["image_id"]
    assert source.is_dir() and not (source / ".codescout").exists()
    original = input_digest(source)
    out = ROOT / ("common-" + stem + "-v1")
    out.mkdir()
    save(out / "registration.json", {"source_digest": original, "source": str(source),
         "image": image, "helper_sha256": hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
         "native_helper_sha256": hashlib.sha256((OLD / "prepare_native.py").read_bytes()).hexdigest(),
         "scope": "public source and existing docs only; no issue, test result, private grader or author call"})
    project = out / "project"
    shutil.copytree(source, project)
    bridge = False
    if (project / "AGENTS.md").is_file() and not (project / "CLAUDE.md").exists():
        (project / "CLAUDE.md").write_text("# Project instructions\n\nRead [AGENTS.md](AGENTS.md) before working in this repository.\n")
        bridge = True
    subprocess.run(["git", "init", "-q"], cwd=project, check=True)
    seed(project, "Public source and instruction bridge")
    runtime = json.loads((OLD / "native-runtime.json").read_text())
    runtime["Image"] = image
    save(out / "native-runtime.json", runtime)
    cfg = {"native_image": image, "runtime_manifest": str(out / "native-runtime.json")}
    prepare_native.ROOT, prepare_native.IMAGE = out, image
    native = prepare_native.Native("onboarding", project, cfg)
    try:
        native.start()
        native.tool("onboarding", {}, timeout=240)
    finally:
        native.close()
    knowledge = project / ".codescout"
    memories = knowledge / "memories"
    memories.mkdir(exist_ok=True)
    provenance = {}
    for rel in ["README.md", "AGENTS.md", "CONTRIBUTING.md", "rust/CLAUDE.md"]:
        path = source / rel
        if path.is_file():
            name = "source-" + rel.replace("/", "-").removesuffix(".md").lower()
            data = path.read_bytes()
            (memories / (name + ".md")).write_bytes(data)
            provenance[name] = {"source": rel, "sha256": hashlib.sha256(data).hexdigest(),
                                "bytes": len(data)}
    assert provenance
    prompt = knowledge / "system-prompt.md"
    if prompt.exists():
        shutil.copy2(prompt, out / "onboarding-system-prompt-original.md")
    guidance = "# Source-only repository guidance\n\nRead the project CLAUDE.md and AGENTS.md where present.\n\nUnaltered public repository documents are available as Codescout memories:\n"
    guidance += "".join("- " + key + " from " + row["source"] + "\n" for key, row in provenance.items())
    prompt.write_text(guidance)
    config = knowledge / "project.toml"
    text, n = re.subn(r'(?ms)^\[embeddings\].*?(?=^\[|\Z)',
        '[embeddings]\nmodel = "CodeRankEmbed"\nurl = "http://source-embeddings:8000/v1"\n\n',
        config.read_text())
    assert n == 1
    text, n = re.subn(r'system_prompt_sha256 = "[0-9a-f]+"',
        'system_prompt_sha256 = "' + hashlib.sha256(prompt.read_bytes()).hexdigest() + '"', text)
    assert n == 1
    config.write_text(text)
    seed(project, "Prepared common source-only guidance")
    assert input_digest(source) == original
    save(out / "preparation.json", {"source_unchanged": True, "original_source_digest": original,
         "prepared_public_digest": _public_digest(project), "image": image, "documents": provenance,
         "instruction_bridge_added": bridge, "programmatic_onboarding_calls": 1,
         "onboarding_author_calls": 0, "index_calls": 0, "model_generation_cost_usd": "0",
         "paid_ready": False, "scope": "programmatic config and raw source-document corpus; indexing, actual canaries and all-arm context remain pending"})
    print(json.dumps({"stem": stem, "out": str(out), "programmatic_onboarding_calls": 1,
                      "source_unchanged": True, "index_calls": 0}), flush=True)

if __name__ == "__main__":
    main(sys.argv[1])
