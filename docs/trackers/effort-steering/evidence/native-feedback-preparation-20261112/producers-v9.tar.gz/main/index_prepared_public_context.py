"""Reuse the existing native index engine for one explicitly named prepared context."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True
import index_skim_context as engine


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--preparation", type=Path, required=True)
    args = parser.parse_args()
    parent = args.preparation.resolve(strict=True)
    prep = json.loads((parent / "preparation.json").read_bytes())
    assert prep["programmatic_onboarding_calls"] == 1 and prep["additional_onboarding_calls"] == 0
    assert prep["index_calls"] == 0
    engine.save(parent / "index-driver-binding-v1.json", {
        "preparation": str(parent),
        "wrapper_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "engine": engine.__file__,
        "engine_sha256": hashlib.sha256(Path(engine.__file__).read_bytes()).hexdigest(),
        "preparation_sha256": hashlib.sha256((parent / "preparation.json").read_bytes()).hexdigest(),
        "additional_onboarding_calls": 0, "client_model_calls": 0, "paid_ready": False})
    engine.PARENT = parent
    return engine.main()


if __name__ == "__main__":
    main()
