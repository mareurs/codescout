"""Disambiguate compact formatting from retrieval on the same projected cache."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import time

sys.dont_write_bytecode=True
WORK=Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from receipts import input_digest
from native_executor import _public_digest
from embedding_runtime import embedding_runtime

ROOT=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/skim-rs__skim-1044")
PREVIOUS=ROOT/"native-projection-canaries-v1"
OUT=ROOT/"native-semantic-full-canaries-v1"
SCRIPTS=Path(__file__).parent


def save(path,value):
    with path.open("x") as stream:
        json.dump(value,stream,sort_keys=True,indent=2)
        stream.write("\n")


def main():
    OUT.mkdir()
    registered=json.loads((PREVIOUS/"registration.json").read_bytes())
    actor=PREVIOUS/"actor"
    source=ROOT/"common-preparation-v1/public-source"
    config=json.loads((PREVIOUS/"clone-config.json").read_bytes())
    expected=_public_digest(actor)
    assert expected==registered["public_source_digest"]
    before=input_digest(ROOT/"common-preparation-v1/project")
    image=registered["image"]
    requests=[
        ("same-query-full",{"query":"SkimItem trait text display preview output fuzzy matching","limit":3,"detail_level":"full"}),
        ("literal-trait-full",{"query":"pub trait SkimItem","limit":5,"detail_level":"full"})]
    save(OUT/"registration.json",{"image":image,"actor":str(actor),"public_source_digest":expected,
        "queries":requests,"producer_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "scope":"Compare original compact preview with full chunks, not a model/repair outcome.",
        "additional_onboarding_calls":0,"client_model_calls":0,"embedding_compute_cost_usd":None,"paid_ready":False})
    relay=OUT/"embedding"
    relay.mkdir()
    spec=importlib.util.spec_from_file_location("skim_full_native",SCRIPTS/"prior_prepare_native.py")
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.ROOT,module.IMAGE=OUT,image
    original=module._native_argv
    rows=[]
    with embedding_runtime(relay,image,registered["embedding"]) as descriptor:
        def private_argv(actor,home,configuration):
            argv=original(actor,home,configuration)
            argv[argv.index("--network")+1]=descriptor["network_id"]
            return argv
        module._native_argv=private_argv
        native=None
        try:
            native=module.Native("native",actor,{"native_image":image,"runtime_manifest":str(PREVIOUS/"native-runtime.json")})
            native.start()
            for name,args in requests:
                start=time.monotonic()
                response=native.tool("semantic_search",args,timeout=240)
                save(OUT/(name+".json"),response)
                rows.append({"name":name,"wall_s":time.monotonic()-start,"transport_complete":True})
            assert _public_digest(actor)==expected and input_digest(source)==expected
            assert input_digest(ROOT/"common-preparation-v1/project")==before
            assert input_digest(actor/".codescout",config["knowledge_paths"])==config["knowledge_sha256"]
            save(OUT/"calls-completed.json",{"rows":rows,"source_unchanged":True,"template_unchanged":True,
                "static_knowledge_unchanged":True,"additional_onboarding_calls":0,"client_model_calls":0,
                "scope":"Inspect primary full payloads before interpreting compact-hit usefulness.","paid_ready":False})
        finally:
            module._native_argv=original
            if native is not None:
                native.close()


if __name__=="__main__":
    main()
