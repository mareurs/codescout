def parser(log: str) -> dict[str, str]:
    import io
    import re
    import xml.etree.ElementTree as ET

    results = {}

    def add_result(name: str, status: str) -> None:
        name = (name or "").strip()
        if not name:
            return
        if status not in ("pass", "fail", "skip"):
            status = "fail"
        if name in results:
            i = 2
            while f"{name}#{i}" in results:
                i += 1
            name = f"{name}#{i}"
        results[name] = status

    def local_name(tag: str) -> str:
        return tag.rsplit("}", 1)[-1] if "}" in tag else tag

    def parse_as_junit_xml(xml_text: str) -> bool:
        start = xml_text.find("<")
        if start == -1:
            return False
        xml_text2 = xml_text[start:].strip()

        candidates = [xml_text2]
        last_gt = xml_text2.rfind(">")
        if last_gt != -1:
            candidates.append(xml_text2[: last_gt + 1])

        for txt in candidates:
            try:
                suite_stack = []
                for event, elem in ET.iterparse(io.StringIO(txt), events=("start", "end")):
                    tag = local_name(elem.tag)

                    if event == "start":
                        if tag == "testsuite":
                            suite_stack.append((elem.attrib.get("name") or "").strip())
                        continue

                    if tag == "testcase":
                        tc_name = (elem.attrib.get("name") or "").strip()
                        classname = (elem.attrib.get("classname") or "").strip()

                        suite_name = ""
                        for s in reversed(suite_stack):
                            if s:
                                suite_name = s
                                break

                        if classname and tc_name:
                            full_name = f"{classname}::{tc_name}"
                        elif suite_name and tc_name:
                            full_name = f"{suite_name}::{tc_name}"
                        else:
                            full_name = classname or tc_name or suite_name

                        status = "pass"
                        for child in list(elem):
                            ctag = local_name(child.tag)
                            if ctag in ("failure", "error"):
                                status = "fail"
                                break
                            if ctag == "skipped":
                                status = "skip"

                        if status == "pass":
                            raw_status = (elem.attrib.get("status") or "").lower()
                            if raw_status in ("skipped", "skip"):
                                status = "skip"
                            elif raw_status in ("failure", "failed", "error"):
                                status = "fail"

                        add_result(full_name, status)
                        elem.clear()

                    elif tag == "testsuite":
                        if suite_stack:
                            suite_stack.pop()
                        elem.clear()

                return True
            except ET.ParseError:
                continue
        return False

    def parse_fallback_text(text: str) -> None:
        for m in re.finditer(
            r"(?m)^(?P<name>\S+::\S+)\s+(?P<status>PASSED|FAILED|SKIPPED|ERROR)\s*$",
            text,
        ):
            st = m.group("status")
            add_result(m.group("name"), "pass" if st == "PASSED" else ("skip" if st == "SKIPPED" else "fail"))

        for m in re.finditer(r"(?m)^---\s+(PASS|FAIL|SKIP):\s+(\S+)", text):
            add_result(m.group(2), {"PASS": "pass", "FAIL": "fail", "SKIP": "skip"}[m.group(1)])

        for m in re.finditer(
            r"(?m)^(?P<name>\w+\s+\([^)]+\))\s+\.\.\.\s+(?P<status>ok|FAIL|ERROR|skipped)\s*$",
            text,
        ):
            st = m.group("status")
            add_result(m.group("name"), "pass" if st == "ok" else ("skip" if st == "skipped" else "fail"))

    if not parse_as_junit_xml(log):
        parse_fallback_text(log)

    return dict(results)