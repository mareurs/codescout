"""Freeze original labels, literal Cargo command preparation, reference source and private controls."""
from pathlib import Path
import hashlib, importlib.util, json, os, shutil, subprocess, sys
sys.dont_write_bytecode = True
WORK = Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path.insert(0, str(WORK / "tools/effort_protocol"))
from feedback_private_commands import prepare_record
from receipts import input_digest
from evaluator_entry import verify_package
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/apache__arrow-rs-7783")
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")
def apply(source, patch, output):
    result = subprocess.run(["git", "-c", "core.autocrlf=false", "apply", "--binary", "--whitespace=nowarn", str(patch)],
        cwd=source, capture_output=True, timeout=60,
        env={"PATH": os.environ["PATH"], "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": "/dev/null"})
    save(output, {"returncode": result.returncode, "stdout": result.stdout.decode(errors="replace"),
        "stderr": result.stderr.decode(errors="replace")})
    assert result.returncode == 0
def main():
    old = ROOT / "private-preparation-v1"
    old_reg = json.loads((old / "registration.json").read_bytes())
    assert sha(old / "full-record.json") == old_reg["original_record_sha256"]
    original = json.loads((old / "full-record.json").read_bytes())
    common = ROOT / "common-preparation-v3"
    public = common / "image-context/public-source"
    public_sha = input_digest(public)
    reg = json.loads((common / "registration.json").read_bytes())
    assert reg["public_source_digest"] == public_sha
    built = json.loads((common / "image-build-v2/result.json").read_bytes())
    image = built["image"]
    old_config = json.loads(Path("/var/tmp/ep11-01a15/private-controls/obscura/config.json").read_bytes())
    package = verify_package(old_config["package_root"], old_config["package_files"])
    sys.path.insert(0, str(package))
    import multilang_tasks as tasks
    import stream_evidence as streams
    out = ROOT / "private-preparation-v3"
    out.mkdir(mode=0o700)
    save(out / "original-record.json", original)
    record = prepare_record(original)
    assert record["FAIL_TO_PASS"] == original["FAIL_TO_PASS"] and record["PASS_TO_PASS"] == original["PASS_TO_PASS"]
    assert record["patch"] == original["patch"] and record["test_patch"] == original["test_patch"]
    assert len(record["FAIL_TO_PASS"] + record["PASS_TO_PASS"]) == len(set(record["FAIL_TO_PASS"] + record["PASS_TO_PASS"]))
    save(out / "full-record.json", record)
    (out / "gold.patch").write_text(record["patch"])
    (out / "official-tests.patch").write_text(record["test_patch"])
    (out / "baseline.patch").write_bytes(b"")
    reference = out / "reference"
    shutil.copytree(public, reference, symlinks=True)
    apply(reference, out / "gold.patch", out / "reference-apply.json")
    fixed = out / "fixed-tests-source"
    shutil.copytree(public, fixed, symlinks=True)
    apply(fixed, out / "official-tests.patch", out / "official-apply.json")
    test_paths = tasks.tasks.patch_files(record["test_patch"])
    production = tasks.tasks.patch_files(record["patch"])
    assert not set(test_paths) & set(production)
    fixed_sha = {"/testbed/" + name: sha(fixed / name) for name in test_paths}
    stream_registration = {"version": streams.VERSION, "commands_sha256": streams.commands_digest(record),
        "tests": [{"profile": streams.LIB, "reports": [0], "stderr_files": []}]}
    assert len(record["test_cmds"]) == len(record["print_cmds"]) == 1
    save(out / "acceptance-labels.json", {"schema": "source-independent-original-acceptance-v1",
        "task": record["instance_id"], "image": image, "record_sha256": sha(out / "full-record.json"),
        "original_f2p": original["FAIL_TO_PASS"], "original_p2p": original["PASS_TO_PASS"],
        "original_record_sha256": sha(out / "original-record.json"), "expected_population_unchanged": True,
        "assertions_unchanged": True, "commands_unchanged": False, "commands_prepared_before_outcomes": True,
        "command_preparation": "Same Cargo selection; rendered compiler-only prefix and no-fail-fast. No Cargo JSON diagnostic mode.",
        "actual_toolchain": "rustc 1.92.0; cargo 1.92.0", "stream_format_contract": streams.LIB,
        "format_compatibility": "Requires actual baseline/reference/repeat controls; contract name is not an installed compiler version.",
        "controls": [], "paid_ready": False})
    paths = [out / name for name in ("original-record.json", "full-record.json", "gold.patch", "official-tests.patch", "acceptance-labels.json")]
    paths += [Path(__file__), WORK / "tools/effort_protocol/feedback_private_commands.py"]
    paths += [fixed / name for name in test_paths]
    config = {"package_root": str(package), "package_files": old_config["package_files"],
        "bindings": {str(path): sha(path) for path in paths},
        "record": str(out / "full-record.json"), "acceptance_registration": str(out / "acceptance-labels.json"),
        "image": image, "production_paths": production, "fixed_test_sha256": fixed_sha,
        "diagnostic_artifacts": {}, "stream_registration": stream_registration}
    save(out / "config.json", config)
    controls = []
    for name, source, patch, edited in (("baseline", public, out / "baseline.patch", []),
            ("reference", reference, out / "gold.patch", production),
            ("reference-repeat", reference, out / "gold.patch", production)):
        directory = out / ("control-" + name)
        directory.mkdir()
        proof = directory / "deterministic-control-patch.json"
        save(proof, {"complete": True, "sha256": sha(patch), "bytes": patch.stat().st_size,
            "edited": edited, "scope": "Deterministic baseline/gold-control construction, not a native actor capture or model outcome."})
        request = {"config": str(out / "config.json"), "config_sha256": sha(out / "config.json"),
            "source": str(source), "source_digest": input_digest(source),
            "public_baseline": str(public), "public_baseline_sha256": public_sha,
            "patch": str(patch), "patch_sha256": sha(patch),
            "capture_proof": str(proof), "capture_proof_sha256": sha(proof)}
        save(directory / "request.json", request)
        controls.append({"name": name, "request": str(directory / "request.json"),
            "request_sha256": sha(directory / "request.json"), "expected_pass": name != "baseline"})
    assert input_digest(public) == public_sha
    verify_package(package, old_config["package_files"])
    save(out / "registration.json", {"schema": "native-feedback-private-controls-preregistration-v1",
        "task": record["instance_id"], "image": image, "public_source": str(public), "public_source_sha256": public_sha,
        "reference": str(reference), "reference_sha256": input_digest(reference),
        "original_record_sha256": sha(out / "original-record.json"), "prepared_record_sha256": sha(out / "full-record.json"),
        "config_sha256": sha(out / "config.json"), "controls": controls,
        "selected_label_count": len(record["FAIL_TO_PASS"]) + len(record["PASS_TO_PASS"]),
        "production_test_paths_disjoint": True, "client_model_calls": 0, "paid_ready": False,
        "scope": "Three actual evaluator controls pending; selected labels are not a count of newly failing tests."})
    print(json.dumps({"prepared": str(out), "selected_label_count": len(record["FAIL_TO_PASS"])+len(record["PASS_TO_PASS"]),
        "image": image, "client_model_calls": 0, "paid_ready": False}))
if __name__ == "__main__":
    main()
