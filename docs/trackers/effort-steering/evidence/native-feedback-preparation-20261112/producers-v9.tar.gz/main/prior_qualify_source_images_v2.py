"""Versioned image acquisition: registry manifest identity and config stay distinct."""
import base64
import datetime
import hashlib
import json
import pathlib
import shutil
import subprocess

ROOT = pathlib.Path(__file__).resolve().parent


def write(path, data):
    with path.open("x") as stream:
        json.dump(data, stream, sort_keys=True, indent=2)
        stream.write("\n")


def main():
    old = json.loads((ROOT / "image-acquisition-registration.json").read_text())
    entries = []
    for original in old["candidates"]:
        row = dict(original)
        verbose_path = ROOT / (row["stem"] + "-manifest-verbose.json")
        verbose = json.loads(verbose_path.read_text())
        descriptor = verbose["Descriptor"]
        original_manifest = json.loads((ROOT / (row["stem"] + "-manifest.json")).read_text())
        assert verbose["SchemaV2Manifest"] == original_manifest
        encoded = verbose["Raw"]
        raw = encoded.encode() if encoded.lstrip().startswith("{") else base64.b64decode(encoded, validate=True)
        assert "sha256:" + hashlib.sha256(raw).hexdigest() == descriptor["digest"]
        assert json.loads(raw) == original_manifest
        row["manifest_digest"] = descriptor["digest"]
        row["config_digest"] = row.pop("expected_image_id")
        row["verbose_manifest_sha256"] = hashlib.sha256(verbose_path.read_bytes()).hexdigest()
        row["pinned_ref"] = row["image"] + "@" + descriptor["digest"]
        entries.append(row)
    free = shutil.disk_usage("/var/lib/docker").free
    pending = []
    for row in entries:
        local = subprocess.run(["docker", "image", "inspect", row["pinned_ref"]],
                               capture_output=True, text=True)
        if local.returncode != 0:
            pending.append(row)
    required = max(40_000_000_000, 5 * sum(x["compressed_layer_bytes"] for x in pending)
                   + 10_000_000_000)
    write(ROOT / "image-acquisition-v2-registration.json", {
        "recorded_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "qualifier_sha256": hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
        "original_registration_sha256": hashlib.sha256((ROOT / "image-acquisition-registration.json").read_bytes()).hexdigest(),
        "candidates": entries, "free_bytes": free, "required_bytes": required,
        "original_failure_preserved": True, "private_or_model_outcomes_read": False,
    })
    assert free >= required
    for row in entries:
        cached = subprocess.run(["docker", "image", "inspect", row["pinned_ref"]],
                                capture_output=True, text=True)
        with (ROOT / (row["stem"] + "-v2-pull.log")).open("x") as log:
            code = 0 if cached.returncode == 0 else subprocess.run(
                ["docker", "pull", row["pinned_ref"]], stdout=log,
                stderr=subprocess.STDOUT, timeout=1800).returncode
        assert code == 0
        facts = json.loads(subprocess.check_output(["docker", "image", "inspect", row["pinned_ref"]]))[0]
        assert facts["Descriptor"]["digest"] == row["manifest_digest"]
        assert any(x.endswith("@" + row["manifest_digest"]) for x in facts["RepoDigests"])
        assert facts["Architecture"] == "amd64" and facts["Os"] == "linux"
        receipt = {"id": row["id"], "image": row["image"], "pinned_ref": row["pinned_ref"],
                   "was_cached": cached.returncode == 0, "pull_exit_code": code,
                   "image_id": facts["Id"], "manifest_digest": row["manifest_digest"],
                   "config_digest": row["config_digest"], "rootfs_layer_diffids": facts["RootFS"]["Layers"],
                   "uncompressed_image_size": facts["Size"],
                   "workdir": facts["Config"].get("WorkingDir"),
                   "free_bytes_after": shutil.disk_usage("/var/lib/docker").free}
        write(ROOT / (row["stem"] + "-v2-image-receipt.json"), receipt)
        assert receipt["free_bytes_after"] >= 40_000_000_000
        print(json.dumps(receipt), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
