"""Seal original Cargo integration roots and documented data before actors."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
REV = Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path.insert(0, str(REV / "tools/effort_protocol"))
import evaluator_entry as entry
import trusted_test_inputs as core
from seal_skim_trusted_inputs import changed_paths

ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/apache__arrow-rs-7783")
OUT = ROOT / "trusted-test-inputs-v1"


def main():
    source = ROOT / "common-preparation-v3/image-context/public-source"
    original = ROOT / "private-preparation-v4/original-record.json"
    before = entry._input_digest(source)
    guidance_path = source / "CONTRIBUTING.md"
    guidance = guidance_path.read_bytes()
    assert b"The tests rely on test data that is contained in git submodules." in guidance
    assert b"./parquet-testing/data" in guidance and b"./testing" in guidance
    conventional = sorted(
        (manifest.parent / "tests").relative_to(source).as_posix()
        for manifest in source.rglob("Cargo.toml")
        if (manifest.parent / "tests").is_dir()
    )
    assert conventional and len(conventional) == len(set(conventional))
    roots = sorted(conventional + ["parquet-testing", "testing"])
    assert all((source / name).is_dir() and not (source / name).is_symlink() for name in roots)
    record = json.loads(original.read_bytes())
    official = changed_paths(record["test_patch"])
    production = changed_paths(record["patch"])
    assert all(any(PurePosixPath(name).is_relative_to(root) for root in roots) for name in official)
    assert not any(PurePosixPath(name).is_relative_to(root) for name in production for root in roots)
    OUT.mkdir()
    canonical = OUT / "canonical"
    shutil.copytree(source, canonical, symlinks=True)
    applied = subprocess.run(["git", "apply", "--binary", "-"], cwd=canonical,
        input=record["test_patch"], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (OUT / "official-patch-apply.log").write_text(applied.stdout)
    assert applied.returncode == 0
    descriptor = core.seal_test_inputs(canonical, roots, OUT / "sealed")
    validated_roots, inventory, _ = core._validated(descriptor)
    assert validated_roots == roots
    assert entry._input_digest(source) == before
    result = {
        "schema": "prospective-test-input-contract-v1", "task": record["instance_id"],
        "roots": roots, "descriptor": descriptor, "entries": len(inventory),
        "regular_files": sum(row["kind"] == "file" for row in inventory.values()),
        "original_public_source_digest": before,
        "source_guidance_sha256": hashlib.sha256(guidance).hexdigest(),
        "original_record_sha256": hashlib.sha256(original.read_bytes()).hexdigest(),
        "official_paths": official, "gold_production_overlap": [],
        "selection_basis": "All original Cargo.toml-adjacent tests/ integration roots; CONTRIBUTING.md explicitly requires the two original pinned test-data submodules.",
        "coverage": "Standalone integration roots and documented test-data only. Inline unit/doctest assertions and other code require a blinded candidate diff audit.",
        "runtime_output_caveat": "Exact post-grade inventory compatibility remains pending actual baseline/reference/repeat controls.",
        "provider_calls": 0, "private_grade_runs": 0, "paid_ready": False,
        "producer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "path_parser_sha256": hashlib.sha256(Path(__file__).with_name("seal_skim_trusted_inputs.py").read_bytes()).hexdigest(),
    }
    (OUT / "contract.json").write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
