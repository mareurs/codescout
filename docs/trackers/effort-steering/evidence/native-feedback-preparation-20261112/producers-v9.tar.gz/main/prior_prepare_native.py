"""One source-only preparation; no issue, private grader, author model or image build."""
from pathlib import Path
import hashlib, json, os, re, select, shutil, subprocess, time, uuid
from qualify_native import _native_argv
import executor
from receipts import input_digest
from readiness import validate_readiness

ROOT = Path('/home/marius/.cache/codescout-resident/codescout/common-preparation-20261109')
SOURCE = Path('/var/tmp/ep9-01a15/real-source-probe-4e959f3765/source')
IMAGE = 'sha256:a7108935ae3cb9c6573af9f0e371dbaaffb4c9a88a92038e334184bf8672cc32'

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def emit(event, **facts):
    print(json.dumps({'event': event, 'time': time.time(), **facts}), flush=True)

class Native:
    def __init__(self, stage, project, cfg):
        self.stage = ROOT / stage
        self.stage.mkdir()
        self.calls, self.raw, self.number = [], b'', 1
        self.name = 'ep-common-' + uuid.uuid4().hex
        self.cid = None
        home = self.stage / 'home'
        home.mkdir()
        argv = _native_argv(project, home, cfg)
        argv[argv.index('--name') + 1] = self.name
        argv[argv.index('--label') + 1] = executor.LABEL + '=' + self.name
        index = argv.index(IMAGE)
        argv[index:index] = ['--cap-drop', 'ALL', '--security-opt', 'no-new-privileges',
                             '-e', 'CARGO_TARGET_DIR=/tmp/target']
        save(self.stage / 'argv.json', argv)
        self.stderr = (self.stage / 'server.stderr').open('wb')
        self.proc = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=self.stderr)

    def rpc(self, method, params, timeout=180):
        number = self.number
        self.number += 1
        self.proc.stdin.write((json.dumps({'jsonrpc':'2.0','id':number,'method':method,'params':params})+'\n').encode())
        self.proc.stdin.flush()
        deadline=time.monotonic()+timeout
        while time.monotonic()<deadline:
            while b'\n' in self.raw:
                line,self.raw=self.raw.split(b'\n',1)
                if line.strip():
                    value=json.loads(line)
                    if value.get('id')==number:
                        self.calls.append({'method':method,'params':params,'response':value})
                        save(self.stage/'calls.json',self.calls)
                        return value
            ready,_,_=select.select([self.proc.stdout],[],[],max(0,deadline-time.monotonic()))
            if ready:
                chunk=os.read(self.proc.stdout.fileno(),65536)
                if not chunk:
                    raise RuntimeError('native EOF '+method)
                self.raw+=chunk
        raise TimeoutError(method)

    def start(self):
        self.rpc('initialize',{'protocolVersion':'2025-06-18','capabilities':{},'clientInfo':{'name':'source-only-common-preparation','version':'1'}})
        self.proc.stdin.write(b'{"jsonrpc":"2.0","method":"notifications/initialized"}\n')
        self.proc.stdin.flush()
        row=json.loads(executor._docker(['inspect',self.name]).stdout)[0]
        self.cid=row['Id']
        executor._owned(row,self.cid,self.name,IMAGE)
        save(self.stage/'before.json',row)

    def tool(self,name,args,timeout=180):
        response=self.rpc('tools/call',{'name':name,'arguments':args},timeout)
        assert not response.get('error') and not response.get('result',{}).get('isError'),response
        return response

    def close(self):
        errors=[]
        try:
            self.proc.stdin.close()
            self.proc.wait(timeout=20)
        except Exception as exc:
            errors.append(str(exc))
            self.proc.kill()
            self.proc.wait(timeout=20)
        self.stderr.close()
        try:
            if self.cid:
                save(self.stage/'after.json',executor._inspect(self.cid))
        finally:
            cleaned=executor._cleanup(self.cid,self.name,IMAGE)
            save(self.stage/'cleanup.json',{'name':self.name,'container':self.cid,'cleanup_complete':cleaned,'close_errors':errors})

def main():
    cfg=json.loads(Path('/tmp/effort-native-cli-config-20261109-01a15ca9.json').read_text())
    runtime=json.loads(Path(cfg['runtime_manifest']).read_text())
    runtime['Image']=IMAGE
    save(ROOT/'native-runtime.json',runtime)
    cfg['native_image']=IMAGE
    cfg['runtime_manifest']=str(ROOT/'native-runtime.json')
    project=ROOT/'project'
    assert not project.exists()
    original=input_digest(SOURCE)
    shutil.copytree(SOURCE,project)
    subprocess.run(['git','init','-q'],cwd=project,check=True)
    subprocess.run(['git','add','--','.'],cwd=project,check=True)
    subprocess.run(['git','-c','user.name=Source-only preparation','-c','user.email=offline@invalid','commit','-qm','Common public source'],cwd=project,check=True)
    emit('programmatic-onboarding-start',source_digest=original)
    native=Native('onboarding',project,cfg)
    try:
        native.start()
        native.tool('onboarding',{},timeout=240)
    finally:
        native.close()
    knowledge=project/'.codescout'
    text=(knowledge/'project.toml').read_text()
    text,count=re.subn(r'(?ms)^\[embeddings\].*?(?=^\[|\Z)',
                       '[embeddings]\nmodel = "local:JinaEmbeddingsV2BaseCode"\n\n',text)
    assert count==1
    (knowledge/'project.toml').write_text(text)
    docs={
        'source-architecture':'docs/book/src/contributing/architecture.md',
        'source-testing':'docs/book/src/contributing/testing.md',
        'source-style':'docs/book/src/contributing/style.md',
        'source-contributing':'CONTRIBUTING.md'}
    memories=knowledge/'memories'
    memories.mkdir(exist_ok=True)
    provenance={}
    for name,relative in docs.items():
        data=(SOURCE/relative).read_bytes()
        (memories/(name+'.md')).write_bytes(data)
        provenance[name]={'source':relative,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
    guidance='# Source-only repository guidance\n\nFollow CLAUDE.md and AI_POLICY.md.\n\nPublic source documentation is copied without alteration into these Codescout memories:\n'+''.join('- '+name+' from '+row['source']+'\n' for name,row in provenance.items())
    (knowledge/'system-prompt.md').write_text(guidance)
    prompt_sha=hashlib.sha256(guidance.encode()).hexdigest()
    text=(knowledge/'project.toml').read_text()
    text,count=re.subn(r'system_prompt_sha256 = "[0-9a-f]+"','system_prompt_sha256 = "'+prompt_sha+'"',text)
    assert count==1
    (knowledge/'project.toml').write_text(text)
    save(ROOT/'source-only-provenance.json',{'source_digest':original,'public_documents':provenance,'system_prompt_sha256':prompt_sha,'programmatic_onboarding_calls':1,'onboarding_author_calls':0,'model_cost_usd':'0','scope':'deterministic public source-doc corpus; not semantic completeness or context parity'})
    emit('index-start')
    native=Native('index-and-readiness',project,cfg)
    try:
        native.start()
        start=time.monotonic()
        indexed=executor._docker(['exec',native.cid,'/bench/bin/codescout','index','-p','/testbed'],timeout=1800)
        (ROOT/'index.stdout').write_text(indexed.stdout)
        (ROOT/'index.stderr').write_text(indexed.stderr)
        save(ROOT/'index-result.json',{'exit_code':indexed.returncode,'wall_s':time.monotonic()-start})
        assert indexed.returncode==0,indexed.stderr
        emit('index-complete',seconds=time.monotonic()-start)
        pages=[];cursor=None
        while True:
            page=native.rpc('tools/list',{'cursor':cursor} if cursor else {})
            page['cursor']=cursor;pages.append(page)
            cursor=page['result'].get('nextCursor')
            if not cursor:break
        status=native.tool('workspace',{'action':'status'})
        specs=[
            {'tool':'references','arguments':{'path':'crates/stdx/src/lib.rs','symbol':'to_snake_case'},'must_contain':['to_lower_snake_case','to_upper_snake_case']},
            {'tool':'symbol_at','arguments':{'path':'crates/stdx/src/lib.rs','line':95,'col':5},'must_contain':['to_snake_case']},
            {'tool':'call_graph','arguments':{'path':'crates/stdx/src/lib.rs','symbol':'to_snake_case','direction':'callers'},'must_contain':['to_lower_snake_case','to_upper_snake_case']},
            {'tool':'semantic_search','arguments':{'query':'convert identifier to snake case','limit':5},'must_contain':['crates/stdx/src/lib.rs']}]
        observations=[{'tool':spec['tool'],'arguments':spec['arguments'],'response':native.tool(spec['tool'],spec['arguments'])} for spec in specs]
        binding={'image':IMAGE,'executable_sha256':executor._docker(['exec',native.cid,'sha256sum','/bench/bin/codescout']).stdout.split()[0],
                 'source_snapshot_sha256':original,'knowledge_sha256':input_digest(knowledge,['project.toml','system-prompt.md']+['memories/'+name+'.md' for name in docs])}
        expected={'project_root':'/testbed','languages':['rust'],'tools':['symbols','references','symbol_at','call_graph','semantic_search'],'binding':binding,'probes':specs}
        wire={'binding':binding,'status':status,'tool_pages':pages,'probes':observations,'index_verification':native.tool('index',{'action':'verify'})}
        save(ROOT/'readiness-raw.json',{'expected':expected,'wire':wire})
        result=validate_readiness(expected,wire)
        save(ROOT/'readiness-result.json',result)
        emit('readiness-complete',probes=result['probes_verified'],tools=len(result['tools']))
    finally:
        native.close()
    assert input_digest(SOURCE)==original
    save(ROOT/'preparation-result.json',{'source_unchanged':True,'onboarding_author_calls':0,'programmatic_onboarding_calls':1,'index_calls':1,'model_cost_usd':'0','paid_ready':False,'scope':'one real source preparation; arm clone/readiness/context qualification pending'})
    emit('preparation-complete')

if __name__=='__main__':
    main()
