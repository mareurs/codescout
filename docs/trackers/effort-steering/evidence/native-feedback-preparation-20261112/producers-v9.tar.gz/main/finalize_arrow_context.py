"""Finish the already executed source-only onboarding; never invokes it a second time."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import shutil
import sys
sys.path.insert(0, "/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from receipts import input_digest
from native_executor import _public_digest

MAIN = Path("/home/marius/work/claude/codescout")
SCRIPTS = MAIN / ".superpowers/sdd/2026-11-11-native-public-feedback-transfer"
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/apache__arrow-rs-7783")

def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    out = ROOT / "common-preparation-v1"
    registered = json.loads((out / "registration.json").read_bytes())
    project, baseline = out / "project", out / "public-source"
    calls = json.loads((out / "onboarding/calls.json").read_bytes())
    actual = [row for row in calls if row["method"] == "tools/call" and row["params"]["name"] == "onboarding"]
    assert len(actual) == 1 and not actual[0]["response"].get("error")
    assert not actual[0]["response"]["result"].get("isError")
    clean = json.loads((out / "onboarding/cleanup.json").read_bytes())
    assert clean["cleanup_complete"] and not clean["close_errors"]
    assert input_digest(ROOT / "lock-preparation-v1/source") == registered["source_digest"]
    # Native onboarding appends its private-memory ignore rule. It is a declared common preparation input.
    before = (baseline / ".gitignore").read_bytes()
    after = (project / ".gitignore").read_bytes()
    assert after == before.rstrip(b"\n") + b"\n.codescout/private-memories/\n"
    with (out / "gitignore-before").open("xb") as stream:
        stream.write(before)
    shutil.copy2(project / ".gitignore", baseline / ".gitignore")
    assert _public_digest(project) == input_digest(baseline)
    knowledge = project / ".codescout"
    memories = knowledge / "memories"
    memories.mkdir(exist_ok=True)
    provenance = {}
    for name in registered["documents"] + ["CLAUDE.md"]:
        source = baseline / name
        assert source.is_file()
        topic = "source-" + name.removesuffix(".md").lower()
        target = memories / (topic + ".md")
        with target.open("xb") as stream:
            stream.write(source.read_bytes())
        provenance[topic] = {"source": name, "sha256": sha(source), "bytes": source.stat().st_size}
    prompt = knowledge / "system-prompt.md"
    assert not prompt.exists()
    text = "# Source-only repository guidance\n\nRead the common project CLAUDE.md and the original public documents it names.\n\n"
    text += "Unaltered public source documents are available as Codescout memories:\n"
    text += "".join("- " + name + " from " + row["source"] + "\n" for name, row in provenance.items())
    prompt.write_text(text)
    config = knowledge / "project.toml"
    original_config = config.read_text()
    with (out / "project-config-onboarding-original.toml").open("x") as stream:
        stream.write(original_config)
    content, count = re.subn(r"(?ms)^\[embeddings\].*?(?=^\[|\Z)",
        '[embeddings]\nmodel = "CodeRankEmbed"\nurl = "http://source-embeddings:8000/v1"\n\n', original_config)
    assert count == 1
    content, count = re.subn(r'system_prompt_sha256 = "[0-9a-f]+"',
        'system_prompt_sha256 = "' + sha(prompt) + '"', content)
    assert count == 1
    config.write_text(content)
    spec = importlib.util.spec_from_file_location("context_seed", SCRIPTS / "prepare_arrow_context.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.seed(project)
    assert _public_digest(project) == input_digest(baseline)
    assert input_digest(ROOT / "lock-preparation-v1/source") == registered["source_digest"]
    save(out / "preparation.json", {"programmatic_onboarding_calls": 1, "additional_onboarding_calls": 0,
        "author_model_calls": 0, "client_model_calls": 0, "client_model_cost_usd": "0",
        "source_documents": provenance, "public_baseline_sha256": input_digest(baseline),
        "original_source_unchanged": True, "project_bridge": "CLAUDE.md",
        "onboarding_generated_public_change": ".gitignore",
        "template_public_sha256": _public_digest(project), "index_calls": 0,
        "paid_ready": False, "root_review_embedding_costs": "unmeasured",
        "scope": "programmatic native config plus raw public documents; not an LLM deep-dive onboarding; index/canaries/CLI delivery pending"})
    print(json.dumps({"source_only_prepared": str(out), "programmatic_onboarding_calls": 1,
        "additional_onboarding_calls": 0, "paid_ready": False}), flush=True)

if __name__ == "__main__":
    main()
