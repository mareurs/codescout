"""Exercise actual frozen LSP calls after confirming capability exposure."""
from pathlib import Path
import hashlib, importlib.util, json, sys, time
sys.dont_write_bytecode = True
sys.path.insert(0, "/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from native_executor import _public_digest
SCRIPTS = Path("/home/marius/work/claude/codescout/.superpowers/sdd/2026-11-11-native-public-feedback-transfer")
PARENT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/apache__arrow-rs-7783/common-preparation-v3")
def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")
def main():
    surface = json.loads((PARENT / "native-tool-surface-v4/result.json").read_bytes())
    assert set(surface["navigation_tools_present"]) == {"references", "call_graph", "symbol_at", "symbols"}
    out = PARENT / "native-lsp-canaries-v4"
    out.mkdir()
    source = PARENT / "project"
    reg = json.loads((PARENT / "registration.json").read_bytes())
    assert _public_digest(source) == reg["public_source_digest"]
    image = json.loads((PARENT / "image-root-ownership-v1/result.json").read_bytes())["image"]
    hit = json.loads((PARENT / "corrected-first-member-v2/member-semantic-payload.json").read_bytes())["results"][0]
    assert "MutableBuffer" in hit["content"]
    path = "arrow-buffer/" + hit["file_path"]
    requests = [
        ("symbols", {"path": path, "name": "MutableBuffer", "exact": True, "kind": "struct"}),
        ("references", {"symbol": "MutableBuffer", "path": path, "limit": 10}),
        ("symbol_at", {"path": path, "line": hit["start_line"], "identifier": "MutableBuffer"}),
        ("call_graph", {"symbol": "impl MutableBuffer/new", "path": path, "direction": "callees", "max_depth": 1})
    ]
    save(out / "registration.json", {"image": image, "source_digest": reg["public_source_digest"],
        "requests": requests, "producer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "client_model_calls": 0, "paid_ready": False})
    spec = importlib.util.spec_from_file_location("lsp_v4_native", SCRIPTS / "prior_prepare_native.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.ROOT, module.IMAGE = out, image
    native = None
    try:
        native = module.Native("native", source, {"native_image": image,
            "runtime_manifest": str(PARENT / "native-runtime-private-v4.json")})
        native.start()
        rows = []
        for tool, args in requests:
            started = time.monotonic()
            response = native.tool(tool, args, timeout=300)
            save(out / (tool + ".json"), response)
            row = {"tool": tool, "wall_s": time.monotonic()-started, "transport_complete": True}
            rows.append(row)
            print(json.dumps(row), flush=True)
        assert _public_digest(source) == reg["public_source_digest"]
        save(out / "calls-completed.json", {"calls": rows, "source_unchanged": True, "client_model_calls": 0,
            "scope": "Transport completion only; inspect actual primary results before claiming successful LSP canaries", "paid_ready": False})
    except BaseException as exc:
        save(out / "failure.json", {"exception": type(exc).__name__, "message": str(exc), "paid_ready": False})
        raise
    finally:
        if native is not None: native.close()
if __name__ == "__main__":
    main()
