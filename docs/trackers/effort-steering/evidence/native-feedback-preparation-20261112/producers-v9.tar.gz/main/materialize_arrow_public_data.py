"""Version the common source with the exact public data declared by its canonical Gitlinks."""
from pathlib import Path
import hashlib
import json
import shutil
import sys
sys.path.insert(0, "/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from receipts import input_digest

ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/apache__arrow-rs-7783")

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")

def main():
    prior = ROOT / "common-preparation-v1/public-source"
    before = input_digest(prior)
    exports = ROOT / "public-submodules-v1"
    report = json.loads((exports / "result.json").read_bytes())
    assert report["client_model_calls"] == 0 and all(row["exit_code"] == 0 and row["cleanup_complete"] for row in report["rows"])
    out = ROOT / "public-data-materialization-v1"
    out.mkdir()
    source = out / "public-source"
    shutil.copytree(prior, source, symlinks=True)
    for row in report["rows"]:
        directory = exports / row["path"]
        assert sha(directory / "inventory.json") == row["inventory_sha256"]
        assert sha(directory / "source.tar") == row["archive_sha256"]
        inventory = json.loads((directory / "inventory.json").read_bytes())
        origin = directory / "source"
        actual = {p.relative_to(origin).as_posix():
            {"link": str(p.readlink())} if p.is_symlink() else {"sha256": sha(p), "bytes": p.stat().st_size}
            for p in origin.rglob("*") if p.is_symlink() or p.is_file()}
        assert actual == inventory
        target = source / row["path"]
        assert target.is_dir() and not target.is_symlink() and not any(target.iterdir())
        # Only remove the known empty exported Gitlink placeholder in this new owned copy.
        target.rmdir()
        shutil.copytree(origin, target, symlinks=True)
    expected_before = {p.relative_to(prior).as_posix() for p in prior.rglob("*")}
    assert input_digest(source, sorted(expected_before)) == before
    assert input_digest(prior) == before
    save(out / "registration.json", {"schema": "source-declared-public-data-materialization-v1",
        "prior_source": str(prior), "prior_source_sha256": before,
        "source": str(source), "source_sha256": input_digest(source),
        "canonical_exports": report["rows"], "exports_result_sha256": sha(exports / "result.json"),
        "producer_sha256": sha(Path(__file__)), "previous_public_inputs_unchanged": True,
        "additional_onboarding_calls": 0, "client_model_calls": 0, "paid_ready": False,
        "scope": "Only declared canonical public submodule data added; final template/index/image/control parity pending."})
    print(json.dumps({"public_source": str(source), "public_source_sha256": input_digest(source),
        "extra_onboarding_calls": 0, "paid_ready": False}), flush=True)

if __name__ == "__main__":
    main()
