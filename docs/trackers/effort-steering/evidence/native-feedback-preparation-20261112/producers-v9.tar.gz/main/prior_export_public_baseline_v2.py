"""Export only the declared public Git baseline; never read benchmark patches/outcomes."""
import datetime
import hashlib
import json
import pathlib
import subprocess
import sys
import tarfile
import uuid

ROOT = pathlib.Path(__file__).resolve().parent
OWNER = "codex:01a15ca9-f939-7603-acb5-01c6b02f68e2"


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")


def main(stem):
    image = json.loads((ROOT / (stem + "-v2-image-receipt.json")).read_text())
    records = json.loads((ROOT / "metadata-universe.json").read_text())["tasks"]
    task = next(r for r in records if r["id"] == image["id"])
    out = ROOT / (stem + "-public-v1")
    out.mkdir()
    command = ["docker", "create", "--name", "ep-cohort-source-" + uuid.uuid4().hex,
               "--label", "effort-cohort-owner=" + OWNER, "--network", "none", "--read-only",
               "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
               "--memory", "2g", "--memory-swap", "2g", "--cpus", "2", "--pids-limit", "128",
               "--entrypoint", "git", image["image_id"], "-c", "safe.directory=/testbed",
               "-C", "/testbed", "archive", "--format=tar", task["base_commit"]]
    save(out / "registration.json", {"recorded_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
         "argv": command, "task": task, "image": image,
         "exporter_sha256": hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()})
    cid = subprocess.check_output(command, text=True).strip()
    save(out / "created.json", {"cid": cid})
    report = {"id": task["id"], "cid": cid}
    try:
        before = json.loads(subprocess.check_output(["docker", "inspect", cid]))[0]
        assert before["Config"]["Labels"]["effort-cohort-owner"] == OWNER
        assert before["Image"] == image["image_id"]
        save(out / "inspect-before.json", before)
        with (out / "public-baseline.tar").open("xb") as archive, (out / "archive.stderr").open("x") as error:
            code = subprocess.run(["docker", "start", "-a", cid], stdout=archive, stderr=error,
                                  timeout=180).returncode
        after = json.loads(subprocess.check_output(["docker", "inspect", cid]))[0]
        save(out / "inspect-after.json", after)
        report.update(archive_exit=code, container_exit=after["State"]["ExitCode"],
                      oom_killed=after["State"]["OOMKilled"])
        assert code == 0 and after["State"]["ExitCode"] == 0 and not after["State"]["OOMKilled"]
        source = out / "source"
        source.mkdir()
        with tarfile.open(out / "public-baseline.tar") as archive:
            members = archive.getmembers()
            assert all(not pathlib.PurePosixPath(m.name).is_absolute()
                       and ".." not in pathlib.PurePosixPath(m.name).parts for m in members)
            assert all(m.isfile() or m.isdir() or m.issym() or m.islnk() for m in members)
            archive.extractall(source, filter="data")
        files = {}
        links = {}
        for path in source.rglob("*"):
            rel = str(path.relative_to(source))
            if path.is_symlink():
                links[rel] = str(path.readlink())
            elif path.is_file():
                files[rel] = {"bytes": path.stat().st_size,
                              "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
        save(out / "public-source-manifest.json", {"files": files, "links": links,
             "archive_sha256": hashlib.sha256((out / "public-baseline.tar").read_bytes()).hexdigest()})
        report.update(regular_paths=len(files), link_paths=len(links),
                      cargo_manifest=(source / "Cargo.toml").is_file(),
                      source_manifest_sha256=hashlib.sha256((out / "public-source-manifest.json").read_bytes()).hexdigest())
    except BaseException as error:
        report.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        facts = json.loads(subprocess.check_output(["docker", "inspect", cid]))[0]
        assert facts["Id"] == cid and facts["Config"]["Labels"]["effort-cohort-owner"] == OWNER
        if facts["State"]["Running"]:
            subprocess.run(["docker", "stop", "-t", "3", cid], check=True, capture_output=True)
        subprocess.run(["docker", "rm", "--volumes", cid], check=True, capture_output=True)
        absence = subprocess.run(["docker", "ps", "-a", "--no-trunc", "--filter", "id=" + cid, "--format", "{{.ID}}"], capture_output=True, text=True)
        report["cleanup_complete"] = absence.returncode == 0 and not absence.stdout.strip()
        save(out / "result.json", report)
    print(json.dumps(report), flush=True)


if __name__ == "__main__":
    main(sys.argv[1])
