"""Versioned registry-readability producer with an explicit actual parent manifest."""
from pathlib import Path
import argparse, hashlib, json, re, shlex, subprocess, sys
sys.dont_write_bytecode = True
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")
def inspect(image):
    return json.loads(subprocess.check_output(["docker", "image", "inspect", image]))[0]
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--task-id", required=True)
    parser.add_argument("--parent-metadata", type=Path, required=True)
    parser.add_argument("--denied-path", required=True)
    args = parser.parse_args()
    task = ROOT / args.task_id
    parent = json.loads(args.parent_metadata.read_bytes())
    before = inspect(parent["tag"])
    assert before["Id"] == parent["image"] and not before["Config"].get("Volumes")
    environment = dict(value.split("=", 1) for value in before["Config"]["Env"])
    registry = environment["CARGO_HOME"].rstrip("/") + "/registry"
    assert re.fullmatch(r"/[A-Za-z0-9_./-]+", registry) and ".." not in Path(registry).parts
    assert Path(args.denied_path).is_relative_to(registry)
    out = task / "readable-registry-image-v1"
    out.mkdir()
    code = "import hashlib,json,os,sys; from pathlib import Path; p=Path(sys.argv[1]); s=p.stat(); print(json.dumps({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'uid':os.getuid(),'owner':s.st_uid,'mode':oct(s.st_mode&4095)}))"
    original = subprocess.run(["docker", "run", "--rm", "--network", "none", "--read-only", "--user", "0:0",
        "--cap-drop", "ALL", "--security-opt", "no-new-privileges", "--entrypoint", "python3", before["Id"],
        "-I", "-B", "-c", code, args.denied_path], capture_output=True, timeout=60)
    assert original.returncode == 0
    original_file = json.loads(original.stdout)
    save(out / "denied-file-original.json", original_file)
    context = out / "context"
    context.mkdir()
    recipe = context / "Dockerfile"
    recipe.write_text("FROM " + parent["tag"] + "\nUSER root\nRUN chmod -R a+rX " + shlex.quote(registry) + "\n")
    tag = "effort-feedback-source:readable-registry-" + before["Id"][7:19]
    assert subprocess.run(["docker", "image", "inspect", tag], capture_output=True).returncode != 0
    save(out / "registration.json", {"parent_image": before["Id"], "parent_tag": parent["tag"],
        "registry": registry, "denied_path": args.denied_path, "recipe_sha256": sha(recipe),
        "parent_metadata": str(args.parent_metadata), "parent_metadata_sha256": sha(args.parent_metadata),
        "producer_sha256": sha(__file__), "client_model_calls": 0, "paid_ready": False})
    result = subprocess.run(["docker", "build", "--pull=false", "--network", "none", "-t", tag, str(context)],
        capture_output=True, timeout=1800)
    (out / "build.stdout").write_bytes(result.stdout)
    (out / "build.stderr").write_bytes(result.stderr)
    assert result.returncode == 0
    assert inspect(parent["tag"])["Id"] == parent["image"]
    after = inspect(tag)
    save(out / "image.json", after)
    observed = subprocess.run(["docker", "run", "--rm", "--network", "none", "--read-only", "--user", "1000:1000",
        "--cap-drop", "ALL", "--security-opt", "no-new-privileges", "--entrypoint", "python3", after["Id"],
        "-I", "-B", "-c", code, args.denied_path], capture_output=True, timeout=60)
    assert observed.returncode == 0
    readable = json.loads(observed.stdout)
    save(out / "denied-file-readable.json", readable)
    assert readable["uid"] == 1000 and readable["sha256"] == original_file["sha256"]
    audit = """import os,json,sys,stat
from pathlib import Path
root=Path(sys.argv[1]); errors=[]; regular=directories=links=0
def walk_error(exc): errors.append({'path':exc.filename,'error':str(exc)})
for directory,names,files in os.walk(root,onerror=walk_error,followlinks=False):
 directories+=1
 if not os.access(directory,os.R_OK|os.X_OK): errors.append({'path':directory,'error':'directory access'})
 for name in names+files:
  p=Path(directory)/name
  try:
   mode=p.lstat().st_mode
   if stat.S_ISLNK(mode):
    links+=1
    if not p.resolve().is_relative_to(root): errors.append({'path':str(p),'error':'escaping link'})
   elif stat.S_ISREG(mode):
    regular+=1
    with p.open('rb') as stream: stream.read(1)
  except OSError as exc: errors.append({'path':str(p),'error':str(exc)})
print(json.dumps({'uid':os.getuid(),'visited_regular_files':regular,'visited_directories':directories,'symlinks':links,'errors':errors}))
"""
    command = ["docker", "run", "--rm", "--network", "none", "--read-only", "--user", "1000:1000",
        "--cap-drop", "ALL", "--security-opt", "no-new-privileges", "--memory", "512m", "--memory-swap", "512m",
        "--cpus", "2", "--pids-limit", "64", "--entrypoint", "python3", after["Id"], "-I", "-B", "-c", audit, registry]
    result = subprocess.run(command, capture_output=True, timeout=300)
    (out / "audit.stdout").write_bytes(result.stdout)
    (out / "audit.stderr").write_bytes(result.stderr)
    assert result.returncode == 0
    tested = json.loads(result.stdout)
    save(out / "registry-readability.json", tested)
    assert tested["uid"] == 1000 and tested["visited_regular_files"] > 0 and tested["errors"] == []
    save(out / "result.json", {"image": after["Id"], "tag": tag, "parent_image": before["Id"],
        "exact_failed_file_bytes_unchanged": True, "registry_permission_probe": tested,
        "client_model_calls": 0, "paid_ready": False, "scope": "Read/open permission only; exact ordinary/broader compilation, private/native qualification pending"})
    print(json.dumps({"image": after["Id"], "visited_regular_files": tested["visited_regular_files"], "permission_errors": len(tested["errors"]), "paid_ready": False}))

if __name__ == "__main__":
    main()
