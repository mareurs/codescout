"""Apply the exact frozen restorer to candidate-mutated fixture inputs; no benchmark verdict."""
from pathlib import Path
import hashlib, json, subprocess, sys, uuid
sys.dont_write_bytecode = True
sys.path.insert(0, "/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from evaluator_entry import verify_package
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/skim-rs__skim-1044")
def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")
def main():
    config = json.loads(Path("/var/tmp/ep11-01a15/private-controls/obscura/config.json").read_bytes())
    package = verify_package(config["package_root"], config["package_files"])
    sys.path.insert(0, str(package))
    import multilang_tasks as tasks
    record = json.loads((ROOT / "private-structure-v1/original-record.json").read_bytes())
    protected = tasks.tasks.patch_files(record["test_patch"])
    candidates = sorted(p.relative_to(ROOT / "source").as_posix() for p in (ROOT / "source").rglob("*.snap"))
    outside = next(path for path in candidates if path not in protected)
    out = ROOT / "test-restore-scope-probe-v1"
    out.mkdir()
    source = out / "fixture"
    source.mkdir()
    for name in [*protected, outside]:
        target = source / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text("canonical fixture input\n")
    subprocess.run(["git", "init", "-q"], cwd=source, check=True)
    subprocess.run(["git", "add", "."], cwd=source, check=True)
    subprocess.run(["git", "-c", "user.name=Restore scope fixture", "-c", "user.email=fixture@invalid",
        "commit", "-qm", "Canonical fixture inputs"], cwd=source, check=True)
    for name in [*protected, outside]: (source / name).write_text("candidate controlled input\n")
    image = json.loads((ROOT / "common-preparation-v1/registration.json").read_bytes())["image"]
    command = ["docker", "run", "--rm", "--pull=never", "--name", "ep-restore-scope-" + uuid.uuid4().hex,
        "--label", "effort-feedback-owner=codex-01a15ca9", "--network", "none", "--read-only", "--user", "1000:1000",
        "--cap-drop", "ALL", "--security-opt", "no-new-privileges", "--memory", "256m", "--memory-swap", "256m",
        "--cpus", "1", "--pids-limit", "64", "--mount", "type=bind,src=" + str(source) + ",dst=/testbed",
        "--workdir", "/testbed", "--entrypoint", "sh", image, "-c", tasks.tasks.RESTORE_SH, "restore", *protected]
    save(out / "registration.json", {"image": image, "argv": command, "actual_official_paths": protected,
        "actual_other_snapshot_path": outside, "restore_source_sha256": hashlib.sha256(tasks.tasks.RESTORE_SH.encode()).hexdigest(),
        "scope": "Exact restorer/actual path arguments on placeholder fixture bytes; no task test execution or false-acceptance claim.",
        "client_model_calls": 0, "paid_ready": False})
    result = subprocess.run(command, capture_output=True, timeout=60)
    (out / "stdout").write_bytes(result.stdout)
    (out / "stderr").write_bytes(result.stderr)
    assert result.returncode == 0
    assert all((source / name).read_text() == "canonical fixture input\n" for name in protected)
    persists = (source / outside).read_text() == "candidate controlled input\n"
    assert persists
    verify_package(package, config["package_files"])
    summary = {"official_paths_restored": len(protected), "other_existing_snapshot_stays_candidate_controlled": persists,
        "other_snapshot": outside, "frozen_package_unchanged": True, "client_model_calls": 0, "paid_ready": False,
        "scope": "Restoration gap only; actual benchmark false acceptance not run."}
    save(out / "result.json", summary)
    print(json.dumps(summary), flush=True)
if __name__ == "__main__":
    main()
