"""Run three preregistered independent deterministic controls, retaining every failure."""
from pathlib import Path
import hashlib, json, os, subprocess, sys, time
sys.dont_write_bytecode = True
WORK = Path("/home/marius/.codex/worktrees/2aa6/codescout")
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/skim-rs__skim-1044/private-preparation-v1")
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")
def main():
    registration = json.loads((ROOT / "registration.json").read_bytes())
    assert registration["client_model_calls"] == 0 and registration["paid_ready"] is False
    config = json.loads((ROOT / "config.json").read_bytes())
    assert sha(ROOT / "config.json") == registration["config_sha256"]
    for path, expected in config["bindings"].items():
        assert sha(path) == expected, path
    entry = WORK / "tools/effort_protocol/evaluator_entry.py"
    save(ROOT / "control-run-started.json", {"registration_sha256": sha(ROOT / "registration.json"),
        "entry_sha256": sha(entry), "producer_sha256": sha(__file__), "time": time.time(),
        "client_model_calls": 0, "scope": "Actual 4CPU/8GiB independent grader controls; CPU cost unmeasured"})
    rows = []
    for control in registration["controls"]:
        request = Path(control["request"])
        assert sha(request) == control["request_sha256"]
        out = request.parent / "evaluation"
        out.mkdir()
        start = time.monotonic()
        with (out / "process.stdout").open("xb") as stdout, (out / "process.stderr").open("xb") as stderr:
            result = subprocess.run([sys.executable, "-I", "-B", str(entry), str(request), str(out)],
                cwd=WORK, stdout=stdout, stderr=stderr, timeout=3600,
                env={"PATH": os.environ["PATH"], "HOME": os.environ["HOME"], "TMPDIR": "/tmp", "PYTHONDONTWRITEBYTECODE": "1"})
        assert sha(entry) == json.loads((ROOT / "control-run-started.json").read_bytes())["entry_sha256"]
        verdict = json.loads((out / "verdict.json").read_bytes()) if (out / "verdict.json").exists() else None
        row = {"name": control["name"], "process_returncode": result.returncode, "wall_s": time.monotonic()-start,
            "expected_pass": control["expected_pass"], "verdict": verdict, "verdict_path": str(out / "verdict.json"),
            "verdict_sha256": sha(out / "verdict.json") if verdict is not None else None}
        rows.append(row)
        save(request.parent / "control-result.json", row)
        print(json.dumps({"control": control["name"], "process_returncode": result.returncode,
            "valid": verdict.get("valid") if verdict else None, "pass": verdict.get("pass") if verdict else None,
            "kind": verdict.get("kind") if verdict else None}), flush=True)
        if not (result.returncode == 0 and verdict is not None and verdict.get("valid") is True
                and verdict.get("pass") is control["expected_pass"]):
            save(ROOT / "controls-stopped.json", {"controls": rows, "paid_ready": False,
                "reason": "First invalid or contradicted deterministic control; no private/model resampling."})
            return 1
    save(ROOT / "controls-result.json", {"controls": rows, "all_three_controls_met": True,
        "client_model_calls": 0, "paid_ready": False,
        "scope": "One task private acceptance controls only; other tasks/native runtime/gate/review still pending"})
    return 0
if __name__ == "__main__":
    raise SystemExit(main())
