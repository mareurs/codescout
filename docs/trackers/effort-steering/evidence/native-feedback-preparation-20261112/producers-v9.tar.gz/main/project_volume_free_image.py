"""Preserve a minimal image's rootfs/config while removing only empty temporary VOLUME declarations."""
from pathlib import Path, PurePosixPath
import argparse, hashlib, json, os, shutil, subprocess, sys, tarfile, uuid
sys.dont_write_bytecode = True
from export_public_git_base import volume_options
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
OWNER = "codex:01a15ca9-f939-7603-acb5-01c6b02f68e2"
def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024*1024), b""): digest.update(block)
    return digest.hexdigest()
def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")
def inspect(image):
    return json.loads(subprocess.check_output(["docker", "image", "inspect", image]))[0]
def changes(config):
    assert set(config) <= {"Env", "Cmd", "Labels", "WorkingDir", "Volumes"}, "unmeasured image configuration"
    result, seen = [], set()
    for value in config.get("Env", []):
        key, sep, text = value.partition("=")
        assert sep and key not in seen and key and not any(c in value for c in '\n\r"\\$')
        seen.add(key)
        result += ["--change", "ENV " + key + "=" + json.dumps(text)]
    if config.get("Cmd") is not None:
        assert isinstance(config["Cmd"], list) and all(isinstance(x, str) for x in config["Cmd"])
        result += ["--change", "CMD " + json.dumps(config["Cmd"])]
    for key, value in sorted((config.get("Labels") or {}).items()):
        assert key and not any(c in key+value for c in '\n\r"\\$')
        result += ["--change", "LABEL " + key + "=" + json.dumps(value)]
    if config.get("WorkingDir"):
        assert config["WorkingDir"].startswith("/") and not any(c.isspace() for c in config["WorkingDir"])
        result += ["--change", "WORKDIR " + config["WorkingDir"]]
    return result
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--task-id", required=True)
    args = parser.parse_args()
    task = ROOT / args.task_id
    base = json.loads((task / "registration.json").read_bytes())
    parent = inspect(base["image_id"])
    assert parent["Id"] == base["image_id"] and parent["Os"] == "linux" and parent["Architecture"] == "amd64"
    assert not parent.get("Variant")
    config = parent["Config"]
    edits = changes(config)
    shadows, expected_tmpfs = volume_options(parent)
    assert shadows
    source = task / "source"
    for destination in expected_tmpfs:
        relative = PurePosixPath(destination).relative_to("/testbed")
        assert not (source / str(relative)).exists() and not (source / str(relative)).is_symlink()
    out = task / "volume-free-image-v1"
    out.mkdir()
    assert shutil.disk_usage(out).free >= 2*parent["Size"] + 80*1024**3
    tag = "effort-feedback-source:volume-free-" + parent["Id"][7:19]
    assert subprocess.run(["docker", "image", "inspect", tag], capture_output=True).returncode != 0, "owned tag exists"
    name = "ep-volume-projection-" + uuid.uuid4().hex
    command = ["docker", "create", "--name", name, "--label", "effort-feedback-owner=" + OWNER,
        "--network", "none", "--read-only", "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
        "--memory", "512m", "--memory-swap", "512m", "--cpus", "1", "--pids-limit", "64", *shadows,
        "--entrypoint", "/bin/true", parent["Id"]]
    save(out / "registration.json", {"parent_image": parent["Id"], "producer_sha256": sha(__file__),
        "dependency_sha256": sha(Path(__file__).with_name("export_public_git_base.py")),
        "config_before": config, "declared_shadows": expected_tmpfs, "argv": command,
        "client_model_calls": 0, "scope": "Empty temporary volume metadata removal only; strict runtime controls still required.", "paid_ready": False})
    cid = subprocess.check_output(command, text=True).strip()
    save(out / "created.json", {"cid": cid})
    def owned():
        row = json.loads(subprocess.check_output(["docker", "inspect", cid]))[0]
        assert row["Id"] == cid and row["Image"] == parent["Id"]
        assert row["Config"]["Labels"]["effort-feedback-owner"] == OWNER
        assert not row["State"]["Running"] and row["HostConfig"]["ReadonlyRootfs"] is True
        assert row["HostConfig"]["Tmpfs"] == expected_tmpfs and not row["HostConfig"].get("Binds")
        assert all(m["Type"] == "tmpfs" for m in row["Mounts"])
        return row
    try:
        save(out / "container-before.json", owned())
        archive = out / "rootfs.tar"
        with archive.open("xb") as stream:
            subprocess.run(["docker", "export", cid], stdout=stream, check=True, timeout=1800)
        prefixes = [name.lstrip("/") + "/" for name in expected_tmpfs]
        with tarfile.open(archive, "r:") as tar:
            members = tar.getmembers()
            assert all(not any(m.name.startswith(prefix) for prefix in prefixes) for m in members), "nonempty volume backing directory"
            rootfs_entry_count = len(members)
        imported = subprocess.run(["docker", "import", "--platform", "linux/amd64", *edits, str(archive), tag],
            capture_output=True, timeout=1800)
        (out / "import.stdout").write_bytes(imported.stdout)
        (out / "import.stderr").write_bytes(imported.stderr)
        assert imported.returncode == 0
        image = inspect(tag)
        save(out / "image.json", image)
        actual = image["Config"]
        assert not actual.get("Volumes")
        assert image["Os"] == parent["Os"] and image["Architecture"] == parent["Architecture"]
        assert actual.get("Cmd") == config.get("Cmd") and actual.get("WorkingDir", "") == config.get("WorkingDir", "")
        assert (actual.get("Labels") or {}) == (config.get("Labels") or {})
        wanted = dict(v.split("=", 1) for v in config.get("Env", []))
        observed = dict(v.split("=", 1) for v in actual.get("Env", []))
        assert len(observed) == len(actual.get("Env", [])) and observed == wanted
        assert not actual.get("User") and not actual.get("Entrypoint") and not actual.get("OnBuild")
        assert inspect(parent["Id"])["Config"] == config
        save(out / "container-after.json", owned())
        save(out / "projection.json", {"image": image["Id"], "tag": tag, "parent_image": parent["Id"],
            "nonvolume_effective_config_unchanged": True, "removed_volume_destinations": sorted(expected_tmpfs),
            "underlying_volume_directories_empty": True, "rootfs_tar_bytes": archive.stat().st_size,
            "rootfs_tar_entries": rootfs_entry_count, "rootfs_tar_sha256": sha(archive),
            "canonical_git_readback_pending": True, "client_model_calls": 0, "paid_ready": False})
        print(json.dumps({"image": image["Id"], "canonical_git_readback_pending": True, "paid_ready": False}), flush=True)
    finally:
        save(out / "cleanup-inspect.json", owned())
        subprocess.run(["docker", "rm", "--volumes", cid], check=True, capture_output=True)
        absent = subprocess.run(["docker", "ps", "-a", "--quiet", "--filter", "id=" + cid], capture_output=True, text=True)
        save(out / "cleanup.json", {"complete": absent.returncode == 0 and not absent.stdout.strip(), "container": cid})
if __name__ == "__main__":
    main()
