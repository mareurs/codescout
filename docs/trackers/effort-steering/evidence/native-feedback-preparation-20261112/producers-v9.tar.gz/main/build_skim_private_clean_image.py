"""Prospective clean private image from frozen builder plus declared common source."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
sys.path.insert(0,"/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from evaluator_entry import verify_package, _input_digest
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/skim-rs__skim-1044")
OUT = ROOT/"private-clean-image-v1"
PARENT_TAG = "effort-feedback-source:readable-registry-9db77a613aa4"
EXPECTED = "sha256:d6e877bbf3808e02c778de60b55af6a7dd821e83915d5947432ba8b388d1a1f2"
TAG = "effort-feedback-skim-private-clean:20261112-01a15-v1"


def save(path,value):
    with path.open("x") as stream:
        json.dump(value,stream,sort_keys=True,indent=2)
        stream.write("\n")


def inspect(tag):
    result = subprocess.run(["docker","image","inspect",tag],capture_output=True,check=True)
    values = json.loads(result.stdout)
    assert len(values)==1
    return values[0]


def main():
    OUT.mkdir()
    free = shutil.disk_usage(OUT).free
    assert free >= 80*1024**3
    config = json.loads(Path("/var/tmp/ep11-01a15/private-controls/obscura/config.json").read_bytes())
    package = verify_package(config["package_root"],config["package_files"])
    sys.path.insert(0,str(package))
    import multilang_tasks as tasks
    record_path = ROOT/"private-structure-v1/original-record.json"
    record = json.loads(record_path.read_bytes())
    public = ROOT/"common-preparation-v1/public-source"
    before_digest = _input_digest(public)
    before = inspect(PARENT_TAG)
    assert before["Id"] == EXPECTED and not before["Config"].get("Volumes")
    save(OUT/"parent-before.json",before)
    context = OUT/"context"
    context.mkdir()
    shutil.copytree(public,context/"public-source",symlinks=True)
    # Use the reviewed historical cleanup/rebuild steps, never a raw gold target cache.
    frozen_recipe = tasks.live_dockerfile(PARENT_TAG,record,"/testbed")
    assert frozen_recipe.count("USER root\n")==1
    recipe = frozen_recipe.replace("USER root\n","USER root\nRUN chown -R 0:0 /testbed\n",1)
    recipe += ("USER root\nRUN rm -f /testbed/CLAUDE.md\n"
               "COPY --chown=0:0 public-source/ /testbed/\n"
               "RUN chown -R 0:0 /testbed && git -C /testbed rev-parse HEAD "
               "&& test \"$(stat -c %u /testbed)\" = 0 "
               "&& test \"$(stat -c %u /testbed/.git)\" = 0\n")
    (context/"Dockerfile").write_text(recipe)
    save(OUT/"registration.json",{"schema":"prospective-private-clean-image-v1",
        "parent_image":EXPECTED,"parent_tag":PARENT_TAG,"tag":TAG,
        "original_record_sha256":hashlib.sha256(record_path.read_bytes()).hexdigest(),
        "public_source":str(public),"public_source_digest":before_digest,
        "recipe_sha256":hashlib.sha256(recipe.encode()).hexdigest(),
        "frozen_builder_sha256":hashlib.sha256(Path(tasks.__file__).read_bytes()).hexdigest(),
        "producer_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "host_disk_free_bytes":free,
        "scope":"Frozen base reset, workspace/gold-cache cleanup and offline base rebuild; identical declared common source, private root ownership. No global Git/toolchain change.",
        "provider_calls":0,"paid_ready":False})
    result = subprocess.run(["docker","build","--pull=false","--network","none","-t",TAG,str(context)],
                            capture_output=True,timeout=2400)
    (OUT/"stdout.log").write_bytes(result.stdout)
    (OUT/"stderr.log").write_bytes(result.stderr)
    save(OUT/"command.json",{"returncode":result.returncode})
    assert result.returncode==0
    after = inspect(PARENT_TAG)
    save(OUT/"parent-after.json",after)
    assert after["Id"]==EXPECTED
    image = inspect(TAG)
    assert not image["Config"].get("Volumes") and image["Config"]["User"]=="root"
    save(OUT/"image.json",image)
    assert _input_digest(public)==before_digest
    verify_package(package,config["package_files"])
    save(OUT/"result.json",{"image":image["Id"],"parent_image":EXPECTED,
        "public_source_unchanged":True,"frozen_package_unchanged":True,
        "cache_cleanup_builder_executed":True,
        "unverified":"Full public source readback, original label benchmark controls and actual native actor projection still pending.",
        "provider_calls":0,"paid_ready":False})
    print(json.dumps({"image":image["Id"],"provider_calls":0,"paid_ready":False}))


if __name__=="__main__":
    main()
