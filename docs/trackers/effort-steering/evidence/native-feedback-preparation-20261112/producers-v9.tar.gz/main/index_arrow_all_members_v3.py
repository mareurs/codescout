"""Index and query every configured member; no repair, author or repeated onboarding call."""
from pathlib import Path
import hashlib, importlib.util, json, subprocess, sys, time
sys.dont_write_bytecode = True
sys.path.insert(0, "/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from embedding_runtime import embedding_runtime
from native_executor import _public_digest
import executor
SCRIPTS = Path("/home/marius/work/claude/codescout/.superpowers/sdd/2026-11-11-native-public-feedback-transfer")
PARENT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/apache__arrow-rs-7783/common-preparation-v3")
def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")
def main():
    previous = PARENT / "corrected-first-member-v2"
    assert json.loads((previous / "result.json").read_bytes())["member_query_has_scoped_hits"]
    for name in ("native", "embedding"):
        row = json.loads((previous / name / "cleanup.json").read_bytes())
        assert row.get("complete", row.get("cleanup_complete")) is True
    reg = json.loads((PARENT / "registration.json").read_bytes())
    project = PARENT / "project"
    source_sha = reg["public_source_digest"]
    assert _public_digest(project) == source_sha
    out = PARENT / "all-configured-members-v1"
    out.mkdir()
    relay = out / "embedding"
    relay.mkdir()
    configuration = json.loads((previous / "registration.json").read_bytes())["embedding"]
    image = reg["index_image"]
    members = [item for item in reg["configured_projects"] if item["root"] != "."]
    assert len(members) == len({item["id"] for item in members}) and members
    save(out / "registration.json", {"configured_members": members, "public_digest": source_sha,
        "image": image, "runtime_sha256": hashlib.sha256((PARENT / "native-runtime-index.json").read_bytes()).hexdigest(),
        "producer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), "client_model_calls": 0,
        "additional_onboarding_calls": 0, "embedding_compute_cost_usd": None, "paid_ready": False,
        "scope": "All configured member namespaces, not every possible nested project or relevance-quality evaluation"})
    spec = importlib.util.spec_from_file_location("all_member_native", SCRIPTS / "prior_prepare_native.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.ROOT, module.IMAGE = out, image
    original = module._native_argv
    with embedding_runtime(relay, image, configuration) as descriptor:
        def private_argv(actor, home, config):
            argv = original(actor, home, config)
            argv[argv.index("--network") + 1] = descriptor["network_id"]
            return argv
        module._native_argv = private_argv
        native = None
        try:
            native = module.Native("native", project, {"native_image": image,
                "runtime_manifest": str(PARENT / "native-runtime-index.json")})
            native.start()
            actual = executor._inspect(native.cid)
            assert len(actual["NetworkSettings"]["Networks"]) == 1
            assert next(iter(actual["NetworkSettings"]["Networks"].values()))["NetworkID"] == descriptor["network_id"]
            rows = []
            for entry in members:
                identity, relative = entry["id"], Path(entry["root"])
                assert not relative.is_absolute() and ".." not in relative.parts
                directory = out / identity
                directory.mkdir()
                started = time.monotonic()
                result = subprocess.run(["docker", "exec", native.cid, "/bench/bin/codescout",
                    "index", "-p", "/testbed/" + relative.as_posix()], capture_output=True, timeout=1800)
                (directory / "index.stdout").write_bytes(result.stdout)
                (directory / "index.stderr").write_bytes(result.stderr)
                save(directory / "command.json", {"returncode": result.returncode, "wall_s": time.monotonic()-started})
                assert result.returncode == 0
                state = json.loads((project / relative / ".codescout/index-state.json").read_bytes())
                save(directory / "index-state.json", state)
                assert state["indexed_with_model"] == "CodeRankEmbed"
                response = native.tool("semantic_search", {"query": identity.replace("-", " ").replace("_", " ") + " source implementation",
                    "project_id": identity, "limit": 3}, timeout=240)
                save(directory / "semantic.json", response)
                payload = json.loads(response["result"]["content"][0]["text"])
                assert payload.get("ok") is not False and payload.get("results"), payload
                for hit in payload["results"]:
                    path = Path(hit["file_path"])
                    assert not path.is_absolute() and ".." not in path.parts
                    local = project / relative / path
                    assert local.is_file() and not local.is_symlink()
                    lines = local.read_text().splitlines()
                    text = "\n".join(lines[hit["start_line"]-1:hit["end_line"]])
                    assert hit["content"].strip() in text and hit["source"] == "stack", hit
                assert _public_digest(project) == source_sha
                row = {"id": identity, "root": relative.as_posix(), "model": state["indexed_with_model"],
                    "returned_hits_checked": len(payload["results"]), "source_unchanged": True}
                rows.append(row)
                save(directory / "result.json", row)
                print(json.dumps({"member_complete": identity, "returned_hits_checked": len(payload["results"])}), flush=True)
            save(out / "root-index-verification.json", native.tool("index", {"action": "verify"}, timeout=240))
            assert _public_digest(project) == source_sha
            save(out / "result.json", {"members": rows, "configured_member_count": len(members),
                "source_unchanged": True, "client_model_calls": 0, "additional_onboarding_calls": 0,
                "scope": "Configured namespace code retrieval only; LSP/first paid CLI context/private acceptance/final qualification pending",
                "paid_ready": False})
        except BaseException as exc:
            save(out / "failure.json", {"exception": type(exc).__name__, "message": str(exc), "paid_ready": False})
            raise
        finally:
            module._native_argv = original
            if native is not None: native.close()
if __name__ == "__main__":
    main()
