"""Read back every common source file/link from the rebuilt image as its actor user."""
from pathlib import Path
import hashlib
import json
import subprocess
import uuid
import sys
sys.path.insert(0, "/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from receipts import input_digest

MAIN = Path("/home/marius/work/claude/codescout")
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/apache__arrow-rs-7783")
def main():
    source = ROOT / "public-data-materialization-v1/public-source"
    before = input_digest(source)
    expected = {"/testbed/" + p.relative_to(source).as_posix():
        {"link": str(p.readlink())} if p.is_symlink() else
        {"sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
        for p in source.rglob("*") if p.is_symlink() or p.is_file()}
    image_file = MAIN / ".superpowers/sdd/2026-11-11-native-public-feedback-transfer/arrow-gitlink-image.json"
    image = json.loads(image_file.read_bytes())[0]["Id"]
    out = ROOT / "image-source-readback-v1"
    out.mkdir()
    code = """import sys,json,pathlib,hashlib,os
expected=json.load(sys.stdin)
actual={}
for name in expected:
 p=pathlib.Path(name)
 try:
  actual[name]={'link':str(p.readlink())} if p.is_symlink() else {'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} if p.is_file() else None
 except OSError as exc:
  actual[name]={'error':type(exc).__name__+':'+str(exc)}
print(json.dumps({'actual':actual,'user':os.getuid()}))
"""
    name = "ep-source-readback-" + uuid.uuid4().hex
    command = ["docker", "run", "--rm", "--pull=never", "-i", "--name", name,
        "--label", "codescout.public-readback=codex-01a15ca9", "--network", "none", "--read-only",
        "--user", "1000:1000", "--memory", "512m", "--memory-swap", "512m", "--cpus", "2",
        "--pids-limit", "128", "--cap-drop=ALL", "--security-opt", "no-new-privileges",
        "--entrypoint", "python3", image, "-I", "-B", "-c", code]
    (out / "registration.json").write_text(json.dumps({"image": image, "source": str(source),
        "source_sha256": before, "argv": command, "expected": expected,
        "producer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "scope": "Full common file/link image readback only; not evaluator qualification."}, indent=2))
    result = subprocess.run(command, input=json.dumps(expected).encode(), capture_output=True, timeout=180)
    (out / "stdout").write_bytes(result.stdout)
    (out / "stderr").write_bytes(result.stderr)
    assert result.returncode == 0, result.stderr.decode(errors="replace")
    observed = json.loads(result.stdout)
    assert observed["user"] == 1000
    differences = {key: {"expected": value, "actual": observed["actual"].get(key)}
        for key, value in expected.items() if observed["actual"].get(key) != value}
    absence = subprocess.run(["docker", "ps", "-a", "--quiet", "--filter", "name=^/" + name + "$"],
        capture_output=True, text=True)
    summary = {"source_entries": len(expected), "differences": differences,
        "same_common_source_bytes": not differences, "user": observed["user"],
        "source_unchanged": input_digest(source) == before,
        "cleanup_complete": absence.returncode == 0 and not absence.stdout.strip(),
        "image": image, "client_model_calls": 0, "paid_ready": False}
    (out / "result.json").write_text(json.dumps(summary, sort_keys=True, indent=2))
    print(json.dumps(summary), flush=True)
    assert not differences and summary["source_unchanged"] and summary["cleanup_complete"]

if __name__ == "__main__":
    main()
