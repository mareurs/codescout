"""Reopen all original-label private controls and their source/input/runtime bindings."""
from pathlib import Path
import hashlib
import json
import sys

sys.dont_write_bytecode=True
sys.path.insert(0,"/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from evaluator_entry import verify_package
import feedback_nextest as nextest
import trusted_test_inputs as trusted
ROOT=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/skim-rs__skim-1044/private-preparation-v1")
OUT=Path("/home/marius/work/claude/codescout/docs/trackers/effort-steering/evidence/native-feedback-preparation-20261112/skim-private-v1-control-audit.json")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    reg=json.loads((ROOT/"registration.json").read_bytes())
    cfg=json.loads((ROOT/"config.json").read_bytes())
    terminal=json.loads((ROOT/"controls-result.json").read_bytes())
    started=json.loads((ROOT/"control-run-started.json").read_bytes())
    assert sha(ROOT/"config.json")==reg["config_sha256"]
    assert terminal["all_three_controls_met"] is True and len(terminal["controls"])==3
    assert [r["name"] for r in terminal["controls"]]==["baseline","reference","reference-repeat"]
    for name,digest in cfg["bindings"].items():
        assert sha(name)==digest,name
    verify_package(cfg["package_root"],cfg["package_files"])
    record=json.loads(Path(cfg["record"]).read_bytes())
    original=json.loads((ROOT/"original-record.json").read_bytes())
    assert record==nextest.prepare_record(original)
    assert len(record["FAIL_TO_PASS"]+record["PASS_TO_PASS"])==reg["selected_label_count"]==588
    roots,entries,_=trusted._validated(cfg["trusted_test_inputs"])
    identifiers=[]
    controls=[]
    for declared,observed in zip(reg["controls"],terminal["controls"]):
        request=Path(declared["request"])
        assert sha(request)==declared["request_sha256"]
        row=json.loads((request.parent/"control-result.json").read_bytes())
        assert row==observed
        assert row["process_returncode"]==0 and sha(row["verdict_path"])==row["verdict_sha256"]
        verdict=json.loads(Path(row["verdict_path"]).read_bytes())
        assert verdict==row["verdict"]
        assert verdict["valid"] is True and verdict["pass"] is declared["expected_pass"]
        assert verdict["adjusted"]["expected"]==588 and verdict["adjusted"]["missing"]==0
        if declared["name"]=="baseline":
            assert verdict["adjusted"]["not_passing"]==1
            assert verdict["adjusted"]["examples"]==record["FAIL_TO_PASS"]
        else:
            assert verdict["adjusted"]["not_passing"]==0
        evaluation=request.parent/"evaluation"
        runtime=json.loads((evaluation/"runtime-proof.json").read_bytes())
        assert runtime["complete"] and runtime["errors"]==[] and runtime["fresh_absence"]==[True]
        assert runtime["cgroup_probes"]==2 and runtime["oom_kill"]==0
        observations=[json.loads(line) for line in (evaluation/"runtime-observations.jsonl").read_text().splitlines()]
        assert [r["stage"] for r in observations]==["after-start","before-remove"]
        cid=observations[0]["inspect"]["Id"]
        assert observations[1]["inspect"]["Id"]==cid
        identifiers.append(cid)
        versions=observations[0]["runner_versions"]
        assert len(versions)==1 and versions[0]["actual"]==versions[0]["expected"]==cfg["stream_registration"]["tests"][0]["runner_version"]
        install=json.loads((evaluation/"trusted-input-installation.json").read_bytes())
        before_remove=observations[1]["trusted_test_inputs"]
        for proof in (install["restoration"],before_remove):
            assert proof["complete"] is True and proof["entries_verified"]==len(entries)
            assert proof["manifest_sha256"]==cfg["trusted_test_inputs"]["manifest_sha256"]
            assert proof["roots"]==roots
        entry=json.loads((evaluation/"private-entry-started.json").read_bytes())
        assert entry["entry_sha256"]==started["entry_sha256"]==sha(Path("/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol/evaluator_entry.py"))
        controls.append({"name":declared["name"],"valid":True,"pass":verdict["pass"],"kind":verdict["kind"],
            "expected":588,"missing":0,"not_passing":verdict["adjusted"]["not_passing"],
            "canonical_input_entries_verified":len(entries),"runtime_complete":True,"owned_cleanup":True,
            "wall_s":row["wall_s"],"verdict_path":row["verdict_path"],"verdict_sha256":row["verdict_sha256"]})
    assert len(set(identifiers))==3
    verify_package(cfg["package_root"],cfg["package_files"])
    result={"schema":"original-label-private-controls-audit-v1","task":reg["task"],"image":reg["image"],
        "all_three_controls_met":True,"controls":controls,"frozen_package_files_reopened":len(cfg["package_files"]),
        "private_bindings_reopened":len(cfg["bindings"]),"canonical_input_roots":roots,
        "canonical_input_entries":len(entries),"registration_sha256":sha(ROOT/"registration.json"),
        "config_sha256":sha(ROOT/"config.json"),"producer_sha256":sha(__file__),
        "provider_calls":0,"paid_ready":False,
        "scope":"One-task independent acceptance/input/runtime controls only; final public/native/all-cohort/gate/review remain pending."}
    with OUT.open("x") as stream:
        json.dump(result,stream,sort_keys=True,indent=2)
        stream.write("\n")
    print(json.dumps(result,sort_keys=True))


if __name__=="__main__":
    main()
