"""Index an existing source-only corpus once through the qualified embedding relay."""
import hashlib
import json
import pathlib
import re
import shutil
import subprocess
import sys
import time
import uuid

ROOT = pathlib.Path(__file__).resolve().parent
OLD = pathlib.Path("/home/marius/.cache/codescout-resident/codescout/common-preparation-20261109")
PROTOCOL = pathlib.Path("/home/marius/.codex/worktrees/cf66/codescout/tools/effort_protocol")
sys.path[:0] = [str(OLD), str(PROTOCOL)]
import prepare_native
import executor
from native_executor import _public_digest

def save(path, value):
    with path.open("x") as f:
        json.dump(value, f, indent=2)
        f.write("\n")

def main(stem):
    assert re.fullmatch(r"[a-z0-9-]+", stem)
    parent = ROOT / ("common-" + stem + "-v1")
    project = parent / "project"
    prep = json.loads((parent / "preparation.json").read_text())
    assert _public_digest(project) == prep["prepared_public_digest"]
    out = parent / "index-coderank-v1"
    out.mkdir()
    image = prep["image"]
    relay = out / "embedding_relay.py"
    shutil.copy2(PROTOCOL / "embedding_relay.py", relay)
    assert hashlib.sha256(relay.read_bytes()).hexdigest() == "16ceb890a5c341f8698251c35d486ab09dc70946ece621f316feddc2850e1839"
    service = executor._inspect("codescout-dense-amd")
    assert service["State"]["Running"]
    assert service["Id"] == "88e74239478cbedcf13732d05417292c3eed43054a2b1b3ea88f8d122abb1ff8"
    assert service["Image"] == "sha256:be175932c3c96e882dfbc7e20e0e834f58c89c2925f48b222837ee929dfc47ee"
    upstream = "codescout-retrieval_retrieval_net"
    assert upstream in service["NetworkSettings"]["Networks"]
    suffix = uuid.uuid4().hex
    network, name = "ep-cohort-embed-" + suffix, "ep-cohort-relay-" + suffix
    proxy = native = None
    network_id = None
    save(out / "registration.json", {"source_digest": prep["prepared_public_digest"],
         "source": str(project), "image": image, "model": "CodeRankEmbed", "dimensions": 768,
         "service_id": service["Id"], "service_image": service["Image"],
         "relay_sha256": hashlib.sha256(relay.read_bytes()).hexdigest(),
         "helper_sha256": hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
         "onboarding_reused": True, "additional_onboarding_calls": 0,
         "actor_generation_calls": 0, "embedding_compute_cost_usd": None, "paid_ready": False})
    original_argv = prepare_native._native_argv
    try:
        made = executor._docker(["network", "create", "--internal", "--label",
                                executor.LABEL + "=" + name, network])
        assert made.returncode == 0, made.stderr
        network_id = made.stdout.strip()
        row = json.loads(executor._docker(["network", "inspect", network]).stdout)[0]
        assert row["Internal"] and row["Labels"][executor.LABEL] == name
        save(out / "network-before.json", row)
        made = executor._docker(["create", "--pull", "never", "--init", "--read-only",
            "--user", "1000:1000", "--network", upstream, "--memory", "512m",
            "--memory-swap", "512m", "--cpus", "1", "--pids-limit", "64",
            "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
            "--name", name, "--label", executor.LABEL + "=" + name,
            "--mount", "type=bind,src=" + str(relay) + ",dst=/relay.py,readonly",
            "--entrypoint", "python3", image, "-I", "-B", "/relay.py",
            "--upstream", "http://codescout-dense-amd:8080/v1/embeddings",
            "--model", "CodeRankEmbed", "--dimensions", "768"])
        assert made.returncode == 0, made.stderr
        proxy = made.stdout.strip()
        linked = executor._docker(["network", "connect", "--alias", "source-embeddings", network, proxy])
        assert linked.returncode == 0, linked.stderr
        before = executor._inspect(proxy)
        executor._owned(before, proxy, name, image)
        assert set(before["NetworkSettings"]["Networks"]) == {upstream, network}
        save(out / "relay-before.json", before)
        started = executor._docker(["start", proxy])
        assert started.returncode == 0, started.stderr
        smoke_code = """import json,urllib.request
r=urllib.request.Request('http://127.0.0.1:8000/v1/embeddings',data=json.dumps({'input':['public source transport smoke']}).encode(),headers={'Content-Type':'application/json'})
with urllib.request.urlopen(r,timeout=120) as s:v=json.load(s)
assert len(v['data'])==1 and len(v['data'][0]['embedding'])==768
print(json.dumps({'count':len(v['data']),'dimensions':len(v['data'][0]['embedding'])}))
"""
        smoke = None
        for attempt in range(20):
            smoke = executor._docker(["exec", proxy, "python3", "-I", "-c", smoke_code], timeout=130)
            if smoke.returncode == 0:
                break
            time.sleep(0.2)
        (out / "smoke.stdout").write_text(smoke.stdout)
        (out / "smoke.stderr").write_text(smoke.stderr)
        assert smoke.returncode == 0, smoke.stderr
        cfg = {"native_image": image, "runtime_manifest": str(parent / "native-runtime.json")}
        prepare_native.ROOT, prepare_native.IMAGE = out, image
        def private_argv(actor, home, config):
            argv = original_argv(actor, home, config)
            argv[argv.index("--network") + 1] = network
            return argv
        prepare_native._native_argv = private_argv
        native = prepare_native.Native("native", project, cfg)
        native.start()
        actual = executor._inspect(native.cid)
        assert set(actual["NetworkSettings"]["Networks"]) == {network}
        save(out / "native-before.json", actual)
        save(out / "index-started.json", {"source_digest": prep["prepared_public_digest"], "index_calls": 1})
        began = time.monotonic()
        indexed = subprocess.run(["docker", "exec", native.cid, "/bench/bin/codescout",
                                  "index", "-p", "/testbed"], capture_output=True, text=True, timeout=1800)
        (out / "index.stdout").write_text(indexed.stdout)
        (out / "index.stderr").write_text(indexed.stderr)
        save(out / "index-result.json", {"exit_code": indexed.returncode, "wall_s": time.monotonic() - began})
        assert indexed.returncode == 0, indexed.stderr
        migrated = subprocess.run(["docker", "exec", native.cid, "/bench/bin/codescout",
                                   "migrate-memories", "--in-place"], capture_output=True, text=True, timeout=300)
        (out / "memory.stdout").write_text(migrated.stdout)
        (out / "memory.stderr").write_text(migrated.stderr)
        save(out / "memory-result.json", {"exit_code": migrated.returncode})
        assert migrated.returncode == 0, migrated.stderr
        save(out / "status.json", native.tool("workspace", {"action": "status"}))
        save(out / "index-verification.json", native.tool("index", {"action": "verify"}, timeout=240))
        assert _public_digest(project) == prep["prepared_public_digest"]
        save(out / "result.json", {"source_digest_unchanged": True, "index_exit": 0,
             "index_calls": 1, "additional_onboarding_calls": 0, "actor_generation_calls": 0,
             "embedding_compute_cost_usd": None, "paid_ready": False,
             "scope": "index and raw native verification captured; canaries, coverage interpretation and all-arm context not admitted"})
        print(json.dumps({"stem": stem, "index_exit": 0, "index_calls": 1, "paid_ready": False}), flush=True)
    except Exception as exc:
        if isinstance(exc, subprocess.TimeoutExpired):
            for label, partial in [("stdout", exc.stdout), ("stderr", exc.stderr)]:
                data = partial.encode() if isinstance(partial, str) else (partial or b"")
                (out / ("timeout." + label)).write_bytes(data)
        save(out / "failure.json", {"exception": type(exc).__name__, "message": str(exc),
             "paid_ready": False, "additional_onboarding_calls": 0})
        raise
    finally:
        prepare_native._native_argv = original_argv
        errors = []
        if native is not None:
            try:
                native.close()
            except Exception as exc:
                errors.append("native:" + type(exc).__name__ + ":" + str(exc))
        if proxy is not None:
            try:
                logs = executor._docker(["logs", proxy])
                (out / "relay.stdout").write_text(logs.stdout)
                (out / "relay.stderr").write_text(logs.stderr)
                save(out / "relay-after.json", executor._inspect(proxy))
                assert executor._cleanup(proxy, name, image)
            except Exception as exc:
                errors.append("relay:" + type(exc).__name__ + ":" + str(exc))
        if network_id is not None:
            try:
                row = json.loads(executor._docker(["network", "inspect", network_id]).stdout)[0]
                assert row["Labels"].get(executor.LABEL) == name and not row.get("Containers")
                deleted = executor._docker(["network", "rm", network_id])
                assert deleted.returncode == 0, deleted.stderr
                check = executor._docker(["network", "ls", "--quiet", "--filter", "name=^" + network + "$"])
                assert check.returncode == 0 and not check.stdout.strip()
            except Exception as exc:
                errors.append("network:" + type(exc).__name__ + ":" + str(exc))
        save(out / "cleanup.json", {"proxy": proxy, "network_id": network_id,
                                   "complete": not errors, "errors": errors})
        if errors:
            raise RuntimeError("owned embedding setup cleanup failed: " + repr(errors))

if __name__ == "__main__":
    main(sys.argv[1])
