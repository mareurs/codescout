"""Reopen original Arrow controls with protected roots; retain baseline compile-status absence."""
from pathlib import Path
import hashlib
import json
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, "/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from evaluator_entry import verify_package
from feedback_private_commands import prepare_record
from receipts import input_digest
import trusted_test_inputs as trusted

ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/apache__arrow-rs-7783/private-preparation-v5")
OUT = Path("/home/marius/work/claude/codescout/docs/trackers/effort-steering/evidence/native-feedback-preparation-20261112/arrow-private-v5-control-audit.json")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    reg = json.loads((ROOT / "registration.json").read_bytes())
    cfg = json.loads((ROOT / "config.json").read_bytes())
    terminal = json.loads((ROOT / "controls-result.json").read_bytes())
    started = json.loads((ROOT / "control-run-started.json").read_bytes())
    assert sha(ROOT / "config.json") == reg["config_sha256"]
    assert terminal["all_three_controls_met"] is True and len(terminal["controls"]) == 3
    assert [row["name"] for row in terminal["controls"]] == ["baseline", "reference", "reference-repeat"]
    for path, expected in cfg["bindings"].items():
        assert sha(path) == expected, path
    verify_package(cfg["package_root"], cfg["package_files"])
    record_path = Path(cfg["record"])
    record = json.loads(record_path.read_bytes())
    original = json.loads((record_path.parent / "original-record.json").read_bytes())
    assert record == prepare_record(original)
    count = len(record["FAIL_TO_PASS"] + record["PASS_TO_PASS"])
    assert count == reg["selected_label_count"] == 3968
    assert cfg["image"] == reg["image"]
    assert input_digest(Path(reg["public_source"])) == reg["public_source_sha256"]
    assert input_digest(Path(reg["reference"])) == reg["reference_sha256"]
    roots, entries, _ = trusted._validated(cfg["trusted_test_inputs"])
    controls, identifiers = [], []
    for declared, observed in zip(reg["controls"], terminal["controls"]):
        request_path = Path(declared["request"])
        assert sha(request_path) == declared["request_sha256"]
        request = json.loads(request_path.read_bytes())
        assert request["config_sha256"] == reg["config_sha256"]
        row = json.loads((request_path.parent / "control-result.json").read_bytes())
        assert row == observed and row["process_returncode"] == 0
        assert sha(row["verdict_path"]) == row["verdict_sha256"]
        verdict = json.loads(Path(row["verdict_path"]).read_bytes())
        assert verdict == row["verdict"]
        assert verdict["valid"] is True and verdict["pass"] is declared["expected_pass"]
        assert verdict["adjusted"]["expected"] == count
        if declared["name"] == "baseline":
            assert verdict["kind"] == "compile_failure"
            assert verdict["statuses"] == {} and verdict["raw_parsed_keys"] == 0
            assert verdict["adjusted"]["missing"] == verdict["adjusted"]["not_passing"] == count
        else:
            assert verdict["kind"] == "pass"
            assert verdict["adjusted"]["missing"] == verdict["adjusted"]["not_passing"] == 0
        evaluation = request_path.parent / "evaluation"
        runtime = json.loads((evaluation / "runtime-proof.json").read_bytes())
        assert runtime["complete"] and runtime["resource_ok"] and runtime["errors"] == []
        assert runtime["fresh_absence"] == [True] and runtime["cgroup_probes"] == 2 and runtime["oom_kill"] == 0
        observations = [json.loads(line) for line in (evaluation / "runtime-observations.jsonl").read_text().splitlines()]
        assert [row["stage"] for row in observations] == ["after-start", "before-remove"]
        cid = observations[0]["inspect"]["Id"]
        assert observations[1]["inspect"]["Id"] == cid
        identifiers.append(cid)
        assert "runner_versions" not in observations[0]
        assert all("runner_version" not in spec for spec in cfg["stream_registration"]["tests"])
        installed = json.loads((evaluation / "trusted-input-installation.json").read_bytes())["restoration"]
        for proof in (installed, observations[1]["trusted_test_inputs"]):
            assert proof["complete"] is True and proof["entries_verified"] == len(entries)
            assert proof["manifest_sha256"] == cfg["trusted_test_inputs"]["manifest_sha256"]
            assert proof["roots"] == roots
        entry = json.loads((evaluation / "private-entry-started.json").read_bytes())
        assert entry["entry_sha256"] == started["entry_sha256"] == reg["entry_sha256"]
        controls.append({"name": declared["name"], "valid": True, "pass": verdict["pass"],
            "kind": verdict["kind"], "expected": count, "missing": verdict["adjusted"]["missing"],
            "not_passing": verdict["adjusted"]["not_passing"], "parsed_statuses": verdict["raw_parsed_keys"],
            "canonical_input_entries_verified": len(entries), "runtime_complete": True,
            "owned_cleanup": True, "wall_s": row["wall_s"], "verdict_path": row["verdict_path"],
            "verdict_sha256": row["verdict_sha256"]})
    assert len(set(identifiers)) == 3
    verify_package(cfg["package_root"], cfg["package_files"])
    result = {"schema": "original-label-protected-private-controls-audit-v1",
        "task": reg["task"], "image": reg["image"], "all_three_controls_met": True, "controls": controls,
        "canonical_input_roots": roots, "canonical_input_entries": len(entries),
        "frozen_package_files_reopened": len(cfg["package_files"]), "private_bindings_reopened": len(cfg["bindings"]),
        "registration_sha256": sha(ROOT / "registration.json"), "config_sha256": sha(ROOT / "config.json"),
        "producer_sha256": sha(__file__), "provider_calls": 0, "paid_ready": False,
        "scope": "One-task original-label/input/runtime controls; compile-failing baseline has no statuses. All-cohort native/admission/gate/review pending."}
    with OUT.open("x") as stream:
        json.dump(result, stream, sort_keys=True, indent=2)
        stream.write("\n")
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
