"""Index the one prepared source corpus using the existing measured embedding runtime."""
from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys
import time
sys.path.insert(0, "/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from embedding_runtime import embedding_runtime
from native_executor import _public_digest
import executor

MAIN = Path("/home/marius/work/claude/codescout")
SCRIPTS = MAIN / ".superpowers/sdd/2026-11-11-native-public-feedback-transfer"
PARENT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/apache__arrow-rs-7783/common-preparation-v1")

def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")

def main():
    prep = json.loads((PARENT / "preparation.json").read_bytes())
    project = PARENT / "project"
    assert _public_digest(project) == prep["template_public_sha256"]
    image = json.loads((PARENT / "registration.json").read_bytes())["image"]
    out = PARENT / "index-coderank-v2"
    out.mkdir()
    relay_out = out / "embedding"
    relay_out.mkdir()
    configuration = {"service_id": "88e74239478cbedcf13732d05417292c3eed43054a2b1b3ea88f8d122abb1ff8",
        "service_image": "sha256:be175932c3c96e882dfbc7e20e0e834f58c89c2925f48b222837ee929dfc47ee",
        "upstream_network": "codescout-retrieval_retrieval_net", "subnet": "100.120.0.0/28"}
    save(out / "registration.json", {"source": str(project), "public_digest": prep["template_public_sha256"],
        "image": image, "embedding": configuration, "model": "CodeRankEmbed", "dimensions": 768,
        "producer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "onboarding_reused": True, "additional_onboarding_calls": 0, "client_model_calls": 0,
        "embedding_compute_cost_usd": None, "paid_ready": False})
    spec = importlib.util.spec_from_file_location("feedback_index_native", SCRIPTS / "prior_prepare_native.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.ROOT, module.IMAGE = out, image
    original = module._native_argv
    with embedding_runtime(relay_out, image, configuration) as descriptor:
        def private_argv(actor, home, config):
            argv = original(actor, home, config)
            argv[argv.index("--network") + 1] = descriptor["network_id"]
            return argv
        module._native_argv = private_argv
        native = None
        try:
            native = module.Native("native", project,
                {"native_image": image, "runtime_manifest": str(PARENT / "native-runtime.json")})
            native.start()
            actual = executor._inspect(native.cid)
            assert {item["NetworkID"] for item in actual["NetworkSettings"]["Networks"].values()} == {descriptor["network_id"]}
            assert len(actual["NetworkSettings"]["Networks"]) == 1
            save(out / "native-network.json", actual)
            save(out / "index-started.json", {"index_calls": 1, "additional_onboarding_calls": 0})
            start = time.monotonic()
            result = subprocess.run(["docker", "exec", native.cid, "/bench/bin/codescout",
                "index", "-p", "/testbed"], capture_output=True, timeout=1800)
            (out / "index.stdout").write_bytes(result.stdout)
            (out / "index.stderr").write_bytes(result.stderr)
            save(out / "index-result.json", {"exit_code": result.returncode, "wall_s": time.monotonic()-start})
            assert result.returncode == 0
            migrated = subprocess.run(["docker", "exec", native.cid, "/bench/bin/codescout",
                "migrate-memories", "--in-place"], capture_output=True, timeout=300)
            (out / "memory.stdout").write_bytes(migrated.stdout)
            (out / "memory.stderr").write_bytes(migrated.stderr)
            save(out / "memory-result.json", {"exit_code": migrated.returncode})
            assert migrated.returncode == 0
            save(out / "status.json", native.tool("workspace", {"action": "status"}))
            save(out / "index-verification.json", native.tool("index", {"action": "verify"}, timeout=240))
            assert _public_digest(project) == prep["template_public_sha256"]
            save(out / "result.json", {"source_digest_unchanged": True, "index_exit": 0,
                "index_calls": 1, "additional_onboarding_calls": 0, "client_model_calls": 0,
                "embedding_compute_cost_usd": None, "paid_ready": False,
                "scope": "native status/index verification captured; actual LSP/semantic canaries and CLI delivery pending"})
            print(json.dumps({"index_exit": 0, "root": str(out), "paid_ready": False}), flush=True)
        except BaseException as exc:
            save(out / "failure.json", {"exception": type(exc).__name__, "message": str(exc), "paid_ready": False})
            raise
        finally:
            module._native_argv = original
            if native is not None:
                native.close()

if __name__ == "__main__":
    main()
