"""Common source-document bridge, one programmatic native onboarding, no model author."""
from pathlib import Path
import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys
sys.path[:0] = ["/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol"]
from receipts import input_digest
from native_executor import _public_digest

MAIN = Path("/home/marius/work/claude/codescout")
SCRIPTS = MAIN / ".superpowers/sdd/2026-11-11-native-public-feedback-transfer"
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/apache__arrow-rs-7783")
OLD = Path("/home/marius/.cache/codescout-resident/codescout/common-preparation-20261109")

def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")

def seed(project):
    files = sorted(p.relative_to(project).as_posix() for p in project.rglob("*")
        if (p.is_file() or p.is_symlink()) and p.relative_to(project).parts[0] not in {".git", ".codescout"})
    subprocess.run(["git", "config", "--local", "core.autocrlf", "false"], cwd=project, check=True)
    subprocess.run(["git", "add", "--force", "--", *files], cwd=project, check=True)
    # Index parity includes symlink targets; git hash-object normally follows them, so inspect each blob directly.
    result = subprocess.check_output(["git", "ls-files", "--stage", "-z"], cwd=project)
    observed = {}
    for entry in result.split(b"\0"):
        if not entry:
            continue
        header, name = entry.split(b"\t", 1)
        mode, digest, stage = header.split()
        assert stage == b"0"
        p = project / name.decode()
        physical = str(p.readlink()).encode() if p.is_symlink() else p.read_bytes()
        assert subprocess.check_output(["git", "cat-file", "blob", digest.decode()], cwd=project) == physical
        observed[name.decode()] = mode.decode()
    assert set(observed) == set(files)
    subprocess.run(["git", "-c", "user.name=Source-only preparation", "-c",
        "user.email=offline@invalid", "commit", "--allow-empty", "-qm", "Common source-only context"],
        cwd=project, check=True)

def main():
    prior = ROOT / "lock-preparation-v1/source"
    original = input_digest(prior)
    ready = json.loads((ROOT / "baseline-public-v4/result.json").read_bytes())
    assert ready["source_unchanged"] and all(r["complete"] and r["resource_valid"] and r["exit_code"] == 0 for r in ready["rows"])
    out = ROOT / "common-preparation-v1"
    out.mkdir()
    baseline = out / "public-source"
    shutil.copytree(prior, baseline, symlinks=True)
    documents = [name for name in ("AGENTS.md", "README.md", "CONTRIBUTING.md")
        if (baseline / name).is_file()]
    assert documents
    bridge = not (baseline / "CLAUDE.md").exists()
    if bridge:
        text = "# Project instructions\n\nRead the existing public project documents before working:\n\n"
        text += "".join("- " + name + "\n" for name in documents)
        (baseline / "CLAUDE.md").write_text(text)
    project = out / "project"
    shutil.copytree(baseline, project, symlinks=True)
    subprocess.run(["git", "init", "-q"], cwd=project, check=True)
    seed(project)
    image = json.loads((ROOT / "readable-image.json").read_bytes())[0]["Id"]
    runtime = json.loads((OLD / "native-runtime.json").read_bytes())
    runtime["Image"] = image
    save(out / "native-runtime.json", runtime)
    save(out / "registration.json", {"source_digest": original, "source": str(prior),
        "public_source_digest": input_digest(baseline), "image": image,
        "producer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "native_helper_sha256": hashlib.sha256((SCRIPTS / "prior_prepare_native.py").read_bytes()).hexdigest(),
        "scope": "public documents/config only; no issue, private tests, gold or model author",
        "project_bridge_added": bridge, "documents": documents, "paid_ready": False})
    spec = importlib.util.spec_from_file_location("feedback_source_onboarding", SCRIPTS / "prior_prepare_native.py")
    native_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(native_module)
    native_module.ROOT, native_module.IMAGE = out, image
    native = native_module.Native("onboarding", project,
        {"native_image": image, "runtime_manifest": str(out / "native-runtime.json")})
    try:
        native.start()
        native.tool("onboarding", {}, timeout=240)
    finally:
        native.close()
    assert input_digest(prior) == original
    assert _public_digest(project) == input_digest(baseline)
    save(out / "onboarding-result.json", {"programmatic_onboarding_calls": 1,
        "client_model_calls": 0, "author_model_calls": 0, "paid_ready": False,
        "source_unchanged": True, "scope": "programmatic native onboarding only; guidance finalization/index/canaries/CLI delivery pending"})
    print(json.dumps({"root": str(out), "onboarding_calls": 1, "paid_ready": False}), flush=True)

if __name__ == "__main__":
    main()
