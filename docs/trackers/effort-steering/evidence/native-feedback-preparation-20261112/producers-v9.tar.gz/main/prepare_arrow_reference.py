"""Independently prepare the dataset gold reference, outside every actor template."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
sys.path.insert(0, "/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from receipts import input_digest

MAIN = Path("/home/marius/work/claude/codescout")
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/apache__arrow-rs-7783")
DATA = Path("/home/marius/work/claude/setup-ab-data/live/multilang-rust.jsonl")
DATA_SHA = "bf2dd8252a07d0f275663ef8f6ab87571dd9bc4ce386abf9ec98d3cd6bb51a81"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")

def main():
    assert sha(DATA) == DATA_SHA
    records = [json.loads(line) for line in DATA.read_text().splitlines() if line.strip()]
    selected = [record for record in records if record["instance_id"] == "apache__arrow-rs-7783"]
    assert len(selected) == 1
    record = selected[0]
    metadata = json.loads((MAIN / "docs/trackers/effort-steering/evidence/native-feedback-population-20261111/original-metadata.json").read_bytes())
    public = next(row for row in metadata["tasks"] if row["id"] == record["instance_id"])
    assert all(public[key] == record[key] for key in ("repo", "base_commit"))
    assert public["image"] == record["docker_image"]
    assert public["public_issue_sha256"] == hashlib.sha256(record["problem_statement"].encode()).hexdigest()
    source = ROOT / "common-preparation-v1/public-source"
    original = input_digest(source)
    out = ROOT / "private-preparation-v1"
    out.mkdir(mode=0o700)
    save(out / "full-record.json", record)
    (out / "gold.patch").write_text(record["patch"])
    (out / "official-tests.patch").write_text(record["test_patch"])
    reference = out / "reference"
    shutil.copytree(source, reference, symlinks=True)
    result = subprocess.run(["git", "apply", "--whitespace=nowarn", str(out / "gold.patch")],
        cwd=reference, capture_output=True, timeout=30)
    save(out / "reference-apply.json", {"returncode": result.returncode,
        "stdout": result.stdout.decode(errors="replace"), "stderr": result.stderr.decode(errors="replace")})
    assert result.returncode == 0
    assert input_digest(source) == original and sha(DATA) == DATA_SHA
    save(out / "registration.json", {"schema": "native-feedback-private-preparation-v1",
        "task_id": record["instance_id"], "dataset": str(DATA), "dataset_sha256": DATA_SHA,
        "original_record_sha256": sha(out / "full-record.json"),
        "original_record_canonical_sha256": hashlib.sha256(json.dumps(record, sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
        "public_source": str(source), "public_source_sha256": original,
        "reference": str(reference), "reference_sha256": input_digest(reference),
        "gold_patch_sha256": sha(out / "gold.patch"), "official_tests_sha256": sha(out / "official-tests.patch"),
        "producer_sha256": sha(Path(__file__)), "public_source_unchanged": True,
        "actor_template_receives_private_input": False, "client_model_calls": 0, "paid_ready": False,
        "scope": "Gold-reference materialization only; no private acceptance verdict or readiness claim."})
    print(json.dumps({"private_reference_prepared": str(out), "public_source_unchanged": True,
        "paid_ready": False}), flush=True)

if __name__ == "__main__":
    main()
