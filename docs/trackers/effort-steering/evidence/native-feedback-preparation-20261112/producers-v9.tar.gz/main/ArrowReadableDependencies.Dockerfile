FROM effort-feedback-deps:arrow-rs-7783-20261112
LABEL codescout.effort-feedback-owner="codex:01a15ca9-f939-7603-acb5-01c6b02f68e2"
RUN chmod -R a+rX /usr/local/cargo/registry
