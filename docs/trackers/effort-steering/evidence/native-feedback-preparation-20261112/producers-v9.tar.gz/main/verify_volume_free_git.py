"""Reopen the projection and compare the complete canonical Git archive to its original export."""
from pathlib import Path, PurePosixPath
import argparse, hashlib, json, subprocess, sys, tarfile, uuid
sys.dont_write_bytecode = True
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
OWNER = "codex:01a15ca9-f939-7603-acb5-01c6b02f68e2"
def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024*1024), b""): digest.update(block)
    return digest.hexdigest()
def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--task-id", required=True)
    args = parser.parse_args()
    task = ROOT / args.task_id
    root = task / "volume-free-image-v1"
    projection = json.loads((root / "projection.json").read_bytes())
    assert json.loads((root / "cleanup.json").read_bytes())["complete"] is True
    assert sha(root / "rootfs.tar") == projection["rootfs_tar_sha256"]
    image = json.loads(subprocess.check_output(["docker", "image", "inspect", projection["image"]]))[0]
    assert image["Id"] == projection["image"] and not image["Config"].get("Volumes")
    metadata = json.loads((task / "registration.json").read_bytes())
    commit = metadata["task"]["base_commit"]
    old_manifest = json.loads((task / "public-source-manifest.json").read_bytes())
    original_hash = sha(task / "public-baseline.tar")
    assert original_hash == old_manifest["archive_sha256"]
    # Independent normalisation also catches an optional leading ./ in an archive name.
    removed = [PurePosixPath(name.lstrip("/")) for name in projection["removed_volume_destinations"]]
    backing = []
    with tarfile.open(root / "rootfs.tar", "r:") as tar:
        for member in tar:
            path = PurePosixPath(member.name)
            assert not path.is_absolute() and ".." not in path.parts
            if any(path == parent or path.is_relative_to(parent) for parent in removed):
                backing.append({"path": str(path), "directory": member.isdir()})
                assert member.isdir() and path in removed, "nonempty or irregular temporary volume backing"
    out = root / "git-readback-v1"
    out.mkdir()
    name = "ep-projected-git-" + uuid.uuid4().hex
    command = ["docker", "create", "--pull=never", "--name", name,
        "--label", "effort-feedback-owner=" + OWNER, "--network", "none", "--read-only",
        "--cap-drop", "ALL", "--security-opt", "no-new-privileges", "--memory", "2g",
        "--memory-swap", "2g", "--cpus", "2", "--pids-limit", "128", "--entrypoint", "git",
        image["Id"], "-c", "safe.directory=/testbed", "-C", "/testbed",
        "archive", "--format=tar", commit]
    save(out / "registration.json", {"image": image["Id"], "commit": commit, "original_archive_sha256": original_hash,
        "argv": command, "projection_sha256": sha(root / "projection.json"), "producer_sha256": sha(__file__),
        "client_model_calls": 0, "paid_ready": False})
    cid = subprocess.check_output(command, text=True).strip()
    def owned():
        row = json.loads(subprocess.check_output(["docker", "inspect", cid]))[0]
        assert row["Id"] == cid and row["Image"] == image["Id"]
        assert row["Config"]["Labels"]["effort-feedback-owner"] == OWNER
        assert row["HostConfig"]["ReadonlyRootfs"] is True and not row["HostConfig"].get("Binds")
        assert not row["Mounts"] and not row["HostConfig"].get("Tmpfs")
        return row
    result = None
    try:
        save(out / "container-before.json", owned())
        with (out / "canonical.tar").open("xb") as stdout, (out / "stderr").open("xb") as stderr:
            process = subprocess.run(["docker", "start", "-a", cid], stdout=stdout, stderr=stderr, timeout=180)
        after = owned()
        save(out / "container-after.json", after)
        assert process.returncode == after["State"]["ExitCode"] == 0 and not after["State"]["OOMKilled"]
        observed = sha(out / "canonical.tar")
        assert observed == original_hash, "canonical Git archive changed"
        result = {"canonical_archive_byte_equal": True, "archive_sha256": observed,
            "temporary_backing_entries": backing, "no_anonymous_volumes": True,
            "image": image["Id"], "client_model_calls": 0, "paid_ready": False,
            "scope": "Config/rootfs export/canonical Git projection only; strict public checks and native/private qualification remain open."}
    finally:
        before_remove = owned()
        if before_remove["State"]["Running"]:
            subprocess.run(["docker", "stop", "-t", "3", cid], check=True, capture_output=True)
        subprocess.run(["docker", "rm", "--volumes", cid], check=True, capture_output=True)
        absence = subprocess.run(["docker", "ps", "-a", "--quiet", "--filter", "id=" + cid], capture_output=True, text=True)
        cleanup = absence.returncode == 0 and not absence.stdout.strip()
        save(out / "cleanup.json", {"complete": cleanup, "container": cid})
        assert cleanup
    assert result is not None
    result["cleanup_complete"] = True
    save(out / "result.json", result)
    print(json.dumps(result), flush=True)
if __name__ == "__main__":
    main()
