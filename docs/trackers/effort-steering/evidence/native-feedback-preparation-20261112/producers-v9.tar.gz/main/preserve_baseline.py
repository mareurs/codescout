"""Preserve closed runtime bytes and transplant only its qualified tool inputs."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

OLD = Path('/home/marius/.codex/worktrees/cf66/codescout')
NEW = Path('/home/marius/.codex/worktrees/2aa6/codescout')
MAIN = Path('/home/marius/work/claude/codescout')
REG = Path('/var/tmp/ep11-01a15/paid-campaign-headroom-v3/registration.json')
OUT = MAIN / 'docs/trackers/effort-steering/evidence/native-feedback-baseline-20261111'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    reg = json.loads(REG.read_text())
    files = {}
    for path, expected in reg['bindings'].items():
        path = Path(path)
        if path.is_relative_to(OLD):
            rel = path.relative_to(OLD)
            assert rel.parts[0] in ('tools', '.superpowers'), rel
            assert path.is_file() and not path.is_symlink(), path
            data = path.read_bytes()
            assert digest(data) == expected, path
            files[str(rel)] = {'sha256': expected, 'size': len(data), 'mode': path.stat().st_mode & 0o777}
    assert sum(Path(p).parts[0] == 'tools' for p in files) == 93, len(files)
    assert len(files) == 102, len(files)
    base = subprocess.check_output(['git', '-C', str(OLD), 'rev-parse', 'HEAD'], text=True).strip()
    assert subprocess.check_output(['git', '-C', str(NEW), 'rev-parse', 'HEAD'], text=True).strip() == base
    changed = subprocess.check_output(['git', '-C', str(OLD), 'diff', '--name-only', '--', 'tools'], text=True).splitlines()
    untracked = subprocess.check_output(['git', '-C', str(OLD), 'ls-files', '--others', '--exclude-standard', '--', 'tools'], text=True).splitlines()
    assert set(changed + untracked) <= set(files), sorted(set(changed + untracked) - set(files))
    patch = subprocess.check_output(['git', '-C', str(OLD), 'diff', '--binary', '--', *changed])
    OUT.mkdir(parents=True, exist_ok=True)
    archive = OUT / 'source.tar.gz'
    assert not archive.exists(), 'preservation is exclusive; inspect existing artifact'
    manifest = {'schema': 'closed-runtime-preservation-v1', 'base': base, 'registration': str(REG),
                'registration_sha256': digest(REG.read_bytes()), 'files': files,
                'tracked_modified': changed, 'untracked_owned': untracked, 'patch_sha256': digest(patch)}
    with tarfile.open(archive, 'x:gz') as tar:
        for rel, row in sorted(files.items()):
            data = (OLD / rel).read_bytes()
            entry = tarfile.TarInfo(rel)
            entry.size, entry.mode = len(data), row['mode']
            tar.addfile(entry, io.BytesIO(data))
    with tarfile.open(archive, 'r:gz') as tar:
        assert len(tar.getmembers()) == len(files)
        for entry in tar:
            assert digest(tar.extractfile(entry).read()) == files[entry.name]['sha256']
    (OUT / 'owned.patch').write_bytes(patch)
    manifest['archive_sha256'] = digest(archive.read_bytes())
    manifest['archive_bytes'] = archive.stat().st_size
    for rel, row in sorted(files.items()):
        src, dest = OLD / rel, NEW / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        assert not dest.is_symlink(), dest
        if dest.exists():
            expected = subprocess.check_output(['git', '-C', str(NEW), 'show', 'HEAD:' + rel])
            assert dest.read_bytes() == expected, 'destination has edits: ' + rel
        shutil.copyfile(src, dest)
        dest.chmod(row['mode'])
        assert digest(dest.read_bytes()) == row['sha256']
        assert digest(src.read_bytes()) == row['sha256']
    manifest['transplanted_to'] = str(NEW)
    (OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'source_files': len(files), 'tool_files': sum(Path(p).parts[0] == 'tools' for p in files), 'modified_tracked': len(changed), 'owned_new': len(untracked),
                      'archive_bytes': manifest['archive_bytes'], 'archive_sha256': manifest['archive_sha256'],
                      'destination': str(NEW)}))


if __name__ == '__main__':
    main()
