"""Run the existing isolated controller against a newly bound protected-input replay."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True
import run_arrow_private_controls_v4 as controller


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--directory", type=Path, required=True)
    args = parser.parse_args()
    root = args.directory.resolve(strict=True)
    registration = json.loads((root / "registration.json").read_bytes())
    assert registration["schema"] == "native-feedback-private-controls-preregistration-v2"
    entry = controller.WORK / "tools/effort_protocol/evaluator_entry.py"
    assert controller.sha(entry) == registration["entry_sha256"]
    controller.save(root / "launcher-binding.json", {
        "wrapper_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "controller": controller.__file__, "controller_sha256": controller.sha(controller.__file__),
        "registration_sha256": controller.sha(root / "registration.json"),
        "client_model_calls": 0, "paid_ready": False})
    controller.ROOT = root
    return controller.main()


if __name__ == "__main__":
    raise SystemExit(main())
