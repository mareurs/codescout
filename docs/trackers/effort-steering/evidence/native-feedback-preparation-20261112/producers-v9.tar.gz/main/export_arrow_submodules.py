"""Export only source-declared public submodule commits, without network/private records."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import shutil
import subprocess
import tarfile
import uuid

MAIN = Path("/home/marius/work/claude/codescout")
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/apache__arrow-rs-7783")
IMAGE = "sha256:7f47d367554a441e75ddea046e2f73ff9ace6a8feaf558524fe4ab1c2273b05a"
OWNER = "codex:01a15ca9-f939-7603-acb5-01c6b02f68e2"
TREE = MAIN / ".superpowers/sdd/2026-11-11-native-public-feedback-transfer/arrow-base-tree.txt"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")

def main():
    links = []
    for line in TREE.read_text().splitlines():
        header, path = line.split("\t", 1)
        mode, kind, commit = header.split()
        if mode == "160000":
            assert not PurePosixPath(path).is_absolute() and ".." not in PurePosixPath(path).parts
            links.append({"path": path, "commit": commit})
    assert links
    out = ROOT / "public-submodules-v1"
    out.mkdir()
    save(out / "registration.json", {"links": links, "parent_inventory": str(TREE),
        "parent_inventory_sha256": sha(TREE), "image": IMAGE, "producer_sha256": sha(Path(__file__)),
        "client_model_calls": 0, "network": "none", "private_input": False, "paid_ready": False})
    results = []
    for link in links:
        directory = out / link["path"]
        directory.mkdir(parents=True)
        name = "ep-public-submodule-" + uuid.uuid4().hex
        command = ["docker", "create", "--pull=never", "--name", name,
            "--label", "codescout.submodule-owner=" + OWNER, "--network", "none", "--read-only",
            "--memory", "2g", "--memory-swap", "2g", "--cpus", "2", "--pids-limit", "128",
            "--cap-drop=ALL", "--security-opt", "no-new-privileges", "--entrypoint", "git",
            IMAGE, "-c", "safe.directory=*", "-C", "/testbed/" + link["path"],
            "archive", "--format=tar", link["commit"]]
        save(directory / "command.json", command)
        cid = subprocess.check_output(command, text=True).strip()
        save(directory / "created.json", {"id": cid, "name": name})
        row = dict(link)
        try:
            before = json.loads(subprocess.check_output(["docker", "inspect", cid]))[0]
            assert before["Id"] == cid and before["Image"] == IMAGE
            assert before["Config"]["Labels"]["codescout.submodule-owner"] == OWNER
            save(directory / "container-before.json", before)
            with (directory / "source.tar").open("xb") as stdout, (directory / "stderr").open("xb") as stderr:
                result = subprocess.run(["docker", "start", "-a", cid], stdout=stdout, stderr=stderr, timeout=180)
            after = json.loads(subprocess.check_output(["docker", "inspect", cid]))[0]
            save(directory / "container-after.json", after)
            assert result.returncode == 0 and after["State"]["ExitCode"] == 0 and not after["State"]["OOMKilled"]
            source = directory / "source"
            source.mkdir()
            with tarfile.open(directory / "source.tar") as archive:
                assert archive.pax_headers.get("comment") == link["commit"]
                members = archive.getmembers()
                assert all(not PurePosixPath(m.name).is_absolute() and ".." not in PurePosixPath(m.name).parts for m in members)
                assert all(m.isdir() or m.isfile() or m.issym() or m.islnk() for m in members)
                archive.extractall(source, filter="data")
            inventory = {p.relative_to(source).as_posix():
                {"link": str(p.readlink())} if p.is_symlink() else {"sha256": sha(p), "bytes": p.stat().st_size}
                for p in source.rglob("*") if p.is_symlink() or p.is_file()}
            save(directory / "inventory.json", inventory)
            row.update(exit_code=0, archive_sha256=sha(directory / "source.tar"),
                inventory_sha256=sha(directory / "inventory.json"), paths=len(inventory))
        finally:
            actual = json.loads(subprocess.check_output(["docker", "inspect", cid]))[0]
            assert actual["Id"] == cid and actual["Config"]["Labels"]["codescout.submodule-owner"] == OWNER
            if actual["State"]["Running"]:
                subprocess.run(["docker", "stop", "-t", "3", cid], check=True, capture_output=True)
            subprocess.run(["docker", "rm", "--volumes", cid], check=True, capture_output=True)
            absence = subprocess.run(["docker", "ps", "-a", "--no-trunc", "--filter", "id=" + cid,
                "--format", "{{.ID}}"], capture_output=True, text=True)
            row["cleanup_complete"] = absence.returncode == 0 and not absence.stdout.strip()
            save(directory / "result.json", row)
        assert row["cleanup_complete"]
        results.append(row)
    save(out / "result.json", {"rows": results, "client_model_calls": 0,
        "paid_ready": False, "scope": "Canonical public data exported; not yet applied to common source/template"})
    print(json.dumps({"submodule_exports": results, "paid_ready": False}), flush=True)

if __name__ == "__main__":
    main()
