"""Cheap canonical tree/index control, without rebuild, private input or model."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

MAIN = Path("/home/marius/work/claude/codescout")
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/apache__arrow-rs-7783")
TREE = MAIN / ".superpowers/sdd/2026-11-11-native-public-feedback-transfer/arrow-base-tree.txt"

def git(project, *args):
    return subprocess.check_output(["git", *args], cwd=project).decode().strip()

def main():
    out = ROOT / "gitlink-parity-probe-v1"
    out.mkdir()
    source = out / "source"
    shutil.copytree(ROOT / "source", source, symlinks=True)
    git(source, "init", "-q")
    git(source, "config", "core.autocrlf", "false")
    (source / ".git/info/attributes").write_text("* -text -ident -filter\n")
    names = sorted(p.relative_to(source).as_posix() for p in source.rglob("*")
        if (p.is_file() or p.is_symlink()) and p.relative_to(source).parts[0] != ".git")
    git(source, "add", "--force", "--", *names)
    before = git(source, "write-tree")
    canonical = {}
    for line in TREE.read_text().splitlines():
        header, name = line.split("\t", 1)
        mode, kind, digest = header.split()
        canonical[name] = (mode, digest)
    observed = {}
    for line in git(source, "ls-files", "--stage").splitlines():
        header, name = line.split("\t", 1)
        mode, digest, stage = header.split()
        assert stage == "0"
        observed[name] = (mode, digest)
    diff = {name: {"expected": canonical.get(name), "observed": observed.get(name)}
        for name in canonical.keys() | observed.keys() if canonical.get(name) != observed.get(name)}
    links = {name: row for name, row in canonical.items() if row[0] == "160000"}
    for name, (mode, digest) in links.items():
        git(source, "update-index", "--add", "--cacheinfo", mode + "," + digest + "," + name)
    after = git(source, "write-tree")
    result = {"before_tree": before, "after_preserving_gitlinks": after, "diff": diff,
        "canonical_leaf_entries": len(canonical), "gitlinks": links,
        "source_inventory_sha256": hashlib.sha256(TREE.read_bytes()).hexdigest(),
        "reproduces_failed_builder_tree": before == "42c6ebeef830cb040bc253fcb25e8728111fc39a",
        "restores_expected_canonical_tree": after == "66c1b3a5d34ac198a2046c5e07ce09ef1925d385",
        "scope": "Actual local Git tree control; not a fixed image build, submodule-data or private-grader qualification.",
        "client_model_calls": 0, "paid_ready": False}
    with (out / "result.json").open("x") as stream:
        json.dump(result, stream, sort_keys=True, indent=2)
    print(json.dumps(result, sort_keys=True), flush=True)

if __name__ == "__main__":
    main()
