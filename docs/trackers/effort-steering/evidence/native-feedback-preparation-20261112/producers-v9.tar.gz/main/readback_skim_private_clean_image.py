"""Full declared-source readback as the actual non-root actor user."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import uuid

sys.dont_write_bytecode=True
sys.path.insert(0,"/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from evaluator_entry import _entries,_input_digest
ROOT=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/skim-rs__skim-1044")
OUT=ROOT/"private-clean-image-v1/public-readback-v1"


def save(path,value):
    with path.open("x") as stream:
        json.dump(value,stream,sort_keys=True,indent=2)
        stream.write("\n")


def docker(*args,check=True):
    return subprocess.run(["docker",*args],capture_output=True,check=check,timeout=180)


def main():
    OUT.mkdir()
    public=ROOT/"common-preparation-v1/public-source"
    expected=_entries(public)
    before=_input_digest(public)
    image=json.loads((ROOT/"private-clean-image-v1/result.json").read_bytes())["image"]
    code="""import hashlib,json,os,stat,sys
from pathlib import Path
result={}
for name in json.loads(sys.argv[1]):
    path=Path('/testbed')/name
    mode=path.lstat().st_mode
    if stat.S_ISLNK(mode): value={'kind':'link','target':os.readlink(path)}
    elif stat.S_ISDIR(mode): value={'kind':'directory','mode':stat.S_IMODE(mode)}
    elif stat.S_ISREG(mode): value={'kind':'file','mode':stat.S_IMODE(mode),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
    else: raise ValueError('unexpected source entry type')
    result[name]=value
print(json.dumps(result,sort_keys=True))
"""
    name="ep-skim-readback-"+uuid.uuid4().hex[:12]
    cid=None
    result={"complete":False,"provider_calls":0,"paid_ready":False}
    try:
        cid=docker("run","-d","--pull=never","--name",name,"--read-only","--network","none",
            "--user","1000:1000","--memory","8g","--memory-swap","8g","--cpus","4",
            "--pids-limit","4096","--init","--cap-drop","ALL","--security-opt","no-new-privileges",
            "--entrypoint","sleep",image,"infinity").stdout.decode().strip()
        identity=json.loads(docker("inspect",cid).stdout)[0]
        assert identity["Id"]==cid and identity["Image"]==image and identity["Mounts"]==[]
        assert identity["Config"]["User"]=="1000:1000"
        assert identity["HostConfig"]["NetworkMode"]=="none" and identity["HostConfig"]["ReadonlyRootfs"]
        save(OUT/"inspect.json",identity)
        actual={}
        names=sorted(expected)
        for start in range(0,len(names),128):
            selected=names[start:start+128]
            request=json.dumps(selected)
            assert len(request.encode())<64000
            row=docker("exec",cid,"python3","-I","-B","-c",code,request)
            assert not row.stderr
            found=json.loads(row.stdout)
            assert set(found)==set(selected)
            assert not set(actual)&set(found)
            actual.update(found)
        differences={name:{"expected":expected[name],"actual":actual.get(name)} for name in expected if actual.get(name)!=expected[name]}
        save(OUT/"observed-entries.json",actual)
        save(OUT/"differences.json",differences)
        assert not differences
        assert _input_digest(public)==before
        result.update({"complete":True,"image":image,"entries_checked":len(expected),
            "regular_files_checked":sum(v["kind"]=="file" for v in expected.values()),
            "links_checked":sum(v["kind"]=="link" for v in expected.values()),
            "differences":len(differences),"source_unchanged":True,
            "producer_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
    finally:
        if cid:
            docker("rm","-f",cid)
            absent=docker("container","inspect",cid,check=False)
            result["owned_cleanup"]=absent.returncode!=0 and b"No such" in absent.stderr
        save(OUT/"result.json",result)
    assert result["owned_cleanup"]
    print(json.dumps(result,sort_keys=True))


if __name__=="__main__":
    main()
