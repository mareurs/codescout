"""Python mutation in an isolated scratch clone; mutation-probe.sh refuses non-Claude identity."""
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

MAIN = Path("/home/marius/work/claude/codescout")
REV = Path("/home/marius/.codex/worktrees/2aa6/codescout")
OUT = MAIN / ".superpowers/sdd/2026-11-11-native-public-feedback-transfer/native-closed-mutation"
FOLDERS = ("effort_protocol", "agent_lifecycle", "hint_authority_pilot")
FIND = '        if self.registration.get("schema")==feedback_policy.SCHEMA:'
REPLACE = '        if False:'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(label, root):
    env = {k: v for k, v in os.environ.items() if k in ("PATH", "HOME", "USER", "LANG")}
    env.update(TMPDIR="/tmp", PYTHONDONTWRITEBYTECODE="1")
    command = [sys.executable, "-B", "-m", "unittest", "discover", "-s",
               "tools/effort_protocol", "-p", "test_feedback_*.py"]
    process = subprocess.run(command, cwd=root, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=120)
    log = OUT / (label + ".log")
    log.write_bytes(process.stdout)
    count = re.search(rb"^Ran (\d+) tests? in ", process.stdout, re.M)
    assert count and int(count[1]) > 0, "no actual unittest count"
    return {"returncode": process.returncode, "tests": int(count[1]), "log": str(log), "log_sha256": sha(log)}


def main():
    phase = sys.argv[1]
    sources = {str(p.relative_to(REV)): sha(p) for folder in FOLDERS
               for p in (REV / "tools" / folder).rglob("*")
               if p.is_file() and "__pycache__" not in p.parts and not p.is_symlink()}
    clone = OUT / "clone"
    target = clone / "tools/effort_protocol/native_campaign.py"
    if phase == "before":
        OUT.mkdir(exist_ok=False)
        for folder in FOLDERS:
            shutil.copytree(REV / "tools" / folder, clone / "tools" / folder,
                            ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
        baseline = run("baseline-before", clone)
        assert baseline["returncode"] == 0
        original = target.read_text()
        assert original.count(FIND) == 1
        mutated = original.replace(FIND, REPLACE)
        ast.parse(mutated)
        target.write_text(mutated)
        (OUT / "original-native-campaign.py").write_text(original)
        observed = run("mutant-before", clone)
        assert observed["tests"] == baseline["tests"]
        result = {"phase": phase, "baseline": baseline, "mutation": observed,
                  "observed": "survived" if observed["returncode"] == 0 else "killed"}
    elif phase == "after":
        assert target.read_text().count(REPLACE) == 1
        shutil.copyfile(REV / "tools/effort_protocol/test_feedback_runner.py",
                        clone / "tools/effort_protocol/test_feedback_runner.py")
        observed = run("mutant-after", clone)
        assert observed["returncode"] != 0
        target.write_text((OUT / "original-native-campaign.py").read_text())
        baseline = run("baseline-after", clone)
        assert baseline["returncode"] == 0 and baseline["tests"] == observed["tests"]
        result = {"phase": phase, "baseline": baseline, "mutation": observed, "observed": "killed"}
    else:
        raise ValueError("expected before or after")
    assert all(sha(REV / name) == expected for name, expected in sources.items())
    result.update(schema="isolated-python-mutation-v1", source_before_after=sources,
                  find=FIND, replacement=REPLACE, producer_sha256=sha(Path(__file__)),
                  limitation="author probe, not independent review;script's cargo verdict unavailable for Python")
    with (OUT / (phase + ".json")).open("x") as stream:
        stream.write(json.dumps(result, sort_keys=True, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "source_before_after"}))


if __name__ == "__main__":
    main()
