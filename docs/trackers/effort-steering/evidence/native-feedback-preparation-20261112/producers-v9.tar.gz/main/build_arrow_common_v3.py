"""Build from an owned tag while checking its immutable ID and inherited layers."""
from pathlib import Path
import hashlib, json, subprocess
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/apache__arrow-rs-7783/common-preparation-v3")
PARENT_TAG = "effort-feedback-base:arrow-rs-7783-gitlinks-20261112"
EXPECTED = "sha256:5105ac56e8ce1dcf32d41393481e7d90b1d345fad6d3f6c070b807bc633f05fe"
TAG = "effort-feedback-base:arrow-rs-7783-common-v3-20261112"
def inspect(tag):
    return json.loads(subprocess.check_output(["docker", "image", "inspect", tag]))[0]
def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")
def main():
    out = ROOT / "image-build-v2"
    out.mkdir()
    before = inspect(PARENT_TAG)
    assert before["Id"] == EXPECTED
    save(out / "parent-before.json", before)
    context = ROOT / "image-context"
    recipe = context / "Dockerfile.v2"
    assert not recipe.exists()
    recipe.write_text("FROM " + PARENT_TAG + "\nUSER root\nCOPY --chown=1000:1000 public-source/ /testbed/\n")
    result = subprocess.run(["docker", "build", "--pull=false", "--network", "none", "-f", str(recipe),
        "-t", TAG, str(context)], capture_output=True, timeout=1200)
    (out / "stdout.log").write_bytes(result.stdout)
    (out / "stderr.log").write_bytes(result.stderr)
    save(out / "command.json", {"returncode": result.returncode, "recipe_sha256": hashlib.sha256(recipe.read_bytes()).hexdigest()})
    assert result.returncode == 0
    after = inspect(PARENT_TAG)
    save(out / "parent-after.json", after)
    assert after["Id"] == EXPECTED
    image = inspect(TAG)
    save(out / "image.json", image)
    layers = before["RootFS"]["Layers"]
    assert image["RootFS"]["Layers"][:len(layers)] == layers
    runtime = json.loads((ROOT / "native-runtime-index.json").read_bytes())
    runtime["Image"] = image["Id"]
    save(ROOT / "native-runtime.json", runtime)
    save(out / "result.json", {"image": image["Id"], "tag": TAG, "parent_image": EXPECTED,
        "parent_layers_unchanged": True, "paid_ready": False})
    print(json.dumps({"image": image["Id"], "paid_ready": False}))
if __name__ == "__main__":
    main()
