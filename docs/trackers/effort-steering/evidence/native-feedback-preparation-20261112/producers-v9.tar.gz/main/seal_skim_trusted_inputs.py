"""Seal public-declared Skim test roots before actors; no grading/model call."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
REV = Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path.insert(0, str(REV / "tools/effort_protocol"))
import evaluator_entry as entry
import trusted_test_inputs as core

ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/skim-rs__skim-1044")
OUT = ROOT / "trusted-test-inputs-v1"


def changed_paths(patch):
    result = subprocess.run(["git", "apply", "--numstat", "-z", "-"], input=patch.encode(),
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
    names = []
    for row in result.stdout.split(b"\0"):
        if not row:
            continue
        fields = row.decode().split("\t", 2)
        if len(fields) != 3 or not fields[2]:
            raise ValueError("unsupported patch path framing")
        names.append(core._relative(fields[2]).as_posix())
    return names


def main():
    OUT.mkdir()
    source = ROOT / "source"
    original = ROOT / "private-structure-v1/original-record.json"
    record = json.loads(original.read_bytes())
    roots = ["tests"]
    # Selection rests on the original public source guidelines and Cargo's
    # standalone integration-test convention, before any actor/outcome.
    guidance = (source / "AGENTS.md").read_bytes()
    assert b"snapshot tests in `tests/`" in guidance
    before = entry._input_digest(source)
    official_paths = changed_paths(record["test_patch"])
    production_paths = changed_paths(record["patch"])
    assert all(any(PurePosixPath(name).is_relative_to(root) for root in roots) for name in official_paths)
    assert not any(PurePosixPath(name).is_relative_to(root) for name in production_paths for root in roots)
    canonical = OUT / "canonical"
    shutil.copytree(source, canonical, symlinks=True)
    applied = subprocess.run(["git", "apply", "--binary", "-"], cwd=canonical,
                             input=record["test_patch"], text=True,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (OUT / "official-patch-apply.log").write_text(applied.stdout)
    assert applied.returncode == 0
    descriptor = core.seal_test_inputs(canonical, roots, OUT / "sealed")
    roots, inventory, _ = core._validated(descriptor)
    assert entry._input_digest(source) == before
    result = {"schema": "prospective-test-input-contract-v1", "task": record["instance_id"],
        "roots": roots, "descriptor": descriptor, "entries": len(inventory),
        "regular_files": sum(item["kind"] == "file" for item in inventory.values()),
        "original_public_source_digest": before,
        "source_guidance_sha256": hashlib.sha256(guidance).hexdigest(),
        "original_record_sha256": hashlib.sha256(original.read_bytes()).hexdigest(),
        "official_paths": official_paths, "gold_production_overlap": [],
        "selection_basis": "Original public AGENTS.md explicitly locates integration/snapshot tests in tests/.",
        "coverage": "Standalone tests root only. Inline assertions and code outside it require a blinded candidate diff audit.",
        "runtime_output_caveat": "Original INSTA_UPDATE=new may emit .snap.new files; exact post-grade inventory compatibility is not yet qualified.",
        "provider_calls": 0, "private_grade_runs": 0, "paid_ready": False,
        "producer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (OUT / "contract.json").write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
