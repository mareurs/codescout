"""Reopen actual formatter evidence and exercise the explicit prospective adapter."""
from pathlib import Path
import hashlib
import json
import sys

sys.dont_write_bytecode = True
sys.path.insert(0,"/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from evaluator_entry import verify_package
import feedback_nextest as adapter

ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/skim-rs__skim-1044")
FIXTURE = ROOT/"nextest-junit-host-diagnostics-v2"
OUT = ROOT/"nextest-junit-host-format-proof-v1"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path,value):
    with path.open("x") as stream:
        json.dump(value,stream,sort_keys=True,indent=2)
        stream.write("\n")


def main():
    OUT.mkdir()
    package_config = json.loads(Path("/var/tmp/ep11-01a15/private-controls/obscura/config.json").read_bytes())
    package = verify_package(package_config["package_root"],package_config["package_files"])
    sys.path.insert(0,str(package))
    import command_capture as capture
    import multilang_tasks as tasks
    import stream_evidence as streams
    import grade_policy as policy
    original_path = ROOT/"private-structure-v1/original-record.json"
    original = json.loads(original_path.read_bytes())
    registered = json.loads((FIXTURE/"registration.json").read_bytes())
    measured = json.loads((FIXTURE/"result.json").read_bytes())
    assert measured["complete"] and measured["owned_cleanup"] and measured["frozen_package_unchanged"]
    producer = Path("/home/marius/work/claude/codescout/.superpowers/sdd/2026-11-11-native-public-feedback-transfer/probe_nextest_junit_host_diagnostics_v2.py")
    assert sha(producer) == registered["producer_sha256"]
    record = {"instance_id":"independent-formatter-fixture",
        "FAIL_TO_PASS":["stream_contract_fixture::tests::noisy_failure"],
        "PASS_TO_PASS":["stream_contract_fixture::tests::noisy_pass"],
        "rebuild_cmds":[],"test_cmds":[registered["test_command"]],
        "print_cmds":[registered["print_command"]],"log_parser":original["log_parser"]}
    bundle = {"workdir":"/fixture","expected":{"fail_to_pass":1,"pass_to_pass_kept":1,"dropped":[],"fail_to_pass_dropped":[]}}
    cases = {}
    bound = [FIXTURE/name for name in ("registration.json","result.json","container-before.json","container-after.json")]
    bound += [producer,original_path,Path(__file__)]
    for label, expected in adapter.EXPECTED_CASES.items():
        case = FIXTURE/label
        full = json.loads((case/"full-evidence.json").read_bytes())
        log = (case/"grade.log").read_text()
        runtime = json.loads((case/"runtime-observations.json").read_bytes())["runtime"]
        for step in full["steps"]:
            wire = case/(step["name"].replace(":","-")+".wire.json")
            assert capture.decode(wire.read_bytes(),step["returncode"]) == step["capture"]
        raw = {key:value for key,value in full.items() if key!="steps"}
        verdict = policy.adjudicate_streams(raw,full,record,bundle,log=log,runtime=runtime,
                                          registered=registered["structural_grammar"])
        observed = {key:verdict[key] for key in ("valid","pass","kind")}
        assert observed == expected
        assert verdict == json.loads((case/"verdict.json").read_bytes())
        cases[label] = observed
        bound += [path for path in case.iterdir() if path.is_file()]
    assert cases == adapter.EXPECTED_CASES
    bindings = {str(path):sha(path) for path in sorted(set(bound))}
    proof = {"schema":"nextest-junit-host-only-format-proof-v1","profile":adapter.PROFILE,
        "qualified":True,"runner_version":measured["nextest_version"],
        "parser_sha256":hashlib.sha256(original["log_parser"].encode()).hexdigest(),
        "cases":cases,"bindings":bindings,
        "scope":"Actual formatter fixture and original parser compatibility; not benchmark/private runtime admission."}
    save(OUT/"compatibility.json",proof)
    specification = {"profile":adapter.PROFILE,"reports":[0],"stderr_files":[],
        "runner_version":proof["runner_version"],
        "compatibility":{"path":str(OUT/"compatibility.json"),"sha256":sha(OUT/"compatibility.json")}}
    registration = {"version":streams.VERSION,"commands_sha256":streams.commands_digest(record),"tests":[specification]}
    results = []
    for label in cases:
        case = FIXTURE/label
        full = json.loads((case/"full-evidence.json").read_bytes())
        log = (case/"grade.log").read_text()
        runtime = json.loads((case/"runtime-observations.json").read_bytes())["runtime"]
        translated = adapter.qualify_registration(record,registration,full,streams)
        raw = {key:value for key,value in full.items() if key!="steps"}
        verdict = policy.adjudicate_streams(raw,full,record,bundle,log=log,runtime=runtime,registered=translated)
        assert {key:verdict[key] for key in ("valid","pass","kind")} == cases[label]
        results.append({"case":label,"verdict":verdict})
    prepared = adapter.prepare_record(original)
    assert all(prepared[key] == original[key] for key in original if key!="test_cmds")
    save(OUT/"prepared-task-record.json",prepared)
    save(OUT/"task-stream-registration.json",{"version":streams.VERSION,
        "commands_sha256":streams.commands_digest(prepared),"tests":[specification]})
    verify_package(package,package_config["package_files"])
    assert all(sha(Path(path)) == digest for path,digest in bindings.items())
    save(OUT/"qualification.json",{"complete":True,"cases":results,"original_selected_labels":len(original["FAIL_TO_PASS"])+len(original["PASS_TO_PASS"]),
        "bound_files_reopened":len(bindings),"frozen_package_files":len(package_config["package_files"]),
        "proof_sha256":sha(OUT/"compatibility.json"),"adapter_sha256":sha(Path(adapter.__file__)),
        "original_parser_unchanged":True,"original_assertions_labels_selectors_unchanged":True,
        "new_provider_calls":0,"paid_ready":False})
    print(json.dumps({"complete":True,"fixture_cases":len(results),"bindings":len(bindings),
        "selected_task_labels_unchanged":len(original["FAIL_TO_PASS"])+len(original["PASS_TO_PASS"]),
        "new_provider_calls":0,"paid_ready":False}))


if __name__=="__main__":
    main()
