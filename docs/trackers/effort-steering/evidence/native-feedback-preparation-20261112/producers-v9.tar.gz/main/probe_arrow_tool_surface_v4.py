"""Observe actual frozen native tool availability on the fully prepared root."""
from pathlib import Path
import hashlib, importlib.util, json, sys
sys.dont_write_bytecode = True
sys.path.insert(0, "/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from native_executor import _public_digest
SCRIPTS = Path("/home/marius/work/claude/codescout/.superpowers/sdd/2026-11-11-native-public-feedback-transfer")
PARENT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/apache__arrow-rs-7783/common-preparation-v3")
def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")
def main():
    out = PARENT / "native-tool-surface-v4"
    out.mkdir()
    source = PARENT / "project"
    reg = json.loads((PARENT / "registration.json").read_bytes())
    assert _public_digest(source) == reg["public_source_digest"]
    image = json.loads((PARENT / "image-root-ownership-v1/result.json").read_bytes())["image"]
    spec = importlib.util.spec_from_file_location("surface_v4_native", SCRIPTS / "prior_prepare_native.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.ROOT, module.IMAGE = out, image
    native = None
    try:
        native = module.Native("native", source, {"native_image": image,
            "runtime_manifest": str(PARENT / "native-runtime-private-v4.json")})
        native.start()
        response = native.rpc("tools/list", {})
        save(out / "tools-list.json", response)
        tools = response["result"]["tools"]
        names = [tool["name"] for tool in tools]
        required = {"references", "call_graph", "symbol_at", "symbols"}
        assert required <= set(names), names
        selected = [tool for tool in tools if tool["name"] in required]
        save(out / "navigation-schemas.json", selected)
        assert _public_digest(source) == reg["public_source_digest"]
        save(out / "result.json", {"listed_tool_count": len(names), "navigation_tools_present": sorted(required),
            "source_unchanged": True, "client_model_calls": 0, "additional_onboarding_calls": 0,
            "producer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "scope": "Actual tools/list capability exposure only; no successful LSP call inferred", "paid_ready": False})
        print(json.dumps({"navigation_schemas": selected}), flush=True)
    finally:
        if native is not None: native.close()
if __name__ == "__main__":
    main()
