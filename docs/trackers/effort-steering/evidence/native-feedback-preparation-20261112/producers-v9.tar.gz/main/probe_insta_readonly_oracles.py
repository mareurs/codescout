"""Compare Insta new/no with identical assertions and original JUnit parser."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import uuid

sys.dont_write_bytecode = True
sys.path.insert(0, "/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from evaluator_entry import verify_package
import trusted_test_inputs as core

ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
TASK = ROOT / "skim-rs__skim-1044"
OUT = TASK / "insta-readonly-oracle-control-v1"
IMAGE = "sha256:d6e877bbf3808e02c778de60b55af6a7dd821e83915d5947432ba8b388d1a1f2"


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")


def docker(*args, check=True, timeout=300):
    return subprocess.run(["docker", *args], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          check=check, timeout=timeout)


def main():
    OUT.mkdir()
    fixture, build = OUT/"fixture", OUT/"build"
    (fixture/"src").mkdir(parents=True)
    (fixture/"tests/snapshots").mkdir(parents=True)
    (fixture/".config").mkdir()
    build.mkdir()
    (fixture/"Cargo.toml").write_text('[package]\nname="oracle_fixture"\nversion="0.1.0"\nedition="2021"\n[dev-dependencies]\ninsta="=1.47.2"\n')
    (fixture/"src/lib.rs").write_text("pub fn production() {}\n")
    (fixture/"tests/snapshot.rs").write_text('#[test]\nfn mismatch() { insta::assert_snapshot!("oracle", "actual"); }\n')
    oracle = fixture/"tests/snapshots/snapshot__oracle.snap"
    oracle.write_text('---\nsource: tests/snapshot.rs\nexpression: "\\"actual\\""\n---\nexpected\n')
    (fixture/".config/nextest.toml").write_text('[profile.default.junit]\npath="junit.xml"\n')
    canonical_oracle_sha = hashlib.sha256(oracle.read_bytes()).hexdigest()
    config = json.loads(Path("/var/tmp/ep11-01a15/private-controls/obscura/config.json").read_bytes())
    package = verify_package(config["package_root"], config["package_files"])
    sys.path.insert(0,str(package))
    import command_capture as capture
    import multilang_grade as grade
    original = json.loads((TASK/"private-structure-v1/original-record.json").read_bytes())
    cid = None
    result = {"cases": [], "provider_calls": 0, "paid_ready": False}
    save(OUT/"registration.json", {"schema": "insta-readonly-oracle-control-v1",
        "insta": "1.47.2", "modes": ["new", "no"], "image": IMAGE,
        "unchanged_assertion": True, "parser_sha256": hashlib.sha256(original["log_parser"].encode()).hexdigest(),
        "canonical_oracle_sha256": canonical_oracle_sha,
        "producer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "scope": "Unrelated single failing snapshot fixture. Not benchmark acceptance."})
    try:
        cid = docker("run","-d","--pull=never","--name","ep-insta-oracle-"+uuid.uuid4().hex[:12],
            "--network","none","--read-only","--user","1000:1000","--memory","2g","--memory-swap","2g",
            "--cpus","2","--pids-limit","128","--init","--cap-drop","ALL","--security-opt","no-new-privileges",
            "--tmpfs","/tmp:rw,exec,size=1g,uid=1000,gid=1000",
            "--mount","type=bind,src="+str(fixture)+",dst=/fixture",
            "--mount","type=bind,src="+str(build)+",dst=/build","--workdir","/fixture",
            "-e","CARGO_TARGET_DIR=/build/target","-e","CARGO_NET_OFFLINE=true",
            "--entrypoint","sleep",IMAGE,"infinity").stdout.decode().strip()
        before = json.loads(docker("inspect",cid).stdout)[0]
        assert before["Id"] == cid and before["Image"] == IMAGE and not before["State"]["OOMKilled"]
        assert before["HostConfig"]["NetworkMode"] == "none" and before["HostConfig"]["ReadonlyRootfs"]
        assert all(row["Type"] in ("bind","tmpfs") for row in before["Mounts"])
        save(OUT/"container-before.json",before)
        lock = docker("exec",cid,"cargo","+stable","generate-lockfile","--offline")
        (OUT/"generate-lock.stdout").write_bytes(lock.stdout)
        (OUT/"generate-lock.stderr").write_bytes(lock.stderr)
        descriptor = core.seal_test_inputs(fixture,["tests"],OUT/"sealed")
        for mode in ("new","no"):
            case = OUT/mode
            case.mkdir()
            core.restore_test_inputs(descriptor,fixture)
            command = ("rm -rf target/nextest && mkdir -p target/nextest/default && "
                       "printf '<testsuites/>' > target/nextest/default/junit.xml && "
                       "INSTA_UPDATE="+mode+" cargo +stable nextest run --status-level all "
                       "--no-fail-fast --success-output never --failure-output never")
            process = docker("exec",cid,"sh","-c",capture.script(command),check=False)
            assert not process.stderr
            (case/"test.wire.json").write_bytes(process.stdout)
            captured = capture.decode(process.stdout,process.returncode)
            assert captured["complete"] and captured["returncode"] == 100
            printed = docker("exec",cid,"cat","target/nextest/default/junit.xml").stdout.decode()
            (case/"grade.log").write_text(printed)
            statuses = grade.run_parser(original["log_parser"],printed)
            assert len(statuses)==1 and list(statuses.values()) == ["fail"],statuses
            assert hashlib.sha256(oracle.read_bytes()).hexdigest() == canonical_oracle_sha
            after = core._inventory(fixture,["tests"])
            save(case/"input-inventory.json",after)
            added = sorted(name for name in after if name not in json.loads(Path(descriptor["manifest"]).read_bytes())["entries"])
            item = {"mode":mode,"statuses":statuses,"canonical_oracle_unchanged":True,"added":added}
            try:
                core.verify_test_inputs(descriptor,fixture)
            except ValueError as exc:
                item["exact_input_verification"] = "rejected"
                item["verification_error"] = str(exc)
            else:
                item["exact_input_verification"] = "pass"
            if mode=="new":
                assert added == ["tests/snapshots/snapshot__oracle.snap.new"],added
                assert item["exact_input_verification"] == "rejected"
                generated = fixture/added[0]
                (case/"generated.snap.new").write_bytes(generated.read_bytes())
                item["generated_sha256"] = hashlib.sha256(generated.read_bytes()).hexdigest()
            else:
                assert added == [] and item["exact_input_verification"] == "pass"
            result["cases"].append(item)
        assert result["cases"][0]["statuses"] == result["cases"][1]["statuses"]
        save(OUT/"container-after.json",json.loads(docker("inspect",cid).stdout)[0])
        verify_package(package,config["package_files"])
        result.update({"complete":True,"same_statuses":True,"frozen_package_unchanged":True})
    except BaseException as exc:
        save(OUT/"failure.json",{"exception":type(exc).__name__,"message":str(exc)})
        raise
    finally:
        if cid:
            docker("rm","-f","--volumes",cid)
            absent = docker("container","inspect",cid,check=False)
            result["owned_cleanup"] = absent.returncode != 0 and b"No such" in absent.stderr
        save(OUT/"result.json",result)
    assert result["owned_cleanup"]
    print(json.dumps({"complete":True,"same_statuses":True,"provider_calls":0,"paid_ready":False}))


if __name__=="__main__":
    main()
