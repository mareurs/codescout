FROM starryzhang/sweb.eval.x86_64.apache_1776_arrow-rs-7783@sha256:f6037b7781fd105b6516939a385a2d7deb73a7fe917fa96cdc865c112724ca10
LABEL codescout.effort-feedback-owner="codex:01a15ca9-f939-7603-acb5-01c6b02f68e2"
COPY . /ep-public-bootstrap
RUN cargo fetch --locked --manifest-path /ep-public-bootstrap/Cargo.toml
