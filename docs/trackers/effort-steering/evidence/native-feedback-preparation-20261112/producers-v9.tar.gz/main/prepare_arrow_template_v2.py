"""Reuse the once-created source guidance/index and add canonical public data in a new version."""
from pathlib import Path
import hashlib
import importlib.util
import json
import shutil
import sys
sys.path.insert(0, "/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from receipts import input_digest
from native_executor import _public_digest

MAIN = Path("/home/marius/work/claude/codescout")
SCRIPTS = MAIN / ".superpowers/sdd/2026-11-11-native-public-feedback-transfer"
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/apache__arrow-rs-7783")

def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    prior = ROOT / "common-preparation-v1"
    old_preparation = json.loads((prior / "preparation.json").read_bytes())
    old_index = json.loads((prior / "index-coderank-v2/result.json").read_bytes())
    assert old_index["source_digest_unchanged"] and old_index["index_exit"] == 0
    for rel in ("index-coderank-v2/native/cleanup.json", "index-coderank-v2/embedding/cleanup.json"):
        row = json.loads((prior / rel).read_bytes())
        assert row.get("complete", row.get("cleanup_complete")) is True
    old_template_hash = input_digest(prior / "project")
    public = ROOT / "public-data-materialization-v1/public-source"
    materialized = json.loads((public.parent / "registration.json").read_bytes())
    assert input_digest(public) == materialized["source_sha256"]
    out = ROOT / "common-preparation-v2"
    out.mkdir()
    project = out / "project"
    shutil.copytree(prior / "project", project, symlinks=True)
    assert _public_digest(project) == old_preparation["template_public_sha256"]
    for row in materialized["canonical_exports"]:
        target = project / row["path"]
        assert target.is_dir() and not any(target.iterdir())
        target.rmdir()
        shutil.copytree(public / row["path"], target, symlinks=True)
    assert _public_digest(project) == input_digest(public)
    (project / ".git/info/attributes").write_text("* -text -ident -filter\n")
    spec = importlib.util.spec_from_file_location("source_seed_v2", SCRIPTS / "prepare_arrow_context.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.seed(project)
    assert _public_digest(project) == input_digest(public)
    image_file = SCRIPTS / "arrow-gitlink-image.json"
    image = json.loads(image_file.read_bytes())[0]["Id"]
    runtime = json.loads((prior / "native-runtime.json").read_bytes())
    runtime["Image"] = image
    save(out / "native-runtime.json", runtime)
    save(out / "registration.json", {"source": str(public), "public_source_digest": input_digest(public),
        "image": image, "image_metadata": str(image_file), "image_metadata_sha256": sha(image_file),
        "producer_sha256": sha(Path(__file__)), "onboarding_reused": True,
        "additional_onboarding_calls": 0, "previous_template_sha256": old_template_hash,
        "public_data": materialized["canonical_exports"], "paid_ready": False})
    save(out / "preparation.json", {**old_preparation, "public_baseline_sha256": input_digest(public),
        "template_public_sha256": _public_digest(project), "reused_prior_root_index": True,
        "onboarding_reused": True, "additional_onboarding_calls": 0,
        "scope": "Existing source-only guidance/cache reused; canonical public data added. Incremental/member indexing and final native/private qualifications pending."})
    assert input_digest(prior / "project") == old_template_hash
    print(json.dumps({"template": str(project), "source_digest": input_digest(public),
        "additional_onboarding_calls": 0, "paid_ready": False}), flush=True)

if __name__ == "__main__":
    main()
