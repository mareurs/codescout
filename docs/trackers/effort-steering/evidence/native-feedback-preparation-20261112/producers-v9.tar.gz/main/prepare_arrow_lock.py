"""One source-bound offline lockfile preparation; never reads a private record."""
import datetime
import hashlib
import json
import pathlib
import shutil
import subprocess
import sys
import uuid

sys.path.insert(0, "/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from receipts import input_digest

ROOT = pathlib.Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/apache__arrow-rs-7783")
OWNER = "codex:01a15ca9-f939-7603-acb5-01c6b02f68e2"

def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")

def main():
    prior = json.loads((ROOT / "result.json").read_bytes())
    assert prior["cleanup_complete"] and prior["archive_exit"] == 0
    image = json.loads((ROOT / "image.json").read_bytes())
    source = ROOT / "source"
    before = input_digest(source)
    out = ROOT / "lock-preparation-v1"
    out.mkdir()
    prepared = out / "source"
    shutil.copytree(source, prepared, symlinks=True)
    assert input_digest(prepared) == before
    command = ["docker", "create", "--pull=never", "--name", "ep-feedback-lock-" + uuid.uuid4().hex,
        "--label", "effort-feedback-owner=" + OWNER, "--network", "none", "--read-only",
        "--memory", str(8 * 1024**3), "--memory-swap", str(8 * 1024**3), "--cpus", "4",
        "--pids-limit", "512", "--cap-drop=ALL", "--security-opt", "no-new-privileges",
        "--user", "1000:1000", "--tmpfs", "/tmp:rw,exec,size=1g,mode=1777",
        "--mount", "type=bind,src=" + str(prepared) + ",dst=/testbed",
        "--workdir", "/testbed", "--env", "HOME=/tmp", "--env", "CARGO_NET_OFFLINE=true",
        "--entrypoint", "cargo", image["Id"], "generate-lockfile", "--offline"]
    save(out / "registration.json", {"recorded_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "command": command, "source_digest": before, "workspace": ".", "image": image["Id"],
        "producer_sha256": hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
        "policy": "one generic source-bound dependency preparation; baseline code unchanged; no private input"})
    cid = subprocess.check_output(command, text=True).strip()
    save(out / "created.json", {"cid": cid})
    result = {"paid_ready": False, "provider_calls": 0}
    try:
        raw = json.loads(subprocess.check_output(["docker", "inspect", cid]))[0]
        assert raw["Config"]["Labels"]["effort-feedback-owner"] == OWNER and raw["Image"] == image["Id"]
        save(out / "container-before.json", raw)
        with (out / "stdout").open("xb") as stdout, (out / "stderr").open("xb") as stderr:
            code = subprocess.run(["docker", "start", "-a", cid], stdout=stdout, stderr=stderr,
                timeout=180).returncode
        raw = json.loads(subprocess.check_output(["docker", "inspect", cid]))[0]
        save(out / "container-after.json", raw)
        assert not raw["State"]["Running"] and not raw["State"]["OOMKilled"]
        result.update(exit_code=raw["State"]["ExitCode"], attach_exit=code)
        assert code in (0, raw["State"]["ExitCode"])
        original_files = {p.relative_to(source).as_posix() for p in source.rglob("*")}
        prepared_files = {p.relative_to(prepared).as_posix() for p in prepared.rglob("*")}
        assert not original_files - prepared_files
        assert prepared_files - original_files <= {"Cargo.lock"}
        assert input_digest(prepared, sorted(original_files)) == before
        assert input_digest(source) == before
        result.update(source_unchanged=True, added_files=sorted(prepared_files-original_files),
            prepared_digest=input_digest(prepared))
        if (prepared / "Cargo.lock").is_file():
            result["lock_sha256"] = hashlib.sha256((prepared / "Cargo.lock").read_bytes()).hexdigest()
    finally:
        raw = json.loads(subprocess.check_output(["docker", "inspect", cid]))[0]
        assert raw["Id"] == cid and raw["Config"]["Labels"]["effort-feedback-owner"] == OWNER
        if raw["State"]["Running"]:
            subprocess.run(["docker", "stop", "-t", "3", cid], check=True, capture_output=True)
        subprocess.run(["docker", "rm", "--volumes", cid], check=True, capture_output=True)
        check = subprocess.run(["docker", "ps", "-a", "--no-trunc", "--filter", "id=" + cid,
            "--format", "{{.ID}}"], capture_output=True, text=True)
        result["cleanup_complete"] = check.returncode == 0 and not check.stdout.strip()
        save(out / "result.json", result)
    print(json.dumps(result), flush=True)

if __name__ == "__main__":
    main()
