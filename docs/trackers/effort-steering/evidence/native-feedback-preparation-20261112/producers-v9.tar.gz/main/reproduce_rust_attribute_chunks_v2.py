"""Minimal unrelated Rust indexing reproduction; frozen binary/cache templates unchanged."""
from pathlib import Path
import hashlib
import importlib.util
import json
import shutil
import sqlite3
import subprocess
import sys

sys.dont_write_bytecode=True
WORK=Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from native_executor import _public_digest
from embedding_runtime import embedding_runtime
from receipts import input_digest

ROOT=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/skim-rs__skim-1044")
OUT=ROOT/"minimal-rust-attribute-index-v2"
SCRIPTS=Path(__file__).parent
SOURCE="""
#[test]
fn first_test() {
    assert_eq!(1 + 1, 2);
}

#[test]
fn second_test() {
    assert!(true);
}

pub fn actual_implementation(value: u32) -> u32 {
    value + 1
}
"""


def save(path,value):
    with path.open("x") as stream:
        json.dump(value,stream,sort_keys=True,indent=2)
        stream.write("\n")


def main():
    OUT.mkdir()
    actor=OUT/"fixture"
    (actor/"src").mkdir(parents=True)
    (actor/".codescout").mkdir()
    (actor/"Cargo.toml").write_text('[package]\nname="attribute_fixture"\nversion="0.1.0"\nedition="2021"\n')
    (actor/"src/lib.rs").write_text(SOURCE)
    (actor/".gitignore").write_text(".codescout/\ntarget/\n.codescout/private-memories/\n")
    for name in ("project.toml","system-prompt.md"):
        shutil.copy2(ROOT/"common-preparation-v1/project/.codescout"/name,actor/".codescout"/name)
    subprocess.run(["git","init","-q"],cwd=actor,check=True,capture_output=True)
    subprocess.run(["git","add","--","Cargo.toml","src/lib.rs",".gitignore"],cwd=actor,check=True,capture_output=True)
    subprocess.run(["git","-c","user.name=Unrelated source probe","-c","user.email=offline@invalid",
                    "commit","-qm","Unrelated Rust source"],cwd=actor,check=True,capture_output=True)
    before=_public_digest(actor)
    prepared=ROOT/"native-projection-canaries-v1"
    previous=json.loads((prepared/"registration.json").read_bytes())
    image=previous["image"]
    relay=OUT/"embedding"
    relay.mkdir()
    save(OUT/"registration.json",{"source_digest":before,"image":image,
        "source_sha256":hashlib.sha256(SOURCE.encode()).hexdigest(),
        "producer_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "scope":"Direct index probe of unrelated Rust syntax, not project onboarding or benchmark readiness.",
        "benchmark_additional_onboarding_calls":0,"client_model_calls":0,"embedding_compute_cost_usd":None,"paid_ready":False})
    spec=importlib.util.spec_from_file_location("attribute_fixture_native",SCRIPTS/"prior_prepare_native.py")
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.ROOT,module.IMAGE=OUT,image
    original=module._native_argv
    with embedding_runtime(relay,image,previous["embedding"]) as descriptor:
        def private_argv(actor,home,configuration):
            argv=original(actor,home,configuration)
            argv[argv.index("--network")+1]=descriptor["network_id"]
            return argv
        module._native_argv=private_argv
        native=None
        try:
            native=module.Native("native",actor,{"native_image":image,"runtime_manifest":str(prepared/"native-runtime.json")})
            native.start()
            result=subprocess.run(["docker","exec",native.cid,"/bench/bin/codescout","index","-p","/testbed"],
                                  capture_output=True,timeout=600)
            (OUT/"index.stdout").write_bytes(result.stdout)
            (OUT/"index.stderr").write_bytes(result.stderr)
            assert result.returncode==0
            assert _public_digest(actor)==before
        finally:
            module._native_argv=original
            if native is not None:
                native.close()
    database=actor/".codescout/embeddings/testbed.db"
    connection=sqlite3.connect(database.as_uri()+"?mode=ro&immutable=1",uri=True)
    connection.row_factory=sqlite3.Row
    rows=[dict(row) for row in connection.execute("SELECT file_path,start_line,end_line,content FROM code_chunk ORDER BY file_path,start_line,end_line")]
    connection.close()
    save(OUT/"stored-chunks.json",rows)
    attributes=[row for row in rows if row["content"].strip()=="#[test]"]
    save(OUT/"result.json",{"complete":True,"stored_chunk_rows":len(rows),"standalone_test_attribute_rows":attributes,
        "attribute_row_count":len(attributes),"database_sha256":hashlib.sha256(database.read_bytes()).hexdigest(),
        "source_unchanged":_public_digest(actor)==before,"client_model_calls":0,"paid_ready":False})
    print(json.dumps({"stored_chunk_rows":len(rows),"standalone_test_attribute_rows":len(attributes),"client_model_calls":0,"paid_ready":False}))


if __name__=="__main__":
    main()
