"""Canonical public Git export with explicit bounded shadows for declared temporary volumes."""
from pathlib import Path, PurePosixPath
import argparse, datetime, hashlib, json, re, subprocess, tarfile, uuid
MAIN = Path("/home/marius/work/claude/codescout")
POP = MAIN / "docs/trackers/effort-steering/evidence/native-feedback-population-20261111"
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
OWNER = "codex:01a15ca9-f939-7603-acb5-01c6b02f68e2"
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")
def volume_options(image):
    declared = image["Config"].get("Volumes") or {}
    assert isinstance(declared, dict) and len(declared) <= 8
    options, expected = [], {}
    git = PurePosixPath("/testbed/.git")
    for name in sorted(declared):
        assert isinstance(name, str) and re.fullmatch(r"/[A-Za-z0-9_./-]+", name)
        path = PurePosixPath(name)
        assert str(path) == name and ".." not in path.parts
        assert not (git.is_relative_to(path) or path.is_relative_to(git)), "volume shadows Git metadata"
        expected[name] = "ro,noexec,nosuid,nodev,size=1m"
        options += ["--tmpfs", name + ":" + expected[name]]
    return options, expected
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--task-id", required=True)
    parser.add_argument("--image-ref", required=True)
    args = parser.parse_args()
    frozen = json.loads((POP / "freeze.json").read_bytes())
    assert all(sha(POP / name) == digest for name, digest in frozen["payload_sha256"].items())
    rows = json.loads((POP / "original-metadata.json").read_bytes())["tasks"]
    selected = [row for row in rows if row["id"] == args.task_id]
    assert len(selected) == 1
    task = selected[0]
    assert args.image_ref.startswith(task["image"] + "@sha256:")
    image = json.loads(subprocess.check_output(["docker", "image", "inspect", args.image_ref]))[0]
    assert args.image_ref in image["RepoDigests"]
    shadows, tmpfs = volume_options(image)
    out = ROOT / task["id"]
    out.mkdir()
    name = "ep-feedback-source-" + uuid.uuid4().hex
    command = ["docker", "create", "--name", name, "--label", "effort-feedback-owner=" + OWNER,
        "--network", "none", "--read-only", "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
        "--memory", "2g", "--memory-swap", "2g", "--cpus", "2", "--pids-limit", "128", *shadows,
        "--entrypoint", "git", image["Id"], "-c", "safe.directory=/testbed", "-C", "/testbed",
        "archive", "--format=tar", task["base_commit"]]
    save(out / "registration.json", {"schema": "native-feedback-public-base-export-v2",
        "recorded_at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "task": task,
        "argv": command, "image_id": image["Id"], "image_ref": args.image_ref, "declared_volume_shadows": tmpfs,
        "exporter_sha256": sha(__file__), "population_freeze_sha256": sha(POP / "freeze.json"),
        "model_calls": 0, "private_patch_read": False, "paid_ready": False,
        "scope": "Read-only source export only; final native/public/private declared-volume handling remains unqualified."})
    save(out / "image.json", image)
    cid = subprocess.check_output(command, text=True).strip()
    save(out / "created.json", {"cid": cid})
    report = {"id": task["id"], "cid": cid, "paid_ready": False}
    def inspect_owned():
        row = json.loads(subprocess.check_output(["docker", "inspect", cid]))[0]
        assert row["Id"] == cid and row["Image"] == image["Id"]
        assert row["Config"]["Labels"]["effort-feedback-owner"] == OWNER
        assert row["HostConfig"]["Tmpfs"] == tmpfs and row["HostConfig"]["ReadonlyRootfs"] is True
        assert not row["HostConfig"].get("Binds") and all(m["Type"] == "tmpfs" for m in row["Mounts"])
        return row
    try:
        save(out / "inspect-before.json", inspect_owned())
        with (out / "public-baseline.tar").open("xb") as stdout, (out / "archive.stderr").open("xb") as stderr:
            code = subprocess.run(["docker", "start", "-a", cid], stdout=stdout, stderr=stderr, timeout=180).returncode
        after = inspect_owned()
        save(out / "inspect-after.json", after)
        assert code == after["State"]["ExitCode"] == 0 and not after["State"]["OOMKilled"]
        source = out / "source"
        source.mkdir()
        with tarfile.open(out / "public-baseline.tar") as archive:
            members = archive.getmembers()
            assert archive.pax_headers.get("comment") == task["base_commit"]
            assert all(not PurePosixPath(m.name).is_absolute() and ".." not in PurePosixPath(m.name).parts for m in members)
            assert all(m.isfile() or m.isdir() or m.issym() or m.islnk() for m in members)
            archive.extractall(source, filter="data")
        files, links = {}, {}
        for path in source.rglob("*"):
            rel = path.relative_to(source).as_posix()
            if path.is_symlink(): links[rel] = str(path.readlink())
            elif path.is_file(): files[rel] = {"bytes": path.stat().st_size, "sha256": sha(path)}
        save(out / "public-source-manifest.json", {"files": files, "links": links, "archive_sha256": sha(out / "public-baseline.tar")})
        report.update(archive_exit=code, container_exit=after["State"]["ExitCode"], regular_paths=len(files),
            link_paths=len(links), cargo_manifest=(source / "Cargo.toml").is_file(),
            source_manifest_sha256=sha(out / "public-source-manifest.json"), no_anonymous_disk_volumes=True)
    except BaseException as error:
        report.update(error_type=type(error).__name__, error=str(error))
        raise
    finally:
        facts = inspect_owned()
        if facts["State"]["Running"]:
            subprocess.run(["docker", "stop", "-t", "3", cid], check=True, capture_output=True)
        subprocess.run(["docker", "rm", "--volumes", cid], check=True, capture_output=True)
        absence = subprocess.run(["docker", "ps", "-a", "--quiet", "--filter", "id=" + cid], capture_output=True, text=True)
        report["cleanup_complete"] = absence.returncode == 0 and not absence.stdout.strip()
        save(out / "result.json", report)
    print(json.dumps(report), flush=True)
if __name__ == "__main__":
    main()
