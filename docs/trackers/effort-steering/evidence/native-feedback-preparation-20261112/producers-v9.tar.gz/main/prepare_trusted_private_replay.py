"""Bind a sealed public-role input contract to unchanged prior private controls."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
WORK = Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path.insert(0, str(WORK / "tools/effort_protocol"))
from evaluator_entry import verify_package
from receipts import input_digest
import trusted_test_inputs as trusted


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--previous", type=Path, required=True)
    parser.add_argument("--contract", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    previous = args.previous.resolve(strict=True)
    contract_path = args.contract.resolve(strict=True)
    out = args.output
    assert out.is_absolute() and out.parent.resolve(strict=True) == previous.parent
    registration = json.loads((previous / "registration.json").read_bytes())
    old_config = previous / "config.json"
    assert sha(old_config) == registration["config_sha256"]
    config = json.loads(old_config.read_bytes())
    for path, digest in config["bindings"].items():
        assert sha(path) == digest, path
    verify_package(config["package_root"], config["package_files"])
    previous_result = json.loads((previous / "controls-result.json").read_bytes())
    assert previous_result["all_three_controls_met"] is True
    assert len(previous_result["controls"]) == len(registration["controls"]) == 3
    assert all(row["process_returncode"] == 0 and row["verdict"]["valid"] is True
        and row["verdict"]["pass"] is row["expected_pass"] for row in previous_result["controls"])
    contract = json.loads(contract_path.read_bytes())
    record = json.loads(Path(config["record"]).read_bytes())
    assert contract["task"] == record["instance_id"]
    descriptor = contract["descriptor"]
    roots, inventory, _ = trusted._validated(descriptor)
    assert roots == contract["roots"] and len(inventory) == contract["entries"]
    assert all(not any(Path(path).is_relative_to(root) for root in roots)
        for path in config["production_paths"])
    canonical = contract_path.parent / "canonical"
    for name in contract["official_paths"]:
        assert sha(canonical / name) == config["fixed_test_sha256"]["/testbed/" + name]
    assert contract["original_public_source_digest"] == registration["public_source_sha256"]
    assert input_digest(Path(registration["public_source"])) == registration["public_source_sha256"]
    assert input_digest(Path(registration["reference"])) == registration["reference_sha256"]
    config = copy.deepcopy(config)
    assert "trusted_test_inputs" not in config
    config["trusted_test_inputs"] = descriptor
    added = [Path(__file__), contract_path, Path(descriptor["archive"]), Path(descriptor["manifest"]),
        old_config, previous / "registration.json", previous / "controls-result.json"]
    added += [WORK / "tools/effort_protocol" / name for name in
        ("evaluator_entry.py", "trusted_test_inputs.py", "feedback_trusted_inputs.py")]
    config["bindings"].update({str(path): sha(path) for path in added})
    out.mkdir(mode=0o700)
    save(out / "config.json", config)
    controls = []
    for control in registration["controls"]:
        request_path = Path(control["request"])
        assert sha(request_path) == control["request_sha256"]
        request = json.loads(request_path.read_bytes())
        assert request["config"] == str(old_config) and request["config_sha256"] == sha(old_config)
        assert input_digest(Path(request["source"])) == request["source_digest"]
        request["config"] = str(out / "config.json")
        request["config_sha256"] = sha(out / "config.json")
        directory = out / ("control-" + control["name"])
        directory.mkdir()
        save(directory / "request.json", request)
        controls.append({**control, "request": str(directory / "request.json"),
            "request_sha256": sha(directory / "request.json")})
    save(out / "registration.json", {**registration, "schema": "native-feedback-private-controls-preregistration-v2",
        "config_sha256": sha(out / "config.json"), "controls": controls,
        "protected_input_contract": str(contract_path), "protected_input_contract_sha256": sha(contract_path),
        "protected_roots": roots, "protected_entries": len(inventory),
        "unchanged_prior_config": str(old_config), "unchanged_prior_config_sha256": sha(old_config),
        "entry_sha256": sha(WORK / "tools/effort_protocol/evaluator_entry.py"),
        "producer_sha256": sha(__file__), "client_model_calls": 0, "paid_ready": False,
        "scope": "Same records, labels, assertions, image, public/reference sources and prepared commands; add sealed input restoration/post-grade verification only. Actual three controls pending."})
    print(json.dumps({"prepared": str(out), "protected_roots": roots, "protected_entries": len(inventory),
        "selected_label_count": registration["selected_label_count"], "paid_ready": False}))


if __name__ == "__main__":
    main()
