"""Owned synthetic transport control; no benchmark outcome or provider call."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import uuid

sys.dont_write_bytecode = True
REV = Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path.insert(0, str(REV / "tools/effort_protocol"))
import trusted_test_inputs as core
import feedback_trusted_inputs as transport

ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
OUT = ROOT / "trusted-container-control-v4"
IMAGE = "sha256:5248bed949d8764c1cc6015676142746148f5bf69074bbe38cc84f6c8806411f"


def docker(*args, timeout=300, check=True):
    return subprocess.run(["docker", *args], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                          text=True, check=check, timeout=timeout)


def main():
    OUT.mkdir()
    canonical = OUT / "canonical"
    candidate = OUT / "candidate"
    for root in (canonical, candidate):
        (root / "tests/snapshots").mkdir(parents=True)
    (canonical / "tests/snapshots/original.snap").write_text("canonical oracle\n")
    (canonical / "tests/official-new.rs").write_text("official test\n")
    (candidate / "tests/snapshots/original.snap").write_text("candidate oracle\n")
    (candidate / "tests/extra.rs").write_text("candidate added\n")
    (candidate / "effort_trusted_probe.txt").write_text("candidate production repair\n")
    descriptor = core.seal_test_inputs(canonical, ["tests"], OUT / "sealed")
    result = {"schema": "trusted-container-synthetic-control-v1", "provider_calls": 0,
              "benchmark_verdict_claim": False, "image": IMAGE,
              "producer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    name = "effort-trusted-control-" + uuid.uuid4().hex[:12]
    cid = None
    try:
        cid = docker("run", "-d", "--name", name, "--network", "none", "--user", "0:0",
            "--memory", "8g", "--memory-swap", "8g", "--cpus", "4", "--init",
            "--cap-drop", "ALL", "--security-opt", "no-new-privileges", "--pids-limit", "4096",
            IMAGE, "sleep", "infinity").stdout.strip()
        identity = json.loads(docker("inspect", cid).stdout)[0]
        result["inspect"] = identity
        assert identity["Id"] == cid and identity["Image"] == IMAGE and identity["Mounts"] == []
        host = identity["HostConfig"]
        assert host["NetworkMode"] == "none" and host["Memory"] == 8*1024**3
        assert host["MemorySwap"] == 8*1024**3 and host["NanoCpus"] == 4*10**9
        setup = ("from pathlib import Path; import json; "
                 "p=Path('/testbed/tests/snapshots'); p.mkdir(parents=True,exist_ok=True); "
                 "(p/'original.snap').write_text('candidate oracle\\n'); "
                 "Path('/testbed/tests/extra.rs').write_text('candidate added\\n'); "
                 "Path('/testbed/effort_trusted_probe.txt').write_text('candidate production repair\\n'); "
                 "print(json.dumps({str(q):{'uid':q.stat().st_uid,'mode':oct(q.stat().st_mode & 511)} "
                 "for q in [p,p.parent,p/'original.snap']}))")
        result["candidate_setup_ownership"] = json.loads(docker("exec", cid, "python3", "-B", "-c", setup).stdout)
        before = docker("exec", cid, "cat", "/testbed/tests/snapshots/original.snap").stdout
        assert before == "candidate oracle\n"
        result["before"] = before
        installed = transport.install_inputs(docker, cid, descriptor)
        result["installation"] = installed
        result["post_install"] = transport.verify_inputs(docker, installed)
        oracle = docker("exec", cid, "cat", "/testbed/tests/snapshots/original.snap").stdout
        production = docker("exec", cid, "cat", "/testbed/effort_trusted_probe.txt").stdout
        assert oracle == "canonical oracle\n" and production == "candidate production repair\n"
        assert docker("exec", cid, "test", "!", "-e", "/testbed/tests/extra.rs", check=False).returncode == 0
        assert docker("exec", cid, "cat", "/testbed/tests/official-new.rs").stdout == "official test\n"
        result.update({"canonical_oracle": oracle, "candidate_production": production,
                       "candidate_added_input_removed": True, "official_new_test_present": True})
        docker("exec", cid, "python3", "-B", "-c",
               "from pathlib import Path; Path('/testbed/tests/snapshots/original.snap').write_text('tampered')")
        try:
            transport.verify_inputs(docker, installed)
        except ValueError as exc:
            result["post_grade_tamper_rejected"] = str(exc)
        else:
            raise AssertionError("post-grade tampering was accepted")
        assert docker("exec", cid, "cat", "/testbed/tests/snapshots/original.snap").stdout == "tampered"
        result["verification_did_not_restore_tampered_input"] = True
        result["memory_events"] = docker("exec", cid, "cat", "/sys/fs/cgroup/memory.events").stdout
        assert "oom_kill 0" in result["memory_events"]
        result["complete"] = True
    finally:
        if cid:
            docker("rm", "-f", cid)
            absent = docker("container", "inspect", cid, check=False)
            result["owned_cleanup"] = absent.returncode != 0 and "No such" in absent.stdout
        (OUT / "result.json").write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
    assert result["owned_cleanup"]
    print(json.dumps({k: result[k] for k in ("complete", "owned_cleanup", "provider_calls", "benchmark_verdict_claim")}, sort_keys=True))


if __name__ == "__main__":
    main()
