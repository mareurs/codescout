"""Versioned locked dependency preparation with a measured path-independent fetch toolchain."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
sys.dont_write_bytecode = True
WORK = Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path.insert(0, str(WORK / "tools/effort_protocol"))
from receipts import input_digest
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")
def inspect(image):
    return json.loads(subprocess.check_output(["docker", "image", "inspect", image]))[0]

FETCH = r"""
import hashlib,json,os,shutil,subprocess
from pathlib import Path
root=Path('/dependency-source')
expected=json.loads(Path('/dependency-control/expected.json').read_bytes())
env=dict(os.environ,RUSTUP_TOOLCHAIN=expected['toolchain'])
def versions():
 rows=[]
 for argv in [['rustc','-Vv'],['cargo','-V']]:
  r=subprocess.run(argv,cwd=root,capture_output=True,text=True,timeout=60,env=env)
  rows.append(dict(argv=argv,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr))
 return rows
lock=root/'Cargo.lock'
assert hashlib.sha256(lock.read_bytes()).hexdigest()==expected['lock_sha256']
before=versions()
assert before==expected['versions']
subprocess.run(['cargo','fetch','--locked'],cwd=root,check=True,timeout=1200,env=env)
assert hashlib.sha256(lock.read_bytes()).hexdigest()==expected['lock_sha256']
after=versions()
assert after==before
for name in expected['cache_roots']:
 p=Path(name)
 if p.exists():
  subprocess.run(['chmod','-R','a+rX',str(p)],check=True)
Path('/dependency-control/result.json').write_text(json.dumps({
 'lock_sha256':expected['lock_sha256'],'lock_bytes_unchanged':True,'toolchain':expected['toolchain'],
 'versions_before':before,'versions_after':after,'fetch_argv':['cargo','fetch','--locked'],
 'source':'Original canonical public source only; no task description/test patch/gold/model inputs.',
 'paid_ready':False},sort_keys=True,indent=2)+'\n')
shutil.rmtree(root)
"""

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--task-id", required=True)
    args = parser.parse_args()
    task = ROOT / args.task_id
    source = task / "source"
    source_sha = input_digest(source)
    projection = json.loads((task / "volume-free-image-v1/projection.json").read_bytes())
    readback = json.loads((task / "volume-free-image-v1/git-readback-v1/result.json").read_bytes())
    assert readback["canonical_archive_byte_equal"] and readback["cleanup_complete"]
    assert readback["image"] == projection["image"]
    before = inspect(projection["image"])
    assert inspect(projection["tag"])["Id"] == before["Id"]
    assert not before["Config"].get("Volumes") and not before["Config"].get("User")
    environment = dict(value.split("=", 1) for value in before["Config"]["Env"])
    cargo_home = Path(environment["CARGO_HOME"])
    assert cargo_home.is_absolute() and ".." not in cargo_home.parts
    versions_path = task / "source-toolchain-version-probe-v1.json"
    versions = json.loads(versions_path.read_bytes())
    assert [row["argv"] for row in versions] == [["rustc", "-Vv"], ["cargo", "-V"]]
    assert all(row["returncode"] == 0 and row["stderr"] == "" for row in versions)
    cwd_probe_path = task / "source-toolchain-cwd-probe-v1.json"
    cwd_probe = json.loads(cwd_probe_path.read_bytes())
    assert cwd_probe["image"] == before["Id"]
    selected = [row for row in cwd_probe["rows"] if row["cwd"] == "/testbed"]
    assert len(selected) == 5 and all(row["returncode"] == 0 and row["stderr"] == "" for row in selected)
    which = {tuple(row["argv"]): row["stdout"].strip() for row in selected}
    rustc = Path(which[("rustup", "which", "rustc")])
    cargo = Path(which[("rustup", "which", "cargo")])
    toolchain = rustc.parent.parent
    assert rustc.name == "rustc" and cargo.name == "cargo" and cargo.parent.parent == toolchain
    assert toolchain.is_absolute() and ".." not in toolchain.parts
    assert toolchain.is_relative_to(Path(environment["RUSTUP_HOME"]) / "toolchains")
    assert [{key: row[key] for key in ("argv", "returncode", "stdout", "stderr")} for row in selected[:2]] == versions
    lock = source / "Cargo.lock"
    assert lock.is_file() and not lock.is_symlink()
    out = task / "locked-dependency-image-v3"
    assert shutil.disk_usage(task).free >= 2 * before["Size"] + 80 * 1024**3
    tag = "effort-feedback-source:locked-dependencies-v3-" + before["Id"][7:19]
    assert subprocess.run(["docker", "image", "inspect", tag], capture_output=True).returncode != 0
    out.mkdir()
    context = out / "context"
    context.mkdir()
    shutil.copytree(source, context / "public-source", symlinks=True)
    assert input_digest(context / "public-source") == source_sha
    control = context / "control"
    control.mkdir()
    save(control / "expected.json", {"lock_sha256": sha(lock), "versions": versions, "toolchain": str(toolchain),
        "cache_roots": [str(cargo_home / name) for name in ("registry", "git")]})
    (control / "fetch.py").write_text(FETCH)
    recipe = context / "Dockerfile"
    recipe.write_text("FROM " + projection["tag"] + "\nCOPY public-source /dependency-source\n"
        "COPY control /dependency-control\nRUN python3 -I -B /dependency-control/fetch.py\n")
    save(out / "registration.json", {"schema": "original-locked-dependency-preparation-v1",
        "task": args.task_id, "parent_image": before["Id"], "public_source": str(source),
        "source_sha256": source_sha, "lock_sha256": sha(lock), "versions_probe_sha256": sha(versions_path),
        "toolchain_cwd_probe_sha256": sha(cwd_probe_path), "fetch_only_toolchain_path": str(toolchain),
        "producer_sha256": sha(__file__), "recipe_sha256": sha(recipe),
        "fetch_helper_sha256": sha(control / "fetch.py"), "network": "Docker default for dependency fetch only",
        "client_model_calls": 0, "root_embedding_compute_costs": "unmeasured", "paid_ready": False})
    built = subprocess.run(["docker", "build", "--pull=false", "--network", "default", "-t", tag, str(context)],
        capture_output=True, timeout=1800)
    (out / "build.stdout").write_bytes(built.stdout)
    (out / "build.stderr").write_bytes(built.stderr)
    assert built.returncode == 0, "locked dependency build failed; inspect preserved logs"
    after = inspect(tag)
    assert inspect(projection["tag"])["Id"] == before["Id"]
    layers = before["RootFS"]["Layers"]
    assert after["RootFS"]["Layers"][:len(layers)] == layers
    save(out / "image.json", after)
    assert not after["Config"].get("Volumes") and inspect(before["Id"])["Config"] == before["Config"]
    code = "from pathlib import Path;print(Path('/dependency-control/result.json').read_text(),end='')"
    command = ["docker", "run", "--rm", "--pull=never", "--network", "none", "--read-only",
        "--user", "1000:1000", "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
        "--memory", "128m", "--memory-swap", "128m", "--cpus", "1", "--pids-limit", "32",
        "--entrypoint", "python3", after["Id"], "-I", "-B", "-c", code]
    observed = subprocess.run(command, capture_output=True, timeout=60)
    (out / "readback.stdout").write_bytes(observed.stdout)
    (out / "readback.stderr").write_bytes(observed.stderr)
    assert observed.returncode == 0 and observed.stderr == b""
    receipt = json.loads(observed.stdout)
    assert receipt["lock_bytes_unchanged"] and receipt["lock_sha256"] == sha(lock)
    assert receipt["versions_before"] == receipt["versions_after"] == versions
    assert receipt["toolchain"] == str(toolchain)
    assert input_digest(source) == source_sha
    save(out / "result.json", {"image": after["Id"], "tag": tag, "parent_image": before["Id"],
        "lock_sha256": sha(lock), "source_unchanged": True, "fetch_receipt": receipt,
        "client_model_calls": 0, "paid_ready": False,
        "scope": "Original locked dependency cache only; exact public/private/native checks, permissions and final image cleanup remain pending."})
    print(json.dumps({"image": after["Id"], "lock_unchanged": True, "source_unchanged": True, "paid_ready": False}))

if __name__ == "__main__":
    main()
