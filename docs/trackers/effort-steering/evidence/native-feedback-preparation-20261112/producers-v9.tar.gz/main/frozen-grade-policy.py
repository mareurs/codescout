"""Explicit prospective adjudication; the raw grader and frozen records stay unchanged."""
import json
import re

import audit_reparse as audit
import multilang_grade as grade
import multilang_tasks as tasks
import stream_evidence as streams

POLICY_VERSION = "semantic-contract-v2"

def invalid(message, raw=None):
    return {"policy_version": POLICY_VERSION, "valid": False, "pass": False,
            "kind": "measurement_invalid", "error": message, "raw": raw}


def runtime_issue(runtime):
    if not isinstance(runtime, dict):
        return "runtime proof missing"
    if runtime.get("complete") is not True or runtime.get("resource_ok") is not True:
        return "runtime evidence incomplete or host resource floor failed"
    if type(runtime.get("cgroup_probes")) is not int or runtime["cgroup_probes"] < 2:
        return "initial/final cgroup observations missing"
    if type(runtime.get("oom_kill")) is not int or runtime["oom_kill"] != 0:
        return "OOM state unknown or nonzero"
    if runtime.get("errors") != []:
        return "runtime observation error"
    return None


def scoped_lines(log):
    """Keep physical lines and distinguish framed test payloads from diagnostics."""
    test_output = False
    indented = False
    after_capture = False
    for line in audit._ANSI.sub("", log).splitlines():
        if test_output:
            if indented and line.strip() and not line.startswith("    "):
                test_output = False
                after_capture = True
            elif not indented and re.match(
                    r"^test result: (?:ok|FAILED)\. \d+ passed; \d+ failed;", line):
                test_output = False
                after_capture = True
                yield line, True, after_capture
                continue
            else:
                yield line, True, after_capture
                continue
        delimited_header = re.match(
            r"^(?:---- .+ (?:stdout|stderr) ----|--- (?:STDOUT|STDERR|OUTPUT): .+ ---)$", line)
        indented_header = re.match(r"^ {0,3}(?:output|stdout|stderr) ─+$", line)
        if delimited_header or indented_header:
            test_output = True
            indented = bool(indented_header)
            yield line, True, after_capture
            continue
        if line.lstrip().startswith("{"):
            try:
                event = json.loads(line)
            except ValueError:
                event = None
            if (isinstance(event, dict) and event.get("type") == "test"
                    and any(key in event for key in ("stdout", "stderr"))):
                yield line, True, after_capture
                continue
        yield line, False, after_capture


def diagnostic_lines(log):
    # Do not turn captured test data or compiler source gutters into runtime evidence.
    lines = [line for line, captured, _ in scoped_lines(log) if not captured]
    return [line.strip() for line in lines
            if not re.match(r"^\s*(?:\d+\s*\||\|)", line)]


def infrastructure_issue(log):
    lines = diagnostic_lines(log)
    signal = grade.toolchain_crash("\n".join(lines))
    if signal:
        return "process-fatal diagnostic: " + signal
    for line in lines:
        if re.search(r"(?:^|:\s)(?:No space left on device|Disk quota exceeded)(?: \(os error \d+\))?$", line):
            return "storage diagnostic: " + line
        if re.search(r"(?:^|\s)/tmp/\S+:\s+Permission denied(?:\s|$)", line):
            return "temporary execution diagnostic: " + line
    return None


def compiler_diagnostic(log):
    """Recognize compiler evidence outside captured test payloads.

    A diagnostic after an unstructured capture ended remains ambiguous; it is
    not enough evidence to invent a candidate compiler failure.
    """
    lines = list(scoped_lines(log))
    for i, (line, captured, after_capture) in enumerate(lines):
        if captured:
            continue
        diagnostic = re.match(r"^error\[E\d+\]: ", line) or (
            re.match(r"^error: ", line) and any(
                re.match(r"^\s*(?:-->\s+\S+:\d+:\d+|\d+\s*\|)", context)
                for context, is_capture, _ in lines[i + 1:i + 5] if not is_capture))
        if diagnostic:
            if after_capture:
                raise ValueError("compiler diagnostic after captured test output has ambiguous provenance")
            return line
    return None

def linker_diagnostic(log):
    """Recognize ordinary Rust linker failure only in qualified physical lines."""
    # CRLF terminates a physical line; other splitlines separators are payload.
    physical_log = log.replace("\r\n", "\n").translate(str.maketrans({
        character: "\ufffd" for character in "\r\v\f\x1c\x1d\x1e\x85\u2028\u2029"
    }))
    for line, captured, after_capture in scoped_lines(physical_log):
        if captured:
            continue
        match = re.fullmatch(r"error: linking with `([^`\r\n]+)` failed: exit status: ([1-9][0-9]*)", line)
        if match and match.group(1).strip() and int(match.group(2)) < 128:
            if after_capture:
                raise ValueError("linker diagnostic after captured test output has ambiguous provenance")
            return line
    return None


def contextual_step_output(step, log):
    """Recover enclosing scope for a suffix, including a decoded UTF-8 cut."""
    tail = step["tail"]
    if step["name"] == "grade:rebuild":
        return tail
    normalized_log = audit._ANSI.sub("", log)
    normalized_tail = audit._ANSI.sub("", tail)
    if normalized_tail and not normalized_log.endswith(normalized_tail):
        normalized_tail = normalized_tail.lstrip("\ufffd")
    if normalized_tail and normalized_log.endswith(normalized_tail):
        return log
    return tail

def step_compiler_failure(step, log):
    """Classify this step without borrowing test output for a failed rebuild."""
    tail = contextual_step_output(step, log)
    if step["name"] == "grade:rebuild":
        return compiler_diagnostic(tail) is not None
    return compiler_diagnostic(tail) is not None or compiler_diagnostic(log) is not None



def classify_public(log, exit_code, *, runtime, truncated=False):
    issue = runtime_issue(runtime) or infrastructure_issue(log)
    if issue or truncated or type(exit_code) is not int or exit_code < 0:
        return invalid(issue or "capture incomplete or process exit unknown/fatal")
    return {"policy_version": POLICY_VERSION, "valid": True, "pass": exit_code == 0,
            "kind": "pass" if exit_code == 0 else "functional_failure", "error": None}

def adjudicate_private(raw, full_evidence, record, bundle, *, log, runtime):
    """Historical tail-only replay; prospective work must use adjudicate_streams."""
    return _adjudicate(raw, full_evidence, record, bundle, log=log, runtime=runtime)
def _adjudicate(raw, full_evidence, record, bundle, *, log, runtime, diagnostics=None):
    """Shared selected-test semantics; prospective diagnostics arrive fully qualified."""
    issue = runtime_issue(runtime)
    if issue:
        return invalid(issue, raw)
    if (not all(isinstance(value, dict) for value in (raw, full_evidence, record, bundle))
            or not isinstance(bundle.get("expected"), dict)):
        return invalid("policy evidence mappings missing or malformed", raw)
    try:
        if (type(raw.get("pass")) is not bool or raw.get("oom_killed") is not False
                or raw.get("container_removed") is not True or raw.get("error")
                or raw.get("infra") is not None):
            return invalid("raw grader fault or unknown terminal metadata", raw)
        steps = full_evidence["steps"]
        expected_steps = (["grade:rebuild"] if any(
            isinstance(cmd, str) and cmd.strip() for cmd in (record.get("rebuild_cmds") or [])) else [])
        expected_steps += [f"grade:test[{i}]" for i in range(len(record["test_cmds"]))]
        expected_steps += [f"grade:print[{i}]" for i in range(len(record["print_cmds"]))]
        if not record["test_cmds"] or not record["print_cmds"] or [s["name"] for s in steps] != expected_steps:
            return invalid("full step evidence missing or out of order", raw)
        for step in steps:
            code = step["returncode"]
            if not isinstance(step.get("tail"), str):
                return invalid("full step tail missing or malformed", raw)
            if type(code) is not int or code < 0 or step.get("truncated"):
                return invalid("step process/capture invalid", raw)
            if step["name"].startswith("grade:print[") and code != 0:
                return invalid("print command failed; log is not qualified", raw)
        evidence_texts = ([log] + [contextual_step_output(step, log) for step in steps]
                          if diagnostics is None else list(diagnostics.values()))
        for evidence in evidence_texts:
            issue = infrastructure_issue(evidence)
            if issue:
                return invalid(issue, raw)
        f2p, p2p = tasks.expected_sets(record, bundle)
        expected = f2p + p2p
        if not f2p or len(set(expected)) != len(expected):
            return invalid("expected set empty or ambiguous", raw)
        observed = grade.run_parser(record["log_parser"], log)
        original = grade.verdict(observed, f2p, p2p)
        for key, value in original.items():
            if (type(raw.get(key)) is not type(value) or raw.get(key) != value
                    or full_evidence.get(key) != value):
                return invalid("raw verdict contradicts parser/evidence", raw)
        result = audit.reparse(record, log, f2p, p2p)
        if result["original"] != original:
            return invalid("audit raw verdict disagrees", raw)
        adjusted = dict(observed)
        for recovered in result["recovered"]:
            adjusted[recovered["key"]] = recovered["status"]
        statuses = {key: adjusted[key] for key in expected if key in adjusted}
        if any(value not in ("pass", "fail", "skip") for value in statuses.values()):
            return invalid("unknown expected status", raw)
        def compiler(step):
            return (step_compiler_failure(step, log) if diagnostics is None
                    else (compiler_diagnostic(diagnostics[step["name"]])
                      or linker_diagnostic(diagnostics[step["name"]])))
        compile_failure = any(
            step["returncode"] != 0 and compiler(step)
            for step in steps if not step["name"].startswith("grade:print["))
        unknown_rebuild = any(
            s["name"] == "grade:rebuild" and s["returncode"] != 0 and not compiler(s)
            for s in steps)
        if unknown_rebuild:
            return invalid("rebuild failed without a classified compiler diagnostic", raw)
        if result["adjusted"]["missing"] and not compile_failure:
            return invalid("expected statuses missing without compiler evidence", raw)
        passed = result["adjusted"]["pass"] and not compile_failure
        return {"policy_version": POLICY_VERSION, "valid": True, "pass": passed,
                "kind": "compile_failure" if compile_failure else ("pass" if passed else "test_failure"),
                "error": None, "raw": original, "adjusted": result["adjusted"],
                "statuses": statuses, "recovered": result["recovered"],
                "raw_parsed_keys": len(observed)}
    except (KeyError, TypeError, ValueError, grade.ParserError) as exc:
        return invalid("policy evidence refused: " + str(exc), raw)


def adjudicate_streams(raw, full_evidence, record, bundle, *, log, runtime, registered):
    """Prospective entry point. No tail-only receipt or unregistered runner can qualify."""
    try:
        if not isinstance(raw, dict) or not isinstance(full_evidence, dict):
            raise streams.EvidenceError("raw/full evidence mappings missing")
        for key in ("pass", "expected", "not_passing", "missing", "examples",
                    "oom_killed", "container_removed", "error", "infra"):
            if (type(raw.get(key)) is not type(full_evidence.get(key))
                    or raw.get(key) != full_evidence.get(key)):
                raise streams.EvidenceError("raw/full metadata contradiction: " + key)
        diagnostics = streams.qualify(full_evidence, record, log, registered)
        result = _adjudicate(raw, full_evidence, record, bundle, log=log, runtime=runtime,
                             diagnostics=diagnostics)
    except streams.EvidenceError as exc:
        result = invalid(str(exc), raw)
    return dict(result, policy_version="semantic-stream-contract-v2")
