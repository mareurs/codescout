"""Probe the actual public_clone projection using frozen native runtime, not the template alone."""
from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys
import time

sys.dont_write_bytecode=True
WORK=Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from public_clone import prepare_public_clone
from receipts import input_digest
from native_executor import _public_digest
from embedding_runtime import embedding_runtime
import executor

SCRIPTS=Path(__file__).parent
ROOT=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/skim-rs__skim-1044")
OUT=ROOT/"native-projection-canaries-v1"


def save(path,value):
    with path.open("x") as stream:
        json.dump(value,stream,sort_keys=True,indent=2)
        stream.write("\n")


def main():
    OUT.mkdir()
    common=ROOT/"common-preparation-v1"
    template=common/"project"
    source=common/"public-source"
    before=input_digest(template)
    source_digest=input_digest(source)
    knowledge=template/".codescout"
    paths=["project.toml","system-prompt.md"]+sorted(p.relative_to(knowledge).as_posix() for p in (knowledge/"memories").rglob("*.md") if p.is_file())
    for optional in ("workspace.toml",):
        if (knowledge/optional).is_file():
            paths.append(optional)
    config={"template":str(template),"template_sha256":before,"knowledge_paths":paths,
            "knowledge_sha256":input_digest(knowledge,paths)}
    save(OUT/"clone-config.json",config)
    projection=prepare_public_clone(source,OUT/"actor",config)
    save(OUT/"projection.json",projection)
    assert projection["source_sha256"]==source_digest and projection["knowledge_sha256"]==config["knowledge_sha256"]
    actor=OUT/"actor"
    image=json.loads((ROOT/"private-clean-image-v1/result.json").read_bytes())["image"]
    runtime=json.loads((common/"native-runtime.json").read_bytes())
    runtime["Image"]=image
    save(OUT/"native-runtime.json",runtime)
    relay=OUT/"embedding"
    relay.mkdir()
    embedding={"service_id":"88e74239478cbedcf13732d05417292c3eed43054a2b1b3ea88f8d122abb1ff8",
        "service_image":"sha256:be175932c3c96e882dfbc7e20e0e834f58c89c2925f48b222837ee929dfc47ee",
        "upstream_network":"codescout-retrieval_retrieval_net","subnet":"100.120.0.0/28"}
    requests=[
        ("workspace",{"action":"status"}),
        ("index",{"action":"verify"}),
        ("semantic_search",{"query":"SkimItem trait text display preview output fuzzy matching","limit":3}),
        ("memory",{"action":"read","topic":"source-claude"}),
        ("symbols",{"path":"src/skim_item.rs","name":"SkimItem","exact":True,"kind":"interface"}),
        ("references",{"path":"src/skim_item.rs","symbol":"SkimItem","limit":10}),
        ("symbol_at",{"path":"src/skim_item.rs","line":89,"identifier":"SkimItem"}),
        ("call_graph",{"path":"src/skim_item.rs","symbol":"SkimItem/output","direction":"callees","max_depth":1})]
    save(OUT/"registration.json",{"schema":"projected-native-canary-v1","image":image,
        "public_source_digest":source_digest,"knowledge_paths":paths,"knowledge_sha256":config["knowledge_sha256"],
        "template_digest":before,"runtime_sha256":hashlib.sha256((OUT/"native-runtime.json").read_bytes()).hexdigest(),
        "embedding":embedding,"requests":requests,"producer_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "additional_onboarding_calls":0,"client_model_calls":0,"embedding_compute_cost_usd":None,
        "scope":"Actual projected public source/cache and native tools; first author request/all16slot qualification remain separate.",
        "paid_ready":False})
    spec=importlib.util.spec_from_file_location("skim_projected_native",SCRIPTS/"prior_prepare_native.py")
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.ROOT,module.IMAGE=OUT,image
    original=module._native_argv
    rows=[]
    with embedding_runtime(relay,image,embedding) as descriptor:
        def private_argv(actor,home,config):
            argv=original(actor,home,config)
            argv[argv.index("--network")+1]=descriptor["network_id"]
            return argv
        module._native_argv=private_argv
        native=None
        try:
            native=module.Native("native",actor,{"native_image":image,"runtime_manifest":str(OUT/"native-runtime.json")})
            native.start()
            actual=executor._inspect(native.cid)
            networks=actual["NetworkSettings"]["Networks"]
            assert len(networks)==1 and next(iter(networks.values()))["NetworkID"]==descriptor["network_id"]
            assert "CODESCOUT_EMBED_MODEL=CodeRankEmbed" in actual["Config"]["Env"]
            assert "CODESCOUT_EMBED_URL=http://source-embeddings:8000/v1" in actual["Config"]["Env"]
            if projection["index_update_required"]:
                start=time.monotonic()
                indexed=subprocess.run(["docker","exec",native.cid,"/bench/bin/codescout","index","-p","/testbed"],
                                       capture_output=True,timeout=1800)
                (OUT/"incremental-index.stdout").write_bytes(indexed.stdout)
                (OUT/"incremental-index.stderr").write_bytes(indexed.stderr)
                save(OUT/"incremental-index.json",{"returncode":indexed.returncode,"wall_s":time.monotonic()-start})
                assert indexed.returncode==0
            pages=[]
            cursor=None
            while True:
                page=native.rpc("tools/list",{"cursor":cursor} if cursor else {})
                pages.append(page)
                cursor=page["result"].get("nextCursor")
                if not cursor:
                    break
            save(OUT/"tool-pages.json",pages)
            for tool,args in requests:
                start=time.monotonic()
                response=native.tool(tool,args,timeout=300)
                save(OUT/(tool+".json"),response)
                row={"tool":tool,"transport_complete":True,"wall_s":time.monotonic()-start}
                rows.append(row)
                print(json.dumps(row),flush=True)
            assert _public_digest(actor)==source_digest and input_digest(source)==source_digest
            assert input_digest(template)==before
            assert input_digest(actor/".codescout",paths)==config["knowledge_sha256"]
            save(OUT/"calls-completed.json",{"calls":rows,"source_unchanged":True,"template_unchanged":True,
                "static_knowledge_unchanged":True,"additional_onboarding_calls":0,"client_model_calls":0,
                "scope":"Transport/source integrity only; inspect primary results before claiming semantic/LSP success.",
                "paid_ready":False})
        except BaseException as exc:
            save(OUT/"failure.json",{"exception":type(exc).__name__,"message":str(exc),"paid_ready":False})
            raise
        finally:
            module._native_argv=original
            if native is not None:
                native.close()


if __name__=="__main__":
    main()
