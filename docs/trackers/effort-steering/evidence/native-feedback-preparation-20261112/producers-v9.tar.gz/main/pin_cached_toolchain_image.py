"""Select an already measured cached compiler through image ENV; do not change the filesystem."""
from pathlib import Path
import argparse, hashlib, json, subprocess, sys
sys.dont_write_bytecode = True
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
TOOLCHAIN = "/usr/local/rustup/toolchains/stable-x86_64-unknown-linux-gnu"
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")
def inspect(image):
    return json.loads(subprocess.check_output(["docker", "image", "inspect", image]))[0]
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--task-id", required=True)
    parser.add_argument("--proxy-probe", type=Path, required=True)
    args = parser.parse_args()
    task = ROOT / args.task_id
    parent_root = task / "volume-free-image-v1"
    parent = json.loads((parent_root / "projection.json").read_bytes())
    qualified = json.loads((parent_root / "git-readback-v1/result.json").read_bytes())
    assert qualified["canonical_archive_byte_equal"] and qualified["cleanup_complete"] and qualified["image"] == parent["image"]
    probe = json.loads(args.proxy_probe.read_bytes())
    assert len(probe) == 2 and [row["argv"] for row in probe] == [["rustc", "-Vv"], ["cargo", "-V"]]
    assert all(row["returncode"] == 0 and row["stderr"] == "" for row in probe)
    before = inspect(parent["tag"])
    assert before["Id"] == parent["image"] and not before["Config"].get("Volumes")
    out = task / "cached-toolchain-image-v1"
    out.mkdir()
    context = out / "context"
    context.mkdir()
    recipe = context / "Dockerfile"
    recipe.write_text("FROM " + parent["tag"] + "\nENV RUSTUP_TOOLCHAIN=" + TOOLCHAIN + "\n")
    tag = "effort-feedback-source:cached-toolchain-" + before["Id"][7:19]
    assert subprocess.run(["docker", "image", "inspect", tag], capture_output=True).returncode != 0
    save(out / "registration.json", {"parent_image": before["Id"], "parent_tag": parent["tag"],
        "toolchain": TOOLCHAIN, "probe": str(args.proxy_probe), "probe_sha256": sha(args.proxy_probe),
        "recipe_sha256": sha(recipe), "producer_sha256": sha(__file__),
        "client_model_calls": 0, "paid_ready": False})
    result = subprocess.run(["docker", "build", "--pull=false", "--network", "none", "-t", tag, str(context)],
        capture_output=True, timeout=300)
    (out / "build.stdout").write_bytes(result.stdout)
    (out / "build.stderr").write_bytes(result.stderr)
    assert result.returncode == 0
    assert inspect(parent["tag"])["Id"] == parent["image"]
    after = inspect(tag)
    save(out / "image.json", after)
    assert after["RootFS"]["Layers"] == before["RootFS"]["Layers"]
    first, second = before["Config"], after["Config"]
    assert all(first.get(key) == second.get(key) for key in first.keys() | second.keys() if key != "Env")
    wanted = dict(value.split("=", 1) for value in first["Env"])
    wanted["RUSTUP_TOOLCHAIN"] = TOOLCHAIN
    actual = dict(value.split("=", 1) for value in second["Env"])
    assert actual == wanted and len(actual) == len(second["Env"])
    code = "import subprocess,json; print(json.dumps([{'argv':a,'returncode':(r:=subprocess.run(a,capture_output=True,text=True)).returncode,'stdout':r.stdout,'stderr':r.stderr} for a in [['rustc','-Vv'],['cargo','-V']]],indent=2))"
    command = ["docker", "run", "--rm", "--pull=never", "--network", "none", "--read-only", "--user", "1000:1000",
        "--cap-drop", "ALL", "--security-opt", "no-new-privileges", "--memory", "512m", "--memory-swap", "512m",
        "--cpus", "1", "--pids-limit", "64", "--entrypoint", "python3", after["Id"], "-I", "-B", "-c", code]
    observed = subprocess.run(command, capture_output=True, timeout=60)
    (out / "proxy.stdout").write_bytes(observed.stdout)
    (out / "proxy.stderr").write_bytes(observed.stderr)
    assert observed.returncode == 0 and observed.stderr == b""
    assert json.loads(observed.stdout) == probe
    save(out / "result.json", {"image": after["Id"], "tag": tag, "parent_image": before["Id"],
        "filesystem_layers_identical": True, "only_effective_config_change": {"RUSTUP_TOOLCHAIN": TOOLCHAIN},
        "readonly_uid1000_proxy_versions": probe, "client_model_calls": 0, "paid_ready": False,
        "scope": "Measured cached toolchain selection; same strict compile/private/native qualifications still required"})
    print(json.dumps({"image": after["Id"], "filesystem_layers_identical": True, "paid_ready": False}))
if __name__ == "__main__":
    main()
