"""Freeze original-label Skim controls under the corrected private input/stream contract."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys

sys.dont_write_bytecode=True
WORK=Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from evaluator_entry import verify_package,_input_digest
import trusted_test_inputs as trusted
import feedback_nextest as nextest

ROOT=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/skim-rs__skim-1044")
OUT=ROOT/"private-preparation-v1"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path,value):
    with path.open("x") as stream:
        json.dump(value,stream,sort_keys=True,indent=2)
        stream.write("\n")


def main():
    readback=json.loads((ROOT/"private-clean-image-v1/public-readback-v1/result.json").read_bytes())
    assert readback["complete"] and readback["owned_cleanup"] and readback["differences"]==0
    image=json.loads((ROOT/"private-clean-image-v1/result.json").read_bytes())["image"]
    assert image==readback["image"]
    old=json.loads(Path("/var/tmp/ep11-01a15/private-controls/obscura/config.json").read_bytes())
    package=verify_package(old["package_root"],old["package_files"])
    sys.path.insert(0,str(package))
    import multilang_tasks as tasks
    import stream_evidence as streams
    original_path=ROOT/"private-structure-v1/original-record.json"
    original=json.loads(original_path.read_bytes())
    public=ROOT/"common-preparation-v1/public-source"
    public_sha=_input_digest(public)
    prepared_root=ROOT/"nextest-junit-host-format-proof-v1"
    record=json.loads((prepared_root/"prepared-task-record.json").read_bytes())
    assert record==nextest.prepare_record(original)
    stream_registration=json.loads((prepared_root/"task-stream-registration.json").read_bytes())
    nextest.translate_registration(record,stream_registration,streams)
    contract=json.loads((ROOT/"trusted-test-inputs-v1/contract.json").read_bytes())
    descriptor=contract["descriptor"]
    roots,_,_=trusted._validated(descriptor)
    production=tasks.tasks.patch_files(record["patch"])
    official=tasks.tasks.patch_files(record["test_patch"])
    assert not any(Path(name).is_relative_to(root) for name in production for root in roots)
    OUT.mkdir(mode=0o700)
    save(OUT/"original-record.json",original)
    save(OUT/"full-record.json",record)
    (OUT/"gold.patch").write_text(record["patch"])
    (OUT/"official-tests.patch").write_text(record["test_patch"])
    (OUT/"baseline.patch").write_bytes(b"")
    reference=OUT/"reference"
    shutil.copytree(public,reference,symlinks=True)
    applied=subprocess.run(["git","apply","--binary",str(OUT/"gold.patch")],cwd=reference,capture_output=True)
    (OUT/"reference-apply.stdout").write_bytes(applied.stdout)
    (OUT/"reference-apply.stderr").write_bytes(applied.stderr)
    assert applied.returncode==0
    fixed=ROOT/"trusted-test-inputs-v1/canonical"
    fixed_sha={"/testbed/"+name:sha(fixed/name) for name in official}
    save(OUT/"acceptance-labels.json",{"schema":"source-independent-original-acceptance-v1",
        "task":record["instance_id"],"image":image,"record_sha256":sha(OUT/"full-record.json"),
        "original_record_sha256":sha(original_path),"original_f2p":original["FAIL_TO_PASS"],
        "original_p2p":original["PASS_TO_PASS"],"expected_population_unchanged":True,
        "assertions_unchanged":True,"commands_unchanged":False,"commands_prepared_before_outcomes":True,
        "command_preparation":"Same selectors and original XML parser/print; output never, no-fail-fast, empty report on compile failure, declared snapshot mode no.",
        "format_profile":nextest.PROFILE,"controls":[],"paid_ready":False})
    paths=[OUT/name for name in ("original-record.json","full-record.json","gold.patch","official-tests.patch","acceptance-labels.json")]
    paths += [fixed/name for name in official]
    paths += [Path(__file__),ROOT/"trusted-test-inputs-v1/contract.json",prepared_root/"compatibility.json",
        prepared_root/"task-stream-registration.json",Path(descriptor["manifest"]),Path(descriptor["archive"])]
    paths += [WORK/"tools/effort_protocol"/name for name in
        ("evaluator_entry.py","trusted_test_inputs.py","feedback_trusted_inputs.py","feedback_nextest.py")]
    config={"package_root":str(package),"package_files":old["package_files"],
        "bindings":{str(path):sha(path) for path in paths},"record":str(OUT/"full-record.json"),
        "acceptance_registration":str(OUT/"acceptance-labels.json"),"image":image,
        "production_paths":production,"fixed_test_sha256":fixed_sha,"diagnostic_artifacts":{},
        "stream_registration":stream_registration,"trusted_test_inputs":descriptor}
    save(OUT/"config.json",config)
    controls=[]
    for name,source,patch,edited in (
            ("baseline",public,OUT/"baseline.patch",[]),
            ("reference",reference,OUT/"gold.patch",production),
            ("reference-repeat",reference,OUT/"gold.patch",production)):
        directory=OUT/("control-"+name)
        directory.mkdir()
        proof=directory/"deterministic-control-patch.json"
        save(proof,{"complete":True,"sha256":sha(patch),"bytes":patch.stat().st_size,"edited":edited,
            "scope":"Deterministic base/reference control; no actor or native capture claim."})
        request={"config":str(OUT/"config.json"),"config_sha256":sha(OUT/"config.json"),
            "source":str(source),"source_digest":_input_digest(source),
            "public_baseline":str(public),"public_baseline_sha256":public_sha,
            "patch":str(patch),"patch_sha256":sha(patch),
            "capture_proof":str(proof),"capture_proof_sha256":sha(proof)}
        save(directory/"request.json",request)
        controls.append({"name":name,"request":str(directory/"request.json"),
            "request_sha256":sha(directory/"request.json"),"expected_pass":name!="baseline"})
    assert _input_digest(public)==public_sha
    verify_package(package,old["package_files"])
    save(OUT/"registration.json",{"schema":"native-feedback-private-controls-preregistration-v1",
        "task":record["instance_id"],"image":image,"public_source":str(public),"public_source_sha256":public_sha,
        "reference":str(reference),"reference_sha256":_input_digest(reference),
        "config_sha256":sha(OUT/"config.json"),"controls":controls,"selected_label_count":len(record["FAIL_TO_PASS"])+len(record["PASS_TO_PASS"]),
        "protected_input_contract_sha256":sha(ROOT/"trusted-test-inputs-v1/contract.json"),
        "client_model_calls":0,"paid_ready":False,
        "scope":"Original-label baseline/reference/repeat pending; stop on first invalid or contradicted control."})
    print(json.dumps({"prepared":str(OUT),"selected_labels":len(record["FAIL_TO_PASS"])+len(record["PASS_TO_PASS"]),
        "image":image,"client_model_calls":0,"paid_ready":False}))


if __name__=="__main__":
    main()
