"""Exclusive, reopened WIP custody checkpoints; never a paid-admission proof."""
import hashlib
import io
import json
from pathlib import Path
import re
import sys
import tarfile

MAIN = Path("/home/marius/work/claude/codescout")
OLD = Path("/home/marius/.codex/worktrees/cf66/codescout")
REV = Path("/home/marius/.codex/worktrees/2aa6/codescout")
OUT = MAIN / "docs/trackers/effort-steering/evidence/native-feedback-baseline-20261111"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    label = sys.argv[1]
    assert re.fullmatch("[a-z0-9-]+", label)
    before = json.loads((OUT / "manifest.json").read_bytes())["files"]
    assert all(sha(OLD / name) == row["sha256"] for name, row in before.items())
    paths = set(before)
    paths.update(str(path.relative_to(REV)) for path in (REV / "tools/effort_protocol").glob("feedback_*.py"))
    paths.update(str(path.relative_to(REV)) for path in (REV / "tools/effort_protocol").glob("test_feedback_*.py"))
    paths.update(str(path.relative_to(REV)) for path in (REV / "tools/effort_protocol").glob("*trusted_test_inputs*.py"))
    members = {}
    archive = OUT / (label + ".tar.gz")
    with tarfile.open(archive, "x:gz") as tar:
        for name in sorted(paths):
            path = REV / name
            assert path.is_file() and not path.is_symlink(), path
            data = path.read_bytes()
            members[name] = {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}
            entry = tarfile.TarInfo(name)
            entry.size = len(data)
            entry.mode = path.stat().st_mode & 0o777
            tar.addfile(entry, io.BytesIO(data))
    with tarfile.open(archive) as tar:
        assert len(tar.getmembers()) == len(members)
        for name, row in members.items():
            assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == row["sha256"]
            assert sha(REV / name) == row["sha256"]
    assert all(sha(OLD / name) == row["sha256"] for name, row in before.items())
    result = {"schema": "feedback-wip-source-custody-v1", "stage": label, "members": members,
              "archive_bytes": archive.stat().st_size, "archive_sha256": sha(archive),
              "legacy_inputs_reopened_unchanged": len(before), "source": str(REV),
              "producer_sha256": sha(Path(__file__)), "paid_admission": False}
    with (OUT / (label + ".json")).open("x") as stream:
        stream.write(json.dumps(result, sort_keys=True, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "members"}))
    print("members=" + str(len(members)))


if __name__ == "__main__":
    main()
