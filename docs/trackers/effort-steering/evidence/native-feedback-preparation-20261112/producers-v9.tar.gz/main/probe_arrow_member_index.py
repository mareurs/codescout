"""Incrementally index the prepared source, then exercise one actual member namespace."""
from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys
import time
sys.path.insert(0, "/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from embedding_runtime import embedding_runtime
from native_executor import _public_digest
import executor

MAIN = Path("/home/marius/work/claude/codescout")
SCRIPTS = MAIN / ".superpowers/sdd/2026-11-11-native-public-feedback-transfer"
PARENT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/apache__arrow-rs-7783/common-preparation-v2")

def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")

def main():
    prep = json.loads((PARENT / "preparation.json").read_bytes())
    project = PARENT / "project"
    assert _public_digest(project) == prep["template_public_sha256"]
    image = json.loads((PARENT / "registration.json").read_bytes())["image"]
    out = PARENT / "root-and-member-index-v1"
    out.mkdir()
    relay_out = out / "embedding"
    relay_out.mkdir()
    configuration = {"service_id": "88e74239478cbedcf13732d05417292c3eed43054a2b1b3ea88f8d122abb1ff8",
        "service_image": "sha256:be175932c3c96e882dfbc7e20e0e834f58c89c2925f48b222837ee929dfc47ee",
        "upstream_network": "codescout-retrieval_retrieval_net", "subnet": "100.120.0.0/28"}
    save(out / "registration.json", {"source": str(project), "public_digest": prep["template_public_sha256"],
        "image": image, "embedding": configuration, "member": {"id": "arrow-buffer", "root": "arrow-buffer"},
        "producer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "additional_onboarding_calls": 0, "client_model_calls": 0, "embedding_compute_cost_usd": None,
        "scope": "Actual root update and one-member canary, not all-member readiness", "paid_ready": False})
    spec = importlib.util.spec_from_file_location("member_probe_native", SCRIPTS / "prior_prepare_native.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.ROOT, module.IMAGE = out, image
    original = module._native_argv
    with embedding_runtime(relay_out, image, configuration) as descriptor:
        def private_argv(actor, home, config):
            argv = original(actor, home, config)
            argv[argv.index("--network") + 1] = descriptor["network_id"]
            return argv
        module._native_argv = private_argv
        native = None
        try:
            native = module.Native("native", project,
                {"native_image": image, "runtime_manifest": str(PARENT / "native-runtime.json")})
            native.start()
            actual = executor._inspect(native.cid)
            assert len(actual["NetworkSettings"]["Networks"]) == 1
            assert next(iter(actual["NetworkSettings"]["Networks"].values()))["NetworkID"] == descriptor["network_id"]
            help_result = subprocess.run(["docker", "exec", native.cid, "/bench/bin/codescout",
                "index", "--help"], capture_output=True, timeout=30)
            (out / "index-help.stdout").write_bytes(help_result.stdout)
            (out / "index-help.stderr").write_bytes(help_result.stderr)
            assert help_result.returncode == 0
            rows = []
            for name, root in (("root", "/testbed"), ("arrow-buffer", "/testbed/arrow-buffer")):
                start = time.monotonic()
                result = subprocess.run(["docker", "exec", native.cid, "/bench/bin/codescout",
                    "index", "-p", root], capture_output=True, timeout=1800)
                (out / (name + ".stdout")).write_bytes(result.stdout)
                (out / (name + ".stderr")).write_bytes(result.stderr)
                row = {"id": name, "root": root, "exit_code": result.returncode, "wall_s": time.monotonic()-start}
                save(out / (name + "-result.json"), row)
                rows.append(row)
                assert result.returncode == 0
            save(out / "member-semantic.json", native.tool("semantic_search",
                {"query": "Rust Arrow immutable mutable buffers MutableBuffer",
                 "project_id": "arrow-buffer", "limit": 3}, timeout=240))
            save(out / "root-index-verification.json", native.tool("index", {"action": "verify"}, timeout=240))
            assert _public_digest(project) == prep["template_public_sha256"]
            save(out / "result.json", {"commands": rows, "source_unchanged": True,
                "additional_onboarding_calls": 0, "client_model_calls": 0,
                "scope": "Raw positive/negative member result captured; interpretation and other namespaces pending",
                "paid_ready": False})
            print(json.dumps({"completed": str(out), "paid_ready": False}), flush=True)
        except BaseException as exc:
            save(out / "failure.json", {"exception": type(exc).__name__, "message": str(exc), "paid_ready": False})
            raise
        finally:
            module._native_argv = original
            if native is not None:
                native.close()

if __name__ == "__main__":
    main()
