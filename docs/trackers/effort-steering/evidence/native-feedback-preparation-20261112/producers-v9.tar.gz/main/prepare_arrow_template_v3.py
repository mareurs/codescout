"""Versioned source-only member preparation; reuse one onboarding, align runtime embeddings."""
from pathlib import Path
import hashlib, importlib.util, json, shutil, subprocess, sys, tomllib
sys.dont_write_bytecode = True
sys.path.insert(0, "/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from receipts import input_digest
from native_executor import _public_digest
MAIN = Path("/home/marius/work/claude/codescout")
SCRIPTS = MAIN / ".superpowers/sdd/2026-11-11-native-public-feedback-transfer"
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/apache__arrow-rs-7783")
def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")
def main():
    prior = ROOT / "common-preparation-v1"
    before = input_digest(prior / "project")
    old = json.loads((prior / "preparation.json").read_bytes())
    public = ROOT / "public-data-materialization-v1/public-source"
    material = json.loads((public.parent / "registration.json").read_bytes())
    assert input_digest(public) == material["source_sha256"]
    out = ROOT / "common-preparation-v3"
    out.mkdir()
    context = out / "image-context"
    context.mkdir()
    source = context / "public-source"
    shutil.copytree(public, source, symlinks=True)
    workspace = tomllib.loads((prior / "project/.codescout/workspace.toml").read_text())
    overlays = []
    for entry in workspace["project"]:
        relative = Path(entry["root"]) / ".gitignore"
        path = source / relative
        assert path.parent.is_dir() and not path.is_symlink()
        original = path.read_bytes() if path.exists() else None
        line = b".codescout/private-memories/"
        content = original or b""
        if line not in content.splitlines():
            content += (b"\n" if content and not content.endswith(b"\n") else b"") + line + b"\n"
            path.write_bytes(content)
            overlays.append({"path": relative.as_posix(), "before_sha256": hashlib.sha256(original).hexdigest() if original is not None else None,
                             "after_sha256": hashlib.sha256(content).hexdigest()})
    source_sha = input_digest(source)
    project = out / "project"
    shutil.copytree(prior / "project", project, symlinks=True)
    for item in source.rglob("*"):
        relative = item.relative_to(source)
        dest = project / relative
        if item.is_symlink():
            if dest.exists() or dest.is_symlink(): dest.unlink()
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.symlink_to(item.readlink())
        elif item.is_file():
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item, dest)
    assert _public_digest(project) == source_sha
    (project / ".git/info/attributes").write_text("* -text -ident -filter\n")
    spec = importlib.util.spec_from_file_location("source_seed_v3", SCRIPTS / "prepare_arrow_context.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.seed(project)
    assert _public_digest(project) == source_sha
    image = json.loads((SCRIPTS / "arrow-gitlink-image.json").read_bytes())[0]["Id"]
    runtime = json.loads((prior / "native-runtime.json").read_bytes())
    runtime["Image"] = image
    keys = {"CODESCOUT_EMBED_MODEL", "CODESCOUT_EMBED_URL"}
    runtime["Config"]["Env"] = [value for value in runtime["Config"]["Env"] if value.split("=")[0] not in keys] + [
        "CODESCOUT_EMBED_MODEL=CodeRankEmbed", "CODESCOUT_EMBED_URL=http://source-embeddings:8000/v1"]
    save(out / "native-runtime-index.json", runtime)
    (context / "Dockerfile").write_text("FROM " + image + "\nUSER root\nCOPY --chown=1000:1000 public-source/ /testbed/\n")
    save(out / "registration.json", {"source": str(source), "public_source_digest": source_sha, "index_image": image,
        "configured_projects": workspace["project"], "declared_public_ignore_overlays": overlays,
        "previous_template_sha256": before, "producer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "onboarding_reused": True, "additional_onboarding_calls": 0, "client_model_calls": 0, "paid_ready": False})
    save(out / "preparation.json", {**old, "public_baseline_sha256": source_sha, "template_public_sha256": source_sha,
        "reused_prior_root_index": True, "additional_onboarding_calls": 0, "scope": "Runtime alignment requires actual corrected member canary; no all-member readiness inferred."})
    assert input_digest(prior / "project") == before
    print(json.dumps({"prepared": str(out), "overlays": len(overlays), "source_sha256": source_sha, "paid_ready": False}))
if __name__ == "__main__":
    main()
