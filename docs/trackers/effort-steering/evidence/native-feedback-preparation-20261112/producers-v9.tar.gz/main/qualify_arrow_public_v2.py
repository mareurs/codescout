"""Same public checks after the registered source-only locked dependency fetch."""
import hashlib
import json
import pathlib
import sys
sys.path.insert(0, "/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from receipts import input_digest
from executor import execute_observation
from campaign_resources import measure_host

ROOT = pathlib.Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/apache__arrow-rs-7783")
WORK = pathlib.Path("/home/marius/.codex/worktrees/2aa6/codescout")
def save(path, data):
    with path.open("x") as stream:
        json.dump(data, stream, sort_keys=True, indent=2)
        stream.write("\n")

def main():
    prep = json.loads((ROOT / "lock-preparation-v1/result.json").read_bytes())
    source = ROOT / "lock-preparation-v1/source"
    assert input_digest(source) == prep["prepared_digest"]
    image = json.loads((ROOT / "dependency-image.json").read_bytes())[0]["Id"]
    out = ROOT / "baseline-public-v2"
    out.mkdir()
    host = measure_host(WORK, "/tmp")
    save(out / "host-before.json", host)
    assert host["root_free"] >= 80 * 1024**3 and host["mem_available"] >= 16 * 1024**3
    assert host["tmp_free"] >= 4 * 1024**3 and host["tmp_exec"]
    bindings = {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted((WORK / "tools/effort_protocol").glob("*.py"))}
    save(out / "source-bindings.json", bindings)
    save(out / "dependency-provenance.json", {"image": image, "source_digest": input_digest(source),
        "files": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
            for name in ("dependency-image.json", "Dependencies.Dockerfile", "dependency-build.log")},
        "source_only": True, "private_input": False, "provider_calls": 0})
    rows = []
    for name, argv in (("ordinary", ["cargo", "check", "--offline", "--workspace"]),
            ("broader", ["cargo", "check", "--offline", "--workspace", "--all-targets"])):
        request = {"id": "public-" + name, "run_id": "native-feedback-arrow-base-v2-" + name,
            "phase": "challenge", "kind": "verification", "image": image, "argv": argv,
            "cwd": ".", "test_files": ["Cargo.toml"],
            "production_files": sorted(p.relative_to(source).as_posix() for p in source.rglob("*")),
            "timeout_s": 900, "max_log_bytes": 67108864, "execution_profile": "cargo-v2"}
        directory = out / name
        directory.mkdir()
        save(directory / "registration.json", {"request": request, "source": str(source),
            "source_digest": input_digest(source), "source_bindings": bindings,
            "scope": "Public baseline compile only; source-only lock/dependency preparation",
            "producer_sha256": hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(), "paid_ready": False})
        print(json.dumps({"starting": name, "image": image}), flush=True)
        try:
            facts = execute_observation(request, source, directory / "commands")
            row = {"name": name, "complete": facts["complete"], "resource_valid": facts["resource_valid"],
                "exit_code": facts["exit_code"], "receipt": facts, "paid_ready": False}
        except BaseException as exc:
            row = {"name": name, "complete": False, "reason": type(exc).__name__ + ": " + str(exc), "paid_ready": False}
        save(directory / "result.json", row)
        rows.append(row)
        print(json.dumps({k: v for k, v in row.items() if k != "receipt"}), flush=True)
        if not (row.get("complete") and row.get("resource_valid") and row.get("exit_code") == 0):
            save(out / "stopped.json", {"rows": rows, "paid_ready": False})
            return
    assert input_digest(source) == prep["prepared_digest"]
    save(out / "result.json", {"rows": rows, "source_unchanged": True, "provider_calls": 0, "paid_ready": False})

if __name__ == "__main__":
    main()
