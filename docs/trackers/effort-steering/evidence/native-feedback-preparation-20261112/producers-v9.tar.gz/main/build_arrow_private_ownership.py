"""Image-scoped grader ownership preparation, with no host/global Git configuration."""
from pathlib import Path
import hashlib, json, subprocess
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/apache__arrow-rs-7783/common-preparation-v3")
PARENT_TAG = "effort-feedback-base:arrow-rs-7783-common-v3-20261112"
EXPECTED = "sha256:a3816ccc24e238a0c04c9c6617c119692ea10c435345c4c0fcf7425b4e9fe5ff"
TAG = "effort-feedback-base:arrow-rs-7783-private-owner-v4-20261112"
def inspect(tag):
    return json.loads(subprocess.check_output(["docker", "image", "inspect", tag]))[0]
def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")
def main():
    out = ROOT / "image-root-ownership-v1"
    out.mkdir()
    before = inspect(PARENT_TAG)
    assert before["Id"] == EXPECTED
    save(out / "parent-before.json", before)
    context = out / "context"
    context.mkdir()
    recipe = context / "Dockerfile"
    recipe.write_text("FROM " + PARENT_TAG + "\nUSER root\nRUN chown -R 0:0 /testbed && git -C /testbed rev-parse HEAD && test \"$(stat -c %u /testbed)\" = 0 && test \"$(stat -c %u /testbed/.git)\" = 0\n")
    save(out / "registration.json", {"parent_image": EXPECTED, "parent_tag": PARENT_TAG,
        "recipe_sha256": hashlib.sha256(recipe.read_bytes()).hexdigest(),
        "producer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "scope": "Private image /testbed ownership only; actor/public source bind mounts and bytes unchanged. No safe.directory/global config change.",
        "paid_ready": False})
    result = subprocess.run(["docker", "build", "--pull=false", "--network", "none", "-t", TAG, str(context)],
        capture_output=True, timeout=1800)
    (out / "stdout.log").write_bytes(result.stdout)
    (out / "stderr.log").write_bytes(result.stderr)
    save(out / "command.json", {"returncode": result.returncode})
    assert result.returncode == 0
    after = inspect(PARENT_TAG)
    save(out / "parent-after.json", after)
    assert after["Id"] == EXPECTED
    image = inspect(TAG)
    save(out / "image.json", image)
    layers = before["RootFS"]["Layers"]
    assert image["RootFS"]["Layers"][:len(layers)] == layers
    runtime = json.loads((ROOT / "native-runtime.json").read_bytes())
    runtime["Image"] = image["Id"]
    save(ROOT / "native-runtime-private-v4.json", runtime)
    save(out / "result.json", {"image": image["Id"], "tag": TAG, "parent_image": EXPECTED,
        "parent_layers_unchanged": True, "private_git_head_probe": True, "paid_ready": False})
    print(json.dumps({"image": image["Id"], "paid_ready": False}))
if __name__ == "__main__":
    main()
