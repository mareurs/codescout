FROM effort-feedback-deps:arrow-rs-7783-readable-20261112
USER root
ENV CARGO_BUILD_JOBS=4
COPY Cargo.lock /testbed/Cargo.lock
RUN set -eux \
 && export CARGO_NET_OFFLINE=true \
 && cd /testbed \
 && git reset --hard -q 91199c7190f1c5b931f1d0b6bcc6ccdd86a4c5c0 \
 && git clean -ffdx -e target -e Cargo.lock -e .venv -e generated-do-not-edit \
 && TREE=$(git rev-parse HEAD^{tree}) \
 && git ls-files -z > /tmp/sab-tracked.lst \
 && PK=$(cargo metadata --no-deps --offline --format-version 1 | grep -o '"name":"[^"]*","version":"' | sed 's/"name":"\([^"]*\)".*/\1/' | sort -u) \
 && [ -n "$PK" ] \
 && ARGS=$(for p in $PK; do printf ' -p %s' "$p"; done) \
 && cargo clean --offline $ARGS \
 && cargo clean --offline --release $ARGS \
 && rm -rf target/*/incremental \
 && for d in target/*/deps; do [ -d "$d" ] || continue; for f in "$d"/*.d; do [ -e "$f" ] || continue; sed -n '1s/^[^ ]*: //p' "$f" | tr ' ' '\n' | grep -qE '^([^/]|/testbed/)' || continue; s=$(basename "$f" .d); rm -rf "$d/$s" "$d/$s".*; rm -rf "$(dirname "$d")"/.fingerprint/*-"${s##*-}"; done; done \
 && ( cargo build --workspace --exclude arrow-pyarrow ) \
 && rm -rf /testbed/reports \
 && for p in /tmp/testdir; do [ -e "$p" ] && echo "Removing-debris $p"; rm -rf "$p"; done && for e in /tmp/* /tmp/.[!.]* /tmp/..?*; do [ -e "$e" ] || [ -L "$e" ] || continue; if [ -n "$(find "$e" \( \( -type d ! -perm -o=rx \) -o \( ! -type d ! -type l ! -perm -o=r \) \) -print -quit)" ]; then echo "Removing-debris $e"; rm -rf "$e"; fi; done \
 && rm -rf /testbed/.git \
 && git init -q \
 && git config user.email diagnostic@example.invalid \
 && git config user.name Diagnostic \
 && git config core.autocrlf false \
 && git config core.safecrlf false \
 && mkdir -p .git/info \
 && printf '/target\n' >> .git/info/exclude \
 && printf '* -text -ident -filter\n' > .git/info/attributes \
 && git add -f --pathspec-from-file=/tmp/sab-tracked.lst --pathspec-file-nul \
 && git add . \
 && git commit -qm 'Benchmark base source' \
 && test "$(git rev-parse HEAD^{tree})" = "$TREE" \
 && rm -f /tmp/sab-tracked.lst \
 && (getent group 1000 >/dev/null || groupadd --gid 1000 agent) \
 && (id -u 1000 >/dev/null 2>&1 || useradd --uid 1000 --gid 1000 --create-home --shell /bin/bash agent) \
 && mkdir -p /home/agent \
 && chown -R 1000:1000 /testbed /home/agent "${CARGO_HOME:-/usr/local/cargo}"
ENV HOME=/home/agent CARGO_NET_OFFLINE=true
USER 1000:1000
WORKDIR /testbed
RUN test -z "$(git status --porcelain)" && test "$(git rev-parse --git-dir)" = .git && test "$(git rev-list --count HEAD)" = 1 && test "$(git log -1 --format=%s)" = "Benchmark base source" && test ! -e /testbed/reports && test ! -e /testbed/reports

USER root
COPY CLAUDE.md /testbed/CLAUDE.md
COPY .gitignore /testbed/.gitignore
RUN chown 1000:1000 /testbed/CLAUDE.md /testbed/.gitignore /testbed/Cargo.lock
USER 1000:1000
