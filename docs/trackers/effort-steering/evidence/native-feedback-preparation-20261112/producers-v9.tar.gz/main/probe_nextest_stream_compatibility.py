"""Actual formatter calibration on an unrelated fixture, never exposed to repair actors."""
from pathlib import Path
import argparse, hashlib, json, subprocess, sys, uuid
sys.dont_write_bytecode = True
sys.path.insert(0, "/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from evaluator_entry import verify_package
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
OWNER = "codex:01a15ca9-f939-7603-acb5-01c6b02f68e2"
def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--task-id", required=True)
    args = parser.parse_args()
    task = ROOT / args.task_id
    image = json.loads((task / "common-preparation-v1/registration.json").read_bytes())["image"]
    out = task / "nextest-format-compatibility-v1"
    out.mkdir()
    fixture, build = out / "fixture", out / "build"
    (fixture / "src").mkdir(parents=True)
    (fixture / ".config").mkdir()
    build.mkdir()
    (fixture / "Cargo.toml").write_text('[package]\nname="stream_contract_fixture"\nversion="0.1.0"\nedition="2021"\n')
    (fixture / "Cargo.lock").write_text('version = 4\n\n[[package]]\nname = "stream_contract_fixture"\nversion = "0.1.0"\n')
    (fixture / ".config/nextest.toml").write_text('[profile.default.junit]\npath = "junit.xml"\n')
    (fixture / "src/lib.rs").write_text("""#[cfg(test)]
mod tests {
    #[test]
    fn noisy_pass() {
        println!("fixture-pass-output");
        eprintln!("open /tmp/fixture.txt: Permission denied");
    }
    #[test]
    fn noisy_failure() {
        println!("fixture-failure-output");
        eprintln!("error: No space left on device (os error 28)");
        eprintln!("error[E0308]: mismatched types");
        panic!("deliberate formatter fixture");
    }
}
""")
    inputs = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in fixture.rglob("*") if path.is_file()}
    command = ["docker", "create", "--pull=never", "--name", "ep-nextest-format-" + uuid.uuid4().hex,
        "--label", "effort-feedback-owner=" + OWNER, "--network", "none", "--read-only", "--user", "1000:1000",
        "--memory", "2g", "--memory-swap", "2g", "--cpus", "2", "--pids-limit", "128", "--init",
        "--cap-drop", "ALL", "--security-opt", "no-new-privileges", "--tmpfs", "/tmp:rw,exec,size=1g,uid=1000,gid=1000",
        "--mount", "type=bind,src=" + str(fixture) + ",dst=/fixture",
        "--mount", "type=bind,src=" + str(build) + ",dst=/build", "--workdir", "/fixture",
        "-e", "CARGO_TARGET_DIR=/build/target", "-e", "CARGO_NET_OFFLINE=true",
        "-e", "NEXTEST_EXPERIMENTAL_LIBTEST_JSON=1", "-e", "TERM=xterm-256color",
        "--entrypoint", "cargo", image, "+stable", "nextest", "run", "--status-level", "all",
        "--no-fail-fast", "--success-output", "immediate", "--failure-output", "immediate",
        "--message-format", "libtest-json-plus"]
    save(out / "registration.json", {"image": image, "argv": command, "inputs": inputs,
        "producer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), "client_model_calls": 0,
        "scope": "Independent formatter provenance fixture, not task acceptance/runtime admission", "paid_ready": False})
    cid = subprocess.check_output(command, text=True).strip()
    def owned():
        row = json.loads(subprocess.check_output(["docker", "inspect", cid]))[0]
        assert row["Id"] == cid and row["Image"] == image and row["Config"]["Labels"]["effort-feedback-owner"] == OWNER
        assert row["HostConfig"]["NetworkMode"] == "none" and row["HostConfig"]["ReadonlyRootfs"]
        assert all(m["Type"] in ("bind", "tmpfs") for m in row["Mounts"])
        return row
    try:
        save(out / "container-before.json", owned())
        with (out / "stdout").open("xb") as stdout, (out / "stderr").open("xb") as stderr:
            result = subprocess.run(["docker", "start", "-a", cid], stdout=stdout, stderr=stderr, timeout=180)
        after = owned()
        save(out / "container-after.json", after)
        assert result.returncode == after["State"]["ExitCode"] == 100 and not after["State"]["OOMKilled"]
        assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest for path, digest in inputs.items())
        config = json.loads(Path("/var/tmp/ep11-01a15/private-controls/obscura/config.json").read_bytes())
        package = verify_package(config["package_root"], config["package_files"])
        sys.path.insert(0, str(package))
        import stream_evidence as streams
        report = (out / "stdout").read_text()
        stderr = (out / "stderr").read_bytes()
        filtered = streams.nextest_diagnostics(stderr, report)
        assert "fixture-pass-output" not in filtered and "fixture-failure-output" not in filtered
        assert "Permission denied" not in filtered and "No space left on device" not in filtered
        host = b"\nerror: No space left on device (os error 28)\n"
        assert "error: No space left on device (os error 28)" in streams.nextest_diagnostics(stderr + host, report)
        events = [json.loads(line) for line in report.splitlines() if line.strip()]
        cases = [event for event in events if event.get("type") == "test" and event.get("event") in ("ok", "failed")]
        assert sorted(event["event"] for event in cases) == ["failed", "ok"]
        verify_package(package, config["package_files"])
        save(out / "result.json", {"fixture_cases": 2, "passing_cases": 1, "failing_cases": 1,
            "bound_diagnostic_like_payloads_removed": True, "true_host_diagnostic_retained": True,
            "frozen_package_unchanged": True, "json_case_names": [event["name"] for event in cases],
            "junit_paths": [str(path) for base in (fixture, build) for path in base.rglob("junit.xml")],
            "client_model_calls": 0, "paid_ready": False, "scope": "Actual 0.9.133 format compatibility only"})
        print(json.dumps({"format_compatibility": True, "paid_ready": False}), flush=True)
    except BaseException as exc:
        save(out / "failure.json", {"exception": type(exc).__name__, "message": str(exc), "paid_ready": False})
        raise
    finally:
        row = owned()
        if row["State"]["Running"]: subprocess.run(["docker", "stop", "-t", "3", cid], check=True, capture_output=True)
        subprocess.run(["docker", "rm", "--volumes", cid], check=True, capture_output=True)
        absence = subprocess.run(["docker", "ps", "-a", "--quiet", "--filter", "id=" + cid], capture_output=True, text=True)
        save(out / "cleanup.json", {"complete": absence.returncode == 0 and not absence.stdout.strip(), "container": cid})
if __name__ == "__main__":
    main()
