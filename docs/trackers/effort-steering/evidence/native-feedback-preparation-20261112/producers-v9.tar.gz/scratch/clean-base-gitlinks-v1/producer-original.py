"""Extend the frozen generic image recipe with source-index Gitlink preservation."""
from pathlib import Path
import hashlib
import importlib
import json
import shutil
import subprocess
import sys
sys.path.insert(0, "/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from evaluator_entry import verify_package
from receipts import input_digest

MAIN = Path("/home/marius/work/claude/codescout")
WORK = Path("/home/marius/.codex/worktrees/2aa6/codescout")
SCRIPTS = MAIN / ".superpowers/sdd/2026-11-11-native-public-feedback-transfer"
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/apache__arrow-rs-7783")
PACKAGE = Path("/var/tmp/ep11-01a15/private-package/evaluator/source/tools/setup-ab-eval")

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")

def main():
    old = json.loads(Path("/var/tmp/ep11-01a15/private-controls/obscura/config.json").read_bytes())
    verify_package(PACKAGE, old["package_files"])
    sys.path.insert(0, str(PACKAGE))
    tasks = importlib.import_module("multilang_tasks")
    assert Path(tasks.__file__).resolve().is_relative_to(PACKAGE)
    record = json.loads((ROOT / "private-preparation-v1/full-record.json").read_bytes())
    image = json.loads(subprocess.check_output(["docker", "image", "inspect",
        "effort-feedback-deps:arrow-rs-7783-readable-20261112"]))[0]
    assert image["Id"] == "sha256:7f47d367554a441e75ddea046e2f73ff9ace6a8feaf558524fe4ab1c2273b05a"
    out = ROOT / "clean-base-gitlinks-v1"
    out.mkdir()
    context = out / "context"
    context.mkdir()
    public = ROOT / "common-preparation-v1/public-source"
    shutil.copytree(public, context / "source", symlinks=True)
    (context / "control").mkdir()
    module = WORK / "tools/effort_protocol/feedback_gitlinks.py"
    shutil.copy2(module, context / "control/feedback_gitlinks.py")
    assert input_digest(public) == input_digest(context / "source")
    recipe = tasks.live_dockerfile("effort-feedback-deps:arrow-rs-7783-readable-20261112", record, "/testbed")
    prefix = "FROM effort-feedback-deps:arrow-rs-7783-readable-20261112\nUSER root\n"
    assert recipe.startswith(prefix)
    recipe = prefix + "ENV CARGO_BUILD_JOBS=4\nCOPY source/Cargo.lock /testbed/Cargo.lock\n" +         "COPY control/feedback_gitlinks.py /ep-control/feedback_gitlinks.py\n" + recipe[len(prefix):]
    capture_anchor = " && TREE=$(git rev-parse HEAD^{tree})"
    assert recipe.count(capture_anchor) == 1
    recipe = recipe.replace(capture_anchor, capture_anchor +
        " \\\n && python3 -I -B /ep-control/feedback_gitlinks.py capture /testbed /tmp/ep-gitlinks.json", 1)
    commit_anchor = " && git commit -qm 'Benchmark base source'"
    assert recipe.count(commit_anchor) == 1
    recipe = recipe.replace(commit_anchor,
        " && python3 -I -B /ep-control/feedback_gitlinks.py restore /testbed /tmp/ep-gitlinks.json \\\n" + commit_anchor, 1)
    recipe += "\nUSER root\nCOPY source/CLAUDE.md /testbed/CLAUDE.md\nCOPY source/.gitignore /testbed/.gitignore\n"
    recipe += "RUN chown 1000:1000 /testbed/CLAUDE.md /testbed/.gitignore /testbed/Cargo.lock\nUSER 1000:1000\n"
    path = SCRIPTS / "ArrowGitlinkBase.Dockerfile"
    with path.open("x") as stream:
        stream.write(recipe)
    save(out / "registration.json", {"source_image": image["Id"], "public_source": str(public),
        "public_source_sha256": input_digest(public), "context_sha256": input_digest(context),
        "module_sha256": sha(module), "recipe_sha256": sha(path),
        "frozen_package_files": old["package_files"], "producer_sha256": sha(Path(__file__)),
        "patches_to_frozen_private_package": 0, "private_gold_or_test_patch_in_context": False,
        "client_model_calls": 0, "paid_ready": False,
        "scope": "Exact reused clean recipe plus generic Gitlink capture/restore; source/data/private acceptance qualification pending."})
    print(json.dumps({"dockerfile": str(path), "context": str(context), "paid_ready": False}), flush=True)

if __name__ == "__main__":
    main()
