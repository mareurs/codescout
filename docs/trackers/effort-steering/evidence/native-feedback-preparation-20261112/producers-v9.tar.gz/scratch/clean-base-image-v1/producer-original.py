"""Reuse the frozen generic clean-base image recipe before private controls."""
from pathlib import Path
import hashlib
import importlib
import json
import sys
import subprocess
sys.path.insert(0, "/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from evaluator_entry import verify_package

MAIN = Path("/home/marius/work/claude/codescout")
SCRIPTS = MAIN / ".superpowers/sdd/2026-11-11-native-public-feedback-transfer"
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/apache__arrow-rs-7783")
PACKAGE = Path("/var/tmp/ep11-01a15/private-package/evaluator/source/tools/setup-ab-eval")

def main():
    old = json.loads(Path("/var/tmp/ep11-01a15/private-controls/obscura/config.json").read_bytes())
    verify_package(PACKAGE, old["package_files"])
    sys.path.insert(0, str(PACKAGE))
    tasks = importlib.import_module("multilang_tasks")
    assert Path(tasks.__file__).resolve().is_relative_to(PACKAGE)
    record = json.loads((ROOT / "private-preparation-v1/full-record.json").read_bytes())
    before = json.loads(subprocess.check_output(["docker", "image", "inspect",
        "effort-feedback-deps:arrow-rs-7783-readable-20261112"]))[0]
    assert before["Id"] == "sha256:7f47d367554a441e75ddea046e2f73ff9ace6a8feaf558524fe4ab1c2273b05a"
    recipe = tasks.live_dockerfile("effort-feedback-deps:arrow-rs-7783-readable-20261112",
        record, "/testbed")
    # The lock is a public derived preparation input; reset_sh deliberately retains ignored Cargo.lock.
    prefix = "FROM effort-feedback-deps:arrow-rs-7783-readable-20261112\nUSER root\n"
    assert recipe.startswith(prefix)
    recipe = prefix + "COPY Cargo.lock /testbed/Cargo.lock\n" + recipe[len(prefix):]
    recipe += "\nUSER root\nCOPY CLAUDE.md /testbed/CLAUDE.md\nCOPY .gitignore /testbed/.gitignore\n"
    recipe += "RUN chown 1000:1000 /testbed/CLAUDE.md /testbed/.gitignore /testbed/Cargo.lock\nUSER 1000:1000\n"
    path = SCRIPTS / "ArrowCleanBase.Dockerfile"
    with path.open("x") as stream:
        stream.write(recipe)
    out = ROOT / "clean-base-image-v1"
    out.mkdir()
    with (out / "registration.json").open("x") as stream:
        json.dump({"source_image": before["Id"], "source_only_context": str(ROOT / "common-preparation-v1/public-source"),
            "workspace_recipe": str(PACKAGE / "multilang_tasks.py"),
            "recipe_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "package_files": old["package_files"], "base_commit": record["base_commit"],
            "producer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "private_patch_or_record_in_build_context": False, "client_model_calls": 0, "paid_ready": False,
            "scope": "Generic reset/debris/workspace artifact rebuild; add only common public lock/instruction inputs"}, stream, indent=2)
    print(json.dumps({"dockerfile": str(path), "paid_ready": False}), flush=True)

if __name__ == "__main__":
    main()
