"""Actual zero-provider pending-to-final control with measured process and evidence seams."""
import argparse
import copy
import hashlib
import importlib.util
import json
import os
import time
from pathlib import Path
import sys
from unittest.mock import patch

WORK = Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path[:0] = [str(WORK / "tools" / name) for name in
                ("effort_protocol", "agent_lifecycle", "hint_authority_pilot")]
import feedback_runner as runner
from native_campaign import NativeCampaignBackend
from resume_qualification_instruments_v5 import ProcessObservation, frozen_inputs
path = Path(__file__).with_name("qualify_native_feedback_campaign_v1.py")
spec = importlib.util.spec_from_file_location("resume_qualification_transport_v1", path)
transport = importlib.util.module_from_spec(spec)
spec.loader.exec_module(transport)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(path, value):
    with Path(path).open("x") as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + "\n")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("registration", type=Path)
    args = parser.parse_args()
    assert Path(__file__).stat().st_mode & 0o222 == 0
    reg = json.loads(args.registration.read_bytes())
    assert reg["mode"] == "scripted" and len(reg["schedule"]) == 16
    assert reg["qualification_driver"] == {"path": str(Path(__file__).resolve()), "sha256": sha(__file__)}
    assert all(sha(path) == digest for path, digest in reg["bindings"].items())
    floors = {task["backend"]["public"]["resource_floors"]["root_free"] for task in reg["tasks"].values()}
    roots = {task["backend"]["public"]["resource_root"] for task in reg["tasks"].values()}
    assert floors == {80 * 1024**3} and len(roots) == 1
    info = os.statvfs(next(iter(roots)))
    available = info.f_bavail * info.f_frsize
    minimum = next(iter(floors)) + 12 * 1024**3
    capacity = {"available_bytes": available, "minimum_launch_bytes": minimum,
                "launch_admitted": available >= minimum, "paid_ready": False, "stage": "not_dispatched"}
    save(args.registration.parent / ("capacity-" + str(time.time_ns()) + ".json"), capacity)
    if available < minimum:
        print(json.dumps(capacity), flush=True)
        raise SystemExit(2)
    backend = NativeCampaignBackend(mode="scripted")
    checked = runner.preflight(reg, backend)
    save(args.registration.parent / "preflight.json", checked)
    assert checked["ready"] and checked["paid_ready"] is False
    private_entries = {task["backend"]["private"]["entry"] for task in reg["tasks"].values()}
    cli_paths = {task["backend"]["public"]["runtime"]["files"]["cli"]["path"] for task in reg["tasks"].values()}
    observer = ProcessObservation(private_entries, cli_paths)
    def observed(kind, phase):
        return [row for row in observer.rows() if row["kind"] == kind and row["phase"] == phase]
    original_audit = backend.audit
    audit_calls = []
    def delayed_last(request, out):
        proof = original_audit(request, out)
        audit_calls.append(proof["opaque_id"])
        if len(audit_calls) == 16:
            proof = copy.deepcopy(proof)
            proof.update(terminal=False, status="unresolved",
                         method="qualification-controller-deferred",
                         reason="Registered zero-provider resume control; real audit descriptor is retained.")
        return proof
    print(json.dumps({"starting": True, "scope": "actual scripted16CLI then actor-free resume",
                      "provider_forwarding": "forbidden", "paid_ready": False}), flush=True)
    with observer, patch.object(transport.external.transport.Proxy, "upstream", transport.no_upstream), \
         patch.object(transport.external.transport.Proxy, "scripted", transport.scripted_turns), \
         patch.object(backend, "audit", side_effect=delayed_last):
        initial = runner.run_campaign(reg, backend)
    root = Path(reg["output_root"])
    save(args.registration.parent / "initial-summary.json",
         {"status": initial["status"], "attempts": len(initial["attempts"]),
          "audit_calls": len(audit_calls), "paid_ready": False})
    assert initial["status"] == "audit_pending" and initial["actor_status"] == "completed"
    assert len(initial["attempts"]) == len(audit_calls) == 16 and initial["closure"]["complete"]
    assert initial["integrity_audit"]["unresolved"] == [15] and not (root / "grades").exists()
    for row in initial["attempts"]:
        assert row["grade"] is None and row["workflow_state"] == "closed" and not row["measurement_invalid"]
        assert row["cost"] == {"known_usd": "0", "unknown": False}
        record = row["invocations"][0]["record"]
        assert record["lifecycle"]["turns"] == 5 and record["lifecycle"]["continuations"] == 4
        receipt = json.loads((Path(record["native_path"]) / "receipt.json").read_bytes())
        assert receipt["forwarded"] == 0 and receipt["scripted"] is True
    assert observed("private", "initial") == []
    initial_cli = observed("cli", "initial")
    receipt_pids = {row["invocations"][0]["record"]["lifecycle"]["client_pid"] for row in initial["attempts"]}
    assert len(initial_cli) == len(receipt_pids) == 16
    assert {row["pid"] for row in initial_cli} == receipt_pids
    assert all(row["returncode"] == 0 for row in initial_cli)
    before = frozen_inputs(root, initial)
    save(args.registration.parent / "frozen-before-resume.json", before)
    resumed_backend = NativeCampaignBackend(mode="scripted")
    assert resumed_backend.registration is None and getattr(resumed_backend, "authorization", None) is None
    blocked = {key: 0 for key in ("invoke", "verify", "launch", "reserve", "upstream")}
    def forbidden(name):
        def guard(*args, **kwargs):
            blocked[name] += 1
            raise AssertionError("actor-free resume attempted " + name)
        return guard
    observer.phase = "resume"
    with observer, patch.object(resumed_backend, "invoke", side_effect=forbidden("invoke")), \
         patch.object(resumed_backend, "verify", side_effect=forbidden("verify")), \
         patch.object(transport.external, "launch", side_effect=forbidden("launch")), \
         patch.object(runner, "_reserve", side_effect=forbidden("reserve")), \
         patch.object(transport.external.transport.Proxy, "upstream", forbidden("upstream")):
        final = runner.resume_grading(reg, resumed_backend)
        assert final["status"] == "completed" and final["paid_ready"] is False
        assert resumed_backend.closed_only is True and resumed_backend.authorization is None
        private_processes = observed("private", "resume")
        assert len(private_processes) == 16 and all(row["returncode"] == 0 for row in private_processes)
        assert len({row["pid"] for row in private_processes}) == 16
        assert observed("cli", "resume") == []
        try:
            runner.resume_grading(reg, resumed_backend)
        except ValueError as exc:
            assert "already started or completed" in str(exc)
        else:
            raise AssertionError("duplicate resume was accepted")
    assert all(count == 0 for count in blocked.values()) and len(observed("private", "resume")) == 16
    assert observed("cli", "resume") == [] and observed("private", "initial") == []
    assert frozen_inputs(root, initial) == before
    assert final["resumed_from"] == {"path": str(root / "result.json"), "sha256": before["entries"][str(root / "result.json")]["sha256"]}
    assert [row["candidate"] for row in final["attempts"]] == [row["candidate"] for row in initial["attempts"]]
    assert all(row["grade"]["valid"] is True and row["grade"]["pass"] is False for row in final["attempts"])
    analysis = runner.analyze(reg, str(root))
    assert analysis["interpretable"] is True and analysis["decision"] == "NO-GO"
    save(root / "runtime-resume-qualification.json", {
        "scope": "Actual scripted16CLI closed batch, deliberately deferred final audit, fresh native rehydration and original evaluator execution.",
        "observed_initial_cli": initial_cli, "private_processes_before_resume": len(observed("private", "initial")),
        "observed_private_processes_after_resume": private_processes, "forbidden_resume_calls": blocked,
        "frozen_evidence_entries": before["entries"], "captured_candidates": before["captured_candidates"],
        "frozen_before_sha256": sha(args.registration.parent / "frozen-before-resume.json"),
        "result_final_sha256": sha(root / "result-final.json"),
        "final_index_sha256": sha(root / "integrity-audits-final.json"),
        "client_model_cost_usd": "0", "compute_cost": "unknown", "paid_ready": False,
        "efficacy_claim": None})
    print(json.dumps({"completed": True, "observed_initial_cli": len(initial_cli), "forbidden_resume_calls": blocked,
                      "private_processes_after_resume": len(observed("private", "resume")), "paid_ready": False}), flush=True)

if __name__ == "__main__":
    main()
