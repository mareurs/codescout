"""Bind actual pending-resume control only after the fresh normal16 batch closes."""
import copy
import hashlib
import json
from pathlib import Path
BASE = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
PREVIOUS = BASE / "native-feedback-qualification-v4-registration"
OUT = BASE / "native-feedback-resume-v5-registration"
RUN = Path("/var/tmp/native-feedback-resume-v5-01a15")

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(path):
    return json.loads(Path(path).read_bytes())

def save(path, value):
    with Path(path).open("x") as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + "\n")

def main():
    assert Path(__file__).stat().st_mode & 0o222 == 0
    assert not OUT.exists() and not RUN.exists()
    terminal = read(PREVIOUS / "terminal-summary.json")
    assert terminal["status"] == "completed" and terminal["attempts"] == 16
    reg = copy.deepcopy(read(PREVIOUS / "final-registration.json"))
    normal = Path(reg["output_root"])
    proof = read(normal / "runtime-qualification.json")
    assert proof["all_workflows_closed"] is True and proof["native_invocations"] == 16
    assert proof["provider_forwarded"] == 0
    calibration_path = BASE / "resume-observer-cli-v5-calibration.json"
    calibration = read(calibration_path)
    assert calibration["stdout"] == "2.1.309 (Claude Code)\n"
    assert len(calibration["observed"]) == 1 and calibration["observed"][0]["returncode"] == 0
    assert type(calibration["observed"][0]["pid"]) is int and calibration["observed"][0]["pid"] > 0
    for task in reg["tasks"].values():
        assert task["backend"]["public"]["runtime"]["files"]["cli"] == calibration["cli_binding"]
    reg.update(campaign_id="native-feedback-resume-v5-01a15", output_root=str(RUN))
    OUT.mkdir()
    scope = OUT / "scope.json"
    save(scope, {"scope": "Actual scripted16CLI closes with deliberately deferred final audit, then fresh actor-free native resume.",
                 "normal_qualification": str(normal), "observer_scope": "Registered parent Popen launch seams, not descendants",
                 "snapshot_scope": "Original registration/closure/ledgers/checkpoint and authoritative attempts/audits; full candidates separately",
                 "excluded_native_working_caches": ["actor", "native-home", "public-build-state"],
                 "compute_cost": "unknown", "paid_ready": False})
    reg["shared_preparation"] = {"cost_usd": "0", "receipt_sha256": sha(scope)}
    driver = Path(__file__).with_name("qualify_native_feedback_resume_v5.py").resolve()
    dependencies = [Path(__file__).resolve(), driver.with_name("qualify_native_feedback_campaign_v1.py"),
                    driver.with_name("resume_qualification_instruments_v5.py")]
    assert all(path.stat().st_mode & 0o222 == 0 for path in [driver, *dependencies])
    reg["qualification_driver"] = {"path": str(driver), "sha256": sha(driver)}
    reg["qualification_driver_dependencies"] = [{"path": str(path), "sha256": sha(path)} for path in dependencies]
    for path in [driver, *dependencies, scope, calibration_path, PREVIOUS / "terminal-summary.json",
                 PREVIOUS / "final-registration.json", normal / "runtime-qualification.json"]:
        reg["bindings"][str(path)] = sha(path)
    assert all(sha(path) == digest for path, digest in reg["bindings"].items())
    save(OUT / "final-registration.json", reg)
    print(json.dumps({"registration": str(OUT / "final-registration.json"), "paid_ready": False}))

if __name__ == "__main__":
    main()
