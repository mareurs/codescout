"""Real frozen CLI version-only calibration; no actor, MCP, private evaluator or provider."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
sys.path.insert(0, "/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from resume_qualification_instruments_v5 import ProcessObservation
REG = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/native-feedback-qualification-v3-registration/final-registration.json")
OUT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/resume-observer-cli-v5-calibration.json")
reg = json.loads(REG.read_bytes())
files = {task["backend"]["public"]["runtime"]["files"]["cli"]["path"]:
         task["backend"]["public"]["runtime"]["files"]["cli"] for task in reg["tasks"].values()}
assert len(files) == 1
cli, binding = next(iter(files.items()))
assert hashlib.sha256(Path(cli).read_bytes()).hexdigest() == binding["sha256"]
observer = ProcessObservation(set(), set(files))
with tempfile.TemporaryDirectory(prefix="ep-observer-") as directory:
    env = {"HOME": directory, "CLAUDE_CONFIG_DIR": directory, "PATH": "/usr/bin:/bin",
           "LANG": "C.UTF-8", "DISABLE_AUTOUPDATER": "1",
           "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC": "1",
           "ANTHROPIC_API_KEY": "no-real-credential", "ANTHROPIC_BASE_URL": "http://127.0.0.1:9"}
    with observer:
        process = subprocess.Popen([cli, "--version", "--session-id", "00000000-0000-4000-8000-000000000005"],
                                   env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = process.communicate(timeout=30)
    assert process.returncode == 0 and stdout.decode().startswith("2.1.309 ")
    rows = observer.rows()
    assert len(rows) == 1 and rows[0]["pid"] == process.pid and rows[0]["returncode"] == 0
    assert rows[0]["kind"] == "cli" and rows[0]["phase"] == "initial"
payload = {"scope": "Version-only frozen CLI at actual parent Popen seam; no actor efficacy or descendant inventory.",
           "registration_sha256": hashlib.sha256(REG.read_bytes()).hexdigest(),
           "cli_binding": binding, "observed": rows, "stdout": stdout.decode(), "stderr": stderr.decode(),
           "real_credentials_read_by_instrument": False, "paid_ready": False}
with OUT.open("x") as stream:
    stream.write(json.dumps(payload, indent=2, sort_keys=True) + "\n")
print(json.dumps(payload))
