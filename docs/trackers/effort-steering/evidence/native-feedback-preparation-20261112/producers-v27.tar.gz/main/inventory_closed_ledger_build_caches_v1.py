"""Read-only cache custody for an operator cleanup decision; never deletes anything."""
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
sys.path.insert(0, "/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from receipts import input_digest
ROOT = Path("/var/tmp/ep11-01a15/public-ledger-diagnosis-v1/commands")
OUT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/closed-ledger-cache-inventory-v1.json")

def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(1024 * 1024):
            digest.update(block)
    return digest.hexdigest()

def main():
    assert not OUT.exists()
    targets = [ROOT / name / "build/target" for name in ("baseline", "candidate")]
    retained = []
    inventories = {}
    for target in targets:
        assert target.is_dir() and not target.is_symlink() and target.resolve() == target
        run = target.parent.parent
        receipt = json.loads((run / "receipt.json").read_bytes())
        assert receipt["cleanup_complete"] is True and receipt["capture_complete"] is True
        assert receipt["resource_valid"] is True and receipt["exit_code"] == 0
        assert receipt["final_container_state"]["Running"] is False
        source = input_digest(run / "input")
        assert source == receipt["source_after"] == receipt["source_before"]
        assert sha(run / "stdout") == receipt["stdout_sha256"]
        assert sha(run / "stderr") == receipt["stderr_sha256"]
        retained.append({"run": str(run), "receipt_sha256": sha(run / "receipt.json"),
                         "source_digest": source, "stdout_sha256": sha(run / "stdout"),
                         "stderr_sha256": sha(run / "stderr"), "container_id": receipt["container_id"]})
        entries = {}
        for parent, directories, files in os.walk(target, followlinks=False):
            for path in [Path(parent), *[Path(parent) / name for name in directories + files]]:
                key = str(path.relative_to(target))
                if key in entries:
                    continue
                info = path.lstat()
                entry = {"mode": stat.S_IMODE(info.st_mode), "uid": info.st_uid}
                if stat.S_ISREG(info.st_mode):
                    entry.update(kind="file", bytes=info.st_size, sha256=sha(path))
                elif stat.S_ISDIR(info.st_mode):
                    entry.update(kind="directory")
                elif stat.S_ISLNK(info.st_mode):
                    entry.update(kind="symlink", target=os.readlink(path))
                else:
                    raise ValueError("unsupported cache artifact: " + str(path))
                entries[key] = entry
        inventories[str(target)] = entries
    referenced = []
    unreadable = []
    scanned = 0
    for proc in Path("/proc").iterdir():
        if not proc.name.isdigit():
            continue
        try:
            command = (proc / "cmdline").read_bytes()
            cwd = os.readlink(proc / "cwd")
            scanned += 1
            if any(str(target).encode() in command or cwd == str(target) or cwd.startswith(str(target) + "/")
                   for target in targets):
                referenced.append({"pid": int(proc.name), "kind": "cmdline-or-cwd"})
            for fd in (proc / "fd").iterdir():
                try:
                    destination = os.readlink(fd)
                    if any(destination == str(target) or destination.startswith(str(target) + "/") for target in targets):
                        referenced.append({"pid": int(proc.name), "kind": "fd", "destination": destination})
                except (FileNotFoundError, PermissionError):
                    continue
        except FileNotFoundError:
            continue
        except PermissionError:
            unreadable.append(int(proc.name))
    ids = subprocess.run(["docker", "ps", "-q"], capture_output=True, text=True, check=True).stdout.split()
    mounts = []
    if ids:
        running = json.loads(subprocess.run(["docker", "inspect", *ids], capture_output=True, text=True, check=True).stdout)
        for container in running:
            for mount in container.get("Mounts", []):
                source = mount.get("Source", "")
                if any(source == str(target) or source.startswith(str(target) + "/")
                       or str(target).startswith(source + "/") for target in targets if source):
                    mounts.append({"id": container["Id"], "source": source})
    result = {"scope": "Two closed diagnostic build targets only; full file SHA inventory, retained inputs/logs reopened.",
              "inventories": inventories, "retained": retained,
              "process_scan": {"scanned": scanned, "unreadable_pids": unreadable, "references": referenced},
              "running_container_mount_references": mounts, "deleted": False,
              "approval_received": False, "reclaimable_filesystem_bytes": None,
              "historical_build_tree_reverification_after_deletion": "not available without original cache bytes"}
    with OUT.open("x") as stream:
        stream.write(json.dumps(result, sort_keys=True, indent=2) + "\n")
    print(json.dumps({"path": str(OUT), "sha256": sha(OUT), "targets": {
        path: {"files_hashed": sum(entry["kind"] == "file" for entry in entries.values()),
               "logical_file_bytes": sum(entry.get("bytes", 0) for entry in entries.values())}
        for path, entries in inventories.items()}, "process_references": referenced,
        "unreadable_processes": len(unreadable), "container_mount_references": mounts, "deleted": False}))
if __name__ == "__main__":
    main()
