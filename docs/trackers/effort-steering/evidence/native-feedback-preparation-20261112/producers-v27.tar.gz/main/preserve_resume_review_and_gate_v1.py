"""Preserve selected review, stopped-run, calibration and gate evidence; no source mutation."""
import hashlib
import io
import json
from pathlib import Path
import tarfile
MAIN = Path("/home/marius/work/claude/codescout")
REV = Path("/home/marius/.codex/worktrees/2aa6/codescout")
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
OUT = MAIN / "docs/trackers/effort-steering/evidence/native-feedback-preparation-20261112"
selected = {}
def add(path, name):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    selected[name] = path
def main():
    for directory in ("native-feedback-resume-review-fbu7mdfe",
                      "native-resume-v5-instrument-review-rzfkkq5q",
                      "native-resume-v5-instrument-replay-vjt2x6zu",
                      "native-resume-guard-replay-mlathqi3"):
        root = Path("/tmp") / directory
        assert root.is_dir()
        # Reviewer reports/probes/logs/mutations at root; not copied code trees.
        for path in root.iterdir():
            if path.is_file() and path.suffix in (".json", ".log", ".diff", ".py"):
                add(path, "review/" + directory + "/" + path.name)
    for name in ("project-gate-openssl35-v2.log", "project-gate-private-tmp-v3.log",
                 "symlink-private-tmp-control-v1.log", "receipt-binding-regressions-v1.log",
                 "receipt-binding-regressions-v2.log", "full-protocol-receipt-binding-v2.log",
                 "full-protocol-receipt-binding-v3.log"):
        add(REV / ".superpowers/sdd/2026-11-12-blinded-assertion-boundary" / name, "verification/" + name)
    add(ROOT / "resume-observer-cli-v5-calibration.json", "calibration/actual-cli-v5.json")
    for name in ("initial-summary.json", "final-registration.json", "terminal-summary.json"):
        add(ROOT / "native-feedback-qualification-v3-registration" / name, "qualification-v3/" + name) if (ROOT / "native-feedback-qualification-v3-registration" / name).exists() else None
    add(OUT / "qualification-v3-stopped-v1.json", "qualification-v3/readback.json")
    for path in (MAIN / ".superpowers/sdd/2026-11-11-native-public-feedback-transfer").glob("*v5*.py"):
        add(path, "instruments/" + path.name)
    for path in (MAIN / ".superpowers/sdd/2026-11-11-native-public-feedback-transfer").glob("*resume_v4.py"):
        add(path, "instruments/" + path.name)
    for path in (MAIN / ".superpowers/sdd/2026-11-11-native-public-feedback-transfer").glob("*resume-v5-tests*.log"):
        add(path, "instruments/" + path.name)
    data = {name: path.read_bytes() for name, path in sorted(selected.items())}
    archive = OUT / "resume-review-and-gate-v1.tar.gz"
    with tarfile.open(archive, "x:gz") as tar:
        for name, content in data.items():
            entry = tarfile.TarInfo(name)
            entry.size, entry.mode = len(content), 0o644
            tar.addfile(entry, io.BytesIO(content))
    with tarfile.open(archive) as tar:
        assert tar.getnames() == list(data)
        assert all(tar.extractfile(name).read() == content for name, content in data.items())
    assert all(selected[name].read_bytes() == content for name, content in data.items())
    sha = lambda data: hashlib.sha256(data).hexdigest()
    manifest = {"schema": "selected-resume-review-gate-custody-v1",
                "archive": str(archive), "archive_bytes": archive.stat().st_size,
                "archive_sha256": sha(archive.read_bytes()), "members": {
                    name: {"path": str(selected[name]), "sha256": sha(content), "bytes": len(content)}
                    for name, content in data.items()},
                "member_count": len(data), "all_members_reopened": True,
                "scope": "Selected evidence only, not all runtime source/private artifacts; actual resume remains unrun.",
                "paid_admission": False}
    with (OUT / "resume-review-and-gate-v1.json").open("x") as stream:
        stream.write(json.dumps(manifest, sort_keys=True, indent=2) + "\n")
    print(json.dumps({key: value for key, value in manifest.items() if key != "members"}))
if __name__ == "__main__":
    main()
