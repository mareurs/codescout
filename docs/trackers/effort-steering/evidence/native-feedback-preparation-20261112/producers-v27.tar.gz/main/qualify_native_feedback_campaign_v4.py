"""Fresh qualification entry with growth headroom, no paid author transport."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import sys
import time
WORK = Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path[:0] = [str(WORK / "tools" / name) for name in
                ("effort_protocol", "agent_lifecycle", "hint_authority_pilot")]

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("registration", type=Path)
    parser.add_argument("--check-capacity-only", action="store_true")
    args = parser.parse_args()
    reg = json.loads(args.registration.read_bytes())
    assert reg["mode"] == "scripted"
    assert not Path(reg["output_root"]).exists()
    roots = {task["backend"]["public"]["resource_root"] for task in reg["tasks"].values()}
    floors = {task["backend"]["public"]["resource_floors"]["root_free"] for task in reg["tasks"].values()}
    assert len(roots) == len(floors) == 1
    floor = next(iter(floors))
    assert floor == 80 * 1024**3
    info = os.statvfs(next(iter(roots)))
    available = info.f_bavail * info.f_frsize
    # An extra12GiB launch margin is a controller guard, not a changed task floor.
    minimum = floor + 12 * 1024**3
    result = {"scope": "Current root capacity before any qualification dispatch",
              "available_bytes": available, "registered_floor_bytes": floor,
              "minimum_launch_bytes": minimum, "launch_admitted": available >= minimum,
              "paid_ready": False, "stage": "not_dispatched"}
    with (args.registration.parent / ("capacity-" + str(time.time_ns()) + ".json")).open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result), flush=True)
    if available < minimum:
        raise SystemExit(2)
    if args.check_capacity_only:
        return
    path = Path(__file__).with_name("qualify_native_feedback_campaign_v1.py")
    spec = importlib.util.spec_from_file_location("frozen_qualification_v1_for_v4", path)
    prior = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(prior)
    prior.__file__ = str(Path(__file__).resolve())
    prior.main()

if __name__ == "__main__":
    main()
