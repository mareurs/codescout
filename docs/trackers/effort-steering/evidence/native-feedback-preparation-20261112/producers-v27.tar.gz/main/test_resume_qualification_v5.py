"""Consuming instrument controls; real local processes, no provider or evaluator."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from resume_qualification_instruments_v5 import ProcessObservation, frozen_inputs

class ProcessControls(unittest.TestCase):
    def test_actual_processes_are_observed_across_both_phases(self):
        with tempfile.TemporaryDirectory() as directory:
            entry = Path(directory) / "entry.py"
            entry.write_text("raise SystemExit(0)\n")
            observer = ProcessObservation({str(entry)}, {"/bin/true"})
            with observer:
                subprocess.run([sys.executable, "-I", "-B", str(entry), "request", "out"], check=True)
                subprocess.run(["/bin/true", "--session-id", "known"], check=True)
                observer.phase = "resume"
                subprocess.run([sys.executable, "-I", "-B", str(entry), "request", "out"], check=True)
                subprocess.run(["/bin/true", "--session-id", "unexpected"], check=True)
                subprocess.run(["/bin/true"], check=True)
            rows = observer.rows()
            self.assertEqual([(r["phase"], r["kind"]) for r in rows],
                             [("initial", "private"), ("initial", "cli"),
                              ("resume", "private"), ("resume", "cli")])
            self.assertEqual(len({r["pid"] for r in rows}), 4)
            self.assertTrue(all(type(r["pid"]) is int and r["pid"] > 0 and r["returncode"] == 0 for r in rows))
            self.assertEqual(rows[0]["argv"][3], str(entry))
            self.assertEqual(observer.rows(), rows)


    def test_observer_reenters_for_the_actual_two_context_driver_shape(self):
        observer = ProcessObservation(set(), {"/bin/true"})
        with observer:
            subprocess.run(["/bin/true", "--session-id", "initial"], check=True)
        observer.phase = "resume"
        with observer:
            subprocess.run(["/bin/true", "--session-id", "resume"], check=True)
        self.assertEqual([(row["phase"], row["returncode"]) for row in observer.rows()],
                         [("initial", 0), ("resume", 0)])

    def test_real_failure_code_and_matching_scope(self):
        with tempfile.TemporaryDirectory() as directory:
            entry = Path(directory) / "entry.py"
            entry.write_text("raise SystemExit(7)\n")
            observer = ProcessObservation({str(entry)}, {"/bin/true"})
            with observer:
                subprocess.run([sys.executable, "-I", "-B", str(entry), "request", "out"])
                subprocess.run([sys.executable, "-I", "-B", str(entry)])
            self.assertEqual(len(observer.rows()), 1)
            self.assertEqual(observer.rows()[0]["returncode"], 7)

class SnapshotControls(unittest.TestCase):
    def fixture(self, root):
        for name in ("registration.json", "actor-batch-closed.json", "ledger-final.json",
                     "ledger-reserved.json", "result.json", "integrity-audits.json"):
            (root / name).write_text("{}")
        receipt = root / "attempts/00-P/repair/invocation.json"
        receipt.parent.mkdir(parents=True)
        receipt.write_text("{}")
        audit = root / "audits/00-P/descriptor.json"
        audit.parent.mkdir(parents=True)
        audit.write_text("{}")
        source = root / "captured"
        source.mkdir()
        (source / "source.rs").write_text("pub fn f() {}")
        return {"attempts": [{"candidate": str(source)}]}, receipt, audit

    def test_original_audit_bytes_modes_links_and_new_entries_are_measured(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            initial, receipt, audit = self.fixture(root)
            baseline = frozen_inputs(root, initial)
            audit.write_text('{"changed":true}')
            self.assertNotEqual(frozen_inputs(root, initial), baseline)
            audit.write_text("{}")
            self.assertEqual(frozen_inputs(root, initial), baseline)
            receipt.chmod(0o600)
            self.assertNotEqual(frozen_inputs(root, initial), baseline)
            receipt.chmod(0o644)
            (audit.parent / "new-link").symlink_to("descriptor.json")
            self.assertNotEqual(frozen_inputs(root, initial), baseline)


    def test_existing_symlink_retarget_is_detected_even_with_identical_target_bytes(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            initial, _, audit = self.fixture(root)
            other = audit.parent / "other.json"
            other.write_bytes(audit.read_bytes())
            link = audit.parent / "existing-link"
            link.symlink_to(audit.name)
            baseline = frozen_inputs(root, initial)
            link.unlink()
            link.symlink_to(other.name)
            self.assertNotEqual(frozen_inputs(root, initial), baseline)

    def test_candidate_mode_and_empty_directory_are_measured(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            initial, _, _ = self.fixture(root)
            baseline = frozen_inputs(root, initial)
            candidate = Path(initial["attempts"][0]["candidate"])
            (candidate / "empty").mkdir()
            self.assertNotEqual(frozen_inputs(root, initial), baseline)
            (candidate / "empty").rmdir()
            (candidate / "source.rs").chmod(0o600)
            self.assertNotEqual(frozen_inputs(root, initial), baseline)

    def test_excluded_cache_and_separate_final_outputs_are_outside_scope(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            initial, receipt, _ = self.fixture(root)
            native = receipt.parent / "native"
            for name in ("actor", "native-home", "public-build-state"):
                (native / name).mkdir(parents=True, exist_ok=True)
            baseline = frozen_inputs(root, initial)
            for name in ("actor", "native-home", "public-build-state"):
                (native / name / "cache").write_text("new working state")
            (root / "grades").mkdir()
            (root / "result-final.json").write_text("{}")
            self.assertEqual(frozen_inputs(root, initial), baseline)
            (native / "receipt.json").write_text("new authoritative evidence")
            self.assertNotEqual(frozen_inputs(root, initial), baseline)

if __name__ == "__main__":
    unittest.main()
