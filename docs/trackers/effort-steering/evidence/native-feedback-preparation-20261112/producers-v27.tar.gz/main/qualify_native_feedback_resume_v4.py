"""Actual scripted16CLI pending-to-final control; no paid provider or actor replay."""
import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch

WORK = Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path[:0] = [str(WORK / "tools" / name) for name in
                ("effort_protocol", "agent_lifecycle", "hint_authority_pilot")]
import feedback_runner as runner
from native_campaign import NativeCampaignBackend
import native_campaign
from receipts import input_digest
path = Path(__file__).with_name("qualify_native_feedback_campaign_v1.py")
spec = importlib.util.spec_from_file_location("resume_qualification_transport_v1", path)
transport = importlib.util.module_from_spec(spec)
spec.loader.exec_module(transport)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(path, value):
    with Path(path).open("x") as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + "\n")

def frozen_inputs(root, initial):
    selected = [root / name for name in ("registration.json", "actor-batch-closed.json",
                "ledger-final.json", "ledger-reserved.json", "result.json", "integrity-audits.json")]
    for path in (root / "attempts").rglob("*"):
        relative = path.relative_to(root / "attempts").parts
        # Cache/preparation working trees are tool state. Complete captured source is
        # separately checked by input_digest, including links, modes and empty dirs.
        if len(relative) >= 4 and relative[2] == "native" and relative[3] in (
                "actor", "native-home", "public-build-state"):
            continue
        if path.is_file() and not path.is_symlink():
            selected.append(path)
    return {"files": {str(path): sha(path) for path in sorted(set(selected))},
            "captured_candidates": {row["candidate"]: input_digest(row["candidate"])
                                    for row in initial["attempts"]}}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("registration", type=Path)
    args = parser.parse_args()
    assert Path(__file__).stat().st_mode & 0o222 == 0
    reg = json.loads(args.registration.read_bytes())
    assert reg["mode"] == "scripted" and len(reg["schedule"]) == 16
    assert reg["qualification_driver"] == {"path": str(Path(__file__).resolve()), "sha256": sha(__file__)}
    assert all(sha(path) == digest for path, digest in reg["bindings"].items())
    backend = NativeCampaignBackend(mode="scripted")
    checked = runner.preflight(reg, backend)
    save(args.registration.parent / "preflight.json", checked)
    assert checked["ready"] and checked["paid_ready"] is False
    original_audit = backend.audit
    audit_calls = []
    def delayed_last(request, out):
        proof = original_audit(request, out)
        audit_calls.append(proof["opaque_id"])
        if len(audit_calls) == 16:
            proof = copy.deepcopy(proof)
            proof.update(terminal=False, status="unresolved",
                         method="qualification-controller-deferred",
                         reason="Registered zero-provider resume control; real audit descriptor is retained.")
        return proof
    print(json.dumps({"starting": True, "scope": "actual scripted16CLI then actor-free resume",
                      "provider_forwarding": "forbidden", "paid_ready": False}), flush=True)
    with patch.object(transport.external.transport.Proxy, "upstream", transport.no_upstream), \
         patch.object(transport.external.transport.Proxy, "scripted", transport.scripted_turns), \
         patch.object(backend, "audit", side_effect=delayed_last):
        initial = runner.run_campaign(reg, backend)
    root = Path(reg["output_root"])
    save(args.registration.parent / "initial-summary.json",
         {"status": initial["status"], "attempts": len(initial["attempts"]),
          "audit_calls": len(audit_calls), "paid_ready": False})
    assert initial["status"] == "audit_pending" and initial["actor_status"] == "completed"
    assert len(initial["attempts"]) == len(audit_calls) == 16 and initial["closure"]["complete"]
    assert initial["integrity_audit"]["unresolved"] == [15] and not (root / "grades").exists()
    for row in initial["attempts"]:
        assert row["grade"] is None and row["workflow_state"] == "closed" and not row["measurement_invalid"]
        assert row["cost"] == {"known_usd": "0", "unknown": False}
        record = row["invocations"][0]["record"]
        assert record["lifecycle"]["turns"] == 5 and record["lifecycle"]["continuations"] == 4
        receipt = json.loads((Path(record["native_path"]) / "receipt.json").read_bytes())
        assert receipt["forwarded"] == 0 and receipt["scripted"] is True
    before = frozen_inputs(root, initial)
    save(args.registration.parent / "frozen-before-resume.json", before)
    resumed_backend = NativeCampaignBackend(mode="scripted")
    assert resumed_backend.authorization is None
    blocked = {key: 0 for key in ("invoke", "verify", "launch", "reserve", "upstream")}
    def forbidden(name):
        def guard(*args, **kwargs):
            blocked[name] += 1
            raise AssertionError("actor-free resume attempted " + name)
        return guard
    private_entries = {task["backend"]["private"]["entry"] for task in reg["tasks"].values()}
    private_processes = []
    real_run = subprocess.run
    def measured_run(*args, **kwargs):
        command = args[0] if args else kwargs.get("args")
        completed = real_run(*args, **kwargs)
        if (isinstance(command, list) and len(command) == 6
                and command[:3] == [sys.executable, "-I", "-B"] and command[3] in private_entries):
            private_processes.append({"argv": command, "returncode": completed.returncode})
        return completed
    with patch.object(resumed_backend, "invoke", side_effect=forbidden("invoke")), \
         patch.object(resumed_backend, "verify", side_effect=forbidden("verify")), \
         patch.object(transport.external, "launch", side_effect=forbidden("launch")), \
         patch.object(runner, "_reserve", side_effect=forbidden("reserve")), \
         patch.object(transport.external.transport.Proxy, "upstream", forbidden("upstream")), \
         patch.object(native_campaign.subprocess, "run", side_effect=measured_run):
        final = runner.resume_grading(reg, resumed_backend)
        assert final["status"] == "completed" and final["paid_ready"] is False
        assert resumed_backend.closed_only is True and resumed_backend.authorization is None
        assert len(private_processes) == 16 and all(row["returncode"] == 0 for row in private_processes)
        try:
            runner.resume_grading(reg, resumed_backend)
        except ValueError as exc:
            assert "already started or completed" in str(exc)
        else:
            raise AssertionError("duplicate resume was accepted")
    assert all(count == 0 for count in blocked.values()) and len(private_processes) == 16
    assert frozen_inputs(root, initial) == before
    assert final["resumed_from"] == {"path": str(root / "result.json"), "sha256": before["files"][str(root / "result.json")]}
    assert [row["candidate"] for row in final["attempts"]] == [row["candidate"] for row in initial["attempts"]]
    assert all(row["grade"]["valid"] is True and row["grade"]["pass"] is False for row in final["attempts"])
    analysis = runner.analyze(reg, str(root))
    assert analysis["interpretable"] is True and analysis["decision"] == "NO-GO"
    save(root / "runtime-resume-qualification.json", {
        "scope": "Actual scripted16CLI closed batch, deliberately deferred final audit, fresh native rehydration and original evaluator execution.",
        "actor_invocations_before_pending": 16, "private_processes_before_resume": 0,
        "observed_private_processes_after_resume": private_processes, "forbidden_resume_calls": blocked,
        "frozen_file_bindings": before["files"], "captured_candidates": before["captured_candidates"],
        "frozen_before_sha256": sha(args.registration.parent / "frozen-before-resume.json"),
        "result_final_sha256": sha(root / "result-final.json"),
        "final_index_sha256": sha(root / "integrity-audits-final.json"),
        "client_model_cost_usd": "0", "compute_cost": "unknown", "paid_ready": False,
        "efficacy_claim": None})
    print(json.dumps({"completed": True, "actual_native_invocations": 16, "resume_actor_calls": 0,
                      "private_processes_after_resume": 16, "paid_ready": False}), flush=True)

if __name__ == "__main__":
    main()
