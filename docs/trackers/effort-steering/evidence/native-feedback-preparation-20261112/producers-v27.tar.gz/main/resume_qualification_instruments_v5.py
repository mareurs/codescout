"""Scoped actual-process and closed-evidence instruments for resume control."""
import hashlib
import os
from pathlib import Path
import stat
import subprocess
import sys
from unittest.mock import patch
from receipts import input_digest

class ProcessObservation:
    """Observe actual parent-process Popen seams used by CLI and private entry.

    This is not a machine-wide or descendant-process inventory. Only the frozen
    production launch paths are covered; their PIDs are calibrated to receipts.
    """
    def __init__(self, private_entries, cli_paths):
        self.private_entries = set(private_entries)
        self.cli_paths = set(cli_paths)
        self.phase = "initial"
        self.processes = []
        self.real_popen = subprocess.Popen
        self.active = False

    def _spawn(self, *args, **kwargs):
        command = args[0] if args else kwargs.get("args")
        kind = None
        if isinstance(command, (list, tuple)):
            command = list(command)
            if (len(command) == 6 and command[:3] == [sys.executable, "-I", "-B"]
                    and command[3] in self.private_entries):
                kind = "private"
            elif command and command[0] in self.cli_paths and "--session-id" in command:
                kind = "cli"
        process = self.real_popen(*args, **kwargs)
        if kind:
            self.processes.append((self.phase, kind, list(command), process))
        return process

    def __enter__(self):
        if self.active:
            raise RuntimeError("process observer already active")
        self.patcher = patch.object(subprocess, "Popen", side_effect=self._spawn)
        self.patcher.start()
        self.active = True
        return self

    def __exit__(self, *exc):
        self.patcher.stop()
        self.active = False

    def rows(self):
        return [{"phase": phase, "kind": kind, "argv": argv, "pid": process.pid,
                 "returncode": process.poll()} for phase, kind, argv, process in self.processes]

def frozen_inputs(root, initial):
    """Full authoritative trees, excluding only registered native working caches."""
    root = Path(root)
    paths = [root / name for name in ("registration.json", "actor-batch-closed.json",
             "ledger-final.json", "ledger-reserved.json", "result.json", "integrity-audits.json")]
    for tree in (root / "attempts", root / "audits"):
        paths.append(tree)
        for parent, dirs, files in os.walk(tree, followlinks=False):
            parent = Path(parent)
            for name in list(dirs):
                path = parent / name
                relative = path.relative_to(root / "attempts").parts if tree.name == "attempts" else ()
                if (len(relative) == 4 and relative[2] == "native"
                        and relative[3] in ("actor", "native-home", "public-build-state")):
                    dirs.remove(name)
                    continue
                paths.append(path)
            paths.extend(parent / name for name in files)
    entries = {}
    for path in sorted(set(paths)):
        info = path.lstat()
        row = {"mode": stat.S_IMODE(info.st_mode)}
        if stat.S_ISLNK(info.st_mode):
            row.update(kind="symlink", target=os.readlink(path))
        elif stat.S_ISDIR(info.st_mode):
            row.update(kind="directory")
        elif stat.S_ISREG(info.st_mode):
            row.update(kind="file", sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        else:
            raise ValueError("unsupported authoritative evidence kind: " + str(path))
        entries[str(path)] = row
    return {"entries": entries,
            "captured_candidates": {row["candidate"]: input_digest(row["candidate"])
                                    for row in initial["attempts"]}}
