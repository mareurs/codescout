"""Controller boundary tests: refusal/dispatch, not model outcomes."""
import contextlib
import io
import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import patch
import qualify_native_feedback_campaign_v4 as subject

class GrowthAdmissionTests(unittest.TestCase):
    def check(self, available, *, capacity_only=False, forged_floor=False):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            registration = root / "registration.json"
            run = root / "future"
            registration.write_text(json.dumps({"mode": "scripted", "output_root": str(run), "tasks": {
                "one": {"backend": {"public": {"resource_root": str(root),
                        "resource_floors": {"root_free": (79 if forged_floor else 80) * 1024**3}}}}}}))
            argv = ["qualification", str(registration)] + (["--check-capacity-only"] if capacity_only else [])
            with patch.object(subject.sys, "argv", argv), \
                 patch.object(subject.os, "statvfs", return_value=SimpleNamespace(f_bavail=available // 4096, f_frsize=4096)), \
                 patch.object(subject.importlib.util, "spec_from_file_location",
                              side_effect=RuntimeError("controlled dispatch boundary")) as dispatch, \
                 contextlib.redirect_stdout(io.StringIO()):
                if forged_floor:
                    with self.assertRaises(AssertionError):
                        subject.main()
                elif available < 92 * 1024**3:
                    with self.assertRaises(SystemExit) as error:
                        subject.main()
                    self.assertEqual(error.exception.code, 2)
                elif capacity_only:
                    subject.main()
                else:
                    with self.assertRaisesRegex(RuntimeError, "controlled dispatch boundary"):
                        subject.main()
                expected_dispatch = int(not forged_floor and available >= 92 * 1024**3 and not capacity_only)
                self.assertEqual(dispatch.call_count, expected_dispatch)
            observations = list(root.glob("capacity-*.json"))
            self.assertEqual(len(observations), 0 if forged_floor else 1)
            if observations:
                result = json.loads(observations[0].read_bytes())
                self.assertEqual(result["available_bytes"], available)
                self.assertEqual(result["registered_floor_bytes"], 80 * 1024**3)
                self.assertEqual(result["minimum_launch_bytes"], 92 * 1024**3)
                self.assertEqual(result["launch_admitted"], available >= 92 * 1024**3)
            self.assertFalse(run.exists())

    def test_below_threshold_refuses_before_dispatch(self):
        self.check(92 * 1024**3 - 4096)

    def test_exact_threshold_reaches_controlled_dispatch(self):
        self.check(92 * 1024**3)

    def test_capacity_only_pass_never_dispatches(self):
        self.check(92 * 1024**3 + 4096, capacity_only=True)

    def test_lowered_original_floor_is_refused(self):
        self.check(100 * 1024**3, forged_floor=True)

class ResumeGrowthAdmissionTests(unittest.TestCase):
    def check(self, available, *, forged_floor=False):
        import qualify_native_feedback_resume_v5 as resume
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            registration = root / "registration.json"
            registration.write_text(json.dumps({
                "mode": "scripted", "schedule": [{}] * 16, "bindings": {},
                "qualification_driver": {"path": str(Path(resume.__file__).resolve()), "sha256": resume.sha(resume.__file__)},
                "tasks": {"one": {"backend": {"public": {"resource_root": str(root),
                    "resource_floors": {"root_free": (79 if forged_floor else 80) * 1024**3}}}}}}))
            with patch.object(resume.sys, "argv", ["resume", str(registration)]), \
                 patch.object(resume.os, "statvfs", return_value=SimpleNamespace(f_bavail=available // 4096, f_frsize=4096)), \
                 patch.object(resume, "NativeCampaignBackend", side_effect=RuntimeError("controlled backend boundary")) as backend, \
                 contextlib.redirect_stdout(io.StringIO()):
                if forged_floor:
                    with self.assertRaises(AssertionError):
                        resume.main()
                elif available < 92 * 1024**3:
                    with self.assertRaises(SystemExit) as error:
                        resume.main()
                    self.assertEqual(error.exception.code, 2)
                else:
                    with self.assertRaisesRegex(RuntimeError, "controlled backend boundary"):
                        resume.main()
                self.assertEqual(backend.call_count, int(not forged_floor and available >= 92 * 1024**3))
            self.assertEqual(len(list(root.glob("capacity-*.json"))), 0 if forged_floor else 1)

    def test_resume_below_margin_refuses_before_backend(self):
        self.check(92 * 1024**3 - 4096)

    def test_resume_at_margin_reaches_controlled_backend(self):
        self.check(92 * 1024**3)

    def test_resume_cannot_lower_the_original_floor(self):
        self.check(100 * 1024**3, forged_floor=True)

if __name__ == "__main__":
    unittest.main()
