"""Reopen the complete stopped v3 population; preserve missing evidence as missing."""
import hashlib
import json
from pathlib import Path
import sys
sys.path.insert(0, "/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from receipts import input_digest
ROOT = Path("/var/tmp/native-feedback-qualified-v3-01a15")
OUT = Path("docs/trackers/effort-steering/evidence/native-feedback-preparation-20261112/qualification-v3-stopped-v1.json")
bindings = {}
def read(path):
    data = path.read_bytes()
    bindings[str(path)] = hashlib.sha256(data).hexdigest()
    return json.loads(data)
result = read(ROOT / "result.json")
registration = read(ROOT / "registration.json")
assert result["status"] == "stopped"
assert len(result["attempts"]) + len(result["unexecuted"]) == len(registration["schedule"]) == 16
rows = []
for item in result["attempts"]:
    attempt = read(Path(item["attempt_receipt"]))
    assert attempt == item
    decision = attempt["invocations"][0]
    record = decision["record"]
    row = {"index": item["attempt_index"], "task_id": item["task_id"], "arm": item["arm"],
           "workflow_state": item["workflow_state"], "measurement_invalid": item["measurement_invalid"],
           "cost": item["cost"], "private_grade": item["grade"],
           "faults": decision.get("faults", []), "host_receipt_present": "native_path" in record}
    if "native_path" in record:
        native = Path(record["native_path"])
        receipt = read(native / "receipt.json")
        launch = read(native / "launch.json")
        invocation = read(Path(item["attempt_receipt"]).parent / "repair/invocation.json")
        assert invocation == record
        assert receipt["scripted"] is True and receipt["forwarded"] == 0
        assert launch["real_credentials_read"] is False
        assert receipt["cost_usd"] == "0" and receipt["unknown_provider_cost"] is False
        assert input_digest(item["candidate"]) == item["source_digest"]
        row.update(actor_started=record["actor_started"], workflow_completed=receipt["workflow_completed"],
                   client_cost_usd=receipt["cost_usd"], provider_forwarded=receipt["forwarded"],
                   real_credentials_read=launch["real_credentials_read"], lifecycle=receipt["lifecycle"],
                   candidate_digest=item["source_digest"], capture_complete=record["capture_complete"])
    rows.append(row)
assert all(row["private_grade"] is None for row in rows) and not (ROOT / "grades").exists()
payload = {"schema": "native-feedback-qualification-failure-v1", "status": result["status"],
           "reason": result["reason"], "rows": rows, "attempt_records": len(rows),
           "closed_native_receipts": sum(row.get("workflow_completed") is True for row in rows),
           "invalid_records": sum(row["measurement_invalid"] is True for row in rows),
           "unexecuted": result["unexecuted"],
           "private_grade_fields_present": sum(row["private_grade"] is not None for row in rows),
           "grades_directory_exists": (ROOT / "grades").exists(),
           "unknown_cost_records": sum(row["cost"]["unknown"] is True for row in rows),
           "paid_ready": False, "compute_cost": "unknown", "efficacy_claim": None,
           "bindings": bindings}
with OUT.open("x") as stream:
    stream.write(json.dumps(payload, indent=2, sort_keys=True) + "\n")
print(json.dumps({key: value for key, value in payload.items() if key not in ("rows", "bindings", "unexecuted")}))
