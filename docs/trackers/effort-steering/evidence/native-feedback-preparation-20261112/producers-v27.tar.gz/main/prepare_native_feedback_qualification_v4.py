"""Prepare a fresh frozen qualification after the stopped v3; never launch actors."""
import copy
import hashlib
import json
from pathlib import Path
MAIN = Path("/home/marius/work/claude/codescout")
WORK = Path("/home/marius/.codex/worktrees/2aa6/codescout")
BASE = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
PREVIOUS = BASE / "native-feedback-qualification-v3-registration"
OUT = BASE / "native-feedback-qualification-v4-registration"
RUN = Path("/var/tmp/native-feedback-qualified-v4-01a15")
EVIDENCE = MAIN / "docs/trackers/effort-steering/evidence/native-feedback-baseline-20261111"

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(path):
    return json.loads(Path(path).read_bytes())

def save(path, value):
    with Path(path).open("x") as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + "\n")

def main():
    assert Path(__file__).stat().st_mode & 0o222 == 0
    assert not OUT.exists() and not RUN.exists()
    terminal = read(PREVIOUS / "terminal-summary.json")
    assert terminal["status"] == "stopped" and terminal["attempts"] == 10
    reg = copy.deepcopy(read(PREVIOUS / "final-registration.json"))
    old = read(EVIDENCE / "task5-real-mcp-framing-reviewed-v1.json")
    source = EVIDENCE / "task5-receipt-binding-reviewed-v1.json"
    new = read(source)
    assert set(old["members"]) == set(new["members"]) and len(new["members"]) == 142
    assert new["legacy_inputs_reopened_unchanged"] == 102
    changed = {name for name in old["members"] if old["members"][name] != new["members"][name]}
    assert changed == {"tools/effort_protocol/test_feedback_audit_resume.py"}
    assert all(sha(WORK / name) == row["sha256"] for name, row in new["members"].items())
    mismatches = {path for path, digest in reg["bindings"].items() if sha(path) != digest}
    assert mismatches == {str(WORK / name) for name in changed}
    reg.update(campaign_id="native-feedback-qualified-v4-01a15", output_root=str(RUN))
    OUT.mkdir()
    scope = OUT / "scope.json"
    save(scope, {"scope": "Fresh same16CLI qualification; only reviewed consuming tests changed.",
                 "old_stopped_root": "/var/tmp/native-feedback-qualified-v3-01a15",
                 "launch_growth_margin_bytes": 12 * 1024**3,
                 "concurrent_host_gate": "prohibited during qualification",
                 "source_members": len(new["members"]), "compute_cost": "unknown", "paid_ready": False})
    reg["shared_preparation"] = {"cost_usd": "0", "receipt_sha256": sha(scope)}
    driver = Path(__file__).with_name("qualify_native_feedback_campaign_v4.py").resolve()
    dependencies = [Path(__file__).resolve(), driver.with_name("qualify_native_feedback_campaign_v1.py")]
    reg["qualification_driver"] = {"path": str(driver), "sha256": sha(driver)}
    reg["qualification_driver_dependencies"] = [{"path": str(path), "sha256": sha(path)} for path in dependencies]
    for path in [driver, *dependencies, scope, source, source.with_suffix(".tar.gz"),
                 PREVIOUS / "terminal-summary.json", *[WORK / name for name in new["members"]]]:
        reg["bindings"][str(path)] = sha(path)
    assert all(sha(path) == digest for path, digest in reg["bindings"].items())
    save(OUT / "final-registration.json", reg)
    print(json.dumps({"registration": str(OUT / "final-registration.json"),
                      "schedule": len(reg["schedule"]), "paid_ready": False}))

if __name__ == "__main__":
    main()
