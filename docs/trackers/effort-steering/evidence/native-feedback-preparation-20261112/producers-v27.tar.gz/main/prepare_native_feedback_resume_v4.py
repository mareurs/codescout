"""Preregister a separate pending/resume control after normal16qualification closes."""
import copy
import hashlib
import json
from pathlib import Path
BASE = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
PREVIOUS = BASE / "native-feedback-qualification-v3-registration"
OUT = BASE / "native-feedback-resume-v4-registration"
RUN = Path("/var/tmp/native-feedback-resume-v4-01a15")
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path, value):
    with Path(path).open("x") as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + "\n")
def main():
    assert Path(__file__).stat().st_mode & 0o222 == 0
    assert not OUT.exists() and not RUN.exists()
    terminal = json.loads((PREVIOUS / "terminal-summary.json").read_bytes())
    assert terminal["status"] == "completed" and terminal["attempts"] == 16
    old = json.loads((PREVIOUS / "final-registration.json").read_bytes())
    normal = Path(old["output_root"])
    qualified = json.loads((normal / "runtime-qualification.json").read_bytes())
    assert qualified["all_workflows_closed"] is True and qualified["native_invocations"] == 16
    assert qualified["provider_forwarded"] == 0
    reg = copy.deepcopy(old)
    reg.update(campaign_id="native-feedback-resume-v4-01a15", output_root=str(RUN))
    OUT.mkdir()
    scope = OUT / "scope.json"
    save(scope, {"scope": "Separate actual16CLI pending-to-final resume control; only final initial audit is deliberately deferred.",
                 "original_normal_qualification": str(normal), "compute_cost": "unknown",
                 "client_author_calls": 0, "client_provider_calls": 0, "paid_ready": False})
    reg["shared_preparation"] = {"cost_usd": "0", "receipt_sha256": sha(scope)}
    driver = Path(__file__).with_name("qualify_native_feedback_resume_v4.py").resolve()
    dependencies = [Path(__file__).resolve(), driver.with_name("qualify_native_feedback_campaign_v1.py")]
    reg["qualification_driver"] = {"path": str(driver), "sha256": sha(driver)}
    reg["qualification_driver_dependencies"] = [{"path": str(path), "sha256": sha(path)} for path in dependencies]
    for path in [driver, *dependencies, scope, PREVIOUS / "terminal-summary.json",
                 PREVIOUS / "final-registration.json", normal / "runtime-qualification.json"]:
        reg["bindings"][str(path)] = sha(path)
    assert all(sha(path) == digest for path, digest in reg["bindings"].items())
    save(OUT / "final-registration.json", reg)
    print(json.dumps({"registration": str(OUT / "final-registration.json"), "paid_ready": False}))
if __name__ == "__main__":
    main()
