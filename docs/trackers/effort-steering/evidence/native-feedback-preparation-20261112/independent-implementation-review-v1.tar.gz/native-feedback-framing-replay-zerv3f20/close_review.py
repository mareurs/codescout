from pathlib import Path
import hashlib,json,re
root=Path(__file__).parent;previous=Path('/tmp/native-feedback-framing-review-apu3o07_');src=Path('/home/marius/.codex/worktrees/2aa6/codescout')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=json.loads((root/'custody-before.json').read_text())
custody={'scratch_baseline_changes':[],'current_source_changes':[],'changes_from_prior119_baseline':[]}
for name,value in before.items():
 p=root/'baseline'/name
 if not p.exists() or sha(p)!=value:custody['scratch_baseline_changes'].append(name)
 p=src/name
 if p.exists() and sha(p)!=value:custody['current_source_changes'].append(name)
 p=previous/'baseline'/name
 if not p.exists() or sha(p)!=value:custody['changes_from_prior119_baseline'].append(name)
(root/'custody-after.json').write_text(json.dumps(custody,indent=2)+'\n')
results=json.loads((root/'mutation-results.json').read_text())
failures={r['id']:re.findall(r'^(?:FAIL|ERROR): .*$',Path(r['log']).read_text(),re.M) for r in results}
(root/'failure-sites.json').write_text(json.dumps(failures,indent=2)+'\n')
report={
 'scope':'Final focused framing correction and exact12-mutation regression replay; no production changes since preceding119-test snapshot',
 'baseline':json.loads((root/'baseline-result.json').read_text()),
 'mutation_counts':{'applied':len(results),'killed':sum(r['verdict']=='KILLED' for r in results),'survived':sum(r['verdict']=='SURVIVED' for r in results),'inconclusive':sum(r['verdict']=='INCONCLUSIVE' for r in results),'tests_per_mutant':120},
 'closed_test_gaps':{'ids':['F03','F04','F05','F08','F09','F12'],'all_killed':True,'quality':'Tests alter an otherwise-valid buffered proof at real validate_readiness. Matching expected python in dictionary-shape case prevents a different language check from masking the mutation. Error-response test pins the new consuming _texts call.'},
 'remaining_survivor':{'id':'F07','severity':'nonblocking redundant guard for this campaign','evidence':str(previous/'consumer-probe-results.json'),'observed':'Mutant and baseline both reject multiline project_root with expected /testbed. Mutant only accepts if expected registration also changes to that multiline path, outside fixed-root campaign.'},
 'correctness':{'open_important_findings':0,'framing_mismatch':'Resolved at parser boundary. Both unmodified Dioxus/Ironclaw recorded status+retrieval envelopes accepted by real validate_readiness under otherwise-valid synthetic proof with expected rust.','recording_replay_evidence':str(previous/'consumer-probe-results.json'),'no_fresh_recording_replay_claim':'Production parser SHA256 unchanged between119 and120 snapshots; final change was test-only.'},
 'prior_four_regressions':{'ids':['M01','M15','M17','M18'],'prior_observed_killed':4,'prior_observed_survived':0,'each_tests_at_that_replay':117,'evidence':'/tmp/native-feedback-delta-review-rm85nlq6/mutation-results.json','scope':'These corrective tests remain unchanged; no claim that those four mutations were replayed again in final120 snapshot.'},
 'api_limits':[
  'Readiness admits only the measured complete first-text-block line-count framing, capped at4096 encoded bytes and64 rendered lines per field; other read_file output shapes fail closed.',
  'Selector identity comes from exact captured query arguments in the same RPC session. Rendered response lacks an independent selector/type metadata echo.',
  'Root is fixed /testbed in this campaign. General arbitrary multiline project paths are outside this profile.',
  'Actual MCP recordings were replayed into otherwise synthetic valid binding/index/probe context; this is parser validation, not complete real-project qualification.'
 ],
 'declined_to_judge':[
  'Actual16 CLI qualification completion, root model-free live readiness probes and full project gate: not rerun or independently closed here.',
  'Skipped tests, provider/actor behavior and efficacy: no such executions in reviewer scope.',
  'Review compute cost and paid financial totals beyond implemented accounting checks: unknown, not treated as zero.',
  'Any source delta beyond the two reviewed production/test revisions and listed prior regressions.'
 ],
 'verdict':'APPROVED for the focused implementation delta, conditional on actual16 qualification and the full required project gate. No open Important correctness or applicable mutation-test gap remains from this focused review. Not permission to merge/publish or a positive efficacy claim.',
 'custody':custody,
 'prior_evidence_preserved':['/tmp/native-feedback-review-ssao8f9p','/tmp/native-feedback-delta-review-rm85nlq6',str(previous)]
}
(root/'review-report.json').write_text(json.dumps(report,indent=2)+'\n')
manifest={p.name:sha(p) for p in root.iterdir() if p.is_file() and p.name!='evidence-manifest.json'}
(root/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'report':str(root/'review-report.json'),'report_sha256':sha(root/'review-report.json'),'manifest_sha256':sha(root/'evidence-manifest.json'),'custody':custody,'failure_sites':failures},indent=2))
