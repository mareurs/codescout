"""Fail-closed native preparation admission from HOST-CAPTURED MCP evidence.

The collector must run in the exact evaluated runtime and bind its public source,
common knowledge and executable independently of the actor. The validator does not authenticate arbitrary dictionaries, author onboarding,
or prove that the later CLI received its instruction context. Optional actual
source verification distinguishes enumerated zero-byte index omissions.
"""
import json
import re
import hashlib
import stat
from pathlib import Path, PurePosixPath
from native_executor import _public_digest
from public_build_inputs import validate_descriptor

LSP_TOOLS = {"references", "symbol_at", "call_graph"}
BINDING_FIELDS = {"image", "executable_sha256", "source_snapshot_sha256", "knowledge_sha256"}

class ReadinessViolation(ValueError):
    """Native preparation is missing, stale, wrong, or unproved."""

def _require(ok, message):
    if not ok:
        raise ReadinessViolation(message)

def _result(reply):
    _require(isinstance(reply, dict) and not reply.get("error"), "MCP request error")
    value = reply.get("result")
    _require(isinstance(value, dict), "MCP result missing")
    _require(value.get("isError", False) is False, "MCP tool failed")
    _require(value.get("ok", True) is not False, "MCP nested failure")
    return value

def _texts(reply):
    value = _result(reply)
    content = value.get("content")
    _require(isinstance(content, list) and bool(content), "MCP tool content missing")
    texts = [part["text"] for part in content
             if isinstance(part, dict) and part.get("type") == "text" and isinstance(part.get("text"), str)]
    _require(bool(texts), "MCP tool has no textual evidence")
    for text in texts:
        try:
            payload = json.loads(text)
        except ValueError:
            continue
        if isinstance(payload, dict):
            _require(payload.get("ok", True) is not False and not payload.get("error"),
                     "MCP content reports failure")
    return texts

def buffered_status_ref(reply):
    """Identify only the MCP buffer envelope; never follow a supplied hint."""
    first = _texts(reply)[0]
    try:
        value = json.loads(first)
    except ValueError:
        return None
    if not isinstance(value, dict) or "output_id" not in value:
        return None
    handle = value["output_id"]
    _require(isinstance(handle, str) and re.fullmatch(r"@tool_[0-9a-f]{8,64}", handle),
             "invalid buffered project status reference")
    return handle


def _project_status(wire):
    statuses = []
    for text in _texts(wire.get("status")):
        try:
            value = json.loads(text)
        except ValueError:
            continue
        if isinstance(value, dict) and "project_root" in value and "languages" in value:
            statuses.append(value)
    handle = buffered_status_ref(wire.get("status"))
    if handle is None:
        _require("status_resolution" not in wire, "unexpected project status resolution")
    else:
        _require(not statuses, "ambiguous buffered project status")
        resolution = wire.get("status_resolution")
        _require(isinstance(resolution, list) and len(resolution) == 2,
                 "two buffered project status fields required")
        status = {}
        for item, field, kind in zip(resolution, ("project_root", "languages"), ("string", "array")):
            query = {"path": handle, "json_path": "$." + field}
            _require(isinstance(item, dict) and set(item) == {"arguments", "response"}
                     and item["arguments"] == query, "buffered project status query mismatch")
            # MCP renders read_file's internal JSON as a line-counted text body.
            # Parse the actual transport, not its pre-render internal Value.
            text = _texts(item["response"])[0]
            frame = re.fullmatch(r"([1-9][0-9]*) lines?\n\n([\s\S]*)", text)
            _require(frame is not None and len(text.encode()) <= 4096,
                     "incomplete buffered project status field")
            count, content = int(frame[1]), frame[2]
            _require(count <= 64 and len(content.splitlines()) == count,
                     "incomplete buffered project status field")
            if field == "project_root":
                _require(count == 1, "incomplete buffered project status field")
                status[field] = content
            else:
                try:
                    status[field] = json.loads(content)
                except ValueError as exc:
                    raise ReadinessViolation("malformed buffered project status languages") from exc
                _require(isinstance(status[field], list)
                         and all(isinstance(language, str) for language in status[field]),
                         "malformed buffered project status languages")
        statuses.append(status)
    _require(len(statuses) == 1, "one structured project status required")
    return statuses[0]

def _verify_index(reply, source=None, *, omission_policy="empty-source-v1"):
    _require(type(omission_policy) is str and omission_policy in
             ("empty-source-v1","ascii-whitespace-source-v1"), "unknown index omission policy")
    values = []
    for text in _texts(reply):
        try:
            value = json.loads(text)
        except ValueError:
            continue
        if isinstance(value, dict) and "verdict" in value:
            values.append(value)
    _require(len(values) == 1, "one native index verification required")
    value = values[0]
    expected, stored = value.get("expected_files"), value.get("stored_files")
    missing = value.get("missing_count")
    _require(type(expected) is int and expected > 0 and type(stored) is int and stored > 0
             and type(missing) is int and missing >= 0 and stored + missing == expected,
             "native index file coverage is unproved")
    empty = []
    whitespace = []
    if value.get("verdict") == "incomplete" and missing > 0 and source is not None:
        names = value.get("missing_sample")
        _require(isinstance(names, list) and len(names) == missing
                 and all(isinstance(name, str) for name in names)
                 and len(set(names)) == missing, "entire unique missing population required")
        root = Path(source)
        _require(all(not part.is_symlink() for part in [root, *root.parents]),
                 "linked source root refused")
        for name in names:
            relative = PurePosixPath(name)
            _require(not relative.is_absolute() and bool(relative.parts)
                     and relative.as_posix() == name and ".." not in relative.parts,
                     "canonical in-root missing path required")
            target = root
            for part in relative.parts:
                target = target / part
                _require(not target.is_symlink(), "linked missing path refused")
            try:
                info = target.stat()
                _require(stat.S_ISREG(info.st_mode), "missing file is not regular source")
                data = target.read_bytes()
                _require(len(data)==info.st_size and (data==b"" or
                         (omission_policy=="ascii-whitespace-source-v1" and not data.strip())),
                         ("missing file is not empty regular source" if omission_policy=="empty-source-v1" else
                          "missing source has content outside the declared omission policy"))
            except OSError as exc:
                raise ReadinessViolation("missing source cannot be inspected") from exc
            if data:
                whitespace.append({"path":name,"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest()})
            else:
                empty.append({"path": name, "sha256": hashlib.sha256(b"").hexdigest()})
    else:
        _require(value.get("verdict") == "complete" and missing == 0,
                 "native index is incomplete")
    for key in ("orphan_count", "chunks_without_vectors"):
        _require(type(value.get(key)) is int and value[key] == 0,
                 "native index has missing/orphan data: " + key)
    memories = value.get("memories")
    _require(isinstance(memories, dict), "native memory verification missing")
    for key in ("missing_count", "orphan_count"):
        _require(type(memories.get(key)) is int and memories[key] == 0,
                 "native memory coverage is incomplete")
    return {**({"whitespace_missing_files":whitespace} if omission_policy=="ascii-whitespace-source-v1" else {}),
            "native_verdict": value["verdict"],
            "coverage": ("all_non_ascii_whitespace_eligible_files" if omission_policy=="ascii-whitespace-source-v1"
                         else "all_nonempty_eligible_files") if (empty or whitespace) else "native_complete",
            "expected_eligible_files": expected, "stored_files": stored,
            "empty_missing_files": empty}


def validate_readiness(expected, wire, *, source=None):
    """Check exact-runtime identity, language/tool surface and public canary calls.

    Public canaries are project adapters: source-derived names and observations,
    never hidden tests or a semantic hint to a repair actor. A canary success
    establishes that operation only, not completeness or quality of onboarding.
    Semantic search is mandatory for this experiment's Codescout-enabled arms.
    """
    _require(isinstance(expected, dict) and isinstance(wire, dict), "readiness objects missing")
    languages = expected.get("languages")
    tools = expected.get("tools")
    probes = expected.get("probes")
    _require(isinstance(languages, list) and bool(languages) and all(isinstance(x, str) and x for x in languages),
             "registered source languages required")
    _require(isinstance(tools, list) and LSP_TOOLS | {"symbols", "semantic_search"} <= set(tools),
             "registered Codescout tool surface incomplete")
    _require(isinstance(probes, list) and bool(probes), "registered public operation canaries required")
    _require(isinstance(expected.get("project_root"), str) and expected["project_root"].startswith("/"),
             "registered absolute project root required")
    binding = expected.get("binding")
    _require(isinstance(binding, dict) and BINDING_FIELDS <= set(binding)
             and set(binding) <= BINDING_FIELDS | {"public_fixture_sha256", "public_build_inputs_sha256"},
             "registered runtime binding incomplete")
    dependency_dirs = []
    descriptor = expected.get("public_build_inputs")
    if descriptor is not None or "public_build_inputs_sha256" in binding:
        _require(descriptor is not None and source is not None, "physical public build inputs required")
        try:
            admitted = validate_descriptor(descriptor, source, binding["image"])
        except (ValueError, OSError, TypeError, KeyError) as exc:
            raise ReadinessViolation("invalid public build inputs") from exc
        _require(binding.get("public_build_inputs_sha256") == admitted["fingerprint"],
                 "registered public build descriptor binding differs")
        dependency_dirs = descriptor["dependency_dirs"]
    for key, value in binding.items():
        pattern = r"sha256:[0-9a-f]{64}" if key == "image" else r"[0-9a-f]{64}"
        _require(isinstance(value, str) and re.fullmatch(pattern, value), "invalid runtime binding " + key)
    _require(wire.get("binding") == binding, "actual runtime/source/knowledge binding mismatch")
    status = _project_status(wire)
    _require(status["project_root"] == expected["project_root"], "wrong active project root")
    _require(isinstance(status["languages"], list) and set(languages) <= set(status["languages"]),
             "expected source languages not active")

    if source is not None:
        _require(_public_digest(source, dependency_dirs=dependency_dirs, preserve_project_context=descriptor is not None) == binding["source_snapshot_sha256"], "actual public source mismatch")
    baseline = expected.get("source_baseline_sha256")
    changed_source = False
    if baseline is not None:
        _require(isinstance(baseline, str) and re.fullmatch(r"[0-9a-f]{64}", baseline)
                 and source is not None, "physical public source and frozen baseline required")
        changed_source = binding["source_snapshot_sha256"] != baseline
    coverage = _verify_index(wire.get("index_verification"), source,
        omission_policy=expected["index_omission_policy"] if "index_omission_policy" in expected else "empty-source-v1")

    pages = wire.get("tool_pages")
    _require(isinstance(pages, list) and bool(pages), "actual MCP tools/list required")
    advertised = set()
    cursor = None
    for page in pages:
        _require(page.get("cursor") == cursor, "tools/list pagination chain mismatch")
        result = _result(page)
        actual_tools = result.get("tools")
        _require(isinstance(actual_tools, list), "MCP tool list missing")
        for tool in actual_tools:
            _require(isinstance(tool, dict) and isinstance(tool.get("name"), str), "malformed tool entry")
            _require(tool["name"] not in advertised, "duplicate advertised MCP tool")
            advertised.add(tool["name"])
        cursor = result.get("nextCursor")
    _require(not cursor, "MCP tool list is incomplete")
    _require(set(tools) <= advertised, "expected MCP tools unavailable")

    actual = wire.get("probes")
    _require(isinstance(actual, list) and len(actual) == len(probes), "actual public operation canaries missing")
    covered = set()
    witnesses = []
    for spec, observation in zip(probes, actual):
        _require(isinstance(spec, dict) and isinstance(observation, dict), "malformed operation canary")
        tool = spec.get("tool")
        _require(tool in advertised and observation.get("tool") == tool, "wrong operation canary tool")
        _require(isinstance(spec.get("arguments"), dict) and observation.get("arguments") == spec["arguments"],
                 "wrong actual operation arguments")
        needles = spec.get("must_contain")
        _require(isinstance(needles, list) and bool(needles) and all(isinstance(x, str) and x for x in needles),
                 "positive public canary witness required")
        # Supplemental guides are not witnesses of an operation.
        text = _texts(observation.get("response"))[0]
        observed = all(needle in text for needle in needles)
        if not changed_source:
            _require(observed, "public operation witness not observed: " + tool)
        witnesses.append({"tool": tool, "observed": observed})
        covered.add(tool)
    _require(LSP_TOOLS | {"semantic_search"} <= covered, "LSP and semantic operation probes required")
    if source is not None:
        _require(_public_digest(source, dependency_dirs=dependency_dirs, preserve_project_context=descriptor is not None) == binding["source_snapshot_sha256"], "source changed during verification")
    result = {"ready": True, "index_coverage": coverage, "project_root": status["project_root"],
              "languages": sorted(status["languages"]), "tools": sorted(advertised),
              "probes_verified": sum(item["observed"] for item in witnesses), "binding": dict(binding)}
    if baseline is not None:
        result.update(readiness_scope="changed-source-capabilities" if changed_source else "baseline-positive-witnesses",
                      probes_observed=len(actual), probe_witnesses=witnesses)
    return result
