"""Parameterized native readiness transport tests with an actual toy stdio process."""
import copy
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parent))
import qualify_native as qualification
import receipts


class RegisteredReadinessTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source, self.actor, self.out = [self.root / name for name in ("source", "actor", "ready")]
        self.source.mkdir()
        (self.source / "module.py").write_text("def public_value(): return 1\n")
        shutil.copytree(self.source, self.actor)
        self.knowledge = self.actor / ".codescout"
        (self.knowledge / "memories").mkdir(parents=True)
        (self.knowledge / "project.toml").write_text('languages = ["python"]\n')
        (self.knowledge / "system-prompt.md").write_text("Public static guidance\n")
        (self.knowledge / "memories/raw.md").write_text("Raw public documentation\n")
        self.static = ["project.toml", "system-prompt.md", "memories/raw.md"]
        self.head = "1" * 40
        (self.knowledge / "index-state.json").write_text(json.dumps({"last_indexed_commit": self.head}))
        self.out.mkdir()
        probes = [{"tool": name, "arguments": {"path": "module.py"}, "must_contain": ["public-operation-witness"]}
                  for name in ("references", "symbol_at", "call_graph", "semantic_search")]
        self.cfg = {"native_image": "sha256:" + "a" * 64,
            "registered_readiness": {"project_root": "/testbed", "languages": ["python"],
                "tools": ["symbols", "references", "symbol_at", "call_graph", "semantic_search"], "probes": probes},
            "knowledge_paths": self.static, "knowledge_sha256": receipts.input_digest(self.knowledge, self.static),
            "baseline_commit": self.head, "index_update_required": False}
        self.index_calls = 0
        self.index_success = True
        self.keep_stale_head = False
        self.witness = "public-operation-witness"
        self.launched = []
        self.removed = False
        self.real_popen = subprocess.Popen

    def popen(self, argv, **kwargs):
        self.launched.append(list(argv))
        self.name = argv[argv.index("--name") + 1]
        status = json.dumps({"project_root": "/testbed", "languages": ["python"]})
        verified = json.dumps({"verdict": "complete", "expected_files": 1, "stored_files": 1,
            "missing_count": 0, "orphan_count": 0, "chunks_without_vectors": 0,
            "memories": {"missing_count": 0, "orphan_count": 0}})
        script = """import json,sys
COUNTS={}
for line in sys.stdin:
 r=json.loads(line)
 if "id" not in r: continue
 method=r["method"];p=r.get("params",{})
 if method=="initialize": result={}
 elif method=="tools/list": result={"tools":[{"name":n} for n in NAMES]}
 elif p.get("name")=="workspace":
  text=json.dumps({"output_id":HANDLE,"summary":"large workspace","buffered_bytes":14177}) if BUFFERED else STATUS
  result={"content":[{"type":"text","text":text}]}
 elif p.get("name")=="read_file":
  a=p.get("arguments",{});jp=a.get("json_path")
  if a.get("path")!=HANDLE or jp not in FIELDS: raise RuntimeError("unexpected buffer query")
  result={"content":[{"type":"text","text":FIELDS[jp]}]}
 elif p.get("name")=="index": result={"content":[{"type":"text","text":VERIFIED}]}
 else:
  name=p.get("name");COUNTS[name]=COUNTS.get(name,0)+1
  timed=name=="references" and ((FIRST and COUNTS[name]==1) or ALWAYS)
  text=json.dumps({"ok":False,"error":"LSP request timed out after 30s: textDocument/references"}) if timed else WITNESS
  result={"content":[{"type":"text","text":text}]}
 print(json.dumps({"jsonrpc":"2.0","id":r["id"],"result":result}),flush=True)
"""
        prefix = "NAMES=" + repr(self.cfg["registered_readiness"]["tools"]) + "\nSTATUS=" + repr(status) + "\nVERIFIED=" + repr(verified) + "\nWITNESS=" + repr(self.witness) + "\n"
        prefix += "FIRST=" + repr(getattr(self, "timeout_first", False)) + "\nALWAYS=" + repr(getattr(self, "always_timeout", False)) + "\n"
        fields = {"$.project_root": "1 line\n\n/testbed",
                  "$.languages": '3 lines\n\n[\n  "python"\n]'}
        fields.update(getattr(self, "status_overrides", {}))
        prefix += "BUFFERED=" + repr(getattr(self, "buffered_status", False)) + "\n"
        prefix += "HANDLE=" + repr(getattr(self, "buffer_handle", "@tool_0123abcd")) + "\nFIELDS=" + repr(fields) + "\n"
        self.last_proc = self.real_popen([sys.executable, "-I", "-u", "-c", prefix + script], **kwargs)
        return self.last_proc

    def docker(self, *args, **kwargs):
        if args[0] == "inspect":
            row = {"Id": "b" * 64, "Image": self.cfg["native_image"],
                   "Config": {"Labels": {"codescout.hfa": self.name}}}
            return SimpleNamespace(returncode=0, stdout=json.dumps([row]), stderr="")
        if args[0] == "exec" and "index" in args:
            self.index_calls += 1
            if not self.keep_stale_head:
                (self.knowledge / "index-state.json").write_text(json.dumps({"last_indexed_commit": self.head}))
            return SimpleNamespace(returncode=0 if self.index_success else 1, stdout="index result", stderr="")
        if args[0] == "exec" and "sha256sum" in args:
            return SimpleNamespace(returncode=0, stdout="c" * 64 + "  /bench/bin/codescout\n", stderr="")
        if args[0] == "rm":
            self.removed = True
            return SimpleNamespace(returncode=0, stdout="", stderr="")
        raise AssertionError(args)

    def run_external(self, argv, **kwargs):
        self.assertEqual(argv[:2], ["docker", "inspect"])
        if self.removed:
            return SimpleNamespace(returncode=1, stdout="", stderr="Error: No such object: " + self.name)
        return self.docker(*argv[1:])

    def measure(self):
        argv = ["docker", "run", "--name", "placeholder", "--label", "codescout.hfa=placeholder",
                self.cfg["native_image"], "start", "--project", "/testbed"]
        with patch.object(qualification, "_docker", self.docker), \
             patch.object(qualification.subprocess, "Popen", self.popen), \
             patch.object(qualification.subprocess, "run", self.run_external):
            return qualification._readiness(self.out, argv, self.actor, self.source, self.cfg)

    def test_buffered_workspace_status_is_reopened_in_the_same_stdio_session(self):
        # Removing live buffer retrieval must reject this otherwise valid clone.
        self.buffered_status = True
        proof = self.measure()
        self.assertTrue(proof["wire"]["status"]["result"]["content"][0]["text"].startswith('{"output_id"'))
        self.assertTrue(json.loads((self.out / "readiness.json").read_text())["result"]["ready"])
        calls = json.loads((self.out / "readiness-calls.json").read_text())
        queries = [call["params"]["arguments"] for call in calls
                   if call["method"] == "tools/call" and call["params"].get("name") == "read_file"]
        self.assertEqual(queries, [{"path": "@tool_0123abcd", "json_path": "$.project_root"},
                                  {"path": "@tool_0123abcd", "json_path": "$.languages"}])
        self.assertTrue(self.removed)

    def test_buffered_workspace_fields_cannot_hide_wrong_project_or_languages(self):
        self.buffered_status = True
        self.status_overrides = {"$.project_root": "1 line\n\n/another"}
        with self.assertRaisesRegex(ValueError, "wrong active project root"):
            self.measure()
        self.assertTrue(self.removed)

    def test_buffered_workspace_languages_are_validated_after_retrieval(self):
        self.buffered_status = True
        self.status_overrides = {"$.languages": '3 lines\n\n[\n  "rust"\n]'}
        with self.assertRaisesRegex(ValueError, "expected source languages not active"):
            self.measure()
        self.assertTrue(self.removed)

    def test_buffered_workspace_partial_field_cannot_qualify(self):
        self.buffered_status = True
        self.status_overrides = {"$.languages": '3 lines\n\n[\n  "python"\n]\n[3 of 9 lines shown]'}
        with self.assertRaisesRegex(ValueError, "incomplete buffered project status field"):
            self.measure()
        self.assertTrue(self.removed)
    def test_filesystem_shaped_buffer_reference_is_refused_before_retrieval(self):
        self.buffered_status = True
        self.buffer_handle = "/tmp/status.json"
        with self.assertRaisesRegex(ValueError, "invalid buffered project status reference"):
            self.measure()
        calls = json.loads((self.out / "readiness-calls.json").read_text())
        self.assertFalse(any(call.get("params", {}).get("name") == "read_file" for call in calls))
        self.assertTrue(self.removed)

    def test_independent_readback_rejects_tampered_buffer_retrieval_provenance(self):
        self.buffered_status = True
        proof = self.measure()
        for fault in ("query", "selector", "rendered-prefix", "language-type", "line-count", "inline-resolution"):
            with self.subTest(fault=fault):
                wire = copy.deepcopy(proof["wire"])
                if fault == "query":
                    wire["status_resolution"][0]["arguments"]["path"] = "@tool_deadbeef"
                elif fault == "selector":
                    wire["status_resolution"][0]["arguments"]["json_path"] = "$.unrelated"
                elif fault == "inline-resolution":
                    wire["status"] = {"result": {"content": [{"type": "text", "text":
                        '{"project_root":"/testbed","languages":["python"]}'}]}}
                else:
                    position = 0 if fault == "rendered-prefix" else 1
                    block = wire["status_resolution"][position]["response"]["result"]["content"][0]
                    block["text"] = {"rendered-prefix": "/testbed",
                                     "language-type": '1 line\n\n{"python":true}',
                                     "line-count": '5 lines\n\n[\n  "python"\n]'}[fault]
                with self.assertRaises(ValueError):
                    qualification.validate_readiness(proof["expected"], wire, source=self.actor)
    def test_buffered_status_rejects_excess_error_or_noncanonical_text_evidence(self):
        self.buffered_status = True
        proof = self.measure()
        for fault in ("prefix", "oversize", "too-many-lines", "error-reply", "extra-record"):
            with self.subTest(fault=fault):
                wire = copy.deepcopy(proof["wire"])
                record = wire["status_resolution"][1]
                block = record["response"]["result"]["content"][0]
                if fault == "prefix":
                    wire["status_resolution"][0]["response"]["result"]["content"][0]["text"] = "noise\n1 line\n\n/testbed"
                elif fault == "oversize":
                    block["text"] = "1 line\n\n" + json.dumps(["python"] + ["x" * 1000] * 5)
                elif fault == "too-many-lines":
                    body = json.dumps(["python"] * 64, indent=2)
                    block["text"] = "66 lines\n\n" + body
                elif fault == "error-reply":
                    record["response"]["result"]["isError"] = True
                else:
                    wire["status_resolution"].append(copy.deepcopy(record))
                with self.assertRaises(ValueError):
                    qualification.validate_readiness(proof["expected"], wire, source=self.actor)

    def test_registered_public_operations_and_all_static_guidance_are_bound(self):
        proof = self.measure()
        self.assertEqual(proof["expected"]["probes"], self.cfg["registered_readiness"]["probes"])
        self.assertEqual(proof["expected"]["languages"], ["python"])
        self.assertEqual(proof["expected"]["binding"]["knowledge_sha256"], self.cfg["knowledge_sha256"])
        self.assertEqual(proof["expected"]["binding"]["source_snapshot_sha256"], receipts.input_digest(self.source))
        self.assertEqual(self.index_calls, 0)
        self.assertTrue(self.removed)

    def test_changed_clone_runs_one_index_and_proves_new_head(self):
        self.cfg["index_update_required"] = True
        (self.knowledge / "index-state.json").unlink()
        self.measure()
        self.assertEqual(self.index_calls, 1)
        binding = json.loads((self.out / "index-commit-binding.json").read_bytes())
        self.assertEqual(binding["last_indexed_commit"], self.head)
        self.assertTrue(self.removed)

    def test_index_failure_or_stale_head_cannot_qualify(self):
        self.cfg["index_update_required"] = True
        self.index_success = False
        with self.assertRaises(ValueError):
            self.measure()
        self.assertEqual(self.index_calls, 1)
        self.assertTrue(self.removed)

    def test_skipped_index_with_wrong_head_is_not_implicit_reuse(self):
        (self.knowledge / "index-state.json").write_text(json.dumps({"last_indexed_commit": "0" * 40}))
        with self.assertRaises(ValueError):
            self.measure()
        self.assertEqual(self.index_calls, 0)
        self.assertTrue(self.removed)

    def test_raw_guidance_drift_refuses_before_native_launch(self):
        (self.knowledge / "memories/raw.md").write_text("changed guidance")
        with self.assertRaises(ValueError):
            self.measure()
        self.assertEqual(self.launched, [])

    def test_partial_registered_contract_does_not_fall_back_to_fixture_canaries(self):
        self.cfg.pop("knowledge_sha256")
        with self.assertRaises(ValueError):
            self.measure()
        self.assertEqual(self.launched, [])

    def test_failed_public_canary_is_retained_without_retry(self):
        self.witness = "no registered witness"
        with self.assertRaises(ValueError):
            self.measure()
        self.assertTrue(self.removed)
        calls = json.loads((self.out / "readiness-calls.json").read_bytes())
        self.assertEqual(sum(call["method"] == "tools/call" and call["params"]["name"] == "references"
                             for call in calls), 1)
    def test_stdout_pipe_is_closed_even_when_readiness_is_rejected(self):
        self.witness = "no registered witness"
        with self.assertRaises(ValueError):
            self.measure()
        self.assertTrue(self.last_proc.stdout.closed)
    def test_explicit_one_startup_timeout_retry_preserves_both_actual_replies(self):
        self.cfg["lsp_warmup_retries"] = 1
        self.timeout_first = True
        self.measure()
        calls = json.loads((self.out / "readiness-calls.json").read_bytes())
        refs = [r for r in calls if r["method"] == "tools/call" and r["params"]["name"] == "references"]
        self.assertEqual(len(refs), 2)
        self.assertIn("timed out", refs[0]["response"]["result"]["content"][0]["text"])
        self.assertIn("public-operation-witness", refs[1]["response"]["result"]["content"][0]["text"])
        retries = json.loads((self.out / "readiness-warmup-retries.json").read_bytes())
        self.assertEqual(len(retries), 1)
        self.assertEqual(retries[0]["prior_response"], refs[0]["response"])
        self.assertEqual(retries[0]["retry_response"], refs[1]["response"])

    def test_repeated_timeout_is_not_an_unbounded_startup_retry(self):
        self.cfg["lsp_warmup_retries"] = 1
        self.always_timeout = True
        with self.assertRaises(ValueError):
            self.measure()
        calls = json.loads((self.out / "readiness-calls.json").read_bytes())
        self.assertEqual(sum(r["method"] == "tools/call" and r["params"]["name"] == "references"
                             for r in calls), 2)
        self.assertTrue(self.removed)

    def test_opted_in_startup_handling_does_not_retry_other_canary_failures(self):
        self.cfg["lsp_warmup_retries"] = 1
        self.witness = "no registered witness"
        with self.assertRaises(ValueError):
            self.measure()
        calls = json.loads((self.out / "readiness-calls.json").read_bytes())
        self.assertEqual(sum(r["method"] == "tools/call" and r["params"]["name"] == "references"
                             for r in calls), 1)

    def test_startup_retry_bound_is_explicit_integer_zero_or_one(self):
        for index, limit in enumerate((True, -1, 2, 1.0, "1", None)):
            with self.subTest(limit=limit):
                self.out = self.root / ("bound-" + str(index))
                self.out.mkdir()
                self.launched = []
                self.removed = False
                self.cfg["lsp_warmup_retries"] = limit
                with self.assertRaises(ValueError):
                    self.measure()
                self.assertEqual(self.launched, [])


if __name__ == "__main__":
    unittest.main()
