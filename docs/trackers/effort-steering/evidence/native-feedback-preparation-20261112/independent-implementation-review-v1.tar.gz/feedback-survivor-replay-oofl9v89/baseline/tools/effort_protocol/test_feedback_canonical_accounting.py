"""Concrete canonical history checks at the prospective feedback admission wrapper."""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

import feedback_admission


class CanonicalFeedbackAccountingTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.reg = {"bindings": {}}

    def save(self, name, value):
        path = self.base / name
        path.write_text(json.dumps(value))
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        self.reg["bindings"][str(path)] = digest
        return {"path": str(path), "sha256": digest}

    def receipt_row(self, pointer, identity, **fields):
        return {"id": identity, "source": pointer["path"], "receipt_sha256": pointer["sha256"], **fields}

    def hold(self, identity):
        pointer = self.save(identity + ".json", {"session_id": identity, "scripted": False,
            "unknown_provider_cost": True, "cost_usd": None, "requests": 0, "forwarded": 0,
            "campaign_available_usd": "4"})
        return self.receipt_row(pointer, "native-client:" + identity,
                                cost_usd=None, reserved_usd="4", settled=False)

    def prepare(self, *, allocation="112", changed_original_hold=False):
        opening = self.save("opening.json", {"prior_campaign_spend_usd": "5"})
        charges = [self.receipt_row(opening, "recorded-pre-native-opening-balance", cost_usd="5")]
        for index in range(48):
            identity = "paid-" + str(index)
            pointer = self.save(identity + ".json", {"session_id": identity, "scripted": False,
                "unknown_provider_cost": False, "cost_usd": "0.25"})
            charges.append(self.receipt_row(pointer, "native-client:" + identity, cost_usd="0.25"))
        held = self.hold("legacy")
        ledger = {"ceiling_usd": "200", "charges": charges, "holds": [held], "reservations": []}
        self.reg["ledger"] = copy.deepcopy(ledger)
        self.reg["carried_holds"] = [{key: held[key] for key in
                                     ("id", "source", "receipt_sha256", "reserved_usd")}]
        old = copy.deepcopy(ledger)
        zero = self.save("shared-zero.json", {"cost_usd": "0"})
        old["charges"].append(self.receipt_row(zero, "old-shared-zero", cost_usd="0"))
        if changed_original_hold:
            old["holds"] = [self.hold("different-original-hold")]
        original = self.save("original-ledger.json", old)
        history = self.save("history.json", {
            "schema": "client-session-reconciliation-audit-v2", "native_receipts": 48,
            "canonical_charges": charges[1:], "historical_opening": charges[0],
            "holds_unchanged": ledger["holds"], "known_client_cost_usd": "17.00",
            "original_ledger": original["path"], "original_ledger_sha256": original["sha256"],
            "original_row_mappings": [{"ledger_id": row["id"]} for row in old["charges"]],
            "shared_zero_evidence": [zero]})
        previous = self.save("closed-audit.json", {"bindings": {}})
        anchor = self.save("anchor.json", {"schema": "client-session-reconciliation-anchor-v1",
            "reconciliation": history["path"], "reconciliation_sha256": history["sha256"],
            "closed_audit": previous["path"], "closed_audit_sha256": previous["sha256"]})
        return self.save("reconciliation.json", {
            "schema": "client-ledger-reconciliation-v1", "ledger": ledger,
            "opening_balance_source": opening["path"], "opening_balance_sha256": opening["sha256"],
            "opening_balance_usd": "5", "known_client_cost_usd": "17.00", "native_receipts": 48,
            "native_client_cost_usd": "12.00", "unresolved_reserve_usd": "4",
            "proposed_new_allocation_usd": allocation,
            "commitment_if_new_allocation_usd": "133.00" if allocation == "112" else "99.00",
            "receipt_bindings": {row["source"]: row["receipt_sha256"] for row in charges[1:] + ledger["holds"]},
            "canonical_history": history, "history_anchor": anchor})

    def test_feedback_wrapper_admits_112_with_all_48_receipts_and_original_hold(self):
        result = feedback_admission.verify_accounting(self.reg, self.prepare())
        self.assertEqual(result["commitment_if_new_allocation_usd"], "133.00")
        self.assertEqual(result["native_receipts"], 48)
        self.assertEqual(result["unsettled_hold_ids"], ["native-client:legacy"])

    def test_feedback_wrapper_rejects_obsolete_78_allocation(self):
        proof = self.prepare(allocation="78")
        with self.assertRaisesRegex(ValueError, "proposed commitment changed"):
            feedback_admission.verify_accounting(self.reg, proof)

    def test_equal_four_dollar_amount_cannot_replace_original_unknown_session(self):
        proof = self.prepare(changed_original_hold=True)
        with self.assertRaisesRegex(ValueError, "original historical row or unknown reserve"):
            feedback_admission.verify_accounting(self.reg, proof)
