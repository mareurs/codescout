from pathlib import Path
import json
root=Path(__file__).parent
mutations=[]
def add(ident,area,old,new,file='readiness.py'):
 mutations.append({'id':ident,'file':file,'area':area,'old':old,'new':new})
add('F01','malformed buffer handle', 're.fullmatch(r"@tool_[0-9a-f]{8,64}", handle)', 'bool(handle)')
add('F02','recorded query identity', 'and item["arguments"] == query, "buffered project status query mismatch")', 'and True, "buffered project status query mismatch")')
add('F03','unanchored framed reply', 'frame = re.fullmatch(r"([1-9][0-9]*) lines?\\n\\n([\\s\\S]*)", text)', 'frame = re.search(r"([1-9][0-9]*) lines?\\n\\n([\\s\\S]*)", text)')
add('F04','encoded byte limit', 'frame is not None and len(text.encode()) <= 4096', 'frame is not None')
add('F05','maximum rendered line count', 'count <= 64 and len(content.splitlines()) == count', 'len(content.splitlines()) == count')
add('F06','rendered body line count agreement', 'count <= 64 and len(content.splitlines()) == count', 'count <= 64')
add('F07','single-line root contract', '_require(count == 1, "incomplete buffered project status field")', '_require(True, "incomplete buffered project status field")')
add('F08','language container normalized before type check', 'status[field] = json.loads(content)', 'status[field] = list(json.loads(content))')
add('F09','MCP error check at new consuming call site', 'text = _texts(item["response"])[0]', 'text = item["response"]["result"]["content"][0]["text"]')
add('F10','inline status cannot carry synthetic resolution', '_require("status_resolution" not in wire, "unexpected project status resolution")', '_require(True, "unexpected project status resolution")')
add('F11','both fields actually requested', 'for field in ("project_root", "languages"):', 'for field in ("project_root",):', 'qualify_native.py')
add('F12','extra resolution records rejected', 'isinstance(resolution, list) and len(resolution) == 2', 'isinstance(resolution, list) and len(resolution) >= 2')
for m in mutations:
 data=(root/'baseline/tools/effort_protocol'/m['file']).read_text()
 assert data.count(m['old'])==1,(m['id'],data.count(m['old']))
(root/'mutations.json').write_text(json.dumps(mutations,indent=2)+'\n')
old=Path('/tmp/native-feedback-delta-review-rm85nlq6/run_mutations.py').read_text()
(root/'run_mutations.py').write_text(old.replace('==117','==119'))
print('prepared',len(mutations),'separate-copy mutations')
