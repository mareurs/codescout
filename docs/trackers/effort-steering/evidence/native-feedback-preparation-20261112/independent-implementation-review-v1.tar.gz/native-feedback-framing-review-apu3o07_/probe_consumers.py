from pathlib import Path
import copy,hashlib,json,sys
root=Path(__file__).parent
which,case=sys.argv[1:]
sys.path[:0]=[str(root/which/'tools'/name) for name in ('effort_protocol','agent_lifecycle','hint_authority_pilot')]
import readiness
from test_registered_readiness import RegisteredReadinessTests
fixture=RegisteredReadinessTests();fixture.setUp();fixture.buffered_status=True
try:
 proof=fixture.measure();wire=copy.deepcopy(proof['wire']);expected=copy.deepcopy(proof['expected'])
 def frame(index,body):wire['status_resolution'][index]['response']['result']['content'][0]['text']=str(len(body.splitlines()))+' lines\n\n'+body
 result={'copy':which,'case':case}
 if case.startswith('recorded:'):
  project=case.split(':',1)[1]
  path=Path('/var/tmp/native-feedback-readiness-buffers-v1-01a15')/project/'readiness/readiness-calls.json'
  calls=json.loads(path.read_text())
  status=[row for row in calls if row.get('params',{}).get('name')=='workspace' and row['params']['arguments'].get('action')=='status'][-1]
  fields=[row for row in calls if row.get('params',{}).get('name')=='read_file']
  wire['status']=status['response'];wire['status_resolution']=[{'arguments':row['params']['arguments'],'response':row['response']} for row in fields]
  expected['languages']=['rust']
  result.update(recording=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),scope='actual status and retrieval responses; otherwise synthetic valid readiness context, registered rust language')
 elif case=='F03':wire['status_resolution'][0]['response']['result']['content'][0]['text']='UNTRUSTED PREFIX\n'+wire['status_resolution'][0]['response']['result']['content'][0]['text']
 elif case=='F04':frame(1,json.dumps(['python','a'*4100],indent=2))
 elif case=='F05':frame(1,json.dumps(['python']*65,indent=2))
 elif case in ('F07','F07-altered-registration'):
  frame(0,'/testbed\nextra')
  if case.endswith('registration'):expected['project_root']='/testbed\nextra'
 elif case=='F08':frame(1,json.dumps({'python':True}))
 elif case=='F09':wire['status_resolution'][1]['response']['result']['isError']=True
 elif case=='F12':wire['status_resolution'].append(copy.deepcopy(wire['status_resolution'][-1]))
 else:raise RuntimeError(case)
 try:
  value=readiness.validate_readiness(expected,wire,source=fixture.actor)
  result.update(accepted=True,ready=value['ready'],project_root=value['project_root'],language_count=len(value['languages']))
 except Exception as exc:result.update(accepted=False,error=type(exc).__name__+': '+str(exc))
 print(json.dumps(result))
finally:fixture.doCleanups()
