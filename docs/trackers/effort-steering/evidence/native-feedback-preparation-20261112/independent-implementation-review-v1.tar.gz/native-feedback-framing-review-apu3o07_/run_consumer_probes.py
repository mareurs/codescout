from pathlib import Path
import json,os,subprocess
root=Path(__file__).parent
cases=[('baseline','recorded:'+name) for name in ('DioxusLabs__dioxus-5384','nearai__ironclaw-6724')]
for case in ('F03','F04','F05','F07','F07-altered-registration','F08','F09','F12'):
 cases.extend([('baseline',case),(case.split('-')[0],case)])
results=[]
for which,case in cases:
 run=subprocess.run(['python3','-B',str(root/'probe_consumers.py'),which,case],env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TMPDIR='/var/tmp'),capture_output=True,text=True)
 row={'exit':run.returncode,'stderr':run.stderr}
 try:row.update(json.loads(run.stdout))
 except ValueError:row['stdout']=run.stdout
 results.append(row)
(root/'consumer-probe-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
