from pathlib import Path
import hashlib,json,re
root=Path(__file__).parent;src=Path('/home/marius/.codex/worktrees/2aa6/codescout')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=json.loads((root/'custody-before.json').read_text())
custody={'scratch_baseline_changes':[],'current_source_changes':[]}
for name,value in before.items():
 p=root/'baseline'/name
 if not p.exists() or sha(p)!=value:custody['scratch_baseline_changes'].append(name)
 p=src/name
 if p.exists() and sha(p)!=value:custody['current_source_changes'].append(name)
(root/'custody-after.json').write_text(json.dumps(custody,indent=2)+'\n')
results=json.loads((root/'mutation-results.json').read_text())
probes=json.loads((root/'consumer-probe-results.json').read_text())
report={
 'snapshot':'Only readiness.py and test_registered_readiness.py replaced relative to prior delta scratch; complete runtime import layout retained',
 'baseline':json.loads((root/'baseline-result.json').read_text()),
 'mutation_counts':{'applied':len(results),'killed':sum(r['verdict']=='KILLED' for r in results),'survived':sum(r['verdict']=='SURVIVED' for r in results),'inconclusive':sum(r['verdict']=='INCONCLUSIVE' for r in results)},
 'real_recording_replay':{'accepted':2,'rejected':0,'scope':'Unmodified recorded workspace-status and read_file responses, otherwise valid synthetic readiness context with expected rust; validates parser, not actual entire project readiness'},
 'important_test_gaps':[
  {'mutations':['F08','F09'],'file':'tools/effort_protocol/readiness.py','lines':[91,102],'finding':'Language-shape and MCP-error discipline at new consumer are not pinned','observed':'All119 pass when list(json.loads(content)) accepts a dict keyed by expected python; all119 pass when new read_file consumer skips _texts. Real validate_readiness then accepts dictionary-as-languages or isError:true respectively; baseline rejects.','test_quality':'Existing language-type negative uses rust while fixture requires python, so independent expected-language check masks shape relaxation.'},
  {'mutations':['F03','F04','F05','F12'],'file':'tools/effort_protocol/readiness.py','lines':[81,92,93,96],'finding':'Exact framing, byte/line caps and exactly-two retrieval records lack consuming negative cases','observed':'Each mutation leaves119 green; real validate_readiness accepts a prepended prefix, over4096-byte body, over64-line body, or ignored third retrieval record respectively; baseline rejects all four.'}
 ],
 'nonblocking_survivor':{'id':'F07','finding':'Single-line-root guard is redundant in this fixed-root campaign','observed':'With unchanged expected /testbed, baseline and mutant reject a multiline root; mutant accepts only when expected registration also changes to that same multiline path. No campaign bypass demonstrated.'},
 'resolved_prior_findings':[
  'Public MCP renderer framing mismatch: both actual raw recorded cases now accepted.',
  'D01 malformed handle, D02 query identity, D07 inline synthetic resolution: corresponding F01/F02/F10 killed with119tests.',
  'Prior four M01/M15/M17/M18 corrections remain unchanged; independently killed against preceding117-test snapshot. No claim of fresh replay of those mutations in this119snapshot.'
 ],
 'remaining_api_limits':[
  'Parses only complete first textual read_file block with measured line-count framing; rejects pagination/truncation/notices or future renderer changes.',
  'Each field is capped at4096 encoded bytes and64 rendered body lines; project_root must be one line. These are admission-profile limits, not general read_file API capability.',
  'Public rendered response has no selector/type/count metadata; selector provenance is from trusted captured request arguments in same RPC session, not echoed in response.',
  'Successful actual-status replay used synthetic remaining binding/index/probe context; complete native project readiness is not inferred from it.'
 ],
 'declined_to_judge':[
  'Any later source/test edits after this snapshot; none replayed without explicit request.',
  'Actual16 CLI qualification completion/full project gate; root owns those runs.',
  'Skipped suites and unexecuted provider behavior; no live server/actor/provider invoked by reviewer.',
  'Financial review compute costs or efficacy; cost unknown and no paid efficacy evidence.'
 ],
 'verdict':'Framing correctness defect repaired at reviewed parser boundary. Conditional implementation readiness still has Important observed regression gaps in six mutations; no merge/publication approval and no actual qualification/gate claim.',
 'custody':custody
}
(root/'review-report.json').write_text(json.dumps(report,indent=2)+'\n')
manifest={p.name:sha(p) for p in root.iterdir() if p.is_file() and p.name!='evidence-manifest.json'}
(root/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'report':str(root/'review-report.json'),'report_sha256':sha(root/'review-report.json'),'manifest_sha256':sha(root/'evidence-manifest.json'),'custody':custody},indent=2))
