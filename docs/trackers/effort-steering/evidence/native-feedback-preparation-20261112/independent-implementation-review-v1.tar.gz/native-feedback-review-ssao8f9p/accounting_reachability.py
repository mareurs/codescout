from pathlib import Path
import copy,hashlib,json,sys
root=Path(__file__).parent
which,case=sys.argv[1:]
sys.path[:0]=[str(root/which/'tools'/name) for name in ('effort_protocol','agent_lifecycle','hint_authority_pilot')]
import feedback_admission
base=root/('accounting-'+which+'-'+case);base.mkdir()
reg={'bindings':{}}
def save(name,value):
 p=base/name;p.write_text(json.dumps(value));digest=hashlib.sha256(p.read_bytes()).hexdigest();reg['bindings'][str(p)]=digest;return {'path':str(p),'sha256':digest}
def row(pointer,id,**fields):
 return {'id':id,'source':pointer['path'],'receipt_sha256':pointer['sha256'],**fields}
opening=save('opening.json',{'prior_campaign_spend_usd':'5'})
charges=[row(opening,'recorded-pre-native-opening-balance',cost_usd='5')]
for i in range(48):
 id='paid-'+str(i);p=save(id+'.json',{'session_id':id,'scripted':False,'unknown_provider_cost':False,'cost_usd':'0.25'})
 charges.append(row(p,'native-client:'+id,cost_usd='0.25'))
def hold(id):
 p=save(id+'.json',{'session_id':id,'scripted':False,'unknown_provider_cost':True,'cost_usd':None,'requests':0,'forwarded':0,'campaign_available_usd':'4'})
 return row(p,'native-client:'+id,cost_usd=None,reserved_usd='4',settled=False)
h=hold('legacy')
ledger={'ceiling_usd':'200','charges':charges,'holds':[h],'reservations':[]}
reg['ledger']=copy.deepcopy(ledger);reg['carried_holds']=[{k:h[k] for k in ('id','source','receipt_sha256','reserved_usd')}]
old=copy.deepcopy(ledger);zero=save('shared-zero.json',{'cost_usd':'0'})
old['charges'].append(row(zero,'old-shared-zero',cost_usd='0'))
if case=='changed-old-hold': old['holds']=[hold('different-original-hold')]
oldp=save('original-ledger.json',old)
history={'schema':'client-session-reconciliation-audit-v2','native_receipts':48,'canonical_charges':charges[1:],'historical_opening':charges[0],'holds_unchanged':ledger['holds'],'known_client_cost_usd':'17.00','original_ledger':oldp['path'],'original_ledger_sha256':oldp['sha256'],'original_row_mappings':[{'ledger_id':r['id']} for r in old['charges']],'shared_zero_evidence':[zero]}
hp=save('history.json',history);previous=save('closed-audit.json',{'bindings':{}})
anchor=save('anchor.json',{'schema':'client-session-reconciliation-anchor-v1','reconciliation':hp['path'],'reconciliation_sha256':hp['sha256'],'closed_audit':previous['path'],'closed_audit_sha256':previous['sha256']})
allocation='78' if case=='legacy-allocation' else '112';commitment='99.00' if allocation=='78' else '133.00'
reconciled={'schema':'client-ledger-reconciliation-v1','ledger':ledger,'opening_balance_source':opening['path'],'opening_balance_sha256':opening['sha256'],'opening_balance_usd':'5','known_client_cost_usd':'17.00','native_receipts':48,'native_client_cost_usd':'12.00','unresolved_reserve_usd':'4','proposed_new_allocation_usd':allocation,'commitment_if_new_allocation_usd':commitment,'receipt_bindings':{r['source']:r['receipt_sha256'] for r in charges[1:]+ledger['holds']},'canonical_history':hp,'history_anchor':anchor}
proof=save('reconciliation.json',reconciled)
try:
 result=feedback_admission.verify_accounting(reg,proof);print(json.dumps({'copy':which,'case':case,'accepted':True,'result':result}))
except Exception as e: print(json.dumps({'copy':which,'case':case,'accepted':False,'error':type(e).__name__+': '+str(e)}))
