"""Versioned leaf proof checks; real JSON/hash/filesystem contracts, no paid actors."""
import copy
import json
from pathlib import Path
import unittest
from unittest.mock import patch

import campaign
import feedback_policy as policy
import paid_admission as subject
import test_paid_admission as fixtures
from receipts import input_digest


class FeedbackPopulationTests(unittest.TestCase):
    setUp = fixtures.PopulationAdmissionTests.setUp
    seal = fixtures.PopulationAdmissionTests.seal

    def prepare_four(self):
        metadata = json.loads(self.payloads["metadata.json"])["tasks"]
        metadata.append(dict(metadata[0], id="task4", repo="org/repo4", public_issue_sha256="5" * 64))
        status = {r["id"]: {"eligible": True, "reason": "source-qualified"} for r in metadata}
        rule = {"seed": self.reg["seed"], "task_count": 4}
        effective = [{**r, **status[r["id"]]} for r in metadata]
        selected = campaign.selection_report(effective, {"task3"}, self.reg["seed"], task_count=4)
        data = {"metadata.json": {"tasks": metadata}, "status.json": status, "rule.json": rule,
                "selection.json": selected, "freeze.json": {
                    "selection": selected, "selection_rule": rule,
                    "selected_ids": [r["id"] for r in selected["selected"]],
                    "private_outcomes_read": False, "replacement_after_private_outcomes": False,
                    "experimental_model_calls": 0}}
        self.payloads.update({name: (json.dumps(value) + "\n").encode() for name, value in data.items()})
        self.reg.update(schema=policy.SCHEMA, metadata=effective, selected=selected["selected"])
        self.seal()

    def test_four_task_population_is_reproduced_without_changing_legacy_quota(self):
        self.prepare_four()
        result = subject.verify_population(self.reg, self.proof, task_count=4)
        self.assertEqual(len(result["selected_ids"]), 4)
        self.assertEqual(result["metadata_tasks"], 5)
        self.assertNotIn("task3", result["selected_ids"])
        self.assertEqual(len(campaign.selection_report(self.reg["metadata"], {"task3"},
                                                      self.reg["seed"])["selected"]), 2)

    def test_two_task_freeze_cannot_be_read_as_four(self):
        with self.assertRaises(ValueError):
            subject.verify_population(self.reg, self.proof, task_count=4)


class FeedbackAccountingTests(unittest.TestCase):
    setUp = fixtures.AccountingAdmissionTests.setUp
    seal = fixtures.AccountingAdmissionTests.seal

    def test_112_allocation_uses_actual_known_cost_and_old_unknown_hold(self):
        self.reconciled["proposed_new_allocation_usd"] = "112"
        self.reconciled["commitment_if_new_allocation_usd"] = "121.25"
        self.seal()
        result = subject.verify_accounting(self.reg, self.proof, allocation_usd="112")
        self.assertEqual(result["commitment_if_new_allocation_usd"], "121.25")
        self.assertEqual(result["unresolved_reserve_usd"], "4")
        self.assertEqual(result["native_receipts"], 1)

    def test_legacy_78_evidence_cannot_authorize_112(self):
        with self.assertRaises(ValueError):
            subject.verify_accounting(self.reg, self.proof, allocation_usd="112")


class FeedbackNativeProofTests(unittest.TestCase):
    setUp = fixtures.NativeInvocationAdmissionTests.setUp
    seal = fixtures.NativeInvocationAdmissionTests.seal

    def prepare_feedback(self, arm="P"):
        selected = policy.condition_spec(arm, ".")
        self.reg["schema"] = policy.SCHEMA
        self.intent.update(arm=arm, phase="repair", effort=selected["effort"], max_continuations=4,
                           feedback_policy=selected, allowance_usd=selected["reserve_usd"],
                           public_packet={"issue": "Public issue"})
        self.public["feedback_policy"] = {"schema": policy.SCHEMA, "workspace": "."}
        prompt = ("Public issue\n\nFrozen public packet:\n" + json.dumps(self.intent["public_packet"], sort_keys=True)
                  + "\n\n" + selected["common_instruction"])
        if selected["plan_instruction"]:
            prompt += "\n\n" + selected["plan_instruction"]
        self.raw["native/prepared.json"].update(
            max_continuations=4, feedback_policy=selected, prompt=prompt,
            checks=[{"id": "public-feedback-compile", "command": "cargo check --offline --workspace" +
                     (" --all-targets" if arm in ("P", "X") else "")}])
        self.raw["native/native-executor.json"]["context_evidence"]["feedback_prompt_delivered"] = True
        self.raw["native/native-executor.json"]["workflow_completed"] = True
        self.raw["native/receipt.json"].update(workflow_completed=True,
                                               public_verification={"status": "completed", "passed": True})
        self.raw["native/request-0.json"]["messages"].append(
            {"role": "user", "content": [{"type": "text", "text": prompt}]})
        self.seal()

    def invoke_feedback(self):
        with patch.object(subject, "validate_readiness", return_value={"ready": True}):
            return subject.verify_native_invocation(self.reg, self.root, self.intent, self.public, feedback=True)

    def test_repair_only_context_scope_and_four_continuations_are_reopened(self):
        self.prepare_feedback()
        self.assertEqual(self.invoke_feedback()["max_continuations"], 4)

    def test_self_declared_context_cannot_hide_absent_prompt_or_noop_check(self):
        self.prepare_feedback()
        original = copy.deepcopy(self.raw)
        for change in ("check", "prompt", "continuations", "context", "completion"):
            self.raw = copy.deepcopy(original)
            if change == "check":
                self.raw["native/prepared.json"]["checks"][0]["command"] = "true"
            elif change == "prompt":
                self.raw["native/request-0.json"]["messages"].pop()
            elif change == "continuations":
                self.raw["native/prepared.json"]["max_continuations"] = 2
            elif change == "context":
                self.raw["native/native-executor.json"]["context_evidence"]["feedback_prompt_delivered"] = False
            else:
                self.raw["native/receipt.json"]["workflow_completed"] = False
            self.seal()
            with self.subTest(change=change), self.assertRaises(ValueError):
                self.invoke_feedback()


class FeedbackRuntimeProofTests(unittest.TestCase):
    setUp = fixtures.RuntimeAdmissionTests.setUp
    bind = fixtures.RuntimeAdmissionTests.bind
    write = fixtures.RuntimeAdmissionTests.write

    def prepare_sixteen(self):
        old_tasks = list(self.reg["tasks"].values())
        metadata = []
        for index in range(4):
            identity = "task" + str(index)
            if identity not in self.reg["tasks"]:
                source = self.base / identity
                source.mkdir()
                (source / "code.rs").write_text("pub fn f() {}")
                self.reg["tasks"][identity] = dict(copy.deepcopy(old_tasks[0]), source=str(source),
                                                   source_sha256=input_digest(source))
            self.reg["tasks"][identity]["backend"]["public"]["feedback_policy"] = {
                "schema": policy.SCHEMA, "workspace": "."}
            metadata.append({"id": identity, "repo": "org/repo" + str(index)})
        self.reg["schema"] = policy.SCHEMA
        self.reg["selected"] = metadata
        schedule = []
        for row in policy.balanced_schedule([r["id"] for r in metadata], 101):
            config = policy.condition_spec(row["arm"], ".")
            schedule.append(dict(row, cli_cap_usd=config["cli_cap_usd"], reserved_usd=config["reserve_usd"]))
        self.reg["schedule"] = schedule
        self.root = self.base / "qualified-feedback"
        self.root.mkdir()
        self.proof = {"root": str(self.root), "producer": self.bind(self.producer)}
        qualified = {"schema": policy.SCHEMA, "mode": "scripted", "campaign_id": "qualification",
                     "selected": metadata, "schedule": schedule, "tasks": copy.deepcopy(self.reg["tasks"]),
                     "bindings": {str(self.frozen): self.reg["bindings"][str(self.frozen)]},
                     "qualification_driver": self.proof["producer"]}
        closed, attempts = {"attempts": []}, []
        for index, attempt in enumerate(schedule):
            directory = self.root / "attempts" / (str(index).zfill(2) + "-" + attempt["arm"])
            phase_root = directory / "repair"
            phase_root.mkdir(parents=True)
            candidate = directory / "candidate"
            candidate.mkdir()
            (candidate / "code.rs").write_text("pub fn f() {}")
            selected = policy.condition_spec(attempt["arm"], ".")
            intent = {"invocation_id": "qualification::" + str(index) + "::repair",
                      "task_id": attempt["task_id"], "arm": attempt["arm"], "phase": "repair",
                      "cli_cap_usd": attempt["cli_cap_usd"], "allowance_usd": attempt["reserved_usd"],
                      "feedback_policy": selected, "max_continuations": 4, "effort": selected["effort"]}
            record = {"native_path": str(phase_root / "native"), "capture_complete": True}
            self.write(phase_root / "intent.json", intent)
            self.write(phase_root / "invocation.json", record)
            row = {"attempt_index": index, "arm": attempt["arm"], "task_id": attempt["task_id"],
                   "attempt_receipt": str(directory / "attempt.json"), "workflow_state": "closed",
                   "measurement_invalid": False, "reason": None, "candidate": str(candidate),
                   "source_digest": input_digest(candidate), "invocations": [{
                       "record": record, "measurement_invalid": False,
                       "cost": {"known_usd": "0", "unknown": False}}], "grade": None}
            self.write(directory / "attempt.json", row)
            closed["attempts"].append({"attempt_receipt": row["attempt_receipt"],
                "receipt_sha256": self.reg["bindings"][row["attempt_receipt"]],
                "candidate": str(candidate), "source_digest": row["source_digest"]})
            grade_root = self.root / "grades" / str(index).zfill(2)
            grade_root.mkdir(parents=True)
            packet = {"source": str(candidate), "source_digest": row["source_digest"],
                      "config": "/private/config", "config_sha256": "c" * 64}
            self.write(grade_root / "private-request.json", packet)
            self.write(grade_root / "private-entry-started.json", {"entry_sha256": "e" * 64,
                "request_sha256": self.reg["bindings"][str(grade_root / "private-request.json")]})
            row["grade"] = {"valid": True, "pass": False}
            self.write(grade_root / "verdict.json", row["grade"])
            attempts.append(row)
        self.write(self.root / "ledger-final.json", {"charges": []})
        closed["ledger_sha256"] = self.reg["bindings"][str(self.root / "ledger-final.json")]
        for role, name, value in [
            ("registration", "registration.json", qualified),
            ("result", "result.json", {"status": "completed", "unexecuted": [], "attempts": attempts}),
            ("qualification", "runtime-qualification.json", {"attempts": 16, "native_invocations": 16,
                "private_evaluator_processes": 16, "provider_forwarded": 0, "all_workflows_closed": True,
                "efficacy_claim": None, "model_cost_usd": "0"}),
            ("closure", "actor-batch-closed.json", closed)]:
            self.write(self.root / name, value)
            self.proof[role] = self.bind(self.root / name)
        self.proof["ledger"] = self.bind(self.root / "ledger-final.json")
        self.prepare_protected_inputs()
        self.prepare_integrity_inputs()

    def prepare_protected_inputs(self):
        import hashlib
        import trusted_test_inputs as core
        for identity,task in self.reg["tasks"].items():
            canonical=self.base/("original-tests-"+identity)
            (canonical/"tests").mkdir(parents=True)
            (canonical/"tests/original.snap").write_text("original "+identity)
            trusted=core.seal_test_inputs(canonical,["tests"],self.base/("sealed-"+identity))
            for role in ("manifest","archive"):self.bind(Path(trusted[role]))
            helpers={}
            for name in ("evaluator_entry.py","trusted_test_inputs.py","feedback_trusted_inputs.py"):
                path=Path(subject.__file__).parent/name
                helpers[str(path)]=self.bind(path)["sha256"]
            config_path=self.base/("private-"+identity+".json")
            self.write(config_path,{"trusted_test_inputs":trusted,"bindings":helpers})
            private=task["backend"]["private"]
            private.update(config=str(config_path),config_sha256=self.reg["bindings"][str(config_path)])
            roots,entries,_=core._validated(trusted)
            checked={"complete":True,"roots":roots,"entries_verified":len(entries),
                     "manifest_sha256":trusted["manifest_sha256"],
                     "coverage":"Registered standalone inputs; no inline assertion claim"}
            for index,attempt in enumerate(self.reg["schedule"]):
                if attempt["task_id"]!=identity:continue
                grade=self.root/"grades"/str(index).zfill(2)
                packet=json.loads((grade/"private-request.json").read_bytes())
                packet.update(config=private["config"],config_sha256=private["config_sha256"])
                self.write(grade/"private-request.json",packet)
                self.write(grade/"private-entry-started.json",{"entry_sha256":"e"*64,
                    "request_sha256":self.reg["bindings"][str(grade/"private-request.json")]})
                remote=dict(trusted)
                for role in ("manifest","archive"):
                    remote[role]="/tmp/effort-trusted-12345678/"+Path(remote[role]).name
                cid=hashlib.sha256(str(index).encode()).hexdigest()
                installation={"container":cid,"helper":"/tmp/effort-trusted-12345678/trusted_test_inputs.py",
                    "helper_sha256":hashlib.sha256(Path(core.__file__).read_bytes()).hexdigest(),
                    "descriptor":remote,"restoration":checked}
                self.write(grade/"trusted-input-installation.json",installation)
                observations=grade/"runtime-observations.jsonl"
                observations.write_text(json.dumps({"stage":"before-remove","inspect":{"Id":cid},
                    "trusted_test_inputs":checked})+"\n")
                self.bind(observations)
        path=self.root/"registration.json"
        qualified=json.loads(path.read_bytes())
        qualified["tasks"]=copy.deepcopy(self.reg["tasks"])
        self.write(path,qualified)
        self.proof["registration"]=self.bind(path)
    def prepare_integrity_inputs(self):
        from feedback_assertion_audit import prepare_audit, verify_audit
        import trusted_test_inputs as core
        (self.root / "audits").mkdir()
        result_path = self.root / "result.json"
        result = json.loads(result_path.read_bytes())
        index_rows = []
        for index, row in enumerate(result["attempts"]):
            task = self.reg["tasks"][row["task_id"]]
            native = Path(row["attempt_receipt"]).parent / "repair/native"
            native.mkdir()
            patch_path = native / "candidate.patch"
            patch_path.write_bytes(b"")
            patch_pointer = self.bind(patch_path)
            capture_path = native / "candidate-capture.json"
            self.write(capture_path, {"complete": True, "sha256": patch_pointer["sha256"], "bytes": 0})
            capture = {"source": row["candidate"], "source_digest": row["source_digest"],
                       "public_baseline": task["source"], "public_baseline_sha256": task["source_sha256"],
                       "patch": str(patch_path), "patch_sha256": patch_pointer["sha256"],
                       "capture_proof": str(capture_path), "capture_proof_sha256": self.bind(capture_path)["sha256"]}
            grade = self.root / "grades" / str(index).zfill(2)
            packet_path = grade / "private-request.json"
            packet = json.loads(packet_path.read_bytes())
            packet.update(capture)
            self.write(packet_path, packet)
            self.write(grade / "private-entry-started.json", {"entry_sha256": "e" * 64,
                       "request_sha256": self.reg["bindings"][str(packet_path)]})
            config = json.loads(Path(task["backend"]["private"]["config"]).read_bytes())
            roots, _, _ = core._validated(config["trusted_test_inputs"])
            descriptor = prepare_audit(capture, task["public_packet"]["issue"], roots,
                                       self.root / "audits" / str(index))
            descriptor_path = self.root / "audits" / str(index) / "descriptor.json"
            pointer = self.write(descriptor_path, descriptor)
            for role in ("manifest", "bundle"):
                self.bind(Path(descriptor[role]))
            proof = verify_audit(descriptor, capture, None, issue=task["public_packet"]["issue"], protected_roots=roots)
            proof["descriptor"] = pointer
            self.write(grade / "integrity-audit.json", proof)
            row["integrity_audit"] = proof
            index_rows.append({"attempt_index": index, "candidate": row["candidate"],
                               "source_digest": row["source_digest"], "audit": proof})
        index_path = self.root / "integrity-audits.json"
        index = {"schema": "closed-candidate-integrity-audits-v1",
                 "closure_sha256": self.reg["bindings"][str(self.root / "actor-batch-closed.json")],
                 "complete": True, "unresolved": [], "audits": index_rows}
        pointer = self.write(index_path, index)
        result["integrity_audit"] = {**index, "index": pointer}
        self.proof["result"] = self.write(result_path, result)

    def invoke_feedback(self):
        with patch.object(subject, "_runtime_sources", return_value=[self.frozen]), \
             patch.object(subject, "verify_native_invocation", return_value={}):
            return subject.verify_runtime(self.reg, self.proof, feedback=True)

    def test_missing_original_input_protection_blocks_feedback_qualification(self):
        self.prepare_sixteen()
        with patch.object(subject,"verify_private_test_inputs",side_effect=ValueError("missing original input protection")):
            with self.assertRaisesRegex(ValueError,"missing original input protection"):
                self.invoke_feedback()

    def test_exact_sixteen_attempt_and_private_process_population_is_checked(self):
        self.prepare_sixteen()
        result = self.invoke_feedback()
        self.assertEqual(result["attempts"], 16)
        self.assertEqual(result["native_invocations"], 16)
        self.assertEqual(result["private_evaluator_processes"], 16)
        self.assertEqual(result["trusted_input_attempts"],16)
    def test_last_attempt_missing_integrity_proof_blocks_paid_admission(self):
        self.prepare_sixteen()
        (self.root / "grades/15/integrity-audit.json").unlink(missing_ok=True)
        with self.assertRaises(ValueError):
            self.invoke_feedback()
    def test_every_attempt_integrity_record_is_mandatory(self):
        self.prepare_sixteen()
        self.assertEqual(self.invoke_feedback()["integrity_audit_attempts"], 16)
        for index in range(16):
            with self.subTest(index=index):
                path = self.root / "grades" / str(index).zfill(2) / "integrity-audit.json"
                original = path.read_bytes()
                path.unlink()
                try:
                    with self.assertRaises(ValueError):
                        self.invoke_feedback()
                finally:
                    path.write_bytes(original)

    def test_self_consistent_copied_clear_cannot_replace_another_candidates_audit(self):
        self.prepare_sixteen()
        result_path = self.root / "result.json"
        result = json.loads(result_path.read_bytes())
        copied = copy.deepcopy(result["attempts"][0]["integrity_audit"])
        self.write(self.root / "grades/15/integrity-audit.json", copied)
        result["attempts"][15]["integrity_audit"] = copied
        index_path = self.root / "integrity-audits.json"
        index = json.loads(index_path.read_bytes())
        index["audits"][15]["audit"] = copied
        binding = self.write(index_path, index)
        result["integrity_audit"] = {**index, "index": binding}
        self.proof["result"] = self.write(result_path, result)
        with self.assertRaises(ValueError):
            self.invoke_feedback()

    def test_historical_eight_attempt_bundle_cannot_authorize_sixteen(self):
        self.reg["schema"] = policy.SCHEMA
        with self.assertRaises(ValueError):
            self.invoke_feedback()


if __name__ == "__main__":
    unittest.main()
