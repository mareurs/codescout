from pathlib import Path
import hashlib,json
root=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=json.loads((root/'custody-before.json').read_text())
original=Path('/home/marius/.codex/worktrees/2aa6/codescout')
check={'scratch_baseline_changes':[],'current_original_changes_since_snapshot':[]}
for name,value in before.items():
 for folder,key in ((root/'baseline','scratch_baseline_changes'),(original,'current_original_changes_since_snapshot')):
  path=folder/name
  if not path.exists() or sha(path)!=value:check[key].append(name)
(root/'custody-after.json').write_text(json.dumps(check,indent=2)+'\n')
results=json.loads((root/'mutation-results.json').read_text())
report={
 'scope':'Frozen initial readiness delta plus four prior-survivor regression tests; later parser/tests excluded',
 'baseline':{'tests':117,'skips':0,'exit':0},
 'mutation_counts':{'applied':len(results),'killed':sum(r['verdict']=='KILLED' for r in results),'survived':sum(r['verdict']=='SURVIVED' for r in results),'inconclusive':0},
 'prior_survivors':{'ids':['M01','M15','M17','M18'],'replayed':4,'killed':4,'survived':0,'each_tests':117,'meaning':'Real consumers observed R prompt, sixteenth native leaf, canonical112 allocation, unchanged original4 hold identity'},
 'important_correctness_finding':{
  'file':'tools/effort_protocol/readiness.py','line':91,
  'input':'Actual Dioxus and Ironclaw successful public MCP read_file responses: 1 line\\n\\n/testbed and 11 lines\\n\\n[...languages...]',
  'effect':'json.loads(texts[0]) raises; readiness is rejected before native launch despite successful retrieval',
  'reproduction':'probe_recorded_mcp.py feeds both recordings through real validate_readiness with otherwise-valid fixture proof; both rejected with malformed buffered project status field',
  'source_contract':'src/tools/read_file.rs::format_read_file_body at2065 renders line count and raw content; read_from_buffer internal Value is not public MCP wire',
  'test_defect':'Toy-stdio doubles mirrored internal Value and never applied actual renderer framing; green117 does not validate real buffered MCP'},
 'readiness_survivor_classification':{
  'D01':'Missing test for restricting output_id to @tool hex refs; guard exists. Malformed references affect producer before retrieval.',
  'D02':'Missing test of recorded query identity; guard exists. Corrupted stored proof can mismatch actual retrieval provenance.',
  'D07':'Missing test of unexpected status_resolution on valid inline status; guard exists. Mutant ignores extra metadata, does not alter derived root/languages.',
  'D08':'Artificial internal-schema returned-selector guard survived. Not a reachable field in valid public MCP output; requires redesign, not counted as real-runtime bypass.',
  'D09':'Artificial internal-schema format guard survived. Not present in valid public MCP text.',
  'D10':'Artificial internal-schema value_type guard survived. Not present in valid public MCP text.',
  'D11':'Artificial internal-schema array-count guard survived. Not present in valid public MCP text.'},
 'declined_to_judge':[
  'Revised framing parser or forthcoming tests: not frozen/reviewed yet; parent requested hold.',
  'Actual16 CLI qualification completion and full project gate: not rerun in this review.',
  'Provider behavior, paid efficacy, total review cost: no provider runs and cost unknown.',
  'Skipped tests from original full suite: no evidence of those paths execution.',
  'Skim semantic witness issue: outside frozen buffer delta; not yet independently attributed.'
 ],
 'verdict':'NOT READY: real MCP schema mismatch. Four original test gaps are meaningfully closed; current new delta needs actual-framing correction and replay before conditional approval.',
 'custody':check
}
(root/'pre-framing-correction-review.json').write_text(json.dumps(report,indent=2)+'\n')
manifest={p.name:sha(p) for p in root.iterdir() if p.is_file() and p.name!='evidence-manifest.json'}
(root/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'report':str(root/'pre-framing-correction-review.json'),'report_sha256':sha(root/'pre-framing-correction-review.json'),'manifest_sha256':sha(root/'evidence-manifest.json'),'custody':check},indent=2))
