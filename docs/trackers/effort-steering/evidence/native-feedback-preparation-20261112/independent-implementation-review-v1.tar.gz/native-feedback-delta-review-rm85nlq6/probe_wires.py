from pathlib import Path
import copy,json,sys
root=Path(__file__).parent
which,case=sys.argv[1:]
sys.path[:0]=[str(root/which/'tools'/name) for name in ('effort_protocol','agent_lifecycle','hint_authority_pilot')]
import readiness
reply=lambda value:{'jsonrpc':'2.0','id':3,'result':{'isError':False,'content':[{'type':'text','text':json.dumps(value)}]}}
handle='@tool_0123abcd'
status={'output_id':handle,'summary':'large workspace','buffered_bytes':14177}
fields=[{'content':'/testbed','path':'$.project_root','value_type':'string','format':'json'}, {'content':'["python"]','path':'$.languages','value_type':'array','format':'json','count':1}]
resolution=[{'arguments':{'path':handle,'json_path':'$.'+name},'response':reply(payload)} for name,payload in zip(('project_root','languages'),fields)]
wire={'status':reply(status),'status_resolution':resolution}
def alter(index,key,value):
 payload=json.loads(wire['status_resolution'][index]['response']['result']['content'][0]['text']);payload[key]=value
 wire['status_resolution'][index]['response']=reply(payload)
if case=='D01':
 status['output_id']='@cmd_0123abcd';wire['status']=reply(status)
 for row in resolution:row['arguments']['path']=status['output_id']
elif case=='D02': resolution[1]['arguments']['json_path']='$.unrelated'
elif case=='D07':wire['status']=reply({'project_root':'/testbed','languages':['python']});wire['status_resolution']=[{'untrusted':'ignored synthetic resolution'}]
elif case=='D08':alter(1,'path','$.unrelated')
elif case=='D09':alter(1,'format','toml')
elif case=='D10':alter(1,'value_type','string')
elif case=='D11':alter(1,'count',2)
try:
 value=readiness._project_status(wire);print(json.dumps({'copy':which,'case':case,'accepted':True,'value':value}))
except Exception as exc:print(json.dumps({'copy':which,'case':case,'accepted':False,'error':type(exc).__name__+': '+str(exc)}))
