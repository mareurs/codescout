from pathlib import Path
import copy, hashlib, json, sys
root=Path(__file__).parent
sys.path[:0]=[str(root/'baseline'/'tools'/name) for name in ('effort_protocol','agent_lifecycle','hint_authority_pilot')]
import readiness
from test_registered_readiness import RegisteredReadinessTests
fixture=RegisteredReadinessTests(); fixture.setUp()
results=[]
try:
 proof=fixture.measure()
 for project in ('DioxusLabs__dioxus-5384','nearai__ironclaw-6724'):
  path=Path('/var/tmp/native-feedback-readiness-buffers-v1-01a15')/project/'readiness/readiness-calls.json'
  calls=json.loads(path.read_text())
  status=[row for row in calls if row.get('params',{}).get('name')=='workspace' and row['params']['arguments'].get('action')=='status'][-1]
  fields=[row for row in calls if row.get('params',{}).get('name')=='read_file']
  wire=copy.deepcopy(proof['wire']);wire['status']=status['response'];wire['status_resolution']=[{'arguments':row['params']['arguments'],'response':row['response']} for row in fields]
  try:
   readiness.validate_readiness(proof['expected'],wire,source=fixture.actor)
   result={'accepted':True}
  except Exception as exc:result={'accepted':False,'error':type(exc).__name__+': '+str(exc)}
  result.update(project=project,recording=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),read_file_responses=[row['response'] for row in fields])
  results.append(result)
finally:fixture.doCleanups()
(root/'recorded-mcp-probe-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
