"""Correct generated-cache ownership using a verified local FROM tag; preserve failed v2 registry lookup."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess,sys,uuid
BASE=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
IDS=("DioxusLabs__dioxus-5384","nearai__ironclaw-6724")
WORK=Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.dont_write_bytecode=True;sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from evaluator_entry import _input_digest
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):
    with path.open("x") as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write(chr(10))
def main():
    assert Path(__file__).stat().st_mode & 0o222==0
    for identity in IDS:
        root=BASE/identity;prior=root/"common-clean-image-v1"
        old=json.loads((prior/"result.json").read_bytes());image=old["image"]
        assert old["workspace_base_cleanup_and_compile_warmup"] and not old["gold_warmup"]
        assert not json.loads((prior/"image.json").read_bytes())["Config"].get("Volumes")
        public=root/"common-preparation-v1/public-source";before=_input_digest(public)
        assert before==json.loads((prior/"registration.json").read_bytes())["source_sha256"]
        out=root/"common-clean-image-v3";out.mkdir()
        free=shutil.disk_usage(out).free;assert free>=80*1024**3
        context=out/"context";context.mkdir()
        parent_tag="ep-feedback-root-parent-"+uuid.uuid4().hex+":frozen"
        tagged=subprocess.run(["docker","tag",image,parent_tag],capture_output=True,timeout=60)
        assert tagged.returncode==0
        parent=subprocess.run(["docker","image","inspect",parent_tag],capture_output=True,timeout=60)
        assert parent.returncode==0 and json.loads(parent.stdout)[0]["Id"]==image
        recipe="FROM "+parent_tag+chr(10)+"USER root"+chr(10)+'RUN chown -R 0:0 /testbed/target /home/agent "${CARGO_HOME:-/usr/local/cargo}"'+chr(10)
        (context/"Dockerfile").write_text(recipe)
        target="ep-feedback-root-cache-"+uuid.uuid4().hex+":base"
        save(out/"registration.json",{"schema":"source-only-common-root-cache-image-v3","task":identity,"parent_image":image,
            "prior_result_sha256":sha(prior/"result.json"),"prior_recipe_sha256":sha(prior/"context/Dockerfile"),
            "parent_tag":parent_tag,"target_tag":target,"recipe_sha256":sha(context/"Dockerfile"),"producer_sha256":sha(__file__),
            "source":str(public),"source_sha256":before,"host_disk_free_bytes":free,"runtime_user":"0:0",
            "changed_roles":["generated Cargo target","Cargo cache ownership","HOME ownership"],
            "source_assertions_and_labels_unchanged":True,"client_model_calls":0,"paid_ready":False,
            "scope":"Ownership correction only; no model call, official/Gold patch, repeated onboarding/index or functional claim."})
        run=subprocess.run(["docker","build","--pull=false","--network","none","-t",target,str(context)],
            capture_output=True,timeout=3600)
        (out/"stdout.log").write_bytes(run.stdout);(out/"stderr.log").write_bytes(run.stderr)
        save(out/"command.json",{"returncode":run.returncode,"stdout_sha256":sha(out/"stdout.log"),"stderr_sha256":sha(out/"stderr.log")})
        assert run.returncode==0
        actual=subprocess.run(["docker","image","inspect",target],capture_output=True,timeout=120)
        assert actual.returncode==0
        row=json.loads(actual.stdout)[0];assert re.fullmatch("sha256:[0-9a-f]{64}",row["Id"])
        assert row["Config"]["User"]=="root" and not row["Config"].get("Volumes")
        save(out/"image.json",row);assert _input_digest(public)==before
        parent=subprocess.run(["docker","image","inspect",parent_tag],capture_output=True,timeout=60)
        assert parent.returncode==0 and json.loads(parent.stdout)[0]["Id"]==image
        save(out/"result.json",{"image":row["Id"],"parent_image":image,"source_unchanged":True,
            "generated_cache_owner_correction":True,"workspace_base_cleanup_and_compile_warmup":True,"gold_warmup":False,
            "frozen_package_unchanged":old["frozen_package_unchanged"],"canonical_seed_restored":old["canonical_seed_restored"],
            "client_model_calls":0,"paid_ready":False,
            "scope":"Image ownership correction built only; final readback/write-access/functional controls still pending."})
        print(json.dumps({"task":identity,"image":row["Id"],"source_unchanged":True,"client_model_calls":0,"paid_ready":False}),flush=True)
if __name__=="__main__":main()
