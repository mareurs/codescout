"""Close the two fixed integrity delivery controls without any actor/provider call."""
import hashlib
import json
from pathlib import Path
import sys

WORK = Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path.insert(0, str(WORK / "tools/effort_protocol"))
from feedback_assertion_audit import verify_audit
from feedback_assertion_review import verify_review
from evaluator_entry import _entries

BASE = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/blind-review-qualification-v1")
DELIVERY = Path(__file__).parent / "blind-review-delivery-v1"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")


def main():
    assert Path(__file__).stat().st_mode & 0o222 == 0
    registration_path = BASE / "registration.json"
    registration = json.loads(registration_path.read_bytes())
    assert len(registration["cases"]) == 2
    for path, expected in registration["bindings"].items():
        assert sha(Path(path).read_bytes()) == expected, path
    rows = []
    for case in registration["cases"]:
        export = Path(case["export"])
        descriptor_path = export / "descriptor.json"
        descriptor = json.loads(descriptor_path.read_bytes())
        assert verify_audit(descriptor, case["request"], None,
                            issue=case["issue"], protected_roots=case["protected_roots"])["status"] == "unresolved"
        manifest = json.loads(Path(descriptor["manifest"]).read_bytes())
        assert _entries(export / "review") == manifest["entries"], "reviewer-visible tree changed"
        delivery = DELIVERY / case["opaque_id"]
        pointers = {name: {"path": str(delivery / (name + ".json")),
                           "sha256": sha((delivery / (name + ".json")).read_bytes())}
                    for name in ("dispatch", "response")}
        decision = {"schema": "blinded-review-decision-v1", **pointers}
        proof = verify_review(descriptor, decision)
        assert proof["status"] == case["expected"] and proof["terminal"]
        raw = json.loads((delivery / "response.json").read_bytes())
        for role in ("baseline", "candidate"):
            control = next(item for item in case["controls"] if item["source_role"] == role)
            assert raw[role + "_test"]["returncode"] == control["returncode"]
        assert all(item["tests_run"] == 1 and item["failures"] == 1
                   and item["errors"] == 0 and item["returncode"] == 1 for item in raw["mutations"])
        save(delivery / "decision.json", decision)
        rows.append({"opaque_id": case["opaque_id"], "expected": case["expected"], "observed": proof["status"],
                     "proof": proof, "descriptor_sha256": sha(descriptor_path.read_bytes()),
                     "reviewer_reported_mutations": len(raw["mutations"]),
                     "reviewer_reported_survivors": sum(item["returncode"] == 0 for item in raw["mutations"])})
    extra = [Path(__file__).absolute(), WORK / "tools/effort_protocol/feedback_assertion_review.py",
             WORK / "tools/effort_protocol/test_feedback_assertion_review.py"]
    result = {"schema": "blind-integrity-review-qualification-closure-v1",
              "registration": {"path": str(registration_path), "sha256": sha(registration_path.read_bytes())},
              "bindings": {**registration["bindings"], **{str(path): sha(path.read_bytes()) for path in extra}},
              "cases": rows, "reviewer_count": 2,
              "scope": "Fixed integrity/delivery controls only. Counts of mutation executions are reviewer reports, not root-replayed mutations. Fresh context is recorded by exact tool arguments and returned receipt; this is not OS filesystem isolation. Raw final response text was transcribed from the returned agent messages without semantic rewriting.",
              "client_actor_provider_calls": 0, "review_compute_cost": "unknown", "paid_ready": False}
    target = DELIVERY / "qualification-closure.json"
    save(target, result)
    print(json.dumps({"closure": str(target), "sha256": sha(target.read_bytes()),
                      "cases": [{key: row[key] for key in ("opaque_id", "expected", "observed")} for row in rows],
                      "paid_ready": False}))


if __name__ == "__main__":
    main()
