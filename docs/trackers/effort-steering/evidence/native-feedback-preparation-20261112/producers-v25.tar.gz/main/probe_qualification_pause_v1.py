"""Exercise only the scripted model end-turn adapter, not the author workflow."""
import importlib.util
import io
import json
from pathlib import Path
import types

PATH = Path(__file__).with_name("qualify_native_feedback_campaign_v1.py")
SPEC = importlib.util.spec_from_file_location("qualified_driver", PATH)
subject = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(subject)


class Handler:
    def __init__(self):
        self.server = types.SimpleNamespace(stage=0, plan=[
            [subject.PAUSE, {}], ["Read", {"file_path": "Cargo.toml"}],
            [subject.PAUSE, {}], ["Read", {"file_path": "Cargo.toml"}]])
        self.wfile = io.BytesIO()
        self.codes = []

    def send_response(self, code):
        self.codes.append(code)

    def send_header(self, *args):
        pass

    def end_headers(self):
        pass

    def run(self):
        self.wfile = io.BytesIO()
        subject.scripted_turns(self, {"model": "fixture", "tools": [{"name": "Read"}]})
        records = [json.loads(line[6:]) for line in self.wfile.getvalue().decode().splitlines() if line.startswith("data: ")]
        return next(row["delta"]["stop_reason"] for row in records if row["type"] == "message_delta")


def main():
    handler = Handler()
    original = list(handler.server.plan)
    observations = [(handler.run(), handler.server.stage) for _ in range(5)]
    assert observations == [("end_turn", 1), ("tool_use", 2), ("end_turn", 3), ("tool_use", 4), ("end_turn", 4)]
    assert handler.server.plan == original and handler.codes == [200] * 5
    print(json.dumps({"scope": "scripted model adapter only; no CLI/provider invocation",
                      "observations": observations, "original_plan_preserved": True}))


if __name__ == "__main__":
    main()
