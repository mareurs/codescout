"""Source-only clean workspace caches using the frozen builder, then restore canonical inputs."""
from pathlib import Path
import hashlib,json,shlex,shutil,subprocess,sys,uuid
sys.dont_write_bytecode=True
sys.path.insert(0,"/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from evaluator_entry import verify_package
from receipts import input_digest
BASE=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
IDS=("DioxusLabs__dioxus-5384","nearai__ironclaw-6724")
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):
    with Path(path).open("x") as stream:json.dump(value,stream,sort_keys=True,indent=2)
def command(*args):
    run=subprocess.run(list(args),capture_output=True,text=True,timeout=120)
    if run.returncode:raise RuntimeError(str(args)+": "+run.stderr[-1200:])
    return run.stdout
def inspect(name):
    rows=json.loads(command("docker","image","inspect",name));assert len(rows)==1
    return rows[0]
def main():
    assert Path(__file__).stat().st_mode & 0o222 == 0
    frozen=json.loads(Path("/var/tmp/ep11-01a15/private-controls/obscura/config.json").read_bytes())
    package=verify_package(frozen["package_root"],frozen["package_files"])
    sys.path.insert(0,str(package))
    import multilang_tasks as tasks
    for identity in IDS:
        root=BASE/identity;common=root/"common-preparation-v1"
        probe=root/"private-setup-probe-v1"
        probed=json.loads((probe/"result.json").read_bytes())
        cleanup=json.loads((probe/"cleanup.json").read_bytes())
        assert probed["base_image_command_preparation_complete"] and cleanup["complete"]
        plan=json.loads((probe/"prepared-plan.json").read_bytes())
        assert sha(probe/"prepared-plan.json")==probed["prepared_plan_sha256"]
        record=plan["record"];image=plan["image"]
        assert image==probed["source_image"]==json.loads((common/"registration.json").read_bytes())["image"]
        public=common/"public-source";before=input_digest(public)
        out=root/"common-clean-image-v1";out.mkdir()
        free=shutil.disk_usage(out).free;assert free>=80*1024**3
        source_image=inspect(image)
        assert source_image["Id"]==image and not source_image["Config"].get("Volumes")
        save(out/"parent-before.json",source_image)
        parent_tag="ep-feedback-parent-"+uuid.uuid4().hex+":frozen"
        command("docker","tag",image,parent_tag)
        target="ep-feedback-clean-"+uuid.uuid4().hex+":base"
        context=out/"context";context.mkdir()
        shutil.copytree(public,context/"public-source",symlinks=True)
        original=tasks.live_dockerfile(parent_tag,record,"/testbed")
        assert original.count("USER root"+chr(10))==1
        recipe=original.replace("USER root"+chr(10),"USER root"+chr(10)+"ARG CARGO_BUILD_JOBS=4"+chr(10),1)
        assert recipe.count("RUN set -eu")==1
        recipe=recipe.replace("RUN set -eu","RUN chown -R 0:0 /testbed && set -eu",1)
        recipe += ("USER root"+chr(10)+
            "RUN find /testbed -mindepth 1 -maxdepth 1 ! -name .git ! -name target -exec rm -rf -- {} +"+chr(10)+
            "COPY --chown=0:0 public-source/ /testbed/"+chr(10)+
            "RUN chown 0:0 /testbed && chown -R 0:0 /testbed/.git"+chr(10))
        descriptor=json.loads((common/"preparation.json").read_bytes()).get("public_build_inputs")
        if descriptor and descriptor["seed"]:
            seed=Path(descriptor["seed"]["path"])
            from public_build_inputs import generated_digest
            assert generated_digest(seed)==descriptor["seed"]["sha256"]
            shutil.copytree(seed,context/"public-cache-seed",symlinks=True)
            destinations=[]
            for mount in descriptor["cache_mounts"]:
                source=mount["seed_relative"]
                assert len(Path(source).parts)==1
                destinations.append("/bench/public-dependencies/"+source)
            assert len(destinations)==len(set(destinations))
            recipe += "RUN rm -rf -- "+shlex.join(destinations)+chr(10)
            recipe += "COPY --chown=1000:1000 public-cache-seed/ /bench/public-dependencies/"+chr(10)
        (context/"Dockerfile").write_text(recipe)
        (out/"frozen-original-recipe.txt").write_text(original)
        save(out/"registration.json",{"schema":"source-only-common-clean-image-v1","task":identity,
            "parent_image":image,"parent_tag":parent_tag,"target_tag":target,
            "source":str(public),"source_sha256":before,"prepared_plan":str(probe/"prepared-plan.json"),
            "prepared_plan_sha256":sha(probe/"prepared-plan.json"),
            "image_bootstrap_attestation":str(probe/"result.json"),"attestation_sha256":sha(probe/"result.json"),
            "recipe_sha256":sha(context/"Dockerfile"),"frozen_builder_sha256":sha(tasks.__file__),
            "producer_sha256":sha(__file__),"host_disk_free_bytes":free,"build_cargo_jobs":4,
            "private_gold_or_official_patch_applied":False,"client_model_calls":0,"paid_ready":False,
            "scope":"Frozen base reset/cache cleanup and original-selection compile-only warm-up. Pure public worktree and canonical dependency seed restored; actual source/versions/controls pending."})
        run=subprocess.run(["docker","build","--pull=false","--network","none","-t",target,str(context)],
            capture_output=True,timeout=3600)
        (out/"stdout.log").write_bytes(run.stdout);(out/"stderr.log").write_bytes(run.stderr)
        save(out/"command.json",{"returncode":run.returncode,"stdout_sha256":sha(out/"stdout.log"),
            "stderr_sha256":sha(out/"stderr.log")})
        assert run.returncode==0
        built=inspect(target);save(out/"image.json",built)
        assert not built["Config"].get("Volumes") and built["Config"]["User"]=="root"
        assert inspect(parent_tag)["Id"]==image and input_digest(public)==before
        verify_package(package,frozen["package_files"])
        save(out/"result.json",{"image":built["Id"],"parent_image":image,"public_source_unchanged":True,
            "workspace_base_cleanup_and_compile_warmup":True,"gold_warmup":False,
            "canonical_seed_restored":bool(descriptor and descriptor["seed"]),
            "frozen_package_unchanged":True,"client_model_calls":0,"paid_ready":False,
            "scope":"Actual new image built only; complete public source readback, final version rebinding and baseline/reference/repeat controls still required."})
        print(json.dumps({"task":identity,"image":built["Id"],"source_unchanged":True,
            "client_model_calls":0,"paid_ready":False}),flush=True)
if __name__=="__main__":main()
