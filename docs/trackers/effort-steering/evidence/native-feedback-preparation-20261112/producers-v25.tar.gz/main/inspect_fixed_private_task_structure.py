"""Read the fixed original records only after source-only standalone policy freeze."""
from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
sys.path.insert(0,"/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from evaluator_entry import verify_package
from receipts import input_digest
BASE=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
DATA=Path("/home/marius/work/claude/setup-ab-data/live/multilang-rust.jsonl")
SHA="bf2dd8252a07d0f275663ef8f6ab87571dd9bc4ce386abf9ec98d3cd6bb51a81"
IDS=("DioxusLabs__dioxus-5384","nearai__ironclaw-6724")
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def main():
    assert Path(__file__).stat().st_mode & 0o222 == 0
    assert sha(DATA)==SHA
    policies={}
    for identity in IDS:
        path=BASE/identity/"public-test-role-inventory-v1/policy.json"
        policy=json.loads(path.read_bytes())
        assert policy["private_record_or_gold_read"] is False
        assert input_digest(Path(policy["source"]))==policy["source_sha256"]
        assert sha(policy["producer"]["path"])==policy["producer"]["sha256"]
        policies[identity]=(path,policy)
    old=json.loads(Path("/var/tmp/ep11-01a15/private-controls/obscura/config.json").read_bytes())
    package=verify_package(old["package_root"],old["package_files"])
    sys.path.insert(0,str(package))
    import tasks
    records={}
    with DATA.open() as stream:
        for line in stream:
            row=json.loads(line)
            if row["instance_id"] in IDS:
                assert row["instance_id"] not in records
                records[row["instance_id"]]=row
    assert set(records)==set(IDS)
    for identity,row in records.items():
        path,policy=policies[identity]
        metadata=json.loads((BASE/identity/"registration.json").read_bytes())["task"]
        assert row["repo"]==metadata["repo"] and row["base_commit"]==metadata["base_commit"]
        assert hashlib.sha256(row["problem_statement"].encode()).hexdigest()==metadata["public_issue_sha256"]
        out=BASE/identity/"private-structure-v1";out.mkdir(mode=0o700)
        with (out/"original-record.json").open("x") as stream:json.dump(row,stream,sort_keys=True,indent=2)
        production=tasks.patch_files(row["patch"]);official=tasks.patch_files(row["test_patch"])
        roots=policy["registered_roots"]
        summary={"schema":"fixed-private-task-structure-v1","task":identity,
            "dataset_sha256":SHA,"original_record_sha256":sha(out/"original-record.json"),
            "public_role_policy":{"path":str(path),"sha256":sha(path)},
            "implementation_paths":production,"official_test_paths":official,
            "implementation_official_path_overlap":sorted(set(production)&set(official)),
            "implementation_standalone_root_overlap":[name for name in production if any(Path(name).is_relative_to(root) for root in roots)],
            "original_f2p_labels":len(row["FAIL_TO_PASS"]),"original_p2p_labels":len(row["PASS_TO_PASS"]),
            "test_commands":row["test_cmds"],"print_commands":row["print_cmds"],
            "rebuild_commands":row.get("rebuild_cmds"),
            "private_outcome_read_or_run":False,"client_model_calls":0,"paid_ready":False}
        with (out/"structure.json").open("x") as stream:json.dump(summary,stream,sort_keys=True,indent=2)
        print(json.dumps(summary,sort_keys=True),flush=True)
    verify_package(package,old["package_files"]);assert sha(DATA)==SHA
if __name__=="__main__":main()
