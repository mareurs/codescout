"""Recheck public readiness only: no Claude CLI, author, private evaluator or provider."""
import copy
import hashlib
import json
from pathlib import Path
import sys
WORK = Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path[:0] = [str(WORK / "tools" / name) for name in
                ("effort_protocol", "agent_lifecycle", "hint_authority_pilot")]
import campaign_native as native
from embedding_runtime import embedding_runtime
from public_clone import prepare_public_clone, verify_source_baseline
from qualify_native import _native_argv, _readiness
from receipts import publish_exclusive

registration = Path(sys.argv[1]).resolve(strict=True)
reg = json.loads(registration.read_bytes())
out = Path(sys.argv[2])
assert not out.exists()
out.mkdir()
binding = {str(path): hashlib.sha256(path.read_bytes()).hexdigest()
           for path in (Path(__file__).resolve(), registration, WORK / "tools/effort_protocol/readiness.py",
                        WORK / "tools/effort_protocol/qualify_native.py",
                        WORK / "tools/effort_protocol/campaign_native.py")}
publish_exclusive(out / "inputs.json", {"bindings": binding, "scope": "public MCP readiness only",
                                       "cli_calls": 0, "author_calls": 0, "efficacy_claim": None})
results = []
for identity, task in reg["tasks"].items():
    stage = out / identity
    stage.mkdir()
    public = copy.deepcopy(task["backend"]["public"])
    source = Path(task["source"])
    baseline = verify_source_baseline(public)
    relay = stage / "embedding"
    relay.mkdir()
    record = {"task_id": identity, "ready": False}
    try:
        with embedding_runtime(relay, public["image"], public["embedding"]) as embedding:
            actor = stage / "actor"
            prepared = prepare_public_clone(source, actor, public)
            home = stage / "native-home"
            home.mkdir()
            argv = _native_argv(actor, home, {"runtime_manifest": public["runtime_manifest"],
                                            "native_image": public["image"]})
            argv[argv.index("--network") + 1] = embedding["network_id"]
            argv[argv.index("--tmpfs") + 1] = "/tmp:rw,exec,size=16g,uid=1000,gid=1000"
            argv.insert(argv.index("--init"), "--read-only")
            argv[-4:-4] = ["--cap-drop", "ALL", "--security-opt", "no-new-privileges",
                           "-e", "CARGO_TARGET_DIR=/tmp/target"]
            argv, build, files = native.prepare_native_build_inputs(stage, actor, argv, public)
            ready = stage / "readiness"
            ready.mkdir()
            cfg = {"native_image": public["image"],
                   "registered_readiness": public["registered_readiness"], **build, "files": files,
                   **{key: prepared[key] for key in ("knowledge_paths", "knowledge_sha256",
                                                     "baseline_commit", "index_update_required")},
                   "lsp_warmup_retries": public.get("lsp_warmup_retries", 0),
                   "source_baseline_sha256": baseline}
            publish_exclusive(ready / "registration.json", cfg)
            proof = _readiness(ready, argv, actor, source, cfg)
            record.update(ready=True, buffered_status=bool(proof["wire"].get("status_resolution")))
    except Exception as exc:
        record["error"] = type(exc).__name__ + ": " + str(exc)
    publish_exclusive(stage / "result.json", record)
    results.append(record)
    print(json.dumps(record), flush=True)
publish_exclusive(out / "result.json", {"tasks": results, "all_ready": all(r["ready"] for r in results),
                                       "author_calls": 0, "efficacy_claim": None})
