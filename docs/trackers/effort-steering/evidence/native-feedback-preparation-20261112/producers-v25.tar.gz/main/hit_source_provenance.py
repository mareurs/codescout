"""Check advertised source spans and the chunker's declared continuation prefix.

This checks text provenance, not AST ownership or semantic relevance.
"""
import hashlib
from pathlib import Path

MARKER = "\n    // ... (continued)\n"


class SourceProvenanceError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise SourceProvenanceError(message)


def lf_lines(text):
    parts = text.split("\n")
    result = [part.removesuffix("\r") for part in parts[:-1]]
    if parts[-1]:
        result.append(parts[-1])
    return result


def verify_hit(project, hit):
    try:
        require(isinstance(hit, dict) and hit.get("source") == "stack", "non-code hit")
        require(isinstance(hit.get("file_path"), str) and hit["file_path"], "missing path")
        relative = Path(hit["file_path"])
        require(not relative.is_absolute() and ".." not in relative.parts, "unscoped path")
        root = Path(project).resolve(strict=True)
        path = root / relative
        require(path.resolve(strict=True).is_relative_to(root) and path.is_file() and not path.is_symlink(),
                "source path is not a scoped regular file")
        raw = path.read_bytes()
        lines = lf_lines(raw.decode("utf-8"))
        start, end = hit["start_line"], hit["end_line"]
        require(type(start) is int and type(end) is int and 1 <= start <= end <= len(lines), "invalid full line bounds")
        rendered = hit["content"]
        require(isinstance(rendered, str) and rendered.strip(), "empty rendered payload")
        span = "\n".join(lines[start-1:end])
        common = {"file_path": str(relative), "file_sha256": hashlib.sha256(raw).hexdigest(),
            "source_range": [start, end], "normalized_source_span_sha256": hashlib.sha256(span.encode()).hexdigest(),
            "source_span_text_verified": True, "ast_ownership_verified": False}
        if rendered.strip() in span:
            return {**common, "mode": "literal-source-span", "prefix_source_ranges": None}
        require(rendered.count(MARKER) == 1, "unknown or repeated nonliteral rendering")
        prefix, body = rendered.split(MARKER)
        require(prefix.strip() and body.strip() and body.strip() in span, "continuation body is not in the advertised source span")
        width = len(lf_lines(prefix))
        require(width > 0, "empty prefix")
        earlier = lines[:start-1]
        locations = [[index+1, index+width] for index in range(len(earlier)-width+1)
            if "\n".join(earlier[index:index+width]).strip() == prefix.strip()]
        require(locations, "continuation prefix is not verbatim earlier source text")
        return {**common, "mode": "source-span-with-declared-continuation", "prefix_source_ranges": locations,
            "prefix_sha256": hashlib.sha256(prefix.encode()).hexdigest(),
            "body_sha256": hashlib.sha256(body.encode()).hexdigest()}
    except (OSError, UnicodeError, KeyError, TypeError, AttributeError) as exc:
        raise SourceProvenanceError("malformed or unavailable hit/source") from exc
