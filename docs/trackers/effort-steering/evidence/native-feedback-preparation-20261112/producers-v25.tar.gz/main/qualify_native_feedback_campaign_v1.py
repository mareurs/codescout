"""Actual sixteen-slot repair-only CLI qualification; scripted model, zero forwarding."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import sys
from unittest.mock import patch

WORK = Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path.insert(0, str(WORK / "tools/effort_protocol"))
import external
from feedback_runner import preflight, run_campaign
from native_campaign import NativeCampaignBackend

PAUSE = "__qualification_end_turn__"
ORIGINAL_SCRIPTED = external.transport.Proxy.scripted


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")


def no_upstream(*args, **kwargs):
    raise AssertionError("provider forwarding forbidden by zero-model qualification")


def scripted_turns(handler, body):
    """Only model-side end-turn simulation; original tools/client/workflow remain real."""
    server = handler.server
    if server.stage < len(server.plan) and server.plan[server.stage][0] == PAUSE:
        assert server.plan[server.stage][1] == {}
        server.stage += 1
        original = server.plan
        server.plan = []
        try:
            return ORIGINAL_SCRIPTED(handler, body)
        finally:
            server.plan = original
    return ORIGINAL_SCRIPTED(handler, body)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("registration", type=Path)
    args = parser.parse_args()
    assert Path(__file__).stat().st_mode & 0o222 == 0
    reg = json.loads(args.registration.read_bytes())
    assert reg["mode"] == "scripted"
    assert reg["qualification_driver"] == {"path": str(Path(__file__).absolute()), "sha256": sha(__file__)}
    for path, digest in reg["bindings"].items():
        assert sha(path) == digest, path
    backend = NativeCampaignBackend(mode="scripted")
    checked = preflight(reg, backend)
    save(args.registration.parent / "preflight.json", checked)
    assert checked["ready"] and checked["paid_ready"] is False, checked
    print(json.dumps({"starting": True, "schedule": reg["schedule"], "provider_forwarding": "forbidden",
                      "paid_ready": False}), flush=True)
    with patch.object(external.transport.Proxy, "upstream", no_upstream), \
         patch.object(external.transport.Proxy, "scripted", scripted_turns):
        result = run_campaign(reg, backend)
    root = Path(reg["output_root"])
    terminal = {"status": result["status"], "reason": result.get("reason"),
                "attempts": len(result["attempts"]), "paid_ready": False}
    save(args.registration.parent / "terminal-summary.json", terminal)
    assert result["status"] == "completed" and len(result["attempts"]) == 16, terminal
    count = 0
    observations = []
    for index, row in enumerate(result["attempts"]):
        assert row["workflow_state"] == "closed" and row["measurement_invalid"] is False
        assert row["grade"]["valid"] is True and row["grade"]["pass"] is False
        assert row["integrity_audit"]["terminal"] is True and row["integrity_audit"]["status"] == "clear"
        assert row["integrity_audit"]["method"] == "identical-source"
        assert len(row["invocations"]) == 1
        decision = row["invocations"][0]
        native = Path(decision["record"]["native_path"])
        launch = json.loads((native / "launch.json").read_bytes())
        receipt = json.loads((native / "receipt.json").read_bytes())
        assert launch["real_credentials_read"] is False
        assert receipt["forwarded"] == 0 and decision["cost"] == {"known_usd": "0", "unknown": False}
        assert receipt["workflow_completed"] is True and receipt["lifecycle"]["continuations"] == 4
        assert receipt["lifecycle"]["turns"] == 5
        assert (native / "candidate.patch").read_bytes() == b""
        assert len(list(native.glob("mcp-launch-*.json"))) == 1
        bodies = [json.loads(path.read_bytes()) for path in sorted(native.glob("request-*.json"))]
        efforts = [body["output_config"]["effort"] for body in bodies if "effort" in body.get("output_config", {})]
        assert efforts and set(efforts) == ({"xhigh"} if row["arm"] == "X" else {"low"})
        observations.append({"index": index, "arm": row["arm"], "task_id": row["task_id"],
                             "continuations": 4, "turns": 5, "provider_forwarded": receipt["forwarded"]})
        count += 1
    summary = {"attempts": 16, "native_invocations": count, "private_evaluator_processes": 16,
               "provider_forwarded": 0, "model_cost_usd": "0", "all_workflows_closed": True,
               "efficacy_claim": None, "paid_ready": False, "observations": observations,
               "scope": "Exact real author CLI/context/public verification/capture/cleanup/private evaluator. Model transport alone is scripted; four failed public checks then original manifest restoration, no repair efficacy."}
    save(root / "runtime-qualification.json", summary)
    print(json.dumps({"completed": True, "attempts": 16, "native_invocations": count,
                      "provider_forwarded": 0, "paid_ready": False}), flush=True)


if __name__ == "__main__":
    main()
