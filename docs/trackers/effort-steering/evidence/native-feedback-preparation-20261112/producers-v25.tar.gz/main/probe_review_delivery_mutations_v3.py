"""Four actual isolated mutations with all three real runtime import folders."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

PRIOR = Path(__file__).with_name("probe_review_delivery_mutations_v1.py")
SPEC = importlib.util.spec_from_file_location("prior_probe", PRIOR)
prior = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(prior)
SOURCE = prior.SOURCE
LIFECYCLE = SOURCE.parent / "agent_lifecycle"
HINT = SOURCE.parent / "hint_authority_pilot"
OUTPUT = prior.OUTPUT.with_name("review-delivery-mutations-v3")

def execute(root, label, mutation=None):
    work = root / label
    target = work / "tools/effort_protocol"
    shutil.copytree(SOURCE, target, ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copytree(LIFECYCLE, work / "tools/agent_lifecycle", ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copytree(HINT, work / "tools/hint_authority_pilot", ignore=shutil.ignore_patterns("__pycache__"))
    if mutation:
        _, name, before, after = mutation
        path = target / name
        text = path.read_text()
        assert text.count(before) == 1
        path.write_text(text.replace(before, after))
        assert before not in path.read_text()
    process = subprocess.run([sys.executable, "-B", "-m", "unittest", "discover", "-s", str(target),
                              "-p", "test_feedback_assertion_*.py", "-v"],
                             cwd=work, capture_output=True, timeout=40)
    output = process.stdout + process.stderr
    (OUTPUT / (label + ".log")).write_bytes(output)
    count = re.search(rb"Ran ([0-9]+) tests? in ", output)
    assert count and int(count[1]) == 20 and b"ImportError" not in output and b"ModuleNotFoundError" not in output
    assert (process.returncode != 0 and b"FAILED (" in output) if mutation else (
        process.returncode == 0 and output.rstrip().endswith(b"OK"))
    return {"id": label, "tests_run": int(count[1]), "returncode": process.returncode,
            "observed": "killed" if mutation else "baseline-pass", "log_sha256": hashlib.sha256(output).hexdigest()}


def bindings():
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest()
            for folder in (SOURCE, LIFECYCLE, HINT) for path in sorted(folder.glob("*.py"))}


def main():
    assert Path(__file__).stat().st_mode & 0o222 == 0
    before = bindings()
    OUTPUT.mkdir()
    with tempfile.TemporaryDirectory(prefix="review-delivery-mutants-v3-", dir="/var/tmp") as directory:
        root = Path(directory)
        rows = [execute(root, "baseline")]
        rows.extend(execute(root, mutation[0], mutation) for mutation in prior.MUTANTS)
    assert bindings() == before
    result = {"schema": "review-delivery-mutation-probe-v3", "bindings": before, "cases": rows,
              "applied": len(prior.MUTANTS), "killed": sum(row["observed"] == "killed" for row in rows),
              "survived": 0, "scope": "Four root-applied temporary mutations, targeted twenty-test suite; not independent final review.",
              "prior_inconclusive": str(prior.OUTPUT / "baseline.log")}
    (OUTPUT / "result.json").write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
    print(json.dumps({key: result[key] for key in ("applied", "killed", "survived")}))


if __name__ == "__main__":
    main()
