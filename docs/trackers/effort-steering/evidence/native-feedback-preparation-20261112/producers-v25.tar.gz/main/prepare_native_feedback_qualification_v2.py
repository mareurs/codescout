"""Versioned standalone-entry bootstrap correction; retain original v1 artifacts."""
import importlib.util
import json
from pathlib import Path

PRIOR = Path(__file__).with_name("prepare_native_feedback_qualification_v1.py")
SPEC = importlib.util.spec_from_file_location("feedback_preparation_v1", PRIOR)
prior = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(prior)


def main():
    assert Path(__file__).stat().st_mode & 0o222 == 0
    prior.OUT = prior.BASE / "native-feedback-qualification-v2-registration"
    prior.RUN = Path("/var/tmp/native-feedback-qualified-v2-01a15")
    prior.main()
    original = prior.OUT / "registration.json"
    reg = prior.read(original)
    driver = Path(__file__).with_name("qualify_native_feedback_campaign_v2.py").absolute()
    dependencies = [reg["qualification_driver"], *reg["qualification_driver_dependencies"],
                    {"path": str(Path(__file__).absolute()), "sha256": prior.sha(__file__)}]
    reg["qualification_driver"] = {"path": str(driver), "sha256": prior.sha(driver)}
    reg["qualification_driver_dependencies"] = dependencies
    for item in [reg["qualification_driver"], *dependencies]:
        reg["bindings"][item["path"]] = item["sha256"]
    target = prior.OUT / "final-registration.json"
    prior.save(target, reg)
    print(json.dumps({"final_registration": str(target), "attempts": len(reg["schedule"]), "paid_ready": False}), flush=True)


if __name__ == "__main__":
    main()
