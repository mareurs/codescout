"""Exact public baseline scopes on isolated dependencies; no author/provider call."""
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True
sys.path.insert(0,"/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
import executor
import public_build_inputs as inputs
from receipts import input_digest
base = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/nearai__ironclaw-6724")
source = base/"pnpm-offline-write-probe-v5/E-source-ro-node-rw-pnpm-state-rw/input"
seed = base/"pnpm-offline-write-probe-v5/cache-seed"
image = "sha256:28aa0e0f6f9cd069363ec49448bf7e3dd1d19e3fcdf3629a6f92d5d47c542de1"
out = base/"baseline-public-cargo-v3-v1"
out.mkdir()
descriptor = {"schema":"public-build-inputs-v1","image":image,
              "seed":{"path":str(seed),"sha256":inputs.generated_digest(seed)},
              "dependency_dirs":["crates/ironclaw_webui/frontend/node_modules"],
              "cache_mounts":[{"seed_relative":p,"destination":"/bench/public-dependencies/"+p}
                              for p in ("pnpm-store","pnpm-cache","pnpm-state")]}
before = input_digest(source)
save = lambda name,value: (out/name).write_text(json.dumps(value,sort_keys=True,indent=2))
save("registration.json",{"source":str(source),"source_sha256":before,"image":image,
                         "public_build_inputs":descriptor,
                         "bindings":{str(Path(m.__file__)):inputs.generated_digest(Path(m.__file__).parent)
                                     for m in ()},
                         "helper_sha256":__import__("hashlib").sha256(Path(inputs.__file__).read_bytes()).hexdigest(),
                         "client_model_calls":0,"paid_ready":False})
rows=[]
for identity,extra in (("ordinary",[]),("broader",["--all-targets"])):
    request={"id":identity,"run_id":"ironclaw-public-cargo-v3-v1","phase":"repair","image":image,
             "argv":["cargo","check","--offline","--workspace",*extra],"cwd":".","kind":"observation",
             "timeout_s":900,"max_log_bytes":67108864,"test_files":["Cargo.toml"],
             "production_files":["crates/ironclaw_webui/build.rs"],"execution_profile":"cargo-v3",
             "public_build_inputs":descriptor}
    save(identity+"-request.json",request)
    try:
        result=executor.execute_observation(request,source,out/"commands")
    except executor.ExecutionInvalid as exc:
        save(identity+"-invalid.json",{"reason":exc.reason,"source_unchanged":input_digest(source)==before})
        raise
    save(identity+"-result.json",result)
    rows.append(result)
    print(json.dumps(result,sort_keys=True),flush=True)
    assert input_digest(source)==before
    assert result["exit_code"]==0, "original public scope failed; retain raw logs"
save("result.json",{"baseline_scopes":rows,"source_unchanged":True,"client_model_calls":0,
                    "paid_ready":False,"scope":"Original ordinary/broader baseline only; reference, onboarding, private/native controls pending."})
