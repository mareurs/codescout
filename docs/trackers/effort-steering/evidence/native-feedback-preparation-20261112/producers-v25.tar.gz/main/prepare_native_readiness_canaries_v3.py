"""Version public-only capability witnesses after measured failed assumptions."""
import copy
import hashlib
import json
from pathlib import Path

OLD = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/native-feedback-qualification-v2-registration/final-registration.json")
OUT = Path("/var/tmp/native-feedback-readiness-canaries-v3-01a15")
assert not OUT.exists()
OUT.mkdir()
reg = copy.deepcopy(json.loads(OLD.read_bytes()))
def probes(identity):
    return reg["tasks"][identity]["backend"]["public"]["registered_readiness"]["probes"]
probes("DioxusLabs__dioxus-5384")[3]["must_contain"] = [
    "packages/core/src/diff/node.rs", "create_dynamic_node"]
probes("skim-rs__skim-1044")[3] = {
    "tool": "semantic_search", "arguments": {"query": "pub trait SkimItem", "limit": 5, "detail_level": "full"},
    "must_contain": ["src/helper/item.rs", "pub struct DefaultSkimItem"]}
probes("nearai__ironclaw-6724")[2] = {
    "tool": "call_graph", "arguments": {"path": "crates/ironclaw_auth/src/oauth.rs",
        "symbol": "opaque_state_hash", "direction": "callees", "max_depth": 1},
    "must_contain": ["→ sha256_hex"]}
scope = {
    "schema": "public-readiness-canary-revision-v3",
    "scope": "Capability calibration only; no efficacy, task resampling, private-outcome input or index/cache change.",
    "DioxusLabs__dioxus-5384": "Same query; measured related create_dynamic_node result was checked in public diff/node.rs655-692.",
    "skim-rs__skim-1044": "Prior measured literal query/limit5/full yields complete DefaultSkimItem; checked public src/helper/item.rs23-29. Broad-query attribute-only ranking remains an explicit open quality caveat d25024261adb4d7c.",
    "nearai__ironclaw-6724": "Prior test-function canary has zero edges; replacement public production opaque_state_hash403-405 calls sha256_hex. New call graph still needs actual measurement.",
    "bindings": {str(OLD): hashlib.sha256(OLD.read_bytes()).hexdigest(),
                 str(Path(__file__).resolve()): hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}}
(OUT / "scope.json").write_text(json.dumps(scope, indent=2) + "\n")
(OUT / "registration.json").write_text(json.dumps(reg, indent=2) + "\n")
print(json.dumps({"root": str(OUT), "paid_ready": False, "actor_calls": 0}))
