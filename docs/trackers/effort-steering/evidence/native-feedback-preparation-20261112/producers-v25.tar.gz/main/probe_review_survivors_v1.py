"""Replay the four observed independent survivors against new consumer regressions."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

SOURCE = Path("/home/marius/.codex/worktrees/2aa6/codescout")
OUT = Path(tempfile.mkdtemp(prefix="feedback-survivor-replay-", dir="/tmp"))
MUTATIONS = [
    ("M01", "native_executor.py", 'if selected["plan_instruction"]:', 'if selected["plan_instruction"] and arm != "R":'),
    ("M15", "paid_admission.py",
     'verify_native_invocation(registration,phase_root,intent,public,feedback=True)',
     'verify_native_invocation(registration,phase_root,intent,public,feedback=True) if index < 15 else None'),
    ("M17", "feedback_admission.py", 'legacy.verify_accounting(registration, descriptor, allocation_usd="112")',
     'legacy.verify_accounting(registration, descriptor, allocation_usd="78")'),
    ("M18", "feedback_admission.py", 'and history["holds_unchanged"] == old["holds"] and len(history["shared_zero_evidence"]) == 1,',
     'and len(history["shared_zero_evidence"]) == 1,')]
rows = []
for identity, file, before, after in [("baseline", None, None, None)] + MUTATIONS:
    root = OUT / identity
    for package in ("effort_protocol", "agent_lifecycle", "hint_authority_pilot"):
        shutil.copytree(SOURCE / "tools" / package, root / "tools" / package,
                        ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    if file:
        target = root / "tools/effort_protocol" / file
        data = target.read_text()
        assert data.count(before) == 1, (identity, data.count(before))
        target.write_text(data.replace(before, after))
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1",
               PYTHONPATH=os.pathsep.join(str(root / "tools" / name) for name in
                                         ("effort_protocol", "agent_lifecycle", "hint_authority_pilot")))
    completed = subprocess.run(["python3", "-B", "-m", "unittest",
        "test_feedback_canonical_accounting", "test_native_executor", "test_feedback_paid_leaves"],
        cwd=root, env=env, capture_output=True, text=True)
    log = OUT / (identity + ".log")
    log.write_text(completed.stdout + completed.stderr)
    row = {"id": identity, "exit_code": completed.returncode, "log": str(log),
           "log_sha256": hashlib.sha256(log.read_bytes()).hexdigest(),
           "tail": (completed.stdout + completed.stderr).splitlines()[-6:]}
    rows.append(row)
    print(json.dumps(row), flush=True)
(OUT / "result.json").write_text(json.dumps(rows, indent=2))
assert rows[0]["exit_code"] == 0 and all(row["exit_code"] == 1 for row in rows[1:])
print(json.dumps({"root": str(OUT), "applied": 4, "killed": 4, "survived": 0}))
