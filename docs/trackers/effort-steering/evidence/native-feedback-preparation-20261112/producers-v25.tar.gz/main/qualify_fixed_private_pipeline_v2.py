"""After the owned image builder ends, qualify both final images, then original-label private controls."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
MAIN=Path("/home/marius/work/claude/codescout")
WORK=Path("/home/marius/.codex/worktrees/2aa6/codescout")
SCRIPTS=MAIN/".superpowers/sdd/2026-11-11-native-public-feedback-transfer"
BASE=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
IDS=("DioxusLabs__dioxus-5384","nearai__ironclaw-6724")
PARENT=Path("/home/marius/.cache/cc-tmp/codescout-bg/212011-9acd60fe-bg_00000172.json")
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):
    with path.open("x") as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write(chr(10))
def main():
    assert Path(__file__).stat().st_mode & 0o222==0
    out=BASE/"fixed-private-qualification-v2";out.mkdir(mode=0o700)
    names=("build_fixed_root_cache_images_v3.py","readback_fixed_common_clean_image_v3.py",
        "qualify_fixed_root_cache_write.py","prepare_fixed_private_controls_v2.py","run_fixed_private_controls_v2.py")
    assert all((SCRIPTS/name).stat().st_mode & 0o222==0 for name in names)
    bindings={str(SCRIPTS/name):sha(SCRIPTS/name) for name in names}
    bindings.update({str(WORK/"tools/effort_protocol"/name):sha(WORK/"tools/effort_protocol"/name) for name in
        ("evaluator_entry.py","trusted_test_inputs.py","feedback_trusted_inputs.py","feedback_private_commands.py")})
    bindings[str(Path(__file__))]=sha(__file__)
    parent=json.loads(PARENT.read_bytes())
    assert parent["job_pid"]==2413254 and parent["server_pid"]==212011 and "build_fixed_root_cache_images_v3.py" in parent["command"]
    save(out/"registration.json",{"schema":"fixed-private-qualification-sequence-v2","parent_job":str(PARENT),
        "bindings":bindings,"tasks":list(IDS),"client_model_calls":0,"paid_ready":False,
        "scope":"No paid/model work. Actual final image readback, zero-capability cache writes, protected baseline/reference/repeat. Stop at first failed dependency; preserve all evidence."})
    if parent["state"]=="running":
        waited=subprocess.run(["tail","--pid=2413254","-f","/dev/null"],capture_output=True)
        assert waited.returncode==0
    assert all(sha(path)==expected for path,expected in bindings.items())
    for identity in IDS:
        built=BASE/identity/"common-clean-image-v3"
        result=json.loads((built/"result.json").read_bytes())
        reg=json.loads((built/"registration.json").read_bytes())
        assert result["generated_cache_owner_correction"] and reg["producer_sha256"]==bindings[str(SCRIPTS/names[0])]
    steps=[]
    schedule=[(name,identity) for name in names[1:4] for identity in IDS]
    schedule += [(names[4],identity) for identity in IDS]
    for number,(producer,identity) in enumerate(schedule,1):
        assert all(sha(path)==expected for path,expected in bindings.items())
        directory=out/("step-"+str(number));directory.mkdir()
        args=[sys.executable,"-B",str(SCRIPTS/producer),identity];started=time.monotonic()
        with (directory/"stdout.log").open("xb") as stdout,(directory/"stderr.log").open("xb") as stderr:
            run=subprocess.run(args,cwd=MAIN,stdout=stdout,stderr=stderr,
                env={"PATH":os.environ["PATH"],"HOME":os.environ["HOME"],"TMPDIR":"/var/tmp","PYTHONDONTWRITEBYTECODE":"1"})
        row={"producer":producer,"task":identity,"argv":args,"returncode":run.returncode,"wall_s":time.monotonic()-started,
            "stdout_sha256":sha(directory/"stdout.log"),"stderr_sha256":sha(directory/"stderr.log")}
        save(directory/"command.json",row);steps.append(row)
        print(json.dumps({"step":number,"task":identity,"producer":producer,"returncode":run.returncode}),flush=True)
        if run.returncode:
            save(out/"stopped.json",{"steps":steps,"client_model_calls":0,"paid_ready":False,
                "reason":"First invalid/contradicted dependency; no model/task resampling or silent retry."})
            return 1
    assert all(sha(path)==expected for path,expected in bindings.items())
    assert all(json.loads((BASE/identity/"private-preparation-v2/controls-result.json").read_bytes())["all_three_controls_met"] for identity in IDS)
    save(out/"result.json",{"complete":True,"steps":steps,"client_model_calls":0,"paid_ready":False,
        "scope":"Deterministic final-image and private control execution only. Independent audit, actual author CLI/all16 admission/gate/review and scientific comparison remain pending."})
    return 0
if __name__=="__main__":raise SystemExit(main())
