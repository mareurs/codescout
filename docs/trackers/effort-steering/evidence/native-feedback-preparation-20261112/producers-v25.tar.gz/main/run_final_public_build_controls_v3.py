"""Qualify both frozen public compile scopes against exact final image and typed immutable dependency inputs."""
import argparse,hashlib,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,"/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from receipts import input_digest
from executor import execute_observation
from campaign_resources import measure_host
from public_build_inputs import validate_descriptor
WORK=Path("/home/marius/.codex/worktrees/2aa6/codescout")
def save(path,value):
    with path.open("x") as stream:
        json.dump(value,stream,sort_keys=True,indent=2)
        stream.write(chr(10))
def main():
    assert Path(__file__).stat().st_mode & 0o222 == 0
    parser = argparse.ArgumentParser()
    parser.add_argument("--task-root", type=Path, required=True)
    parser.add_argument("--image-metadata", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workspace", required=True)
    parser.add_argument("--public-build-inputs", type=Path, required=True)
    args = parser.parse_args()
    from feedback_policy import condition_spec
    workspace = condition_spec("L", args.workspace)["check"]["cwd"]
    assert args.source.resolve(strict=True) == args.source
    digest = input_digest(args.source)
    image_info = json.loads(args.image_metadata.read_bytes())
    image = (image_info[0] if isinstance(image_info, list) else image_info)["Id"]
    build_descriptor=json.loads(args.public_build_inputs.read_bytes())
    admitted=validate_descriptor(build_descriptor,args.source,image)
    args.output.mkdir()
    host = measure_host(WORK, "/tmp")
    save(args.output / "host-before.json", host)
    assert host["root_free"] >= 80 * 1024**3 and host["mem_available"] >= 16 * 1024**3
    assert host["tmp_free"] >= 4 * 1024**3 and host["tmp_exec"]
    bindings = {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted((WORK / "tools/effort_protocol").glob("*.py"))}
    save(args.output / "source-bindings.json", bindings)
    save(args.output / "preparation-inputs.json", {"task_root": str(args.task_root),
        "image_metadata": str(args.image_metadata),
        "image_metadata_sha256": hashlib.sha256(args.image_metadata.read_bytes()).hexdigest(),
        "public_build_inputs":str(args.public_build_inputs),"public_build_inputs_sha256":hashlib.sha256(args.public_build_inputs.read_bytes()).hexdigest(),
        "public_build_inputs_fingerprint":admitted["fingerprint"],
        "source": str(args.source), "source_digest": digest,
        "producer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "scope": "Public source-only compile qualification; no private/model input", "provider_calls": 0})
    manifest = "Cargo.toml" if workspace == "." else workspace + "/Cargo.toml"
    rows = []
    for name, arm in (("ordinary", "L"), ("broader", "P")):
        argv = condition_spec(arm, workspace)["check"]["argv"]
        request = {"id": "public-" + name, "run_id": args.output.name + "-" + name,
            "phase": "challenge", "kind": "verification", "image": image, "argv": argv,
            "cwd": workspace, "test_files": [manifest],
            "production_files": sorted(p.relative_to(args.source).as_posix() for p in args.source.rglob("*")),
            "timeout_s": 900, "max_log_bytes": 67108864, "execution_profile": "cargo-v3", "public_build_inputs":build_descriptor}
        directory = args.output / name
        directory.mkdir()
        save(directory / "registration.json", {"request": request, "source": str(args.source),
            "source_digest": digest, "source_bindings": bindings, "paid_ready": False})
        print(json.dumps({"starting": name, "image": image}), flush=True)
        try:
            facts = execute_observation(request, args.source, directory / "commands")
            row = {"name": name, "complete": facts["complete"], "resource_valid": facts["resource_valid"],
                "exit_code": facts["exit_code"], "receipt": facts, "paid_ready": False}
        except BaseException as exc:
            row = {"name": name, "complete": False, "reason": type(exc).__name__ + ": " + str(exc), "paid_ready": False}
        save(directory / "result.json", row)
        rows.append(row)
        print(json.dumps({k: v for k, v in row.items() if k != "receipt"}), flush=True)
        if not (row.get("complete") and row.get("resource_valid") and row.get("exit_code") == 0):
            save(args.output / "stopped.json", {"rows": rows, "paid_ready": False})
            return 1
    assert input_digest(args.source) == digest
    assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==value for path,value in bindings.items())
    assert validate_descriptor(build_descriptor,args.source,image)==admitted
    save(args.output / "result.json", {"rows": rows, "source_unchanged": True,
        "provider_calls": 0, "paid_ready": False})
if __name__=="__main__":raise SystemExit(main())
