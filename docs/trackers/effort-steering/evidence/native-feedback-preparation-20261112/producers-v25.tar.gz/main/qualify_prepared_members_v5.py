"""Namespace-separated member qualification; reuses hash-bound completed index commands."""
import argparse, importlib.util, json, subprocess, sys, time
from pathlib import Path
sys.dont_write_bytecode = True
import index_prepared_members_v2 as engine
from hit_source_provenance import verify_hit

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--preparation", type=Path, required=True)
    args = parser.parse_args()
    parent = args.preparation.resolve(strict=True)
    project = parent / "project"
    prep = json.loads((parent / "preparation.json").read_bytes())
    public_sha = prep["template_public_sha256"]
    assert engine._public_digest(project) == public_sha
    image = json.loads((parent / "registration.json").read_bytes())["image"]
    members = [entry for entry in prep["configured_projects"] if entry["root"] != "."]
    members.sort(key=lambda entry: (entry["id"] == Path(entry["root"]).name, entry["root"], entry["id"]))
    assert members and len(members) == len({entry["id"] for entry in members})
    previous = parent / "configured-member-qualification-v2"
    engine_sha = engine.sha(engine.__file__)
    for mode in ("first", "all"):
        prior = previous / ("run-" + mode)
        registration = json.loads((prior / "registration.json").read_bytes())
        assert registration["producer_sha256"] == engine_sha
        assert registration["configured_members"] == members
        assert registration["source_public_sha256"] == public_sha and registration["image"] == image
        for label in ("native", "embedding"):
            cleanup = json.loads((prior / label / "cleanup.json").read_bytes())
            assert cleanup.get("complete", cleanup.get("cleanup_complete")) is True
    root_index = parent / "index-coderank-v1"
    root_result = json.loads((root_index / "result.json").read_bytes())
    assert root_result["index_exit"] == 0 and root_result["source_digest_unchanged"]
    configuration = json.loads((root_index / "registration.json").read_bytes())["embedding"]
    checker = Path(__file__).with_name("hit_source_provenance.py")
    source_hashes = {str(path): engine.sha(path) for path in
        (Path(__file__), Path(engine.__file__), checker, parent / "native-runtime.json", parent / "preparation.json")}
    out = parent / "configured-member-qualification-v5"
    out.mkdir()
    (out / "embedding").mkdir()
    (out / "members").mkdir()
    latest = parent / "configured-member-qualification-v4"
    latest_registration = json.loads((latest / "registration.json").read_bytes())
    assert latest_registration["members"] == members
    assert latest_registration["public_source_sha256"] == public_sha and latest_registration["image"] == image
    assert all(engine.sha(path) == digest for path, digest in latest_registration["bindings"].items())
    for label in ("native", "embedding"):
        cleanup = json.loads((latest / label / "cleanup.json").read_bytes())
        assert cleanup.get("complete", cleanup.get("cleanup_complete")) is True
    engine.save(out / "registration.json", {"members": members, "configured_nonroot_count": len(members),
        "public_source_sha256": public_sha, "image": image, "bindings": source_hashes,
        "previous_index_root": str(previous), "client_model_calls": 0, "additional_onboarding_calls": 0,
        "embedding_compute_cost_usd": None, "paid_ready": False,
        "scope": "Configured namespace and payload text provenance; AST context ownership and semantic relevance are not measured."})
    spec = importlib.util.spec_from_file_location("member_source_native", engine.SCRIPTS / "prior_prepare_native.py")
    native_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(native_module)
    native_module.ROOT, native_module.IMAGE = out, image
    original = native_module._native_argv
    rows = []
    reused = 0
    with engine.embedding_runtime(out / "embedding", image, configuration) as descriptor:
        def private_argv(actor, home, config):
            argv = original(actor, home, config)
            argv[argv.index("--network") + 1] = descriptor["network_id"]
            return argv
        native_module._native_argv = private_argv
        native = None
        try:
            native = native_module.Native("native", project, {"native_image": image,
                "runtime_manifest": str(parent / "native-runtime.json")})
            native.start()
            observed = engine.executor._inspect(native.cid)
            assert len(observed["NetworkSettings"]["Networks"]) == 1
            assert next(iter(observed["NetworkSettings"]["Networks"].values()))["NetworkID"] == descriptor["network_id"]
            for entry in members:
                identity, relative = entry["id"], Path(entry["root"])
                assert Path(identity).name == identity and identity not in ("", ".", "..")
                assert not relative.is_absolute() and ".." not in relative.parts
                directory = out / "members" / identity
                directory.mkdir()
                state_path = project / relative / ".codescout/index-state.json"
                old = latest / identity
                if not (old / "result.json").exists():
                    old = previous / identity
                reuse = (old / "command.json").exists() or (old / "reused-index.json").exists()
                if reuse:
                    command_path = old / "command.json"
                    if not command_path.exists():
                        chain = json.loads((old / "reused-index.json").read_bytes())
                        command_path = Path(chain["prior_command"])
                        assert engine.sha(command_path) == chain["prior_command_sha256"]
                    command = json.loads(command_path.read_bytes())
                    assert command["returncode"] == 0
                    assert json.loads(state_path.read_bytes()) == json.loads((old / "index-state.json").read_bytes())
                    if (old / "result.json").exists():
                        prior_result = json.loads((old / "result.json").read_bytes())
                        if "state_sha256" in prior_result:
                            assert prior_result["state_sha256"] == engine.sha(state_path)
                        else:
                            assert engine.sha(old / "semantic.json") == prior_result["semantic_sha256"]
                            assert engine.sha(old / "source-provenance.json") == prior_result["provenance_sha256"]
                    engine.save(directory / "reused-index.json", {
                        "prior_command": str(command_path), "prior_command_sha256": engine.sha(command_path),
                        "prior_state": str(old / "index-state.json"), "prior_state_sha256": engine.sha(old / "index-state.json"),
                        "state_sha256": engine.sha(state_path), "state_json_value_equal": True})
                    reused += 1
                else:
                    started = time.monotonic()
                    command = subprocess.run(["docker", "exec", native.cid, "/bench/bin/codescout", "index",
                        "-p", "/testbed/" + relative.as_posix()], capture_output=True, timeout=1800)
                    (directory / "index.stdout").write_bytes(command.stdout)
                    (directory / "index.stderr").write_bytes(command.stderr)
                    engine.save(directory / "command.json", {"returncode": command.returncode,
                        "wall_s": time.monotonic()-started})
                    assert command.returncode == 0
                state = json.loads(state_path.read_bytes())
                assert state["indexed_with_model"] == "CodeRankEmbed"
                engine.save(directory / "index-state.json", state)
                response = native.tool("semantic_search", {
                    "query": identity.replace("-", " ").replace("_", " ") + " source implementation",
                    "project_id": identity, "limit": 3, "detail_level": "full"}, timeout=240)
                engine.save(directory / "semantic.json", response)
                payload = json.loads(response["result"]["content"][0]["text"])
                assert payload.get("ok") is not False and payload.get("results"), payload
                provenance = [verify_hit(project / relative, hit) for hit in payload["results"]]
                engine.save(directory / "source-provenance.json", provenance)
                assert engine._public_digest(project) == public_sha
                assert all(engine.sha(path) == digest for path, digest in source_hashes.items())
                row = {"id": identity, "root": str(relative), "index_reused": reuse, "model": state["indexed_with_model"],
                    "returned_hits_checked": len(provenance),
                    "continuation_hits": sum(item["mode"] == "source-span-with-declared-continuation" for item in provenance),
                    "source_unchanged": True, "semantic_sha256": engine.sha(directory / "semantic.json"),
                    "provenance_sha256": engine.sha(directory / "source-provenance.json")}
                engine.save(directory / "result.json", row)
                rows.append(row)
                print(json.dumps(row), flush=True)
            engine.save(out / "root-index-verification.json", native.tool("index", {"action": "verify"}, timeout=240))
            engine.save(out / "result.json", {"configured_nonroot_count": len(members), "completed_member_count": len(rows),
                "all_configured_members_checked": len(rows) == len(members), "reused_indexes": reused,
                "new_explicit_index_cli_calls": len(rows)-reused, "members": rows, "source_unchanged": True,
                "client_model_calls": 0, "additional_onboarding_calls": 0, "paid_ready": False,
                "scope": "Member namespace and payload text provenance only; AST ownership, semantic relevance, LSP/author context and repair efficacy remain separate."})
        except BaseException as exc:
            engine.save(out / "failure.json", {"exception": type(exc).__name__, "message": str(exc), "paid_ready": False})
            raise
        finally:
            native_module._native_argv = original
            if native is not None:
                native.close()

if __name__ == "__main__":
    main()
