"""Freeze the original four public tasks for a real sixteen-slot zero-model qualification."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

MAIN = Path("/home/marius/work/claude/codescout")
WORK = Path("/home/marius/.codex/worktrees/2aa6/codescout")
BASE = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
OUT = BASE / "native-feedback-qualification-v1-registration"
RUN = Path("/var/tmp/native-feedback-qualified-v1-01a15")
FREEZE = MAIN / "docs/trackers/effort-steering/evidence/native-feedback-population-20261111"
sys.path.insert(0, str(WORK / "tools/effort_protocol"))
import campaign
import feedback_policy as policy
from native_executor import _public_digest
from preparation import _runtime, _runtime_inputs
from receipts import input_digest

CANARIES = {
    "apache__arrow-rs-7783": ("arrow-buffer/src/buffer/mutable.rs", "MutableBuffer", 62,
                            "impl MutableBuffer/new", "with_capacity", "MutableBuffer contiguous memory buffer"),
    "skim-rs__skim-1044": ("src/skim_item.rs", "SkimItem", 89,
                          "SkimItem/output", "text", "SkimItem trait text display preview output fuzzy matching"),
    "DioxusLabs__dioxus-5384": ("packages/core/src/nodes.rs", "VNode", 96,
                              "impl Default for VNode/default", "placeholder", "VNode placeholder dynamic nodes virtual DOM"),
    "nearai__ironclaw-6724": ("crates/ironclaw_common/src/hashing.rs", "sha256_hex", 10,
                            "tests/sha256_hex_matches_known_vector", "sha256_hex", "sha256_hex hexadecimal hash bytes helper"),
}
COMMON = {identity: ("common-preparation-v3" if identity.startswith("apache__") else "common-preparation-v1")
          for identity in CANARIES}


def read(path):
    return json.loads(Path(path).read_bytes())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")


def plan(source, probes):
    result = [["Skill", {"skill": "codescout-companion:reconnaissance"}],
              ["mcp__codescout__read_file", {"path": ".codescout/system-prompt.md", "force": True,
                                           "start_line": 1, "end_line": 100}],
              ["mcp__codescout__workspace", {"action": "status"}]]
    result.extend([["mcp__codescout__" + probe["tool"], probe["arguments"]] for probe in probes])
    original = (Path(source) / "Cargo.toml").read_text()
    assert original.encode() == (Path(source) / "Cargo.toml").read_bytes()
    result.append(["mcp__codescout__create_file", {"path": "Cargo.toml", "overwrite": True,
                  "content": original + "\n[qualification_invalid_header\n"}])
    for index in range(4):
        result.append(["__qualification_end_turn__", {}])
        if index < 3:
            result.append(["mcp__codescout__workspace", {"action": "status"}])
    result.append(["mcp__codescout__create_file", {"path": "Cargo.toml", "overwrite": True, "content": original}])
    return result


def main():
    assert Path(__file__).stat().st_mode & 0o222 == 0
    assert not RUN.exists()
    OUT.mkdir(mode=0o700)
    rule = read(FREEZE / "selection-rule.json")
    status = read(FREEZE / "status-initial.json")
    metadata = read(FREEZE / "original-metadata.json")["tasks"]
    metadata = [dict(row, **({"eligible": True, "reason": "fixed public/private controls qualified"}
                             if row["id"] in CANARIES else status[row["id"]])) for row in metadata]
    exposure = read(FREEZE / "exposure.json")["tasks"]
    selected = campaign.selection_report(metadata, set(exposure), rule["seed"], task_count=4)
    assert selected["complete"] and {row["id"] for row in selected["selected"]} == set(CANARIES)
    save(OUT / "selection.json", selected)
    accounting = read(MAIN / "docs/trackers/effort-steering/evidence/native-feedback-accounting-20261111/admission-inputs/qualification.json")["registration"]
    prior = read("/var/tmp/ep11-01a15/headroom-native-qualification-v1/registration.json")
    shared = next(iter(prior["tasks"].values()))["backend"]["public"]
    reg = {"schema": policy.SCHEMA, "campaign_id": "native-feedback-qualified-v1-01a15", "mode": "scripted",
           "output_root": str(RUN), "metadata": metadata, "exposure": exposure, "seed": rule["seed"],
           "order_seed": rule["order_seed"], "selected": selected["selected"], "tasks": {},
           "ledger": copy.deepcopy(accounting["ledger"]), "carried_holds": copy.deepcopy(accounting["carried_holds"]),
           "bindings": copy.deepcopy(accounting["bindings"])}
    for row in policy.balanced_schedule([item["id"] for item in selected["selected"]], reg["order_seed"]):
        spec = policy.condition_spec(row["arm"], ".")
        reg.setdefault("schedule", []).append(dict(row, cli_cap_usd=spec["cli_cap_usd"], reserved_usd=spec["reserve_usd"]))
    for identity, (path, symbol, line, caller, callee, query) in CANARIES.items():
        packet_path = BASE / "fixture-complete-controls-v1" / identity / "preparation.json"
        packet = read(packet_path)
        task = copy.deepcopy(packet["task"])
        private = task["backend"]["private"]
        config = read(private["config"])
        original = read(config["record"])
        common = BASE / identity / COMMON[identity]
        template = common / "project"
        public = task["backend"]["public"]
        build = public["public_build_inputs"]
        assert input_digest(task["source"]) == task["source_sha256"]
        assert _public_digest(template, dependency_dirs=build["dependency_dirs"], preserve_project_context=True) == task["source_sha256"]
        manifest = read(common / ("native-runtime-private-v4.json" if identity.startswith("apache__") else "native-runtime.json"))
        manifest["Image"] = public["image"]
        runtime_path = OUT / (identity + "-native-runtime.json")
        save(runtime_path, manifest)
        runtime = copy.deepcopy(shared["runtime"])
        assert _runtime(_runtime_inputs(runtime)) == runtime
        bin_source = next(item["Source"] for item in manifest["Mounts"] if item["Destination"] == "/bench/bin")
        assert sha(Path(bin_source) / "codescout") == runtime["files"]["codescout"]["sha256"]
        knowledge = template / ".codescout"
        paths = ["project.toml", "system-prompt.md"] + sorted(
            item.relative_to(knowledge).as_posix() for item in (knowledge / "memories").rglob("*.md") if item.is_file())
        if (knowledge / "workspace.toml").is_file():
            paths.append("workspace.toml")
        probes = [
            {"tool": "references", "arguments": {"path": path, "symbol": symbol, "limit": 20},
             "must_contain": [symbol]},
            {"tool": "symbol_at", "arguments": {"path": path, "line": line, "identifier": symbol},
             "must_contain": [symbol]},
            {"tool": "call_graph", "arguments": {"path": path, "symbol": caller, "direction": "callees", "max_depth": 1},
             "must_contain": ["→ " + callee]},
            {"tool": "semantic_search", "arguments": {"query": query, "limit": 3},
             "must_contain": [Path(path).name]},
        ]
        public.update(template=str(template), template_sha256=input_digest(template), knowledge_paths=paths,
                      knowledge_sha256=input_digest(knowledge, paths), runtime_manifest=str(runtime_path), runtime=runtime,
                      global_rules=shared["global_rules"], global_rules_sha256=shared["global_rules_sha256"],
                      embedding={**shared["embedding"], "subnet": "100.125.0.0/28"},
                      registered_readiness={"project_root": "/testbed", "languages": ["rust"],
                          "tools": ["symbols", "references", "symbol_at", "call_graph", "semantic_search"],
                          "probes": probes, "index_omission_policy": "ascii-whitespace-source-v1"},
                      feedback_policy={"schema": policy.SCHEMA, "workspace": "."},
                      capture_base_commit=subprocess.check_output(["git", "-C", str(template), "rev-parse", "HEAD"], text=True).strip(),
                      source_baseline={"path": task["source"], "sha256": task["source_sha256"]},
                      cli_checks=[], timeout_s=3600, check_timeout_s=900, command_timeout_s=900,
                      max_log_bytes=67108864, allowed_probe_prefixes=["probes/"], lsp_warmup_retries=1,
                      resource_root=str(WORK), resource_floors=copy.deepcopy(shared["resource_floors"]))
        task["public_packet"] = {"issue": original["problem_statement"]}
        expected = next(item["public_issue_sha256"] for item in selected["selected"] if item["id"] == identity)
        assert hashlib.sha256(original["problem_statement"].encode()).hexdigest() == expected
        entry = WORK / "tools/effort_protocol/evaluator_entry.py"
        private.update(entry=str(entry), entry_sha256=sha(entry))
        task["backend"]["scripted_plans"] = {arm + ":repair": plan(task["source"], probes) for arm in "LRPX"}
        reg["tasks"][identity] = task
        reg["bindings"].update(packet["bindings"])
        for item in (packet_path, runtime_path, entry, Path(private["config"])):
            reg["bindings"][str(item)] = sha(item)
    scope = OUT / "scope.json"
    save(scope, {"scope": "Real16CLI, same four public tasks and canonical evaluators. Scripted model restores original manifest after four public failures; no task repair or efficacy claim.",
                 "client_author_calls": 0, "client_provider_calls": 0, "compute_cost": "unknown", "paid_ready": False})
    reg["shared_preparation"] = {"cost_usd": "0", "receipt_sha256": sha(scope)}
    driver = Path(__file__).with_name("qualify_native_feedback_campaign_v1.py").absolute()
    reg["qualification_driver"] = {"path": str(driver), "sha256": sha(driver)}
    reg["qualification_driver_dependencies"] = [{"path": str(Path(__file__).absolute()), "sha256": sha(__file__)}]
    files = [Path(__file__).absolute(), driver, scope, *FREEZE.glob("*.json"),
             *[p for folder in ("effort_protocol", "agent_lifecycle", "hint_authority_pilot")
               for p in (WORK / "tools" / folder).glob("*.py") if not p.name.startswith("test_") and p.name != "paid_admission.py"],
             WORK / "tools/effort_protocol/prompts.json"]
    for path in files:
        reg["bindings"][str(path)] = sha(path)
    save(OUT / "registration.json", reg)
    print(json.dumps({"registration": str(OUT / "registration.json"), "attempts": len(reg["schedule"]),
                      "task_ids": list(reg["tasks"]), "paid_ready": False}), flush=True)


if __name__ == "__main__":
    main()
