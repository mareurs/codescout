"""Run the original pause probe after the explicit standalone v2 entry bootstrap."""
import importlib.util
from pathlib import Path

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

if __name__ == "__main__":
    load("standalone_v2", Path(__file__).with_name("qualify_native_feedback_campaign_v2.py"))
    probe = load("original_pause_probe", Path(__file__).with_name("probe_qualification_pause_v1.py"))
    probe.main()
