"""Qualify final private cache/image roles before the original Ironclaw baseline/reference/repeat."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
MAIN=Path("/home/marius/work/claude/codescout")
WORK=Path("/home/marius/.codex/worktrees/2aa6/codescout")
SCRIPTS=MAIN/".superpowers/sdd/2026-11-11-native-public-feedback-transfer"
ROOT=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/nearai__ironclaw-6724")
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):
    with path.open("x") as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write(chr(10))
def main():
    assert Path(__file__).stat().st_mode & 0o222==0
    image_root=ROOT/"private-cache-owner-image-v5"
    built=json.loads((image_root/"result.json").read_bytes());image=built["image"]
    assert built["generated_cache_owner_correction"] and built["source_unchanged"] and not built["gold_warmup"]
    assert json.loads((image_root/"public-readback-v1/result.json").read_bytes())["complete"]
    assert json.loads((image_root/"public-readback-v1/cleanup.json").read_bytes())["complete"]
    before=json.loads(json.loads((image_root/"write-before.json").read_bytes())["stdout"])
    after=json.loads(json.loads((image_root/"write-after.json").read_bytes())["stdout"])
    assert before["sha256"]==after["sha256"] and not before["rolled_back_schema_write"] and after["rolled_back_schema_write"]
    assert before["uid"]==1000 and after["uid"]==0 and before["cap_eff"]==after["cap_eff"]=="0000000000000000"
    out=ROOT/"private-qualification-v4";out.mkdir(mode=0o700)
    names=("qualify_private_root_write_v5.py","qualify_private_captured_format_v5.py",
        "prepare_ironclaw_private_v4.py","run_ironclaw_private_v4.py")
    assert all((SCRIPTS/name).stat().st_mode & 0o222==0 for name in names)
    paths=[SCRIPTS/name for name in names]
    paths += [WORK/"tools/effort_protocol"/name for name in ("evaluator_entry.py","trusted_test_inputs.py",
        "feedback_trusted_inputs.py","feedback_private_commands.py","feedback_private_capture.py")]
    paths += [image_root/name for name in ("registration.json","result.json","write-before.json","write-after.json")]
    paths += [Path(__file__)]
    bindings={str(path):sha(path) for path in paths}
    save(out/"registration.json",{"schema":"private-frontend-role-qualification-v4","image":image,
        "bindings":bindings,"steps":list(names),"client_model_calls":0,"paid_ready":False,
        "scope":"Private evaluator uid0 cache and format roles only; no task substitution or Gold warm-up, no model/paid work."})
    rows=[]
    for number,name in enumerate(names,1):
        assert all(sha(path)==digest for path,digest in bindings.items())
        directory=out/("step-"+str(number));directory.mkdir()
        args=[sys.executable,"-B",str(SCRIPTS/name),"nearai__ironclaw-6724"];started=time.monotonic()
        with (directory/"stdout.log").open("xb") as stdout,(directory/"stderr.log").open("xb") as stderr:
            run=subprocess.run(args,cwd=MAIN,stdout=stdout,stderr=stderr,
                env={"PATH":os.environ["PATH"],"HOME":os.environ["HOME"],"TMPDIR":"/var/tmp","PYTHONDONTWRITEBYTECODE":"1"})
        row={"producer":name,"returncode":run.returncode,"wall_s":time.monotonic()-started,
            "stdout_sha256":sha(directory/"stdout.log"),"stderr_sha256":sha(directory/"stderr.log")}
        save(directory/"command.json",row);rows.append(row);print(json.dumps({"step":number,**row}),flush=True)
        if run.returncode:
            save(out/"stopped.json",{"steps":rows,"paid_ready":False,"client_model_calls":0,"reason":"First failed qualification, no silent retry or task/model resampling."})
            return 1
    assert json.loads((ROOT/"private-preparation-v4/controls-result.json").read_bytes())["all_three_controls_met"]
    assert all(sha(path)==digest for path,digest in bindings.items())
    save(out/"result.json",{"complete":True,"image":image,"steps":rows,"client_model_calls":0,"paid_ready":False,
        "scope":"Private deterministic control execution only; independent audit, actor/public native admission and scientific efficacy remain pending."})
    return 0
if __name__=="__main__":raise SystemExit(main())
