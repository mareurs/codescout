"""Relocate exact archived preparation-only helper bytes; keep Arrow records, image, source and assertions unchanged."""
from pathlib import Path
import copy,hashlib,json,sys,tarfile
sys.dont_write_bytecode=True
WORK=Path("/home/marius/.codex/worktrees/2aa6/codescout")
MAIN=Path("/home/marius/work/claude/codescout")
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from evaluator_entry import verify_package,_load,_input_digest
ROOT=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/apache__arrow-rs-7783")
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):
    with path.open("x") as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write(chr(10))
def main():
    assert Path(__file__).stat().st_mode & 0o222==0
    old=ROOT/"private-preparation-v5";reg=json.loads((old/"registration.json").read_bytes())
    assert sha(old/"config.json")==reg["config_sha256"]
    config=json.loads((old/"config.json").read_bytes())
    helper=WORK/"tools/effort_protocol/feedback_private_commands.py";want=config["bindings"][str(helper)]
    assert want=="4cf4b18e954243bee02cebf7fd762e378dda565761e0f5fa0872e080f0b11c53"
    for name,digest in config["bindings"].items():
        if name!=str(helper):assert sha(name)==digest
    package=verify_package(config["package_root"],config["package_files"])
    archive=MAIN/"docs/trackers/effort-steering/evidence/native-feedback-baseline-20261111/task5-member-transfer-v1.tar.gz"
    assert sha(archive)=="20b9b67f8e262441e79625f4a575edf7dba1802b553c9fb885f5fcfa231c79b9"
    member="tools/effort_protocol/feedback_private_commands.py"
    with tarfile.open(archive) as stream:
        entry=stream.getmember(member);assert entry.isfile() and entry.size==2448
        data=stream.extractfile(entry).read()
    assert hashlib.sha256(data).hexdigest()==want
    out=ROOT/"private-preparation-v6";out.mkdir(mode=0o700)
    snapshot=out/"frozen-preparation-helper";snapshot.mkdir()
    frozen=snapshot/"feedback_private_commands.py";frozen.write_bytes(data);frozen.chmod(0o444)
    save(out/"helper-provenance.json",{"archive":str(archive),"archive_sha256":sha(archive),"member":member,
        "member_sha256":want,"snapshot":str(frozen),"snapshot_sha256":sha(frozen),
        "role":"Preparation-only helper bytes, not imported by the private grader; historical version preserved exactly."})
    config=copy.deepcopy(config)
    del config["bindings"][str(helper)]
    config["bindings"].update({str(frozen):want,str(out/"helper-provenance.json"):sha(out/"helper-provenance.json"),str(Path(__file__)):sha(__file__)})
    assert all(sha(name)==digest for name,digest in config["bindings"].items())
    save(out/"config.json",config)
    _load(config)
    controls=[]
    for control in reg["controls"]:
        old_request=Path(control["request"]);assert sha(old_request)==control["request_sha256"]
        request=json.loads(old_request.read_bytes())
        assert _input_digest(request["source"])==request["source_digest"]
        assert _input_digest(request["public_baseline"])==request["public_baseline_sha256"]
        changed=copy.deepcopy(request);changed["config"]=str(out/"config.json");changed["config_sha256"]=sha(out/"config.json")
        assert {k:v for k,v in changed.items() if k not in ("config","config_sha256")}=={k:v for k,v in request.items() if k not in ("config","config_sha256")}
        directory=out/("control-"+control["name"]);directory.mkdir()
        save(directory/"request.json",changed)
        controls.append({**control,"request":str(directory/"request.json"),"request_sha256":sha(directory/"request.json")})
    new=copy.deepcopy(reg)
    new.update(config_sha256=sha(out/"config.json"),controls=controls,producer_sha256=sha(__file__),
        unchanged_prior_config=str(old/"config.json"),unchanged_prior_config_sha256=reg["config_sha256"],
        frozen_preparation_helper=str(frozen),frozen_preparation_helper_sha256=want,client_model_calls=0,paid_ready=False,
        scope="Only relocate exact preparation-only helper bytes into an immutable versioned snapshot. Record/parser/labels/assertions/commands/image/source/99file grader unchanged; actual baseline/reference/repeat pending.")
    save(out/"registration.json",new)
    verify_package(package,config["package_files"])
    assert all(sha(name)==digest for name,digest in config["bindings"].items())
    print(json.dumps({"task":reg["task"],"prepared":str(out),"record_unchanged":True,"image_unchanged":True,
        "helper_snapshot_sha256":want,"client_model_calls":0,"paid_ready":False}),flush=True)
if __name__=="__main__":main()
