"""Versioned member namespace indexing with an explicitly created embedding output."""
from pathlib import Path
import argparse, fcntl, hashlib, importlib.util, json, subprocess, sys, time
sys.dont_write_bytecode = True
sys.path.insert(0, "/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from embedding_runtime import embedding_runtime
from native_executor import _public_digest
import executor
SCRIPTS = Path("/home/marius/work/claude/codescout/.superpowers/sdd/2026-11-11-native-public-feedback-transfer")
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--preparation", type=Path, required=True)
    parser.add_argument("--first-only", action="store_true")
    args = parser.parse_args()
    parent = args.preparation.resolve(strict=True)
    prep = json.loads((parent / "preparation.json").read_bytes())
    root = parent / "index-coderank-v1"
    root_result = json.loads((root / "result.json").read_bytes())
    assert root_result["index_exit"] == 0 and root_result["source_digest_unchanged"]
    for name in ("native", "embedding"):
        cleanup = json.loads((root / name / "cleanup.json").read_bytes())
        assert cleanup.get("complete", cleanup.get("cleanup_complete")) is True
    registration = json.loads((parent / "registration.json").read_bytes())
    project = parent / "project"
    public_sha = prep["template_public_sha256"]
    assert _public_digest(project) == public_sha
    image = registration["image"]
    configuration = json.loads((root / "registration.json").read_bytes())["embedding"]
    members = [entry for entry in prep["configured_projects"] if entry["root"] != "."]
    assert members and len(members) == len({entry["id"] for entry in members})
    for entry in members:
        relative = Path(entry["root"])
        assert not relative.is_absolute() and ".." not in relative.parts
        assert Path(entry["id"]).name == entry["id"] and entry["id"] not in ("", ".", "..")
        assert (project / relative).resolve(strict=True).is_relative_to(project.resolve())
    # Test a configured alias before the boring basename case, without task/outcome inputs.
    members.sort(key=lambda entry: (entry["id"] == Path(entry["root"]).name, entry["root"], entry["id"]))
    selected = members[:1] if args.first_only else members
    out = parent / "configured-member-qualification-v2"
    out.mkdir(exist_ok=True)
    with (out / "controller.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        mode = "first" if args.first_only else "all"
        run = out / ("run-" + mode)
        run.mkdir()
        (run / "embedding").mkdir()
        save(run / "registration.json", {"configured_members": members, "selected_members": selected,
            "configured_nonroot_count": len(members), "selected_count": len(selected),
            "source_public_sha256": public_sha, "image": image, "producer_sha256": sha(__file__),
            "runtime_sha256": sha(parent / "native-runtime.json"), "root_preparation_sha256": sha(parent / "preparation.json"),
            "additional_onboarding_calls": 0, "client_model_calls": 0, "embedding_compute_cost_usd": None,
            "paid_ready": False, "scope": "Member namespace/source-content checks; not semantic relevance or repair quality."})
        module_spec = importlib.util.spec_from_file_location("prepared_member_native", SCRIPTS / "prior_prepare_native.py")
        module = importlib.util.module_from_spec(module_spec)
        module_spec.loader.exec_module(module)
        module.ROOT, module.IMAGE = run, image
        original = module._native_argv
        rows = []
        reused = 0
        with embedding_runtime(run / "embedding", image, configuration) as descriptor:
            def private_argv(actor, home, config):
                argv = original(actor, home, config)
                argv[argv.index("--network") + 1] = descriptor["network_id"]
                return argv
            module._native_argv = private_argv
            native = None
            try:
                native = module.Native("native", project, {"native_image": image,
                    "runtime_manifest": str(parent / "native-runtime.json")})
                native.start()
                actual = executor._inspect(native.cid)
                assert len(actual["NetworkSettings"]["Networks"]) == 1
                assert next(iter(actual["NetworkSettings"]["Networks"].values()))["NetworkID"] == descriptor["network_id"]
                for entry in selected:
                    identity, relative = entry["id"], Path(entry["root"])
                    directory = out / identity
                    state_path = project / relative / ".codescout/index-state.json"
                    if (directory / "result.json").exists():
                        previous = json.loads((directory / "result.json").read_bytes())
                        assert previous["id"] == identity and previous["root"] == str(relative)
                        assert previous["source_public_sha256"] == public_sha
                        assert previous["producer_sha256"] == sha(__file__)
                        assert sha(state_path) == previous["state_sha256"]
                        assert sha(directory / "semantic.json") == previous["semantic_sha256"]
                        rows.append(previous)
                        reused += 1
                        continue
                    directory.mkdir()
                    started = time.monotonic()
                    command = subprocess.run(["docker", "exec", native.cid, "/bench/bin/codescout",
                        "index", "-p", "/testbed/" + relative.as_posix()], capture_output=True, timeout=1800)
                    (directory / "index.stdout").write_bytes(command.stdout)
                    (directory / "index.stderr").write_bytes(command.stderr)
                    save(directory / "command.json", {"returncode": command.returncode, "wall_s": time.monotonic()-started})
                    assert command.returncode == 0
                    state = json.loads(state_path.read_bytes())
                    save(directory / "index-state.json", state)
                    assert state["indexed_with_model"] == "CodeRankEmbed"
                    response = native.tool("semantic_search", {"query": identity.replace("-", " ").replace("_", " ") + " source implementation",
                        "project_id": identity, "limit": 3}, timeout=240)
                    save(directory / "semantic.json", response)
                    payload = json.loads(response["result"]["content"][0]["text"])
                    assert payload.get("ok") is not False and payload.get("results"), payload
                    for hit in payload["results"]:
                        path = Path(hit["file_path"])
                        assert not path.is_absolute() and ".." not in path.parts
                        local = project / relative / path
                        assert local.is_file() and not local.is_symlink()
                        lines = local.read_text().splitlines()
                        text = "\n".join(lines[hit["start_line"]-1:hit["end_line"]])
                        assert hit["content"].strip() in text and hit["source"] == "stack", hit
                    assert _public_digest(project) == public_sha
                    row = {"id": identity, "root": str(relative), "model": state["indexed_with_model"],
                        "returned_hits_checked": len(payload["results"]), "source_public_sha256": public_sha,
                        "producer_sha256": sha(__file__), "state_sha256": sha(state_path),
                        "semantic_sha256": sha(directory / "semantic.json"), "source_unchanged": True}
                    save(directory / "result.json", row)
                    rows.append(row)
                    print(json.dumps(row), flush=True)
                assert _public_digest(project) == public_sha
                save(run / "result.json", {"configured_nonroot_count": len(members),
                    "requested_member_count": len(selected), "completed_member_count": len(rows),
                    "reused_index_checkpoints": reused, "new_index_calls": len(rows)-reused,
                    "complete_configured_population": len(rows) == len(members), "members": rows,
                    "source_unchanged": True, "additional_onboarding_calls": 0,
                    "client_model_calls": 0, "paid_ready": False,
                    "scope": "Literal member namespace and returned source-content checks; first-only is a subset, not all-member qualification."})
            except BaseException as exc:
                save(run / "failure.json", {"exception": type(exc).__name__, "message": str(exc), "paid_ready": False})
                raise
            finally:
                module._native_argv = original
                if native is not None:
                    native.close()

if __name__ == "__main__":
    main()
