"""Reopen the already qualified local compatibility prefix; no global library change."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
OLD = Path("/var/tmp/ep11-01a15/gate-openssl35-v1")
OUT = Path("/var/tmp/native-feedback-gate-openssl-readback-20261112")
assert not OUT.exists()
OUT.mkdir()
old = json.loads((OLD / "result.json").read_bytes())
for name, row in old["manifest"].items():
    path = Path(name)
    if row["type"] == "symlink":
        assert path.is_symlink() and str(path.readlink()) == row["target"], path
    else:
        data = path.read_bytes()
        assert len(data) == row["bytes"] and hashlib.sha256(data).hexdigest() == row["sha256"], path
command = list(old["compile_argv"])
command[-1] = str(OUT / "version-probe")
compiled = subprocess.run(command, capture_output=True, text=True)
assert compiled.returncode == 0, compiled.stderr
environment = dict(os.environ, **old["environment"])
measured = subprocess.run([str(OUT / "version-probe")], env=environment, capture_output=True, text=True)
assert measured.returncode == 0 and measured.stdout.splitlines() == old["header_runtime_version_probe"]
host = subprocess.run(["pkg-config", "--modversion", "openssl"], capture_output=True, text=True)
assert host.returncode == 0 and host.stdout.strip() == "4.1.0"
result = {"scope": "Per-command gate environment; host remains OpenSSL4.1.0",
          "old_result_sha256": hashlib.sha256((OLD / "result.json").read_bytes()).hexdigest(),
          "prefix_entries_reopened": len(old["manifest"]), "compile_argv": command,
          "source_sha256": hashlib.sha256((OLD / "version_probe.c").read_bytes()).hexdigest(),
          "binary_sha256": hashlib.sha256((OUT / "version-probe").read_bytes()).hexdigest(),
          "header_runtime": measured.stdout.splitlines(), "environment": old["environment"],
          "global_changes": False, "paid_ready": False}
(OUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result))
