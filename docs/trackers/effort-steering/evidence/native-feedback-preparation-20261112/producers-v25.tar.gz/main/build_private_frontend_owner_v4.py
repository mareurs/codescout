"""Extend the private uid0 owner contract to frontend offline SQLite caches; preserve every old control."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess,sys,uuid
BASE=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
IDS=("nearai__ironclaw-6724",)
WORK=Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.dont_write_bytecode=True;sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from evaluator_entry import _input_digest
PROBE="""from pathlib import Path
import hashlib,json,os,sqlite3,stat,uuid
path=Path('/bench/public-dependencies/pnpm-store/v11/index.db');s=path.stat()
result={"euid":os.geteuid(),"cap_eff":next(x.split()[1] for x in Path('/proc/self/status').read_text().splitlines() if x.startswith('CapEff:')),
    "path":str(path),"uid":s.st_uid,"gid":s.st_gid,"mode":oct(stat.S_IMODE(s.st_mode)),"sha256":hashlib.sha256(path.read_bytes()).hexdigest()}
connection=None
try:
    connection=sqlite3.connect(path,timeout=3)
    connection.execute('BEGIN IMMEDIATE')
    connection.execute('CREATE TABLE __effort_probe_'+uuid.uuid4().hex+' (value integer)')
    connection.rollback()
    result["rolled_back_schema_write"]=True
except sqlite3.Error as exc:
    result.update(rolled_back_schema_write=False,error=str(exc),sqlite_errorcode=getattr(exc,'sqlite_errorcode',None))
finally:
    if connection is not None:connection.close()
print(json.dumps(result,sort_keys=True))
"""
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):
    with path.open("x") as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write(chr(10))
def probe_image(image,path,expected):
    name="ep-pnpm-sqlite-"+uuid.uuid4().hex
    args=["docker","run","--rm","--pull=never","--name",name,"--network","none","--user","0:0",
        "--memory","1g","--memory-swap","1g","--cpus","1","--pids-limit","128","--cap-drop","ALL",
        "--security-opt","no-new-privileges","--label","effort-feedback-owner=codex:01a15ca9-f939-7603-acb5-01c6b02f68e2",
        "--entrypoint","python3",image,"-I","-B","-c",PROBE]
    run=subprocess.run(args,capture_output=True,timeout=120)
    save(path,{"image":image,"argv":args,"returncode":run.returncode,"stdout":run.stdout.decode(),"stderr":run.stderr.decode()})
    assert run.returncode==0
    found=json.loads(run.stdout);assert found["euid"]==0 and int(found["cap_eff"],16)==0
    assert found["rolled_back_schema_write"] is expected
    if expected:assert found["uid"]==0
    else:assert found["uid"]==1000 and found["sqlite_errorcode"]==8
    absent=subprocess.run(["docker","container","inspect",name],capture_output=True,timeout=30)
    assert absent.returncode==1 and name.encode() in absent.stderr and b"No such" in absent.stderr

def main():
    assert Path(__file__).stat().st_mode & 0o222==0
    for identity in IDS:
        root=BASE/identity;prior=root/"common-clean-image-v3"
        old=json.loads((prior/"result.json").read_bytes());image=old["image"]
        assert old["workspace_base_cleanup_and_compile_warmup"] and not old["gold_warmup"]
        assert not json.loads((prior/"image.json").read_bytes())["Config"].get("Volumes")
        public=root/"common-preparation-v1/public-source";before=_input_digest(public)
        assert before==json.loads((prior/"registration.json").read_bytes())["source_sha256"]
        out=root/"private-cache-owner-image-v4";out.mkdir()
        free=shutil.disk_usage(out).free;assert free>=80*1024**3
        context=out/"context";context.mkdir()
        parent_tag="ep-feedback-root-parent-"+uuid.uuid4().hex+":frozen"
        tagged=subprocess.run(["docker","tag",image,parent_tag],capture_output=True,timeout=60)
        assert tagged.returncode==0
        parent=subprocess.run(["docker","image","inspect",parent_tag],capture_output=True,timeout=60)
        assert parent.returncode==0 and json.loads(parent.stdout)[0]["Id"]==image
        recipe="FROM "+parent_tag+chr(10)+"USER root"+chr(10)+'RUN chown -R 0:0 /bench/public-dependencies'+chr(10)
        (context/"Dockerfile").write_text(recipe)
        probe_image(image,out/"write-before.json",False)
        target="ep-feedback-root-cache-"+uuid.uuid4().hex+":base"
        save(out/"registration.json",{"schema":"private-frontend-cache-owner-image-v4","task":identity,"parent_image":image,
            "prior_result_sha256":sha(prior/"result.json"),"prior_recipe_sha256":sha(prior/"context/Dockerfile"),
            "parent_tag":parent_tag,"target_tag":target,"recipe_sha256":sha(context/"Dockerfile"),"producer_sha256":sha(__file__),
            "source":str(public),"source_sha256":before,"host_disk_free_bytes":free,"runtime_user":"0:0",
            "changed_roles":["frontend offline store/cache/state/Corepack ownership"],
            "source_assertions_and_labels_unchanged":True,"client_model_calls":0,"paid_ready":False,
            "scope":"Ownership correction only; no model call, official/Gold patch, repeated onboarding/index or functional claim."})
        run=subprocess.run(["docker","build","--pull=false","--network","none","-t",target,str(context)],
            capture_output=True,timeout=3600)
        (out/"stdout.log").write_bytes(run.stdout);(out/"stderr.log").write_bytes(run.stderr)
        save(out/"command.json",{"returncode":run.returncode,"stdout_sha256":sha(out/"stdout.log"),"stderr_sha256":sha(out/"stderr.log")})
        assert run.returncode==0
        actual=subprocess.run(["docker","image","inspect",target],capture_output=True,timeout=120)
        assert actual.returncode==0
        row=json.loads(actual.stdout)[0];assert re.fullmatch("sha256:[0-9a-f]{64}",row["Id"])
        assert row["Config"]["User"]=="root" and not row["Config"].get("Volumes")
        save(out/"image.json",row);assert _input_digest(public)==before
        probe_image(row["Id"],out/"write-after.json",True)
        parent=subprocess.run(["docker","image","inspect",parent_tag],capture_output=True,timeout=60)
        assert parent.returncode==0 and json.loads(parent.stdout)[0]["Id"]==image
        save(out/"result.json",{"image":row["Id"],"parent_image":image,"source_unchanged":True,
            "generated_cache_owner_correction":True,"workspace_base_cleanup_and_compile_warmup":True,"gold_warmup":False,
            "frozen_package_unchanged":old["frozen_package_unchanged"],"canonical_seed_restored":old["canonical_seed_restored"],
            "client_model_calls":0,"paid_ready":False,
            "scope":"Image ownership correction built only; final readback/write-access/functional controls still pending."})
        print(json.dumps({"task":identity,"image":row["Id"],"source_unchanged":True,"client_model_calls":0,"paid_ready":False}),flush=True)
if __name__=="__main__":main()
