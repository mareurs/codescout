"""Versioned complete original pnpm install/cache preparation with explicit runtime offline mode."""
import argparse, hashlib, json, re, shutil, subprocess, sys
from pathlib import Path
sys.dont_write_bytecode = True
WORK = Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path.insert(0, str(WORK / "tools/effort_protocol"))
from receipts import input_digest
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
CACHE = "/bench/public-dependencies"
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")
def inspect(image):
    return json.loads(subprocess.check_output(["docker", "image", "inspect", image]))[0]

FETCH = r"""
import hashlib,json,os,shutil,subprocess
from pathlib import Path
expected=json.loads(Path('/dependency-control/expected.json').read_bytes())
root=Path('/dependency-source')
project=root/expected['project']
env=dict(os.environ,COREPACK_ENABLE_NETWORK='1',COREPACK_ENABLE_DOWNLOAD_PROMPT='0',pnpm_config_offline='false')
for key in ('corepack_home','store','cache_dir','state_dir'):
 Path(expected[key]).mkdir(parents=True,exist_ok=True)
def run(argv):
 r=subprocess.run(argv,cwd=project,env=env,capture_output=True,text=True,timeout=1200)
 print(json.dumps(dict(argv=argv,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr)),flush=True)
 r.check_returncode()
 return r.stdout.strip()
for relative,digest in expected['inputs'].items():
 assert hashlib.sha256((project/relative).read_bytes()).hexdigest()==digest
versions_before={'node':run(['node','-v']),'corepack':run(['corepack','--version'])}
assert versions_before['node'].startswith('v22.')
manager=run(['corepack','pnpm','--version'])
assert 'pnpm@'+manager==expected['package_manager']
store=run(['corepack','pnpm','config','get','storeDir'])
assert store==expected['store']
for key,field in [('cacheDir','cache_dir'),('stateDir','state_dir')]:
 assert run(['corepack','pnpm','config','get',key])==expected[field]
assert run(['corepack','pnpm','config','get','offline'])=='false'
run(['corepack','pnpm','fetch','--frozen-lockfile'])
run(['corepack','pnpm','install','--frozen-lockfile'])
for relative,digest in expected['inputs'].items():
 assert hashlib.sha256((project/relative).read_bytes()).hexdigest()==digest
versions_after={'node':run(['node','-v']),'corepack':run(['corepack','--version'])}
assert versions_before==versions_after
for name in (expected['corepack_home'],expected['store'],expected['cache_dir'],expected['state_dir']):
 p=Path(name)
 assert p.is_dir()
 subprocess.run(['chmod','-R','a+rX',str(p)],check=True)
# pnpm's project-reference index points at this disposable fetch workspace.
# Keep dependency blobs; remove only these newly generated stale references.
references=[]
project_refs=Path(expected['store'])/'v11/projects'
assert project_refs.is_dir()
for path in project_refs.iterdir():
 assert path.is_symlink()
 target=os.readlink(path)
 assert path.resolve()==project.resolve()
 references.append({'path':str(path),'target':target})
for item in references:
 Path(item['path']).unlink()
assert not list(project_refs.iterdir())
Path('/dependency-control/pnpm-cache-result.json').write_text(json.dumps({
 'package_manager':expected['package_manager'],'project':expected['project'],
 'inputs':expected['inputs'],'original_locked_inputs_unchanged':True,
 'versions_before':versions_before,'versions_after':versions_after,
 'corepack_home':expected['corepack_home'],'pnpm_store':expected['store'],
 'pnpm_cache_dir':expected['cache_dir'],'pnpm_state_dir':expected['state_dir'],
 'runtime_pnpm_offline':True,'install_argv':['corepack','pnpm','install','--frozen-lockfile'],
 'fetch_argv':['corepack','pnpm','fetch','--frozen-lockfile'],
 'removed_ephemeral_workspace_references':references,
 'precomputed_frontend_bundle':False,'client_model_calls':0,'paid_ready':False,
 'scope':'Pinned tooling and original dependency store only; offline install/build and strict runtime remain pending.'
},sort_keys=True,indent=2)+'\n')
shutil.rmtree(root)
"""

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--task-id", required=True)
    parser.add_argument("--parent-metadata", type=Path, required=True)
    parser.add_argument("--project", required=True)
    args = parser.parse_args()
    task = ROOT / args.task_id
    source = task / "source"
    public_sha = input_digest(source)
    relative = Path(args.project)
    assert not relative.is_absolute() and ".." not in relative.parts and str(relative) == args.project
    frontend = source / relative
    assert frontend.resolve(strict=True).is_relative_to(source.resolve()) and frontend.is_dir()
    names = ("package.json", "pnpm-lock.yaml", "pnpm-workspace.yaml")
    assert all((frontend / name).is_file() and not (frontend / name).is_symlink() for name in names)
    inputs = {name: sha(frontend / name) for name in names}
    package_manager = json.loads((frontend / "package.json").read_bytes())["packageManager"]
    assert re.fullmatch(r"pnpm@[0-9]+\.[0-9]+\.[0-9]+", package_manager)
    parent = json.loads(args.parent_metadata.read_bytes())
    before = inspect(parent["image"])
    assert inspect(parent["tag"])["Id"] == before["Id"] and not before["Config"].get("Volumes")
    assert shutil.disk_usage(task).free >= 2 * before["Size"] + 80 * 1024**3
    out = task / "pnpm-cache-image-v4"
    tag = "effort-feedback-source:pnpm-cache-v4-" + before["Id"][7:19]
    assert subprocess.run(["docker", "image", "inspect", tag], capture_output=True).returncode != 0
    out.mkdir()
    context = out / "context"
    context.mkdir()
    shutil.copytree(source, context / "public-source", symlinks=True)
    assert input_digest(context / "public-source") == public_sha
    control = context / "control"
    control.mkdir()
    expected = {"project": args.project, "inputs": inputs, "package_manager": package_manager,
        "corepack_home": CACHE + "/corepack", "store": CACHE + "/pnpm-store",
        "cache_dir": CACHE + "/pnpm-cache", "state_dir": CACHE + "/pnpm-state"}
    save(control / "expected.json", expected)
    (control / "fetch.py").write_text(FETCH)
    recipe = context / "Dockerfile"
    recipe.write_text("FROM " + parent["tag"] + "\n"
        "ENV COREPACK_HOME=" + expected["corepack_home"] + " pnpm_config_store_dir=" + expected["store"]
        + " pnpm_config_cache_dir=" + expected["cache_dir"] + " pnpm_config_state_dir=" + expected["state_dir"]
        + " pnpm_config_offline=true COREPACK_ENABLE_NETWORK=0 COREPACK_ENABLE_DOWNLOAD_PROMPT=0\n"
        "COPY public-source /dependency-source\nCOPY control /dependency-control\n"
        "RUN python3 -I -B /dependency-control/fetch.py\n")
    save(out / "registration.json", {"schema": "public-pnpm-cache-preparation-v1",
        "task": args.task_id, "parent_image": before["Id"], "public_source_sha256": public_sha,
        "parent_metadata": str(args.parent_metadata), "parent_metadata_sha256": sha(args.parent_metadata),
        "original_frontend_inputs": inputs, "package_manager": package_manager,
        "producer_sha256": sha(__file__), "recipe_sha256": sha(recipe),
        "fetch_helper_sha256": sha(control / "fetch.py"), "build_network": "default",
        "runtime_network": "none", "pnpm_config_contract": "https://pnpm.io/blog/releases/11.0", "client_model_calls": 0, "compute_costs": "unmeasured", "paid_ready": False})
    built = subprocess.run(["docker", "build", "--pull=false", "--network", "default", "-t", tag, str(context)],
        capture_output=True, timeout=1800)
    (out / "build.stdout").write_bytes(built.stdout)
    (out / "build.stderr").write_bytes(built.stderr)
    assert built.returncode == 0, "pnpm preparation failed; retained logs"
    after = inspect(tag)
    save(out / "image.json", after)
    assert inspect(parent["tag"])["Id"] == before["Id"]
    layers = before["RootFS"]["Layers"]
    assert after["RootFS"]["Layers"][:len(layers)] == layers
    assert not after["Config"].get("Volumes")
    code = "from pathlib import Path;print(Path('/dependency-control/pnpm-cache-result.json').read_text(),end='')"
    argv = ["docker", "run", "--rm", "--pull=never", "--network", "none", "--read-only",
        "--user", "1000:1000", "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
        "--memory", "128m", "--memory-swap", "128m", "--cpus", "1", "--pids-limit", "32",
        "--entrypoint", "python3", after["Id"], "-I", "-B", "-c", code]
    observed = subprocess.run(argv, capture_output=True, timeout=60)
    (out / "readback.stdout").write_bytes(observed.stdout)
    (out / "readback.stderr").write_bytes(observed.stderr)
    assert observed.returncode == 0 and observed.stderr == b""
    receipt = json.loads(observed.stdout)
    assert receipt["original_locked_inputs_unchanged"] and receipt["inputs"] == inputs
    assert receipt["package_manager"] == package_manager and receipt["precomputed_frontend_bundle"] is False
    assert receipt["versions_before"] == receipt["versions_after"]
    assert input_digest(source) == public_sha
    save(out / "result.json", {"image": after["Id"], "tag": tag, "parent_image": before["Id"],
        "source_unchanged": True, "receipt": receipt, "client_model_calls": 0, "paid_ready": False,
        "scope": "Original pinned pnpm/tool/store preparation only; strict offline write locations, actual frontend build and all-cohort qualification pending."})
    print(json.dumps({"image": after["Id"], "package_manager": package_manager,
        "original_inputs_unchanged": True, "paid_ready": False}))

if __name__ == "__main__":
    main()
