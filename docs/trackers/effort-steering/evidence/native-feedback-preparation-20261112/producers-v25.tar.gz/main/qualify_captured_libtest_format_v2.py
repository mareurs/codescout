"""Qualify suite-prefixed original parser with independently declared fixture keys; preserve v1 bare-key probe failure."""
from pathlib import Path
import copy,hashlib,json,re,shutil,subprocess,sys,uuid
sys.dont_write_bytecode=True
WORK=Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from evaluator_entry import verify_package,memory_events
import feedback_private_capture as adapter
import feedback_private_commands as parent
BASE=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
IDS=("nearai__ironclaw-6724",)
RUST=r"""#[test] fn alpha() {
    for i in 0..300 { println!("arbitrary payload {i}"); }
    println!("error[E0308]: user payload\n --> src/lib.rs:1:1");
}
#[test] fn beta() {
    println!("write failed: No space left on device");
    println!("rustc: fatal error: terminated with signal 9");
}
#[test] fn fails() {
    if std::env::var("FIXTURE_FAIL").as_deref()==Ok("1") { assert!(false,"calibration failure"); }
}
"""
WRITE="""import json,sys
from pathlib import Path
for name,content in json.loads(sys.stdin.read()).items():
    path=Path(name);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(content)
"""
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):
    with path.open("x") as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write(chr(10))
def docker(*args,data=None,check=True):
    run=subprocess.run(["docker",*args],input=data,capture_output=True,timeout=900)
    if check and run.returncode:raise RuntimeError(repr((args,run.returncode,run.stderr[-3000:])))
    return run
def main():
    assert Path(__file__).stat().st_mode & 0o222==0
    frozen=json.loads(Path("/var/tmp/ep11-01a15/private-controls/obscura/config.json").read_bytes())
    package=verify_package(frozen["package_root"],frozen["package_files"]);sys.path.insert(0,str(package))
    import command_capture as capture
    import multilang_grade as grade
    import stream_evidence as streams
    import grade_policy as policy
    for identity in IDS:
        root=BASE/identity;final=root/"common-clean-image-v3"
        readback=json.loads((final/"public-readback-v1/result.json").read_bytes())
        image=readback["image"];assert readback["complete"]
        assert json.loads((final/"root-write-qualification-v1/result.json").read_bytes())["complete"]
        out=root/"captured-libtest-format-v2";out.mkdir(mode=0o700)
        original=json.loads((root/"private-structure-v1/original-record.json").read_bytes())
        bindings={str(path):sha(path) for path in (Path(__file__),Path(adapter.__file__),Path(parent.__file__))}
        save(out/"registration.json",{"schema":"captured-libtest-image-format-v2","image":image,"task":identity,
            "bindings":bindings,"frozen_package_files":frozen["package_files"],"parser":original["log_parser"],
            "fixture_source_sha256":hashlib.sha256(RUST.encode()).hexdigest(),"cases":["pass","failure","compile-failure"],
            "selected_fixture_names":["unittests src/lib.rs::fails","unittests src/lib.rs::alpha","unittests src/lib.rs::beta"],"client_model_calls":0,"paid_ready":False,
            "scope":"Three synthetic format controls per actual image, not task outcomes or scientific efficacy."})
        name="ep-captured-format-"+uuid.uuid4().hex;cid=None;cases=[]
        try:
            cid=docker("run","-d","--pull=never","--name",name,"--network","none","--user","0:0",
                "--memory","8g","--memory-swap","8g","--cpus","4","--pids-limit","4096","--init",
                "--cap-drop","ALL","--security-opt","no-new-privileges",
                "--label","effort-feedback-owner=codex:01a15ca9-f939-7603-acb5-01c6b02f68e2",
                "--entrypoint","sleep",image,"infinity").stdout.decode().strip()
            assert re.fullmatch("[0-9a-f]{64}",cid)
            before=json.loads(docker("inspect",cid).stdout)[0];save(out/"runtime-before.json",before)
            host=before["HostConfig"]
            resource_ok=(before["Image"]==image and before["Id"]==cid and before["Config"]["User"]=="0:0"
                and before["Mounts"]==[] and host["NetworkMode"]=="none" and host["Memory"]==8*1024**3
                and host["MemorySwap"]==8*1024**3 and host["NanoCpus"]==4*10**9 and host["PidsLimit"]==4096
                and host["Init"] is True and host["CapDrop"]==["ALL"])
            assert resource_ok
            events_before=memory_events(docker("exec",cid,"cat","/sys/fs/cgroup/memory.events").stdout.decode())
            save(out/"memory-before.json",events_before)
            versions=docker("exec","-w","/testbed",cid,"rustc","--version")
            (out/"rustc-version.stdout").write_bytes(versions.stdout)
            manifest='[package]\nname="capture_probe"\nversion="0.0.0"\nedition="2021"\n'
            docker("exec","-i",cid,"python3","-I","-B","-c",WRITE,data=json.dumps({
                "/tmp/effort-format/Cargo.toml":manifest,"/tmp/effort-format/src/lib.rs":RUST,
                "/testbed/reports/.capture-marker":""}).encode())
            for kind,flag,want in (("pass","0","pass"),("failure","1","test_failure"),("compile-failure","0","compile_failure")):
                directory=out/kind;directory.mkdir()
                if kind=="compile-failure":
                    docker("exec","-i",cid,"python3","-I","-B","-c",WRITE,data=json.dumps({
                        "/tmp/effort-format/src/lib.rs":"pub fn broken() { let _: u32 = \"not a number\"; }\n"}).encode())
                record={"instance_id":"captured-format-probe","test_cmds":[
                    "FIXTURE_FAIL="+flag+" cargo test --manifest-path /tmp/effort-format/Cargo.toml --lib -- --nocapture > reports/format.log 2>&1"],
                    "rebuild_cmds":[],"print_cmds":["cat reports/format.log"],"log_parser":original["log_parser"],
                    "FAIL_TO_PASS":["unittests src/lib.rs::fails"],"PASS_TO_PASS":["unittests src/lib.rs::alpha","unittests src/lib.rs::beta"]}
                plan=adapter.prepare_captured_shell_record(record,image=image);prepared=plan["record"]
                save(directory/"prepared-plan.json",plan)
                steps=[]
                commands=[("grade:rebuild"," ; ".join(prepared["rebuild_cmds"])),
                    ("grade:test[0]",prepared["test_cmds"][0]),("grade:print[0]",prepared["print_cmds"][0])]
                for index,(step_name,command) in enumerate(commands):
                    run=docker("exec","-w","/testbed",cid,"bash","-o","pipefail","-c",capture.script(command),check=False)
                    (directory/(str(index)+".wire")).write_bytes(run.stdout)
                    (directory/(str(index)+".outer-stderr")).write_bytes(run.stderr)
                    assert not run.stderr
                    captured=capture.decode(run.stdout,run.returncode)
                    steps.append({"name":step_name,"returncode":run.returncode,"tail":captured["tail"],"capture":captured})
                stdout,stderr=capture.read_streams(steps[-1]["capture"]);assert not stderr
                log=stdout.decode("utf-8","replace");(directory/"grade.log").write_text(log)
                statuses=grade.run_parser(prepared["log_parser"],log)
                raw=grade.verdict(statuses,prepared["FAIL_TO_PASS"],prepared["PASS_TO_PASS"])
                save(directory/"parsed-statuses.json",statuses);save(directory/"steps.json",steps)
                if kind!="compile-failure":
                    assert statuses=={"unittests src/lib.rs::alpha":"pass","unittests src/lib.rs::beta":"pass","unittests src/lib.rs::fails":"fail" if flag=="1" else "pass"}
                    assert "arbitrary payload 299" in log and "---- alpha stdout ----" in log
                    assert "No space left on device" in log and "---- beta stdout ----" in log
                else:assert statuses=={}
                cases.append((kind,directory,prepared,steps,raw,log,want))
            events_after=memory_events(docker("exec",cid,"cat","/sys/fs/cgroup/memory.events").stdout.decode())
            save(out/"memory-after.json",events_after)
            after=json.loads(docker("inspect",cid).stdout)[0];save(out/"runtime-after.json",after)
            assert events_after["oom_kill"]-events_before["oom_kill"]==0 and not after["State"]["OOMKilled"]
        finally:
            if cid:
                actual=json.loads(docker("inspect",cid).stdout)[0]
                assert actual["Id"]==cid and actual["Image"]==image and actual["Name"]=="/"+name
                docker("rm","-f",cid);absent=docker("container","inspect",cid,check=False)
                assert absent.returncode==1 and cid.encode() in absent.stderr and b"No such" in absent.stderr
                save(out/"cleanup.json",{"complete":True,"container":cid,"returncode":absent.returncode,
                    "stderr_sha256":hashlib.sha256(absent.stderr).hexdigest()})
        runtime={"complete":True,"resource_ok":resource_ok,"cgroup_probes":2,
            "oom_kill":events_after["oom_kill"]-events_before["oom_kill"],"errors":[]}
        results=[]
        for kind,directory,prepared,steps,raw,log,want in cases:
            raw.update(oom_killed=False,container_removed=True)
            full={**raw,"steps":steps}
            bundle={"expected":{"fail_to_pass":1,"pass_to_pass_kept":2,"dropped":[],"fail_to_pass_dropped":[]}}
            registered={"version":streams.VERSION,"commands_sha256":streams.commands_digest(prepared),
                "tests":[{"profile":streams.LIB,"reports":[0],"stderr_files":[]}]}
            verdict=policy.adjudicate_streams(raw,full,prepared,bundle,log=log,runtime=runtime,registered=registered)
            save(directory/"verdict.json",verdict)
            assert verdict["valid"] is True and verdict["kind"]==want and verdict["pass"]==(kind=="pass"),verdict
            results.append({"name":kind,"kind":verdict["kind"],"valid":verdict["valid"],"pass":verdict["pass"],
                "missing":verdict["adjusted"]["missing"],"verdict_sha256":sha(directory/"verdict.json")})
        assert len(results)==3 and all(sha(path)==digest for path,digest in bindings.items())
        verify_package(package,frozen["package_files"])
        save(out/"result.json",{"complete":True,"image":image,"rustc_version":versions.stdout.decode().strip(),
            "cases":results,"resource_proof":runtime,"source_bindings_unchanged":True,"frozen_package_unchanged":True,
            "client_model_calls":0,"paid_ready":False,
            "scope":"Three actual synthetic libtest-format/complete-stream controls; selected task controls remain required."})
        print(json.dumps({"task":identity,"image":image,"cases":results,"complete":True,"paid_ready":False}),flush=True)
if __name__=="__main__":main()
