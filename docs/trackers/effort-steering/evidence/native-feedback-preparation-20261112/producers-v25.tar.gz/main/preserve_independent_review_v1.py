"""Preserve review reports, actual mutants, observed logs and changed source snapshots."""
import hashlib
import io
import json
from pathlib import Path
import tarfile
ROOTS = [
    Path("/tmp/native-feedback-review-ssao8f9p"),
    Path("/tmp/native-feedback-delta-review-rm85nlq6"),
    Path("/tmp/native-feedback-framing-review-apu3o07_"),
    Path("/tmp/native-feedback-framing-replay-zerv3f20"),
    Path("/tmp/feedback-survivor-replay-oofl9v89")]
OUT = Path("docs/trackers/effort-steering/evidence/native-feedback-preparation-20261112")
archive = OUT / "independent-implementation-review-v1.tar.gz"
selected = {}
for root in ROOTS:
    for path in sorted(root.iterdir()):
        if path.is_file() and path.suffix in (".json", ".log", ".diff", ".py"):
            selected[root.name + "/" + path.name] = path
    for relative in ("readiness.py", "qualify_native.py", "test_registered_readiness.py",
                     "test_native_executor.py", "test_feedback_paid_leaves.py",
                     "test_feedback_canonical_accounting.py"):
        for base in ("baseline", "pristine"):
            path = root / base / "tools/effort_protocol" / relative
            if path.is_file():
                selected[root.name + "/" + base + "/tools/effort_protocol/" + relative] = path
manifest = {}
with tarfile.open(archive, "x:gz") as tar:
    for name, path in sorted(selected.items()):
        data = path.read_bytes()
        manifest[name] = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(), "source": str(path)}
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o444
        tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive) as tar:
    assert len(tar.getmembers()) == len(manifest)
    for name, row in manifest.items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == row["sha256"]
        assert hashlib.sha256(selected[name].read_bytes()).hexdigest() == row["sha256"]
payload = {"schema": "independent-review-evidence-custody-v1", "archive": str(archive),
    "archive_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(), "archive_bytes": archive.stat().st_size,
    "members": manifest, "scope": "Observed review and mutant evidence; not repair efficacy or paid admission.",
    "provider_calls": None, "review_cost_usd": None}
with (OUT / "independent-implementation-review-v1.json").open("x") as stream:
    stream.write(json.dumps(payload, indent=2) + "\n")
print(json.dumps({key:value for key,value in payload.items() if key != "members"}))
print("members=" + str(len(manifest)))
