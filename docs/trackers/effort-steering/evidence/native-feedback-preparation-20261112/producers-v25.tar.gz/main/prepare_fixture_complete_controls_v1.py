"""Compose full official private references uniformly; no actor/provider invocation."""
from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
WORK=Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from feedback_reference_inputs import prepare_reference,verify_reference
from feedback_policy import condition_spec
from receipts import input_digest
from public_build_inputs import validate_descriptor
BASE=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
CHOICES={"DioxusLabs__dioxus-5384":("v3","common-clean-image-v3"),
    "nearai__ironclaw-6724":("v4","private-cache-owner-image-v5"),
    "apache__arrow-rs-7783":("v6",None),"skim-rs__skim-1044":("v1",None)}
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):
    with path.open("x") as stream:
        json.dump(value,stream,sort_keys=True,indent=2);stream.write("\n")
def main():
    assert Path(__file__).stat().st_mode & 0o222==0
    batch=BASE/"fixture-complete-controls-v1";batch.mkdir(mode=0o700)
    source_bindings={str(p):sha(p) for p in sorted((WORK/"tools/effort_protocol").glob("*.py"))}
    source_bindings[str(Path(__file__).absolute())]=sha(__file__)
    packets={}
    for identity,(version,image_parent) in CHOICES.items():
        root=BASE/identity;prepared=root/("private-preparation-"+version)
        config_path=prepared/"config.json";config=json.loads(config_path.read_bytes())
        registration=json.loads((prepared/"registration.json").read_bytes())
        assert sha(config_path)==registration["config_sha256"]
        assert all(sha(path)==digest for path,digest in config["bindings"].items())
        record_path=Path(config["record"]);record=json.loads(record_path.read_bytes())
        original_path=record_path.parent/"original-record.json";original=json.loads(original_path.read_bytes())
        assert all(record[key]==original[key] for key in original.keys()-{"test_cmds","rebuild_cmds"})
        source=Path(registration["public_source"]);source_sha=input_digest(source)
        assert source_sha==registration["public_source_sha256"]
        image=registration["image"];out=batch/identity;out.mkdir(mode=0o700)
        descriptor=prepare_reference(source,record,config["trusted_test_inputs"],out/"private-reference")
        closure=verify_reference(descriptor,source,record,config["trusted_test_inputs"])
        descriptor_path=out/"reference-inputs.json";save(descriptor_path,descriptor)
        if image_parent is not None:
            build_path=root/image_parent/"public-readback-v1/public-build-inputs.json"
            build=json.loads(build_path.read_bytes())
        else:
            build={"schema":"public-build-inputs-v1","image":image,"seed":None,
                "dependency_dirs":[],"cache_mounts":[]}
            build_path=out/"public-build-inputs.json";save(build_path,build)
        validate_descriptor(build,source,image)
        validate_descriptor(build,Path(descriptor["reference"]),image)
        bindings=dict(config["bindings"])
        for path in (config_path,record_path,original_path,descriptor_path,build_path,
                     Path(descriptor["patch"]),Path(descriptor["test_patch"]),
                     Path(config["trusted_test_inputs"]["manifest"]),Path(config["trusted_test_inputs"]["archive"])):
            bindings[str(path)]=sha(path)
        commands=[{"argv":condition_spec(arm,".")["check"]["argv"],"cwd":".","test_files":["Cargo.toml"]}
                  for arm in ("L","P")]
        task={"source":str(source),"source_sha256":source_sha,"backend":{
            "public":{"image":image,"execution_profile":"cargo-v3","public_build_inputs":build,
                      "feedback_policy":{"workspace":"."},"public_checks":commands},
            "private":{"config":str(config_path),"config_sha256":sha(config_path)}}}
        packets[identity]={"task":task,"bindings":bindings,"reference_inputs":{
            "path":str(descriptor_path),"sha256":sha(descriptor_path)},"closure":closure,
            "source_bindings":source_bindings,"contains_private_assertions":True,
            "actor_input_role":"original-public-baseline","client_model_calls":0,"paid_ready":False}
        save(out/"preparation.json",packets[identity])
        print(json.dumps({"task":identity,"reference_sha256":closure["reference_sha256"],
            "protected_entries_verified":closure["protected_entries_verified"]}),flush=True)
    assert all(sha(path)==digest for path,digest in source_bindings.items())
    save(batch/"preparation.json",{"schema":"fixture-complete-reference-control-preparation-v1",
        "tasks":list(packets),"source_bindings":source_bindings,"client_model_calls":0,"paid_ready":False})
    return 0
if __name__=="__main__":
    raise SystemExit(main())
