"""Resume only after the one completed onboarding; retain original failed producer."""
from pathlib import Path
import hashlib,json,subprocess,sys,tomllib,re,shutil
sys.dont_write_bytecode=True
import prepare_public_source_build_context as base
from receipts import input_digest
from native_executor import _public_digest
from public_build_inputs import generated_inventory,validate_descriptor
sha,save=base.sha,base.save
def main():
    task=base.ROOT/"nearai__ironclaw-6724"
    out=task/"common-preparation-v1"
    assert not (out/"preparation.json").exists()
    registration=json.loads((out/"registration.json").read_bytes())
    project,baseline=out/"project",out/"public-source"
    original=Path(registration["source"]);original_sha=registration["source_digest"]
    assert input_digest(original)==original_sha
    calls=json.loads((out/"onboarding/calls.json").read_bytes())
    actual=[row for row in calls if row["method"]=="tools/call"]
    assert len(actual)==1 and actual[0]["params"]=={"name":"onboarding","arguments":{}}
    assert not actual[0]["response"].get("error") and not actual[0]["response"]["result"].get("isError")
    cleanup=json.loads((out/"onboarding/cleanup.json").read_bytes())
    assert cleanup["cleanup_complete"] and not cleanup["close_errors"]
    absent=subprocess.run(["docker","inspect",cleanup["container"]],capture_output=True,text=True,timeout=60)
    assert absent.returncode==1 and "no such" in absent.stderr.lower()
    binding=json.loads((out/"public-build-inputs.json").read_bytes())
    descriptor=binding["descriptor"]
    admitted=validate_descriptor(descriptor,baseline,registration["image"])
    assert admitted["fingerprint"]==binding["fingerprint"] and binding["canonical_targets_created_before_onboarding"]
    def public_digest(path):
        return _public_digest(path,dependency_dirs=descriptor["dependency_dirs"],preserve_project_context=True)
    assert input_digest(original/".claude")==input_digest(baseline/".claude")==input_digest(project/".claude")
    synchronized=[]
    workspace=project/".codescout/workspace.toml"
    configured=tomllib.loads(workspace.read_text())["project"] if workspace.exists() else []
    for entry in configured:
        relative=Path(entry["root"])
        assert not relative.is_absolute() and ".." not in relative.parts
        expected=baseline/relative/".gitignore"
        target=project/relative/".gitignore"
        if not expected.exists():continue
        before=target.read_bytes() if target.exists() else b""
        after=expected.read_bytes()
        if before!=after:
            marker=b".codescout/private-memories/"
            assert marker not in before.splitlines()
            assert after==before+(bytes([10]) if before and not before.endswith(bytes([10])) else b"")+marker+bytes([10])
            synchronized.append({"path":str(relative/".gitignore"),
                "before_sha256":hashlib.sha256(before).hexdigest(),"after_sha256":sha(expected)})
            shutil.copy2(expected,target)
    assert public_digest(project)==input_digest(baseline)
    left,right=generated_inventory(original),generated_inventory(baseline)
    overlays=[{"path":name,"kind":"reconstructed-canonical-public-overlay",
               "before":left.get(name),"after":right.get(name)}
              for name in sorted(set(left)|set(right)) if left.get(name)!=right.get(name)]
    documents=[name for name in ("CLAUDE.md","AGENTS.md","README.md","CONTRIBUTING.md","ARCHITECTURE.md")
               if (baseline/name).is_file()]
    seed_module=base.load("resume_common_seed",base.SCRIPTS/"prepare_arrow_context.py")
    ignore_private=base.ignore_private
    save(out/"resume-after-onboarding-binding-v3.json",{
        "producer_sha256":sha(__file__),"source_producer_sha256":sha(base.__file__),
        "calls_sha256":sha(out/"onboarding/calls.json"),"completed_onboarding_calls":1,"resumed_public_ignore_copies":synchronized,
        "additional_onboarding_calls":0,"project_claude_source_sha256":input_digest(original/".claude"),
        "fresh_owned_absence":{"container":cleanup["container"],"returncode":absent.returncode,
                              "stderr_sha256":hashlib.sha256(absent.stderr.encode()).hexdigest()},
        "policy":"Preserve original project .claude in the new source contract; no onboarding retry.",
        "client_model_calls":0,"paid_ready":False})
    # No retry of onboarding even if a later source/readiness guard fails.
    assert public_digest(project) == input_digest(baseline)
    workspace = project / ".codescout/workspace.toml"
    configured = tomllib.loads(workspace.read_text())["project"] if workspace.exists() else []
    for entry in configured:
        relative = Path(entry["root"])
        assert not relative.is_absolute() and ".." not in relative.parts
        before_count = len(overlays)
        ignore_private(baseline, relative, overlays)
        if len(overlays) != before_count:
            target = project / relative / ".gitignore"
            shutil.copy2(baseline / relative / ".gitignore", target)
    assert public_digest(project) == input_digest(baseline)
    knowledge = project / ".codescout"
    memories = knowledge / "memories"
    memories.mkdir(exist_ok=True)
    provenance, aliases, by_hash = {}, {}, {}
    for name in documents:
        source = baseline / name
        digest = sha(source)
        if digest in by_hash:
            aliases[name] = by_hash[digest]
            continue
        topic = "source-" + name.removesuffix(".md").lower()
        target = memories / (topic + ".md")
        with target.open("xb") as stream: stream.write(source.read_bytes())
        provenance[topic] = {"source": name, "sha256": digest, "bytes": source.stat().st_size}
        by_hash[digest] = topic
    prompt = knowledge / "system-prompt.md"
    assert not prompt.exists()
    text = "# Source-only repository guidance\n\nFollow the common project CLAUDE.md and existing project instructions.\n\n"
    text += "Unaltered public document payloads are available as Codescout memories:\n"
    text += "".join("- " + topic + " from " + row["source"] + "\n" for topic, row in provenance.items())
    prompt.write_text(text)
    config = knowledge / "project.toml"
    original_config = config.read_text()
    (out / "project-config-onboarding-original.toml").write_text(original_config)
    content, count = re.subn(r"(?ms)^\[embeddings\].*?(?=^\[|\Z)",
        '[embeddings]\nmodel = "CodeRankEmbed"\nurl = "http://source-embeddings:8000/v1"\n\n', original_config)
    assert count == 1
    content, count = re.subn(r'system_prompt_sha256 = "[0-9a-f]+"',
        'system_prompt_sha256 = "' + sha(prompt) + '"', content)
    assert count == 1
    config.write_text(content)
    seed_module.seed(project)
    assert input_digest(original) == original_sha and public_digest(project) == input_digest(baseline)
    cleanup = json.loads((out / "onboarding/cleanup.json").read_bytes())
    assert cleanup["cleanup_complete"] and not cleanup["close_errors"]
    save(out / "preparation.json", {"programmatic_onboarding_calls": 1, "additional_onboarding_calls": 0,
        "public_build_inputs":descriptor,"public_build_inputs_sha256":admitted["fingerprint"],
        "author_model_calls": 0, "client_model_calls": 0, "public_overlays": overlays,
        "source_documents": provenance, "duplicate_document_aliases": aliases, "configured_projects": configured,
        "public_baseline_sha256": input_digest(baseline), "template_public_sha256": public_digest(project),
        "original_source_unchanged": True, "index_calls": 0, "paid_ready": False,
        "root_review_embedding_compute_costs": "unmeasured",
        "scope": "One programmatic onboarding plus source document payloads; not LLM deep-dive or index/canary/author-context qualification."})
    print(json.dumps({"source_only_prepared": str(out), "onboarding_calls": 1, "additional_onboarding_calls": 0, "paid_ready": False}))

if __name__ == "__main__":
    main()
