"""Independently reopen current Arrow controls using the exact archived preparation origin."""
from pathlib import Path
import hashlib,importlib.util,json,os,re,subprocess,sys
sys.dont_write_bytecode=True
WORK=Path("/home/marius/.codex/worktrees/2aa6/codescout")
MAIN=Path("/home/marius/work/claude/codescout")
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from evaluator_entry import verify_package,_input_digest,_source_files
from paid_admission import verify_private_test_inputs
BASE=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def main():
    assert Path(__file__).stat().st_mode & 0o222==0
    identity=sys.argv[1];assert identity=="apache__arrow-rs-7783"
    root=BASE/identity;prepared=root/"private-preparation-v6"
    reg=json.loads((prepared/"registration.json").read_bytes())
    assert sha(prepared/"config.json")==reg["config_sha256"]
    config=json.loads((prepared/"config.json").read_bytes())
    for name,digest in config["bindings"].items():assert sha(name)==digest
    package=verify_package(config["package_root"],config["package_files"]);sys.path.insert(0,str(package))
    import grade_policy as policy
    import multilang_tasks as tasks
    record=json.loads(Path(config["record"]).read_bytes())
    original=json.loads((Path(config["record"]).parent/"original-record.json").read_bytes())
    helper=Path(reg["frozen_preparation_helper"])
    assert sha(helper)==reg["frozen_preparation_helper_sha256"]=="4cf4b18e954243bee02cebf7fd762e378dda565761e0f5fa0872e080f0b11c53"
    assert helper.stat().st_mode & 0o222==0
    spec=importlib.util.spec_from_file_location("frozen_arrow_preparation",helper)
    frozen_helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(frozen_helper)
    assert record==frozen_helper.prepare_record(original)
    loader=json.loads((prepared/"helper-snapshot-loader-proof.json").read_bytes())
    assert loader["isolated_flag"]==1 and loader["new_loaded"] and loader["record_unchanged"] and loader["image_unchanged"]
    assert all(record[key]==original[key] for key in original.keys()-{"test_cmds","rebuild_cmds"})
    f2p,p2p=original["FAIL_TO_PASS"],original["PASS_TO_PASS"]
    assert len(f2p+p2p)==len(set(f2p+p2p))==reg["selected_label_count"]
    bundle={"expected":{"fail_to_pass":len(f2p),"pass_to_pass_kept":len(p2p),"dropped":[],"fail_to_pass_dropped":[]}}
    result=json.loads((prepared/"controls-result.json").read_bytes());assert result["all_three_controls_met"]
    assert [row["name"] for row in result["controls"]]==["baseline","reference","reference-repeat"]
    rows=[];containers=set();image=reg["image"];observed_bindings={}
    for index,(control,closed) in enumerate(zip(reg["controls"],result["controls"])):
        request_path=Path(control["request"]);assert sha(request_path)==control["request_sha256"]
        request=json.loads(request_path.read_bytes());directory=request_path.parent;out=directory/"evaluation"
        assert request["config_sha256"]==reg["config_sha256"] and _input_digest(request["source"])==request["source_digest"]
        assert request["public_baseline"]==reg["public_source"] and _input_digest(reg["public_source"])==reg["public_source_sha256"]
        assert _source_files(out/"patch-verification")==_source_files(request["source"])
        for role in ("patch","capture_proof"):assert sha(request[role])==request[role+"_sha256"]
        assert closed==json.loads((directory/"control-result.json").read_bytes())
        assert closed["process_returncode"]==0 and closed["verdict_sha256"]==sha(out/"verdict.json")
        verdict=json.loads((out/"verdict.json").read_bytes());assert verdict==closed["verdict"] and verdict["valid"]
        assert verdict["pass"] is control["expected_pass"]
        if control["name"]=="baseline":
            assert verdict["kind"]=="compile_failure" and verdict["statuses"]=={} and verdict["adjusted"]["missing"]==len(f2p+p2p)
        else:
            assert verdict["kind"]=="pass" and verdict["adjusted"]["missing"]==0
        raw=json.loads((out/"raw-grade.json").read_bytes())
        full=json.loads(Path(raw["log"]).with_name("grade.json").read_bytes())
        log=Path(raw["log"]).read_text()
        runtime=json.loads((out/"runtime-proof.json").read_bytes())
        observations=[json.loads(line) for line in (out/"runtime-observations.jsonl").read_text().splitlines()]
        assert [item["stage"] for item in observations]==["after-start","before-remove"]
        assert runtime["complete"] and runtime["resource_ok"] and runtime["cgroup_probes"]==len(observations)==2
        assert runtime["oom_kill"]==0 and runtime["errors"]==[] and runtime["fresh_absence"]==[True]
        cid=observations[0]["inspect"]["Id"];assert re.fullmatch("[0-9a-f]{64}",cid) and cid not in containers
        containers.add(cid)
        for item in observations:
            observed=item["inspect"];host=observed["HostConfig"]
            assert item["name"]==raw["container"] and observed["Id"]==cid and observed["Image"]==image
            assert observed["Config"]["User"] in ("root","0","0:0") and observed["Mounts"]==[]
            assert host["NetworkMode"]=="none" and host["Memory"]==8*1024**3 and host["MemorySwap"]==8*1024**3
            assert host["NanoCpus"]==4*10**9 and host["PidsLimit"]==4096 and host["Init"] is True
            assert host["CapDrop"]==["ALL"] and "no-new-privileges" in host["SecurityOpt"]
            assert item["memory_events"]["oom_kill"]==0 and not observed["State"]["OOMKilled"]
        expected_source={}
        for name in config["production_paths"]:
            path=Path(request["source"])/name
            expected_source["/testbed/"+name]=({"link":os.readlink(path)} if path.is_symlink() else sha(path) if path.is_file() else None)
        expected_source.update(config["fixed_test_sha256"])
        assert observations[-1]["source_sha256"]==expected_source
        bindings=dict(config["bindings"]);bindings[str(prepared/"config.json")]=reg["config_sha256"]
        for path in (out/"trusted-input-installation.json",out/"runtime-observations.jsonl"):
            bindings[str(path)]=sha(path)
        protected=verify_private_test_inputs({"bindings":bindings},
            {"config":str(prepared/"config.json"),"config_sha256":reg["config_sha256"]},out)
        recomputed=policy.adjudicate_streams(raw,full,record,bundle,log=log,runtime=runtime,registered=config["stream_registration"])
        assert recomputed==verdict
        assert set(verdict["statuses"])==(set() if control["name"]=="baseline" else set(f2p+p2p))
        absent=subprocess.run(["docker","container","inspect",cid],capture_output=True,timeout=60)
        assert absent.returncode==1 and cid.encode() in absent.stderr and b"No such" in absent.stderr
        proof_files=[request_path,directory/"control-result.json",out/"raw-grade.json",out/"runtime-proof.json",
            out/"runtime-observations.jsonl",out/"trusted-input-installation.json",out/"verdict.json",
            Path(raw["log"]),Path(raw["log"]).with_name("grade.json")]
        observed_bindings.update({str(path):sha(path) for path in proof_files})
        rows.append({"name":control["name"],"kind":verdict["kind"],"pass":verdict["pass"],
            "expected":verdict["adjusted"]["expected"],"not_passing":verdict["adjusted"]["not_passing"],
            "missing":verdict["adjusted"]["missing"],"raw_parsed_keys":verdict["raw_parsed_keys"],
            "selected_pass":sum(value=="pass" for value in verdict["statuses"].values()),
            "selected_fail":sum(value=="fail" for value in verdict["statuses"].values()),
            "cgroup_probes":len(observations),"memory_max_events":observations[-1]["memory_events"]["max"],
            "protected_entries_verified":protected["entries_verified"],"container":cid,"fresh_absence":True})
    assert len(containers)==3
    verify_package(package,config["package_files"])
    assert all(sha(path)==digest for path,digest in config["bindings"].items())
    output=MAIN/"docs/trackers/effort-steering/evidence/native-feedback-preparation-20261112/arrow-private-v6-control-audit.json"
    packet={"schema":"fixed-original-private-control-audit-v1","task":identity,"image":image,"controls":rows,
        "selected_labels":len(f2p+p2p),"frozen_package_files_reopened":len(config["package_files"]),
        "private_bindings_reopened":len(config["bindings"]),"frozen_package_and_private_bindings_unchanged":True,
        "evidence_bindings":observed_bindings,"producer_sha256":sha(__file__),"client_model_calls":0,"paid_ready":False,
        "scope":"Original private labels/assertions/parser and captured report, three observed containers/resource profiles, canonical byte restore/postgrade verification and independent exact verdict recomputation. No actor CLI or repair efficacy claim."}
    with output.open("x") as stream:json.dump(packet,stream,sort_keys=True,indent=2);stream.write(chr(10))
    print(json.dumps({key:value for key,value in packet.items() if key!="evidence_bindings"}),flush=True)
if __name__=="__main__":main()
