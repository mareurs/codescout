"""Bound standalone entry; same real qualification with corrected public canaries."""
import importlib.util
from pathlib import Path
import sys
WORK = Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path[:0] = [str(WORK / "tools" / name) for name in
                ("effort_protocol", "agent_lifecycle", "hint_authority_pilot")]
path = Path(__file__).with_name("qualify_native_feedback_campaign_v1.py")
spec = importlib.util.spec_from_file_location("frozen_qualification_v1_for_v3", path)
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
prior.__file__ = str(Path(__file__).resolve())
if __name__ == "__main__":
    prior.main()
