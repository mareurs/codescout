"""Actual generic staging + offline frontend component; no provider call or Cargo claim."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, "/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
import public_build_inputs as inputs
from receipts import input_digest

WORKER = r"""
import json, pathlib, subprocess
root = pathlib.Path("/build")
def sample():
    base = pathlib.Path("/sys/fs/cgroup")
    return {name:(base/name).read_text() for name in ("memory.events","memory.max","cpu.max","pids.max")}
samples = [sample()]
rows = []
for name, argv in (("install",["corepack","pnpm","install","--frozen-lockfile"]),
                   ("bundle",["corepack","pnpm","exec","vite","build","--outDir","/build/frontend-dist","--emptyOutDir"])):
    with (root/(name+".stdout")).open("xb") as stdout, (root/(name+".stderr")).open("xb") as stderr:
        process = subprocess.run(argv, cwd="/testbed/crates/ironclaw_webui/frontend",
                                 stdout=stdout, stderr=stderr, timeout=90)
    rows.append({"name":name,"argv":argv,"returncode":process.returncode})
    if process.returncode:
        break
samples.append(sample())
(root/"worker.json").write_text(json.dumps({"commands":rows,"samples":samples},sort_keys=True,indent=2))
"""

base = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/nearai__ironclaw-6724")
prior = base / "pnpm-offline-write-probe-v5"
source = prior / "E-source-ro-node-rw-pnpm-state-rw/input"
seed = prior / "cache-seed"
image = "sha256:28aa0e0f6f9cd069363ec49448bf7e3dd1d19e3fcdf3629a6f92d5d47c542de1"
out = base / "public-build-input-staging-v2"
out.mkdir()
build = out / "build"
build.mkdir()
(build/"scratch").mkdir()
save = lambda name,value: (out/name).write_text(json.dumps(value,sort_keys=True,indent=2))
descriptor = {"schema":"public-build-inputs-v1","image":image,
              "seed":{"path":str(seed),"sha256":inputs.generated_digest(seed)},
              "dependency_dirs":["crates/ironclaw_webui/frontend/node_modules"],
              "cache_mounts":[{"seed_relative":name,"destination":"/bench/public-dependencies/"+name}
                              for name in ("pnpm-store","pnpm-cache","pnpm-state")]}
before = input_digest(source)
stage = inputs.stage_inputs(descriptor,source,image,out/"stage")
save("descriptor.json",descriptor)
save("stage-before.json",stage)
assert inputs.verify_staged(stage,source,image)["generated_sha256"] == stage["initial_generated_sha256"]
name = "ep-build-input-staging-01a15ca9-v2"
argv = ["docker","create","--pull=never","--name",name,"--label","codescout.effort-protocol="+name,
        "--network","none","--read-only","--init","--user","1000:1000",
        "--cpus","4","--memory","8g","--memory-swap","8g","--pids-limit","512",
        "--cap-drop=ALL","--security-opt","no-new-privileges",
        "--tmpfs","/tmp:rw,exec,size=1g,uid=1000,gid=1000,mode=1777",
        "--mount","type=bind,src="+str(source)+",dst=/testbed,readonly",
        "--mount","type=bind,src="+str(build)+",dst=/build",
        "--mount","type=bind,src="+str(build/"scratch")+",dst=/mnt_tmp",
        "--workdir","/testbed","--env","HOME=/tmp","--env","TMPDIR=/mnt_tmp",
        "--entrypoint","python3"]
for mount in stage["mounts"]:
    argv.extend(["--mount","type=bind,src="+mount["source"]+",dst="+mount["destination"]])
argv.extend([image,"-c",WORKER])
save("request.json",{"argv":argv,"helper_sha256":hashlib.sha256(Path(inputs.__file__).read_bytes()).hexdigest()})
cid = None
clean = False
try:
    created = subprocess.run(argv,capture_output=True,text=True,timeout=30)
    assert created.returncode == 0, created.stderr
    cid = created.stdout.strip()
    def inspect():
        return json.loads(subprocess.run(["docker","inspect",cid],capture_output=True,text=True,check=True,timeout=30).stdout)[0]
    raw = inspect()
    save("container-before.json",raw)
    host = raw["HostConfig"]
    assert raw["Image"] == image and host["ReadonlyRootfs"] and host["NetworkMode"] == "none"
    assert host["Memory"] == host["MemorySwap"] == 8*1024**3 and host["NanoCpus"] == 4_000_000_000
    assert host["PidsLimit"] == 512 and host["Init"] and raw["Config"]["User"] == "1000:1000"
    expected = {"/testbed":(str(source),False),"/build":(str(build),True),"/mnt_tmp":(str(build/"scratch"),True)}
    expected.update({r["destination"]:(r["source"],True) for r in stage["mounts"]})
    actual = {r["Destination"]:(r["Source"],r["RW"]) for r in raw["Mounts"] if r["Type"] == "bind"}
    assert actual == expected
    with (out/"attach.stdout").open("xb") as stdout,(out/"attach.stderr").open("xb") as stderr:
        completed = subprocess.run(["docker","start","--attach",cid],stdout=stdout,stderr=stderr,timeout=120)
    raw = inspect()
    save("container-after.json",raw)
    assert completed.returncode == raw["State"]["ExitCode"] == 0 and not raw["State"]["OOMKilled"]
    worker = json.loads((build/"worker.json").read_bytes())
    assert [r["returncode"] for r in worker["commands"]] == [0,0]
    assert len(worker["samples"]) == 2 and all("oom_kill 0" in r["memory.events"] for r in worker["samples"])
    assert input_digest(source) == before
    reopened = inputs.verify_staged(stage,source,image)
    save("stage-after.json",reopened)
    save("result.json",{"public_component_passed":True,"source_unchanged":True,"seed_unchanged":True,
                       "descriptor_fingerprint":stage["fingerprint"],"cgroup_probes":len(worker["samples"]),
                       "command_codes":[r["returncode"] for r in worker["commands"]],
                       "generated_changed":reopened["generated_sha256"]!=stage["initial_generated_sha256"],
                       "client_model_calls":0,"paid_ready":False,"scope":"Declared staging + real Docker component only; full Cargo/native/private integration pending."})
finally:
    if cid is not None:
        raw = inspect()
        assert raw["Id"] == cid and raw["Config"]["Labels"]["codescout.effort-protocol"] == name
        removed = subprocess.run(["docker","rm","--force",cid],capture_output=True,text=True,timeout=30)
        absence = subprocess.run(["docker","inspect",cid],capture_output=True,text=True,timeout=30)
        clean = removed.returncode == 0 and absence.returncode != 0 and "no such" in absence.stderr.lower()
    save("cleanup.json",{"complete":clean,"container":cid})
    assert clean
print(json.dumps(json.loads((out/"result.json").read_bytes()),sort_keys=True))
