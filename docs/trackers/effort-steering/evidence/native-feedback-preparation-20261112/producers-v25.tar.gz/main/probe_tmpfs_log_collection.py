"""Discriminate container tmpfs visibility from Docker archive/cp visibility."""
import json
from pathlib import Path
import subprocess
import uuid
ROOT=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/skim-rs__skim-1044/tmpfs-log-collection-v1")
ROOT.mkdir()
name="ep-tmpfs-01a15-"+uuid.uuid4().hex[:10]
image="sha256:338d956b2271853f58da5b29ed6be9acebd1d2a1fdb4f020135446e890185876"
save=lambda n,v:(ROOT/n).write_text(json.dumps(v,sort_keys=True,indent=2))
cid=None
try:
    create=["docker","create","--pull=never","--name",name,"--label","codescout.log-probe="+name,
            "--network","none","--read-only","--user","1000:1000","--memory","128m","--pids-limit","64",
            "--cap-drop=ALL","--security-opt","no-new-privileges",
            "--tmpfs","/tmp:rw,exec,size=4m,uid=1000,gid=1000,mode=1777",
            "--entrypoint","python3",image,"-u","-c","import time; time.sleep(120)"]
    p=subprocess.run(create,capture_output=True,text=True,timeout=30)
    save("create.json",{"argv":create,"returncode":p.returncode,"stdout":p.stdout,"stderr":p.stderr})
    assert p.returncode==0
    cid=p.stdout.strip()
    subprocess.run(["docker","start",cid],capture_output=True,check=True,timeout=30)
    row=json.loads(subprocess.run(["docker","inspect",cid],capture_output=True,text=True,check=True,timeout=30).stdout)[0]
    save("runtime.json",row)
    assert row["Image"]==image and row["State"]["Running"] and row["Config"]["Labels"]["codescout.log-probe"]==name
    write=subprocess.run(["docker","exec",cid,"python3","-c",
        "from pathlib import Path; Path('/tmp/owned-log').write_bytes(b'marker bytes')"],
        capture_output=True,timeout=30)
    assert write.returncode==0,write.stderr
    cp=subprocess.run(["docker","cp",cid+":/tmp/owned-log",str(ROOT/"cp-output")],capture_output=True,text=True,timeout=30)
    direct=subprocess.run(["docker","exec",cid,"cat","/tmp/owned-log"],capture_output=True,timeout=30)
    save("result.json",{"docker_cp":{"returncode":cp.returncode,"stdout":cp.stdout,"stderr":cp.stderr},
        "docker_exec":{"returncode":direct.returncode,"stdout":direct.stdout.decode(),"stderr":direct.stderr.decode()},
        "same_container":cid,"client_model_calls":0,"scope":"Own tmpfs marker only, no MCP or Cargo claim."})
    assert direct.returncode==0 and direct.stdout==b"marker bytes"
finally:
    if cid:
        row=json.loads(subprocess.run(["docker","inspect",cid],capture_output=True,text=True,check=True,timeout=30).stdout)[0]
        assert row["Config"]["Labels"]["codescout.log-probe"]==name and row["Image"]==image
        rm=subprocess.run(["docker","rm","--force",cid],capture_output=True,text=True,timeout=30)
        absent=subprocess.run(["docker","inspect",cid],capture_output=True,text=True,timeout=30)
        save("cleanup.json",{"complete":rm.returncode==0 and absent.returncode!=0 and "no such" in absent.stderr.lower()})
print((ROOT/"result.json").read_text())
