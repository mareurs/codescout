"""Bind separate final-root-cache controls after actual uid0 cache-write qualification."""
from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
WORK=Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from evaluator_entry import verify_package,_input_digest
import trusted_test_inputs as trusted
import feedback_private_commands as planner
BASE=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
IDS=("DioxusLabs__dioxus-5384","nearai__ironclaw-6724")
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):
    with Path(path).open("x") as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write(chr(10))
def main():
    assert Path(__file__).stat().st_mode & 0o222==0
    identity=sys.argv[1];assert identity in IDS
    root=BASE/identity;readback=root/"common-clean-image-v3/public-readback-v1"
    observed=json.loads((readback/"result.json").read_bytes())
    assert observed["complete"] and observed["differences"]==0 and json.loads((readback/"cleanup.json").read_bytes())["complete"]
    image=observed["image"];common=root/"common-preparation-v1";public=common/"public-source"
    write_probe=root/"common-clean-image-v3/root-write-qualification-v1"
    writable=json.loads((write_probe/"result.json").read_bytes())
    assert writable["complete"] and writable["image"]==image and writable["write_open_successes"]==writable["write_open_population"]==4
    assert writable["actual_uid"]==0 and int(writable["actual_cap_eff"],16)==0
    assert json.loads((write_probe/"cleanup.json").read_bytes())["complete"]
    public_sha=_input_digest(public);assert public_sha==observed["source_sha256"]
    old=json.loads(Path("/var/tmp/ep11-01a15/private-controls/obscura/config.json").read_bytes())
    package=verify_package(old["package_root"],old["package_files"])
    sys.path.insert(0,str(package))
    import stream_evidence as streams
    import multilang_tasks as tasks
    inputs=root/"private-inputs-reference-v1";contract=json.loads((inputs/"contract.json").read_bytes())
    assert contract["public_source_sha256"]==public_sha and contract["public_source"]==str(public)
    descriptor=contract["descriptor"];roots,_,_=trusted._validated(descriptor)
    reference=Path(contract["reference"]);assert _input_digest(reference)==contract["reference_sha256"]
    original_path=root/"private-structure-v1/original-record.json";original=json.loads(original_path.read_bytes())
    plan=json.loads((readback/"prepared-plan.json").read_bytes())
    bootstrap={"image":image,"apt_packages":observed["packages"]} if observed["packages"] else None
    assert plan==planner.prepare_shell_record(original,image=image,bootstrap=bootstrap)
    record=plan["record"]
    assert all(record[key]==original[key] for key in original.keys()-{"test_cmds","rebuild_cmds"})
    assert record["FAIL_TO_PASS"]==contract["original_f2p"] and record["PASS_TO_PASS"]==contract["original_p2p"]
    production=tasks.tasks.patch_files(record["patch"]);official=tasks.tasks.patch_files(record["test_patch"])
    assert set(production)==set(contract["production_paths"]) and set(official)==set(contract["official_paths"])
    assert not set(production)&set(official)
    assert not any(Path(name).is_relative_to(root) for name in production for root in roots)
    out=root/"private-preparation-v2";out.mkdir(mode=0o700)
    save(out/"original-record.json",original);save(out/"full-record.json",record)
    (out/"gold.patch").write_text(record["patch"]);(out/"official-tests.patch").write_text(record["test_patch"])
    (out/"baseline.patch").write_bytes(b"")
    assert len(record["test_cmds"])==len(record["print_cmds"])==1
    stream_registration={"version":streams.VERSION,"commands_sha256":streams.commands_digest(record),
        "tests":[{"profile":streams.LIB,"reports":[0],"stderr_files":[]}]}
    save(out/"acceptance-labels.json",{"schema":"source-independent-original-acceptance-v1","task":identity,
        "image":image,"record_sha256":sha(out/"full-record.json"),"original_record_sha256":sha(original_path),
        "original_f2p":original["FAIL_TO_PASS"],"original_p2p":original["PASS_TO_PASS"],
        "expected_population_unchanged":True,"assertions_unchanged":True,"commands_unchanged":False,
        "commands_prepared_before_outcomes":True,"command_preparation_schema":plan["schema"],
        "command_preparation":"Literal same Cargo selectors/env/report and original parser/print; no-fail-fast plus compile-only prefix. Installed package bootstrap omitted using final-image attestation.",
        "actual_program_versions":observed["programs"],"stream_format_contract":streams.LIB,
        "format_compatibility":"Structural stream contract; actual compiler version and controls recorded separately.",
        "controls":[],"paid_ready":False})
    paths=[out/name for name in ("original-record.json","full-record.json","gold.patch","official-tests.patch","acceptance-labels.json")]
    paths += [original_path,inputs/"contract.json",Path(descriptor["manifest"]),Path(descriptor["archive"]),Path(__file__)]
    paths += [root/"public-test-role-inventory-v1/policy.json",root/"common-clean-image-v3/registration.json"]
    paths += [readback/name for name in ("registration.json","result.json","cleanup.json","prepared-plan.json","probe.stdout","public-build-inputs.json")]
    paths += [WORK/"tools/effort_protocol"/name for name in ("evaluator_entry.py","trusted_test_inputs.py","feedback_trusted_inputs.py","feedback_private_commands.py")]
    paths += [write_probe/name for name in ("registration.json","result.json","cleanup.json","probe.stdout")]
    config={"package_root":str(package),"package_files":old["package_files"],"bindings":{str(path):sha(path) for path in paths},
        "record":str(out/"full-record.json"),"acceptance_registration":str(out/"acceptance-labels.json"),"image":image,
        "production_paths":production,"fixed_test_sha256":contract["fixed_test_sha256"],"diagnostic_artifacts":{},
        "stream_registration":stream_registration,"trusted_test_inputs":descriptor}
    save(out/"config.json",config)
    controls=[]
    for name,source,patch,edited in (("baseline",public,out/"baseline.patch",[]),
            ("reference",reference,out/"gold.patch",production),("reference-repeat",reference,out/"gold.patch",production)):
        directory=out/("control-"+name);directory.mkdir()
        proof=directory/"deterministic-control-patch.json"
        save(proof,{"complete":True,"sha256":sha(patch),"bytes":patch.stat().st_size,"edited":edited,
            "scope":"Deterministic baseline/reference calibration; no model author/capture/outcome claim."})
        request={"config":str(out/"config.json"),"config_sha256":sha(out/"config.json"),"source":str(source),
            "source_digest":_input_digest(source),"public_baseline":str(public),"public_baseline_sha256":public_sha,
            "patch":str(patch),"patch_sha256":sha(patch),"capture_proof":str(proof),"capture_proof_sha256":sha(proof)}
        save(directory/"request.json",request)
        controls.append({"name":name,"request":str(directory/"request.json"),"request_sha256":sha(directory/"request.json"),"expected_pass":name!="baseline"})
    assert _input_digest(public)==public_sha and _input_digest(reference)==contract["reference_sha256"]
    verify_package(package,old["package_files"])
    save(out/"registration.json",{"schema":"native-feedback-private-controls-preregistration-v1","task":identity,"image":image,
        "public_source":str(public),"public_source_sha256":public_sha,"reference":str(reference),
        "reference_sha256":contract["reference_sha256"],"config_sha256":sha(out/"config.json"),"controls":controls,
        "selected_label_count":len(record["FAIL_TO_PASS"])+len(record["PASS_TO_PASS"]),
        "protected_input_contract_sha256":sha(inputs/"contract.json"),"prepared_record_sha256":sha(out/"full-record.json"),
        "client_model_calls":0,"paid_ready":False,"scope":"Actual original-label controls pending; stop on first invalid or contradicted control. No private/model resampling."})
    print(json.dumps({"task":identity,"prepared":str(out),"selected_labels":len(record["FAIL_TO_PASS"])+len(record["PASS_TO_PASS"]),"image":image,"paid_ready":False}),flush=True)
if __name__=="__main__":main()
