"""Freeze a source-only standalone-input selection policy before opening private records."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,stat,sys,tomllib
sys.dont_write_bytecode=True
sys.path.insert(0,"/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from receipts import input_digest
from public_build_inputs import generated_inventory
BASE=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
EXCLUDED={".git",".codescout",".claude",".buddy",".superpowers","target","node_modules"}
NAMES={"tests","test","fixtures","testdata","test_data","snapshots","__snapshots__"}
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("tasks",nargs="+")
    args=parser.parse_args()
    assert Path(__file__).stat().st_mode & 0o222 == 0
    for task in args.tasks:
        assert Path(task).name==task
        source=BASE/task/"common-preparation-v1/public-source"
        before=input_digest(source)
        candidates=[];inline=[];linked=[];manifests=[];explicit=[]
        for path in sorted(source.rglob("*")):
            relative=path.relative_to(source)
            if EXCLUDED.intersection(relative.parts):continue
            if path.name=="Cargo.toml" and path.is_file():
                data=tomllib.loads(path.read_text())
                manifests.append({"path":relative.as_posix(),"sha256":sha(path)})
                for target in data.get("test",[]):
                    name=target.get("path")
                    if name is None:continue
                    name=PurePosixPath(name)
                    assert not name.is_absolute() and ".." not in name.parts
                    actual=path.parent/str(name)
                    if actual.is_file():
                        value=actual.relative_to(source).as_posix()
                        explicit.append(value)
                        if "src" in actual.relative_to(path.parent).parts:inline.append(value)
                        else:candidates.append(value)
            if path.is_dir() and path.name in NAMES:
                name=relative.as_posix()
                if path.is_symlink():linked.append(name)
                elif "src" in relative.parts:inline.append(name)
                else:candidates.append(name)
        roots=[]
        for name in sorted(set(candidates),key=lambda x:(len(PurePosixPath(x).parts),x)):
            if not any(PurePosixPath(name).is_relative_to(old) for old in roots):roots.append(name)
        roots.sort()
        assert roots and all((source/name).exists() for name in roots)
        inventory=generated_inventory(source)
        entries={name:item for name,item in inventory.items()
                 if any(PurePosixPath(name).is_relative_to(root) for root in roots)}
        out=BASE/task/"public-test-role-inventory-v1"
        out.mkdir(mode=0o700)
        result={"schema":"source-only-test-role-policy-v1","task":task,
            "source":str(source),"source_sha256":before,
            "producer":{"path":str(Path(__file__).resolve()),"sha256":sha(__file__)},
            "selection":{"directory_names":sorted(NAMES),"excluded_components":sorted(EXCLUDED),
                "exclude_source_module_component":"src","explicit_cargo_test_paths_outside_src":True,
                "minimize_ancestor_overlap":True},
            "registered_roots":roots,"entries":entries,"entries_count":len(entries),
            "cargo_manifests":manifests,"explicit_cargo_test_paths":sorted(set(explicit)),
            "inline_or_source_module_scopes":sorted(set(inline)),
            "linked_candidates_requiring_separate_contract":sorted(set(linked)),
            "private_record_or_gold_read":False,"client_model_calls":0,"paid_ready":False,
            "scope":"Original public standalone role candidates only. Canonical official-test overlay, production overlap, link targets and inline/unprotected assertions require separate validation."}
        assert input_digest(source)==before
        with (out/"policy.json").open("x") as stream:json.dump(result,stream,sort_keys=True,indent=2)
        print(json.dumps({"task":task,"roots":len(roots),"entries":len(entries),
            "inline_scopes":len(set(inline)),"linked_candidates":len(set(linked)),
            "source_unchanged":True,"private_record_or_gold_read":False,"paid_ready":False}),flush=True)
if __name__=="__main__":
    main()
