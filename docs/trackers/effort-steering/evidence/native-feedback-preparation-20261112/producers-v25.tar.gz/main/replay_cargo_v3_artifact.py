"""Read real baseline command receipts through the public artifact exporter."""
import json
from pathlib import Path
import sys
sys.dont_write_bytecode=True
sys.path.insert(0,"/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from public_artifacts import build_public_artifact
base=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/nearai__ironclaw-6724/baseline-public-cargo-v3-v1")
request=json.loads((base/"ordinary-request.json").read_bytes())
registration=json.loads((base/"registration.json").read_bytes())
artifact=build_public_artifact(run_id="ironclaw-public-cargo-v3-v1",phase="repair",arm="R",
    source=Path(registration["source"]),commands=base/"commands",receipt_ids=["ordinary","broader"],submission=None,
    expected_profile="cargo-v3",expected_build_inputs=request["public_build_inputs"])
assert len(artifact["observations"])==2 and all(r["exit_code"]==0 for r in artifact["observations"])
target=base/"public-artifact-replay-v1.json"
with target.open("x") as stream: json.dump(artifact,stream,sort_keys=True,indent=2)
print(json.dumps({"reopened_real_observations":len(artifact["observations"]),"public_artifact":str(target),
                  "client_model_calls":0,"paid_ready":False}))
