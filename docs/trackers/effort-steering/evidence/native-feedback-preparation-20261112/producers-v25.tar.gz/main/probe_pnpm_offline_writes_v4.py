"""Repeat write-location controls on complete metadata/tool/store caches, preserving default frontend build."""
import argparse, hashlib, json, os, shutil, subprocess, sys, time, uuid
from pathlib import Path
sys.dont_write_bytecode = True
from probe_pnpm_offline_writes import OWNER, ROOT, sha, save, docker, inspect, owned, cleanup, input_digest
from probe_pnpm_offline_writes_v3 import WORKER

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--task-id", required=True)
    parser.add_argument("--cache-metadata", type=Path, required=True)
    args = parser.parse_args()
    task = ROOT / args.task_id
    source = task / "source"
    source_sha = input_digest(source)
    original_names = [path.relative_to(source).as_posix() for path in source.rglob("*")]
    metadata = json.loads(args.cache_metadata.read_bytes())
    image = metadata["image"]
    receipt = metadata["receipt"]
    project = Path(receipt["project"])
    assert not project.is_absolute() and ".." not in project.parts
    assert receipt["original_locked_inputs_unchanged"] and not receipt["precomputed_frontend_bundle"]
    image_row = json.loads(subprocess.check_output(["docker", "image", "inspect", image]))[0]
    assert image_row["Id"] == image and not image_row["Config"].get("Volumes")
    environment = dict(value.split("=", 1) for value in image_row["Config"]["Env"])
    assert environment["COREPACK_ENABLE_NETWORK"] == "0"
    cache_root = Path(receipt["corepack_home"]).parent
    assert Path(receipt["pnpm_store"]).parent == cache_root
    assert not (source / project / "node_modules").exists()
    out = task / "pnpm-offline-write-probe-v4"
    out.mkdir()
    control = out / "control"
    control.mkdir()
    (control / "worker.py").write_text(WORKER)
    save(out / "registration.json", {"image": image, "source_sha256": source_sha,
        "cache_metadata": str(args.cache_metadata), "cache_metadata_sha256": sha(args.cache_metadata),
        "producer_sha256": sha(__file__), "worker_sha256": sha(control / "worker.py"),
        "helper_sha256": sha(Path(__file__).with_name("probe_pnpm_offline_writes.py")),
        "worker_module_sha256": sha(Path(__file__).with_name("probe_pnpm_offline_writes_v3.py")),
        "project": str(project), "cache_root": str(cache_root), "client_model_calls": 0, "paid_ready": False,
        "scope": "Four diagnostic combinations of source/cache/node_modules write permissions; no golden/task/actor inputs."})
    name = "ep-pnpm-cache-export-" + uuid.uuid4().hex
    made = docker(["create", "--pull=never", "--name", name, "--label", "effort-feedback-owner=" + OWNER,
        "--network", "none", "--read-only", "--user", "1000:1000", "--cap-drop", "ALL",
        "--security-opt", "no-new-privileges", "--memory", "128m", "--memory-swap", "128m",
        "--cpus", "1", "--pids-limit", "32", "--entrypoint", "/bin/true", image], text=True)
    assert made.returncode == 0
    cid = made.stdout.strip()
    try:
        save(out / "cache-export-inspect.json", owned(cid, image, name))
        copied = docker(["cp", cid + ":" + str(cache_root), str(out / "cache-seed")], timeout=300)
        (out / "cache-copy.stderr").write_bytes(copied.stderr)
        assert copied.returncode == 0
    finally:
        save(out / "cache-export-cleanup.json", cleanup(cid, image, name))
    seed = out / "cache-seed"
    assert (seed / "corepack").is_dir() and (seed / "pnpm-store").is_dir()
    seed_sha = input_digest(seed)
    rows = []
    cases = [("A-source-ro-cache-ro", True, False, False),
             ("B-source-rw-cache-ro", False, False, False),
             ("C-source-rw-cache-rw", False, True, False),
             ("D-source-ro-node-rw-cache-rw", True, True, True)]
    for identity, readonly, cache_rw, node_rw in cases:
        directory = out / identity
        directory.mkdir()
        snapshot = directory / "input"
        shutil.copytree(source, snapshot, symlinks=True)
        assert input_digest(snapshot) == source_sha
        if node_rw:
            (snapshot / project / "node_modules").mkdir()
        projected_sha = input_digest(snapshot)
        assert input_digest(snapshot, original_names) == source_sha
        build = directory / "build"
        build.mkdir()
        (build / "scratch").mkdir()
        mounts = [("type=bind,src=" + str(snapshot) + ",dst=/testbed" + (",readonly" if readonly else "")),
                  "type=bind,src=" + str(build) + ",dst=/build",
                  "type=bind,src=" + str(build / "scratch") + ",dst=/mnt_tmp",
                  "type=bind,src=" + str(control) + ",dst=/control,readonly"]
        if cache_rw:
            shutil.copytree(seed, directory / "cache", symlinks=True)
            assert input_digest(directory / "cache") == seed_sha
            mounts.append("type=bind,src=" + str(directory / "cache") + ",dst=" + str(cache_root))
        if node_rw:
            (directory / "node_modules").mkdir()
            mounts.append("type=bind,src=" + str(directory / "node_modules") + ",dst=/testbed/" + str(project) + "/node_modules")
        name = "ep-pnpm-offline-" + uuid.uuid4().hex
        argv = ["create", "--pull=never", "--name", name, "--label", "effort-feedback-owner=" + OWNER,
            "--network", "none", "--read-only", "--memory", str(8 * 1024**3), "--memory-swap", str(8 * 1024**3),
            "--cpus", "4", "--pids-limit", "512", "--init", "--user", "1000:1000",
            "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
            "--tmpfs", "/tmp:rw,exec,size=1073741824,mode=1777",
            "--env", "pnpm_config_offline=true", "--env", "HOME=/tmp", "--env", "TMPDIR=/mnt_tmp", "--env", "CARGO_NET_OFFLINE=true",
            "--env", "CARGO_TARGET_DIR=/build/target", "--env", "PYTHONDONTWRITEBYTECODE=1",
            "--workdir", "/testbed/" + str(project)]
        for mount in mounts:
            argv += ["--mount", mount]
        argv += ["--entrypoint", "python3", image, "-I", "-B", "/control/worker.py"]
        save(directory / "request.json", {"argv": argv, "source_ro": readonly,
            "cache_rw": cache_rw, "node_modules_rw": node_rw, "source_before": projected_sha,
            "original_source_sha256": source_sha, "cache_seed_sha256": seed_sha, "paid_ready": False})
        made = docker(argv, text=True)
        assert made.returncode == 0, made.stderr
        cid = made.stdout.strip()
        try:
            before = owned(cid, image, name)
            save(directory / "container-before.json", before)
            assert before["HostConfig"]["NetworkMode"] == "none" and before["HostConfig"]["ReadonlyRootfs"] is True
            assert before["HostConfig"]["Memory"] == before["HostConfig"]["MemorySwap"] == 8 * 1024**3
            assert before["HostConfig"]["NanoCpus"] == 4_000_000_000
            observed_mounts = {mount["Destination"]: mount for mount in before["Mounts"]}
            assert observed_mounts["/testbed"]["RW"] is (not readonly)
            if cache_rw:
                assert observed_mounts[str(cache_root)]["RW"] is True
            if node_rw:
                assert observed_mounts["/testbed/" + str(project) + "/node_modules"]["RW"] is True
            started = time.monotonic()
            attached = docker(["start", "-a", cid], timeout=660)
            (directory / "process.stdout").write_bytes(attached.stdout)
            (directory / "process.stderr").write_bytes(attached.stderr)
            after = owned(cid, image, name)
            save(directory / "container-after.json", after)
            assert attached.returncode == after["State"]["ExitCode"] == 0 and not after["State"]["OOMKilled"]
            result = json.loads((build / "worker-result.json").read_bytes())
            assert result["complete"] and len(result["cgroup_samples"]) == 2
            assert input_digest(snapshot, original_names) == source_sha
            if readonly:
                assert input_digest(snapshot) == projected_sha
            rows.append({"case": identity, "source_ro": readonly, "cache_rw": cache_rw, "node_modules_rw": node_rw,
                "commands": result["commands"], "original_inputs_unchanged": True,
                "command_timelimit_hit": result["command_timelimit_hit"], "pnpm_offline": True,
                "cgroup_probes": len(result["cgroup_samples"]), "wall_s": time.monotonic()-started,
                "owned_cleanup_pending": True})
        finally:
            save(directory / "cleanup.json", cleanup(cid, image, name))
        rows[-1]["owned_cleanup_pending"] = False
        save(directory / "result.json", rows[-1])
        print(json.dumps(rows[-1]), flush=True)
    assert input_digest(source) == source_sha and input_digest(seed) == seed_sha
    save(out / "result.json", {"cases": rows, "original_source_unchanged": True,
        "seed_cache_unchanged": True, "image": image, "client_model_calls": 0, "paid_ready": False,
        "scope": "Four observed frontend dependency write-location controls only; no new execution profile or repair-quality qualification."})

if __name__ == "__main__":
    main()
