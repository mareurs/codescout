"""Preserve the failed no-provider qualification without rewriting its registration."""
import hashlib
import json
from pathlib import Path
ROOT = Path("/var/tmp/native-feedback-qualified-v2-01a15")
OUT = Path("docs/trackers/effort-steering/evidence/native-feedback-preparation-20261112/qualification-v2-stopped-v1.json")
assert not OUT.exists()
bindings = {}
def read(path):
    data = path.read_bytes()
    bindings[str(path)] = hashlib.sha256(data).hexdigest()
    return json.loads(data)
result = read(ROOT / "result.json")
assert result["status"] == "stopped" and len(result["attempts"]) == 5 and len(result["unexecuted"]) == 11
rows = []
for index, item in enumerate(result["attempts"]):
    attempt = read(Path(item["attempt_receipt"]))
    record = attempt["invocations"][0]["record"]
    row = {"index": index, "task_id": attempt["task_id"], "arm": attempt["arm"],
           "workflow_state": attempt["workflow_state"], "measurement_invalid": attempt["measurement_invalid"],
           "actor_started": record["actor_started"], "cost": attempt["cost"], "private_grade": attempt["grade"]}
    if index < 4:
        assert attempt["task_id"] == "apache__arrow-rs-7783" and attempt["workflow_state"] == "closed"
        assert not attempt["measurement_invalid"] and record["context_valid"] and record["capture_complete"] and record["cleanup_complete"]
        assert record["lifecycle"]["turns"] == 5 and record["lifecycle"]["continuations"] == 4
        native = Path(record["native_path"])
        receipt = read(native / "receipt.json")
        launch = read(native / "launch.json")
        assert receipt["forwarded"] == 0 and receipt["unknown_provider_cost"] is False
        assert launch["scripted"] is True and launch["real_credentials_read"] is False
        row.update(turns=5, continuations=4, provider_forwarded=0, credentials_read=False)
    else:
        assert record["actor_started"] is False and record["turns"] == 0
        row["reason"] = record["reason"]
        calls = read(Path(record["native_path"]) / "readiness/readiness-calls.json")
        workspace = [call for call in calls if call["method"] == "tools/call" and call["params"]["name"] == "workspace"]
        assert len(workspace) == 1
        envelope = json.loads(workspace[0]["response"]["result"]["content"][0]["text"])
        assert envelope["output_id"].startswith("@tool_") and envelope["buffered_bytes"] == 14177
        row["status_envelope"] = envelope
    rows.append(row)
assert all(row["private_grade"] is None and row["cost"] == {"known_usd": "0", "unknown": False} for row in rows)
payload = {"schema": "native-feedback-qualification-failure-v1", "status": "stopped",
           "rows": rows, "closed_arrow_receipts": 4, "attempt_receipts": 5, "unexecuted": 11,
           "private_grades": 0, "known_client_usd": "0", "paid_ready": False,
           "compute_cost": "unknown", "efficacy_claim": None, "bindings": bindings}
OUT.write_text(json.dumps(payload, indent=2) + "\n")
print(json.dumps({"path": str(OUT), "sha256": hashlib.sha256(OUT.read_bytes()).hexdigest(),
                  "closed_arrow_receipts": 4, "private_grades": 0, "paid_ready": False}))
