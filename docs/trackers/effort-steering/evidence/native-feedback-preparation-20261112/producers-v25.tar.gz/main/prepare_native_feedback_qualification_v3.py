"""Bind the reviewed source and measured public canaries into a new16CLI qualification."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
WORK = Path("/home/marius/.codex/worktrees/2aa6/codescout")
MAIN = Path("/home/marius/work/claude/codescout")
BASE = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
OUT = BASE / "native-feedback-qualification-v3-registration"
RUN = Path("/var/tmp/native-feedback-qualified-v3-01a15")
CANARY = Path("/var/tmp/native-feedback-readiness-canaries-v3-01a15")
PROBE = Path("/var/tmp/native-feedback-readiness-buffers-v3-01a15")
sys.path[:0] = [str(WORK / "tools" / name) for name in
                ("effort_protocol", "agent_lifecycle", "hint_authority_pilot")]
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):
    return json.loads(Path(path).read_bytes())
def save(path, value):
    with Path(path).open("x") as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + "\n")
def main():
    assert Path(__file__).stat().st_mode & 0o222 == 0
    assert not OUT.exists() and not RUN.exists()
    reg = copy.deepcopy(read(CANARY / "registration.json"))
    measured = read(PROBE / "result.json")
    assert measured["all_ready"] is True and len(measured["tasks"]) == 4
    assert {row["task_id"] for row in measured["tasks"]} == set(reg["tasks"])
    assert all(row["ready"] is True for row in measured["tasks"])
    OUT.mkdir()
    reg.update(campaign_id="native-feedback-qualified-v3-01a15", output_root=str(RUN))
    prior_path = Path(__file__).with_name("prepare_native_feedback_qualification_v1.py")
    spec = importlib.util.spec_from_file_location("qualification_v1_plan_builder", prior_path)
    prior = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(prior)
    for task in reg["tasks"].values():
        probes = task["backend"]["public"]["registered_readiness"]["probes"]
        task["backend"]["scripted_plans"] = {
            arm + ":repair": prior.plan(task["source"], probes) for arm in "LRPX"}
    source = MAIN / "docs/trackers/effort-steering/evidence/native-feedback-baseline-20261111/task5-real-mcp-framing-reviewed-v1.json"
    custody = read(source)
    assert len(custody["members"]) == 142 and custody["legacy_inputs_reopened_unchanged"] == 102
    assert all(sha(WORK / path) == row["sha256"] for path, row in custody["members"].items())
    scope = OUT / "scope.json"
    save(scope, {"scope": "New full16CLI qualification bound to reviewed source142 and measured public capability canaries.",
                 "old_stopped_qualification": "/var/tmp/native-feedback-qualified-v2-01a15",
                 "canary_scope": read(CANARY / "scope.json"), "client_author_calls": 0,
                 "client_provider_calls": 0, "compute_cost": "unknown", "paid_ready": False})
    reg["shared_preparation"] = {"cost_usd": "0", "receipt_sha256": sha(scope)}
    driver = Path(__file__).with_name("qualify_native_feedback_campaign_v3.py").resolve()
    dependencies = [Path(__file__).resolve(), prior_path.resolve(),
                    driver.with_name("qualify_native_feedback_campaign_v1.py")]
    reg["qualification_driver"] = {"path": str(driver), "sha256": sha(driver)}
    reg["qualification_driver_dependencies"] = [{"path": str(path), "sha256": sha(path)} for path in dependencies]
    files = [driver, *dependencies, scope, source, CANARY / "registration.json", CANARY / "scope.json",
             PROBE / "result.json", PROBE / "inputs.json"]
    for folder in ("effort_protocol", "agent_lifecycle", "hint_authority_pilot"):
        files.extend(path for path in (WORK / "tools" / folder).glob("*.py")
                     if not path.name.startswith("test_") and path.name != "paid_admission.py")
    files.extend(WORK / path for path in custody["members"])
    for path in files:
        reg["bindings"][str(path)] = sha(path)
    assert all(sha(path) == digest for path, digest in reg["bindings"].items())
    save(OUT / "final-registration.json", reg)
    print(json.dumps({"registration": str(OUT / "final-registration.json"),
                      "schedule": len(reg["schedule"]), "tasks": len(reg["tasks"]),
                      "source_members": 142, "paid_ready": False}))
if __name__ == "__main__":
    main()
