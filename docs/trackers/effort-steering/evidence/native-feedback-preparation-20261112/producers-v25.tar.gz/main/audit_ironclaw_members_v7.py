"""Independently reopen every member result and raw RPC, then inspect owned cleanup."""
from pathlib import Path
import hashlib,json,subprocess,sys
sys.dont_write_bytecode=True
sys.path.insert(0,"/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from native_executor import _public_digest
from readiness import _verify_index
from hit_source_provenance import verify_hit
ROOT=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/nearai__ironclaw-6724/common-preparation-v1")
def load(path):return json.loads(Path(path).read_bytes())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def main():
    assert Path(__file__).stat().st_mode & 0o222 == 0
    out=ROOT/"configured-member-qualification-v7";prior=ROOT/"configured-member-qualification-v6"
    reg=load(out/"registration.json");result=load(out/"result.json");prep=load(ROOT/"preparation.json")
    expected={row["id"]:row["root"] for row in prep["configured_projects"] if row["root"]!="."}
    assert len(expected)==reg["configured_nonroot_count"]==74
    assert result["all_configured_members_checked"] and len(result["members"])==74
    assert {row["id"]:row["root"] for row in result["members"]}==expected
    assert all(sha(path)==digest for path,digest in reg["bindings"].items())
    original=load(prior/"registration.json")
    assert all(sha(path)==digest for path,digest in original["bindings"].items())
    assert reg["prior_registration_sha256"]==sha(prior/"registration.json")
    assert reg["prior_failure_sha256"]==sha(prior/"failure.json")
    assert reg["producer_read_only"] is True
    assert Path(next(path for path in reg["bindings"] if Path(path).name=="qualify_prepared_build_members_v7.py")).stat().st_mode & 0o222 == 0
    helper=Path(__file__).with_name("prior_prepare_native.py")
    assert sha(helper)==load(ROOT/"registration.json")["native_helper_sha256"]
    project=ROOT/"project"
    assert _public_digest(project,preserve_project_context=True)==reg["public_source_sha256"]==prep["template_public_sha256"]
    calls=[row for row in load(out/"native/calls.json") if row["method"]=="tools/call"
           and row["params"]["name"]=="semantic_search"]
    assert len(calls)==74
    actual={row["params"]["arguments"]["project_id"]:row for row in calls}
    assert len(actual)==74 and set(actual)==set(expected)
    hits=0;reused=0;continuations=0
    for row in result["members"]:
        identity=row["id"];directory=out/"members"/identity
        assert load(directory/"result.json")==row and type(row["index_reused"]) is bool
        assert sha(directory/"semantic.json")==row["semantic_sha256"]
        assert sha(directory/"source-provenance.json")==row["provenance_sha256"]
        state=load(project/row["root"]/".codescout/index-state.json")
        assert state==load(directory/"index-state.json") and state["indexed_with_model"]=="CodeRankEmbed"
        if row["index_reused"]:
            link=load(directory/"reused-index.json")
            command=Path(link["prior_command"]);old_state=Path(link["prior_state"])
            assert command==prior/"members"/identity/"command.json"
            assert old_state==prior/"members"/identity/"index-state.json"
            assert sha(command)==link["prior_command_sha256"] and load(command)["returncode"]==0
            assert sha(old_state)==link["prior_state_sha256"] and load(old_state)==state
            assert sha(project/row["root"]/".codescout/index-state.json")==link["state_sha256"]
            reused+=1
        else:assert load(directory/"command.json")["returncode"]==0
        response=load(directory/"semantic.json")
        assert response==actual[identity]["response"]
        assert actual[identity]["params"]["arguments"]=={
            "query":identity.replace("-"," ").replace("_"," ")+" source implementation",
            "project_id":identity,"limit":3,"detail_level":"full"}
        payload=json.loads(response["result"]["content"][0]["text"])
        checked=[verify_hit(project/row["root"],hit) for hit in payload["results"]]
        assert checked==load(directory/"source-provenance.json") and len(checked)==row["returned_hits_checked"]
        hits+=len(checked)
        continuations+=sum(item["mode"]=="source-span-with-declared-continuation" for item in checked)
    old_commands={p.parent.name for p in (prior/"members").glob("*/command.json")}
    new_commands={p.parent.name for p in (out/"members").glob("*/command.json")}
    assert not old_commands & new_commands and old_commands | new_commands == set(expected)
    assert len(old_commands)==reused==result["reused_indexes"]
    assert len(new_commands)==74-reused==result["new_explicit_index_cli_calls"]
    coverage=_verify_index(load(out/"root-index-verification.json"),project,
                           omission_policy="ascii-whitespace-source-v1")
    native=load(out/"native/cleanup.json");embedding=load(out/"embedding/cleanup.json")
    assert native["cleanup_complete"] and not native["close_errors"]
    assert embedding["complete"] and not embedding["errors"]
    absence=[]
    for kind,identity in (("container",native["container"]),("container",embedding["proxy"]),("network",embedding["network_id"])):
        argv=["docker"]+(["network","inspect"] if kind=="network" else ["inspect"])+[identity]
        run=subprocess.run(argv,capture_output=True,text=True,timeout=60)
        assert run.returncode==1 and identity in run.stderr and any(word in run.stderr.lower() for word in ("no such","not found"))
        absence.append({"kind":kind,"id":identity,"returncode":run.returncode,"stderr_sha256":hashlib.sha256(run.stderr.encode()).hexdigest()})
    assert _public_digest(project,preserve_project_context=True)==reg["public_source_sha256"]
    audit={"schema":"ironclaw-member-control-audit-v1","member_namespaces":74,
        "raw_semantic_rpc_responses":len(calls),"returned_payload_rows_reopened":hits,
        "continuation_payload_rows":continuations,"reused_v6_index_commands":reused,
        "new_v7_index_commands":len(new_commands),"no_duplicate_member_index_commands":True,
        "root_index_coverage":coverage,"public_source_sha256":reg["public_source_sha256"],
        "source_and_bound_code_unchanged":True,"fresh_absence":absence,
        "one_original_onboarding_reused":True,"additional_onboarding_calls":0,"client_model_calls":0,
        "embedding_compute_cost_usd":None,"root_review_compute_cost_usd":None,"paid_ready":False,
        "reader_sha256":sha(__file__),"scope":"Actual74 member namespaces, raw returned payload provenance, protected root omission interpretation and owned cleanup only; no actor CLI/LSP or repair efficacy."}
    target=Path("/home/marius/work/claude/codescout/docs/trackers/effort-steering/evidence/native-feedback-preparation-20261112/ironclaw-members-v7-audit.json")
    with target.open("x") as stream:json.dump(audit,stream,sort_keys=True,indent=2)
    print(json.dumps(audit,sort_keys=True))
if __name__=="__main__":main()
