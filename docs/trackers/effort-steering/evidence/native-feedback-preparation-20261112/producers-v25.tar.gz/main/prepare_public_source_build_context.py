"""One native source-only onboarding; reuse public guidance, materialize safe instruction links once."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re, shutil, subprocess, sys, tomllib
sys.dont_write_bytecode = True
WORK = Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path.insert(0, str(WORK / "tools/effort_protocol"))
from receipts import input_digest
from native_executor import _public_digest
SCRIPTS = Path(__file__).parent.resolve()
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
def ignore_private(root, relative, overlays):
    path = root / relative / ".gitignore"
    assert path.parent.is_dir() and not path.is_symlink()
    before = path.read_bytes() if path.exists() else b""
    line = b".codescout/private-memories/"
    if line not in before.splitlines():
        after = before + (b"\n" if before and not before.endswith(b"\n") else b"") + line + b"\n"
        path.write_bytes(after)
        overlays.append({"path": path.relative_to(root).as_posix(), "kind": "native-private-memory-ignore",
            "before_sha256": hashlib.sha256(before).hexdigest(), "after_sha256": sha(path)})
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--task-id", required=True)
    parser.add_argument("--ready", type=Path, required=True)
    parser.add_argument("--image-metadata", type=Path, required=True)
    parser.add_argument("--build-inputs-request", type=Path, required=True)
    args = parser.parse_args()
    task = ROOT / args.task_id
    original = task / "source"
    original_sha = input_digest(original)
    ready = json.loads(args.ready.read_bytes())
    assert ready["source_unchanged"] and all(r["complete"] and r["resource_valid"] and r["exit_code"] == 0 for r in ready["baseline_scopes"])
    image_data = json.loads(args.image_metadata.read_bytes())
    image = (image_data[0] if isinstance(image_data, list) else image_data)["Id"]
    build_request = json.loads(args.build_inputs_request.read_bytes())
    descriptor = build_request["public_build_inputs"]
    assert descriptor["image"] == image
    out = task / "common-preparation-v1"
    out.mkdir()
    baseline = out / "public-source"
    shutil.copytree(original, baseline, symlinks=True)
    overlays = []
    for relative in descriptor["dependency_dirs"]:
        target=baseline/relative
        assert not target.exists() and target.parent.is_dir()
        target.mkdir()
        overlays.append({"path":relative,"kind":"declared-empty-public-dependency-target"})
    from public_build_inputs import validate_descriptor
    admitted=validate_descriptor(descriptor,baseline,image)
    documents = [name for name in ("CLAUDE.md", "AGENTS.md", "README.md", "CONTRIBUTING.md", "ARCHITECTURE.md")
        if (baseline / name).is_file()]
    assert documents
    instructions = baseline / "CLAUDE.md"
    if instructions.is_symlink():
        link = str(instructions.readlink())
        target = instructions.resolve(strict=True)
        assert target.is_relative_to(baseline.resolve()) and target.is_file()
        content = target.read_bytes()
        instructions.unlink()
        instructions.write_bytes(content)
        overlays.append({"path": "CLAUDE.md", "kind": "materialized-internal-instruction-link",
            "original_target": link, "effective_bytes_unchanged": True, "sha256": sha(instructions)})
    elif not instructions.exists():
        text = "# Project instructions\n\nRead the existing public project documents before working:\n\n"
        text += "".join("- " + name + "\n" for name in documents)
        instructions.write_text(text)
        documents.insert(0, "CLAUDE.md")
        overlays.append({"path": "CLAUDE.md", "kind": "public-document-bridge", "sha256": sha(instructions)})
    assert instructions.is_file() and not instructions.is_symlink()
    ignore_private(baseline, Path("."), overlays)
    project = out / "project"
    shutil.copytree(baseline, project, symlinks=True)
    subprocess.run(["git", "init", "-q"], cwd=project, check=True)
    (project / ".git/info/attributes").write_text("* -text -ident -filter\n")
    save(out / "public-build-inputs.json", {"descriptor":descriptor,"fingerprint":admitted["fingerprint"],
        "request":str(args.build_inputs_request),"request_sha256":sha(args.build_inputs_request),
        "canonical_targets_created_before_onboarding":True,"paid_ready":False})
    seed_module = load("common_public_source_seed", SCRIPTS / "prepare_arrow_context.py")
    seed_module.seed(project)
    runtime_origin = ROOT / "apache__arrow-rs-7783/common-preparation-v3/native-runtime-private-v4.json"
    runtime = json.loads(runtime_origin.read_bytes())
    runtime["Image"] = image
    runtime_env = dict(v.split("=", 1) for v in runtime["Config"]["Env"])
    assert runtime_env["CODESCOUT_EMBED_MODEL"] == "CodeRankEmbed"
    assert runtime_env["CODESCOUT_EMBED_URL"] == "http://source-embeddings:8000/v1"
    save(out / "native-runtime.json", runtime)
    save(out / "registration.json", {"task": args.task_id, "source": str(original), "source_digest": original_sha,
        "image": image, "ready_result": str(args.ready), "ready_result_sha256": sha(args.ready),
        "image_metadata": str(args.image_metadata), "image_metadata_sha256": sha(args.image_metadata),
        "public_build_inputs":descriptor,"public_build_inputs_sha256":admitted["fingerprint"],
        "producer_sha256": sha(__file__), "native_helper_sha256": sha(SCRIPTS / "prior_prepare_native.py"),
        "seed_helper_sha256": sha(SCRIPTS / "prepare_arrow_context.py"),
        "runtime_origin_sha256": sha(runtime_origin), "programmatic_onboarding_calls_planned": 1,
        "scope": "Public source/config/documents only; no issue, labels, private patch, gold or author model", "paid_ready": False})
    module = load("single_public_native_onboarding", SCRIPTS / "prior_prepare_native.py")
    module.ROOT, module.IMAGE = out, image
    native = None
    try:
        native = module.Native("onboarding", project, {"native_image": image, "runtime_manifest": str(out / "native-runtime.json")})
        native.start()
        native.tool("onboarding", {}, timeout=240)
    finally:
        if native is not None: native.close()
    # No retry of onboarding even if a later source/readiness guard fails.
    assert _public_digest(project) == input_digest(baseline)
    workspace = project / ".codescout/workspace.toml"
    configured = tomllib.loads(workspace.read_text())["project"] if workspace.exists() else []
    for entry in configured:
        relative = Path(entry["root"])
        assert not relative.is_absolute() and ".." not in relative.parts
        before_count = len(overlays)
        ignore_private(baseline, relative, overlays)
        if len(overlays) != before_count:
            target = project / relative / ".gitignore"
            shutil.copy2(baseline / relative / ".gitignore", target)
    assert _public_digest(project) == input_digest(baseline)
    knowledge = project / ".codescout"
    memories = knowledge / "memories"
    memories.mkdir(exist_ok=True)
    provenance, aliases, by_hash = {}, {}, {}
    for name in documents:
        source = baseline / name
        digest = sha(source)
        if digest in by_hash:
            aliases[name] = by_hash[digest]
            continue
        topic = "source-" + name.removesuffix(".md").lower()
        target = memories / (topic + ".md")
        with target.open("xb") as stream: stream.write(source.read_bytes())
        provenance[topic] = {"source": name, "sha256": digest, "bytes": source.stat().st_size}
        by_hash[digest] = topic
    prompt = knowledge / "system-prompt.md"
    assert not prompt.exists()
    text = "# Source-only repository guidance\n\nFollow the common project CLAUDE.md and existing project instructions.\n\n"
    text += "Unaltered public document payloads are available as Codescout memories:\n"
    text += "".join("- " + topic + " from " + row["source"] + "\n" for topic, row in provenance.items())
    prompt.write_text(text)
    config = knowledge / "project.toml"
    original_config = config.read_text()
    (out / "project-config-onboarding-original.toml").write_text(original_config)
    content, count = re.subn(r"(?ms)^\[embeddings\].*?(?=^\[|\Z)",
        '[embeddings]\nmodel = "CodeRankEmbed"\nurl = "http://source-embeddings:8000/v1"\n\n', original_config)
    assert count == 1
    content, count = re.subn(r'system_prompt_sha256 = "[0-9a-f]+"',
        'system_prompt_sha256 = "' + sha(prompt) + '"', content)
    assert count == 1
    config.write_text(content)
    seed_module.seed(project)
    assert input_digest(original) == original_sha and _public_digest(project) == input_digest(baseline)
    cleanup = json.loads((out / "onboarding/cleanup.json").read_bytes())
    assert cleanup["cleanup_complete"] and not cleanup["close_errors"]
    save(out / "preparation.json", {"programmatic_onboarding_calls": 1, "additional_onboarding_calls": 0,
        "public_build_inputs":descriptor,"public_build_inputs_sha256":admitted["fingerprint"],
        "author_model_calls": 0, "client_model_calls": 0, "public_overlays": overlays,
        "source_documents": provenance, "duplicate_document_aliases": aliases, "configured_projects": configured,
        "public_baseline_sha256": input_digest(baseline), "template_public_sha256": _public_digest(project),
        "original_source_unchanged": True, "index_calls": 0, "paid_ready": False,
        "root_review_embedding_compute_costs": "unmeasured",
        "scope": "One programmatic onboarding plus source document payloads; not LLM deep-dive or index/canary/author-context qualification."})
    print(json.dumps({"source_only_prepared": str(out), "onboarding_calls": 1, "additional_onboarding_calls": 0, "paid_ready": False}))

if __name__ == "__main__":
    main()
