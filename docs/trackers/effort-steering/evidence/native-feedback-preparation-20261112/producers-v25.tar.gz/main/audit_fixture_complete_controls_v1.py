"""Independent complete-reference admission/receipt/cleanup readback; no provider calls."""
from pathlib import Path
import hashlib,json,subprocess,sys
sys.dont_write_bytecode=True
WORK=Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from feedback_admission import verify_reference_controls
from receipts import input_digest
BASE=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/fixture-complete-controls-v1")
MAIN=Path("/home/marius/work/claude/codescout")
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def main():
    assert Path(__file__).stat().st_mode & 0o222==0
    population=json.loads((BASE/"preparation.json").read_bytes())
    tasks=population["tasks"]
    assert len(tasks)==len(set(tasks))==4
    registration={"tasks":{},"bindings":{}};evidence={};controls=[];containers=set();code_paths=set()
    evidence_bindings={str(BASE/"preparation.json"):sha(BASE/"preparation.json")}
    for identity in tasks:
        parent=BASE/identity;runtime=parent/"runtime"
        prepared=json.loads((parent/"preparation.json").read_bytes())
        reg=json.loads((runtime/"registration.json").read_bytes())
        proof=json.loads((runtime/"evidence.json").read_bytes())
        result=json.loads((runtime/"result.json").read_bytes())
        assert reg["tasks"]=={identity:prepared["task"]} and set(proof)=={identity}
        assert result["actor_source_unchanged"] and result["client_model_calls"]==0
        for path,digest in {**prepared["source_bindings"],**result["source_bindings"]}.items():
            assert sha(path)==digest
            code_paths.add(path)
        for path,digest in reg["bindings"].items():
            assert sha(path)==digest
            assert registration["bindings"].get(path,digest)==digest
            registration["bindings"][path]=digest
        registration["tasks"].update(reg["tasks"]);evidence.update(proof)
        task=reg["tasks"][identity];ref=proof[identity]["reference"]
        sources={"baseline":(Path(task["source"]),task["source_sha256"]),
                 "reference":(Path(ref["source"]),ref["source_sha256"])}
        assert len(result["rows"])==4
        for source_role,(source,digest) in sources.items():
            assert input_digest(source)==digest
            for kind in ("ordinary","broader"):
                directory=runtime/source_role/kind
                declared=json.loads((directory/"registration.json").read_bytes())
                observed=json.loads((directory/"result.json").read_bytes())
                assert declared["source_role"]==source_role and declared["source"]==str(source)
                assert declared["source_digest"]==digest
                request=declared["request"]
                command=directory/"commands"/request["id"]
                before=json.loads((command/"container-before.json").read_bytes())
                after=json.loads((command/"container-after.json").read_bytes())
                cid=before["Id"]
                assert after["Id"]==cid and cid not in containers
                assert before["Image"]==after["Image"]==task["backend"]["public"]["image"]
                containers.add(cid)
                absent=subprocess.run(["docker","container","inspect",cid],capture_output=True,timeout=60)
                assert absent.returncode==1 and cid.encode() in absent.stderr and b"no such" in absent.stderr.lower()
                assert observed["complete"] is True and observed["resource_valid"] is True
                assert type(observed["exit_code"]) is int and observed["exit_code"]==0
                controls.append({"task":identity,"source_role":source_role,"kind":kind,
                    "source_sha256":digest,"argv":request["argv"],"exit_code":observed["exit_code"],
                    "container":cid,"fresh_absence":True})
                for path in (directory/"registration.json",directory/"result.json",
                             command/"container-before.json",command/"container-after.json"):
                    evidence_bindings[str(path)]=sha(path)
        for path in (parent/"preparation.json",runtime/"registration.json",runtime/"evidence.json",runtime/"result.json"):
            evidence_bindings[str(path)]=sha(path)
    checked=verify_reference_controls(registration,evidence)
    assert len(controls)==len(containers)==16
    assert all(row["baseline"]["verified_commands"]==row["reference"]["verified_commands"]==2
               and row["closure"]["role"]=="private-reference-only" for row in checked.values())
    assert all(sha(path)==digest for path,digest in {**registration["bindings"],**evidence_bindings}.items())
    output=MAIN/"docs/trackers/effort-steering/evidence/native-feedback-preparation-20261112/fixture-complete-controls-v1-audit.json"
    packet={"schema":"fixture-complete-reference-control-audit-v1","tasks":tasks,"controls":controls,
        "verified":checked,"evidence_bindings":evidence_bindings,"source_binding_files_reopened":len(code_paths),
        "producer_sha256":sha(__file__),"client_model_calls":0,"paid_ready":False,
        "scope":"Actual current mandatory four-task complete-reference reader, unchanged actor baselines, both exact public scopes, generated dependency/raw receipt readback and16distinct freshly absent containers. No actor CLI or efficacy claim."}
    with output.open("x") as stream:json.dump(packet,stream,sort_keys=True,indent=2);stream.write("\n")
    print(json.dumps({key:value for key,value in packet.items() if key not in ("evidence_bindings","controls")}),flush=True)
    return 0
if __name__=="__main__":
    raise SystemExit(main())
