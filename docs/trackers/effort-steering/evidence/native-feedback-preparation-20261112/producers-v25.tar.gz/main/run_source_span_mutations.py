"""Apply actual isolated mutations; interpret unittest counts, not the Cargo-only wrapper verdict."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
sys.dont_write_bytecode = True
MAIN = Path("/home/marius/work/claude/codescout")
SCRIPTS = MAIN / ".superpowers/sdd/2026-11-11-native-public-feedback-transfer"
OUT = SCRIPTS / "source-span-mutations-v1"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")


def summary(result):
    text = result.stdout + result.stderr
    counts = re.findall(r"^Ran ([0-9]+) tests? in ", text, re.MULTILINE)
    assert len(counts) == 1, "runner population was not measured exactly once"
    count = int(counts[0])
    assert count > 0
    if result.returncode == 0 and re.search(r"^OK$", text, re.MULTILINE):
        return count, "pass"
    assert result.returncode != 0 and re.search(r"^FAILED \(failures=[1-9][0-9]*\)$", text, re.MULTILINE)
    assert not re.search(r"^ERROR:", text, re.MULTILINE), "import/setup failure is not a killed mutant"
    return count, "test-failure"


def main():
    OUT.mkdir()
    repo = OUT / "fixture"
    repo.mkdir()
    names = ("hit_source_provenance.py", "test_hit_source_provenance.py")
    source_hashes = {name: sha(SCRIPTS / name) for name in names}
    for name in names:
        shutil.copy2(SCRIPTS / name, repo / name)
    env = dict(os.environ, GIT_CONFIG_NOSYSTEM="1", GIT_CONFIG_GLOBAL="/dev/null",
        CODEX_SESSION_ID="01a15ca9-f939-7603-acb5-01c6b02f68e2", PYTHONDONTWRITEBYTECODE="1")
    for argv in (["git", "init", "-q"], ["git", "add", "--", *names],
                 ["git", "-c", "user.name=Codex fixture", "-c", "user.email=codex-fixture@local.invalid",
                  "commit", "-qm", "Source-span mutation fixture\n\nSession-Id: codex:01a15ca9-f939-7603-acb5-01c6b02f68e2"]):
        subprocess.run(argv, cwd=repo, env=env, capture_output=True, check=True)
    command = [sys.executable, "-B", "-m", "unittest", "discover", "-s", ".", "-p", "test_hit_source_provenance.py", "-v"]
    baseline = subprocess.run(command, cwd=repo, env=env, capture_output=True, text=True, timeout=60)
    (OUT / "baseline.stdout").write_text(baseline.stdout)
    (OUT / "baseline.stderr").write_text(baseline.stderr)
    count, kind = summary(baseline)
    assert kind == "pass"
    source = (repo / names[0]).read_text()
    start = source.index("def lf_lines(text):")
    end = source.index("\n\ndef verify_hit", start)
    mutations = [
        ("lf-to-python-splitlines", source[start:end], "def lf_lines(text):\n    return text.splitlines()"),
        ("remove-body-span-check", "prefix.strip() and body.strip() and body.strip() in span", "prefix.strip() and body.strip()"),
        ("remove-earlier-prefix-check", 'require(locations, "continuation prefix is not verbatim earlier source text")',
         'require(True, "continuation prefix is not verbatim earlier source text")'),
        ("remove-end-bound", "1 <= start <= end <= len(lines)", "1 <= start <= end"),
    ]
    rows = []
    for identity, old, new in mutations:
        assert source.count(old) == 1
        directory = OUT / identity
        directory.mkdir()
        argv = [str(MAIN / "scripts/mutation-probe.sh"), "--file", names[0], "--find", old, "--replace", new, "--", *command]
        result = subprocess.run(argv, cwd=repo, env=env, capture_output=True, text=True, timeout=300)
        (directory / "stdout").write_text(result.stdout)
        (directory / "stderr").write_text(result.stderr)
        actual, outcome = summary(result)
        assert actual == count
        assert sha(repo / names[0]) == source_hashes[names[0]]
        assert all(sha(SCRIPTS / name) == expected for name, expected in source_hashes.items())
        row = {"mutation": identity, "argv": argv, "returncode": result.returncode,
            "unittest_tests_run": actual, "observed": "survived" if outcome == "pass" else "killed",
            "wrapper_verdict_scope": "Cargo count parser excludes Python; use observed unittest summary.",
            "source_fixture_restored": True, "main_inputs_unchanged": True}
        save(directory / "result.json", row)
        rows.append(row)
        print(json.dumps({key: value for key, value in row.items() if key != "argv"}), flush=True)
    save(OUT / "result.json", {"baseline_tests_run": count, "mutations": rows,
        "applied_mutations": len(rows), "survived": sum(row["observed"] == "survived" for row in rows),
        "killed": sum(row["observed"] == "killed" for row in rows), "source_hashes": source_hashes,
        "producer_sha256": sha(__file__), "independent_review": False, "client_model_calls": 0,
        "scope": "Actually applied mutations on isolated two-file Git fixture; no production or frozen evaluator source mutation."})


if __name__ == "__main__":
    main()
