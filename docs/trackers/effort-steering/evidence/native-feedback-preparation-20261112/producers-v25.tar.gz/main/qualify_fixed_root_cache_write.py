"""Qualify actual uid0 zero-capability cache writes in a disposable writable image overlay."""
from pathlib import Path
import hashlib,json,re,subprocess,sys,uuid
BASE=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
IDS=("DioxusLabs__dioxus-5384","nearai__ironclaw-6724")
CODE="""import json,os,stat,uuid
from pathlib import Path
result={"euid":os.geteuid(),"cap_eff":next(x.split()[1] for x in Path('/proc/self/status').read_text().splitlines() if x.startswith('CapEff:')),"entries":{}}
for name in ("/testbed/target","/testbed/target/debug","/testbed/target/debug/.cargo-lock","/usr/local/cargo"):
    path=Path(name);s=path.stat();row={"uid":s.st_uid,"gid":s.st_gid,"mode":oct(stat.S_IMODE(s.st_mode))}
    target=path/(".effort-write-probe-"+uuid.uuid4().hex) if path.is_dir() else path
    try:
        fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600) if path.is_dir() else os.open(target,os.O_WRONLY)
        os.close(fd)
        if path.is_dir():target.unlink()
        row["opened_for_write"]=True
    except OSError as exc:row.update(opened_for_write=False,errno=exc.errno,error=str(exc))
    result["entries"][name]=row
print(json.dumps(result,sort_keys=True))
"""
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):
    with path.open("x") as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write(chr(10))
def docker(*args,check=True):
    p=subprocess.run(["docker",*args],capture_output=True,timeout=180)
    if check and p.returncode:raise RuntimeError(repr((args,p.returncode,p.stderr[-2000:])))
    return p
def main():
    assert Path(__file__).stat().st_mode & 0o222==0
    identity=sys.argv[1];assert identity in IDS
    root=BASE/identity/"common-clean-image-v3";image=json.loads((root/"result.json").read_bytes())["image"]
    readback=root/"public-readback-v1"
    assert json.loads((readback/"result.json").read_bytes())["complete"] and json.loads((readback/"cleanup.json").read_bytes())["complete"]
    out=root/"root-write-qualification-v1";out.mkdir()
    name="ep-root-write-qualified-"+uuid.uuid4().hex;cid=None
    argv=["create","--name",name,"--label","effort-feedback-owner=codex:01a15ca9-f939-7603-acb5-01c6b02f68e2",
        "--network","none","--user","0:0","--memory","1g","--memory-swap","1g","--cpus","1",
        "--pids-limit","128","--cap-drop","ALL","--security-opt","no-new-privileges","--entrypoint","sleep",image,"infinity"]
    save(out/"registration.json",{"image":image,"argv":["docker",*argv],"producer_sha256":sha(__file__),
        "readback_sha256":sha(readback/"result.json"),"scope":"Actual nonfunctional writable cache probes only; not a repair or resource-admission result.","client_model_calls":0,"paid_ready":False})
    try:
        cid=docker(*argv).stdout.decode().strip();assert re.fullmatch("[0-9a-f]{64}",cid)
        docker("start",cid);before=json.loads(docker("inspect",cid).stdout)[0];save(out/"runtime-before.json",before)
        assert before["Image"]==image and before["Id"]==cid and before["Mounts"]==[]
        assert before["Config"]["User"]=="0:0" and not before["HostConfig"]["ReadonlyRootfs"] and before["HostConfig"]["NetworkMode"]=="none"
        run=docker("exec",cid,"python3","-I","-B","-c",CODE)
        (out/"probe.stdout").write_bytes(run.stdout);(out/"probe.stderr").write_bytes(run.stderr)
        found=json.loads(run.stdout)
        assert found["euid"]==0 and int(found["cap_eff"],16)==0 and len(found["entries"])==4
        assert all(row["opened_for_write"] and row["uid"]==0 for row in found["entries"].values())
        save(out/"runtime-after.json",json.loads(docker("inspect",cid).stdout)[0])
        save(out/"result.json",{"complete":True,"image":image,"actual_uid":found["euid"],"actual_cap_eff":found["cap_eff"],
            "write_open_successes":sum(row["opened_for_write"] for row in found["entries"].values()),"write_open_population":len(found["entries"]),
            "raw_sha256":sha(out/"probe.stdout"),"client_model_calls":0,"paid_ready":False,
            "scope":"Four actual cache write opens/creates succeeded at uid0 with CapEff0; private functional controls pending."})
        print(json.dumps({"task":identity,"image":image,"write_opens":len(found["entries"]),"complete":True,"paid_ready":False}),flush=True)
    finally:
        if cid:
            actual=json.loads(docker("inspect",cid).stdout)[0]
            assert actual["Id"]==cid and actual["Image"]==image and actual["Name"]=="/"+name
            docker("rm","-f",cid);absent=docker("container","inspect",cid,check=False)
            assert absent.returncode==1 and cid.encode() in absent.stderr and b"No such" in absent.stderr
            save(out/"cleanup.json",{"complete":True,"container":cid,"returncode":absent.returncode,"stderr_sha256":hashlib.sha256(absent.stderr).hexdigest()})
if __name__=="__main__":main()
