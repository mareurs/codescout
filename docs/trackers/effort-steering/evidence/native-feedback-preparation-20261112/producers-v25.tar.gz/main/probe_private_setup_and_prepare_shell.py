"""Read-only owned image probes precede generic original-record shell preparation."""
from pathlib import Path
import hashlib,json,re,subprocess,sys,uuid
sys.dont_write_bytecode=True
sys.path.insert(0,"/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
import feedback_private_commands as planner
BASE=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
IDS=("DioxusLabs__dioxus-5384","nearai__ironclaw-6724")
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):
    with Path(path).open("x") as stream:json.dump(value,stream,sort_keys=True,indent=2)
def docker(*args):
    run=subprocess.run(["docker",*args],capture_output=True,text=True,timeout=180)
    if run.returncode:raise RuntimeError(str(args)+": "+run.stderr[-1200:])
    return run.stdout
CODE="""import json,subprocess,sys
packages,programs=json.loads(sys.argv[1]),json.loads(sys.argv[2])
result={"packages":{},"programs":[]}
fmt=chr(36)+"{Status}"+chr(9)+chr(36)+"{Version}"+chr(10)
for name in packages:
    p=subprocess.run(["dpkg-query","-W","-f="+fmt,name],capture_output=True,text=True,timeout=30)
    result["packages"][name]={"returncode":p.returncode,"stdout":p.stdout,"stderr":p.stderr}
for spec in programs:
    p=subprocess.run(spec["argv"],cwd=spec["cwd"],capture_output=True,text=True,timeout=60)
    result["programs"].append({**spec,"returncode":p.returncode,"stdout":p.stdout,"stderr":p.stderr})
print(json.dumps(result,sort_keys=True))
"""
def main():
    assert Path(__file__).stat().st_mode & 0o222 == 0
    for identity in IDS:
        root=BASE/identity
        common=root/"common-preparation-v1"
        original=root/"private-structure-v1/original-record.json"
        record=json.loads(original.read_bytes())
        image=json.loads((common/"registration.json").read_bytes())["image"]
        packages=set()
        for command in record.get("rebuild_cmds") or []:
            for group in planner._literal_shell_groups(command):
                if group[:2]==["apt-get","install"]:
                    packages.update(word for word in group[2:] if not word.startswith("-"))
        programs=[{"argv":["cargo","--version"],"cwd":"/testbed"},
                  {"argv":["rustc","--version"],"cwd":"/testbed"}]
        if packages:programs.append({"argv":["pkg-config","--version"],"cwd":"/testbed"})
        if any("linker=clang" in value for value in (record.get("rebuild_cmds") or [])):
            programs += [{"argv":["clang","--version"],"cwd":"/testbed"},
                         {"argv":["/usr/bin/mold","--version"],"cwd":"/testbed"}]
        prep=json.loads((common/"preparation.json").read_bytes())
        descriptor=prep.get("public_build_inputs")
        if descriptor and descriptor["dependency_dirs"]:
            relative=Path(descriptor["dependency_dirs"][0]).parent.as_posix()
            programs += [{"argv":["node","--version"],"cwd":"/testbed/"+relative},
                         {"argv":["corepack","--version"],"cwd":"/testbed/"+relative},
                         {"argv":["pnpm","--version"],"cwd":"/testbed/"+relative}]
        out=root/"private-setup-probe-v1";out.mkdir(mode=0o700)
        image_row=json.loads(docker("image","inspect",image))[0]
        assert image_row["Id"]==image and not image_row["Config"].get("Volumes")
        save(out/"image.json",image_row)
        name="ep-private-setup-"+uuid.uuid4().hex
        argv=["create","--name",name,"--label","effort-feedback-owner=codex:01a15ca9-f939-7603-acb5-01c6b02f68e2",
            "--network","none","--read-only","--user","0:0","--memory","1g","--memory-swap","1g",
            "--cpus","1","--pids-limit","128","--cap-drop","ALL","--security-opt","no-new-privileges",
            "--tmpfs","/tmp:rw,exec,nosuid,nodev,size=128m,mode=1777",
            "--entrypoint","sleep",image,"infinity"]
        save(out/"registration.json",{"image":image,"argv":["docker",*argv],
            "producer_sha256":sha(__file__),"planner_sha256":sha(planner.__file__),
            "record_sha256":sha(original),"packages":sorted(packages),"programs":programs,
            "scope":"Read-only base-image package/version probes and command preparation; not private test execution.",
            "client_model_calls":0,"paid_ready":False})
        cid=None
        try:
            cid=docker(*argv).strip();assert re.fullmatch(r"[0-9a-f]{64}",cid)
            docker("start",cid)
            before=json.loads(docker("inspect",cid))[0];save(out/"runtime-before.json",before)
            assert before["Image"]==image and before["HostConfig"]["ReadonlyRootfs"] is True
            run=subprocess.run(["docker","exec","-w","/testbed",cid,"python3","-I","-B","-c",CODE,
                json.dumps(sorted(packages)),json.dumps(programs)],capture_output=True,text=True,timeout=900)
            (out/"probe.stdout").write_text(run.stdout);(out/"probe.stderr").write_text(run.stderr)
            save(out/"probe-command.json",{"returncode":run.returncode,"stdout_sha256":sha(out/"probe.stdout"),
                "stderr_sha256":sha(out/"probe.stderr")})
            assert run.returncode==0
            result=json.loads(run.stdout);versions={}
            for package,value in result["packages"].items():
                assert value["returncode"]==0
                status,version=value["stdout"].strip().split(chr(9),1)
                assert status=="install ok installed" and version
                versions[package]=version
            assert all(row["returncode"]==0 and row["stdout"].strip() for row in result["programs"])
            bootstrap={"image":image,"apt_packages":versions} if packages else None
            plan=planner.prepare_shell_record(record,image=image,bootstrap=bootstrap)
            assert all(plan["record"][key]==record[key] for key in record.keys()-{"rebuild_cmds","test_cmds"})
            save(out/"prepared-plan.json",plan)
            save(out/"runtime-after.json",json.loads(docker("inspect",cid))[0])
            save(out/"result.json",{"source_image":image,"package_versions":versions,"programs":result["programs"],
                "original_record_sha256":sha(original),"prepared_plan_sha256":sha(out/"prepared-plan.json"),
                "original_labels_assertions_parser_and_print_unchanged":True,
                "base_image_command_preparation_complete":True,"client_model_calls":0,"paid_ready":False,
                "scope":"Final private derivative must rebind image/version evidence; no private functional control yet."})
            print(json.dumps({"task":identity,"packages_probed":len(versions),"programs_probed":len(result["programs"]),
                "prepared":True,"client_model_calls":0,"paid_ready":False}),flush=True)
        finally:
            if cid:
                observed=json.loads(docker("inspect",cid))[0]
                assert observed["Id"]==cid and observed["Image"]==image and observed["Name"]=="/"+name
                docker("rm","-f",cid)
                absent=subprocess.run(["docker","inspect",cid],capture_output=True,text=True,timeout=60)
                assert absent.returncode==1 and cid in absent.stderr and "no such" in absent.stderr.lower()
                save(out/"cleanup.json",{"container":cid,"complete":True,"returncode":absent.returncode,
                    "stderr_sha256":hashlib.sha256(absent.stderr.encode()).hexdigest()})
if __name__=="__main__":main()
