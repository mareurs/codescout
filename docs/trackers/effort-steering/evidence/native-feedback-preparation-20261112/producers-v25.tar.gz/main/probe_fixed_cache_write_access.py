"""Compare actual write opens under capability-dropped users; a readonly os.access proxy is insufficient."""
from pathlib import Path
import hashlib,json,re,subprocess,sys,uuid
BASE=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
CODE="""import json,os,stat,uuid
from pathlib import Path
result={"euid":os.geteuid(),"entries":{}}
for name in ("/testbed/target","/testbed/target/debug","/testbed/target/debug/.cargo-lock","/usr/local/cargo"):
    path=Path(name);s=path.stat();row={"uid":s.st_uid,"gid":s.st_gid,"mode":oct(stat.S_IMODE(s.st_mode))}
    target=path/(".effort-write-probe-"+uuid.uuid4().hex) if path.is_dir() else path
    try:
        fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600) if path.is_dir() else os.open(target,os.O_WRONLY)
        os.close(fd)
        if path.is_dir():target.unlink()
        row["opened_for_write"]=True
    except OSError as exc:row.update(opened_for_write=False,errno=exc.errno,error=str(exc))
    result["entries"][name]=row
print(json.dumps(result,sort_keys=True))
"""
def save(path,value):
    with path.open("x") as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write(chr(10))
def main():
    assert Path(__file__).stat().st_mode & 0o222==0
    root=BASE/"DioxusLabs__dioxus-5384"/"common-clean-image-v1";image=json.loads((root/"result.json").read_bytes())["image"]
    out=root/"actual-cache-write-probe-v1";out.mkdir()
    rows=[]
    for user in ("0:0","1000:1000"):
        name="ep-cache-write-"+uuid.uuid4().hex
        args=["docker","run","--rm","--pull=never","--name",name,"--network","none","--user",user,
            "--memory","1g","--memory-swap","1g","--cpus","1","--pids-limit","128","--cap-drop","ALL",
            "--security-opt","no-new-privileges","--label","effort-feedback-owner=codex:01a15ca9-f939-7603-acb5-01c6b02f68e2",
            "--entrypoint","python3",image,"-I","-B","-c",CODE]
        p=subprocess.run(args,capture_output=True,text=True,timeout=120)
        save(out/("user-"+user.replace(":","-")+".json"),{"argv":args,"returncode":p.returncode,"stdout":p.stdout,"stderr":p.stderr})
        assert p.returncode==0;found=json.loads(p.stdout);rows.append(found)
        absent=subprocess.run(["docker","container","inspect",name],capture_output=True,text=True,timeout=30)
        assert absent.returncode==1 and name in absent.stderr and "No such" in absent.stderr
    assert rows[0]["euid"]==0 and rows[1]["euid"]==1000
    assert all(not row["opened_for_write"] and row["errno"]==13 for row in rows[0]["entries"].values())
    assert all(row["opened_for_write"] for row in rows[1]["entries"].values())
    save(out/"result.json",{"complete":True,"image":image,"users":rows,"owned_cleanup":True,
        "producer_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),"client_model_calls":0,"paid_ready":False,
        "scope":"Actual open/create pair under writable disposable overlays; immutable image source unchanged. Rootless capability/mode causation, not functional calibration."})
    print(json.dumps({"complete":True,"root_write_opens":0,"uid1000_write_opens":4,"image":image}),flush=True)
if __name__=="__main__":main()
