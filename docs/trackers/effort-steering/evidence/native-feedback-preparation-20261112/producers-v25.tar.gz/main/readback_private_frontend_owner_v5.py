"""Complete source and final-version readback on the private frontend-cache owner image."""
from pathlib import Path
import hashlib,json,os,re,stat,subprocess,sys,uuid
sys.dont_write_bytecode=True
WORK=Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from evaluator_entry import _entries,_input_digest,verify_package
import feedback_private_commands as planner
import public_build_inputs as build_inputs
BASE=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
IDS=("nearai__ironclaw-6724",)
INVENTORY="""import hashlib,json,os,stat
from pathlib import Path
root=Path('/testbed');result={}
for parent,dirs,files in os.walk(root,followlinks=False):
    base=Path(parent)
    if base==root:dirs[:]=[name for name in dirs if name not in ('.git','target')]
    for name in dirs+files:
        path=base/name;mode=path.lstat().st_mode;relative=path.relative_to(root).as_posix()
        if stat.S_ISLNK(mode):row={'kind':'link','target':os.readlink(path)}
        elif stat.S_ISDIR(mode):row={'kind':'directory','mode':stat.S_IMODE(mode)}
        elif stat.S_ISREG(mode):row={'kind':'file','mode':stat.S_IMODE(mode),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
        else:raise ValueError('unsupported source type')
        result[relative]=row
print(json.dumps(result,sort_keys=True))
"""
PROBE="""import json,subprocess,sys
packages,programs=json.loads(sys.argv[1]),json.loads(sys.argv[2]);result={"packages":{},"programs":[]}
fmt=chr(36)+"{Status}"+chr(9)+chr(36)+"{Version}"+chr(10)
for name in packages:
    p=subprocess.run(["dpkg-query","-W","-f="+fmt,name],capture_output=True,text=True,timeout=30)
    result["packages"][name]={"returncode":p.returncode,"stdout":p.stdout,"stderr":p.stderr}
for spec in programs:
    p=subprocess.run(spec["argv"],cwd=spec["cwd"],capture_output=True,text=True,timeout=60)
    result["programs"].append({**spec,"returncode":p.returncode,"stdout":p.stdout,"stderr":p.stderr})
print(json.dumps(result,sort_keys=True))
"""
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):
    with Path(path).open("x") as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write(chr(10))
def docker(*args,check=True):
    run=subprocess.run(["docker",*args],capture_output=True,timeout=900)
    if check and run.returncode:raise RuntimeError(repr((args,run.returncode,run.stderr[-4000:])))
    return run
def main():
    assert Path(__file__).stat().st_mode & 0o222==0
    identity=sys.argv[1];assert identity in IDS
    root=BASE/identity;built=root/"private-cache-owner-image-v5";common=root/"common-preparation-v1"
    image=json.loads((built/"result.json").read_bytes())["image"]
    registered=json.loads((built/"registration.json").read_bytes())
    assert sha(built/"context/Dockerfile")==registered["recipe_sha256"]
    public=common/"public-source";expected=_entries(public);before=_input_digest(public)
    assert before==registered["source_sha256"] and not any(name.split("/")[0] in (".git","target") for name in expected)
    prior=json.loads((root/"private-setup-probe-v1/result.json").read_bytes())
    programs=[{"argv":row["argv"],"cwd":row["cwd"]} for row in prior["programs"]]
    packages=sorted(prior["package_versions"])
    out=built/"public-readback-v1";out.mkdir(mode=0o700)
    name="ep-final-readback-"+uuid.uuid4().hex;cid=None
    argv=["create","--name",name,"--label","effort-feedback-owner=codex:01a15ca9-f939-7603-acb5-01c6b02f68e2",
        "--read-only","--network","none","--user","0:0","--memory","1g","--memory-swap","1g","--cpus","1",
        "--pids-limit","128","--cap-drop","ALL","--security-opt","no-new-privileges",
        "--tmpfs","/tmp:rw,exec,nosuid,nodev,size=128m,mode=1777","--entrypoint","sleep",image,"infinity"]
    save(out/"registration.json",{"image":image,"argv":["docker",*argv],"producer_sha256":sha(__file__),
        "public_source_sha256":before,"build_registration_sha256":sha(built/"registration.json"),
        "planner_sha256":sha(planner.__file__),"inventory_exclusions":[".git","target"],
        "scope":"All lexical public source entries and final immutable-image package/program versions. Build cache intentionally excluded, not claimed empty.",
        "client_model_calls":0,"paid_ready":False})
    try:
        cid=docker(*argv).stdout.decode().strip();assert re.fullmatch("[0-9a-f]{64}",cid)
        docker("start",cid)
        observed=json.loads(docker("inspect",cid).stdout)[0];save(out/"runtime-before.json",observed)
        assert observed["Id"]==cid and observed["Image"]==image and observed["HostConfig"]["ReadonlyRootfs"]
        assert observed["HostConfig"]["NetworkMode"]=="none" and observed["Mounts"]==[]
        assert observed["HostConfig"]["Tmpfs"]=={"/tmp":"rw,exec,nosuid,nodev,size=128m,mode=1777"}
        run=docker("exec",cid,"python3","-I","-B","-c",INVENTORY)
        (out/"inventory.stdout").write_bytes(run.stdout);(out/"inventory.stderr").write_bytes(run.stderr)
        actual=json.loads(run.stdout)
        differences={key:{"expected":expected.get(key),"actual":actual.get(key)} for key in expected.keys()|actual.keys() if expected.get(key)!=actual.get(key)}
        save(out/"differences.json",differences)
        assert not differences,("public-source-differences",len(differences))
        run=docker("exec","-w","/testbed",cid,"python3","-I","-B","-c",PROBE,json.dumps(packages),json.dumps(programs))
        (out/"probe.stdout").write_bytes(run.stdout);(out/"probe.stderr").write_bytes(run.stderr)
        found=json.loads(run.stdout);versions={}
        for package,row in found["packages"].items():
            assert row["returncode"]==0
            status,version=row["stdout"].strip().split(chr(9),1);assert status=="install ok installed" and version
            versions[package]=version
        assert versions==prior["package_versions"]
        assert all(row["returncode"]==0 and row["stdout"].strip() for row in found["programs"])
        original=root/"private-structure-v1/original-record.json";record=json.loads(original.read_bytes())
        bootstrap={"image":image,"apt_packages":versions} if packages else None
        prepared=planner.prepare_shell_record(record,image=image,bootstrap=bootstrap)
        save(out/"prepared-plan.json",prepared)
        descriptor=json.loads((common/"preparation.json").read_bytes()).get("public_build_inputs")
        if descriptor is not None:
            descriptor["image"]=image
            assert build_inputs.generated_digest(Path(descriptor["seed"]["path"]))==descriptor["seed"]["sha256"]
        else:
            descriptor={"schema":"public-build-inputs-v1","image":image,"seed":None,"dependency_dirs":[],"cache_mounts":[]}
        admitted=build_inputs.validate_descriptor(descriptor,public,image)
        save(out/"public-build-inputs.json",descriptor)
        save(out/"runtime-after.json",json.loads(docker("inspect",cid).stdout)[0])
        assert _input_digest(public)==before and sha(planner.__file__)==json.loads((out/"registration.json").read_bytes())["planner_sha256"]
        save(out/"result.json",{"complete":True,"image":image,"source_sha256":before,"entries_checked":len(expected),
            "observed_entries":len(actual),"differences":0,"inventory_exclusions":[".git","target"],
            "packages":versions,"programs":found["programs"],"prepared_plan_sha256":sha(out/"prepared-plan.json"),
            "descriptor_sha256":sha(out/"public-build-inputs.json"),"fingerprint":admitted["fingerprint"],"source_unchanged":True,
            "source_onboarding_reused":True,"additional_onboarding_calls":0,"additional_index_calls":0,
            "client_model_calls":0,"paid_ready":False,"scope":"Final source/version/command readback only; no actor, functional-control or scientific success claim."})
        print(json.dumps({"task":identity,"image":image,"entries":len(expected),"source_parity":True,"private_controls_pending":True}),flush=True)
    finally:
        if cid:
            observed=json.loads(docker("inspect",cid).stdout)[0]
            assert observed["Id"]==cid and observed["Image"]==image and observed["Name"]=="/"+name
            docker("rm","-f",cid)
            absent=docker("container","inspect",cid,check=False)
            assert absent.returncode==1 and b"No such" in absent.stderr and cid.encode() in absent.stderr
            save(out/"cleanup.json",{"complete":True,"container":cid,"returncode":absent.returncode,
                "stderr_sha256":hashlib.sha256(absent.stderr).hexdigest()})
if __name__=="__main__":main()
