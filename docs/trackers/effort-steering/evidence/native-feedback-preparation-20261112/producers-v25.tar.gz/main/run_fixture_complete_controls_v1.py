"""Run identical public compile scopes on original actor baseline and private complete reference."""
from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
WORK=Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from executor import execute_observation
from campaign_resources import measure_host
from receipts import input_digest
from public_build_inputs import validate_descriptor
from feedback_admission import verify_reference_controls
BASE=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/fixture-complete-controls-v1")
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):
    with path.open("x") as stream:
        json.dump(value,stream,sort_keys=True,indent=2);stream.write("\n")
def main():
    assert Path(__file__).stat().st_mode & 0o222==0
    identity=sys.argv[1]
    population=json.loads((BASE/"preparation.json").read_bytes())
    assert identity in population["tasks"]
    parent=BASE/identity;prepared=json.loads((parent/"preparation.json").read_bytes())
    assert prepared["actor_input_role"]=="original-public-baseline" and prepared["contains_private_assertions"]
    bindings=dict(prepared["bindings"]);code=dict(prepared["source_bindings"])
    code[str(Path(__file__).absolute())]=sha(__file__)
    assert all(sha(path)==digest for path,digest in {**bindings,**code}.items())
    task=prepared["task"];public=task["backend"]["public"]
    reference=json.loads(Path(prepared["reference_inputs"]["path"]).read_bytes())
    sources={"baseline":Path(task["source"]),"reference":Path(reference["reference"])}
    digests={role:input_digest(source) for role,source in sources.items()}
    assert digests=={"baseline":task["source_sha256"],"reference":reference["reference_sha256"]}
    out=parent/"runtime";out.mkdir(mode=0o700)
    host=measure_host(WORK,"/tmp");save(out/"host-before.json",host)
    assert host["root_free"]>=80*1024**3 and host["mem_available"]>=16*1024**3
    assert host["tmp_free"]>=4*1024**3 and host["tmp_exec"]
    proof={"baseline":[],"reference":{"source":str(sources["reference"]),
        "source_sha256":digests["reference"],"record_sha256":bindings[
            json.loads(Path(task["backend"]["private"]["config"]).read_bytes())["record"]],
        "inputs":prepared["reference_inputs"],"commands":[]}}
    rows=[]
    for role,source in sources.items():
        validate_descriptor(public["public_build_inputs"],source,public["image"])
        for index,command in enumerate(public["public_checks"]):
            name="ordinary" if index==0 else "broader";directory=out/role/name;directory.mkdir(parents=True)
            request={"id":"public-"+name,"run_id":"full-reference-v1-"+identity+"-"+role+"-"+name,
                "phase":"challenge","kind":"verification","image":public["image"],**command,
                "production_files":sorted(path.relative_to(source).as_posix() for path in source.rglob("*")),
                "timeout_s":900,"max_log_bytes":67108864,"execution_profile":"cargo-v3",
                "public_build_inputs":public["public_build_inputs"]}
            registration=directory/"registration.json";result=directory/"result.json"
            save(registration,{"request":request,"source":str(source),"source_digest":digests[role],
                "source_bindings":code,"source_role":role,"paid_ready":False})
            print(json.dumps({"task":identity,"role":role,"starting":name}),flush=True)
            try:
                facts=execute_observation(request,source,directory/"commands")
                row={"complete":facts["complete"],"resource_valid":facts["resource_valid"],
                    "exit_code":facts["exit_code"],"receipt":facts}
            except BaseException as exc:
                row={"complete":False,"reason":type(exc).__name__+": "+str(exc)}
            save(result,row)
            rows.append({"role":role,"kind":name,**{k:v for k,v in row.items() if k!="receipt"}})
            print(json.dumps(rows[-1]),flush=True)
            if not (row.get("complete") is True and row.get("resource_valid") is True
                    and type(row.get("exit_code")) is int and row["exit_code"]==0):
                save(out/"stopped.json",{"rows":rows,"client_model_calls":0,"paid_ready":False})
                return 1
            for path in (registration,result):bindings[str(path)]=sha(path)
            entry={"registration":{"path":str(registration),"sha256":sha(registration)},
                   "result":{"path":str(result),"sha256":sha(result)}}
            (proof["baseline"] if role=="baseline" else proof["reference"]["commands"]).append(entry)
    registration={"tasks":{identity:task},"bindings":bindings};evidence={identity:proof}
    verified=verify_reference_controls(registration,evidence)
    assert all(input_digest(source)==digests[role] for role,source in sources.items())
    assert all(sha(path)==digest for path,digest in {**bindings,**code}.items())
    save(out/"registration.json",registration);save(out/"evidence.json",evidence)
    save(out/"result.json",{"schema":"fixture-complete-reference-controls-v1","task":identity,
        "rows":rows,"verified":verified,"source_bindings":code,"actor_source_unchanged":True,
        "client_model_calls":0,"paid_ready":False})
    print(json.dumps({"task":identity,"verified_commands":len(rows),"terminal":True,"paid_ready":False}),flush=True)
    return 0
if __name__=="__main__":
    raise SystemExit(main())
