"""Independently exercise the real admission reader on exact-source positive controls and retained negative reference."""
from pathlib import Path
import hashlib,json,subprocess,sys
sys.dont_write_bytecode=True
WORK=Path("/home/marius/.codex/worktrees/2aa6/codescout")
MAIN=Path("/home/marius/work/claude/codescout")
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from receipts import input_digest
from paid_admission import verify_public_commands
from public_build_inputs import validate_descriptor
BASE=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def main():
    assert Path(__file__).stat().st_mode & 0o222==0
    identity=sys.argv[1];assert identity in ("DioxusLabs__dioxus-5384","nearai__ironclaw-6724")
    root=BASE/identity;parent="common-clean-image-v3" if identity=="DioxusLabs__dioxus-5384" else "private-cache-owner-image-v5"
    descriptor=json.loads((root/parent/"public-readback-v1/public-build-inputs.json").read_bytes())
    image=descriptor["image"];controls=[];containers=set();source_bindings=set()
    for case in ("baseline","reference"):
        directory=root/("final-public-"+case+"-v1")
        source=root/"common-preparation-v1/public-source" if case=="baseline" else root/"private-inputs-reference-v1/reference"
        digest=input_digest(source);admitted=validate_descriptor(descriptor,source,image)
        rows=[];bindings={};commands=[]
        for kind in ("ordinary","broader"):
            declared=directory/kind/"registration.json";result=directory/kind/"result.json"
            registration=json.loads(declared.read_bytes());actual=json.loads(result.read_bytes())
            assert registration["source"]==str(source) and registration["source_digest"]==digest
            request=registration["request"]
            assert request["image"]==image and request["execution_profile"]=="cargo-v3" and request["public_build_inputs"]==descriptor
            for path,value in registration["source_bindings"].items():
                assert sha(path)==value
                source_bindings.add(path)
            row={"registration":{"path":str(declared),"sha256":sha(declared)},
                 "result":{"path":str(result),"sha256":sha(result)}}
            rows.append(row);bindings.update({str(declared):sha(declared),str(result):sha(result)})
            commands.append({key:request[key] for key in ("argv","cwd","test_files")})
            command_root=directory/kind/"commands"/request["id"]
            before=json.loads((command_root/"container-before.json").read_bytes())
            after=json.loads((command_root/"container-after.json").read_bytes())
            cid=before["Id"];assert after["Id"]==cid and cid not in containers and before["Image"]==after["Image"]==image
            containers.add(cid)
            absent=subprocess.run(["docker","container","inspect",cid],capture_output=True,timeout=60)
            assert absent.returncode==1 and cid.encode() in absent.stderr and b"no such" in absent.stderr.lower()
            controls.append({"source_case":case,"kind":kind,"source_sha256":digest,"argv":request["argv"],
                "complete":actual["complete"],"resource_valid":actual["resource_valid"],"exit_code":actual["exit_code"],
                "registration_sha256":sha(declared),"result_sha256":sha(result),"container":cid,"fresh_absence":True})
        public={"image":image,"execution_profile":"cargo-v3","public_build_inputs":descriptor,"public_checks":commands}
        reg={"bindings":bindings,"tasks":{identity:{"source":str(source),"source_sha256":digest,"backend":{"public":public}}}}
        evidence={identity:rows}
        if identity=="nearai__ironclaw-6724" and case=="reference":
            reason=None
            try:verify_public_commands(reg,evidence)
            except ValueError as exc:reason=str(exc)
            assert reason=="public command did not complete successfully",reason
            controls[-1]["actual_admission_rejected"]=reason
        else:
            verified=verify_public_commands(reg,evidence)
            assert verified[identity]=={"verified_commands":2,"source_sha256":digest}
        assert input_digest(source)==digest
    assert len(containers)==4
    packet={"schema":"exact-source-public-controls-audit-v1","task":identity,"image":image,"controls":controls,
        "source_binding_files_reopened":len(source_bindings),"positive_qualification":identity=="DioxusLabs__dioxus-5384",
        "negative_reference_gate_observed":identity=="nearai__ironclaw-6724",
        "producer_sha256":sha(__file__),"client_model_calls":0,"paid_ready":False,
        "scope":"Actual current paid-admission public-command reader, exact source/profile/dependency inputs, raw receipt/generated output reopens and fresh cleanup. Negative compiler reference is retained and must not authorize paid work."}
    prefix="dioxus" if identity=="DioxusLabs__dioxus-5384" else "ironclaw"
    output=MAIN/("docs/trackers/effort-steering/evidence/native-feedback-preparation-20261112/"+prefix+"-final-public-v1-control-audit.json")
    with output.open("x") as stream:json.dump(packet,stream,sort_keys=True,indent=2);stream.write(chr(10))
    print(json.dumps(packet),flush=True)
if __name__=="__main__":main()
