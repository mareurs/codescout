"""Exercise real observation producer/readback; frontend component, not repair efficacy."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True
sys.path.insert(0,"/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
import executor
import public_build_inputs as inputs
parser = argparse.ArgumentParser()
parser.add_argument("--label",required=True)
parser.add_argument("--expect-invalid",action="store_true")
args = parser.parse_args()
assert args.label.replace("-","").isalnum()
base = Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/nearai__ironclaw-6724")
prior = base/"pnpm-offline-write-probe-v5"
source = prior/"E-source-ro-node-rw-pnpm-state-rw/input"
seed = prior/"cache-seed"
image = "sha256:28aa0e0f6f9cd069363ec49448bf7e3dd1d19e3fcdf3629a6f92d5d47c542de1"
out = base/args.label
out.mkdir()
descriptor = {"schema":"public-build-inputs-v1","image":image,
              "seed":{"path":str(seed),"sha256":inputs.generated_digest(seed)},
              "dependency_dirs":["crates/ironclaw_webui/frontend/node_modules"],
              "cache_mounts":[{"seed_relative":p,"destination":"/bench/public-dependencies/"+p}
                              for p in ("pnpm-store","pnpm-cache","pnpm-state")]}
worker = """
import json,pathlib,subprocess,sys
root=pathlib.Path("/build")
def sample():
    base=pathlib.Path("/sys/fs/cgroup")
    return {p:(base/p).read_text() for p in ("memory.events","memory.max","cpu.max","pids.max")}
samples=[sample()]
codes=[]
for argv in (["corepack","pnpm","install","--frozen-lockfile"],["corepack","pnpm","exec","vite","build","--outDir","/build/frontend-dist","--emptyOutDir"]):
    code=subprocess.run(argv).returncode
    codes.append(code)
    if code: break
samples.append(sample())
(root/"resource-control.json").write_text(json.dumps({"samples":samples,"codes":codes}))
sys.exit(next((v for v in codes if v),0))
"""
request={"id":"component","run_id":args.label,"phase":"repair","image":image,
         "argv":["python3","-c",worker],"cwd":"crates/ironclaw_webui/frontend","kind":"observation",
         "timeout_s":180,"max_log_bytes":16777216,"test_files":["Cargo.toml"],
         "production_files":["crates/ironclaw_webui/build.rs"],"execution_profile":"cargo-v3",
         "public_build_inputs":descriptor}
(out/"request.json").write_text(json.dumps(request,sort_keys=True,indent=2))
try:
    result=executor.execute_observation(request,source,out/"observations")
except executor.ExecutionInvalid as exc:
    (out/"observed-invalid.json").write_text(json.dumps({"reason":exc.reason,"expected":args.expect_invalid}))
    print(json.dumps({"invalid_reason":exc.reason,"expected":args.expect_invalid}))
    if not args.expect_invalid: raise
else:
    assert not args.expect_invalid, result
    assert result["exit_code"]==0 and result["complete"] and result["resource_valid"]
    actual=json.loads((out/"observations/component/build/resource-control.json").read_bytes())
    assert actual["codes"]==[0,0] and len(actual["samples"])==2
    assert all("oom_kill 0" in r["memory.events"] for r in actual["samples"])
    (out/"result.json").write_text(json.dumps({"verified_receipt":result,"component":actual,
        "client_model_calls":0,"paid_ready":False,"scope":"Actual observation executor plus independent receipt; no full Cargo/native/private qualification."},sort_keys=True,indent=2))
    print(json.dumps(result,sort_keys=True))
