"""Reopen exact historical compile-control code bytes after unrelated native audit development."""
from pathlib import Path
import hashlib,json,tarfile
MAIN=Path("/home/marius/work/claude/codescout")
WORK=Path("/home/marius/.codex/worktrees/2aa6/codescout")
EVIDENCE=MAIN/"docs/trackers/effort-steering/evidence"
CONTROL=EVIDENCE/"native-feedback-preparation-20261112/fixture-complete-controls-v1-audit.json"
SOURCE=EVIDENCE/"native-feedback-baseline-20261111/task5-complete-reference-admission-v1.tar.gz"
PRODUCERS=EVIDENCE/"native-feedback-preparation-20261112/producers-v22.tar.gz"
def sha(data):
    return hashlib.sha256(data).hexdigest()
def main():
    assert Path(__file__).stat().st_mode & 0o222==0
    expected={SOURCE:"be685e4cd09611a5f0a4f876aac2d83b637936588f27ae9dcbf5df918540c533",
              PRODUCERS:"35061c703d11cfb2d67b53e7dde574ee7639965da1430712efc7f5edc94cacd7"}
    archives={}
    for path,digest in expected.items():
        assert path.is_file() and not path.is_symlink() and sha(path.read_bytes())==digest
        with tarfile.open(path,"r:gz") as archive:
            members=archive.getmembers()
            assert len({m.name for m in members})==len(members) and all(m.isfile() for m in members)
            archives[path]={m.name:sha(archive.extractfile(m).read()) for m in members}
    audit=json.loads(CONTROL.read_bytes());bindings={}
    base=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/fixture-complete-controls-v1")
    for identity in audit["tasks"]:
        result=json.loads((base/identity/"runtime/result.json").read_bytes())
        for name,digest in result["source_bindings"].items():
            assert bindings.get(name,digest)==digest
            bindings[name]=digest
    rows=[];changed=[]
    for name,digest in sorted(bindings.items()):
        path=Path(name)
        if path.is_relative_to(WORK):
            archive=SOURCE;member=path.relative_to(WORK).as_posix()
        else:
            assert path.is_relative_to(MAIN/".superpowers/sdd/2026-11-11-native-public-feedback-transfer")
            archive=PRODUCERS;member="main/"+path.name
        assert archives[archive][member]==digest
        current=sha(path.read_bytes())
        if current!=digest:changed.append(name)
        rows.append({"original_path":name,"sha256":digest,"archive":str(archive),"member":member})
    assert len(rows)==audit["source_binding_files_reopened"]
    assert all(sha(Path(name).read_bytes())==digest for name,digest in audit["evidence_bindings"].items())
    packet={"schema":"qualified-control-code-custody-v1",
        "control_audit":{"path":str(CONTROL),"sha256":sha(CONTROL.read_bytes())},
        "archives":[{"path":str(path),"sha256":digest} for path,digest in expected.items()],
        "code_inputs_reopened":len(rows),"inputs":rows,"changed_live_inputs":changed,
        "producer_sha256":sha(Path(__file__).read_bytes()),"client_model_calls":0,"paid_ready":False,
        "scope":"Historical measured code and runtime proofs remain byte-bound in preserved capsules. Later native/controller audit development does not rewrite or re-run these compile controls. This is custody, not current author CLI qualification or efficacy."}
    output=EVIDENCE/"native-feedback-preparation-20261112/fixture-complete-controls-v1-code-custody.json"
    with output.open("x") as stream:json.dump(packet,stream,sort_keys=True,indent=2);stream.write("\n")
    print(json.dumps({key:value for key,value in packet.items() if key!="inputs"}),flush=True)
if __name__=="__main__":
    main()
