import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE = Path(__file__).parent / "blind-review-delivery-v1"
OUTPUT = Path(__file__).parents[3] / "docs/trackers/effort-steering/evidence/native-feedback-preparation-20261112/blind-review-qualification-v1.tar.gz"


def main():
    closure = json.loads((BASE / "qualification-closure.json").read_bytes())
    files = {}
    for path, expected in closure["bindings"].items():
        data = Path(path).read_bytes()
        if hashlib.sha256(data).hexdigest() != expected and Path(path).name == "test_feedback_assertion_review.py":
            # Recover only the newly inserted test, then require the original exact SHA.
            data = data.replace("    def test_original_capture_verifier_consumes_the_bound_review(self):\n        verify = importlib.import_module(\"feedback_assertion_audit\").verify_audit\n        proof = verify(self.descriptor, self.fixture.request, self.decision(),\n                       issue=\"Return two.\", protected_roots=[\"tests\"])\n        self.assertTrue(proof[\"terminal\"])\n        self.assertEqual(proof[\"status\"], \"clear\")\n        self.assertEqual(proof[\"method\"], \"blinded-independent-review\")\n".encode(), b"")
        assert hashlib.sha256(data).hexdigest() == expected, path
        files["source/" + expected + ".py"] = data
    for path in BASE.rglob("*"):
        if path.is_file():
            files["delivery/" + path.relative_to(BASE).as_posix()] = path.read_bytes()
    for case in closure["cases"]:
        opaque = case["opaque_id"]
        dispatch = json.loads((BASE / opaque / "dispatch.json").read_bytes())
        files["delivery/" + opaque + "/brief.txt"] = Path(dispatch["brief"]["path"]).read_bytes()
    registration = Path(closure["registration"]["path"])
    assert hashlib.sha256(registration.read_bytes()).hexdigest() == closure["registration"]["sha256"]
    files["registration.json"] = registration.read_bytes()
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    with OUTPUT.open("xb") as stream, tarfile.open(fileobj=stream, mode="w:gz") as archive:
        for name, data in sorted(files.items()):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o444
            archive.addfile(info, io.BytesIO(data))
    with tarfile.open(OUTPUT) as archive:
        assert {item.name: archive.extractfile(item).read() for item in archive} == files
    print(json.dumps({"path": str(OUTPUT), "members": len(files), "bytes": OUTPUT.stat().st_size,
                      "sha256": hashlib.sha256(OUTPUT.read_bytes()).hexdigest()}))


if __name__ == "__main__":
    main()
