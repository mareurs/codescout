"""Reopen both unchanged independent review messages through the extended live boundary."""
import hashlib
import json
from pathlib import Path
import sys
import tarfile

MAIN = Path("/home/marius/work/claude/codescout")
WORK = Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path.insert(0, str(WORK / "tools/effort_protocol"))
from feedback_assertion_audit import verify_audit
from evaluator_entry import _entries

DELIVERY = Path(__file__).parent / "blind-review-delivery-v1"
ARCHIVE = MAIN / "docs/trackers/effort-steering/evidence/native-feedback-preparation-20261112/blind-review-qualification-v1.tar.gz"
OUTPUT = ARCHIVE.with_name("blind-review-current-boundary-v2.json")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    assert Path(__file__).stat().st_mode & 0o222 == 0
    assert sha(ARCHIVE.read_bytes()) == "37f190b4c8a9cc83330ba10d0a4731f0fb9b2cf7451ecd0f28bb61af1c3063bc"
    with tarfile.open(ARCHIVE) as archive:
        historical = {member.name: archive.extractfile(member).read() for member in archive}
    assert len(historical) == 17
    closure = json.loads(historical["delivery/qualification-closure.json"])
    for path, expected in closure["bindings"].items():
        assert sha(historical["source/" + expected + ".py"]) == expected, path
    registration = json.loads(historical["registration.json"])
    rows = []
    for case in registration["cases"]:
        opaque = case["opaque_id"]
        delivery = DELIVERY / opaque
        for role in ("response", "dispatch", "decision"):
            assert (delivery / (role + ".json")).read_bytes() == historical["delivery/" + opaque + "/" + role + ".json"]
        decision = json.loads((delivery / "decision.json").read_bytes())
        descriptor = json.loads((Path(case["export"]) / "descriptor.json").read_bytes())
        manifest = json.loads(Path(descriptor["manifest"]).read_bytes())
        assert _entries(Path(case["export"]) / "review") == manifest["entries"]
        proof = verify_audit(descriptor, case["request"], decision, issue=case["issue"],
                             protected_roots=case["protected_roots"])
        assert proof["terminal"] and proof["status"] == case["expected"]
        rows.append({"opaque_id": opaque, "expected": case["expected"], "observed": proof["status"], "proof": proof})
    sources = [Path(__file__).absolute(), *[WORK / "tools/effort_protocol" / name for name in (
        "feedback_assertion_audit.py", "feedback_assertion_review.py", "evaluator_entry.py", "receipts.py",
        "native_campaign.py", "feedback_runner.py", "feedback_runtime_audits.py", "paid_admission.py")]]
    result = {"schema": "blind-review-current-boundary-v2", "historical_archive_sha256": sha(ARCHIVE.read_bytes()),
              "bindings": {str(path): sha(path.read_bytes()) for path in sources}, "cases": rows,
              "scope": "Same two fixed integrity controls and original reviewer messages, consumed by the current core verifier. No new reviewer/model/actor call. This is not actual16 NativeCLI qualification or repair efficacy.",
              "review_compute_cost": "unknown", "paid_ready": False}
    with OUTPUT.open("x") as stream:
        json.dump(result, stream, sort_keys=True, indent=2)
        stream.write("\n")
    print(json.dumps({"path": str(OUTPUT), "sha256": sha(OUTPUT.read_bytes()),
                      "cases": [{key: row[key] for key in ("opaque_id", "expected", "observed")} for row in rows]}))


if __name__ == "__main__":
    main()
