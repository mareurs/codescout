"""Apply the explicit omission policy to saved real native verification, without a new index."""
from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
sys.path.insert(0,"/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
import readiness
from native_executor import _public_digest
root=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/DioxusLabs__dioxus-5384/common-preparation-v1")
source=root/"project"
prep=json.loads((root/"preparation.json").read_bytes())
path=root/"index-coderank-v1/index-verification.json"
before=_public_digest(source,preserve_project_context=True)
assert before==prep["template_public_sha256"]
wire=json.loads(path.read_bytes())
try:
    readiness._verify_index(wire,source)
except readiness.ReadinessViolation as exc:
    default_refusal=str(exc)
else:
    raise AssertionError("Legacy empty-only policy unexpectedly admitted newline omissions")
result=readiness._verify_index(wire,source,omission_policy="ascii-whitespace-source-v1")
assert result["native_verdict"]=="incomplete"
assert result["expected_eligible_files"]==1060 and result["stored_files"]==1053
assert len(result["empty_missing_files"])==4 and len(result["whitespace_missing_files"])==3
assert all(row["bytes"]==1 for row in result["whitespace_missing_files"])
assert _public_digest(source,preserve_project_context=True)==before
value={"schema":"native-index-whitespace-policy-audit-v1","task":"DioxusLabs__dioxus-5384",
    "saved_actual_native_verification":{"path":str(path),"sha256":hashlib.sha256(path.read_bytes()).hexdigest()},
    "reader_sha256":hashlib.sha256(Path(readiness.__file__).read_bytes()).hexdigest(),
    "public_source_sha256":before,"source_unchanged":True,"additional_index_calls":0,"additional_onboarding_calls":0,
    "default_policy_refusal":default_refusal,"explicit_policy":"ascii-whitespace-source-v1","coverage":result,
    "client_model_calls":0,"paid_ready":False,
    "scope":"Readback of saved real native verifier with physical omitted source files; no new MCP/actor/CLI qualification."}
output=Path("/home/marius/work/claude/codescout/docs/trackers/effort-steering/evidence/native-feedback-preparation-20261112/dioxus-whitespace-policy-audit-v1.json")
with output.open("x") as stream:json.dump(value,stream,sort_keys=True,indent=2)
print(json.dumps(value,sort_keys=True))
