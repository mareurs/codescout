"""Freeze original acceptance and canonical test bytes, separately from the public actor template."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
sys.dont_write_bytecode=True
sys.path.insert(0,"/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from evaluator_entry import verify_package
from receipts import input_digest
import trusted_test_inputs as trusted
BASE=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112")
IDS=("DioxusLabs__dioxus-5384","nearai__ironclaw-6724")
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):
    with Path(path).open("x") as stream:json.dump(value,stream,sort_keys=True,indent=2)
def apply(source,patch,out):
    run=subprocess.run(["git","apply","--binary","--whitespace=nowarn",str(patch)],
        cwd=source,capture_output=True,timeout=60)
    (out.with_suffix(".stdout")).write_bytes(run.stdout)
    (out.with_suffix(".stderr")).write_bytes(run.stderr)
    save(out,{"returncode":run.returncode,"stdout_sha256":sha(out.with_suffix(".stdout")),
        "stderr_sha256":sha(out.with_suffix(".stderr"))})
    assert run.returncode==0
def main():
    assert Path(__file__).stat().st_mode & 0o222 == 0
    frozen=json.loads(Path("/var/tmp/ep11-01a15/private-controls/obscura/config.json").read_bytes())
    package=verify_package(frozen["package_root"],frozen["package_files"])
    sys.path.insert(0,str(package))
    import tasks
    for identity in IDS:
        root=BASE/identity;public=root/"common-preparation-v1/public-source"
        policy_path=root/"public-test-role-inventory-v1/policy.json";policy=json.loads(policy_path.read_bytes())
        original_path=root/"private-structure-v1/original-record.json";record=json.loads(original_path.read_bytes())
        metadata=json.loads((root/"registration.json").read_bytes())["task"]
        assert record["docker_image"]==metadata["image"]
        assert input_digest(public)==policy["source_sha256"]
        assert sha(policy["producer"]["path"])==policy["producer"]["sha256"]
        f2p,p2p=record["FAIL_TO_PASS"],record["PASS_TO_PASS"]
        assert isinstance(f2p,list) and isinstance(p2p,list) and f2p
        assert all(isinstance(key,str) and key for key in f2p+p2p)
        assert len(f2p+p2p)==len(set(f2p+p2p))
        production=tasks.patch_files(record["patch"]);official=tasks.patch_files(record["test_patch"])
        assert not set(production)&set(official)
        out=root/"private-inputs-reference-v1";out.mkdir(mode=0o700)
        (out/"gold.patch").write_text(record["patch"])
        (out/"official-tests.patch").write_text(record["test_patch"])
        (out/"baseline.patch").write_bytes(b"")
        reference=out/"reference";canonical=out/"canonical"
        shutil.copytree(public,reference,symlinks=True)
        shutil.copytree(public,canonical,symlinks=True)
        apply(reference,out/"gold.patch",out/"reference-apply.json")
        apply(canonical,out/"official-tests.patch",out/"official-apply.json")
        candidates=policy["registered_roots"]+[name for name in official if (canonical/name).exists() or (canonical/name).is_symlink()]
        selected=[]
        for name in sorted(set(candidates),key=lambda x:(len(Path(x).parts),x)):
            if not any(Path(name).is_relative_to(root) for root in selected):selected.append(name)
        selected.sort()
        missing=[name for name in selected if not ((canonical/name).exists() or (canonical/name).is_symlink())]
        assert not missing,missing
        assert not any(Path(name).is_relative_to(root) for name in production for root in selected)
        descriptor=trusted.seal_test_inputs(canonical,selected,out/"sealed")
        roots,entries,_=trusted._validated(descriptor)
        fixed={}
        for name in official:
            path=canonical/name
            fixed["/testbed/"+name]=({"link":os.readlink(path)} if path.is_symlink()
                else sha(path) if path.is_file() else None)
        assert input_digest(public)==policy["source_sha256"]
        result={"schema":"fixed-original-private-input-contract-v1","task":identity,
            "original_record":{"path":str(original_path),"sha256":sha(original_path)},
            "public_role_policy":{"path":str(policy_path),"sha256":sha(policy_path)},
            "public_source":str(public),"public_source_sha256":input_digest(public),
            "reference":str(reference),"reference_sha256":input_digest(reference),
            "canonical":str(canonical),"canonical_sha256":input_digest(canonical),
            "descriptor":descriptor,"roots":roots,"entries":len(entries),"official_paths":official,
            "fixed_test_sha256":fixed,"production_paths":production,
            "original_f2p":f2p,"original_p2p":p2p,
            "public_standalone_roots":policy["registered_roots"],
            "official_file_roots_added":[name for name in roots if name not in policy["registered_roots"]],
            "inline_or_unprotected_assertion_audit_pending":True,
            "producer_sha256":sha(__file__),"trusted_reader_sha256":sha(trusted.__file__),
            "client_model_calls":0,"private_outcome_run":False,"paid_ready":False,
            "scope":"Same original acceptance/assertions. Public standalone roots plus authoritative official test-patch files; no evaluator image/config or functional outcome yet."}
        save(out/"contract.json",result)
        print(json.dumps({"task":identity,"roots":len(roots),"entries":len(entries),
            "official_files":len(official),"selected_labels":len(f2p)+len(p2p),
            "reference_sha256":result["reference_sha256"],"private_outcome_run":False,
            "client_model_calls":0,"paid_ready":False}),flush=True)
    verify_package(package,frozen["package_files"])
if __name__=="__main__":main()
