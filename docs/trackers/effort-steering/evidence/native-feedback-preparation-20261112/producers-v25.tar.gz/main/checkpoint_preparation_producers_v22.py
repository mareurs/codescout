"""Selected producer custody including complete-reference role gates and all observed failures."""
from pathlib import Path
import hashlib,io,json,tarfile
MAIN=Path("/home/marius/work/claude/codescout")
SCRIPTS=MAIN/".superpowers/sdd/2026-11-11-native-public-feedback-transfer"
SCRATCH=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/apache__arrow-rs-7783")
OUTPUT=MAIN/"docs/trackers/effort-steering/evidence/native-feedback-preparation-20261112"
def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    selected = {}
    for pattern in ("*.py", "*.Dockerfile"):
        for path in SCRIPTS.glob(pattern):
            selected["main/" + path.name] = path
    for path in SCRATCH.rglob("producer-original.py"):
        selected["scratch/" + path.relative_to(SCRATCH).as_posix()] = path
    for relative in ("clean-base-gitlinks-v1/context/control/feedback_gitlinks.py",
            "common-preparation-v3/image-context/Dockerfile", "common-preparation-v3/image-context/Dockerfile.v2",
            "common-preparation-v3/image-root-ownership-v1/context/Dockerfile"):
        path = SCRATCH / relative
        assert path.is_file()
        selected["scratch/" + relative] = path
    assert selected and all(path.is_file() and not path.is_symlink() for path in selected.values())
    data = {name: path.read_bytes() for name, path in sorted(selected.items())}
    OUTPUT.mkdir(exist_ok=True)
    archive = OUTPUT / "producers-v22.tar.gz"
    assert not archive.exists()
    with archive.open("xb") as stream, tarfile.open(fileobj=stream, mode="w:gz") as tar:
        for name, content in data.items():
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(content), 0o644, 0
            tar.addfile(info, io.BytesIO(content))
    with tarfile.open(archive, "r:gz") as tar:
        assert tar.getnames() == list(data)
        for member in tar.getmembers():
            assert member.isfile() and tar.extractfile(member).read() == data[member.name]
    for name, path in selected.items():
        assert path.read_bytes() == data[name]
    manifest = {"schema": "feedback-preparation-producer-custody-v22", "archive": str(archive),
        "archive_bytes": archive.stat().st_size, "archive_sha256": sha(archive.read_bytes()),
        "selected_producer_members": len(data), "all_members_reopened": True,
        "members": {name: {"path": str(selected[name]), "bytes": len(content), "sha256": sha(content)} for name, content in data.items()},
        "scope": "Selected current/failed producers and generated recipes only; not all runtime/private control evidence or admission.",
        "client_model_calls": 0, "paid_ready": False}
    with (OUTPUT / "producers-v22-manifest.json").open("x") as stream:
        json.dump(manifest, stream, sort_keys=True, indent=2)
        stream.write("\n")
    print(json.dumps({key: value for key, value in manifest.items() if key != "members"}))

if __name__=="__main__":
    main()
