"""Fallback prescribed by mutation-probe.sh outside Claude: mutate fresh scratch copies."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

SOURCE = Path("/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
OUTPUT = Path("/home/marius/.codex/worktrees/2aa6/codescout/.superpowers/sdd/2026-11-12-blinded-assertion-boundary/review-delivery-mutations-v1")
MUTANTS = [
    ("fresh-context", "feedback_assertion_review.py", 'dispatch["request"] == expected', "True"),
    ("changed-path-coverage", "feedback_assertion_review.py", "changed <= set(inspected)", "True"),
    ("integer-not-bool", "feedback_assertion_review.py", "type(record[key]) is int", "isinstance(record[key], int)"),
    ("known-bypass-raw-grade", "native_campaign.py", 'audit.get("status") not in ("clear", "confirmed-bypass")', 'audit.get("status") != "clear"'),
]


def bindings():
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(SOURCE.glob("*.py"))}


def execute(root, label, mutation=None):
    target = root / label
    shutil.copytree(SOURCE, target, ignore=shutil.ignore_patterns("__pycache__"))
    if mutation:
        _, name, before, after = mutation
        path = target / name
        text = path.read_text()
        assert text.count(before) == 1
        path.write_text(text.replace(before, after))
        assert before not in path.read_text()
    result = subprocess.run([sys.executable, "-B", "-m", "unittest", "discover", "-s", str(target),
                             "-p", "test_feedback_assertion_*.py", "-v"],
                            cwd=root, capture_output=True, timeout=40)
    output = result.stdout + result.stderr
    (OUTPUT / (label + ".log")).write_bytes(output)
    count = re.search(rb"Ran ([0-9]+) tests? in ", output)
    assert count and int(count[1]) == 20 and b"ImportError" not in output and b"ModuleNotFoundError" not in output
    if mutation:
        assert result.returncode != 0 and b"FAILED (" in output
    else:
        assert result.returncode == 0 and output.rstrip().endswith(b"OK")
    return {"id": label, "tests_run": int(count[1]), "returncode": result.returncode,
            "observed": "killed" if mutation else "baseline-pass",
            "log_sha256": hashlib.sha256(output).hexdigest()}


def main():
    assert Path(__file__).stat().st_mode & 0o222 == 0
    before = bindings()
    OUTPUT.mkdir()
    with tempfile.TemporaryDirectory(prefix="review-delivery-mutants-", dir="/var/tmp") as directory:
        root = Path(directory)
        rows = [execute(root, "baseline")]
        rows.extend(execute(root, mutation[0], mutation) for mutation in MUTANTS)
    assert bindings() == before, "original protocol bytes changed"
    result = {"schema": "review-delivery-mutation-probe-v1", "bindings": before, "cases": rows,
              "applied": len(MUTANTS), "killed": sum(row["observed"] == "killed" for row in rows),
              "survived": 0, "scope": "Four root-applied temporary mutations, targeted twenty-test suite; not independent final review."}
    (OUTPUT / "result.json").write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
    print(json.dumps({key: result[key] for key in ("applied", "killed", "survived")}))


if __name__ == "__main__":
    main()
