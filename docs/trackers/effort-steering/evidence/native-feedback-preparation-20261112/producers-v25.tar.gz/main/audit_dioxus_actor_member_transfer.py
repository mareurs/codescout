"""Consume the existing prepared Dioxus template; no new onboarding or indexing."""
from pathlib import Path
import hashlib,json,sys,subprocess
sys.dont_write_bytecode=True
sys.path.insert(0,"/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
import public_clone
from receipts import input_digest
from native_executor import _public_digest
from public_build_inputs import generated_inventory
root=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/DioxusLabs__dioxus-5384/common-preparation-v1")
prep=json.loads((root/"preparation.json").read_bytes())
registration=json.loads((root/"registration.json").read_bytes())
template=root/"project";source=root/"public-source"
members=[row for row in prep["configured_projects"] if row["root"]!="."]
assert len(members)==len({row["root"] for row in members})==114
expected={row["root"]:generated_inventory(template/row["root"]/".codescout") for row in members}
knowledge=template/".codescout"
paths=[name for name in ("project.toml","system-prompt.md","workspace.toml") if (knowledge/name).is_file()]
paths+=sorted(str(path.relative_to(knowledge)) for path in (knowledge/"memories").rglob("*") if path.is_file())
image=registration["image"]
descriptor={"schema":"public-build-inputs-v1","image":image,"seed":None,"dependency_dirs":[],"cache_mounts":[]}
config={"template":str(template),"template_sha256":input_digest(template),
        "knowledge_paths":paths,"knowledge_sha256":input_digest(knowledge,paths),
        "image":image,"public_build_inputs":descriptor}
assert input_digest(source)==prep["public_baseline_sha256"]==prep["template_public_sha256"]
out=root/"actor-clone-member-transfer-v1";out.mkdir()
with (out/"registration.json").open("x") as stream:json.dump({
    "source":str(source),"source_sha256":input_digest(source),"config":config,
    "producer_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "clone_helper_sha256":hashlib.sha256(Path(public_clone.__file__).read_bytes()).hexdigest(),
    "member_roots":sorted(expected),"client_model_calls":0,"paid_ready":False},stream,sort_keys=True,indent=2)
actor=out/"actor"
result=public_clone.prepare_public_clone(source,actor,config)
assert {row["root"] for row in result["member_metadata_reused"]}==set(expected)
for name,inventory in expected.items():
    assert generated_inventory(actor/name/".codescout")==inventory
    assert generated_inventory(template/name/".codescout")==inventory
assert input_digest(template)==config["template_sha256"]
assert _public_digest(actor,preserve_project_context=True)==input_digest(source)
tracked=subprocess.check_output(["git","-C",str(template),"ls-files","-z"]).decode().split(chr(0))
tracked_metadata=[name for name in tracked if name and ".codescout" in Path(name).parts]
audit={"schema":"dioxus-actor-member-transfer-v1","member_namespaces":len(expected),
    "member_metadata_reopened":len(result["member_metadata_reused"]),
    "exact_inventory_parity":True,"source_and_template_unchanged":True,
    "onboarding_author_calls":result["onboarding_author_calls"],"additional_index_calls":0,
    "index_update_required":result["index_update_required"],
    "tracked_template_metadata_paths":tracked_metadata,
    "source_sha256":input_digest(source),"template_sha256":config["template_sha256"],
    "clone_helper_sha256":hashlib.sha256(Path(public_clone.__file__).read_bytes()).hexdigest(),
    "actor":str(actor),"client_model_calls":0,"paid_ready":False,
    "scope":"Actual local actor clone and all114 member metadata byte/mode/link inventory parity; no MCP/CLI/repair efficacy."}
with (out/"result.json").open("x") as stream:json.dump(result,stream,sort_keys=True,indent=2)
target=Path("/home/marius/work/claude/codescout/docs/trackers/effort-steering/evidence/native-feedback-preparation-20261112/dioxus-actor-clone-member-audit-v1.json")
with target.open("x") as stream:json.dump(audit,stream,sort_keys=True,indent=2)
print(json.dumps({key:value for key,value in audit.items() if key!="tracked_template_metadata_paths"},sort_keys=True))
print("tracked_template_metadata_paths_count="+str(len(tracked_metadata)))
