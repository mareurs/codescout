"""Explicit sibling-import bootstrap for the unchanged actual16 qualification driver."""
import importlib.util
from pathlib import Path
import sys

WORK = Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path[:0] = [str(WORK / "tools" / name) for name in
               ("effort_protocol", "agent_lifecycle", "hint_authority_pilot")]
PRIOR = Path(__file__).with_name("qualify_native_feedback_campaign_v1.py")
SPEC = importlib.util.spec_from_file_location("actual_feedback_driver_v1", PRIOR)
prior = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(prior)
# The executed entry identity is v2; v1 is an explicitly bound dependency.
prior.__file__ = str(Path(__file__).absolute())
scripted_turns = prior.scripted_turns
PAUSE = prior.PAUSE


if __name__ == "__main__":
    prior.main()
