"""Independent source/runtime readback for the real native build-input component."""
from pathlib import Path
import hashlib, json, re, sqlite3, subprocess, sys
sys.dont_write_bytecode=True
sys.path.insert(0,"/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from receipts import input_digest
from native_executor import _public_digest, external
import public_build_inputs as build_inputs
ROOT=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/skim-rs__skim-1044")
P=ROOT/"native-build-input-canaries-v1"
OUT=Path("/home/marius/work/claude/codescout/docs/trackers/effort-steering/evidence/native-feedback-preparation-20261112/skim-native-build-input-audit-v1.json")
def load(path):
    return json.loads(path.read_bytes())
def text(name):
    return "\n".join(block["text"] for block in load(P/(name+".json"))["result"]["content"] if block["type"]=="text")
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    config=load(P/"clone-config.json")
    projection=load(P/"projection.json")
    registered=load(P/"registration.json")
    actor=P/"actor"
    assert projection["onboarding_reused"] is True and projection["index_update_required"] is False
    assert _public_digest(actor)==registered["public_source_digest"]
    assert input_digest(ROOT/"common-preparation-v1/project")==config["template_sha256"]
    assert input_digest(actor/".codescout",config["knowledge_paths"])==config["knowledge_sha256"]
    status=json.loads(load(P/"workspace.json")["result"]["content"][0]["text"])
    index=json.loads(load(P/"index.json")["result"]["content"][0]["text"])
    assert status["project_root"]=="/testbed" and "rust" in status["languages"]
    assert status["embeddings_model"]=="CodeRankEmbed"
    assert status["server"]["build_id"]=="cdc53728d28a659b5a697048e6e5b719149693df2cf57cb8554ee0751ebf51bb"
    assert index["verdict"]=="complete" and index["expected_files"]==index["stored_files"]==130
    assert index["missing_count"]==index["orphan_count"]==index["chunks_without_vectors"]==0
    assert index["memories"]["on_disk"]==index["memories"]["in_store"]==5
    assert index["memories"]["missing_count"]==index["memories"]["orphan_count"]==0
    assert index["git_sync"]["status"]=="up_to_date"
    guidance=(actor/"CLAUDE.md").read_text()
    assert text("memory")==guidance
    pages=load(P/"tool-pages.json")
    tools={tool["name"] for page in pages for tool in page["result"]["tools"]}
    assert {"references","call_graph","symbol_at","symbols","semantic_search"}<=tools
    current=None
    references=[]
    for line in text("references").splitlines():
        heading=re.fullmatch(r"([A-Za-z0-9_./-]+\.rs) \(\d+\)",line.strip())
        if heading:
            current=heading[1]
            continue
        row=re.match(r"^\s+(\d+)\s+(.+)$",line)
        if current and row:
            number=int(row[1])
            assert (actor/current).read_text().splitlines()[number-1].strip()==row[2].strip()
            references.append({"path":current,"line":number})
    assert references
    assert "src/skim_item.rs:49" in text("symbol_at")
    assert (actor/"src/skim_item.rs").read_text().splitlines()[48].startswith("pub trait SkimItem")
    assert "SkimItem/output → text" in text("call_graph") and "lsp" in text("call_graph")
    assert "self.text()" in (actor/"src/skim_item.rs").read_text().splitlines()[69]
    returned=[]
    for path in (P/"semantic_search.json",):
        payload=json.loads(load(path)["result"]["content"][0]["text"])
        assert payload["results"]
        for hit in payload["results"]:
            source=(actor/hit["file_path"]).read_text().splitlines()
            observed="\n".join(source[hit["start_line"]-1:hit["end_line"]])
            assert observed==hit["content"] and hit["source"]=="stack"
            returned.append(hit)
    broad=json.loads(load(P/"semantic_search.json")["result"]["content"][0]["text"])["results"]
    assert all(hit["content"].strip()=="#[test]" for hit in broad)
    database=actor/".codescout/embeddings/testbed.db"
    connection=sqlite3.connect(database.as_uri()+"?mode=ro&immutable=1",uri=True)
    rows=connection.execute("SELECT content FROM code_chunk").fetchall()
    connection.close()
    assert len(rows)==status["index"]["chunks"]
    for stage in (P,):
        assert load(stage/"native/cleanup.json")["cleanup_complete"]
        assert load(stage/"native/cleanup.json")["close_errors"]==[]
        assert load(stage/"embedding/cleanup.json")["complete"]
        assert load(stage/"embedding/cleanup.json")["errors"]==[]
    public=[]
    for name in ("final-baseline-public-v1","final-reference-public-v1"):
        result=load(ROOT/name/"result.json")
        assert result["source_unchanged"]
        assert len(result["rows"])==2
        for row in result["rows"]:
            assert row["complete"] and row["resource_valid"] and row["exit_code"]==0
        public.append({"scope":name,"exact_public_checks":len(result["rows"]),"source_unchanged":True})
    result={"schema":"native-build-input-component-audit-v1","task":"skim-rs__skim-1044",
        "image":registered["image"],"public_source_sha256":registered["public_source_digest"],
        "static_knowledge_sha256":config["knowledge_sha256"],"memory_document_bytes":len(guidance.encode()),
        "index_expected_files":index["expected_files"],"index_stored_files":index["stored_files"],
        "memory_files_covered":index["memories"]["in_store"],"native_tools_exposed":len(tools),
        "returned_reference_rows_source_checked":len(references),"definition_and_lsp_call_edge_verified":True,
        "returned_semantic_hit_rows_source_checked":len(returned),
        "semantic_broad_query_hits_only_test_attributes":True,
        "stored_code_chunks":len(rows),"stored_chunks_exactly_test_attribute":sum(row[0].strip()=="#[test]" for row in rows),
        "semantic_quality_issue":"d25024261adb4d7c","semantic_relevance_or_repair_quality_claim":False,
        "prior_public_checks":public,"native_and_embedding_cleanup":True,"original_template_unchanged":True,
        "additional_onboarding_calls":0,"client_model_calls":0,"embedding_compute_cost_usd":None,
        "producer_sha256":sha(Path(__file__)),"paid_ready":False,
        "scope":"Actual projection/source/guidance/index/navigation facts; first author request/all16 slots, librarian artifacts and semantic usefulness are not qualified."}
    boundary=P/"public-build-boundary"
    cfg=load(boundary/"prepared-build.json")
    helper=Path(cfg["public_build_inputs_helper"])
    assert sha(helper)==cfg["files"][str(helper)]==sha(Path(build_inputs.__file__))
    argv=load(P/"native/argv.json")
    options={"--mount":[value for index,value in enumerate(argv) if index>0 and argv[index-1]=="--mount"]}
    reopened=external.public_build_contract(cfg,options,actor)
    assert reopened==load(boundary/"closed-generated-evidence.json")
    assert reopened["fingerprint"]==cfg["public_build_stage"]["fingerprint"]
    for phase in ("before","after"):
        raw=load(boundary/("container-"+phase+".json"))
        observed=external.public_build_runtime(cfg,raw,actor)
        assert observed["fingerprint"]==reopened["fingerprint"] and observed["generated_sha256"] is None
        group=load(boundary/("cgroup-"+phase+".json"))
        assert int(group["memory.max"])==32*1024**3 and int(group["pids.max"])==4096
        quota,period=map(int,group["cpu.max"].split())
        assert quota==4*period
        assert int(dict(line.split() for line in group["memory.events"].splitlines())["oom_kill"])==0
    native_cleanup=load(P/"native/cleanup.json")
    embedding_cleanup=load(P/"embedding/cleanup.json")
    absence=[]
    for kind,identity in (("container",native_cleanup["container"]),("container",embedding_cleanup["proxy"]),
                          ("network",embedding_cleanup["network_id"])):
        process=subprocess.run(["docker",kind,"inspect",identity],capture_output=True,text=True,timeout=30)
        assert process.returncode!=0 and ("no such" in process.stderr.lower() or
                                         ("network "+identity+" not found") in process.stderr.lower())
        absence.append({"kind":kind,"id":identity,"returncode":process.returncode,
                        "stderr_sha256":hashlib.sha256(process.stderr.encode()).hexdigest()})
    result.update(public_build_descriptor_sha256=reopened["fingerprint"], helper_sha256=sha(helper),
                  cgroup_probes=2, observed_native_memory_limit_bytes=32*1024**3,
                  actual_mounts_reopened=True, closed_generated_evidence_reopened=True, fresh_absence=absence,
                  scope="Real MCP preparation/build-input/navigation components only; no author CLI first request or all16 qualification.")
    with OUT.open("x") as stream:
        json.dump(result,stream,sort_keys=True,indent=2)
        stream.write("\n")
    print(json.dumps(result,sort_keys=True))

if __name__=="__main__":
    main()
