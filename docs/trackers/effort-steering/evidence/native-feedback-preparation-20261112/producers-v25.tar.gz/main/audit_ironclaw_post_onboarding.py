"""Read-only physical comparison after the one onboarding; do not retry onboarding."""
from pathlib import Path
import hashlib,json,os,stat,sys
sys.dont_write_bytecode=True
sys.path.insert(0,"/home/marius/.codex/worktrees/2aa6/codescout/tools/effort_protocol")
from native_executor import _public_digest, TOOL_ROLES
from receipts import input_digest
root=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/nearai__ironclaw-6724/common-preparation-v1")
def inventory(base):
    out={}
    for path in sorted(base.rglob("*")):
        name=path.relative_to(base).as_posix()
        if any(part in TOOL_ROLES for part in path.relative_to(base).parts):continue
        mode=path.lstat().st_mode
        out[name]=({"kind":"link","target":os.readlink(path)} if stat.S_ISLNK(mode) else
            {"kind":"file","mode":stat.S_IMODE(mode),"sha256":hashlib.sha256(path.read_bytes()).hexdigest()}
            if stat.S_ISREG(mode) else {"kind":"directory","mode":stat.S_IMODE(mode)})
    return out
left,right=inventory(root/"public-source"),inventory(root/"project")
value={"baseline_all_sha256":input_digest(root/"public-source"),
       "baseline_public_sha256":_public_digest(root/"public-source"),
       "project_public_sha256":_public_digest(root/"project"),
       "excluded_root_names":[p.name for p in (root/"public-source").iterdir() if p.name in TOOL_ROLES],
       "source_differences":[{"path":name,"before":left.get(name),"after":right.get(name)}
                             for name in sorted(set(left)|set(right)) if left.get(name)!=right.get(name)]}
print(json.dumps(value,sort_keys=True,indent=2))
with (root/"post-onboarding-source-audit-v1.json").open("x") as stream:json.dump(value,stream,sort_keys=True,indent=2)
