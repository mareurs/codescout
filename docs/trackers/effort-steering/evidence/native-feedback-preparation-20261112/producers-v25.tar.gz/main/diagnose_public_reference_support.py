"""Private diagnostic only: named canonical support overlay on a separate pure-reference copy."""
from pathlib import Path
import hashlib,json,shutil,sys
sys.dont_write_bytecode=True
WORK=Path("/home/marius/.codex/worktrees/2aa6/codescout")
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from receipts import input_digest
from executor import execute_observation
from campaign_resources import measure_host
from feedback_policy import condition_spec
from public_build_inputs import validate_descriptor
ROOT=Path("/home/marius/.cache/codescout-resident/codescout/native-feedback-preparation-20261112/nearai__ironclaw-6724")
RELATIVE="crates/ironclaw_memory/src/test_support.rs"
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):
    with path.open("x") as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write(chr(10))
def main():
    assert Path(__file__).stat().st_mode & 0o222==0
    inputs=ROOT/"private-inputs-reference-v1";contract=json.loads((inputs/"contract.json").read_bytes())
    original=Path(contract["reference"]);public=Path(contract["public_source"])
    assert input_digest(original)==contract["reference_sha256"] and input_digest(public)==contract["public_source_sha256"]
    assert not (original/RELATIVE).exists()
    canonical=Path(contract["canonical"])/RELATIVE
    assert canonical.is_file() and not canonical.is_symlink() and "/testbed/"+RELATIVE in contract["fixed_test_sha256"]
    assert sha(canonical)==contract["fixed_test_sha256"]["/testbed/"+RELATIVE]
    image_root=ROOT/"private-cache-owner-image-v5"
    image=json.loads((image_root/"result.json").read_bytes())["image"]
    descriptor=json.loads((image_root/"public-readback-v1/public-build-inputs.json").read_bytes())
    out=ROOT/"private-diagnostic-reference-support-v1";out.mkdir(mode=0o700)
    host=measure_host(WORK,"/tmp");save(out/"host-before.json",host)
    assert host["root_free"]>=80*1024**3 and host["mem_available"]>=16*1024**3 and host["tmp_free"]>=4*1024**3 and host["tmp_exec"]
    source=out/"private-reference-source";shutil.copytree(original,source,symlinks=True)
    shutil.copy2(canonical,source/RELATIVE)
    digest=input_digest(source);validate_descriptor(descriptor,source,image)
    paths=[Path(__file__),inputs/"contract.json",canonical]
    paths += list((WORK/"tools/effort_protocol").glob("*.py"))
    bindings={str(path):sha(path) for path in paths}
    request={"id":"private-support-diagnostic","run_id":"private-reference-support-diagnostic-v1",
        "phase":"challenge","kind":"verification","image":image,
        "argv":condition_spec("P",".")["check"]["argv"],"cwd":".","test_files":["Cargo.toml"],
        "production_files":sorted(path.relative_to(source).as_posix() for path in source.rglob("*")),
        "timeout_s":900,"max_log_bytes":67108864,"execution_profile":"cargo-v3","public_build_inputs":descriptor}
    save(out/"registration.json",{"schema":"private-reference-support-diagnostic-v1","source":str(source),"source_digest":digest,
        "original_reference":str(original),"original_reference_sha256":contract["reference_sha256"],
        "public_source":str(public),"public_source_sha256":contract["public_source_sha256"],
        "added_canonical_private_support":RELATIVE,"added_sha256":sha(canonical),"bindings":bindings,"request":request,
        "contains_private_contract_assertions":True,"actor_inputs_unchanged":True,"admissible_for_paid":False,
        "scope":"Causal compile diagnostic only. This source contains private canonical support and must never be used as actor source/context or silently substituted into admission.",
        "client_model_calls":0,"paid_ready":False})
    try:
        facts=execute_observation(request,source,out/"commands")
        row={"complete":facts["complete"],"resource_valid":facts["resource_valid"],"exit_code":facts["exit_code"],"receipt":facts}
    except BaseException as exc:
        row={"complete":False,"reason":type(exc).__name__+": "+str(exc)}
    assert input_digest(source)==digest and input_digest(original)==contract["reference_sha256"]
    assert input_digest(public)==contract["public_source_sha256"]
    assert all(sha(path)==value for path,value in bindings.items())
    save(out/"result.json",{**row,"admissible_for_paid":False,"actor_inputs_unchanged":True,
        "client_model_calls":0,"paid_ready":False,"scope":"Private diagnostic only; no change to registered baseline/reference control or experiment interpretation."})
    print(json.dumps({key:value for key,value in row.items() if key!="receipt"}),flush=True)
if __name__=="__main__":main()
