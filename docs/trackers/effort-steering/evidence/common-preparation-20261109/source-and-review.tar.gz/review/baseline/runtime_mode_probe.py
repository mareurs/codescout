import json
import preparation
from test_preparation import PreparationTests
case=PreparationTests();case.setUp()
try:
    case.cli.chmod(0o755)
    case.freeze()
    case.cli.chmod(0o644)
    preparation.prepare_arm(case.frozen,"L",case.root / "L")
    print(json.dumps({"accepted":True,"cli_permission_changed":"0755 -> 0644","arm_generated":(case.root / "L/arm.json").exists()}))
finally:
    case.doCleanups()
