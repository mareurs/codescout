import json, shutil, stat
from pathlib import Path
import preparation
from test_preparation import PreparationTests

def case(name, fn):
    test=PreparationTests()
    test.setUp()
    try:
        result=fn(test)
        print(json.dumps({"case":name, **result}))
    finally:
        test.doCleanups()

def rules_link(t):
    t.freeze()
    external=t.root / "external-rules"
    shutil.copytree(t.frozen / "rules", external)
    shutil.rmtree(t.frozen / "rules")
    (t.frozen / "rules").symlink_to(external, target_is_directory=True)
    result=preparation.prepare_arm(t.frozen,"L",t.root / "L")
    return {"accepted":True,"rules_directory_is_symlink":(t.frozen / "rules").is_symlink(),"generated_arm":(t.root / "L/arm.json").exists()}

def out_link(t):
    t.freeze()
    alias=t.root / "requested-output"
    target=t.root / "outside-target"
    alias.symlink_to(target,target_is_directory=True)
    preparation.prepare_arm(t.frozen,"L",alias)
    return {"accepted":True,"requested_output_was_symlink":alias.is_symlink(),"wrote_external_target":(target / "arm.json").exists()}

def readonly_clone(t):
    (t.source / "lib.rs").chmod(0o444)
    t.freeze()
    result=preparation.prepare_arm(t.frozen,"L",t.root / "L")
    path=Path(result["actor"]) / "lib.rs"
    return {"accepted":True,"actor_mode":oct(stat.S_IMODE(path.stat().st_mode)),"has_write_permission":bool(path.stat().st_mode & 0o222)}

case("linked-rules-directory",rules_link)
case("dangling-output-symlink",out_link)
case("read-only-clone",readonly_clone)
