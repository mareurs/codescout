print('public')
