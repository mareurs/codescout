import os,sys,json,pathlib,subprocess,time,hashlib
ROOT=pathlib.Path('/var/tmp/ep11-01a15/whole-admission-review-v1')
identity,relative,*modules=sys.argv[1:]
out=ROOT/'mutations'/identity;out.mkdir(parents=True,exist_ok=False)
source=ROOT/'copy'/relative
mutant=out/'mutated.py';mutant.write_bytes(source.read_bytes())
original=ROOT/'retained/originals'/relative
assert source.read_bytes()!=original.read_bytes()
def desc(p):return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
env=os.environ.copy();env.update(TMPDIR=str(ROOT/'tmp'),PYTHONDONTWRITEBYTECODE='1')
for k in ('EFFORT_PROTOCOL_TEST_IMAGE','EFFORT_FIXTURE_TEST_IMAGE'):env.pop(k,None)
cwd=ROOT/'copy/tools/effort_protocol'
def run(name,argv,timeout):
 start=time.time();log=out/(name+'.log')
 with log.open('wb') as stream:
  try:process=subprocess.run(argv,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=timeout);code=process.returncode;timed=False
  except subprocess.TimeoutExpired:code=None;timed=True
 return {'argv':argv,'cwd':str(cwd),'timeout_seconds':timeout,'exit_code':code,'timed_out':timed,'duration_seconds':time.time()-start,'log':desc(log)}
syntax=run('syntax',['python3','-B','-c','import pathlib,sys; compile(pathlib.Path(sys.argv[1]).read_bytes(),sys.argv[1],"exec")',str(source)],15)
test=run('test',['python3','-B','-m','unittest','-v',*modules],120) if syntax['exit_code']==0 and not syntax['timed_out'] else {'exit_code':None,'timed_out':False,'log':syntax['log']}
row={'id':identity,'source':str(pathlib.Path('/home/marius/.codex/worktrees/cf66/codescout')/relative),'original':desc(original),'mutated':desc(mutant),'syntax_exit_code':syntax['exit_code'],'syntax_timed_out':syntax['timed_out'],'test_exit_code':test['exit_code'],'timed_out':test['timed_out'],'log':test['log'],'equivalent':False}
(out/'result.json').write_text(json.dumps(row,indent=2)+'\n');(out/'execution.json').write_text(json.dumps({'syntax':syntax,'test':test,'environment':{'TMPDIR':env['TMPDIR'],'PYTHONDONTWRITEBYTECODE':'1','optional_Docker_tests':'disabled'}},indent=2)+'\n')
print(json.dumps(row));print(pathlib.Path(test['log']['path']).read_text()[-6000:])
