"""Adversarial read-only verifier reproduction. These inputs are NOT an admission or correction."""
import json,pathlib,hashlib,copy,sys
root=pathlib.Path('/var/tmp/ep11-01a15/whole-admission-review-v1');out=root/'replay-counterexample';out.mkdir(exist_ok=False)
sys.path.insert(0,'/home/marius/.codex/worktrees/cf66/codescout/tools/effort_protocol')
import paid_admission as subject
reg=json.loads(pathlib.Path('/var/tmp/ep11-01a15/paid-registration-v1/registration-for-review.json').read_text())
before=json.loads((root/'verification-input.json').read_text())['source_before']
mutants=[json.loads(p.read_text()) for p in sorted((root/'mutations').glob('*/result.json'))]
def bind(path):
 path=pathlib.Path(path);digest=hashlib.sha256(path.read_bytes()).hexdigest();reg['bindings'][str(path)]=digest;return {'path':str(path),'sha256':digest}
for row in mutants:
 for role in ['original','mutated','log']:bind(row[role]['path'])
baseline=json.loads((root/'baseline.json').read_text());bind(baseline['log']['path'])
report={'schema':'effort-whole-admission-review-v1','scope':'whole-admission','reviewer':{'id':'adversarial-counterexample-only','model':'not-an-approval'},'target_sha256':subject.review_target(reg),'verdict':'changes_required','source_before':before,'baseline':baseline,'mutations':mutants,'findings':[],'purpose':'Deliberately invalid replay evidence, never authorize payment with these artifacts'}
report_path=out/'counterexample-report-input.json';report_path.write_text(json.dumps(report,indent=2)+'\n');report_desc=bind(report_path)
survivors=[row for row in mutants if row['test_exit_code']==0]
killed=next(row for row in mutants if row['id']=='M02')
replays=[dict(copy.deepcopy(killed),id=row['id']) for row in survivors]
resolution={'schema':'effort-bounded-review-correction-v1','correction_rounds':1,'review_sha256':report_desc['sha256'],'target_sha256':report['target_sha256'],'source_before':before,'source_after':before,'findings_closed':[],'outstanding':[],'replays':replays,'purpose':'INVALID: substitutes the already-killed phase-state mutant M02 for every surviving mutant; no source was corrected'}
path=out/'invalid-resolution-counterexample.json';path.write_text(json.dumps(resolution,indent=2)+'\n');descriptor={'report':report_desc,'resolution':bind(path)}
proof=subject.verify_review(reg,descriptor)
result={'is_authorization':False,'expected':'reject substituted unrelated mutant','observed':'accepted','proof':proof,'substitutions':[{'survivor':s['id'],'original_source':s['source'],'original_mutated_sha256':s['mutated']['sha256'],'substitute_source':killed['source'],'substitute_mutated_sha256':killed['mutated']['sha256'],'substitute_log':killed['log']} for s in survivors]}
(out/'observed.json').write_text(json.dumps(result,indent=2)+'\n');(out/'counterexample-registration.json').write_text(json.dumps(reg,indent=2)+'\n');print(json.dumps(result,indent=2))
