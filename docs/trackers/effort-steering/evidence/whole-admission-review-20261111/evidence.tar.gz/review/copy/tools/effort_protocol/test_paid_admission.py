"""Paid admission consumes frozen evidence; summaries and synthetic populations cannot substitute."""
import copy
import hashlib
import io
import json
from pathlib import Path
import tarfile
import tempfile
import unittest

from campaign import attempt_schedule, selection_report
from receipts import input_digest
from unittest.mock import patch
try:
    import paid_admission as subject
except ModuleNotFoundError:
    subject=None


class PopulationAdmissionTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(subject, "paid admission evidence verifier missing")
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        metadata=[{"id":"task"+str(i),"repo":"org/repo"+str(i),"base_commit":"a"*40,
            "image":"registry/task"+str(i),"language":"rust","public_issue_sha256":str(i+1)*64}
            for i in range(4)]
        status={row["id"]:{"eligible":True,"reason":"frozen public qualification"} for row in metadata}
        def raw(value): return (json.dumps(value,sort_keys=True)+"\n").encode()
        self.members={"metadata":"metadata.json","exposure":"exposure.json","status":"status.json",
            "rule":"rule.json","freeze":"freeze.json","selection":"selection.json"}
        self.payloads={"metadata.json":raw({"tasks":metadata}),
            "exposure.json":raw({"tasks":{"task3":["prior exposure"]}}),
            "status.json":raw(status),"rule.json":raw({"seed":"frozen-original-seed"})}
        effective=[{**row,**status[row["id"]]} for row in metadata]
        selected=selection_report(effective,{"task3"},"frozen-original-seed")
        self.payloads["selection.json"]=raw(selected)
        self.payloads["freeze.json"]=raw({"selection":selected,
            "selection_rule":{"seed":"frozen-original-seed"},"selected_ids":[r["id"] for r in selected["selected"]],
            "private_outcomes_read":False,"replacement_after_private_outcomes":False,
            "experimental_model_calls":0})
        self.reg={"metadata":effective,"exposure":["task3"],"seed":"frozen-original-seed",
            "selected":selected["selected"],"bindings":{}}
        self.archive=self.root/"population.tar.gz"
        self.seal()

    def seal(self):
        with tarfile.open(self.archive,"w:gz") as packed:
            for name,raw in self.payloads.items():
                member=tarfile.TarInfo(name)
                member.size=len(raw)
                packed.addfile(member,io.BytesIO(raw))
        digest=hashlib.sha256(self.archive.read_bytes()).hexdigest()
        self.reg["bindings"][str(self.archive)]=digest
        self.proof={"path":str(self.archive),"sha256":digest,"members":copy.deepcopy(self.members)}

    def test_original_universe_exposure_seed_and_selected_order_are_recomputed(self):
        result=subject.verify_population(self.reg,self.proof)
        self.assertEqual(result["metadata_tasks"],4)
        self.assertEqual(result["exposure_ids"],1)
        self.assertEqual(result["excluded_universe_tasks"],1)
        self.assertEqual(result["selected_ids"],[r["id"] for r in self.reg["selected"]])

    def test_external_exposure_ids_are_not_counted_as_excluded_universe_tasks(self):
        exposure={"task3":[],"external-history":[]}
        self.payloads["exposure.json"]=json.dumps({"tasks":exposure}).encode()
        self.reg["exposure"]=sorted(exposure)
        selected=selection_report(self.reg["metadata"],set(exposure),self.reg["seed"])
        self.payloads["selection.json"]=json.dumps(selected).encode()
        freeze=json.loads(self.payloads["freeze.json"])
        freeze["selection"]=selected
        self.payloads["freeze.json"]=json.dumps(freeze).encode()
        self.seal()
        result=subject.verify_population(self.reg,self.proof)
        self.assertEqual(result["exposure_ids"],2)
        self.assertEqual(result["excluded_universe_tasks"],1)

    def test_synthetic_two_row_universe_or_changed_seed_cannot_admit(self):
        original=copy.deepcopy(self.reg)
        for case in ("universe","seed","exposure","order","qualification","unknown-metadata"):
            with self.subTest(case=case):
                self.reg=copy.deepcopy(original)
                if case=="universe": self.reg["metadata"]=self.reg["selected"]
                elif case=="seed": self.reg["seed"]="synthetic-runtime-seed"
                elif case=="exposure": self.reg["exposure"]=[]
                elif case=="order": self.reg["selected"].reverse()
                elif case=="qualification": self.reg["metadata"][0]["eligible"]=False
                else: self.reg["metadata"][0]["private_score"]=1
                with self.assertRaises(ValueError):
                    subject.verify_population(self.reg,self.proof)

    def test_archive_hash_binding_link_and_duplicate_member_are_rejected(self):
        original=self.archive.read_bytes()
        self.reg["bindings"][str(self.archive)]="0"*64
        with self.assertRaises(ValueError): subject.verify_population(self.reg,self.proof)
        self.reg["bindings"][str(self.archive)]=self.proof["sha256"]
        self.archive.write_bytes(original+b"changed")
        with self.assertRaises(ValueError): subject.verify_population(self.reg,self.proof)
        self.archive.write_bytes(original)
        alias=self.root/"alias"
        alias.symlink_to(self.archive)
        linked={**self.proof,"path":str(alias)}
        self.reg["bindings"][str(alias)]=linked["sha256"]
        with self.assertRaises(ValueError): subject.verify_population(self.reg,linked)
        with tarfile.open(self.archive,"w:gz") as packed:
            for name,raw in list(self.payloads.items())+[("metadata.json",self.payloads["metadata.json"])]:
                member=tarfile.TarInfo(name);member.size=len(raw);packed.addfile(member,io.BytesIO(raw))
        digest=hashlib.sha256(self.archive.read_bytes()).hexdigest()
        self.proof["sha256"]=digest;self.reg["bindings"][str(self.archive)]=digest
        with self.assertRaises(ValueError): subject.verify_population(self.reg,self.proof)

    def test_private_outcome_selection_unknown_calls_and_mismatched_freeze_are_refused(self):
        original=copy.deepcopy(self.payloads)
        for case in ("private","replacement","calls","selection","rule","ids","metadata-hash","exposure-hash"):
            with self.subTest(case=case):
                self.payloads=copy.deepcopy(original)
                freeze=json.loads(self.payloads["freeze.json"])
                if case=="private": freeze["private_outcomes_read"]=True
                elif case=="replacement": freeze["replacement_after_private_outcomes"]=True
                elif case=="calls": freeze["experimental_model_calls"]=None
                elif case=="selection": freeze["selection"]["complete"]=False
                elif case=="rule": freeze["selection_rule"]["seed"]="changed"
                elif case=="ids": freeze["selected_ids"].reverse()
                else:
                    selected=json.loads(self.payloads["selection.json"])
                    selected["metadata_sha256" if case=="metadata-hash" else "exposure_sha256"]="0"*64
                    self.payloads["selection.json"]=json.dumps(selected).encode()
                    freeze["selection"]=selected
                self.payloads["freeze.json"]=json.dumps(freeze).encode()
                self.seal()
                with self.assertRaises(ValueError): subject.verify_population(self.reg,self.proof)
class PublicCommandAdmissionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.source=self.root/"source"
        self.source.mkdir()
        (self.source/"Cargo.toml").write_text("[workspace]\n")
        self.command={"argv":["cargo","check","--offline","--workspace"],"cwd":".",
                      "test_files":["Cargo.toml"]}
        self.facts={"id":"public-cargo-check","complete":True,"resource_valid":True,"exit_code":0}
        self.public={"public_checks":[self.command],"execution_profile":"cargo-v2"}
        self.reg={"tasks":{"task":{"source":str(self.source),
            "source_sha256":subject.input_digest(self.source),"backend":{"public":self.public}}},"bindings":{}}
        self.registered={"source":str(self.source),"source_digest":subject.input_digest(self.source),
            "request":{"id":"public-cargo-check",**self.command}}
        self.result={"complete":True,"resource_valid":True,"exit_code":0,"receipt":self.facts}
        self.proof={"task":[{"registration":self.bound("registration.json",self.registered),
                            "result":self.bound("result.json",self.result)}]}

    def bound(self,name,value):
        path=self.root/name
        path.write_text(json.dumps(value))
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        self.reg["bindings"][str(path)]=digest
        return {"path":str(path),"sha256":digest}

    def test_reads_the_actual_source_profile_fixture_and_host_receipt(self):
        from unittest.mock import patch
        self.public["public_fixture"]={"fingerprint":"frozen"}
        with patch.object(subject,"verify_receipt",return_value=self.facts) as verify:
            result=subject.verify_public_commands(self.reg,self.proof)
        verify.assert_called_once_with({"id":"public-cargo-check"},self.root/"commands",self.source,
            expected_profile="cargo-v2",expected_fixture=self.public["public_fixture"])
        self.assertEqual(result["task"]["verified_commands"],1)

    def test_extra_missing_or_different_public_command_cannot_qualify(self):
        from unittest.mock import patch
        original=copy.deepcopy(self.reg)
        for case in ("missing","extra","command","source","profile-result","failed","drift"):
            with self.subTest(case=case):
                self.reg=copy.deepcopy(original)
                self.public=self.reg["tasks"]["task"]["backend"]["public"]
                proof=copy.deepcopy(self.proof)
                result=copy.deepcopy(self.result)
                facts=copy.deepcopy(self.facts)
                if case=="missing": proof={}
                elif case=="extra": proof["extra"]=proof["task"]
                elif case=="command": self.public["public_checks"][0]["argv"]=["true"]
                elif case=="source": self.reg["tasks"]["task"]["source_sha256"]="0"*64
                elif case=="profile-result": facts["execution_profile"]="wrong"
                elif case=="failed":
                    result["exit_code"]=101
                    proof["task"][0]["result"]=self.bound("result.json",result)
                elif case=="drift": (self.root/"result.json").write_text("changed")
                with patch.object(subject,"verify_receipt",return_value=facts):
                    with self.assertRaises(ValueError):
                        subject.verify_public_commands(self.reg,proof)
                self.bound("result.json",self.result)

    def test_incomplete_raw_receipt_is_not_replaced_by_the_positive_summary(self):
        from unittest.mock import patch
        with patch.object(subject,"verify_receipt",side_effect=ValueError("incomplete capture")):
            with self.assertRaisesRegex(ValueError,"incomplete capture"):
                subject.verify_public_commands(self.reg,self.proof)
class AccountingAdmissionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.reg={"bindings":{}}
        self.opening=self.root/"opening.json"
        self.known=self.root/"known.json"
        self.hold=self.root/"hold.json"
        self.opening.write_text(json.dumps({"prior_campaign_spend_usd":"5"}))
        self.known.write_text(json.dumps({"session_id":"known","scripted":False,
            "unknown_provider_cost":False,"cost_usd":"0.25"}))
        self.hold.write_text(json.dumps({"session_id":"legacy","scripted":False,
            "unknown_provider_cost":True,"cost_usd":None,"requests":0,"forwarded":0,
            "campaign_available_usd":"4"}))
        def row(path,identity,**fields):
            digest=hashlib.sha256(path.read_bytes()).hexdigest()
            self.reg["bindings"][str(path)]=digest
            return {"id":identity,"source":str(path),"receipt_sha256":digest,**fields}
        self.ledger={"ceiling_usd":"200","charges":[
            row(self.opening,"recorded-pre-native-opening-balance",cost_usd="5"),
            row(self.known,"native-client:known",cost_usd="0.25")],
            "holds":[row(self.hold,"native-client:legacy",cost_usd=None,reserved_usd="4",settled=False)],
            "reservations":[]}
        self.reg["ledger"]=copy.deepcopy(self.ledger)
        self.reg["carried_holds"]=[{k:self.ledger["holds"][0][k]
            for k in ("id","source","receipt_sha256","reserved_usd")}]
        self.reconciled={"schema":"client-ledger-reconciliation-v1","ledger":self.ledger,
            "opening_balance_source":str(self.opening),
            "opening_balance_sha256":self.ledger["charges"][0]["receipt_sha256"],
            "opening_balance_usd":"5","known_client_cost_usd":"5.25","native_receipts":1,
            "native_client_cost_usd":"0.25","unresolved_reserve_usd":"4",
            "proposed_new_allocation_usd":"38","commitment_if_new_allocation_usd":"47.25",
            "receipt_bindings":{r["source"]:r["receipt_sha256"]
                for r in self.ledger["charges"][1:]+self.ledger["holds"]}}
        self.report=self.root/"reconciliation.json"
        self.seal()

    def seal(self):
        self.report.write_text(json.dumps(self.reconciled))
        digest=hashlib.sha256(self.report.read_bytes()).hexdigest()
        self.reg["bindings"][str(self.report)]=digest
        self.proof={"path":str(self.report),"sha256":digest}

    def test_every_charge_is_reopened_and_the_unknown_hold_is_retained(self):
        original=copy.deepcopy(self.reg["ledger"])
        checked=subject.verify_accounting(self.reg,self.proof)
        self.assertEqual(checked["known_client_cost_usd"],"5.25")
        self.assertEqual(checked["unresolved_reserve_usd"],"4")
        self.assertEqual(checked["native_receipts"],1)
        self.assertEqual(self.reg["ledger"],original)

    def test_omitted_charge_changed_receipt_unbound_opening_and_false_sum_refuse(self):
        original=copy.deepcopy(self.reg)
        original_report=copy.deepcopy(self.reconciled)
        raw=self.known.read_bytes()
        for case in ("omitted","changed","unbound-opening","sum","count","carry","commitment","receipt-coverage"):
            with self.subTest(case=case):
                self.reg=copy.deepcopy(original)
                self.reconciled=copy.deepcopy(original_report)
                self.known.write_bytes(raw)
                if case=="omitted": self.reg["ledger"]["charges"].pop()
                elif case=="changed": self.known.write_bytes(raw+b" ")
                elif case=="unbound-opening": self.reg["bindings"].pop(str(self.opening))
                elif case=="sum": self.reconciled["known_client_cost_usd"]="0"
                elif case=="count": self.reconciled["native_receipts"]=0
                elif case=="carry": self.reg.pop("carried_holds")
                elif case=="commitment": self.reconciled["commitment_if_new_allocation_usd"]="0"
                else: self.reconciled["receipt_bindings"].pop(str(self.known))
                self.seal()
                with self.assertRaises(ValueError):
                    subject.verify_accounting(self.reg,self.proof)

    def test_unknown_or_scripted_receipt_cannot_become_a_known_historical_charge(self):
        original=copy.deepcopy(self.reg)
        for case in ("unknown","scripted","wrong-session","wrong-cost"):
            with self.subTest(case=case):
                self.reg=copy.deepcopy(original)
                raw={"session_id":"known","scripted":False,"unknown_provider_cost":False,"cost_usd":"0.25"}
                if case=="unknown": raw.update(unknown_provider_cost=True,cost_usd=None)
                elif case=="scripted": raw["scripted"]=True
                elif case=="wrong-session": raw["session_id"]="other"
                else: raw["cost_usd"]="0.26"
                self.known.write_text(json.dumps(raw))
                digest=hashlib.sha256(self.known.read_bytes()).hexdigest()
                self.reg["bindings"][str(self.known)]=digest
                self.reg["ledger"]["charges"][1]["receipt_sha256"]=digest
                self.reconciled["ledger"]=copy.deepcopy(self.reg["ledger"])
                self.reconciled["receipt_bindings"][str(self.known)]=digest
                self.seal()
                with self.assertRaises(ValueError):
                    subject.verify_accounting(self.reg,self.proof)
class NativeInvocationAdmissionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.native=self.root/"native";self.native.mkdir()
        (self.native/"readiness").mkdir()
        self.source=self.root/"input";self.source.mkdir()
        (self.source/"program.rs").write_text("fn main() {}")
        self.reg={"bindings":{}}
        self.intent={"invocation_id":"q::0::repair","arm":"L","source":str(self.source),
                     "cli_cap_usd":"2.75","max_continuations":2}
        self.public={"image":"sha256:"+"a"*64,"capture_base_commit":"b"*40,
            "knowledge_sha256":"f"*64,"runtime":{"files":{"cli":{"path":"/frozen/cli"}},
            "plugin":{"path":"/frozen/plugin"}}}
        argv=["/frozen/cli","--effort","low","--model","claude-sonnet-5-5",
              "--setting-sources","user,project,local","--plugin-dir","/frozen/plugin",
              "--max-budget-usd","2.75"]
        self.raw={
            "invocation.json":{"invocation_id":self.intent["invocation_id"],"native_path":str(self.native),
                "measurement_invalid":False,"context_valid":True,"capture_complete":True,
                "cleanup_complete":True,"cost_is_final":True,"cost_usd":"0",
                "candidate":str(self.source),"source_digest":input_digest(self.source)},
            "native/launch.json":{"argv":argv,"scripted":True,"real_credentials_read":False,
                "source_image":self.public["image"],"mcp_protocol_negotiation":"legacy","session_id":"q"},
            "native/receipt.json":{"scripted":True,"context_valid":True,"session_id":"q",
                "unknown_provider_cost":False,"forwarded":0,"requests":1,"transport_errors":[],
                "cleanup_error":None,"supervision_error":None,"cost_usd":"0"},
            "native/native-executor.json":{"context_evidence":{"recon_delivered":True,"system_delivered":True},
                "context_valid":True,"capture_complete":True,"cleanup_complete":True,"cost_is_final":True,
                "scripted_provider":True,"provider_forwarded":0},
            "native/prepared.json":{"cli":"/frozen/cli","max_continuations":2,"baseline_commit":"b"*40},
            "native/public-preparation.json":{"source_sha256":input_digest(self.source),
                "onboarding_reused":True,"onboarding_author_calls":0,"knowledge_sha256":"f"*64},
            "native/supervision-final.json":{"complete":True,"resource_ok":True,"errors":[],
                "cgroup_probes":2,"oom_kill":0},
            "native/candidate-capture.json":{"complete":True,"image":self.public["image"],
                "baseline_commit":"b"*40,"bytes":5,"sha256":hashlib.sha256(b"patch").hexdigest()},
            "native/cleanup.json":[{"name":"worker","absent":True}],
            "native/mcp-launch-one.json":{"name":"worker"},
            "native/readiness/readiness.json":{"expected":{},"wire":{},"result":{"ready":True}},
            "native/request-0.json":{"output_config":{"effort":"low"},"messages":[{"role":"assistant",
                "content":[{"type":"tool_use","name":"Skill","input":{"skill":"codescout-companion:reconnaissance"}}]}]}}
        patch_path=self.native/"candidate.patch";patch_path.write_bytes(b"patch")
        self.reg["bindings"][str(patch_path)]=hashlib.sha256(b"patch").hexdigest()
        from context_inputs import prepare_context
        actor=self.native/"actor"
        (actor/".codescout").mkdir(parents=True)
        (actor/".codescout/system-prompt.md").write_text("FROZEN ONBOARDING")
        plugin=self.root/"plugin"
        skill=plugin/"skills/reconnaissance"
        skill.mkdir(parents=True)
        (skill/"SKILL.md").write_text("FROZEN RECON")
        context=prepare_context(self.native,actor,plugin)
        self.public["runtime"]["plugin"]["path"]=str(plugin)
        argv[argv.index("--plugin-dir")+1]=str(plugin)
        argv+=["--append-system-prompt",Path(context["path"]).read_text()]
        self.raw["native/launch.json"]["context_preload_sha256"]=context["files"][context["path"]]
        self.raw["native/prepared.json"].update(actor=str(actor),plugin=str(plugin),context_preload=context,
                                              files=context["files"])
        self.reg["bindings"].update(context["files"])
        self.raw["native/expected.json"]={"effort":"low","clause":"AUTHORITY","declaration":False,
            "global_visible":["GLOBAL"],"project_visible":["PROJECT"],
            "preload_visible":["<prepared-context>","FROZEN ONBOARDING","FROZEN RECON","</prepared-context>"]}
        self.raw["native/expected.json"]["preload_visible"]=Path(context["path"]).read_text().splitlines()
        self.raw["native/expected.json"]["preload_visible"]=[v for v in self.raw["native/expected.json"]["preload_visible"] if v.strip()]
        self.raw["native/request-0.json"].update(model="claude-sonnet-5-5",
            system=[{"type":"text","text":"GLOBAL\nPROJECT\n"+Path(context["path"]).read_text()}])
        self.seal()

    def test_preloaded_context_is_verified_without_model_selected_skill_calls(self):
        self.raw["native/request-0.json"]["messages"]=[]
        self.seal()
        self.assertEqual(self.invoke()["context_preloaded"],True)
        for case in ("missing","user-only","argument","hash"):
            original=copy.deepcopy(self.raw)
            request=self.raw["native/request-0.json"]
            if case=="missing":
                request["system"][0]["text"]=request["system"][0]["text"].replace("FROZEN RECON","")
            elif case=="user-only":
                request["messages"]=[{"role":"user","content":request["system"]}]
                request["system"]=[]
            elif case=="argument":
                argv=self.raw["native/launch.json"]["argv"]
                argv[argv.index("--append-system-prompt")+1]="unrelated"
            else:
                self.raw["native/launch.json"]["context_preload_sha256"]="0"*64
            self.seal()
            with self.subTest(case=case),self.assertRaises(ValueError):
                self.invoke()
            self.raw=original
            self.seal()

    def seal(self):
        for name,value in self.raw.items():
            path=self.root/name
            path.write_text(json.dumps(value))
            self.reg["bindings"][str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()

    def invoke(self):
        with patch.object(subject,"validate_readiness",return_value={"ready":True}) as validator:
            result=subject.verify_native_invocation(self.reg,self.root,self.intent,self.public)
        validator.assert_called_once_with({}, {}, source=self.source)
        return result

    def test_complete_native_contract_and_duplicate_cli_argument(self):
        checked=self.invoke()
        self.assertEqual(checked["effort"],"low")
        self.assertEqual(checked["cli_cap_usd"],"2.75")
        self.assertEqual(checked["cgroup_probes"],2)
        self.raw["native/launch.json"]["argv"]+=["--effort","xhigh"]
        self.seal()
        with self.assertRaisesRegex(ValueError,"repeated CLI"):
            self.invoke()

    def test_rebound_metadata_cannot_fake_semantic_native_guards(self):
        original=copy.deepcopy(self.raw)
        cases={
            "context":("invocation.json","context_valid",False),
            "unknown":("native/receipt.json","unknown_provider_cost",True),
            "forwarded":("native/receipt.json","forwarded",1),
            "recon":("native/native-executor.json","context_evidence",{"recon_delivered":False,"system_delivered":True}),
            "probes":("native/supervision-final.json","cgroup_probes",1),
            "oom":("native/supervision-final.json","oom_kill",1),
            "source":("native/public-preparation.json","source_sha256","0"*64),
            "memory":("native/public-preparation.json","knowledge_sha256","0"*64),
            "patch":("native/candidate-capture.json","sha256","0"*64),
            "continuations":("native/prepared.json","max_continuations",3)}
        for case,(name,key,value) in cases.items():
            with self.subTest(case=case):
                self.raw=copy.deepcopy(original)
                self.raw[name][key]=value
                self.seal()
                with self.assertRaises(ValueError): self.invoke()

    def test_wrong_effort_cap_context_skill_and_absence_refuse(self):
        original=copy.deepcopy(self.raw)
        for case in ("effort","cap","model","settings","plugin","request-effort","skill","absence","worker"):
            with self.subTest(case=case):
                self.raw=copy.deepcopy(original)
                argv=self.raw["native/launch.json"]["argv"]
                if case in ("effort","cap","model","settings","plugin"):
                    option={"effort":"--effort","cap":"--max-budget-usd","model":"--model",
                            "settings":"--setting-sources","plugin":"--plugin-dir"}[case]
                    argv[argv.index(option)+1]={"effort":"xhigh","cap":"3","model":"other",
                                              "settings":"local","plugin":"/other"}[case]
                elif case=="request-effort":
                    self.raw["native/request-0.json"]["output_config"]["effort"]="xhigh"
                elif case=="skill": self.raw["native/request-0.json"]["system"]=[]
                elif case=="absence": self.raw["native/cleanup.json"][0]["absent"]=False
                else: self.raw["native/cleanup.json"][0]["name"]="other"
                self.seal()
                with self.assertRaises(ValueError): self.invoke()
class RuntimeAdmissionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix="ep-runtime-unit-",dir="/var/tmp")
        self.addCleanup(self.temp.cleanup)
        self.base=Path(self.temp.name)
        self.root=self.base/"qualified";self.root.mkdir()
        self.reg={"output_root":str(self.base/"future-paid"),"tasks":{},"bindings":{}}
        metadata=[{"id":"task"+str(i),"repo":"org/repo"+str(i),"base_commit":"a"*40,
            "image":"frozen-image","language":"rust","public_issue_sha256":str(i+1)*64,
            "eligible":True,"reason":"qualified"} for i in range(2)]
        self.reg["selected"]=metadata
        self.reg["schedule"]=attempt_schedule(metadata)
        self.frozen=self.base/"runtime.py";self.frozen.write_text("reviewed runtime")
        self.producer=self.base/"producer.py";self.producer.write_text("actual controller driver")
        for row in metadata:
            source=self.base/row["id"];source.mkdir()
            (source/"code.rs").write_text("pub fn f() {}")
            self.reg["tasks"][row["id"]]={"source":str(source),"source_sha256":input_digest(source),
                "public_packet":{"issue":"public issue"},"backend":{"public":{},
                "private":{"config":"/private/config","config_sha256":"c"*64,"entry_sha256":"e"*64}}}
        self.reg["bindings"][str(self.frozen)]=hashlib.sha256(self.frozen.read_bytes()).hexdigest()
        self.proof={"root":str(self.root),"producer":self.bind(self.producer)}
        qualified={"mode":"scripted","campaign_id":"qualification","selected":metadata,
            "schedule":self.reg["schedule"],"tasks":copy.deepcopy(self.reg["tasks"]),
            "bindings":{str(self.frozen):self.reg["bindings"][str(self.frozen)]},
            "qualification_driver":self.proof["producer"]}
        closed={"attempts":[]}
        attempts=[]
        for index,attempt in enumerate(self.reg["schedule"]):
            directory=self.root/"attempts"/(str(index).zfill(2)+"-"+attempt["arm"])
            directory.mkdir(parents=True)
            candidate=directory/"candidate";candidate.mkdir()
            (candidate/"code.rs").write_text("pub fn f() {}")
            invocations=[]
            phases=("investigate","repair","challenge") if attempt["arm"] in ("P","R") else ("repair",)
            for phase_index,phase in enumerate(phases):
                phase_root=directory/phase;phase_root.mkdir()
                identity="qualification::"+str(index)+"::"+phase
                cap=attempt["phase_cli_caps_usd"][phase_index] if len(phases)==3 else attempt["cli_cap_usd"]
                allowance=attempt["phase_reservations_usd"][phase_index] if len(phases)==3 else attempt["reserved_usd"]
                intent={"invocation_id":identity,"task_id":attempt["task_id"],"arm":attempt["arm"],
                    "phase":phase,"cli_cap_usd":cap,"allowance_usd":allowance}
                record={"native_path":str(phase_root/"native")}
                self.write(phase_root/"intent.json",intent)
                self.write(phase_root/"invocation.json",record)
                invocations.append({"record":record,"measurement_invalid":False,
                                    "cost":{"known_usd":"0","unknown":False}})
            row={"attempt_index":index,"arm":attempt["arm"],"task_id":attempt["task_id"],
                 "attempt_receipt":str(directory/"attempt.json"),"workflow_state":"closed",
                 "measurement_invalid":False,"reason":None,"candidate":str(candidate),
                 "source_digest":input_digest(candidate),"invocations":invocations,"grade":None}
            self.write(directory/"attempt.json",row)
            closed["attempts"].append({"attempt_receipt":row["attempt_receipt"],
                "receipt_sha256":self.reg["bindings"][row["attempt_receipt"]],
                "candidate":str(candidate),"source_digest":row["source_digest"]})
            grade_root=self.root/"grades"/str(index).zfill(2);grade_root.mkdir(parents=True)
            packet={"source":str(candidate),"source_digest":row["source_digest"],
                    "config":"/private/config","config_sha256":"c"*64}
            self.write(grade_root/"private-request.json",packet)
            self.write(grade_root/"private-entry-started.json",{"entry_sha256":"e"*64,
                "request_sha256":self.reg["bindings"][str(grade_root/"private-request.json")]})
            row["grade"]={"valid":True,"pass":False}
            self.write(grade_root/"verdict.json",row["grade"])
            attempts.append(row)
        self.write(self.root/"ledger-final.json",{"charges":[]})
        closed["ledger_sha256"]=self.reg["bindings"][str(self.root/"ledger-final.json")]
        documents={"registration":("registration.json",qualified),
            "result":("result.json",{"status":"completed","unexecuted":[],"attempts":attempts}),
            "qualification":("runtime-qualification.json",{"attempts":8,"native_invocations":16,
                "private_evaluator_processes":8,"provider_forwarded":0,"all_protocol_workflows_closed":True,
                "efficacy_claim":None,"model_cost_usd":"0"}),
            "closure":("actor-batch-closed.json",closed)}
        for role,(name,value) in documents.items():
            self.write(self.root/name,value)
            self.proof[role]=self.bind(self.root/name)
        self.proof["ledger"]=self.bind(self.root/"ledger-final.json")

    def bind(self,path):
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        self.reg["bindings"][str(path)]=digest
        return {"path":str(path),"sha256":digest}

    def write(self,path,value):
        path.write_text(json.dumps(value))
        return self.bind(path)

    def invoke(self):
        with patch.object(subject,"_runtime_sources",return_value=[self.frozen]), \
             patch.object(subject,"verify_native_invocation",return_value={}) as native:
            result=subject.verify_runtime(self.reg,self.proof)
        return result,native.call_count

    def test_sixteen_native_invocations_and_eight_independent_grade_inputs_are_reopened(self):
        checked,calls=self.invoke()
        self.assertEqual(calls,16)
        self.assertEqual(checked["native_invocations"],16)
        self.assertEqual(checked["private_evaluator_processes"],8)

    def test_changed_qualified_runtime_source_is_not_covered_by_a_positive_summary(self):
        self.frozen.write_text("changed after qualification")
        with self.assertRaisesRegex(ValueError,"evidence bytes changed"):
            self.invoke()

    def test_rebound_summary_incomplete_attempt_or_wrong_phase_cap_refuse(self):
        for case in ("summary","attempt","cap","private"):
            with self.subTest(case=case):
                target={"summary":self.root/"runtime-qualification.json",
                    "attempt":self.root/"result.json",
                    "cap":self.root/"attempts/00-L/repair/intent.json",
                    "private":self.root/"grades/00/private-entry-started.json"}[case]
                raw=target.read_bytes()
                value=json.loads(raw)
                if case=="summary": value["native_invocations"]=15
                elif case=="attempt": value["attempts"][0]["workflow_state"]="incomplete"
                elif case=="cap": value["cli_cap_usd"]="3"
                else: value["entry_sha256"]="0"*64
                self.write(target,value)
                role={"summary":"qualification","attempt":"result"}.get(case)
                if role: self.proof[role]=self.bind(target)
                with self.assertRaises(ValueError): self.invoke()
                target.write_bytes(raw)
                self.bind(target)
                if role: self.proof[role]=self.bind(target)

    def test_different_paid_schedule_or_unbound_producer_cannot_reuse_qualification(self):
        self.reg["schedule"].reverse()
        with self.assertRaises(ValueError): self.invoke()
        self.reg["schedule"].reverse()
        self.reg["bindings"].pop(str(self.producer))
        with self.assertRaises(ValueError): self.invoke()
class VerificationAdmissionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir="/var/tmp")
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.source=self.root/"source.py";self.source.write_text("reviewed source")
        self.reg={"bindings":{}}
        self.commands={role:{"cwd":str(self.root),"argv":["command",role]} for role in
                       ("protocol","lifecycle","evaluator","gate")}
        self.sources=[self.source]
        digest=hashlib.sha256(self.source.read_bytes()).hexdigest()
        self.reg["bindings"][str(self.source)]=digest
        self.value={"schema":"effort-verification-v1","source_before":{str(self.source):digest},
                    "source_after":{str(self.source):digest},"executions":{}}
        for role,command in self.commands.items():
            log=self.root/(role+".log");log.write_text("observed complete test output")
            self.value["executions"][role]={**command,"exit_code":0,"timed_out":False,
                "environment":{"TMPDIR":"/var/tmp","PYTHONDONTWRITEBYTECODE":"1",
                    "CODESCOUT_WIP_ATTRIBUTION_TIMEOUT_MS":"120000","NEXTEST_TEST_THREADS":"4","RUST_TEST_THREADS":"4",
                    "EFFORT_PROTOCOL_TEST_IMAGE":"sha256:"+"a"*64,"EFFORT_FIXTURE_TEST_IMAGE":"sha256:"+"a"*64},
                "log":self.bind(log)}
        producer=self.root/"producer.py";producer.write_text("observed verification driver")
        self.value["producer"]=self.bind(producer)
        self.seal()

    def bind(self,path):
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        self.reg["bindings"][str(path)]=digest
        return {"path":str(path),"sha256":digest}

    def seal(self):
        path=self.root/"verification.json";path.write_text(json.dumps(self.value))
        self.descriptor=self.bind(path)

    def invoke(self):
        with patch.object(subject,"verification_contract",return_value=(self.sources,self.commands)):
            return subject.verify_verification(self.reg,self.descriptor)

    def test_complete_current_sources_and_exact_commands_are_required(self):
        self.assertEqual(set(self.invoke()["executions"]),set(self.commands))
        original=copy.deepcopy(self.value)
        for case in ("exit","bool","timeout","command","cwd","environment","sources","after","missing","empty-log"):
            self.value=copy.deepcopy(original)
            row=self.value["executions"]["gate"]
            if case=="exit":row["exit_code"]=1
            elif case=="bool":row["exit_code"]=False
            elif case=="timeout":row["timed_out"]=True
            elif case=="command":row["argv"]=["true"]
            elif case=="cwd":row["cwd"]="/elsewhere"
            elif case=="environment":row["environment"]["NEXTEST_TEST_THREADS"]="99"
            elif case=="sources":self.value["source_before"]={}
            elif case=="after":self.value["source_after"]={}
            elif case=="missing":self.value["executions"].pop("evaluator")
            else:
                path=self.root/"empty.log";path.write_text("")
                row["log"]=self.bind(path)
            self.seal()
            with self.subTest(case=case),self.assertRaises(ValueError):
                self.invoke()
        self.value=original;self.seal()
        self.source.write_text("unverified later source")
        with self.assertRaises(ValueError):self.invoke()
class ReviewAdmissionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir="/var/tmp")
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.source=self.root/"source.py";self.source.write_text("load-bearing guard")
        digest=hashlib.sha256(self.source.read_bytes()).hexdigest()
        self.reg={"bindings":{str(self.source):digest},"admission":{"verification":{},"review":{}},
                  "campaign_id":"fixed-campaign","schedule":[{"arm":"L"}]}
        self.source_map={str(self.source):digest}
        self.value={"schema":"effort-whole-admission-review-v1","scope":"whole-admission",
                    "reviewer":{"id":"independent-review","model":"strongest-available"},
                    "verdict":"approve","source_before":self.source_map,"findings":[],"mutations":[]}
        self.value["target_sha256"]=subject.review_target(self.reg)
        baseline=self.root/"baseline.log";baseline.write_text("baseline tests passed")
        self.value["baseline"]={"exit_code":0,"timed_out":False,"log":self.bind(baseline)}
        original=self.root/"original.py";original.write_bytes(self.source.read_bytes())
        for index in range(8):
            mutant=self.root/("mutant-"+str(index)+".py");mutant.write_text("removed guard "+str(index))
            log=self.root/("mutant-"+str(index)+".log");log.write_text("tests failed on the applied mutant")
            self.value["mutations"].append({"id":"M"+str(index),"source":str(self.source),
                "original":self.bind(original),"mutated":self.bind(mutant),"syntax_exit_code":0,
                "test_exit_code":1,"timed_out":False,"syntax_timed_out":False,"log":self.bind(log),"equivalent":False})
        self.seal()

    def bind(self,path):
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        self.reg["bindings"][str(path)]=digest
        return {"path":str(path),"sha256":digest}

    def seal(self,resolution=None):
        path=self.root/"review.json";path.write_text(json.dumps(self.value))
        self.descriptor={"report":self.bind(path),"resolution":resolution}

    def invoke(self):
        with patch.object(subject,"verification_contract",return_value=([self.source],{})):
            return subject.verify_review(self.reg,self.descriptor)

    def test_observed_mutation_results_and_full_scope_are_required(self):
        self.assertEqual(self.invoke()["valid_applied_mutants"],8)
        original=copy.deepcopy(self.value)
        for case in ("seven","reasoning","survivor","syntax","bool","scope","target","finding","baseline","timeout","syntax-timeout","encoded-signal","missing-timeout","missing-syntax-timeout","baseline-timeout","baseline-missing-timeout"):
            self.value=copy.deepcopy(original)
            if case=="seven":self.value["mutations"].pop()
            elif case=="reasoning":self.value["mutations"]=[]
            elif case=="survivor":self.value["mutations"][0]["test_exit_code"]=0
            elif case=="syntax":self.value["mutations"][0]["syntax_exit_code"]=1
            elif case=="bool":self.value["mutations"][0]["test_exit_code"]=True
            elif case=="scope":self.value["scope"]="slice"
            elif case=="target":self.value["target_sha256"]="0"*64
            elif case=="finding":self.value["findings"]=[{"id":"F1","severity":"high"}]
            elif case=="baseline":self.value["baseline"]["exit_code"]=1
            elif case=="timeout":self.value["mutations"][0].update(test_exit_code=124,timed_out=True)
            elif case=="syntax-timeout":self.value["mutations"][0]["syntax_timed_out"]=True
            elif case=="encoded-signal":self.value["mutations"][0]["test_exit_code"]=137
            elif case=="missing-timeout":self.value["mutations"][0].pop("timed_out")
            elif case=="missing-syntax-timeout":self.value["mutations"][0].pop("syntax_timed_out")
            elif case=="baseline-timeout":self.value["baseline"]["timed_out"]=True
            else:self.value["baseline"].pop("timed_out")
            self.seal()
            with self.subTest(case=case),self.assertRaises(ValueError):
                self.invoke()
        self.value=original;self.seal()
        self.reg["schedule"][0]["arm"]="X"
        with self.assertRaises(ValueError):self.invoke()

    def test_one_bounded_correction_requires_exact_survivor_replay_and_current_sources(self):
        self.value["verdict"]="changes_required"
        self.value["findings"]=[{"id":"F1","severity":"high"}]
        self.value["mutations"][0]["test_exit_code"]=0
        self.seal()
        report_sha=self.descriptor["report"]["sha256"]
        self.source.write_text("corrected guard and regression")
        after=self.bind(self.source)["sha256"]
        replay=copy.deepcopy(self.value["mutations"][0])
        original=self.root/"corrected-original.py";original.write_bytes(self.source.read_bytes())
        replay["original"]=self.bind(original)
        replay["test_exit_code"]=1
        resolution={"schema":"effort-bounded-review-correction-v1","correction_rounds":1,
            "review_sha256":report_sha,"target_sha256":self.value["target_sha256"],
            "source_before":self.value["source_before"],"source_after":{str(self.source):after},
            "findings_closed":["F1"],"outstanding":[],"replays":[replay]}
        path=self.root/"resolution.json";path.write_text(json.dumps(resolution))
        self.descriptor["resolution"]=self.bind(path)
        self.assertEqual(self.invoke()["bounded_correction_rounds"],1)
        resolution["replays"]=[]
        path.write_text(json.dumps(resolution));self.descriptor["resolution"]=self.bind(path)
        with self.assertRaises(ValueError):self.invoke()
class SharedPreparationAdmissionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir="/var/tmp")
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.reg={"bindings":{},"tasks":{}}
        self.value={"schema":"effort-shared-reuse-v1","client_author_calls":0,"new_client_model_cost_usd":"0",
                    "excluded_costs":{name:{"status":"unmeasured","usd":None} for name in
                                      ("root","review","embedding_compute")},"tasks":{}}
        producer=self.root/"producer.py";producer.write_text("local reuse-only preparation")
        self.value["producer"]=self.bind(producer)
        for identity in ("a","b"):
            template=self.root/identity
            (template/".codescout").mkdir(parents=True)
            (template/"code.rs").write_text("source")
            system=template/".codescout/system-prompt.md";system.write_text("frozen onboarding")
            public={"template":str(template),"template_sha256":input_digest(template),
                    "knowledge_paths":["system-prompt.md"],
                    "knowledge_sha256":input_digest(template/".codescout",["system-prompt.md"])}
            self.reg["tasks"][identity]={"backend":{"public":public}}
            self.value["tasks"][identity]={key:public[key] for key in
                                          ("template","template_sha256","knowledge_sha256")}
            self.bind(system)
        self.seal()

    def bind(self,path):
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        self.reg["bindings"][str(path)]=digest
        return {"path":str(path),"sha256":digest}

    def seal(self):
        path=self.root/"shared.json";path.write_text(json.dumps(self.value))
        self.descriptor=self.bind(path)
        self.reg["shared_preparation"]={"cost_usd":"0","receipt_sha256":self.descriptor["sha256"]}

    def test_zero_author_reuse_retains_unmeasured_costs_and_exact_templates(self):
        self.assertEqual(subject.verify_shared_preparation(self.reg,self.descriptor)["client_author_calls"],0)
        original=copy.deepcopy(self.value)
        for case in ("calls","cost","coverage","knowledge","excluded"):
            self.value=copy.deepcopy(original)
            if case=="calls":self.value["client_author_calls"]=1
            elif case=="cost":self.value["new_client_model_cost_usd"]="0.5"
            elif case=="coverage":self.value["tasks"].pop("a")
            elif case=="knowledge":self.value["tasks"]["a"]["knowledge_sha256"]="0"*64
            else:self.value["excluded_costs"]["review"]={"status":"unmeasured","usd":"0"}
            self.seal()
            with self.subTest(case=case),self.assertRaises(ValueError):
                subject.verify_shared_preparation(self.reg,self.descriptor)
        self.value=original;self.seal()
        (self.root/"a/.codescout/system-prompt.md").write_text("reauthored onboarding")
        with self.assertRaises(ValueError):subject.verify_shared_preparation(self.reg,self.descriptor)

class PaidEvidenceBoundaryTests(unittest.TestCase):
    def test_every_concrete_proof_is_required_and_no_ready_flag_can_replace_it(self):
        roles={"population":"verify_population","public_commands":"verify_public_commands",
               "accounting":"verify_accounting","runtime":"verify_runtime",
               "verification":"verify_verification","review":"verify_review",
               "shared_preparation":"verify_shared_preparation"}
        reg={"schema":"evidence-campaign-v1","mode":"paid","tasks":{"a":{"backend":{"scripted_plans":{}}}},
             "admission":{name:{"proof":name} for name in roles}}
        reg["admission"]["credential_path"]="/registered/token"
        from contextlib import ExitStack
        with ExitStack() as stack:
            mocks={name:stack.enter_context(patch.object(subject,function,return_value={"checked":name}))
                   for name,function in roles.items()}
            result=subject.verify_paid(reg)
            self.assertTrue(result["ready"])
            self.assertEqual(set(result["proofs"]),set(roles))
            for name,checker in mocks.items():
                checker.assert_called_once_with(reg,reg["admission"][name])
            mocks["runtime"].side_effect=ValueError("runtime incomplete")
            with self.assertRaisesRegex(ValueError,"runtime incomplete"):subject.verify_paid(reg)
        reg["admission"]={"ready":True}
        with self.assertRaises(ValueError):subject.verify_paid(reg)
class PaidAuthorizationTests(unittest.TestCase):
    """Authorization-only fixtures mock the separate concrete evidence verifier."""
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir="/var/tmp")
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.token=self.root/"token";self.token.write_text("unit placeholder");self.token.chmod(0o600)
        self.reg={"campaign_id":"paid","output_root":str(self.root/"outputs"),"tasks":{},"bindings":{},
                  "admission":{"credential_path":str(self.token)}}
        selected=[{"id":"task"+str(i),"repo":"org/repo"+str(i),"base_commit":"a"*40,
                   "image":"frozen-image","language":"rust","public_issue_sha256":str(i+1)*64,
                   "eligible":True,"reason":"qualified"} for i in range(2)]
        self.reg["schedule"]=attempt_schedule(selected)
        for row in selected:
            source=self.root/row["id"];source.mkdir()
            (source/"source.rs").write_text("baseline")
            self.reg["tasks"][row["id"]]={"source":str(source),"source_sha256":input_digest(source),
                "public_packet":{"issue":"public issue"},"backend":{"public":{"runtime":"frozen"}}}
        bound=self.root/"bound";bound.write_text("fixed")
        self.reg["bindings"][str(bound)]=hashlib.sha256(bound.read_bytes()).hexdigest()
        with patch.object(subject,"verify_paid",return_value={"ready":True}):
            self.admission=subject.PaidAdmission(self.reg,self.token)

    def request(self,index=0,phase="repair"):
        attempt=self.reg["schedule"][index]
        task=self.reg["tasks"][attempt["task_id"]]
        phases=("investigate","repair","challenge") if attempt["arm"] in ("P","R") else ("repair",)
        pos=phases.index(phase)
        request={"attempt_index":index,"task_id":attempt["task_id"],"arm":attempt["arm"],"phase":phase,
                 "invocation_id":"paid::"+str(index)+"::"+phase,"source":task["source"],
                 "state":{"run_id":"paid-"+str(index),"turns_used":0,"baseline_digest":task["source_sha256"]},
                 "allowance_usd":attempt["phase_reservations_usd"][pos] if len(phases)==3 else attempt["reserved_usd"],
                 "cli_cap_usd":attempt["phase_cli_caps_usd"][pos] if len(phases)==3 else attempt["cli_cap_usd"],
                 "effort":"xhigh" if attempt["arm"]=="X" else "low","max_continuations":2,
                 "public_packet":{"issue":"public issue","prior_public_artifacts":[]}}
        out=Path(self.reg["output_root"])/"attempts"/(str(index).zfill(2)+"-"+attempt["arm"])/phase
        out.mkdir(parents=True,exist_ok=True)
        return request,out,task["backend"]["public"]

    def test_exact_authorization_is_single_use_and_cannot_mutate_its_registration(self):
        request,out,public=self.request()
        self.assertEqual(self.admission.authorize(request,out,public,self.token),
                         {"authorized_invocation":"paid::0::repair"})
        with self.assertRaises(ValueError):self.admission.authorize(request,out,public,self.token)
        self.admission.registration["campaign_id"]="changed"
        with self.assertRaises(ValueError):self.admission.authorize(request,out,public,self.token)

    def test_rebound_budget_source_context_effort_and_prior_phase_are_refused(self):
        original,out,public=self.request()
        for key,value in (("attempt_index",True),("cli_cap_usd","99"),("allowance_usd","99"),
                          ("effort","xhigh"),("max_continuations",8),("invocation_id","another")):
            request=copy.deepcopy(original);request[key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):
                self.admission.authorize(request,out,public,self.token)
        request=copy.deepcopy(original);request["public_packet"]["issue"]="private leakage"
        with self.assertRaises(ValueError):self.admission.authorize(request,out,public,self.token)
        request=copy.deepcopy(original);request["state"]["turns_used"]=1
        with self.assertRaises(ValueError):self.admission.authorize(request,out,public,self.token)
        request,out,public=self.request(1,"repair")
        with self.assertRaises(ValueError):self.admission.authorize(request,out,public,self.token)
        Path(next(iter(self.reg["bindings"]))).write_text("drift")
        request,out,public=self.request()
        with self.assertRaises(ValueError):self.admission.authorize(request,out,public,self.token)

    def test_later_phase_uses_exact_settled_candidate_and_public_artifact(self):
        request,out,public=self.request(1,"investigate")
        self.admission.authorize(request,out,public,self.token)
        candidate=self.root/"candidate";candidate.mkdir()
        (candidate/"source.rs").write_text("intermediate repair")
        artifact={"receipt":"public investigation"}
        record={"measurement_invalid":False,"cost_is_final":True,
                "state":{"phase":"repair","turns_used":2},"candidate":str(candidate),
                "source_digest":input_digest(candidate),"public_artifact":artifact}
        (out/"invocation.json").write_text(json.dumps(record))
        request,out,public=self.request(1,"repair")
        request["source"]=str(candidate)
        request["state"]["turns_used"]=2
        request["public_packet"]["prior_public_artifacts"]=[artifact]
        for case in ("source","artifact","unknown"):
            bad=copy.deepcopy(request)
            if case=="source":bad["source"]=self.reg["tasks"][bad["task_id"]]["source"]
            elif case=="artifact":bad["public_packet"]["prior_public_artifacts"]=[]
            else:
                previous=out.parent/"investigate/invocation.json"
                changed=copy.deepcopy(record);changed["cost_is_final"]=False
                previous.write_text(json.dumps(changed))
            with self.subTest(case=case),self.assertRaises(ValueError):
                self.admission.authorize(bad,out,public,self.token)
            (out.parent/"investigate/invocation.json").write_text(json.dumps(record))
        self.assertEqual(self.admission.authorize(request,out,public,self.token)["authorized_invocation"],
                         "paid::1::repair")

    def test_credential_permission_or_path_change_is_rejected_before_use(self):
        self.token.chmod(0o644)
        with patch.object(subject,"verify_paid",return_value={"ready":True}),self.assertRaises(ValueError):
            subject.PaidAdmission(self.reg,self.token)
        request,out,public=self.request()
        with self.assertRaises(ValueError):
            self.admission.authorize(request,out,public,self.root/"other-token")


if __name__=="__main__":
    unittest.main()
