import sys, base64, copy
from pathlib import Path
sys.path.insert(0, sys.argv[1])
import test_grade_policy as T
import grade_policy as P
import multilang_control as C

FX = Path(sys.argv[1]) / "fixtures/multilang"
JSONL = (FX / "nextest_capture.jsonl").read_text()
STDERR = (FX / "nextest_capture.stderr").read_text()
NX_PARSER = (
    "def parser(log):\n"
    "    import json\n"
    "    result = {}\n"
    "    for line in log.splitlines():\n"
    "        event = json.loads(line)\n"
    "        if event.get('type') == 'test' and event.get('event') in ('ok', 'failed'):\n"
    "            result[event['name']] = 'pass' if event['event'] == 'ok' else 'fail'\n"
    "    return result\n")
SEL = "policy_capture_probe::policy_capture_probe$selected_pass"


def show(label, res):
    print(label, "->", {k: res.get(k) for k in ("valid", "pass", "kind", "error")})


_U = object()
def run(label, log, steps_mut=None, raw=_U, record=_U):
    r, full = T.fixture(log)
    if steps_mut: steps_mut(full)
    try:
        show(label, P.adjudicate_private(r if raw is _U else raw, full, T.RECORD if record is _U else record, T.BUNDLE, log=log, runtime=T.OK))
    except Exception as e:
        print(label, "-> EXC", type(e).__name__, e)


def nx(label, tail, log=JSONL, rc=100, selected=SEL, extra_steps=None, print_tails=None):
    import multilang_grade as G
    raw = dict(G.verdict(G.run_parser(NX_PARSER, log), [selected], []), oom_killed=False, container_removed=True)
    steps = [{"name": "grade:test[0]", "returncode": rc, "tail": tail}]
    steps += extra_steps or []
    pts = print_tails or [log]
    for i, t in enumerate(pts):
        steps.append({"name": f"grade:print[{i}]", "returncode": 0, "tail": t})
    full = dict(raw, steps=steps)
    record = dict(T.RECORD, log_parser=NX_PARSER, FAIL_TO_PASS=[selected], PASS_TO_PASS=[],
                  test_cmds=["t"] * sum(1 for s in steps if s["name"].startswith("grade:test")),
                  print_cmds=["p"] * len(pts))
    bundle = {"expected": {"fail_to_pass": 1, "pass_to_pass_kept": 0, "dropped": []}}
    try:
        show(label, P.adjudicate_private(raw, full, record, bundle, log=log, runtime=T.OK))
    except Exception as e:
        print(label, "-> EXC", type(e).__name__, e)


def cut(text, n=4096):
    return C._decode_tail(base64.b64encode(text.encode()).decode())

print("== F1 original probe")
nxt = ("    FAIL [0.010s] crate::ui trybuild_ui\n--- STDERR:              crate::ui trybuild_ui ---\n"
       "error[E0308]: mismatched types\n --> tests/ui/x.rs:3:5\n")
def rc101tail(t):
    def m(full): full["steps"][0].update(returncode=101, tail=t)
    return m
run("F1 PASS_LOG legacy STDERR tail", T.PASS_LOG, rc101tail(nxt))

print("== F2 original probes")
CAP = "---- f stdout ----\n{}\nfailures:\n    f\ntest result: FAILED. 1 passed; 1 failed; 0 ignored; 0 measured; 0 filtered out\n"
def rc101(full): full["steps"][0]["returncode"] = 101
for s in ("write failed: No space left on device", "open /tmp/fixture.txt: Permission denied",
          "rustc: fatal error: terminated with signal 9"):
    run("F2 %r" % s, T.FAIL_LOG + CAP.format(s), rc101)

print("== F4")
for bad in (None, "x", []):
    run("F4 raw=%r" % (bad,), T.PASS_LOG, None, raw=bad)
run("F4 record=[]", T.PASS_LOG, None, record=[])
print("== F5")
run("F5 rebuild_cmds=None", T.PASS_LOG, None, record=dict(T.RECORD, rebuild_cmds=None))

print("== N0 committed fixture, real shape")
nx("N0 fixture tail as-is", STDERR)

print("== N1 nextest indented capture, stderr > 4096 bytes, cut drops header (real record shape)")
pad = "".join(f"    filler line {i:04d} of captured test output\n" for i in range(140))
big = STDERR.replace("    running 1 test\n", "    running 1 test\n" + pad)
t = cut(big)
print("   tail has header:", "output ───" in t, "len", len(t.encode()), "suffix of log:", JSONL.endswith(t))
nx("N1 cut indented capture", t)

print("== N2 legacy nextest (--- STDOUT/STDERR ---, unindented) cut drops header")
legacy = ("    Starting 2 tests across 1 binary\n        PASS [   0.008s] probe selected_pass\n"
          "        FAIL [   0.007s] probe captured_stderr\n"
          "--- STDOUT:              probe captured_stderr ---\n\nrunning 1 test\ntest captured_stderr ... FAILED\n\n"
          "failures:\n\nfailures:\n    captured_stderr\n\ntest result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 1 filtered out; finished in 0.00s\n\n"
          "--- STDERR:              probe captured_stderr ---\n" + "".join(f"log line {i:04d} from the unselected test\n" for i in range(150)) +
          "error[E0308]: mismatched types\n --> tests/ui/x.rs:3:5\n  |\n3 |     let x: u8 = \"s\";\n\n"
          "thread 'captured_stderr' panicked at src/lib.rs:10:5:\ncontrolled unselected test failure\n\n"
          "------------\n     Summary [   0.009s] 2 tests run: 1 passed, 1 failed, 0 skipped\n        FAIL [   0.007s] probe captured_stderr\nerror: test run failed\n")
nx("N2a legacy uncut", legacy)
t = cut(legacy)
print("   tail has STDERR header:", "--- STDERR" in t)
nx("N2b legacy cut (header lost)", t)

print("== N3 legacy STDERR section never terminates: later top-level infra hidden")
leg3 = ("        FAIL [   0.007s] probe captured_stderr\n--- STDERR:              probe captured_stderr ---\n"
        "thread 'captured_stderr' panicked at src/lib.rs:10:5:\nboom\n\n"
        "------------\n     Summary [   0.009s] 2 tests run: 1 passed, 1 failed\n"
        "error: No space left on device (os error 28)\nerror: test run failed\n")
nx("N3 legacy STDERR then storage error", leg3)
ind3 = STDERR + "error: No space left on device (os error 28)\n"
nx("N3b indented (control)", ind3)
leg3c = ("--- STDERR:              probe captured_stderr ---\nboom\n"
         "error[E0425]: cannot find value `y` in this scope\n --> src/lib.rs:3:5\n")
nx("N3c legacy STDERR then col-0 compiler error, rc=101", leg3c, rc=101)
run("N3d libtest stdout capture with no test result line then storage (cargo test log)",
    T.PASS_LOG + "---- f stdout ----\ndata\nerror: No space left on device (os error 28)\n")

print("== N4 multi print_cmds: print[0] tail is not a suffix of the joined log")
cap4 = "---- f stdout ----\n" + "".join(f"captured {i:04d}\n" for i in range(400)) + "write failed: No space left on device\n" \
       "\nfailures:\n    f\n\ntest result: FAILED. 1 passed; 1 failed; 0 ignored; 0 measured; 0 filtered out\n"
part0 = T.FAIL_LOG + cap4
part1 = "summary: done\n"
log4 = part0 + part1
p0tail = base64.b64encode(part0.encode())
p0tail = base64.b64decode(p0tail)[-4096:].decode("utf-8", "replace")
r4, full4 = T.fixture(log4)
full4["steps"] = [{"name": "grade:test[0]", "returncode": 101, "tail": ""},
                  {"name": "grade:print[0]", "returncode": 0, "tail": p0tail},
                  {"name": "grade:print[1]", "returncode": 0, "tail": part1}]
show("N4 two print_cmds, selected real failure", P.adjudicate_private(
    r4, full4, dict(T.RECORD, print_cmds=["cat a", "cat b"]), T.BUNDLE, log=log4, runtime=T.OK))
full4b = copy.deepcopy(full4); full4b["steps"] = [full4["steps"][0], {"name": "grade:print[0]", "returncode": 0, "tail": log4[-4096:]}]
show("N4b one print_cmd (control)", P.adjudicate_private(r4, full4b, T.RECORD, T.BUNDLE, log=log4, runtime=T.OK))

print("== N5 utf-8 cut at every offset around 2/3/4-byte chars (cargo test log, tail suffix path)")
bad = {}
for ch in ("é", "─", "😀"):
    for extra in range(0, 8):
        suffix = ("\nerror[E0425]: printed diagnostic\n --> tests/u.rs:1:1\n"
                  "test result: FAILED. 2 passed; 1 failed; 0 ignored; 0 measured\n")
        padding = "x" * (4095 - len(suffix.encode()) - extra)
        log = T.PASS_LOG + "---- unselected stdout ----\n" + ch * 3 + padding + suffix
        tail = C._decode_tail(base64.b64encode(log.encode()).decode())
        r, full = T.fixture(log)
        full["steps"][0].update(returncode=101, tail=tail)
        res = P.adjudicate_private(r, full, T.RECORD, T.BUNDLE, log=log, runtime=T.OK)
        if not (res["valid"] and res["pass"]):
            bad[(ch, extra)] = (tail[:3], res["kind"], res.get("error"))
print("   failures:", bad or "none")

print("== N6 ANSI escape cut at tail start (CARGO_TERM_COLOR=always)")
suffix = ("\n\x1b[0m\x1b[1m\x1b[38;5;9merror[E0425]\x1b[0m: printed diagnostic\n --> tests/u.rs:1:1\n"
          "test result: FAILED. 2 passed; 1 failed; 0 ignored; 0 measured\n")
for extra in range(0, 6):
    padding = "x" * (4096 - len(suffix.encode()))
    body = "\x1b[1m" + padding[: -extra or None] if extra else padding
    log = T.PASS_LOG + "---- unselected stdout ----\n" + "\x1b[0m\x1b[1m" * 3 + padding + suffix
    blog = log.encode()
    tail = blog[-(4096 + extra):].decode("utf-8", "replace") if False else None
for k in range(1, 6):
    log = T.PASS_LOG + "---- unselected stdout ----\nzz\x1b[38;5;9m" + "y" * 10 + suffix
    tl = log.encode()
    start = tl.index(b"\x1b[38;5;9m") + k
    tail = tl[start:].decode()
    r, full = T.fixture(log)
    full["steps"][0].update(returncode=101, tail=tail)
    show(f"N6 cut {k} bytes into ESC seq tail={tail[:6]!r}", P.adjudicate_private(r, full, T.RECORD, T.BUNDLE, log=log, runtime=T.OK))

print("== N7 CRLF / empty / no newline")
run("N7a CRLF capture + storage in capture", (T.FAIL_LOG + CAP.format("write failed: No space left on device")).replace("\n", "\r\n"), rc101)
run("N7b PASS_LOG no trailing newline", T.PASS_LOG.rstrip("\n"))
def emptytail(full): full["steps"][0].update(returncode=101, tail="")
run("N7c empty tail rc=101 pass log", T.PASS_LOG, emptytail)
nx("N7d indented capture CRLF", STDERR.replace("\n", "\r\n"))

print("== N8 genuine candidate compile failure inside nextest run (stderr only, JSON empty)")
ce = ("   Compiling probe v0.1.0 (/w)\nerror[E0308]: mismatched types\n --> src/lib.rs:3:5\n  |\n3 |     1u8 + \"x\"\n\n"
      "error: could not compile `probe` (lib test) due to 1 previous error\n"
      "error: command `cargo test --no-run --message-format json-render-diagnostics` exited with code 101\n")
nx("N8 compile failure, empty JSON log", ce, log="", rc=101)
big_ce = "   Compiling probe v0.1.0 (/w)\n" + "".join(
    f"error[E0308]: mismatched types\n --> src/lib.rs:{i}:5\n  |\n{i} |     1u8 + \"x\"\n\n" for i in range(1, 200)) + \
    "error: could not compile `probe` (lib test) due to 199 previous errors\n"
nx("N8b compile failure > 4096 bytes cut", cut(big_ce), log="", rc=101)
print("== N9 nextest indented capture: compile error printed after a capture in same stderr (rc=101)")
nx("N9 capture then compile error", STDERR.replace("error: test run failed\n", "") + ce, rc=101)

print("== N10 nested capture: inner cargo test summary inside outer libtest capture")
nest = (T.FAIL_LOG + "---- f stdout ----\nrunning inner\ntest result: ok. 3 passed; 0 failed; 0 ignored\n"
        "open /tmp/fixture.txt: Permission denied\n\nfailures:\n    f\n\ntest result: FAILED. 1 passed; 1 failed; 0 ignored; 0 measured\n")
run("N10 nested summary then captured infra", nest, rc101)

print("== N11 status line glued to capture header")
glued = T.PASS_LOG.replace("test p ... ok\n", "") + "test p ... ok---- f stdout ----\nwrite failed: No space left on device\n" \
        "test result: ok. 2 passed; 0 failed; 0 ignored\n"
run("N11 glued header", glued)

print("== N12 multi test_cmds, second step real build failure, first step nextest capture")
nx("N12 test[1] compile failure", STDERR, rc=100,
   extra_steps=[{"name": "grade:test[1]", "returncode": 101, "tail": ce}])
