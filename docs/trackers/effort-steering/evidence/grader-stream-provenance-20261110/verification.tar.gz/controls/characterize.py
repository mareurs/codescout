"""Bounded offline output characterization; never runs a benchmark task or model."""
import base64
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).parent
IMAGES = {
    "obscura": "sha256:b22988cd6022dd7a428a750799114b9c6f09bcaecc4fd9d8b86a0ef8502772d1",
    "nushell": "sha256:17c4fd82728d1ad59ab92be14ea2e21e213ec4d15f38b9cc700e3ab8d1f38f9e",
    "rust-analyzer": "sha256:db296171bf8540492772e074d08d0bceecfe0e2444dc99ee5b1808781ea1bc7c",
}
MANIFEST = '[package]\nname="stream_probe"\nversion="0.0.0"\nedition="2021"\n'
SOURCE = """
#[test] fn selected_pass() { assert_eq!(2+2,4); }
#[test] fn captured_failure() {
    for i in 0..180 { eprintln!("captured padding line {i:04}................................"); }
    eprintln!("error[E0425]: planted compiler diagnostic\\n --> tests/ui/x.rs:3:5");
    eprintln!("write failed: No space left on device");
    eprintln!("rustc: fatal error: terminated with signal 9");
    panic!("intentional characterization failure");
}
"""
def run(args, timeout=60, **kwargs):
    r = subprocess.run(args, timeout=timeout, capture_output=True, **kwargs)
    return r.returncode, r.stdout, r.stderr
def save(name, rc, out, err, args):
    (ROOT/(name+".stdout")).write_bytes(out)
    (ROOT/(name+".stderr")).write_bytes(err)
    return {"args":args, "returncode":rc, "stdout_bytes":len(out),
            "stderr_bytes":len(err), "stdout_sha256":hashlib.sha256(out).hexdigest(),
            "stderr_sha256":hashlib.sha256(err).hexdigest()}
def docker_args(name, image, probe=False):
    args=["docker","run","--pull","never","--rm","--name",name,
          "--label","effort.owner=codex-01a15ca9","--network","none",
          "--read-only","--cap-drop","ALL","--security-opt","no-new-privileges",
          "--memory","2g","--cpus","1","--tmpfs","/mnt_tmp:ro,noexec,nosuid,nodev,size=1m"]
    if probe:
        args += ["--tmpfs","/probe:rw,exec,nosuid,nodev,size=256m",
                 "--workdir","/probe","-i"]
    args += ["--entrypoint","/bin/bash",image,"-c"]
    return args
def main():
    receipts={}
    for key,image in IMAGES.items():
        name="ep-nextest-char-01a15-"+key
        args=docker_args(name,image)+["cargo nextest --version"]
        rc,out,err=run(args)
        receipts[key]={"image":image,"version":save(key+"-version",rc,out,err,args)}
        if rc==0:
            script=("mkdir -p src\nprintf %s "+__import__("shlex").quote(MANIFEST)+
                    " >Cargo.toml\nprintf %s "+__import__("shlex").quote(SOURCE)+
                    " >src/lib.rs\nNEXTEST_EXPERIMENTAL_LIBTEST_JSON=1 cargo nextest run "
                    "--offline --no-fail-fast --message-format libtest-json-plus --color never\n")
            args=docker_args(name+"-probe",image,True)+["bash"]
            rc,out,err=run(args,timeout=90,input=script.encode())
            receipts[key]["probe"]=save(key+"-probe",rc,out,err,args)
            tail=err[-4096:]
            (ROOT/(key+"-probe.tail")).write_bytes(tail)
            text=err.decode("utf-8","replace")
            receipts[key]["framing"]={
                "modern_output_header":"output ─" in text,
                "modern_stdout_header":"stdout ─" in text,
                "modern_stderr_header":"stderr ─" in text,
                "legacy_header":"--- STDERR:" in text or "--- STDOUT:" in text,
                "tail_keeps_header": any(x in tail.decode("utf-8","replace")
                                        for x in ("output ─","stdout ─","stderr ─","--- STDERR:","--- STDOUT:"))}
        rc,out,err=run(["docker","ps","-aq","--filter","name=^/"+name,"--filter",
                        "label=effort.owner=codex-01a15ca9"])
        receipts[key]["cleanup"]={"query_returncode":rc,"remaining_ids":out.decode().split()}
        (ROOT/"characterization.json").write_text(json.dumps(receipts,indent=2)+"\n")
    print(json.dumps(receipts,indent=2))
if __name__=="__main__":
    main()
