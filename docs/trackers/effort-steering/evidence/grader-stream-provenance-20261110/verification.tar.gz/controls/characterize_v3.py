"""Use a writable scratch TMPDIR too; prior failed controls stay untouched."""
from pathlib import Path
import characterize as original
original.ROOT = Path(__file__).parent / "v3"
original.ROOT.mkdir(exist_ok=False)
original_args = original.docker_args
def docker_args(*args, **kwargs):
    result = [value.replace("/probe:rw,exec,nosuid,nodev,size=256m",
                           "/probe:rw,exec,nosuid,nodev,size=256m,mode=1777")
              for value in original_args(*args, **kwargs)]
    index = result.index("--entrypoint")
    result[index:index] = ["--env", "TMPDIR=/probe"]
    return result
original.docker_args = docker_args
original.main()
