"""Feed actual generated-crate output through unchanged policy, with synthetic selection."""
import base64
import json
from pathlib import Path
import sys
sys.path.insert(0,sys.argv[1])
import grade_policy as P
import multilang_grade as G
import multilang_control as C
import test_grade_policy as T
ROOT=Path(__file__).parent
DATA=ROOT/"v3"
PARSER="""def parser(log):
    import json
    result={}
    for line in log.splitlines():
        if not line.strip(): continue
        event=json.loads(line)
        if event.get('type')=='test' and event.get('event') in ('ok','failed'):
            result[event['name']]='pass' if event['event']=='ok' else 'fail'
    return result
"""
log=(DATA/"obscura-probe.stdout").read_text()
stderr=(DATA/"obscura-probe.stderr").read_text()
receipt=json.loads((DATA/"characterization.json").read_text())["obscura"]
assert receipt["probe"]["returncode"]==100, receipt
observed=G.run_parser(PARSER,log)
assert observed["stream_probe::stream_probe$selected_pass"]=="pass"
assert observed["stream_probe::stream_probe$captured_failure"]=="fail"
results={}
for selected in ("selected_pass","captured_failure"):
    key="stream_probe::stream_probe$"+selected
    raw=dict(G.verdict(observed,[key],[]),oom_killed=False,container_removed=True)
    record=dict(T.RECORD,log_parser=PARSER,FAIL_TO_PASS=[key],PASS_TO_PASS=[],
                test_cmds=["generated nextest characterization only"],print_cmds=["stdout"])
    bundle={"expected":{"fail_to_pass":1,"pass_to_pass_kept":0,"dropped":[]}}
    for mode,tail in (("full",stderr),("tail",C._decode_tail(base64.b64encode(stderr.encode()).decode()))):
        full=dict(raw,steps=[
            {"name":"grade:test[0]","returncode":100,"tail":tail},
            {"name":"grade:print[0]","returncode":0,"tail":log[-4096:]}])
        result=P.adjudicate_private(raw,full,record,bundle,log=log,runtime=T.OK)
        results[selected+"-"+mode]=result
results["scope"]={"generated_crate":True,"benchmark_candidate_regrade":False,
                  "policy_source":"f586d35f4",
                  "nextest_version":"0.9.128",
                  "stderr_bytes":len(stderr.encode()),
                  "tail_header_retained":"output ─" in stderr.encode()[-4096:].decode("utf-8","replace")}
(ROOT/"native-policy-results.json").write_text(json.dumps(results,indent=2)+"\n")
print(json.dumps(results,indent=2))
