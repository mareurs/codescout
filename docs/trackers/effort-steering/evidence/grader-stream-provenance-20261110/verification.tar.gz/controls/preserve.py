"""Preserve only explicitly selected diagnostics and the exact reviewed source."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
ROOT=Path(__file__).parent
WORK=Path("/home/marius/work/claude/codescout/.worktrees/grader-stream-provenance-01a15ca9")
MAIN=Path("/home/marius/work/claude/codescout")
BASE="f586d35f4b0d41768931648dd1a9a33f1cdd450f"
DEST=Path("docs/trackers/effort-steering/evidence/grader-stream-provenance-20261110")
members={}
for directory in (ROOT,ROOT/"v2",ROOT/"v3"):
    for p in sorted(directory.iterdir()):
        if p.is_file() and not p.is_symlink() and p.suffix in {".py",".json",".txt",".stdout",".stderr",".tail"}:
            members["controls/"+p.relative_to(ROOT).as_posix()]=p.read_bytes()
peer=Path("/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/b3485581-2540-4da8-a440-3bed2e9c517f/scratchpad/probes2/probe2.py")
members["peer/probe2.py"]=peer.read_bytes()
for name in ("grade_policy.py","multilang_control.py","test_grade_policy.py"):
    rel="tools/setup-ab-eval/"+name
    source=subprocess.run(["git","show",BASE+":"+rel],cwd=WORK,check=True,capture_output=True).stdout
    assert (WORK/rel).read_bytes()==source, rel
    members["reviewed-source/"+rel]=source
rows=[{"path":p,"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}
      for p,b in sorted(members.items())]
manifest={"source_commit":BASE,"source_modified":False,"llm_calls":0,
          "benchmark_candidate_regrades":0,"independent_new_mutation_replay":False,
          "members":rows}
manifest_bytes=(json.dumps(manifest,indent=2)+"\n").encode()
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode="w:gz") as archive:
    for name,data in sorted(members.items()):
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
        archive.addfile(info,io.BytesIO(data))
payload=buffer.getvalue()
with tarfile.open(fileobj=io.BytesIO(payload),mode="r:gz") as archive:
    actual={m.name:archive.extractfile(m).read() for m in archive.getmembers() if m.isfile()}
assert actual==members
closure={"archive_bytes":len(payload),"archive_sha256":hashlib.sha256(payload).hexdigest(),
         "member_count":len(rows),"all_members_reopened_equal":True,
         "source_commit":BASE,"new_paid_pilot_admitted":False}
for base in (WORK,MAIN):
    dest=base/DEST
    dest.mkdir(parents=True,exist_ok=False)
    (dest/"verification.tar.gz").write_bytes(payload)
    (dest/"manifest.json").write_bytes(manifest_bytes)
    (dest/"closure.json").write_text(json.dumps(closure,indent=2)+"\n")
    assert (dest/"verification.tar.gz").read_bytes()==payload
print(json.dumps(closure,indent=2))
