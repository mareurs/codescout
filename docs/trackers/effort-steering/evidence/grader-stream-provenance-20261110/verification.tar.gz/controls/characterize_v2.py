"""Correct only the scratch tmpfs permissions; preserve v1's failed control."""
from pathlib import Path
import characterize as original
original.ROOT = Path(__file__).parent / "v2"
original.ROOT.mkdir(exist_ok=False)
original_args = original.docker_args
def docker_args(*args, **kwargs):
    result = original_args(*args, **kwargs)
    return [value.replace("/probe:rw,exec,nosuid,nodev,size=256m",
                          "/probe:rw,exec,nosuid,nodev,size=256m,mode=1777")
            for value in result]
original.docker_args = docker_args
original.main()
