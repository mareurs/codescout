import unittest
from pathlib import Path
from unittest.mock import patch
import preparation
from test_preparation import PreparationTests

class EdgeTests(unittest.TestCase):
    setUp = PreparationTests.setUp
    freeze = PreparationTests.freeze

    def test_freeze_late_source_drift(self):
        real = preparation.shutil.copy2
        def copy(src, dst, *args, **kwargs):
            result = real(src, dst, *args, **kwargs)
            if Path(dst) == self.frozen / "rules/global.md":
                (self.source / "lib.rs").write_text("late source drift")
            return result
        with patch.object(preparation.shutil, "copy2", side_effect=copy):
            with self.assertRaisesRegex(ValueError, "preparation input changed"):
                self.freeze()
        self.assertFalse((self.frozen / "manifest.json").exists())

    def test_arm_late_runtime_drift(self):
        self.freeze()
        real = preparation.shutil.copy2
        def copy(src, dst, *args, **kwargs):
            result = real(src, dst, *args, **kwargs)
            if Path(dst) == self.root / "L/global.md":
                self.cli.write_text("late runtime drift")
            return result
        with patch.object(preparation.shutil, "copy2", side_effect=copy):
            with self.assertRaisesRegex(ValueError, "frozen runtime drift"):
                preparation.prepare_arm(self.frozen, "L", self.root / "L")
        self.assertFalse((self.root / "L/arm.json").exists())

    def corrupt_actor_copy(self, part, relative, message):
        self.freeze()
        real = preparation.shutil.copytree
        def copy(src, dst, *args, **kwargs):
            result = real(src, dst, *args, **kwargs)
            if Path(src) == self.frozen / part:
                (Path(dst) / relative).write_text("corrupted copy")
            return result
        with patch.object(preparation.shutil, "copytree", side_effect=copy):
            with self.assertRaisesRegex(ValueError, message):
                preparation.prepare_arm(self.frozen, "L", self.root / "L")
        self.assertFalse((self.root / "L/arm.json").exists())

    def test_actor_source_copy(self):
        self.corrupt_actor_copy("source", "lib.rs", "actor source copy drift")

    def test_actor_knowledge_copy(self):
        self.corrupt_actor_copy("knowledge", "memories/source-architecture.md", "actor knowledge copy drift")

    def test_actor_rules_copy(self):
        self.freeze()
        real = preparation.shutil.copy2
        def copy(src, dst, *args, **kwargs):
            result = real(src, dst, *args, **kwargs)
            if Path(dst) == self.root / "L/global.md":
                Path(dst).write_text("corrupted copy")
            return result
        with patch.object(preparation.shutil, "copy2", side_effect=copy):
            with self.assertRaisesRegex(ValueError, "actor rule copy drift"):
                preparation.prepare_arm(self.frozen, "L", self.root / "L")
        self.assertFalse((self.root / "L/arm.json").exists())

    def test_internal_child_link(self):
        (self.source / "link.rs").symlink_to("lib.rs")
        with self.assertRaisesRegex(ValueError, "symbolic or special input"):
            preparation._tree(self.source)

    def test_frozen_root_link(self):
        self.freeze()
        linked = self.root / "linked-frozen"
        linked.symlink_to(self.frozen, target_is_directory=True)
        with self.assertRaisesRegex(ValueError, "linked frozen root refused"):
            preparation.prepare_arm(linked, "L", self.root / "L")
        self.assertFalse((self.root / "L").exists())
