"""Common-input isolation and fail-before-output controls; no model calls."""
import hashlib
import importlib
import json
from pathlib import Path
import tempfile
import unittest

try:
    preparation = importlib.import_module("preparation")
except ModuleNotFoundError as exc:
    if exc.name != "preparation":
        raise
    preparation = None


class PreparationTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(preparation, "common preparation is not implemented")
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.root = Path(tmp.name)
        self.source = self.root / "public-source"
        self.source.mkdir()
        (self.source / "CLAUDE.md").write_text("Read source and public tests.\n")
        (self.source / "lib.rs").write_text("pub fn public_api() {}\n")
        self.knowledge = self.root / "public-knowledge"
        self.knowledge.mkdir()
        (self.knowledge / "project.toml").write_text('[project]\nlanguages = ["rust"]\n')
        (self.knowledge / "system-prompt.md").write_text("Architecture is in the public source documentation.\n")
        (self.knowledge / "memories").mkdir()
        (self.knowledge / "memories/source-architecture.md").write_text("Copied public architecture documentation.\n")
        self.rules = self.root / "global.md"
        self.rules.write_text("Verify before claiming.\n")
        self.cli = self.root / "cli"
        self.cli.write_text("frozen CLI")
        self.server = self.root / "codescout"
        self.server.write_text("frozen server")
        self.plugin = self.root / "plugin"
        self.plugin.mkdir()
        (self.plugin / "SKILL.md").write_text("Inspect public interfaces before edits.\n")
        self.runtime = {"image": "sha256:" + "a" * 64, "model": "registered-model",
                        "files": {"cli": str(self.cli), "codescout": str(self.server)},
                        "plugin": str(self.plugin)}
        self.frozen = self.root / "frozen"

    def freeze(self, **kwargs):
        return preparation.freeze_preparation(self.source, self.knowledge, self.rules,
                                               self.runtime, self.frozen, **kwargs)

    def test_all_arms_have_identical_initial_inputs_and_frozen_rules(self):
        frozen = self.freeze()
        arms = [preparation.prepare_arm(self.frozen, arm, self.root / arm) for arm in "LRPX"]
        for result in arms:
            self.assertEqual(result["preparation_sha256"], frozen["manifest_sha256"])
            self.assertEqual((Path(result["actor"]) / "lib.rs").read_bytes(), (self.source / "lib.rs").read_bytes())
            self.assertEqual((Path(result["actor"]) / ".codescout/memories/source-architecture.md").read_bytes(),
                             (self.knowledge / "memories/source-architecture.md").read_bytes())
            self.assertEqual(Path(result["global_rules"]).read_bytes(), self.rules.read_bytes())
        self.assertEqual(len({result["actor"] for result in arms}), 4)

    def test_actor_writes_are_physically_independent_for_source_and_knowledge(self):
        self.freeze()
        a = preparation.prepare_arm(self.frozen, "L", self.root / "L")
        b = preparation.prepare_arm(self.frozen, "P", self.root / "P")
        for name in ["lib.rs", ".codescout/memories/source-architecture.md"]:
            left, right = Path(a["actor"]) / name, Path(b["actor"]) / name
            self.assertNotEqual((left.stat().st_dev, left.stat().st_ino),
                                (right.stat().st_dev, right.stat().st_ino))
            old = right.read_bytes()
            left.write_text("actor-private mutation")
            self.assertEqual(right.read_bytes(), old)
        preparation.verify_preparation(self.frozen)

    def test_source_or_knowledge_drift_is_refused_before_output(self):
        self.freeze()
        for index, path in enumerate([self.frozen / "source/lib.rs",
                                      self.frozen / "knowledge/memories/source-architecture.md"]):
            original = path.read_bytes()
            path.write_text("drift")
            destination = self.root / ("drift-" + str(index))
            with self.subTest(path=str(path)), self.assertRaises(ValueError):
                preparation.prepare_arm(self.frozen, "L", destination)
            self.assertFalse(destination.exists())
            path.write_bytes(original)

    def test_rule_drift_inside_snapshot_is_refused_but_home_changes_are_not_loaded(self):
        self.freeze()
        self.rules.write_text("new home rules")
        accepted = preparation.prepare_arm(self.frozen, "L", self.root / "L")
        self.assertEqual(Path(accepted["global_rules"]).read_text(), "Verify before claiming.\n")
        (self.frozen / "rules/global.md").write_text("drift")
        with self.assertRaises(ValueError):
            preparation.prepare_arm(self.frozen, "P", self.root / "P")
        self.assertFalse((self.root / "P").exists())

    def test_runtime_file_or_plugin_drift_refused_before_output(self):
        self.freeze()
        for index, path in enumerate([self.cli, self.server, self.plugin / "SKILL.md"]):
            original = path.read_bytes()
            path.write_text("runtime drift")
            destination = self.root / ("runtime-" + str(index))
            with self.subTest(path=str(path)), self.assertRaises(ValueError):
                preparation.prepare_arm(self.frozen, "X", destination)
            self.assertFalse(destination.exists())
            path.write_bytes(original)

    def test_manifest_relabelled_digest_cannot_hide_input_drift(self):
        self.freeze()
        path = self.frozen / "manifest.json"
        row = json.loads(path.read_text())
        row["preparation_cost_usd"] = "0"
        path.write_text(json.dumps(row))
        with self.assertRaises(ValueError):
            preparation.prepare_arm(self.frozen, "L", self.root / "L")
        self.assertFalse((self.root / "L").exists())

    def test_replay_unknown_arm_and_overlap_fail_before_output(self):
        self.freeze()
        destination = self.root / "L"
        preparation.prepare_arm(self.frozen, "L", destination)
        for arm, path in [("L", destination), ("unknown", self.root / "bad"),
                          ("P", self.frozen / "nested")]:
            with self.subTest(arm=arm, path=str(path)), self.assertRaises(ValueError):
                preparation.prepare_arm(self.frozen, arm, path)
        self.assertEqual((destination / "actor/lib.rs").read_bytes(), (self.source / "lib.rs").read_bytes())
        self.assertFalse((self.root / "bad").exists())
        self.assertFalse((self.frozen / "nested").exists())

    def test_missing_onboarding_or_empty_languages_refused_before_freeze(self):
        (self.knowledge / "system-prompt.md").unlink()
        with self.assertRaises(ValueError):
            self.freeze()
        self.assertFalse(self.frozen.exists())
        (self.knowledge / "system-prompt.md").write_text("Public source guidance.")
        (self.knowledge / "project.toml").write_text("[project]\nlanguages=[]\n")
        with self.assertRaises(ValueError):
            self.freeze()
        self.assertFalse(self.frozen.exists())

    def test_external_links_or_overlapping_freeze_are_refused(self):
        link = self.knowledge / "leak"
        link.symlink_to(self.rules)
        with self.assertRaises(ValueError):
            self.freeze()
        self.assertFalse(self.frozen.exists())
        link.unlink()
        with self.assertRaises(ValueError):
            preparation.freeze_preparation(self.source, self.knowledge, self.rules,
                                           self.runtime, self.source / "nested")
        self.assertFalse((self.source / "nested").exists())

    def test_unknown_charge_is_preserved_and_never_assumed_zero(self):
        unknown = self.freeze()
        self.assertIsNone(unknown["preparation_cost_usd"])
        result = preparation.prepare_arm(self.frozen, "R", self.root / "R")
        self.assertIsNone(result["preparation_cost_usd"])
        other = self.root / "known"
        known = preparation.freeze_preparation(self.source, self.knowledge, self.rules,
                                              self.runtime, other, preparation_cost_usd="0.125")
        self.assertEqual(known["preparation_cost_usd"], "0.125")
