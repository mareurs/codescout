"""Host-only common preparation. No author, backend, provider or grading calls."""
import hashlib
import json
from decimal import Decimal
from pathlib import Path
import re
import shutil
import tomllib

from receipts import input_digest

ARMS = frozenset("LRPX")


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _sha(path):
    path = Path(path)
    _require(not path.is_symlink() and path.is_file(), "regular input file required")
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _tree(path):
    path = Path(path)
    _require(not path.is_symlink() and path.is_dir(), "regular input tree required")
    for child in path.rglob("*"):
        _require(not child.is_symlink() and (child.is_file() or child.is_dir()),
                 "symbolic or special input is not allowed")
    return input_digest(path)


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _destination(path, inputs):
    path = Path(path).resolve()
    _require(not path.exists(), "output path already exists")
    for source in inputs:
        source = Path(source).resolve()
        _require(not path.is_relative_to(source) and not source.is_relative_to(path),
                 "input/output paths overlap")
    return path


def _runtime(runtime):
    _require(isinstance(runtime, dict) and set(runtime) == {"image", "model", "files", "plugin"},
             "runtime contract fields missing or unknown")
    _require(isinstance(runtime["image"], str) and re.fullmatch(r"sha256:[0-9a-f]{64}", runtime["image"]),
             "immutable runtime image required")
    _require(isinstance(runtime["model"], str) and bool(runtime["model"]), "registered model required")
    _require(isinstance(runtime["files"], dict) and set(runtime["files"]) == {"cli", "codescout"},
             "CLI and Codescout runtime files required")
    files = {name: {"path": str(Path(path).resolve()), "sha256": _sha(path)}
             for name, path in runtime["files"].items()}
    plugin = {"path": str(Path(runtime["plugin"]).resolve()), "sha256": _tree(runtime["plugin"])}
    return {"image": runtime["image"], "model": runtime["model"], "files": files, "plugin": plugin}


def _runtime_inputs(record):
    return {"image": record["image"], "model": record["model"],
            "files": {name: entry["path"] for name, entry in record["files"].items()},
            "plugin": record["plugin"]["path"]}


def _knowledge(path):
    digest = _tree(path)
    _require((Path(path) / "system-prompt.md").is_file()
             and bool((Path(path) / "system-prompt.md").read_text().strip()),
             "source guidance is missing")
    config = tomllib.loads((Path(path) / "project.toml").read_text()) if (Path(path) / "project.toml").is_file() else {}
    languages = config.get("project", {}).get("languages")
    _require(isinstance(languages, list) and bool(languages)
             and all(isinstance(value, str) and value for value in languages),
             "configured source languages missing")
    return digest


def freeze_preparation(source, knowledge, global_rules, runtime, out, *, preparation_cost_usd=None):
    source, knowledge, rules = Path(source), Path(knowledge), Path(global_rules)
    _require(not (source / ".codescout").exists() and not (source / ".git").exists(),
             "source must be separate from knowledge and Git runtime state")
    source_digest = _tree(source)
    knowledge_digest = _knowledge(knowledge)
    rules_digest = _sha(rules)
    runtime_facts = _runtime(runtime)
    if preparation_cost_usd is not None:
        charge = Decimal(str(preparation_cost_usd))
        _require(charge.is_finite() and charge >= 0, "invalid preparation charge")
        preparation_cost_usd = str(charge)
    destination = _destination(out, [source, knowledge, rules, runtime["plugin"],
                                     *runtime["files"].values()])
    record = {"schema": 1, "source_digest": source_digest, "knowledge_digest": knowledge_digest,
              "global_rules_sha256": rules_digest, "runtime": runtime_facts,
              "preparation_cost_usd": preparation_cost_usd}
    record["manifest_sha256"] = _digest(record)
    destination.mkdir(parents=True)
    shutil.copytree(source, destination / "source")
    shutil.copytree(knowledge, destination / "knowledge")
    (destination / "rules").mkdir()
    shutil.copy2(rules, destination / "rules/global.md")
    _require(_tree(source) == source_digest and _tree(knowledge) == knowledge_digest
             and _sha(rules) == rules_digest and _runtime(runtime) == runtime_facts,
             "preparation input changed while copying")
    (destination / "manifest.json").write_text(json.dumps(record, indent=2) + "\n")
    verify_preparation(destination)
    return record


def verify_preparation(frozen):
    frozen = Path(frozen)
    _require(not frozen.is_symlink(), "linked frozen root refused")
    record = json.loads((frozen / "manifest.json").read_text())
    _require(isinstance(record, dict) and set(record) == {
        "schema", "source_digest", "knowledge_digest", "global_rules_sha256",
        "runtime", "preparation_cost_usd", "manifest_sha256"}, "preparation manifest fields invalid")
    payload = {name: value for name, value in record.items() if name != "manifest_sha256"}
    _require(record["schema"] == 1 and _digest(payload) == record["manifest_sha256"],
             "preparation manifest digest mismatch")
    _require(_tree(frozen / "source") == record["source_digest"], "frozen source drift")
    _require(_knowledge(frozen / "knowledge") == record["knowledge_digest"], "frozen knowledge drift")
    _require(_sha(frozen / "rules/global.md") == record["global_rules_sha256"], "frozen rule drift")
    _require(_runtime(_runtime_inputs(record["runtime"])) == record["runtime"], "frozen runtime drift")
    return record


def prepare_arm(frozen, arm, out):
    _require(arm in ARMS, "unknown arm")
    record = verify_preparation(frozen)
    destination = _destination(out, [frozen, record["runtime"]["plugin"]["path"],
                                     *(entry["path"] for entry in record["runtime"]["files"].values())])
    destination.mkdir(parents=True)
    actor = destination / "actor"
    shutil.copytree(Path(frozen) / "source", actor)
    _require(_tree(actor) == record["source_digest"], "actor source copy drift")
    shutil.copytree(Path(frozen) / "knowledge", actor / ".codescout")
    _require(_tree(actor / ".codescout") == record["knowledge_digest"], "actor knowledge copy drift")
    shutil.copy2(Path(frozen) / "rules/global.md", destination / "global.md")
    _require(_sha(destination / "global.md") == record["global_rules_sha256"], "actor rule copy drift")
    verify_preparation(frozen)
    result = {"arm": arm, "actor": str(actor.resolve()), "global_rules": str((destination / "global.md").resolve()),
              "preparation_sha256": record["manifest_sha256"], "runtime": record["runtime"],
              "preparation_cost_usd": record["preparation_cost_usd"]}
    (destination / "arm.json").write_text(json.dumps(result, indent=2) + "\n")
    return result
