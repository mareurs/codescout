"""Preserve stopped preparation evidence; verify every archived file against bytes/mode."""
from pathlib import Path
import hashlib,json,stat,tarfile
from preparation import verify_preparation
ROOT=Path('/home/marius/.cache/codescout-resident/codescout/common-preparation-20261109')
DEST=Path('/home/marius/work/claude/codescout/docs/trackers/effort-steering/evidence/common-native-final-20261109')
SOURCE=Path('/home/marius/.codex/worktrees/cf66/codescout/tools/effort_protocol')
def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
    return h.hexdigest()
def build(target,entries):
    assert not target.exists()
    manifest=[]
    names=set()
    for path,name in sorted(entries,key=lambda row:row[1]):
        assert path.is_file() and not path.is_symlink() and name not in names
        names.add(name)
        manifest.append({'path':name,'bytes':path.stat().st_size,
                         'mode':stat.S_IMODE(path.stat().st_mode),'sha256':digest(path)})
    with tarfile.open(target,'w:gz',dereference=True) as archive:
        for path,name in sorted(entries,key=lambda row:row[1]):
            archive.add(path,arcname=name,recursive=False)
    by_name={row['path']:row for row in manifest}
    with tarfile.open(target,'r:gz') as archive:
        members=archive.getmembers()
        assert len(members)==len(by_name)
        for member in members:
            assert member.isfile()
            row=by_name.pop(member.name)
            assert member.mode==row['mode'] and member.size==row['bytes']
            assert hashlib.sha256(archive.extractfile(member).read()).hexdigest()==row['sha256']
        assert not by_name
    for path,name in entries:
        row=next(row for row in manifest if row['path']==name)
        assert digest(path)==row['sha256'] and stat.S_IMODE(path.stat().st_mode)==row['mode']
    return {'archive':str(target),'bytes':target.stat().st_size,'sha256':digest(target),
            'regular_file_count':len(manifest),'entries':manifest}
def collect(folder,prefix):
    return [(p,prefix+'/'+str(p.relative_to(folder))) for p in folder.rglob('*')
            if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts]
def main():
    for path in ['coderank-infrastructure-cleanup.json','coderank-proof-infrastructure-cleanup.json']:
        assert json.loads((ROOT/path).read_text())['complete']
    verify_preparation(ROOT/'common-frozen-v2')
    DEST.mkdir(parents=True,exist_ok=False)
    entries=[(p,'protocol/'+p.name) for p in SOURCE.glob('*.py')]
    entries += [(p,'capture/'+p.name) for p in ROOT.iterdir() if p.is_file()]
    for name in ['review','relay-review','readiness-primary-review','readiness-empty-review']:
        entries += collect(ROOT/name,'capture/'+name)
    for name in ['onboarding','index-and-readiness','post-timeout-native-audit','minilm-index-and-readiness',
                 'coderank-index-and-readiness','coderank-proof-index-and-readiness']:
        entries += [(p,'capture/'+name+'/'+p.name) for p in (ROOT/name).iterdir() if p.is_file()]
    compact=build(DEST/'source-and-native-evidence.tar.gz',entries)
    full=build(ROOT/'frozen-preparation.tar.gz',
               collect(ROOT/'common-frozen-v2','prepared')+
               collect(ROOT/'project-coderank-proof/.git','public-git-seed'))
    verify_preparation(ROOT/'common-frozen-v2')
    record={'schema':1,'scope':'closed source/native development preparation and public Git seed; transitive runtime not a self-contained closure',
            'protocol_source_files':len(list(SOURCE.glob('*.py'))),
            'compact':compact,'frozen':full,
            'no_paid_admission':True}
    (DEST/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({k:{field:value[field] for field in ['archive','bytes','sha256','regular_file_count']}
                      for k,value in [('compact',compact),('frozen',full)]}))
if __name__=='__main__':main()
