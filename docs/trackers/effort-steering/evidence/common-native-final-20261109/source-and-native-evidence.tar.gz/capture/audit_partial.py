from pathlib import Path
import json, shutil
from prepare_native import ROOT, IMAGE, Native, save, emit
from native_executor import _public_digest
from receipts import input_digest

def main():
    snapshot=ROOT/'stopped-partial-knowledge'
    assert not snapshot.exists()
    shutil.copytree(ROOT/'project/.codescout',snapshot,symlinks=True)
    save(ROOT/'partial-store-snapshot.json',{'path':str(snapshot),'digest':input_digest(snapshot),'scope':'stopped post-timeout knowledge; not qualified complete'})
    cfg=json.loads(Path('/tmp/effort-native-cli-config-20261109-01a15ca9.json').read_text())
    cfg.update(native_image=IMAGE,runtime_manifest=str(ROOT/'native-runtime.json'))
    native=Native('post-timeout-native-audit',ROOT/'project',cfg)
    try:
        native.start()
        status=native.tool('workspace',{'action':'status'})
        verification=native.tool('index',{'action':'verify'},timeout=240)
        save(ROOT/'partial-native-status.json',status)
        save(ROOT/'partial-native-index-verification.json',verification)
        emit('partial-native-index-verification',response=verification)
        tools=[]; cursor=None
        while True:
            page=native.rpc('tools/list',{'cursor':cursor} if cursor else {})
            tools.extend(item['name'] for item in page['result']['tools'])
            cursor=page['result'].get('nextCursor')
            if not cursor:break
        observations=[]
        for tool,args in [
            ('references',{'path':'crates/stdx/src/lib.rs','symbol':'to_snake_case'}),
            ('symbol_at',{'path':'crates/stdx/src/lib.rs','line':95,'col':5}),
            ('call_graph',{'path':'crates/stdx/src/lib.rs','symbol':'to_snake_case','direction':'callers'}),
            ('semantic_search',{'query':'to_snake_case identifier transformation','limit':5})]:
            try:
                response=native.tool(tool,args,timeout=240)
                observations.append({'tool':tool,'arguments':args,'response':response})
            except Exception as exc:
                observations.append({'tool':tool,'arguments':args,'error':type(exc).__name__+': '+str(exc)})
            save(ROOT/'partial-native-operations.json',observations)
            emit('operation-complete',tool=tool,error=observations[-1].get('error'))
        save(ROOT/'partial-audit-result.json',{'tools':tools,'operations':observations,'prepared_public_digest':_public_digest(ROOT/'project'),'paid_ready':False,'scope':'diagnostic queries only; no onboarding or index command'})
    finally:
        native.close()

if __name__=='__main__':
    main()
