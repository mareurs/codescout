"""A separate CPU embedding profile; reuse onboarding/docs, never model outcomes."""
from pathlib import Path
import hashlib,json,re,shutil,time,subprocess
from prepare_native import ROOT,IMAGE,Native,save,emit
from native_executor import _public_digest
from receipts import input_digest
from readiness import validate_readiness

def main():
    previous=ROOT/'project'
    project=ROOT/'project-minilm'
    assert not project.exists()
    def skip(src,names):
        return {'embeddings','index-state.json'} & set(names) if Path(src)==previous/'.codescout' else set()
    shutil.copytree(previous,project,symlinks=True,ignore=skip)
    config=project/'.codescout/project.toml'
    text,count=re.subn(r'(?ms)^\[embeddings\].*?(?=^\[|\Z)',
                      '[embeddings]\nmodel = "local:AllMiniLML6V2Q"\n\n',config.read_text())
    assert count==1
    config.write_text(text)
    actual_source=_public_digest(project)
    assert actual_source=='44ad1034c6c570c2f998cfcf48e15f9556cc3f115608dfd9b261bb38bf29d40d'
    cfg=json.loads(Path('/tmp/effort-native-cli-config-20261109-01a15ca9.json').read_text())
    cfg.update(native_image=IMAGE,runtime_manifest=str(ROOT/'native-runtime.json'))
    save(ROOT/'minilm-profile.json',{'embedding_model':'local:AllMiniLML6V2Q','dimensions':384,
        'source_digest':actual_source,'model_cache':'/home/marius/.cache/codescout/fastembed/models--Xenova--all-MiniLM-L6-v2',
        'programmatic_onboarding_calls':0,'onboarding_author_calls':0,'provider_calls':0,
        'origin':'existing source-only preparation and four verbatim public docs; Jina partial store excluded and preserved',
        'scope':'new preparation profile shared by all eventual arms; no repair outcome or efficacy tuning'})
    native=Native('minilm-index-and-readiness',project,cfg)
    try:
        native.start()
        emit('minilm-index-start',source_digest=actual_source)
        start=time.monotonic()
        argv=['docker','exec',native.cid,'/bench/bin/codescout','index','-p','/testbed','--force']
        try:
            indexed=subprocess.run(argv,capture_output=True,text=True,timeout=1800)
        except subprocess.TimeoutExpired as exc:
            (ROOT/'minilm-index.stdout').write_bytes(exc.stdout or b'')
            (ROOT/'minilm-index.stderr').write_bytes(exc.stderr or b'')
            save(ROOT/'minilm-index-result.json',{'error':'TimeoutExpired','wall_s':time.monotonic()-start})
            raise
        (ROOT/'minilm-index.stdout').write_text(indexed.stdout)
        (ROOT/'minilm-index.stderr').write_text(indexed.stderr)
        save(ROOT/'minilm-index-result.json',{'exit_code':indexed.returncode,'wall_s':time.monotonic()-start})
        assert indexed.returncode==0,indexed.stderr
        emit('minilm-index-complete',seconds=time.monotonic()-start)
        # The copied public memories must be in the recall store too.
        migrated=subprocess.run(['docker','exec',native.cid,'/bench/bin/codescout','migrate-memories','--in-place'],
                                capture_output=True,text=True,timeout=300)
        (ROOT/'minilm-memory.stdout').write_text(migrated.stdout)
        (ROOT/'minilm-memory.stderr').write_text(migrated.stderr)
        save(ROOT/'minilm-memory-result.json',{'exit_code':migrated.returncode})
        assert migrated.returncode==0,migrated.stderr
        pages=[];cursor=None
        while True:
            page=native.rpc('tools/list',{'cursor':cursor} if cursor else {})
            page['cursor']=cursor;pages.append(page)
            cursor=page['result'].get('nextCursor')
            if not cursor:break
        status=native.tool('workspace',{'action':'status'})
        specs=[
            {'tool':'references','arguments':{'path':'crates/stdx/src/lib.rs','symbol':'to_snake_case'},'must_contain':['to_lower_snake_case','to_upper_snake_case']},
            {'tool':'symbol_at','arguments':{'path':'crates/stdx/src/lib.rs','line':95,'col':5},'must_contain':['to_snake_case']},
            {'tool':'call_graph','arguments':{'path':'crates/stdx/src/lib.rs','symbol':'to_snake_case','direction':'callers'},'must_contain':['to_lower_snake_case','to_upper_snake_case','lsp']},
            {'tool':'semantic_search','arguments':{'query':'to_snake_case identifier transformation','limit':5},'must_contain':['crates/stdx/src/lib.rs']}]
        observations=[{'tool':spec['tool'],'arguments':spec['arguments'],'response':native.tool(spec['tool'],spec['arguments'],timeout=240)} for spec in specs]
        static=['project.toml','system-prompt.md']+[str(p.relative_to(project/'.codescout')) for p in sorted((project/'.codescout/memories').glob('*.md'))]
        binding={'image':IMAGE,'executable_sha256':subprocess.check_output(['docker','exec',native.cid,'sha256sum','/bench/bin/codescout'],text=True).split()[0],
                 'source_snapshot_sha256':_public_digest(project),'knowledge_sha256':input_digest(project/'.codescout',static)}
        assert binding['source_snapshot_sha256']==actual_source
        expected={'project_root':'/testbed','languages':['rust'],'tools':['symbols','references','symbol_at','call_graph','semantic_search'],'binding':binding,'probes':specs}
        wire={'binding':binding,'status':status,'tool_pages':pages,'probes':observations,'index_verification':native.tool('index',{'action':'verify'},timeout=240)}
        save(ROOT/'minilm-readiness-raw.json',{'expected':expected,'wire':wire})
        result=validate_readiness(expected,wire)
        save(ROOT/'minilm-readiness-result.json',result)
        emit('minilm-readiness-complete',tools=len(result['tools']),probes=result['probes_verified'])
    finally:
        native.close()
    save(ROOT/'minilm-preparation-result.json',{'paid_ready':False,'source_digest':actual_source,
        'programmatic_onboarding_calls':0,'onboarding_author_calls':0,'model_cost_usd':'0',
        'scope':'new embedding profile; real arm clone/context qualification pending'})
    emit('minilm-preparation-complete')

if __name__=='__main__':
    main()
