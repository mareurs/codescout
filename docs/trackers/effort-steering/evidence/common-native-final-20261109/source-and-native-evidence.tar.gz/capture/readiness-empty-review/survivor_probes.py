import sys,copy,json,unittest
from pathlib import Path
from unittest.mock import patch
folder=Path(sys.argv.pop(1));sys.path.insert(0,str(folder))
import readiness
import test_readiness as fixtures
class SurvivorTests(unittest.TestCase):
 def setUp(self):
  helper=fixtures.ReadinessTests('test_verified_empty_omissions_are_reported_without_rewriting_native_verdict')
  self.addCleanup(helper.doCleanups)
  self.source,self.expected,self.wire,self.value=helper.empty_case()
 def test_source_before(self):
  target=self.source/'src/lib.rs';original=target.read_bytes();target.write_bytes(b'changed before verification')
  verify=readiness._verify_index
  def restore_then_verify(*args,**kwargs):
   target.write_bytes(original)
   return verify(*args,**kwargs)
  with patch.object(readiness,'_verify_index',side_effect=restore_then_verify):
   with self.assertRaises(readiness.ReadinessViolation):
    readiness.validate_readiness(self.expected,self.wire,source=self.source)
 def test_source_after(self):
  verify=readiness._verify_index
  def verify_then_change(*args,**kwargs):
   result=verify(*args,**kwargs)
   (self.source/'src/lib.rs').write_bytes(b'changed during verification')
   return result
  with patch.object(readiness,'_verify_index',side_effect=verify_then_change):
   with self.assertRaises(readiness.ReadinessViolation):
    readiness.validate_readiness(self.expected,self.wire,source=self.source)
 def test_root_link(self):
  alias=self.source.parent/'alias';alias.symlink_to(self.source.parent,target_is_directory=True)
  linked_source=alias/'source'
  self.assertFalse(linked_source.is_symlink())
  self.assertEqual(readiness._public_digest(linked_source),self.expected['binding']['source_snapshot_sha256'])
  with self.assertRaises(readiness.ReadinessViolation):
   readiness.validate_readiness(self.expected,self.wire,source=linked_source)
 def test_memory_counts(self):
  for key in ['missing_count','orphan_count']:
   with self.subTest(key=key):
    value=copy.deepcopy(self.value);value['memories'][key]=1
    self.wire['index_verification']=fixtures.reply(json.dumps(value))
    with self.assertRaises(readiness.ReadinessViolation):
     readiness.validate_readiness(self.expected,self.wire,source=self.source)
if __name__=='__main__':unittest.main()
