from pathlib import Path
import json,hashlib,subprocess,difflib,os,re
root=Path(__file__).parent;src=Path('/home/marius/.codex/worktrees/cf66/codescout/tools/effort_protocol')
files={n:(src/n).read_bytes() for n in ['readiness.py','test_readiness.py']}
source=files['readiness.py'].decode();sha=lambda data:hashlib.sha256(data).hexdigest()
(root/'original').mkdir(exist_ok=True)
for n,data in files.items():(root/'original'/n).write_bytes(data)
(root/'source-hashes.json').write_text(json.dumps({n:sha(data) for n,data in files.items()},indent=2)+'\n')
mutations=[
('nonempty','stat.S_ISREG(info.st_mode) and info.st_size == 0\n                         and target.read_bytes() == b""','stat.S_ISREG(info.st_mode)'),
('coverage_count','and stored + missing == expected',''),
('sample_complete','isinstance(names, list) and len(names) == missing\n                 and all(isinstance(name, str) for name in names)\n                 and len(set(names)) == missing','isinstance(names, list)\n                 and all(isinstance(name, str) for name in names)\n                 and len(set(names)) == len(names)'),
('sample_unique','and len(set(names)) == missing',''),
('path_link','_require(not target.is_symlink(), "linked missing path refused")','pass'),
('canonical_path','not relative.is_absolute() and bool(relative.parts)\n                     and relative.as_posix() == name and ".." not in relative.parts','True'),
('source_before','_require(_public_digest(source) == binding["source_snapshot_sha256"], "actual public source mismatch")','pass'),
('source_after','_require(_public_digest(source) == binding["source_snapshot_sha256"], "source changed during verification")','pass'),
('root_link','all(not part.is_symlink() for part in [root, *root.parents])','True'),
('memory_counts','type(memories.get(key)) is int and memories[key] == 0','True'),
('other_counts','type(value.get(key)) is int and value[key] == 0','True'),
]
env=dict(os.environ,PYTHONPATH=str(src));rows=[];nonmatching=[]
def run(name,code):
 folder=root/name;folder.mkdir(exist_ok=True)
 for n,data in files.items():(folder/n).write_bytes(data)
 (folder/'readiness.py').write_text(code);(folder/'mutant.py').write_text(code)
 (folder/'mutation.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True),code.splitlines(True),fromfile='original/readiness.py',tofile=name+'/readiness.py')))
 try:
  p=subprocess.run(['python3','-B','-m','unittest','-v','test_readiness'],cwd=folder,env=env,capture_output=True,text=True,timeout=20)
  (folder/'suite.stdout').write_text(p.stdout);(folder/'suite.stderr').write_text(p.stderr);(folder/'suite.exit').write_text(str(p.returncode)+'\n')
  return {'name':name,'exit':p.returncode,'summary':re.findall(r'^Ran .*|^OK.*|^FAILED .*',p.stderr,re.M),'assertions':re.findall(r'^AssertionError:.*',p.stderr,re.M),'errors':re.findall(r'^ERROR:.*',p.stderr,re.M)}
 finally:(folder/'readiness.py').write_bytes(files['readiness.py'])
for name,code in [('baseline',source)]:rows.append(run(name,code));print(json.dumps(rows[-1]),flush=True)
for name,before,after in mutations:
 matches=source.count(before)
 if matches!=1:nonmatching.append({'name':name,'matches':matches,'anchor':before});continue
 rows.append(run(name,source.replace(before,after)));print(json.dumps(rows[-1]),flush=True)
rows.append(run('restored_control',source));print(json.dumps(rows[-1]),flush=True)
(root/'mutation-results.json').write_text(json.dumps(rows,indent=2)+'\n');(root/'nonmatching.json').write_text(json.dumps(nonmatching,indent=2)+'\n');print(json.dumps({'nonmatching':nonmatching}),flush=True)
