from pathlib import Path
import tempfile
from native_executor import _public_digest
"""Admission checks consume host-captured MCP replies, not actor assertions."""
import copy
import importlib
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
try:
    readiness = importlib.import_module("readiness")
except ModuleNotFoundError as exc:
    if exc.name != "readiness":
        raise
    readiness = None

def reply(text, **extra):
    return {"result": {"content": [{"type": "text", "text": text}], "isError": False, **extra}}

def fixture():
    expected = {"project_root": "/testbed", "languages": ["rust"],
                "tools": ["symbols", "references", "symbol_at", "call_graph", "semantic_search"],
                "binding": {"image": "sha256:" + "a"*64, "executable_sha256": "b"*64,
                            "source_snapshot_sha256": "c"*64, "knowledge_sha256": "d"*64},
                "probes": [{"tool": "references", "arguments": {"path": "src/lib.rs", "symbol": "double"},
                            "must_contain": ["use_double", "src/lib.rs"]},
                           {"tool": "symbol_at", "arguments": {"path": "src/lib.rs", "line": 2, "col": 34},
                            "must_contain": ["pub fn double"]},
                           {"tool": "call_graph", "arguments": {"path": "src/lib.rs", "symbol": "double", "direction": "callers"},
                            "must_contain": ["use_double", "lsp"]},
                           {"tool": "semantic_search", "arguments": {"query": "double the input"},
                            "must_contain": ["src/lib.rs", "double"]}]}
    wire = {"index_verification": reply(json.dumps({"verdict": "complete", "expected_files": 3,
                "stored_files": 3, "missing_count": 0, "orphan_count": 0, "chunks_without_vectors": 0,
                "memories": {"missing_count": 0, "orphan_count": 0}})),
            "binding": copy.deepcopy(expected["binding"]),
            "status": reply(json.dumps({"project_root": "/testbed", "languages": ["rust"]})),
            "tool_pages": [{"result": {"tools": [{"name": n} for n in expected["tools"]]}}],
            "probes": [{**copy.deepcopy({k: p[k] for k in ("tool", "arguments")}),
                        "response": reply(" ".join(p["must_contain"]))} for p in expected["probes"]]}
    return expected, wire

class ReadinessTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(readiness, "readiness admission boundary is not implemented")
        self.expected, self.wire = fixture()

    def reject(self):
        with self.assertRaises(readiness.ReadinessViolation):
            readiness.validate_readiness(self.expected, self.wire)

    def test_complete_host_wire_is_admitted_without_mutating_inputs(self):
        before = copy.deepcopy(self.wire)
        result = readiness.validate_readiness(self.expected, self.wire)
        self.assertTrue(result["ready"])
        self.assertEqual(self.wire, before)

    def test_empty_languages_are_rejected_even_with_all_tool_names(self):
        self.wire["status"] = reply(json.dumps({"project_root": "/testbed", "languages": []}))
        self.reject()

    def test_another_language_does_not_satisfy_rust_project(self):
        self.wire["status"] = reply(json.dumps({"project_root": "/testbed", "languages": ["python"]}))
        self.reject()

    def test_wrong_active_root_is_rejected(self):
        self.wire["status"] = reply(json.dumps({"project_root": "/tmp", "languages": ["rust"]}))
        self.reject()

    def test_each_missing_lsp_tool_is_rejected(self):
        for name in ("references", "symbol_at", "call_graph"):
            with self.subTest(name=name):
                self.expected, self.wire = fixture()
                self.wire["tool_pages"][0]["result"]["tools"] = [
                    t for t in self.wire["tool_pages"][0]["result"]["tools"] if t["name"] != name]
                self.reject()

    def test_unconsumed_pagination_is_rejected(self):
        self.wire["tool_pages"][0]["result"]["nextCursor"] = "more"
        self.reject()

    def test_listed_tool_with_failed_actual_call_is_rejected(self):
        self.wire["probes"][0]["response"]["result"]["isError"] = True
        self.reject()

    def test_nested_false_success_payload_is_rejected(self):
        self.wire["probes"][0]["response"] = reply(json.dumps({"ok": False, "text": "src/lib.rs use_double"}))
        self.reject()

    def test_empty_reference_result_is_not_readiness(self):
        self.wire["probes"][0]["response"] = reply("0 references")
        self.reject()

    def test_semantic_search_must_find_the_public_canary(self):
        self.wire["probes"][-1]["response"] = reply("[]")
        self.reject()

    def test_wrong_actual_arguments_are_rejected(self):
        self.wire["probes"][0]["arguments"]["symbol"] = "another"
        self.reject()

    def test_missing_probe_cannot_be_replaced_by_ready_boolean(self):
        self.wire["probes"].pop()
        self.wire["ready"] = True
        self.reject()

    def test_each_runtime_binding_dimension_is_required(self):
        for field in self.expected["binding"]:
            with self.subTest(field=field):
                self.expected, self.wire = fixture()
                self.wire["binding"][field] = "e"*64
                self.reject()

    def test_empty_expectations_cannot_make_an_unprepared_project_pass(self):
        self.expected["probes"] = []
        self.expected["languages"] = []
        self.expected["tools"] = []
        self.wire["probes"] = []
        self.reject()

    def test_missing_native_index_verification_is_rejected(self):
        self.wire.pop("index_verification", None)
        self.reject()

    def test_one_semantic_hit_does_not_override_incomplete_index(self):
        self.wire["index_verification"] = reply(json.dumps({
            "verdict": "incomplete", "expected_files": 3, "stored_files": 2,
            "missing_count": 1, "orphan_count": 0, "chunks_without_vectors": 0,
            "memories": {"missing_count": 0, "orphan_count": 0}}))
        self.reject()

    def test_missing_vectors_are_rejected_even_with_complete_label(self):
        self.wire["index_verification"] = reply(json.dumps({
            "verdict": "complete", "expected_files": 3, "stored_files": 3,
            "missing_count": 0, "orphan_count": 0, "chunks_without_vectors": 1,
            "memories": {"missing_count": 0, "orphan_count": 0}}))
        self.reject()

    def test_supplemental_guidance_cannot_supply_operation_witness(self):
        for index in range(4):
            with self.subTest(tool_index=index):
                self.expected, self.wire = fixture()
                result = self.wire["probes"][index]["response"]["result"]
                positive = result["content"][0]["text"]
                result["content"] = [
                    {"type": "text", "text": "No operation results"},
                    {"type": "text", "text": "<!-- auto-injected guide --> " + positive}]
                self.reject()

    def empty_case(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        source = Path(temp.name) / "source"
        (source / "src").mkdir(parents=True)
        (source / "src/lib.rs").write_text("pub fn double(x: i32) -> i32 { x * 2 }")
        for name in ["one.rs", "two.rs"]:
            (source / name).write_bytes(b"")
        expected, wire = fixture()
        expected["binding"]["source_snapshot_sha256"] = _public_digest(source)
        wire["binding"] = copy.deepcopy(expected["binding"])
        value = {"verdict": "incomplete", "expected_files": 3, "stored_files": 1,
                 "missing_count": 2, "missing_sample": ["one.rs", "two.rs"],
                 "orphan_count": 0, "chunks_without_vectors": 0,
                 "memories": {"missing_count": 0, "orphan_count": 0}}
        wire["index_verification"] = reply(json.dumps(value))
        return source, expected, wire, value

    def test_verified_empty_omissions_are_reported_without_rewriting_native_verdict(self):
        source, expected, wire, _ = self.empty_case()
        before = copy.deepcopy(wire)
        result = readiness.validate_readiness(expected, wire, source=source)
        self.assertTrue(result["ready"])
        coverage = result["index_coverage"]
        self.assertEqual(coverage["native_verdict"], "incomplete")
        self.assertEqual(coverage["coverage"], "all_nonempty_eligible_files")
        self.assertEqual([x["path"] for x in coverage["empty_missing_files"]], ["one.rs", "two.rs"])
        self.assertEqual(coverage["stored_files"], 1)
        self.assertEqual(wire, before)

    def test_empty_omissions_still_require_opt_in_actual_source(self):
        _, expected, wire, _ = self.empty_case()
        with self.assertRaises(readiness.ReadinessViolation):
            readiness.validate_readiness(expected, wire)

    def test_nonempty_missing_file_refused_even_with_current_source_binding(self):
        source, expected, wire, _ = self.empty_case()
        (source / "one.rs").write_text("pub fn missing() {}")
        expected["binding"]["source_snapshot_sha256"] = _public_digest(source)
        wire["binding"] = copy.deepcopy(expected["binding"])
        with self.assertRaises(readiness.ReadinessViolation):
            readiness.validate_readiness(expected, wire, source=source)

    def test_omission_population_must_be_complete_unique_and_in_root(self):
        for missing in [["one.rs"], ["one.rs", "one.rs"], ["../outside.rs", "two.rs"]]:
            with self.subTest(missing=missing):
                source, expected, wire, value = self.empty_case()
                (source.parent / "outside.rs").write_bytes(b"")
                value["missing_sample"] = missing
                wire["index_verification"] = reply(json.dumps(value))
                with self.assertRaises(readiness.ReadinessViolation):
                    readiness.validate_readiness(expected, wire, source=source)

    def test_linked_empty_omission_refused(self):
        source, expected, wire, _ = self.empty_case()
        (source / "one.rs").unlink()
        (source / "one.rs").symlink_to(source / "two.rs")
        expected["binding"]["source_snapshot_sha256"] = _public_digest(source)
        wire["binding"] = copy.deepcopy(expected["binding"])
        with self.assertRaises(readiness.ReadinessViolation):
            readiness.validate_readiness(expected, wire, source=source)

    def test_actual_source_drift_refused(self):
        source, expected, wire, _ = self.empty_case()
        (source / "src/lib.rs").write_text("changed")
        with self.assertRaises(readiness.ReadinessViolation):
            readiness.validate_readiness(expected, wire, source=source)

    def test_empty_interpretation_cannot_hide_vector_or_count_failure(self):
        for key, value in [("chunks_without_vectors", 1), ("stored_files", 2), ("orphan_count", 1)]:
            with self.subTest(key=key):
                source, expected, wire, report = self.empty_case()
                report[key] = value
                wire["index_verification"] = reply(json.dumps(report))
                with self.assertRaises(readiness.ReadinessViolation):
                    readiness.validate_readiness(expected, wire, source=source)

if __name__ == "__main__":
    unittest.main()
