"""No-index native continuation; preserved original attempt remains unchanged."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess,time,uuid
import prepare_native
from prepare_native import ROOT,IMAGE,Native,save,emit
from native_executor import _public_digest
from receipts import input_digest
from readiness import validate_readiness
import executor
LIVE_RELAY=Path('/home/marius/.codex/worktrees/cf66/codescout/tools/effort_protocol/embedding_relay.py')
UPSTREAM_NETWORK='codescout-retrieval_retrieval_net'

def main():
    original=ROOT/'project-coderank'
    assert json.loads((ROOT/'coderank-infrastructure-cleanup.json').read_text())['complete']
    assert json.loads((ROOT/'coderank-index-result.json').read_text())['exit_code']==0
    project=ROOT/'project-coderank-proof'
    assert not project.exists()
    shutil.copytree(original,project)
    knowledge=project/'.codescout'
    actual_source=_public_digest(project)
    assert actual_source=='44ad1034c6c570c2f998cfcf48e15f9556cc3f115608dfd9b261bb38bf29d40d'
    runtime=ROOT/'coderank-proof-relay-runtime'
    runtime.mkdir()
    relay_path=runtime/'embedding_relay.py'
    shutil.copy2(LIVE_RELAY,relay_path)
    suffix=uuid.uuid4().hex
    network='ep-source-embed-'+suffix
    proxy_name='ep-source-relay-'+suffix
    proxy=None;native=None
    profile={'embedding_model':'CodeRankEmbed','dimensions':768,'source_digest':actual_source,
        'source_only_onboarding_reused':True,'additional_onboarding_calls':0,
        'repair_or_author_llm_calls':0,'embedding_compute_cost_usd':None,
        'relay_source_sha256':hashlib.sha256(relay_path.read_bytes()).hexdigest(),
        'upstream_service':json.loads((ROOT/'existing-dense-service.json').read_text()),
        'scope':'separate shared source-only preparation profile; no paid/repair outcome'}
    try:
        made=executor._docker(['network','create','--internal','--label',executor.LABEL+'='+proxy_name,network])
        assert made.returncode==0,made.stderr
        network_id=made.stdout.strip()
        raw_network=json.loads(executor._docker(['network','inspect',network]).stdout)[0]
        assert raw_network['Internal'] and raw_network['Labels'][executor.LABEL]==proxy_name
        save(ROOT/'coderank-proof-network-before.json',raw_network)
        made=executor._docker(['create','--pull','never','--init','--read-only','--user','1000:1000',
            '--network',UPSTREAM_NETWORK,'--memory','512m','--memory-swap','512m','--cpus','1',
            '--pids-limit','64','--cap-drop','ALL','--security-opt','no-new-privileges',
            '--name',proxy_name,'--label',executor.LABEL+'='+proxy_name,
            '--mount','type=bind,src='+str(relay_path)+',dst=/relay.py,readonly',
            '--entrypoint','python3',IMAGE,'-I','-B','/relay.py',
            '--upstream','http://codescout-dense-amd:8080/v1/embeddings',
            '--model','CodeRankEmbed','--dimensions','768'])
        assert made.returncode==0,made.stderr
        proxy=made.stdout.strip()
        linked=executor._docker(['network','connect','--alias','source-embeddings',network,proxy])
        assert linked.returncode==0,linked.stderr
        before=executor._inspect(proxy)
        executor._owned(before,proxy,proxy_name,IMAGE)
        assert set(before['NetworkSettings']['Networks'])=={UPSTREAM_NETWORK,network}
        save(ROOT/'coderank-proof-proxy-before.json',before)
        started=executor._docker(['start',proxy]);assert started.returncode==0,started.stderr
        # Health/smoke is inside the owned proxy; no listening host port.
        smoke_program="import json,urllib.request; r=urllib.request.Request('http://127.0.0.1:8000/v1/embeddings',data=json.dumps({'input':['public source transport smoke']}).encode(),headers={'Content-Type':'application/json'});\nwith urllib.request.urlopen(r,timeout=120) as s: v=json.load(s)\nassert len(v['data'])==1 and len(v['data'][0]['embedding'])==768\nprint(json.dumps({'count':len(v['data']),'dimensions':len(v['data'][0]['embedding'])}))"
        smoke=None
        for attempt in range(20):
            smoke=executor._docker(['exec',proxy,'python3','-I','-c',smoke_program],timeout=130)
            if smoke.returncode==0:break
            time.sleep(0.2)
        (ROOT/'coderank-proof-proxy-smoke.stdout').write_text(smoke.stdout)
        (ROOT/'coderank-proof-proxy-smoke.stderr').write_text(smoke.stderr)
        assert smoke.returncode==0,smoke.stderr
        cfg=json.loads(Path('/tmp/effort-native-cli-config-20261109-01a15ca9.json').read_text())
        cfg.update(native_image=IMAGE,runtime_manifest=str(ROOT/'native-runtime.json'))
        original_argv=prepare_native._native_argv
        def argv_on_private_network(actor,home,config):
            argv=original_argv(actor,home,config)
            argv[argv.index('--network')+1]=network
            return argv
        prepare_native._native_argv=argv_on_private_network
        native=Native('coderank-proof-index-and-readiness',project,cfg)
        native.start()
        actual=executor._inspect(native.cid)
        assert set(actual['NetworkSettings']['Networks'])=={network}
        profile.update(private_network=network,private_network_id=network_id,relay_container=proxy)
        save(ROOT/'coderank-proof-profile.json',profile)
        emit('coderank-proof-reused-index', source_digest=actual_source,
             indexing_calls=0, onboarding_calls=0, author_or_repair_calls=0)
        pages=[];cursor=None
        while True:
            page=native.rpc('tools/list',{'cursor':cursor} if cursor else {})
            page['cursor']=cursor;pages.append(page)
            cursor=page['result'].get('nextCursor')
            if not cursor:break
        status=native.tool('workspace',{'action':'status'})
        specs=[
            {'tool':'references','arguments':{'path':'crates/stdx/src/lib.rs','symbol':'to_snake_case'},'must_contain':['crates/stdx/src/lib.rs','to_snake_case(s, char::to_lowercase)','to_snake_case(s, char::to_uppercase)']},
            {'tool':'symbol_at','arguments':{'path':'crates/stdx/src/lib.rs','line':95,'col':5},'must_contain':['to_snake_case']},
            {'tool':'call_graph','arguments':{'path':'crates/stdx/src/lib.rs','symbol':'to_snake_case','direction':'callers'},'must_contain':['to_lower_snake_case','to_upper_snake_case','(depth=1, lsp)']},
            {'tool':'semantic_search','arguments':{'query':'to_snake_case identifier transformation','limit':5},'must_contain':['crates/stdx/src/lib.rs']}]
        observations=[{'tool':spec['tool'],'arguments':spec['arguments'],'response':native.tool(spec['tool'],spec['arguments'],timeout=240)} for spec in specs]
        static=['project.toml','system-prompt.md']+[str(p.relative_to(knowledge)) for p in sorted((knowledge/'memories').glob('*.md'))]
        binding={'image':IMAGE,'executable_sha256':subprocess.check_output(['docker','exec',native.cid,'sha256sum','/bench/bin/codescout'],text=True).split()[0],
            'source_snapshot_sha256':_public_digest(project),'knowledge_sha256':input_digest(knowledge,static)}
        assert binding['source_snapshot_sha256']==actual_source
        expected={'project_root':'/testbed','languages':['rust'],'tools':['symbols','references','symbol_at','call_graph','semantic_search'],'binding':binding,'probes':specs}
        wire={'binding':binding,'status':status,'tool_pages':pages,'probes':observations,'index_verification':native.tool('index',{'action':'verify'},timeout=240)}
        save(ROOT/'coderank-proof-readiness-raw.json',{'expected':expected,'wire':wire})
        result=validate_readiness(expected,wire,source=project)
        save(ROOT/'coderank-proof-readiness-result.json',result)
        emit('coderank-proof-readiness-complete',tools=len(result['tools']),probes=result['probes_verified'])
        save(ROOT/'coderank-proof-preparation-result.json',{'paid_ready':False,'source_digest':actual_source,
             'repair_or_author_llm_calls':0,'embedding_compute_cost_usd':None,'scope':'one common source preparation; four-arm clone/context qualification pending'})
    finally:
        errors=[]
        if native is not None:
            try:native.close()
            except Exception as exc:errors.append(str(exc))
        if proxy is not None:
            try:
                (ROOT/'coderank-proof-proxy.logs').write_text(executor._docker(['logs',proxy]).stdout)
                save(ROOT/'coderank-proof-proxy-after.json',executor._inspect(proxy))
                executor._cleanup(proxy,proxy_name,IMAGE)
            except Exception as exc:errors.append(str(exc))
        try:
            network_row=executor._docker(['network','inspect',network])
            if network_row.returncode==0:
                row=json.loads(network_row.stdout)[0]
                assert row['Labels'].get(executor.LABEL)==proxy_name and not row.get('Containers')
                removed=executor._docker(['network','rm',row['Id']]);assert removed.returncode==0,removed.stderr
            check=executor._docker(['network','ls','--quiet','--filter','name=^'+network+'$'])
            assert check.returncode==0 and not check.stdout.strip()
        except Exception as exc:errors.append(str(exc))
        save(ROOT/'coderank-proof-infrastructure-cleanup.json',{'proxy':proxy,'network':network,'complete':not errors,'errors':errors})
        if errors:raise RuntimeError('owned relay finalization failed: '+str(errors))

if __name__ == '__main__':
    main()
