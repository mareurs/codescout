"""Freeze the qualified development corpus once and measure independent arm copies."""
from pathlib import Path
import hashlib,json,shutil,stat
from preparation import freeze_preparation,prepare_arm,verify_preparation
from native_executor import _public_digest
from receipts import input_digest

ROOT=Path('/home/marius/.cache/codescout-resident/codescout/common-preparation-20261109')
OUT=ROOT/'common-frozen-v2'
IMAGE='sha256:a7108935ae3cb9c6573af9f0e371dbaaffb4c9a88a92038e334184bf8672cc32'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    proof=json.loads((ROOT/'coderank-proof-readiness-result.json').read_text())
    assert proof['ready'] and proof['index_coverage']['coverage']=='all_nonempty_eligible_files'
    assert json.loads((ROOT/'coderank-proof-infrastructure-cleanup.json').read_text())['complete']
    assert json.loads((ROOT/'coderank-proof-index-and-readiness/cleanup.json').read_text())['cleanup_complete']
    project=ROOT/'project-coderank-proof'
    public=ROOT/'common-public-source-v2'
    knowledge=ROOT/'common-public-knowledge-v2'
    assert not public.exists() and not knowledge.exists() and not OUT.exists()
    shutil.copytree(project,public,ignore=shutil.ignore_patterns('.git','.codescout'))
    assert _public_digest(public)==proof['binding']['source_snapshot_sha256']
    knowledge.mkdir()
    original=project/'.codescout'
    for name in ['project.toml','system-prompt.md']:
        shutil.copy2(original/name,knowledge/name)
    (knowledge/'memories').mkdir()
    for path in (original/'memories').glob('*.md'):
        shutil.copy2(path,knowledge/'memories'/path.name)
    (knowledge/'embeddings').mkdir()
    for path in (original/'embeddings').iterdir():
        if path.name.endswith('.db') or path.name=='.gitignore':
            assert path.is_file() and not path.is_symlink()
            shutil.copy2(path,knowledge/'embeddings'/path.name)
    assert all((knowledge/'embeddings'/name).is_file() for name in ['testbed.db','testbed.memories.db'])
    assert {p.name for p in (knowledge/'embeddings').glob('*.db')} == {p.name for p in (original/'embeddings').glob('*.db')}
    assert not list((original/'embeddings').glob('*-wal')), 'uncheckpointed SQLite WAL'
    if (original/'index-state.json').exists():
        shutil.copy2(original/'index-state.json',knowledge/'index-state.json')
    cfg=json.loads(Path('/tmp/effort-native-cli-config-20261109-01a15ca9.json').read_text())
    runtime={'image':IMAGE,'model':'CodeRankEmbed',
             'files':{'cli':cfg['cli'],'codescout':'/home/marius/.cache/codescout-resident/codescout/native-build-provenance-20261104/bin/codescout'},
             'plugin':cfg['plugin']}
    manifest=freeze_preparation(public,knowledge,cfg['global_rules'],runtime,OUT)
    arms={arm:prepare_arm(OUT,arm,ROOT/('common-arm-v2-'+arm)) for arm in ['L','R','P','X']}
    seen={}
    populations={}
    for label,folder in [('frozen',OUT)]+[(k,Path(v['actor']).parent) for k,v in arms.items()]:
        files=[p for p in folder.rglob('*') if p.is_file()]
        populations[label]=len(files)
        for path in files:
            assert not path.is_symlink()
            st=path.stat();key=(st.st_dev,st.st_ino)
            assert key not in seen, ('shared inode',str(path),seen.get(key))
            seen[key]=str(path)
    checks=[]
    for relative in ['actor/.gitignore','actor/.codescout/system-prompt.md','global.md']:
        paths={arm:Path(data['actor']).parent/relative for arm,data in arms.items()}
        before={arm:sha(path) for arm,path in paths.items()}
        target=paths['L'];old=target.read_bytes()
        try:
            target.write_bytes(old+b'\nindependence probe\n')
            assert sha(target)!=before['L']
            assert all(sha(paths[arm])==before[arm] for arm in ['R','P','X'])
            verify_preparation(OUT)
            checks.append({'path':relative,'changed_arm':'L','other_arms_unchanged':True,'frozen_verified':True})
        finally:
            target.write_bytes(old)
        assert all(sha(paths[arm])==before[arm] for arm in paths)
    result={'paid_ready':False,'native_context_parity':False,'scope':'development-source common physical copies; no cohort admission',
            'preparation':manifest,'arms':arms,'all_regular_file_inode_populations':populations,
            'shared_inodes':0,'write_independence_controls':checks,
            'knowledge_files':[str(p.relative_to(knowledge)) for p in sorted(knowledge.rglob('*')) if p.is_file()],
            'curated_knowledge_digest':input_digest(knowledge),
            'original_native_verdict':proof['index_coverage']['native_verdict'],
            'coverage':proof['index_coverage'],'git_runtime_not_prepared':True,'actor_model_not_registered':True,
            'author_or_repair_llm_calls':0,'embedding_compute_cost_usd':None}
    (ROOT/'common-freeze-result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'common_manifest':manifest['manifest_sha256'],'arms':list(arms),
                     'shared_inodes':0,'paid_ready':False}))

if __name__=='__main__':
    main()
