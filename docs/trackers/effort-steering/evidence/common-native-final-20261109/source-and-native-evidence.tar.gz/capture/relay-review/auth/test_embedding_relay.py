"""Real HTTP boundary tests for a fixed embedding-only relay."""
import http.client
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import importlib
import json
import threading
import unittest

try:
    relay = importlib.import_module("embedding_relay")
except ModuleNotFoundError as exc:
    if exc.name != "embedding_relay":
        raise
    relay = None


class RelayTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(relay, "embedding relay is not implemented")
        self.seen = []
        self.mode = "valid"
        parent = self
        class Upstream(BaseHTTPRequestHandler):
            def do_POST(self):
                body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                parent.seen.append({"path": self.path, "body": body, "headers": dict(self.headers)})
                status = 500 if parent.mode == "error" else 200
                count = len(body["input"]) if parent.mode != "count" else 0
                dims = 2 if parent.mode == "dimensions" else 3
                payload = {"data": [{"index": index, "embedding": [0.5] * dims} for index in range(count)]}
                if parent.mode == "invalid-number":
                    payload["data"][0]["embedding"][0] = "secret-shaped-text"
                data = json.dumps(payload).encode()
                self.send_response(status)
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            def log_message(self, *args):
                pass
        self.upstream = self.start(Upstream)
        self.gateway = self.start(relay.make_handler(
            "http://127.0.0.1:" + str(self.upstream.server_port) + "/v1/embeddings",
            "registered-embedding-model", 3, max_bytes=256))

    def start(self, handler):
        server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
        thread = threading.Thread(target=lambda: server.serve_forever(poll_interval=0.01), daemon=True)
        thread.start()
        def close():
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)
        self.addCleanup(close)
        return server

    def request(self, method="POST", path="/v1/embeddings", payload=None, raw=None, headers=None):
        if raw is None:
            raw = json.dumps(payload if payload is not None else {"input": ["public source"]}).encode()
        connection = http.client.HTTPConnection("127.0.0.1", self.gateway.server_port, timeout=3)
        self.addCleanup(connection.close)
        connection.request(method, path, body=raw, headers=headers or {})
        response = connection.getresponse()
        return response.status, json.loads(response.read())

    def test_valid_embedding_request_uses_registered_model_and_strips_auth(self):
        status, body = self.request(payload={"model": "actor-selected", "input": ["public source"]},
                                    headers={"Authorization": "Bearer must-not-forward"})
        self.assertEqual(status, 200)
        self.assertEqual(body["model"], "registered-embedding-model")
        self.assertEqual(body["data"][0]["embedding"], [0.5, 0.5, 0.5])
        self.assertEqual(self.seen[0]["path"], "/v1/embeddings")
        self.assertEqual(self.seen[0]["body"]["model"], "registered-embedding-model")
        self.assertFalse(any(name.lower() == "authorization" for name in self.seen[0]["headers"]))

    def test_other_paths_and_methods_never_reach_upstream(self):
        for method, path in [("GET", "/v1/embeddings"), ("POST", "/v1/messages"),
                             ("POST", "/admin"), ("POST", "/v1/embeddings?redirect=other")]:
            with self.subTest(method=method, path=path):
                status, _ = self.request(method=method, path=path)
                self.assertGreaterEqual(status, 400)
        self.assertEqual(self.seen, [])

    def test_invalid_json_and_unknown_generation_fields_refused(self):
        for raw in [b"{", b'{"messages":[],"input":["x"]}', b'{"input":[12]}', b'{"input":[]}']:
            with self.subTest(raw=raw):
                status, _ = self.request(raw=raw)
                self.assertEqual(status, 400)
        self.assertEqual(self.seen, [])

    def test_body_limit_is_enforced_before_forwarding(self):
        status, _ = self.request(raw=b"x" * 257)
        self.assertEqual(status, 413)
        self.assertEqual(self.seen, [])

    def test_wrong_embedding_dimensions_are_not_success(self):
        self.mode = "dimensions"
        status, _ = self.request()
        self.assertEqual(status, 502)

    def test_missing_embedding_items_are_not_success(self):
        self.mode = "count"
        status, _ = self.request()
        self.assertEqual(status, 502)

    def test_non_numeric_embedding_is_not_success(self):
        self.mode = "invalid-number"
        status, _ = self.request()
        self.assertEqual(status, 502)

    def test_upstream_http_failure_is_not_an_empty_success(self):
        self.mode = "error"
        status, body = self.request()
        self.assertEqual(status, 502)
        self.assertIn("error", body)

    def test_health_does_not_call_upstream(self):
        status, body = self.request(method="GET", path="/health")
        self.assertEqual(status, 200)
        self.assertEqual(body, {"ready": True})
        self.assertEqual(self.seen, [])
