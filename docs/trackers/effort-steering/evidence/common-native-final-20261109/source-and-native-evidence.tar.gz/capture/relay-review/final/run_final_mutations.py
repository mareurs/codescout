from pathlib import Path
import subprocess,json,difflib,hashlib,re
root=Path(__file__).parent
source=Path('/home/marius/.codex/worktrees/cf66/codescout/tools/effort_protocol')
files={name:(source/name).read_bytes() for name in ('embedding_relay.py','test_embedding_relay.py')}
for name,data in files.items():(root/name).write_bytes(data)
original=files['embedding_relay.py'].decode()
sha=lambda data:hashlib.sha256(data).hexdigest()
(root/'source-hashes-before.json').write_text(json.dumps({n:sha(d) for n,d in files.items()},indent=2)+'\n')
mutations=[
('route', 'if self.path != "/v1/embeddings":', 'if False:'),
('model', '{"input": inputs, "model": model}', '{"input": inputs, "model": value.get("model", model)}'),
('auth', 'headers={"Content-Type": "application/json"}', 'headers={"Content-Type": "application/json", "Authorization": self.headers.get("Authorization", "")}'),
('cookie', 'headers={"Content-Type": "application/json"}', 'headers={"Content-Type": "application/json", "Cookie": self.headers.get("Cookie", "")}'),
('body_limit', 'if length > max_bytes:', 'if False:'),
('input_shape', 'not all(isinstance(item, str) and item for item in inputs)', 'False'),
('input_count', 'not 1 <= len(inputs) <= 1024', 'not 1 <= len(inputs)'),
('dimensions', 'or len(vector) != dimensions', ''),
('vector_count', 'or len(items) != len(inputs)', ''),
('numeric', 'type(number) in {int, float}', 'isinstance(number, (int, float))'),
('index', 'item.get("index") != index or ', ''),
('upstream_failure', 'self.send_json(502,', 'self.send_json(200,'),
('framing', 'if len(lengths) != 1 or self.headers.get("Transfer-Encoding"):', 'if False:'),
('redirect', 'build_opener(ProxyHandler({}), NoRedirect())', 'build_opener(ProxyHandler({}))'),
('request_length', 'if len(raw_input) != length:', 'if False:'),
('response_length', 'if expected is not None and len(raw) != expected:', 'if False:'),
('client_timeout', 'self.request.settimeout(client_timeout)', 'self.request.settimeout(None)'),
('client_slots', 'self.slots = threading.BoundedSemaphore(max_clients)', 'self.slots = threading.BoundedSemaphore(1000000)'),
('overflow_catcher', 'AttributeError, OverflowError, HTTPException', 'AttributeError, HTTPException'),
]
rows=[];nonmatching=[]
def run(name,code):
 folder=root/name;folder.mkdir(exist_ok=True)
 (folder/'embedding_relay.py').write_text(code)
 (folder/'test_embedding_relay.py').write_bytes(files['test_embedding_relay.py'])
 (folder/'mutant.py').write_text(code)
 (folder/'mutation.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),code.splitlines(True),fromfile='original/embedding_relay.py',tofile=name+'/embedding_relay.py')))
 command=['python3','-B','-m','unittest','-v','test_embedding_relay']
 (folder/'command.json').write_text(json.dumps(command)+'\n')
 try:
  p=subprocess.run(command,cwd=folder,capture_output=True,text=True,timeout=12)
  out,err,exitcode=p.stdout,p.stderr,p.returncode
 except subprocess.TimeoutExpired as e:
  out=(e.stdout or b'').decode() if isinstance(e.stdout,bytes) else e.stdout or ''
  err=(e.stderr or b'').decode() if isinstance(e.stderr,bytes) else e.stderr or ''
  exitcode='instrument-timeout'
 finally:
  (folder/'embedding_relay.py').write_bytes(files['embedding_relay.py'])
 (folder/'suite.stdout').write_text(out);(folder/'suite.stderr').write_text(err);(folder/'exit.txt').write_text(str(exitcode)+'\n')
 failure=re.search(r'^FAILED \((.*)\)',err,re.M)
 row={'name':name,'exit':exitcode,'suite_summary':re.findall(r'^Ran .*|^OK.*|^FAILED .*',err,re.M),'failure_summary':failure.group(1) if failure else None,'assertions':re.findall(r'^AssertionError:.*',err,re.M),'error_tests':re.findall(r'^ERROR:.*',err,re.M),'skip_lines':re.findall(r'^.*skipped.*$',err,re.M),'restored_hash':sha((folder/'embedding_relay.py').read_bytes())}
 return row
rows.append(run('baseline',original));print(json.dumps(rows[-1]),flush=True)
for name,before,after in mutations:
 matches=original.count(before)
 if matches!=1:
  nonmatching.append({'name':name,'anchor':before,'matches':matches});continue
 row=run(name,original.replace(before,after));rows.append(row);print(json.dumps(row),flush=True)
rows.append(run('restored_control',original));print(json.dumps(rows[-1]),flush=True)
(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
(root/'nonmatching.json').write_text(json.dumps(nonmatching,indent=2)+'\n')
final={n:{'before':sha(data),'after':sha((source/n).read_bytes()),'snapshot':sha((root/n).read_bytes())} for n,data in files.items()}
(root/'source-hashes-after.json').write_text(json.dumps(final,indent=2)+'\n');print(json.dumps({'nonmatching':nonmatching,'final_hashes':final}),flush=True)
