"""Fixed-upstream embedding-only HTTP relay for an isolated native runtime."""
import argparse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import math
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import build_opener, ProxyHandler, Request


def make_handler(upstream, model, dimensions, *, max_bytes=32 * 1024 * 1024):
    endpoint = urlsplit(upstream)
    if (endpoint.scheme not in {"http", "https"} or not endpoint.hostname
            or endpoint.username or endpoint.password or endpoint.query or endpoint.fragment
            or endpoint.path not in {"/v1/embeddings", "/embeddings"}):
        raise ValueError("fixed embedding upstream required")
    if not isinstance(model, str) or not model or type(dimensions) is not int or dimensions <= 0:
        raise ValueError("registered model and vector dimensions required")
    opener = build_opener(ProxyHandler({}))

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def send_json(self, status, value):
            data = json.dumps(value, allow_nan=False).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Connection", "close")
            self.end_headers()
            self.wfile.write(data)
            self.close_connection = True

        def do_GET(self):
            if self.path == "/health":
                self.send_json(200, {"ready": True})
            else:
                self.send_json(405, {"error": "embedding POST required"})

        def do_POST(self):
            if self.path != "/v1/embeddings":
                self.send_json(404, {"error": "route unavailable"})
                return
            lengths = self.headers.get_all("Content-Length") or []
            if len(lengths) != 1 or self.headers.get("Transfer-Encoding"):
                self.send_json(400, {"error": "one explicit content length required"})
                return
            try:
                length = int(lengths[0])
            except ValueError:
                length = -1
            if length < 0:
                self.send_json(400, {"error": "invalid content length"})
                return
            if length > max_bytes:
                self.send_json(413, {"error": "embedding input too large"})
                return
            try:
                value = json.loads(self.rfile.read(length))
                if not isinstance(value, dict) or set(value) - {"input", "model", "encoding_format", "dimensions"}:
                    raise ValueError("embedding fields only")
                inputs = value.get("input")
                if isinstance(inputs, str):
                    inputs = [inputs]
                if not isinstance(inputs, list) or not 1 <= len(inputs) <= 1024 or not all(isinstance(item, str) and item for item in inputs):
                    raise ValueError("text embedding inputs required")
                if value.get("encoding_format", "float") != "float" or value.get("dimensions", dimensions) != dimensions:
                    raise ValueError("registered float vectors required")
            except (ValueError, TypeError):
                self.send_json(400, {"error": "invalid embedding input"})
                return
            payload = json.dumps({"input": inputs, "model": model}).encode()
            request = Request(upstream, data=payload, headers={"Content-Type": "application/json"})
            try:
                with opener.open(request, timeout=120) as response:
                    raw = response.read(64 * 1024 * 1024 + 1)
                if len(raw) > 64 * 1024 * 1024:
                    raise ValueError("oversized embedding response")
                result = json.loads(raw)
                items = result.get("data") if isinstance(result, dict) else None
                if not isinstance(items, list) or len(items) != len(inputs):
                    raise ValueError("embedding count mismatch")
                checked = []
                for index, item in enumerate(items):
                    vector = item.get("embedding") if isinstance(item, dict) else None
                    if (item.get("index") != index or not isinstance(vector, list) or len(vector) != dimensions
                            or not all(type(number) in {int, float} and math.isfinite(number) for number in vector)):
                        raise ValueError("invalid embedding vector")
                    checked.append({"object": "embedding", "index": index, "embedding": vector})
            except (HTTPError, URLError, OSError, ValueError, TypeError, AttributeError):
                self.send_json(502, {"error": "embedding upstream failed validation"})
                return
            self.send_json(200, {"object": "list", "model": model, "data": checked})

    return Handler


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--upstream", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--dimensions", required=True, type=int)
    parser.add_argument("--port", default=8000, type=int)
    args = parser.parse_args()
    server = ThreadingHTTPServer(("0.0.0.0", args.port),
                                 make_handler(args.upstream, args.model, args.dimensions))
    server.serve_forever()


if __name__ == "__main__":
    main()
