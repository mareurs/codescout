import contextlib, http.client, importlib.util, json, socket, sys, threading, time, traceback, unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
folder=Path(sys.argv.pop(1))
spec=importlib.util.spec_from_file_location('review_relay',folder/'embedding_relay.py')
relay=importlib.util.module_from_spec(spec);spec.loader.exec_module(relay)

class Harness:
 def __init__(self):
  self.servers=[];self.threads=[];self.seen=[];self.mode='valid';self.redirect=None;self.errors=[]
 def start(self,handler):
  parent=self
  class Server(ThreadingHTTPServer):
   def handle_error(self,*args): parent.errors.append(traceback.format_exc())
  server=Server(('127.0.0.1',0),handler)
  thread=threading.Thread(target=lambda:server.serve_forever(poll_interval=.01),daemon=True);thread.start()
  self.servers.append(server);self.threads.append(thread);return server
 def setup(self):
  parent=self
  class Upstream(BaseHTTPRequestHandler):
   def log_message(self,*args): pass
   def do_GET(self): self.serve()
   def do_POST(self): self.serve()
   def serve(self):
    body=self.rfile.read(int(self.headers.get('Content-Length','0')))
    parent.seen.append({'method':self.command,'path':self.path,'headers':dict(self.headers),'body':body.decode()})
    if parent.mode=='redirect' and self.server is parent.upstream:
     self.send_response(302);self.send_header('Location',parent.redirect);self.end_headers();return
    n=len(json.loads(body)['input']) if body else 1
    value={'data':[{'index':i,'embedding':[.5,.5,.5]} for i in range(n)]}
    if parent.mode=='bool':value['data'][0]['embedding'][0]=True
    if parent.mode=='index':value['data'][0]['index']=9
    if parent.mode=='huge_int':value['data'][0]['embedding'][0]=10**400
    data=json.dumps(value).encode()
    self.send_response(200);self.send_header('Content-Length',str(len(data)+(10 if parent.mode=='truncated' else 0)));self.end_headers();self.wfile.write(data)
  self.upstream=self.start(Upstream);self.alternate=self.start(Upstream)
  self.gateway=self.start(relay.make_handler('http://127.0.0.1:%d/v1/embeddings'%self.upstream.server_port,'registered',3,max_bytes=16384))
  self.redirect='http://127.0.0.1:%d/admin'%self.alternate.server_port
  return self
 def request(self,body=None,headers=None):
  conn=http.client.HTTPConnection('127.0.0.1',self.gateway.server_port,timeout=2)
  try:
   conn.request('POST','/v1/embeddings',body=json.dumps(body or {'input':['public source']}),headers=headers or {})
   response=conn.getresponse();return {'status':response.status,'body':json.loads(response.read())}
  except Exception as exc:return {'exception':type(exc).__name__,'message':str(exc)}
  finally:conn.close()
 def raw(self,extra=b'',declared_delta=0,halfclose=True):
  body=b'{"input":["public source"]}'
  sock=socket.create_connection(('127.0.0.1',self.gateway.server_port),timeout=2)
  try:
   sock.sendall(b'POST /v1/embeddings HTTP/1.1\r\nHost: localhost\r\nContent-Length: '+str(len(body)+declared_delta).encode()+b'\r\n'+extra+b'Connection: close\r\n\r\n'+body)
   if halfclose:sock.shutdown(socket.SHUT_WR)
   out=b''
   while True:
    data=sock.recv(65536)
    if not data:break
    out+=data
   return out.decode()
  finally:sock.close()
 def close(self):
  for server in self.servers:server.shutdown();server.server_close()
  for thread in self.threads:thread.join(2)

class ExtraTests(unittest.TestCase):
 def setUp(self):self.h=Harness().setup();self.addCleanup(self.h.close)
 def test_cookie_stripped(self):
  self.assertEqual(self.h.request(headers={'Cookie':'public-canary'})['status'],200)
  self.assertFalse(any(k.lower()=='cookie' for k in self.h.seen[0]['headers']))
 def test_input_count_capped(self):
  self.assertEqual(self.h.request({'input':['x']*1025})['status'],400);self.assertEqual(self.h.seen,[])
 def test_boolean_vector_rejected(self):
  self.h.mode='bool';self.assertEqual(self.h.request()['status'],502)
 def test_index_rejected(self):
  self.h.mode='index';self.assertEqual(self.h.request()['status'],502)
 def test_transfer_encoding_rejected(self):
  result=self.h.raw(extra=b'Transfer-Encoding: chunked\r\n')
  self.assertTrue(result.startswith('HTTP/1.0 400'),result);self.assertEqual(self.h.seen,[])

if __name__=='__main__':
 if len(sys.argv)>1 and sys.argv[1]=='observe':
  rows=[]
  for mode in ['redirect','short_request','truncated','huge_int','idle_clients']:
   h=Harness().setup();sockets=[]
   try:
    h.mode=mode
    if mode=='short_request':result={'wire':h.raw(declared_delta=100)}
    elif mode=='idle_clients':
     before=threading.active_count()
     for i in range(24):
      sock=socket.create_connection(('127.0.0.1',h.gateway.server_port),timeout=2)
      sock.sendall(b'POST /v1/embeddings HTTP/1.1\r\nHost: localhost\r\nContent-Length: 1000\r\n\r\n{')
      sockets.append(sock)
     time.sleep(2.2)
     result={'clients':len(sockets),'threads_before':before,'threads_after':threading.active_count(),'request_socket_timeout':h.gateway.socket.gettimeout(),'handler_setup_overridden':relay.make_handler('http://127.0.0.1:9/v1/embeddings','registered',3).setup is not BaseHTTPRequestHandler.setup}
    else:result=h.request()
    rows.append({'mode':mode,'result':result,'seen':h.seen.copy(),'errors':h.errors.copy()})
   finally:
    for sock in sockets:sock.close()
    h.close()
  print(json.dumps(rows,indent=2))
 else:unittest.main()
