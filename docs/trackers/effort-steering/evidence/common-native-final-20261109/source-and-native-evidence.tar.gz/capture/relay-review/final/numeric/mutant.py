"""Fixed-upstream embedding-only HTTP relay for an isolated native runtime."""
import argparse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import math
import threading
from http.client import HTTPException
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import build_opener, ProxyHandler, Request, HTTPRedirectHandler


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class RelayServer(ThreadingHTTPServer):
    """Bound active clients, including clients that never finish a body."""
    daemon_threads = True

    def __init__(self, address, handler, *, max_clients=8):
        if type(max_clients) is not int or max_clients < 1:
            raise ValueError("positive client bound required")
        self.slots = threading.BoundedSemaphore(max_clients)
        super().__init__(address, handler)

    def process_request(self, request, client_address):
        if not self.slots.acquire(blocking=False):
            try:
                request.settimeout(1)
                request.sendall(b"HTTP/1.0 503 Busy\r\nContent-Length: 0\r\nConnection: close\r\n\r\n")
            except OSError:
                pass
            finally:
                self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except BaseException:
            self.slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self.slots.release()

def make_handler(upstream, model, dimensions, *, max_bytes=32 * 1024 * 1024, client_timeout=10):
    endpoint = urlsplit(upstream)
    if (endpoint.scheme not in {"http", "https"} or not endpoint.hostname
            or endpoint.username or endpoint.password or endpoint.query or endpoint.fragment
            or endpoint.path not in {"/v1/embeddings", "/embeddings"}):
        raise ValueError("fixed embedding upstream required")
    if not isinstance(model, str) or not model or type(dimensions) is not int or dimensions <= 0:
        raise ValueError("registered model and vector dimensions required")
    if not 0 < client_timeout <= 120:
        raise ValueError("bounded client timeout required")
    opener = build_opener(ProxyHandler({}), NoRedirect())

    class Handler(BaseHTTPRequestHandler):
        def setup(self):
            self.request.settimeout(client_timeout)
            super().setup()

        def log_message(self, *args):
            pass

        def send_json(self, status, value):
            data = json.dumps(value, allow_nan=False).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Connection", "close")
            self.end_headers()
            self.wfile.write(data)
            self.close_connection = True

        def do_GET(self):
            if self.path == "/health":
                self.send_json(200, {"ready": True})
            else:
                self.send_json(405, {"error": "embedding POST required"})

        def do_POST(self):
            if self.path != "/v1/embeddings":
                self.send_json(404, {"error": "route unavailable"})
                return
            lengths = self.headers.get_all("Content-Length") or []
            if len(lengths) != 1 or self.headers.get("Transfer-Encoding"):
                self.send_json(400, {"error": "one explicit content length required"})
                return
            try:
                length = int(lengths[0])
            except ValueError:
                length = -1
            if length < 0:
                self.send_json(400, {"error": "invalid content length"})
                return
            if length > max_bytes:
                self.send_json(413, {"error": "embedding input too large"})
                return
            try:
                raw_input = self.rfile.read(length)
                if len(raw_input) != length:
                    raise ValueError("incomplete request body")
                value = json.loads(raw_input)
                if not isinstance(value, dict) or set(value) - {"input", "model", "encoding_format", "dimensions"}:
                    raise ValueError("embedding fields only")
                inputs = value.get("input")
                if isinstance(inputs, str):
                    inputs = [inputs]
                if not isinstance(inputs, list) or not 1 <= len(inputs) <= 1024 or not all(isinstance(item, str) and item for item in inputs):
                    raise ValueError("text embedding inputs required")
                if value.get("encoding_format", "float") != "float" or value.get("dimensions", dimensions) != dimensions:
                    raise ValueError("registered float vectors required")
            except TimeoutError:
                self.send_json(408, {"error": "embedding input timed out"})
                return
            except (ValueError, TypeError):
                self.send_json(400, {"error": "invalid embedding input"})
                return
            payload = json.dumps({"input": inputs, "model": model}).encode()
            request = Request(upstream, data=payload, headers={"Content-Type": "application/json"})
            try:
                with opener.open(request, timeout=120) as response:
                    lengths = response.headers.get_all("Content-Length") or []
                    if len(lengths) > 1 or (lengths and response.headers.get("Transfer-Encoding")):
                        raise ValueError("ambiguous upstream framing")
                    expected = int(lengths[0]) if lengths else None
                    if expected is not None and not 0 <= expected <= 64 * 1024 * 1024:
                        raise ValueError("invalid upstream length")
                    raw = response.read(64 * 1024 * 1024 + 1)
                    if expected is not None and len(raw) != expected:
                        raise ValueError("incomplete upstream body")
                if len(raw) > 64 * 1024 * 1024:
                    raise ValueError("oversized embedding response")
                result = json.loads(raw)
                items = result.get("data") if isinstance(result, dict) else None
                if not isinstance(items, list) or len(items) != len(inputs):
                    raise ValueError("embedding count mismatch")
                checked = []
                for index, item in enumerate(items):
                    vector = item.get("embedding") if isinstance(item, dict) else None
                    if (item.get("index") != index or not isinstance(vector, list) or len(vector) != dimensions
                            or not all(isinstance(number, (int, float)) and math.isfinite(number) for number in vector)):
                        raise ValueError("invalid embedding vector")
                    checked.append({"object": "embedding", "index": index, "embedding": vector})
            except (HTTPError, URLError, OSError, ValueError, TypeError, AttributeError, OverflowError, HTTPException):
                self.send_json(502, {"error": "embedding upstream failed validation"})
                return
            self.send_json(200, {"object": "list", "model": model, "data": checked})

    return Handler


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--upstream", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--dimensions", required=True, type=int)
    parser.add_argument("--port", default=8000, type=int)
    args = parser.parse_args()
    server = RelayServer(("0.0.0.0", args.port),
                                 make_handler(args.upstream, args.model, args.dimensions))
    server.serve_forever()


if __name__ == "__main__":
    main()
