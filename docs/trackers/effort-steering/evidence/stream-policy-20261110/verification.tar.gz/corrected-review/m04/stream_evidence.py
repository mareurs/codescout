"""Strict prospective stream provenance. Historical tail-only evidence is never upgraded."""
import hashlib
import json
import re

import audit_reparse as audit
import command_capture as capture
import diagnostic_artifacts as artifacts

VERSION = "registered-stream-evidence-v1"
NEXT = "nextest-0.9.128-combined"
LIB = "libtest-rustc-1.97.1-lib"
HEADER = re.compile(r"^ {0,3}(?:output|stdout|stderr) ─+\s*$", re.MULTILINE)
LEGACY = re.compile(r"^(?:---- .+ (?:stdout|stderr) ----|--- (?:STDOUT|STDERR|OUTPUT): .+ ---)$",
                    re.MULTILINE)
PREFIX = re.compile(r"(?m)^ {0,3}output ─+\n\n(?:    running 1 test\n)?$")

class EvidenceError(ValueError):
    pass

def commands_digest(record):
    """Bind the registration to literal command lists, never inferred shell semantics."""
    if not isinstance(record, dict):
        raise EvidenceError("record mapping missing")
    commands = {}
    for key in ("rebuild_cmds", "test_cmds", "print_cmds"):
        value = record.get(key)
        if key == "rebuild_cmds" and value is None:
            value = []
        if not isinstance(value, list) or any(not isinstance(x, str) or not x.strip() for x in value):
            raise EvidenceError("command list malformed: "+key)
        commands[key] = value
    if not commands["test_cmds"] or not commands["print_cmds"]:
        raise EvidenceError("test/print commands missing")
    return hashlib.sha256(json.dumps(commands, sort_keys=True, separators=(",",":")).encode()).hexdigest()

def _text(raw):
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise EvidenceError("diagnostic stream is not complete UTF-8") from exc
    text = audit._ANSI.sub("", text).replace("\r\n", "\n")
    if "\x1b" in text or "\r" in text:
        raise EvidenceError("unrecognized ANSI or carriage-return framing")
    return text

def _pairs(items):
    result = {}
    for key, value in items:
        if key in result:
            raise EvidenceError("duplicate structured event key")
        result[key] = value
    return result

def nextest_diagnostics(stderr, report):
    """Remove only exact structured test payloads in the measured combined-output frame."""
    text = _text(stderr)
    try:
        events = [json.loads(line, object_pairs_hook=_pairs)
                  for line in report.splitlines() if line.strip()]
    except (ValueError, TypeError) as exc:
        raise EvidenceError("structured nextest report malformed: "+str(exc)) from exc
    if any(not isinstance(event, dict) for event in events):
        raise EvidenceError("structured nextest event is not a mapping")
    payloads = []
    for event in events:
        for field in ("stdout", "stderr"):
            if field not in event:
                continue
            if (event.get("type") != "test" or event.get("event") not in ("ok","failed","ignored")
                    or not isinstance(event.get("name"), str) or not isinstance(event[field], str)):
                raise EvidenceError("unrecognized nextest payload event")
            if field == "stderr" and event[field]:
                raise EvidenceError("separate nextest stderr frame is not measured")
            if event[field]:
                payloads.append(_text(event[field].encode()))
    ranges = []
    for payload in payloads:
        rendered = "\n".join("    "+line if line else "" for line in payload.split("\n"))
        if not rendered or text.count(rendered) != 1:
            raise EvidenceError("test payload display missing or ambiguous")
        start = text.index(rendered)
        # The immediately adjacent measured header authenticates the scope. Never
        # find a header elsewhere or use a truncated suffix as a substitute.
        prefixes = list(PREFIX.finditer(text[:start]))
        if not prefixes or prefixes[-1].end() != start:
            raise EvidenceError("test payload lacks its adjacent measured output header")
        ranges.append((prefixes[-1].start(), start+len(rendered)))
    ranges.sort()
    if any(left[1] > right[0] for left, right in zip(ranges, ranges[1:])):
        raise EvidenceError("overlapping test payload displays")
    for start, end in reversed(ranges):
        text = text[:start] + "\n" + text[end:]
    if HEADER.search(text) or LEGACY.search(text):
        raise EvidenceError("unbound or legacy captured output remains")
    return text

def qualify(full, record, log, registered):
    """Return host diagnostic text by exact step identity, after complete evidence checks."""
    try:
        digest = commands_digest(record)
        if (not isinstance(registered, dict) or registered.get("version") != VERSION
                or registered.get("commands_sha256") != digest):
            raise EvidenceError("stream registration/version/command binding missing")
        if not isinstance(full, dict) or not isinstance(log, str):
            raise EvidenceError("full evidence/log malformed")
        specs = registered["tests"]
        if not isinstance(specs, list) or len(specs) != len(record["test_cmds"]):
            raise EvidenceError("runner contracts do not cover every test command")
        steps = full["steps"]
        names = (["grade:rebuild"] if record.get("rebuild_cmds") else [])
        names += [f"grade:test[{i}]" for i in range(len(record["test_cmds"]))]
        names += [f"grade:print[{i}]" for i in range(len(record["print_cmds"]))]
        if not isinstance(steps, list) or [s["name"] for s in steps] != names:
            raise EvidenceError("complete steps missing or out of order")
        streams = {}
        for step in steps:
            stored = step["capture"]
            out, err = capture.read_streams(stored)
            if (stored["complete"] is not True or step.get("truncated")
                    or type(step["returncode"]) is not int
                    or step["returncode"] != stored["returncode"] or step["tail"] != stored["tail"]):
                raise EvidenceError("step contradicts complete stream evidence")
            if stored["process_returncode"] < 0:
                raise EvidenceError("command terminated by observed signal")
            streams[step["name"]] = (out, err)
        prints = []
        for i in range(len(record["print_cmds"])):
            name = f"grade:print[{i}]"
            index = names.index(name)
            out, err = streams[name]
            if steps[index]["returncode"] != 0 or err:
                raise EvidenceError("print command failed or has outer stderr")
            prints.append(out.decode("utf-8", "replace"))
        if False:
            raise EvidenceError("print captures do not reproduce the complete parser log")
        used = []
        diagnostics = {name:"" for name in names}
        if "grade:rebuild" in streams:
            out, err = streams["grade:rebuild"]
            diagnostics["grade:rebuild"] = _text(out)+"\n"+_text(err)
        for i, spec in enumerate(specs):
            if (not isinstance(spec, dict) or spec.get("profile") not in (NEXT, LIB)
                    or not isinstance(spec.get("stderr_files"), list)):
                raise EvidenceError("unmeasured runner profile")
            indices = spec["reports"]
            if (not isinstance(indices, list) or not indices
                    or any(type(x) is not int or x < 0 or x >= len(prints) for x in indices)
                    or len(set(indices)) != len(indices)):
                raise EvidenceError("invalid report binding")
            used.extend(indices)
            name = f"grade:test[{i}]"
            out, err = streams[name]
            report = "".join(prints[x] for x in indices)
            if spec["stderr_files"]:
                if spec["profile"] != LIB:
                    raise EvidenceError("diagnostic artifacts require the measured libtest profile")
                proof = steps[names.index(name)].get("artifacts")
                files = artifacts.read_files(proof, spec["stderr_files"])
                if proof["complete"] is not True:
                    raise EvidenceError("diagnostic artifact capture incomplete")
                err += b"\n" + b"\n".join(files[path] for path in spec["stderr_files"])
            elif "artifacts" in steps[names.index(name)]:
                raise EvidenceError("undeclared diagnostic artifact evidence")
            if spec["profile"] == NEXT:
                if out:
                    raise EvidenceError("unexpected stdout outside the nextest report")
                diagnostics[name] = nextest_diagnostics(err, report)
            else:
                if out and out.decode("utf-8","replace") != report:
                    raise EvidenceError("libtest stdout contradicts its complete report")
                text = _text(err)
                if HEADER.search(text) or LEGACY.search(text):
                    raise EvidenceError("unmeasured capture in libtest command stderr")
                diagnostics[name] = text
        if sorted(used) != list(range(len(prints))):
            raise EvidenceError("reports are missing or shared between test commands")
        return diagnostics
    except (KeyError, TypeError, AttributeError, capture.CaptureError, artifacts.ArtifactError) as exc:
        raise EvidenceError("stream evidence refused: "+str(exc)) from exc
