import sys,json,base64,hashlib,pathlib,subprocess,os,copy
from unittest import mock
sys.path.insert(0,sys.argv[1])
import test_stream_evidence as t
import stream_evidence as e
import command_capture as c
import diagnostic_artifacts as a
import multilang_control as ctl
import test_stream_policy as p
from test_grade_policy import OK
root=pathlib.Path(sys.argv[2]);root.mkdir(exist_ok=True)
results={}
def observe(name, fn):
    try: results[name]={"accepted":True,"result":fn()}
    except Exception as exc: results[name]={"accepted":False,"type":type(exc).__name__,"error":str(exc)}
record=dict(t.RECORD,test_cmds=["cargo test --lib > report"])
log="test f ... ok\n"
reg=t.contract(record,profile=e.LIB)
def full_lib(out="",err=""):
    return {"steps":[t.step("grade:test[0]",out=out,err=err),t.step("grade:print[0]",out=log)]}
# Complete and coherent truncated capture: normalized reader accepts retained bytes.
wire={"version":c.VERSION,"returncode":0,"process_returncode":0,"open_streams":0,
      "stdout":"","stderr":base64.b64encode(b"x"*17).decode(),"stdout_bytes":0,"stderr_bytes":80}
cap=c.decode(json.dumps(wire),0,16)
full=full_lib();full["steps"][0]={"name":"grade:test[0]","returncode":0,"tail":cap["tail"],"capture":cap}
observe("m02_complete_gate",lambda:e.qualify(full,record,log,reg))
# Unreferenced second print has empty bytes, so joined log remains identical.
r5=dict(record,print_cmds=["cat report","printf empty"])
f5=full_lib();f5["steps"].append(t.step("grade:print[1]"))
observe("m05_report_partition",lambda:e.qualify(f5,r5,log,t.contract(r5,profile=e.LIB)))
# Exact payload still present once, but a physical diagnostic intervenes after its header.
err7=t.NATIVE_ERR.replace("    running 1 test\n","    running 1 test\nHOST INSERTION\n",1)
observe("m07_header_adjacency",lambda:e.qualify(t.fixture(err=err7),t.RECORD,t.NATIVE_LOG,t.contract()))
# Original payload matches; an additional unknown capture remains after it.
err8=t.NATIVE_ERR+"  output ───\n\n    unknown payload\n"
observe("m08_unbound_residual",lambda:e.qualify(t.fixture(err=err8),t.RECORD,t.NATIVE_LOG,t.contract()))
observe("m09_libtest_stdout",lambda:e.qualify(full_lib(out="different report"),record,log,reg))
def artifact(raw,total=None,limit=1024):
    proof={"version":a.VERSION,"nonce":"a"*32,"paths":["1"],"prepared":True}
    total=len(raw) if total is None else total
    return {"version":a.VERSION,"nonce":"a"*32,"preparation":proof,"limit_bytes":limit,"complete":total<=limit,
            "files":[{"path":"1","base64":base64.b64encode(raw).decode(),"bytes":len(raw),"total_bytes":total,"sha256":hashlib.sha256(raw).hexdigest()}]}
f11=full_lib();f11["steps"][0]["artifacts"]=artifact(b"x"*17,80,16)
r11=copy.deepcopy(reg);r11["tests"][0]["stderr_files"]=["1"]
observe("m11_artifact_completeness",lambda:e.qualify(f11,record,log,r11))
a13=artifact(b"stderr");a13["nonce"]="b"*32
observe("m13_nonce_binding",lambda:a.read_files(a13,["1"]))
# Real file operation in independent retained directory, after valid preparation.
hard=root/"hardlink";hard.mkdir(exist_ok=True)
subprocess.run(["git","init","-q",str(hard)],check=True)
prep_run=subprocess.run(["bash","-c",a.prepare_script(["1"])],cwd=hard,capture_output=True,text=True,check=True)
prep=a.prepared(prep_run.stdout,["1"])
(hard/"outside").write_text("shared");os.link(hard/"outside",hard/"1")
def hard_read():
    cp=subprocess.run(["bash","-c",a.read_script(["1"],prep)],cwd=hard,capture_output=True,text=True,timeout=10)
    return {"returncode":cp.returncode,"stdout":cp.stdout,"stderr":cp.stderr}
observe("m16_hardlink",hard_read)
# Valid receipt paired with a failed preparation process must still refuse.
ctrlroot=root/"control";ctrlroot.mkdir(exist_ok=True);subprocess.run(["git","init","-q",str(ctrlroot)],check=True)
def bad_prepare(container,workdir,*args,**kw):
    cp=subprocess.run(args,cwd=workdir,capture_output=True,text=True,timeout=10)
    if '"prepared":true' in cp.stdout.replace(" ",""):
        cp.returncode=1
    return cp
def control_run():
    steps=[]
    with mock.patch.object(ctl,"_exec",side_effect=bad_prepare):
        got=ctl.run_tests("owned",str(ctrlroot),{"test_cmds":["printf fresh >1"],"print_cmds":["printf ok"]},steps=steps,state="grade",capture_streams=True,diagnostic_artifacts={0:["1"]})
    return {"log":got,"steps":len(steps)}
observe("m18_prepare_returncode",control_run)
# Native _exec shape merges stderr into stdout.
def merged_fail(*args,**kwargs): return subprocess.CompletedProcess(args,1,stdout="preparation refused",stderr=None)
def merged_run():
    with mock.patch.object(ctl,"_exec",side_effect=merged_fail):
        return ctl.run_tests("owned",str(ctrlroot),{"test_cmds":["true"],"print_cmds":["true"]},capture_streams=True,diagnostic_artifacts={0:["1"]})
observe("merged_stderr_failure",merged_run)
# Baseline policy contradictions.
rec=dict(t.RECORD,log_parser=p.JSON_PARSER,FAIL_TO_PASS=[p.SELECTED],PASS_TO_PASS=[])
raw,ful=p.prepared(rec,t.NATIVE_LOG,t.fixture())
for key,value in [("pass",1),("oom_killed",True),("container_removed",False),("error","transport failed"),("infra","unknown")]:
    changed=copy.deepcopy(ful);changed[key]=value
    observe("full_"+key,lambda changed=changed:p.policy.adjudicate_streams(raw,changed,rec,p.BUNDLE,log=t.NATIVE_LOG,runtime=OK,registered=t.contract(rec)))
# Actual negative process termination receipt normalized to positive shell exit.
changed=copy.deepcopy(ful);cap=t.stream(err=t.NATIVE_ERR,code=137);cap["process_returncode"]=-9
changed["steps"][0]={"name":"grade:test[0]","returncode":137,"tail":cap["tail"],"capture":cap}
observe("negative_process_code",lambda:p.policy.adjudicate_streams(raw,changed,rec,p.BUNDLE,log=t.NATIVE_LOG,runtime=OK,registered=t.contract(rec)))
(root/"probes.json").write_text(json.dumps(results,indent=2,default=lambda x:x.decode() if isinstance(x,bytes) else str(x)))
print(json.dumps({k:{"accepted":v["accepted"],"type":v.get("type"),"valid":v.get("result",{}).get("valid") if isinstance(v.get("result"),dict) else None,"returncode":v.get("result",{}).get("returncode") if isinstance(v.get("result"),dict) else None} for k,v in results.items()},indent=2))
