import sys,json,pathlib
sys.path.insert(0,sys.argv[1])
import test_stream_evidence as t
import test_grade_policy as old
import test_stream_policy as p
record=dict(old.RECORD,rebuild_cmds=[],test_cmds=["cargo test --lib > report"],print_cmds=["cat report"])
log=old.PASS_LOG+"---- callback stdout ----\nerror[E0425]: callback expected error\n --> tests/callback.rs:3:5\nwrite failed: No space left on device\nrustc: fatal error: terminated with signal 9\ntest result: FAILED. 2 passed; 1 failed;\n"
raw,full=p.prepared(record,log,{"steps":[t.step("grade:test[0]",out=log,code=101),t.step("grade:print[0]",out=log)]})
result=p.policy.adjudicate_streams(raw,full,record,old.BUNDLE,log=log,runtime=old.OK,registered=t.contract(record,profile="libtest-rustc-1.97.1-lib"))
pathlib.Path(sys.argv[2]).write_text(json.dumps(result,indent=2));print(json.dumps(result))
