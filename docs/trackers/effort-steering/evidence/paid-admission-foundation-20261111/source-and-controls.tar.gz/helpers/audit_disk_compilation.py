"""Independently re-read raw build inputs, profiles, streams and fresh cleanup for public controls."""
import hashlib
import json
from pathlib import Path
import sys

WORK=Path("/home/marius/.codex/worktrees/cf66/codescout")
ROOT=Path("/var/tmp/ep11-01a15")
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from receipts import verify_receipt, input_digest

def main():
    results=[]
    for stem in ("obscura-421","lean-ctx-1168"):
        directory=ROOT/"public-compilation"/stem
        public=json.loads((ROOT/"native-controls"/stem/"registration.json").read_bytes())["public"]
        raw=json.loads((directory/"result.json").read_bytes())
        registered=json.loads((directory/"registration.json").read_bytes())
        source=Path(registered["source"])
        assert input_digest(source)==registered["source_digest"]
        checked=verify_receipt({"id":"public-cargo-check"},directory/"commands",source,
            expected_profile=public["execution_profile"],expected_fixture=public.get("public_fixture"))
        assert checked==raw["receipt"]
        assert checked["complete"] and checked["resource_valid"] and checked["exit_code"]==0
        results.append({"project":stem,"receipt_sha256":hashlib.sha256(
            (directory/"commands/public-cargo-check/receipt.json").read_bytes()).hexdigest(),
            "reopened_build_and_streams":True,"verified":checked})
    target=ROOT/"public-compilation/independent-readback.json"
    with target.open("x") as stream:
        json.dump({"controls":results,"provider_calls":0,"paid_ready":False},stream,indent=2)
    print(json.dumps({"reopened_controls":len(results),"all_valid":True,"provider_calls":0,"paid_ready":False}),flush=True)

if __name__=="__main__":
    main()
