"""Observe an import-namespace mutant on an isolated source copy."""
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

WORK = Path("/home/marius/.codex/worktrees/cf66/codescout")
OUT = WORK / ".superpowers/sdd/2026-11-10-campaign-integration"
root = Path(tempfile.mkdtemp(prefix="embedding-import-mutant-"))
for name in ("effort_protocol", "agent_lifecycle"):
    folder = root / name
    folder.mkdir()
    for path in (WORK / "tools" / name).iterdir():
        if path.is_file() and path.suffix in (".py", ".json"):
            shutil.copy2(path, folder / path.name)
path = root / "effort_protocol/embedding_runtime.py"
original = path.read_text()
mutated = original.replace("from receipts import publish_exclusive",
    "from receipts import publish_exclusive\nimport executor\nexecutor.LABEL = 'wrong-import-namespace'", 1)
assert mutated != original
path.write_text(mutated)
result = subprocess.run([sys.executable, "-B", "-m", "unittest", "discover", "-s",
    str(root / "effort_protocol"), "-p", "test_embedding_runtime.py"], capture_output=True, text=True)
(OUT / "embedding-import-mutant-before.log").write_text(result.stdout + result.stderr)
(OUT / "embedding-import-mutant-before.json").write_text(json.dumps({
    "isolated_root": str(root), "mutation": "import overwrites executor.LABEL",
    "observed_test_exit": result.returncode, "survived": result.returncode == 0}, indent=2)+"\n")
print(json.dumps({"isolated_root": str(root), "exit_code": result.returncode,
                  "survived": result.returncode == 0}))
