"""Seal the concrete admission foundation, distinct from unfinished whole admission."""
import hashlib
import io
import json
from pathlib import Path
import stat
import tarfile

WORK=Path("/home/marius/.codex/worktrees/cf66/codescout")
MAIN=Path("/home/marius/work/claude/codescout")
ROOT=Path("/var/tmp/ep11-01a15")
PLAN=WORK/".superpowers/sdd/2026-11-10-campaign-integration"
DEST=MAIN/"docs/trackers/effort-steering/evidence/paid-admission-foundation-20261111"

def main():
    DEST.mkdir(parents=True,exist_ok=False)
    files={}
    for folder in ("effort_protocol","agent_lifecycle","hint_authority_pilot"):
        for path in (WORK/"tools"/folder).glob("*"):
            if path.is_file() and path.suffix in (".py",".json"):
                files["source/tools/"+folder+"/"+path.name]=path
    for path in PLAN.glob("*.py"):
        files["helpers/"+path.name]=path
    for path in PLAN.glob("paid-*.log"):
        files["logs/"+path.name]=path
    for folder in ("population-admission","population-admission-v2","public-command-admission","accounting-admission"):
        for path in (ROOT/folder).glob("*.json"):
            files["controls/"+folder+"/"+path.name]=path
    entries={}
    for name,path in files.items():
        assert path.is_file() and not path.is_symlink()
        data=path.read_bytes()
        entries[name]={"source":str(path),"bytes":len(data),
            "sha256":hashlib.sha256(data).hexdigest(),"mode":stat.S_IMODE(path.stat().st_mode)}
    manifest={"schema":"paid-admission-foundation-checkpoint-v1","entries":entries,
        "scope":"Population, public-command and historical-accounting admission checks plus current source. Full runtime/review/verification admission and paid backend wiring remain incomplete.",
        "runtime_checkpoint":"disk-runtime-checkpoint-20261111/closure.json",
        "paid_ready":False,"provider_calls":0}
    payload=(json.dumps(manifest,indent=2,sort_keys=True)+"\n").encode()
    archive=DEST/"source-and-controls.tar.gz"
    with tarfile.open(archive,"x:gz") as packed:
        for name,path in sorted(files.items()):
            data=path.read_bytes()
            assert hashlib.sha256(data).hexdigest()==entries[name]["sha256"]
            member=tarfile.TarInfo(name);member.mode=entries[name]["mode"];member.size=len(data)
            packed.addfile(member,io.BytesIO(data))
        member=tarfile.TarInfo("manifest.json");member.mode=0o600;member.size=len(payload)
        packed.addfile(member,io.BytesIO(payload))
    with tarfile.open(archive) as packed:
        members=packed.getmembers()
        assert len(members)==len(entries)+1 and len({m.name for m in members})==len(members)
        for member in members:
            raw=packed.extractfile(member).read()
            if member.name=="manifest.json":
                assert raw==payload
            else:
                row=entries[member.name]
                assert member.isfile() and member.mode==row["mode"] and len(raw)==row["bytes"]
                assert hashlib.sha256(raw).hexdigest()==row["sha256"]
                assert Path(row["source"]).read_bytes()==raw
    closure={"archive":archive.name,"bytes":archive.stat().st_size,
        "sha256":hashlib.sha256(archive.read_bytes()).hexdigest(),"regular_file_payloads":len(entries),
        "all_payloads_reopened":True,"source_originals_rechecked":True,"scope":manifest["scope"],
        "paid_ready":False,"provider_calls":0}
    with (DEST/"closure.json").open("x") as stream:
        json.dump(closure,stream,sort_keys=True,indent=2);stream.write("\n")
    print(json.dumps(closure),flush=True)

if __name__=="__main__":
    main()
