"""Reconcile a carried opening balance with individually rehashed native receipts."""
from decimal import Decimal, localcontext
import hashlib
import json
from pathlib import Path
import sys

WORK=Path("/home/marius/.codex/worktrees/cf66/codescout")
MAIN=Path("/home/marius/work/claude/codescout")
PLAN=WORK/".superpowers/sdd/2026-11-10-campaign-integration"
ANCHOR=Path("/home/marius/.cache/codescout-resident/codescout/hint-authority-effort-20261104/launch-v1/rulings.json")
OUT=MAIN/"docs/trackers/effort-steering/evidence/campaign-accounting-20261111"
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from campaign import accounting_totals

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def main():
    inventory_path=PLAN/"native-client-cost-inventory.json"
    inventory=json.loads(inventory_path.read_bytes())
    anchor=json.loads(ANCHOR.read_bytes())
    prefix=Decimal(anchor["prior_campaign_spend_usd"])
    assert prefix==Decimal("29.221154299999999834")
    assert len(inventory["selected"])==30 and not inventory["read_failures"]
    assert not set(inventory["selected"]) & set(inventory["unsettled_session_ids"])
    ledger={"ceiling_usd":"200","charges":[{"id":"recorded-pre-native-opening-balance",
        "cost_usd":str(prefix),"receipt_sha256":sha(ANCHOR),"source":str(ANCHOR),
        "basis":"Previously recorded opening balance; earlier raw charges NOT freshly rescanned."}],
        "holds":[],"reservations":[]}
    receipt_bindings={}
    for identity,item in sorted(inventory["selected"].items()):
        path=Path(item["path"])
        assert sha(path)==item["sha256"]
        row=json.loads(path.read_bytes())
        assert row["session_id"]==identity and row["scripted"] is False
        assert row["unknown_provider_cost"] is False and row["cost_usd"]==item["cost_usd"]
        receipt_bindings[str(path)]=sha(path)
        ledger["charges"].append({"id":"native-client:"+identity,"cost_usd":item["cost_usd"],
            "receipt_sha256":sha(path),"source":str(path),"basis":"Final non-scripted native client receipt."})
    assert set(inventory["unsettled_session_ids"])=={"98aaa6c0-110a-4a19-8789-b39df522284b"}
    unknown=inventory["unsettled_session_ids"]["98aaa6c0-110a-4a19-8789-b39df522284b"]
    assert len(unknown)==1
    path=Path(unknown[0]["path"]);assert sha(path)==unknown[0]["sha256"]
    row=json.loads(path.read_bytes())
    assert row["cost_usd"] is None and row["unknown_provider_cost"] is True and row["forwarded"]==0
    assert Decimal(str(row["campaign_available_usd"]))==Decimal("4")
    receipt_bindings[str(path)]=sha(path)
    ledger["holds"].append({"id":"native-client:"+row["session_id"],"reserved_usd":"4",
        "settled":False,"cost_usd":None,"receipt_sha256":sha(path),"source":str(path),
        "basis":"Original unresolved pre-provider-startup hold. Zero observed forwards is not a final invoice."})
    with localcontext() as context:
        context.prec=128
        known=sum((Decimal(item["cost_usd"]) for item in ledger["charges"]),Decimal(0))
        assert known==Decimal("64.401093499999998654")
        allocated=known+Decimal("4")+Decimal("38")
    totals=accounting_totals(ledger)
    assert Decimal(totals["committed_usd"])==known+Decimal("4")
    result={"schema":"client-ledger-reconciliation-v1","ledger":ledger,
        "known_client_cost_usd":str(known),"opening_balance_usd":str(prefix),
        "opening_balance_source":str(ANCHOR),"opening_balance_sha256":sha(ANCHOR),
        "native_receipts":30,"native_client_cost_usd":inventory["selected_sum_usd"],
        "receipt_bindings":receipt_bindings,"inventory_sha256":sha(inventory_path),
        "unresolved_reserve_usd":"4","proposed_new_allocation_usd":"38",
        "commitment_if_new_allocation_usd":str(allocated),
        "earlier_charge_rescan":False,"provider_invoice_reconciliation":False,
        "orchestration_review_embedding_compute_cost":"unmeasured",
        "paid_ready":False,
        "limits":["Opening balance retained from a previously recorded reconciliation, not a fresh earlier-charge rescan.",
                  "Original unknown remains unknown and fully reserved; no hold is released here.",
                  "This artifact does not alter the current admission rule or authorize a provider call."]}
    OUT.mkdir()
    with (OUT/"reconciliation.json").open("x") as stream: json.dump(result,stream,indent=2,sort_keys=True)
    for name,digest in receipt_bindings.items(): assert sha(name)==digest
    print(json.dumps({k:result[k] for k in ("known_client_cost_usd","opening_balance_usd",
        "native_receipts","native_client_cost_usd","unresolved_reserve_usd",
        "commitment_if_new_allocation_usd","earlier_charge_rescan","paid_ready")}))
if __name__=="__main__": main()
