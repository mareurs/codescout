"""Actual composed P malformed-submission controls; no provider or efficacy claim."""
import hashlib
import json
from pathlib import Path
import sys
from unittest.mock import patch

WORK = Path("/home/marius/.codex/worktrees/cf66/codescout")
sys.path.insert(0, str(WORK / "tools/effort_protocol"))
import executor
from campaign_native import invoke_native
from native_executor import RECON, external
from receipts import input_digest

ROOT = Path("/home/marius/.cache/codescout-resident/codescout/evidence-cohort-20261110")
FROZEN = Path("/home/marius/.cache/codescout-resident/codescout/common-preparation-20261109/common-frozen-v2")
BASE = Path("/tmp/effort-contract-resource-20261111-01a15ca9")
OUT = Path("/tmp/effort-native-composition-20261111-01a15ca9")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def no_upstream(*args, **kwargs):
    raise AssertionError("upstream forbidden in native composition control")


def main():
    OUT.mkdir()
    files = [Path(__file__), *sorted((WORK / "tools/effort_protocol").glob("*.py")),
             *sorted((WORK / "tools/agent_lifecycle").glob("*.py")), WORK/"tools/effort_protocol/prompts.json"]
    bindings = {str(path): sha(path) for path in files}
    save(OUT/"source-bindings.json", bindings)
    runtime = json.loads((FROZEN/"manifest.json").read_bytes())["runtime"]
    rows = []
    for stem in ("obscura-421", "lean-ctx-1168"):
        assert executor.LABEL == "codescout.effort-protocol"
        common = ROOT/("common-"+stem+"-v3")
        template = common/"project"
        source = BASE/stem/"public-source"
        prior = json.loads((common/"preparation.json").read_bytes())
        expected = json.loads((common/"native-canaries-v11/readiness-raw.json").read_bytes())["expected"]
        static = ["project.toml","system-prompt.md"] + [
            str(path.relative_to(template/".codescout")) for path in sorted((template/".codescout/memories").glob("*.md"))]
        public = {"image": prior["image"], "template": str(template),
            "template_sha256": input_digest(template), "knowledge_paths": static,
            "knowledge_sha256": input_digest(template/".codescout", static),
            "runtime_manifest": str(common/"native-runtime.json"), "runtime": runtime,
            "global_rules": str(FROZEN/"rules/global.md"), "global_rules_sha256": sha(FROZEN/"rules/global.md"),
            "embedding": {"service_id": "88e74239478cbedcf13732d05417292c3eed43054a2b1b3ea88f8d122abb1ff8",
                "service_image": "sha256:be175932c3c96e882dfbc7e20e0e834f58c89c2925f48b222837ee929dfc47ee",
                "upstream_network": "codescout-retrieval_retrieval_net",
                "subnet": json.loads((ROOT/"public-runtime-subnets-v1.json").read_bytes())["subnets"][stem]},
            "registered_readiness": {key: expected[key] for key in ("project_root","languages","tools","probes")},
            "execution_profile": "cargo-public-v1" if (common/"public-fixture.json").exists() else "cargo-v2",
            "cli_checks": [{"id": "public-context-file", "command": "test -f CLAUDE.md"}],
            "timeout_s": 180, "check_timeout_s": 30, "command_timeout_s": 900, "max_log_bytes": 67108864,
            "allowed_probe_prefixes": ["probes/"], "public_checks": [], "lsp_warmup_retries": 1,
            "resource_root": str(WORK), "resource_floors": {
                "root_free":80*1024**3,"tmp_free":4*1024**3,"mem_available":16*1024**3}}
        if (common/"public-fixture.json").exists():
            public["public_fixture"] = json.loads((common/"public-fixture.json").read_bytes())
        out = OUT/stem
        out.mkdir()
        request = {"invocation_id": "native-composition::"+stem, "arm":"P", "phase":"investigate",
            "source":str(source),"state":{"run_id":"native-composition-"+stem,"phase":"investigate",
                "turns_used":0,"used_receipts":[],
                "baseline_paths":sorted(path.relative_to(source).as_posix() for path in source.rglob("*")),
                "baseline_digest":input_digest(source)},
            "public_packet":{"issue":"Qualification: report public context; this is an intentionally malformed evidence submission."},
            "allowance_usd":"0.60","cli_cap_usd":"0.55","max_continuations":2}
        save(out/"registration.json", {"request":request,"public":public,"paid_ready":False})
        plan = [("Skill", {"skill":RECON}),
            ("mcp__codescout__read_file",{"path":".codescout/system-prompt.md","force":True,"start_line":1,"end_line":100}),
            ("mcp__codescout__workspace",{"action":"status"}),
            ("mcp__codescout__create_file",{"path":"submission.json","content":json.dumps({"status":"submitted","clauses":[],"commands":[]})})]
        print(json.dumps({"project":stem,"starting":True}),flush=True)
        with patch.object(external.transport.Proxy,"upstream",no_upstream):
            result = invoke_native(request,out,public,mode="scripted",scripted_plan=plan)
        assert not result["measurement_invalid"],result
        assert result["state"]["phase"]=="incomplete" and result["state"]["turns_used"]==result["turns"]>=1,result
        assert result["cost_usd"]=="0" and result["cost_is_final"]
        assert result["actor_started"] and result["capture_complete"] and result["cleanup_complete"]
        launch = json.loads((out/"native/launch.json").read_bytes())
        raw = json.loads((out/"native/receipt.json").read_bytes())
        assert launch["real_credentials_read"] is False and raw["forwarded"]==0
        assert executor.LABEL=="codescout.effort-protocol"
        rows.append({"project":stem,"state":"incomplete","turns":result["turns"],
                     "cost_usd":"0","forwarded":0,"measurement_valid":True,"paid_ready":False})
        save(out/"verified.json",rows[-1])
        print(json.dumps(rows[-1]),flush=True)
    for path, expected_hash in bindings.items():
        assert sha(path)==expected_hash,path
    save(OUT/"result.json",{"controls":rows,"paid_ready":False})


if __name__=="__main__":
    main()
