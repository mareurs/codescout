"""Recover sealed inputs onto persistent scratch; never fabricate missing run outputs."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import tarfile

WORK = Path("/home/marius/.codex/worktrees/cf66/codescout")
PLAN = WORK/".superpowers/sdd/2026-11-10-campaign-integration"
MAIN = Path("/home/marius/work/claude/codescout")
ROOT = Path("/var/tmp/ep11-01a15")
sys.path.insert(0, str(WORK/"tools/effort_protocol"))
from receipts import input_digest

def load(name):
    spec = importlib.util.spec_from_file_location("disk_"+name, PLAN/(name+".py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")

def main():
    ROOT.mkdir(mode=0o700)
    source = MAIN/"docs/trackers/effort-steering/evidence/contract-resources-20261111/evidence.tar.gz"
    assert hashlib.sha256(source.read_bytes()).hexdigest() == "07fca37fce6f3afc7976d1d3d8defc4c07996bb7cc0e26722b6fd7081dfe8860"
    # The exact identity above is checked against the durable closure below too.
    closure = json.loads((source.parent/"closure.json").read_bytes())
    assert hashlib.sha256(source.read_bytes()).hexdigest() == closure["sha256"]
    counts = {}
    with tarfile.open(source) as archive:
        manifest = json.loads(archive.extractfile("manifest.json").read())["entries"]
        for stem in ("obscura-421", "lean-ctx-1168"):
            prefix = "control/"+stem+"/public-source"
            selected = [member for member in archive.getmembers()
                        if member.name == prefix or member.name.startswith(prefix+"/")]
            assert selected
            for member in selected:
                rel = PurePosixPath(member.name).relative_to("control")
                assert not rel.is_absolute() and ".." not in rel.parts
                target = ROOT/"base"/rel
                row = manifest[member.name]
                if member.isdir():
                    target.mkdir(parents=True, exist_ok=True)
                elif member.isfile():
                    raw = archive.extractfile(member).read()
                    assert hashlib.sha256(raw).hexdigest() == row["sha256"]
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with target.open("xb") as stream: stream.write(raw)
                    target.chmod(row["mode"])
                    assert hashlib.sha256(target.read_bytes()).hexdigest() == row["sha256"]
                elif member.issym():
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.symlink_to(row["target"])
                else:
                    raise ValueError("unsupported archived source member")
            registered = json.loads(archive.extractfile("control/"+stem+"/registration.json").read())
            actual = input_digest(ROOT/"base"/stem/"public-source")
            assert actual == registered["source_digest"], (stem, actual, registered["source_digest"])
            counts[stem] = {"entries":len(selected), "source_digest":actual}
    exporter = load("export_private_package")
    exporter.OUT = ROOT/"private-package"
    exporter.main()
    save(ROOT/"restoration.json", {"source_archive_sha256":closure["sha256"],
        "public_sources":counts, "private_sources":99,
        "scope":"Immutable inputs only. Missing prior runtime outputs were not reconstructed.",
        "paid_ready":False})
    print(json.dumps({"restored":str(ROOT), "sources":counts, "paid_ready":False}), flush=True)

if __name__ == "__main__":
    main()
