"""Export only sealed original sources and acceptance records; never mutation copies."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile

MAIN = Path("/home/marius/work/claude/codescout")
EVIDENCE = MAIN/"docs/trackers/effort-steering/evidence"
OUT = Path("/tmp/effort-private-package-20261111-01a15ca9")
ARCHIVES = {
    "evaluator": ("prospective-linker-20261110/final-evidence.tar.gz",
        "06c45de573b8b249b23c3d3585eb8fdf9ccaf281e161c1e4d8bb90eaabe62f3d"),
    "lean": ("full-lean-superset-controls-v2-20261110/verification.tar.gz",
        "a052683ec061ada7d6f283b9d47e215cf322f0b3cbd6709a45a41d6f4d403fde"),
    "obscura": ("full-obscura-fixture-v5-20261110/verification.tar.gz",
        "ef33dbccbe796dfbdb22ea6baeef603ecbb9955da6fa2b58836c607505e57b20")}
SELECT = {
    "lean": ["native-controls/full-record.json",
        "helpers/qualify-lean-full-superset-20261110.py"],
    "obscura": ["private-plan/full-native-v5/full-record.json",
        "private-plan/full-native-v5/loopback_page.py"]}
def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    OUT.mkdir()
    payloads = {}
    for role,(name,expected) in ARCHIVES.items():
        source = EVIDENCE/name
        assert sha(source.read_bytes()) == expected
        with tarfile.open(source) as archive:
            members = [m for m in archive.getmembers() if
                m.name.startswith("source/tools/setup-ab-eval/")] if role=="evaluator" else [
                    archive.getmember(name) for name in SELECT[role]]
            if role=="evaluator":
                assert len(members)==99, len(members)
            assert len({m.name for m in members})==len(members)
            for member in members:
                rel = PurePosixPath(member.name)
                assert member.isfile() and not rel.is_absolute() and ".." not in rel.parts
                data = archive.extractfile(member).read()
                target = OUT/role/rel
                target.parent.mkdir(parents=True,exist_ok=True)
                with target.open("xb") as stream: stream.write(data)
                assert target.read_bytes()==data
                payloads[str(target.relative_to(OUT))] = sha(data)
        if role != "evaluator":
            registration = source.parent/"registration.json"
            data = registration.read_bytes()
            target = OUT/role/"registration.json"
            with target.open("xb") as stream: stream.write(data)
            payloads[str(target.relative_to(OUT))] = sha(data)
    result = {"archives": ARCHIVES, "files": payloads, "source_count":99,
              "package":str(OUT/"evaluator/source/tools/setup-ab-eval"),"paid_ready":False}
    with (OUT/"export.json").open("x") as stream: json.dump(result,stream,indent=2,sort_keys=True)
    for name,expected in payloads.items(): assert sha((OUT/name).read_bytes())==expected
    print(json.dumps({"output":str(OUT),"source_count":99,"total_files":len(payloads),"paid_ready":False}))
if __name__=="__main__": main()
