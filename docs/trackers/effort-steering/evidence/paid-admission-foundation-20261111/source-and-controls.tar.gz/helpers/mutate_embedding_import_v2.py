"""Calibrate isolated baseline before classifying the import-namespace mutant."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

WORK = Path("/home/marius/.codex/worktrees/cf66/codescout")
OUT = WORK / ".superpowers/sdd/2026-11-10-campaign-integration"
root = Path(tempfile.mkdtemp(prefix="embedding-import-mutant-v2-"))
for name in ("effort_protocol", "agent_lifecycle"):
    folder = root / name
    folder.mkdir()
    for path in (WORK / "tools" / name).iterdir():
        if path.is_file() and path.suffix in (".py", ".json"):
            shutil.copy2(path, folder / path.name)
env = dict(os.environ, PYTHONPATH=str(WORK / "tools/hint_authority_pilot"))
argv = [sys.executable, "-B", "-m", "unittest", "discover", "-s",
        str(root / "effort_protocol"), "-p", "test_embedding_runtime.py"]
baseline = subprocess.run(argv, capture_output=True, text=True, env=env)
(OUT / "embedding-import-baseline-v2.log").write_text(baseline.stdout + baseline.stderr)
assert baseline.returncode == 0 and "Ran 4 tests" in baseline.stderr, baseline.stderr
path = root / "effort_protocol/embedding_runtime.py"
original = path.read_text()
mutated = original.replace("from receipts import publish_exclusive",
    "from receipts import publish_exclusive\nimport executor\nexecutor.LABEL = 'wrong-import-namespace'", 1)
assert mutated != original
path.write_text(mutated)
result = subprocess.run(argv, capture_output=True, text=True, env=env)
(OUT / "embedding-import-mutant-v2.log").write_text(result.stdout + result.stderr)
valid = "Ran 4 tests" in result.stderr and "Failed to import test module" not in result.stderr
report = {"isolated_root": str(root), "mutation": "import overwrites executor.LABEL",
    "baseline_exit": baseline.returncode, "observed_test_exit": result.returncode,
    "valid": valid, "survived": valid and result.returncode == 0}
(OUT / "embedding-import-mutant-v2.json").write_text(json.dumps(report, indent=2)+"\n")
print(json.dumps(report))
