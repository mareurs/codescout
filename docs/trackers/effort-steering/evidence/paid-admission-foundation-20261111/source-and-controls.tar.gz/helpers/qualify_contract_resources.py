"""Two real CLI delivery/resource controls; scripted zero-provider, not efficacy."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import uuid
from unittest.mock import patch

WORK = Path("/home/marius/.codex/worktrees/cf66/codescout")
sys.path[:0] = [str(WORK / "tools/effort_protocol"), str(WORK / "tools/agent_lifecycle")]
import adapter
import native_executor
import preparation
import public_fixture
from campaign_resources import ResourceSupervisor, measure_host
from embedding_profile import validate_embedding_profile
from qualify_native import _native_argv
from receipts import input_digest

HELPER = Path("/tmp/shared-public-runtime-correction-20261110/qualify_all_arms_v3.py")
spec = importlib.util.spec_from_file_location("qualified_public_runtime_v3", HELPER)
runtime_helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runtime_helper)
ROOT = runtime_helper.ROOT
OUT = Path("/tmp/effort-contract-resource-20261111-01a15ca9")
FLOORS = {"root_free": 80 * 1024**3, "tmp_free": 4 * 1024**3, "mem_available": 16 * 1024**3}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")


def no_upstream(*args, **kwargs):
    raise AssertionError("provider forwarding prohibited in model-free control")


def qualify(stem):
    parent = ROOT / ("common-" + stem + "-v3")
    project = parent / "project"
    prior = json.loads((parent / "preparation.json").read_bytes())
    proof_path = parent / "native-canaries-v11/readiness-raw.json"
    proof = json.loads(proof_path.read_bytes())
    before = native_executor._public_digest(project)
    assert before == prior["prepared_public_digest"]
    fixture_path = parent / "public-fixture.json"
    fixture = json.loads(fixture_path.read_bytes()) if fixture_path.exists() else None
    frozen = runtime_helper.OLD / "common-frozen-v2"
    manifest = json.loads((frozen / "manifest.json").read_bytes())
    runtime = manifest["runtime"]
    assert preparation._runtime(preparation._runtime_inputs(runtime)) == runtime
    rules = frozen / "rules/global.md"
    assert sha(rules) == manifest["global_rules_sha256"]
    out = OUT / stem
    out.mkdir()
    subnet = json.loads((ROOT / "public-runtime-subnets-v1.json").read_bytes())["subnets"][stem]
    save(out / "registration.json", {"source_digest": before, "readiness_sha256": sha(proof_path),
        "public_fixture": fixture, "runtime": runtime, "global_rules_sha256": sha(rules),
        "legacy_helper_sha256": sha(HELPER), "floors": FLOORS, "paid_ready": False,
        "scope": "P investigate intentionally incomplete; actual delivery and sampled resources only"})
    with runtime_helper.relay_runtime(out, prior["image"], subnet) as embedding:
        stage = out / "native"
        stage.mkdir()
        actor = stage / "actor"
        native_executor._capture(project, actor)
        shutil.copytree(project / ".git", actor / ".git", symlinks=True)
        shutil.copytree(project / ".codescout", actor / ".codescout", symlinks=True)
        assert native_executor._public_digest(actor) == before
        baseline = subprocess.check_output(["git", "-C", str(actor), "rev-parse", "HEAD"], text=True).strip()
        home = stage / "native-home"
        home.mkdir()
        argv = _native_argv(actor, home, {"runtime_manifest": str(parent / "native-runtime.json"),
                                        "native_image": prior["image"]})
        name = "ep-cli-" + uuid.uuid4().hex
        argv[argv.index("--name") + 1] = name
        argv[argv.index("--label") + 1] = "codescout.hfa=" + name
        argv[argv.index("--network") + 1] = embedding["network_id"]
        argv[argv.index("--tmpfs") + 1] = "/tmp:rw,exec,size=16g,uid=1000,gid=1000"
        argv.insert(argv.index("--init"), "--read-only")
        argv[-4:-4] = ["--cap-drop", "ALL", "--security-opt", "no-new-privileges",
                       "-e", "CARGO_TARGET_DIR=/tmp/target"]
        if fixture is not None:
            position = argv.index("--entrypoint")
            del argv[position:position + 2]
            argv[-4:-4] = public_fixture.fixture_docker_options(fixture, "native")
        options = {key: [argv[i + 1] for i, value in enumerate(argv[:-4]) if value == key]
                   for key in ("--network", "--tmpfs", "--cap-drop", "--security-opt")}
        options["--read-only"] = [True]
        save(stage / "embedding-admission.json", validate_embedding_profile(embedding, options, prior["image"]))
        native_path = stage / "mcp-native-argv.json"
        save(native_path, argv)
        static = ["project.toml", "system-prompt.md"] + [
            str(p.relative_to(actor / ".codescout"))
            for p in sorted((actor / ".codescout/memories").glob("*.md"))]
        config = {"actor": str(actor), "image": prior["image"], "baseline_commit": baseline,
            "cli": runtime["files"]["cli"]["path"], "plugin": runtime["plugin"]["path"],
            "global_rules": str(rules), "prompt": "qualification",
            "checks": [{"id": "public-context-file", "command": "test -f CLAUDE.md"}],
            "timeout_s": 180, "check_timeout_s": 30, "max_continuations": 2,
            "knowledge_paths": static, "embedding_profile": embedding,
            **({"public_fixture": fixture} if fixture else {}),
            "files": {str(p): sha(p) for p in (native_path, rules, Path(runtime["files"]["cli"]["path"]), actor / "CLAUDE.md")}}
        save(stage / "prepared.json", config)
        script = [("Skill", {"skill": native_executor.RECON}),
            ("mcp__codescout__read_file", {"path": ".codescout/system-prompt.md", "force": True,
                                          "start_line": 1, "end_line": 100}),
            ("mcp__codescout__workspace", {"action": "status"})]
        code = "print('public-contract-runtime-control')"
        if fixture:
            bundle = public_fixture.read_fixture_bundle(fixture)
            code = "import urllib.request;print(urllib.request.urlopen(" + repr(
                "http://" + bundle["hostname"] + ":" + str(bundle["port"]) + "/") + ").read().decode(),end='')"
        script += [("mcp__codescout__run_command", {"command": "python3 -I -c " + shlex.quote(code),
                                                  "timeout_secs": 15}),
                   ("mcp__codescout__create_file", {"path": "submission.json",
                    "content": json.dumps({"status": "incomplete", "clauses": [], "commands": []})})]
        profile = {"Memory": 32 * 1024**3, "MemorySwap": 32 * 1024**3, "NanoCpus": 4 * 10**9,
            "PidsLimit": 4096, "ReadonlyRootfs": True, "NetworkMode": embedding["network_id"],
            "CapDrop": ["ALL"], "SecurityOpt": ["no-new-privileges"],
            "Tmpfs": {"/tmp": "/tmp:".join(argv[argv.index("--tmpfs") + 1].split("/tmp:")[1:])}}
        supervisor = ResourceSupervisor(floors=FLOORS, native_profile=profile, root=WORK)
        backend = native_executor.NativeExecutor(stage, out / "native-captured",
            system_lines=native_executor.external.worker.visible((actor / ".codescout/system-prompt.md").read_text()),
            recon_marker="Base directory for this skill:", scripted_plan=script, supervisor=supervisor)
        public = out / "public-source"
        native_executor._capture(project, public)
        state = {"run_id": "contract-" + stem, "phase": "investigate", "turns_used": 0,
            "baseline_paths": sorted(p.relative_to(public).as_posix() for p in public.rglob("*")),
            "baseline_digest": input_digest(public), "used_receipts": []}
        request = {"state": state, "out": str(out / "phase"), "arm": "P", "phase_budget_usd": "0.60",
            "cli_cap_usd": "0.55", "image": prior["image"], "execution_mode": "native",
            "native_preflight": proof, "execution_profile": "cargo-public-v1" if fixture else "cargo-v2",
            **({"public_fixture": fixture} if fixture else {}),
            "public_packet": {"issue": "Qualification: report public context and declare this control incomplete."},
            "allowed_probe_prefixes": ["probes/"], "public_checks": [],
            "command_timeout_s": 900, "max_log_bytes": 64 * 1024 * 1024}
        print(json.dumps({"stem": stem, "starting": True}), flush=True)
        with patch.object(native_executor.external.transport.Proxy, "upstream", no_upstream):
            outcome = adapter.run_phase(request, backend)
        receipt = json.loads((stage / "native-executor.json").read_bytes())
        lifecycle = json.loads((stage / "receipt.json").read_bytes())
        assert outcome["state"]["phase"] == "incomplete", outcome
        assert outcome["measurement_invalid"] is False, outcome
        assert all(receipt[key] is True for key in ("context_valid", "cleanup_complete", "capture_complete", "cost_is_final")), receipt
        assert receipt["provider_forwarded"] == 0 and receipt["cost_usd"] == "0", receipt
        assert supervisor.proof()["complete"], supervisor.proof()
        launch = json.loads((stage / "launch.json").read_bytes())
        assert launch["real_credentials_read"] is False
        assert launch["argv"][launch["argv"].index("--max-budget-usd") + 1] == "0.55"
        packet = json.loads((out / "phase/actor-packet.json").read_bytes())
        prompt = packet["prompt"]
        assert "public-submission-contract-v1" in prompt
        bodies = [json.loads(p.read_bytes()) for p in sorted(stage.glob("request-*.json"))]
        assert bodies and all(body["output_config"]["effort"] == "low" for body in bodies)
        texts = [item["text"] for body in bodies for message in body.get("messages", [])
                 if message.get("role") == "user" for item in (
                     message["content"] if isinstance(message.get("content"), list) else [])
                 if isinstance(item, dict) and item.get("type") == "text"]
        assert any(prompt in text for text in texts), "exact actor contract missing in real request"
        assert native_executor._public_digest(project) == before
        save(out / "result.json", {"scope": "synthetic intentionally incomplete runtime control",
            "actual_request_bodies": len(bodies), "exact_prompt_delivered": True, "effort": "low",
            "cli_cap_usd": "0.55", "provider_forwarded": 0, "model_cost_usd": "0",
            "real_credentials_read": False, "supervision": supervisor.proof(), "native": receipt,
            "workflow_completed": lifecycle["workflow_completed"], "state": outcome["state"]["phase"],
            "onboarding_author_calls": 0, "paid_ready": False})
    print(json.dumps({"stem": stem, "finished": True, "paid_ready": False}), flush=True)


def main():
    OUT.mkdir(exist_ok=False)
    files = [HELPER, Path(__file__)] + sorted((WORK / "tools/effort_protocol").glob("*.py")) + [
        WORK / "tools/effort_protocol/prompts.json"] + sorted((WORK / "tools/agent_lifecycle").glob("*.py"))
    save(OUT / "source-bindings.json", {str(p): sha(p) for p in files})
    measured = measure_host(WORK, "/tmp")
    assert measured["tmp_exec"] and all(measured[k] >= floor for k, floor in FLOORS.items()), measured
    save(OUT / "host-before.json", measured)
    for stem in ("obscura-421", "lean-ctx-1168"):
        qualify(stem)
    for path, expected in json.loads((OUT / "source-bindings.json").read_bytes()).items():
        assert sha(path) == expected, path
    save(OUT / "complete.json", {"controls": 2, "paid_ready": False, "model_cost_usd": "0"})


if __name__ == "__main__":
    main()
