"""Actual CLI controls on persistent scratch; retain previous volatile results as history."""
import json
from pathlib import Path
import qualify_native_composition as control
import qualify_native_composition_v2 as checks

ROOT = Path("/var/tmp/ep11-01a15")

def main():
    control.BASE = ROOT/"base"
    control.OUT = ROOT/"native-controls"
    checks.OUT = control.OUT
    checks.main()
    for stem in ("obscura-421", "lean-ctx-1168"):
        native = control.OUT/stem/"native"
        launch = json.loads((native/"launch.json").read_bytes())
        temporary = Path(launch["client_temporary"])
        assert temporary.parent == Path("/var/tmp") and temporary.is_dir()
        assert temporary.stat().st_mode & 0o777 == 0o700
        assert len(str(temporary)) < 40
        events = json.loads((native/"supervision-final.json").read_bytes())
        assert events["complete"]
    print(json.dumps({"disk_runtime_valid":True,"paid_ready":False}), flush=True)

if __name__ == "__main__":
    main()
