"""Recompute the real frozen public cohort; no model/private outcome read."""
import hashlib
import json
from pathlib import Path
import sys
import tarfile

WORK=Path("/home/marius/.codex/worktrees/cf66/codescout")
MAIN=Path("/home/marius/work/claude/codescout")
OUT=Path("/var/tmp/ep11-01a15/population-admission-v2")
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from paid_admission import verify_population

def main():
    archive=MAIN/"docs/trackers/effort-steering/evidence/public-cohort-20261110/verification.tar.gz"
    expected="98500549aabe4b1101229f489595d562c2a77519b372f723835943c87bd16145"
    assert hashlib.sha256(archive.read_bytes()).hexdigest()==expected
    members={"metadata":"public-selection-v3/inputs/metadata-universe.json",
        "exposure":"public-selection-v3/inputs/exposure-exclusions.json",
        "status":"frozen-public-cohort-v1/qualification-status-v4.json",
        "rule":"public-selection-v3/inputs/selection-rule.json",
        "freeze":"frozen-public-cohort-v1/registration.json",
        "selection":"frozen-public-cohort-v1/selection-final-v1.json"}
    with tarfile.open(archive) as packed:
        records={key:json.loads(packed.extractfile(name).read()) for key,name in members.items()}
    status=records["status"]
    metadata=[{**row,"eligible":status[row["id"]]["eligible"],"reason":status[row["id"]]["reason"]}
        for row in records["metadata"]["tasks"]]
    proof={"path":str(archive),"sha256":expected,"members":members}
    registration={"metadata":metadata,"exposure":sorted(records["exposure"]["tasks"]),
        "seed":records["rule"]["seed"],"selected":records["selection"]["selected"],
        "bindings":{str(archive):expected}}
    checked=verify_population(registration,proof)
    OUT.mkdir()
    for name,value in [("registration-inputs.json",registration),
                       ("population-proof.json",proof),
                       ("readback.json",{"verified":checked,"provider_calls":0,"paid_ready":False})]:
        with (OUT/name).open("x") as stream:
            json.dump(value,stream,sort_keys=True,indent=2)
            stream.write("\n")
    print(json.dumps({"verified":checked,"provider_calls":0,"paid_ready":False}),flush=True)

if __name__=="__main__":
    main()
