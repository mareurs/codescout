"""Read-only recheck of six already sealed acceptance controls; no regrade."""
import hashlib
import json
from pathlib import Path
import tarfile

MAIN=Path("/home/marius/work/claude/codescout")
E=MAIN/"docs/trackers/effort-steering/evidence"
FROZEN=Path("/tmp/effort-private-package-20261111-01a15ca9")
OUT=Path("/home/marius/.codex/worktrees/cf66/codescout/.superpowers/sdd/2026-11-10-campaign-integration/frozen-acceptance-audit.json")
CASES=(
    ("lean","full-lean-superset-controls-v2-20261110","native-controls",8591,3,
     "a052683ec061ada7d6f283b9d47e215cf322f0b3cbd6709a45a41d6f4d403fde"),
    ("obscura","full-obscura-fixture-v5-20261110","private-plan/full-native-v5",331,2,
     "ef33dbccbe796dfbdb22ea6baeef603ecbb9955da6fa2b58836c607505e57b20"))
def main():
    rows=[]
    for role,directory,prefix,total,bad,digest in CASES:
        archive=E/directory/"verification.tar.gz"
        assert hashlib.sha256(archive.read_bytes()).hexdigest()==digest
        accepted=json.loads((FROZEN/role/"registration.json").read_bytes())
        expected=accepted["original_f2p"]+accepted.get("new_f2p",[])+accepted["original_p2p"]+accepted.get("new_p2p",[])
        failures=set(accepted.get("new_f2p") or accepted["original_f2p"])
        assert len(expected)==len(set(expected))==total
        controls={}
        with tarfile.open(archive) as tar:
            for case in ("base","reference","reference-repeat"):
                name=prefix+"/"+case+"/result.json"
                data=tar.extractfile(name).read()
                result=json.loads(data);raw=result["raw"]
                assert raw["expected"]==total and raw["missing"]==0
                assert raw["not_passing"]==(bad if case=="base" else 0)
                assert raw["pass"] is (case!="base")
                for key in ("applied_source_bytes_verified","complete_stream_contract",
                            "fresh_container_absent","original_full_expected_population_executed","source_unchanged"):
                    assert result[key] is True,(role,case,key)
                if role=="obscura": assert result["service_bytes_verified"] is True
                statuses=result["statuses"]
                assert set(statuses)==set(expected)
                assert {key for key,value in statuses.items() if value!="pass"}==(failures if case=="base" else set())
                controls[case]=statuses
                rows.append({"role":role,"control":case,"archive_sha256":digest,"member":name,
                    "member_sha256":hashlib.sha256(data).hexdigest(),"expected":total,
                    "not_passing":raw["not_passing"],"missing":0,"complete_stream_contract":True,
                    "source_bytes_verified":True,"fresh_absence":True})
        assert controls["reference"]==controls["reference-repeat"]
    with OUT.open("x") as stream: json.dump({"controls":rows,"fresh_compiler_runs":0,
        "historical_results_changed":False,"paid_ready":False},stream,indent=2,sort_keys=True)
    print(json.dumps({"controls_reopened":len(rows),"fresh_compiler_runs":0,"all_predicates":True,"paid_ready":False}))
if __name__=="__main__": main()
