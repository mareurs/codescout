"""Qualify the new private subprocess against prior scripted native baseline captures."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

WORK = Path("/home/marius/.codex/worktrees/cf66/codescout")
MAIN = Path("/home/marius/work/claude/codescout")
FROZEN = Path("/tmp/effort-private-package-20261111-01a15ca9")
PUBLIC = Path("/tmp/effort-native-composition-v2-20261111-01a15ca9")
OUT = Path("/tmp/effort-private-entry-qualification-v3-20261111-01a15ca9")
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
import evaluator_entry as entry
from receipts import input_digest
PACKAGE = FROZEN/"evaluator/source/tools/setup-ab-eval"
sys.path.insert(0,str(PACKAGE))
import multilang_tasks as tasks

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):
    with Path(path).open("x") as stream: json.dump(value,stream,indent=2,sort_keys=True)
def image_test_files(image, names, out):
    import base64
    import uuid
    name = "ep-private-test-export-"+uuid.uuid4().hex
    code = """import base64,json,subprocess,sys
names=json.loads(sys.argv[1])
head=subprocess.check_output(['git','-C','/testbed','rev-parse','HEAD'],text=True).strip()
files={}
for name in names:
    p=subprocess.run(['git','-C','/testbed','show','HEAD:'+name],capture_output=True)
    files[name]={'returncode':p.returncode,'data':base64.b64encode(p.stdout).decode(),'stderr':p.stderr.decode(errors='replace')}
print(json.dumps({'head':head,'files':files}))
"""
    argv=["docker","run","--rm","--name",name,"--label","codescout.effort-private-export="+name,
        "--user","0:0","--network","none","--read-only","--cap-drop","ALL","--security-opt","no-new-privileges",
        "--memory","256m","--cpus","1","--pids-limit","128","--entrypoint","python3",image,"-c",code,json.dumps(names)]
    result=subprocess.run(argv,capture_output=True,text=True,timeout=120)
    absent=subprocess.run(["docker","container","inspect",name],capture_output=True,text=True,timeout=30)
    save(out/"image-test-export.json",{"argv":argv,"returncode":result.returncode,
        "stdout":result.stdout,"stderr":result.stderr,"fresh_absence":absent.returncode!=0 and "No such container" in absent.stderr})
    assert result.returncode==0 and absent.returncode!=0 and "No such container" in absent.stderr
    packet=json.loads(result.stdout)
    return {name:base64.b64decode(item["data"]) for name,item in packet["files"].items() if item["returncode"]==0}

def main():
    OUT.mkdir()
    exported=json.loads((FROZEN/"export.json").read_bytes())
    package_files={name.removeprefix("evaluator/source/tools/setup-ab-eval/"):digest
        for name,digest in exported["files"].items() if name.startswith("evaluator/source/tools/setup-ab-eval/")}
    entry.verify_package(PACKAGE,package_files)
    bindings={str(FROZEN/name):digest for name,digest in exported["files"].items()}
    for name,digest in exported["archives"].values():
        path=MAIN/"docs/trackers/effort-steering/evidence"/name
        assert sha(path)==digest
        bindings[str(path)]=digest
    rows=[]
    for role,stem,record_name in (
        ("obscura","obscura-421","private-plan/full-native-v5/full-record.json"),
        ("lean","lean-ctx-1168","native-controls/full-record.json")):
        out=OUT/role;out.mkdir()
        record_path=FROZEN/role/record_name
        record=json.loads(record_path.read_bytes())
        accepted_path=FROZEN/role/"registration.json"
        accepted=json.loads(accepted_path.read_bytes())
        assert sha(record_path)==accepted["record_sha256"]
        prior=json.loads((PUBLIC/stem/"registration.json").read_bytes())
        template=Path(prior["public"]["template"])
        fixed=out/"fixed-tests";fixed.mkdir()
        test_files=tasks.tasks.patch_files(record["test_patch"])
        for name in test_files:
            entry._relative(name)
        image_files=image_test_files(accepted["image"],test_files,out)
        for name,data in image_files.items():
            path=fixed/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
        patch=out/"official-tests.patch";patch.write_text(record["test_patch"])
        applied=subprocess.run(["git","apply","--binary",str(patch)],cwd=fixed,capture_output=True)
        save(out/"official-apply.json",{"returncode":applied.returncode,
            "stdout":applied.stdout.decode(errors="replace"),"stderr":applied.stderr.decode(errors="replace")})
        assert applied.returncode==0
        fixed_sha={"/testbed/"+name:sha(fixed/name) for name in test_files}
        production=accepted.get("production_paths")
        if production is None:
            production=[name.removeprefix("/testbed/") for name in accepted["expected_source_by_control"]["base"]]
        config={"package_root":str(PACKAGE),"package_files":package_files,"bindings":bindings,
            "record":str(record_path),"acceptance_registration":str(accepted_path),
            "image":accepted["image"],"stream_registration":accepted["stream_registration"],
            "production_paths":production,"fixed_test_sha256":fixed_sha,
            "diagnostic_artifacts":{"0":["rust/1"]} if role=="lean" else {},"fixture":None}
        if role=="obscura":
            program=FROZEN/role/"private-plan/full-native-v5/loopback_page.py"
            spec=json.loads(Path("/home/marius/.cache/codescout-resident/codescout/evidence-cohort-20261110/public-page-fixture-v1/spec.json").read_bytes())
            config["fixture"]={"program":str(program),"program_sha256":sha(program),
                "hostname":spec["hostname"],"port":spec["port"],
                "body_sha256":hashlib.sha256(spec["routes"]["/"]["body"].encode()).hexdigest()}
        config_path=out/"config.json";save(config_path,config)
        invocation=json.loads((PUBLIC/stem/"invocation.json").read_bytes())
        native=PUBLIC/stem/"native"
        source=invocation["candidate"]
        baseline=prior["request"]["source"]
        request={"task_id":record["instance_id"],"arm":"P","source":source,
            "source_digest":input_digest(source),"public_baseline":baseline,
            "public_baseline_sha256":input_digest(baseline),
            "patch":str(native/"candidate.patch"),"patch_sha256":sha(native/"candidate.patch"),
            "capture_proof":str(native/"candidate-capture.json"),
            "capture_proof_sha256":sha(native/"candidate-capture.json"),
            "config":str(config_path),"config_sha256":sha(config_path)}
        request_path=out/"request.json";save(request_path,request)
        save(out/"registration.json",{"entry_sha256":sha(WORK/"tools/effort_protocol/evaluator_entry.py"),
            "request_sha256":sha(request_path),"config_sha256":sha(config_path),
            "scope":"prior intentionally malformed native baseline candidate; no model call",
            "paid_ready":False})
        print(json.dumps({"role":role,"starting":True}),flush=True)
        env={key:value for key,value in os.environ.items() if key in ("PATH","HOME","USER","LANG","TMPDIR")}
        with (out/"process.stdout").open("xb") as stdout,(out/"process.stderr").open("xb") as stderr:
            result=subprocess.run([sys.executable,"-I","-B",str(WORK/"tools/effort_protocol/evaluator_entry.py"),
                str(request_path),str(out)],stdout=stdout,stderr=stderr,env=env,timeout=3600)
        verdict=json.loads((out/"verdict.json").read_bytes())
        row={"role":role,"returncode":result.returncode,"valid":verdict.get("valid"),
            "pass":verdict.get("pass"),"kind":verdict.get("kind"),"reason":verdict.get("reason"),
            "expected_baseline_not_passing":2 if role=="obscura" else 3,"provider_calls":0}
        rows.append(row);save(out/"verified-summary.json",row);print(json.dumps(row),flush=True)
        if result.returncode!=0 or verdict.get("valid") is not True:
            save(OUT/"stopped.json",{"rows":rows,"unexecuted":["lean"] if role=="obscura" else [],"paid_ready":False})
            raise RuntimeError("private boundary qualification invalid")
        assert verdict["pass"] is False,verdict
    save(OUT/"result.json",{"rows":rows,"paid_ready":False,"provider_calls":0})
if __name__=="__main__": main()
