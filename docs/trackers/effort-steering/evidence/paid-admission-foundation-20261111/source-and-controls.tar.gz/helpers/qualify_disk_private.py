"""Qualify the unchanged frozen private package using current disk-backed native captures."""
import sys
from pathlib import Path

ROOT = Path("/var/tmp/ep11-01a15")
sys.path.insert(0,str(ROOT/"private-package/evaluator/source/tools/setup-ab-eval"))
import qualify_private_entry as control

def main():
    control.FROZEN = ROOT/"private-package"
    control.PACKAGE = ROOT/"private-package/evaluator/source/tools/setup-ab-eval"
    control.PUBLIC = ROOT/"native-controls"
    control.OUT = ROOT/"private-controls"
    control.main()

if __name__ == "__main__":
    main()
