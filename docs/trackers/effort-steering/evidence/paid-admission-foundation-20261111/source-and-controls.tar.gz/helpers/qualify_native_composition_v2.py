"""Requalify composed startup with the measured CLI legacy setting and retained stdio."""
import hashlib
import json
from pathlib import Path
import qualify_native_composition as previous

OUT = Path("/tmp/effort-native-composition-v2-20261111-01a15ca9")


def main():
    previous.OUT = OUT
    registration = OUT.with_suffix(".registration.json")
    previous.save(registration, {"output": str(OUT), "launcher": str(Path(__file__).resolve()),
        "launcher_sha256": previous.sha(Path(__file__)), "public_driver": str(previous.__file__),
        "driver_sha256": previous.sha(Path(previous.__file__)), "paid_ready": False,
        "scope": "same intentionally malformed scripted P control after CLI-only legacy/source fixes"})
    previous.main()
    checks = []
    for stem in ("obscura-421", "lean-ctx-1168"):
        native = OUT/stem/"native"
        launch = json.loads((native/"launch.json").read_bytes())
        assert launch["mcp_protocol_negotiation"] == "legacy"
        rows = [json.loads(path.read_bytes()) for path in native.glob("mcp-launch-*.json")]
        assert len(rows) == 1, rows
        assert "--rm" not in rows[0]["argv"]
        stderr = Path(rows[0]["stderr_path"])
        assert stderr.is_file() and stderr.name == "native-stderr-" + rows[0]["name"] + ".log"
        resources = json.loads((native/"supervision-final.json").read_bytes())
        assert resources["complete"] and resources["cgroup_probes"] >= 2 and resources["oom_kill"] == 0
        checks.append({"project": stem, "native_connections": len(rows),
            "cgroup_probes": resources["cgroup_probes"], "oom_kill": resources["oom_kill"],
            "native_stderr_bytes": stderr.stat().st_size,
            "native_stderr_sha256": hashlib.sha256(stderr.read_bytes()).hexdigest(),
            "paid_ready": False})
    previous.save(OUT/"single-worker-verification.json", {"controls": checks,"paid_ready":False})
    print(json.dumps(checks),flush=True)


if __name__=="__main__":
    main()
