"""Reopen the actual carried client ledger through the paid-boundary checker."""
import copy
import hashlib
import json
from pathlib import Path
import sys

WORK=Path("/home/marius/.codex/worktrees/cf66/codescout")
MAIN=Path("/home/marius/work/claude/codescout")
ROOT=Path("/var/tmp/ep11-01a15")
OUT=ROOT/"accounting-admission"
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from paid_admission import verify_accounting

def main():
    report=MAIN/"docs/trackers/effort-steering/evidence/campaign-accounting-20261111/reconciliation.json"
    reconciled=json.loads(report.read_bytes())
    registration={"ledger":copy.deepcopy(reconciled["ledger"]),"bindings":{}}
    registration["carried_holds"]=[{k:row[k] for k in ("id","source","receipt_sha256","reserved_usd")}
        for row in registration["ledger"]["holds"] if not row["settled"]]
    for row in registration["ledger"]["charges"]+registration["ledger"]["holds"]:
        registration["bindings"][row["source"]]=row["receipt_sha256"]
    proof={"path":str(report),"sha256":hashlib.sha256(report.read_bytes()).hexdigest()}
    registration["bindings"][str(report)]=proof["sha256"]
    checked=verify_accounting(registration,proof)
    OUT.mkdir()
    for name,value in [("registration-inputs.json",registration),("accounting-proof.json",proof),
                       ("readback.json",{"verified":checked,"provider_calls":0,"paid_ready":False})]:
        with (OUT/name).open("x") as stream:
            json.dump(value,stream,sort_keys=True,indent=2)
            stream.write("\n")
    print(json.dumps({"verified":checked,"provider_calls":0,"paid_ready":False}),flush=True)

if __name__=="__main__":
    main()
