"""Preserve the two model-free controls and verify every archived byte/link."""
import hashlib
import io
import json
from pathlib import Path
import stat
import tarfile

WORK = Path("/home/marius/.codex/worktrees/cf66/codescout")
CONTROL = Path("/tmp/effort-contract-resource-20261111-01a15ca9")
DEST = Path("/home/marius/work/claude/codescout/docs/trackers/effort-steering/evidence/contract-resources-20261111")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    DEST.mkdir(parents=True, exist_ok=False)
    files = {}
    for path in sorted(CONTROL.rglob("*")):
        files["control/" + path.relative_to(CONTROL).as_posix()] = path
    bindings = json.loads((CONTROL / "source-bindings.json").read_bytes())
    for index, (name, expected) in enumerate(sorted(bindings.items())):
        path = Path(name)
        assert sha(path.read_bytes()) == expected, name
        files["native-source/" + str(index).zfill(3) + "-" + path.name] = path
    for folder in ("effort_protocol", "agent_lifecycle"):
        for path in sorted((WORK / "tools" / folder).iterdir()):
            if path.suffix in (".py", ".json") and path.is_file():
                files["checkpoint-source/" + folder + "/" + path.name] = path
    for path in sorted((WORK / ".superpowers/sdd/2026-11-10-campaign-integration").iterdir()):
        if path.suffix in (".log", ".py", ".md", ".json") and path.is_file():
            files["integration-evidence/" + path.name] = path
    entries = {}
    for name, path in files.items():
        info = path.lstat()
        row = {"source": str(path), "mode": stat.S_IMODE(info.st_mode)}
        if stat.S_ISREG(info.st_mode):
            raw = path.read_bytes()
            row.update(kind="file", size=len(raw), sha256=sha(raw))
        elif stat.S_ISLNK(info.st_mode):
            row.update(kind="symlink", target=path.readlink().as_posix())
        elif stat.S_ISDIR(info.st_mode):
            row.update(kind="directory")
        else:
            raise ValueError("nonregular payload: " + str(path))
        entries[name] = row
    manifest = {"version": "contract-resources-closure-v1", "entries": entries,
        "scope": "Two intentionally incomplete P investigate controls, source snapshots and local unit evidence; no efficacy or full admission.",
        "external_runtime": "CLI, frozen native mounts, shared onboarding and embedding service are referenced by checked runtime bindings and prior shared-runtime custody; their transitive closure is not claimed here.",
        "paid_ready": False}
    raw_manifest = (json.dumps(manifest, sort_keys=True, indent=2) + "\n").encode()
    archive = DEST / "evidence.tar.gz"
    with tarfile.open(archive, "x:gz") as packed:
        for name, path in files.items():
            packed.add(path, arcname=name, recursive=False)
        item = tarfile.TarInfo("manifest.json")
        item.mode, item.size = 0o600, len(raw_manifest)
        packed.addfile(item, io.BytesIO(raw_manifest))
    with tarfile.open(archive, "r:gz") as packed:
        members = packed.getmembers()
        assert len(members) == len(entries) + 1
        assert len({item.name for item in members}) == len(members)
        for item in members:
            if item.name == "manifest.json":
                assert packed.extractfile(item).read() == raw_manifest
                continue
            row = entries[item.name]
            assert stat.S_IMODE(item.mode) == row["mode"]
            if row["kind"] == "file":
                assert item.isfile() and item.size == row["size"]
                assert sha(packed.extractfile(item).read()) == row["sha256"]
                assert sha(Path(row["source"]).read_bytes()) == row["sha256"]
            elif row["kind"] == "symlink":
                assert item.issym() and item.linkname == row["target"]
                assert Path(row["source"]).readlink().as_posix() == row["target"]
            else:
                assert item.isdir()
    receipt = {"archive": archive.name, "bytes": archive.stat().st_size,
        "sha256": sha(archive.read_bytes()), "payload_entries": len(entries),
        "regular_files": sum(row["kind"] == "file" for row in entries.values()),
        "symlinks": sum(row["kind"] == "symlink" for row in entries.values()),
        "all_payloads_reopened": True, "actual_native_source_bindings": len(bindings),
        "paid_ready": False, "scope": manifest["scope"]}
    with (DEST / "closure.json").open("x") as stream:
        json.dump(receipt, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps(receipt, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
