"""Preserve closed disk controls plus exact current source, then reopen every archive payload."""
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import subprocess
import tarfile

WORK=Path("/home/marius/.codex/worktrees/cf66/codescout")
MAIN=Path("/home/marius/work/claude/codescout")
ROOT=Path("/var/tmp/ep11-01a15")
PLAN=WORK/".superpowers/sdd/2026-11-10-campaign-integration"
DEST=MAIN/"docs/trackers/effort-steering/evidence/disk-runtime-checkpoint-20261111"

def sha_stream(stream):
    digest=hashlib.sha256()
    while chunk:=stream.read(1024*1024): digest.update(chunk)
    return digest.hexdigest()

def sha(path):
    with path.open("rb") as stream: return sha_stream(stream)

def main():
    for name in ("native-controls/result.json","private-controls/result.json","public-compilation/result.json",
                 "public-compilation/independent-readback.json"):
        assert (ROOT/name).is_file(),name
    DEST.mkdir(parents=True,exist_ok=False)
    paths={"disk/"+p.relative_to(ROOT).as_posix():p for p in ROOT.rglob("*")}
    for stem in ("obscura-421","lean-ctx-1168"):
        launch=json.loads((ROOT/"native-controls"/stem/"native/launch.json").read_bytes())
        temporary=Path(launch["client_temporary"])
        assert temporary.parent==Path("/var/tmp") and temporary.is_dir()
        paths["cli-temporary/"+stem]=temporary
        for p in temporary.rglob("*"):
            paths["cli-temporary/"+stem+"/"+p.relative_to(temporary).as_posix()]=p
    for folder in ("effort_protocol","agent_lifecycle","hint_authority_pilot"):
        for p in (WORK/"tools"/folder).glob("*"):
            if p.suffix in (".py",".json") and p.is_file():
                paths["source/tools/"+folder+"/"+p.name]=p
    for p in PLAN.iterdir():
        if p.suffix in (".py",".log",".json",".md") and p.is_file():
            paths["integration/"+p.name]=p
    entries={}
    for name,p in sorted(paths.items()):
        info=p.lstat()
        row={"source":str(p),"mode":stat.S_IMODE(info.st_mode)}
        if stat.S_ISREG(info.st_mode):
            row.update(kind="file",size=info.st_size,sha256=sha(p))
        elif stat.S_ISDIR(info.st_mode): row.update(kind="directory")
        elif stat.S_ISLNK(info.st_mode): row.update(kind="symlink",target=os.readlink(p))
        else: raise ValueError("special evidence node: "+str(p))
        entries[name]=row
    git={}
    for label,cmd in (("head",["rev-parse","HEAD"]),("status",["status","--porcelain=v1"]),
                      ("diff",["diff","--binary","HEAD","--","tools/effort_protocol","tools/agent_lifecycle"])):
        result=subprocess.run(["git",*cmd],cwd=WORK,capture_output=True)
        assert result.returncode==0
        git[label]=result.stdout.decode()
    manifest={"schema":"disk-runtime-checkpoint-v1","entries":entries,"git":git,
        "scope":"Two actual scripted native malformed-submission controls, two private baseline subprocesses, two public compile controls with complete build inputs, and exact current source. No full eight-attempt disk campaign or efficacy/purchase admission.",
        "limits":"Existing absolute paths, pinned images and transitive runtime/embedding service files remain external references; this is not a standalone system image. Earlier missing volatile run outputs were not recreated.",
        "provider_forwarded":0,"paid_ready":False}
    payload=(json.dumps(manifest,indent=2,sort_keys=True)+"\n").encode()
    archive=DEST/"evidence.tar.gz"
    with tarfile.open(archive,"x:gz",compresslevel=1) as packed:
        for name,p in sorted(paths.items()): packed.add(p,arcname=name,recursive=False)
        member=tarfile.TarInfo("manifest.json");member.mode=0o600;member.size=len(payload)
        packed.addfile(member,io.BytesIO(payload))
    with tarfile.open(archive) as packed:
        members=packed.getmembers()
        assert len(members)==len(entries)+1 and len({m.name for m in members})==len(members)
        for member in members:
            if member.name=="manifest.json":
                assert packed.extractfile(member).read()==payload
                continue
            row=entries[member.name];original=Path(row["source"])
            assert stat.S_IMODE(member.mode)==row["mode"]
            if row["kind"]=="file":
                assert member.isfile() and member.size==row["size"]
                assert sha_stream(packed.extractfile(member))==row["sha256"]
                assert sha(original)==row["sha256"]
            elif row["kind"]=="directory": assert member.isdir() and original.is_dir()
            else: assert member.issym() and member.linkname==row["target"]==os.readlink(original)
    closure={"archive":"evidence.tar.gz","bytes":archive.stat().st_size,"sha256":sha(archive),
        "payload_entries":len(entries),"regular_files":sum(x["kind"]=="file" for x in entries.values()),
        "all_payloads_reopened":True,"source_originals_rechecked":True,
        "provider_forwarded":0,"paid_ready":False,"scope":manifest["scope"]}
    with (DEST/"closure.json").open("x") as stream: json.dump(closure,stream,indent=2,sort_keys=True)
    print(json.dumps(closure),flush=True)

if __name__=="__main__":
    main()
