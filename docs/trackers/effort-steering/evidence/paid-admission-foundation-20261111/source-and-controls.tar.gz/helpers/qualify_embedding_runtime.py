"""Real owned-runtime smoke on both frozen images; no actor or provider."""
import hashlib
import json
from pathlib import Path
import sys

WORK = Path("/home/marius/.codex/worktrees/cf66/codescout")
sys.path.insert(0, str(WORK / "tools/effort_protocol"))
import executor
BEFORE_IMPORT = executor.LABEL
from embedding_runtime import embedding_runtime
from native_executor import external
from campaign_resources import measure_host
assert executor.LABEL == BEFORE_IMPORT

ROOT = Path("/home/marius/.cache/codescout-resident/codescout/evidence-cohort-20261110")
OUT = Path("/tmp/effort-embedding-runtime-20261111-01a15ca9")


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def main():
    OUT.mkdir()
    paths = [Path(__file__), *sorted((WORK / "tools/effort_protocol").glob("*.py")),
             *sorted((WORK / "tools/agent_lifecycle").glob("*.py"))]
    hashes = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}
    save(OUT / "source-bindings.json", hashes)
    host = measure_host(WORK, "/tmp")
    assert host["tmp_exec"] and host["root_free"] >= 80*1024**3 and host["tmp_free"] >= 4*1024**3 and host["mem_available"] >= 16*1024**3
    save(OUT / "host-before.json", host)
    rows = []
    for stem in ("obscura-421", "lean-ctx-1168"):
        image = json.loads((ROOT / ("common-" + stem + "-v3/preparation.json")).read_bytes())["image"]
        config = {"service_id": "88e74239478cbedcf13732d05417292c3eed43054a2b1b3ea88f8d122abb1ff8",
            "service_image": "sha256:be175932c3c96e882dfbc7e20e0e834f58c89c2925f48b222837ee929dfc47ee",
            "upstream_network": "codescout-retrieval_retrieval_net",
            "subnet": json.loads((ROOT / "public-runtime-subnets-v1.json").read_bytes())["subnets"][stem]}
        out = OUT / stem
        out.mkdir()
        save(out / "registration.json", {"image": image, "embedding": config, "executor_namespace": BEFORE_IMPORT})
        with embedding_runtime(out, image, config) as descriptor:
            options = {"--network": [descriptor["network_id"]],
                "--tmpfs": ["/tmp:rw,exec,size=16g,uid=1000,gid=1000"], "--read-only": [True],
                "--cap-drop": ["ALL"], "--security-opt": ["no-new-privileges"]}
            save(out / "profile-admission.json", external.validate_embedding_profile(descriptor, options, image))
            assert executor.LABEL == BEFORE_IMPORT
        assert executor.LABEL == BEFORE_IMPORT
        cleanup = json.loads((out / "cleanup.json").read_bytes())
        assert cleanup["complete"]
        rows.append({"project": stem, "profile_valid": True, "cleanup_complete": True,
                     "executor_namespace_unchanged": True, "actor_calls": 0, "model_calls": 0})
    for path, expected in hashes.items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == expected, path
    save(OUT / "result.json", {"controls": rows, "paid_ready": False})
    print(json.dumps(rows), flush=True)


if __name__ == "__main__":
    main()
