"""Calibrate literal chunk/source coherence on a known-fresh native code store."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import sqlite3
import tempfile

WORK = Path("/home/marius/.codex/worktrees/cf66/codescout")
OUT = WORK/".superpowers/sdd/2026-11-10-campaign-integration/public-chunk-coherence.json"
ROOT = Path("/home/marius/.cache/codescout-resident/codescout/evidence-cohort-20261110")
PROJECTS = {
    "fresh-code-control": Path("/tmp/effort-public-clone-native-20261111-01a15ca9/obscura-421/changed/actor"),
    "frozen-obscura": ROOT/"common-obscura-421-v3/project",
    "frozen-lean": ROOT/"common-lean-ctx-1168-v3/project",
    "changed-lean-control": Path("/tmp/effort-public-clone-native-v2-20261111-01a15ca9/lean-ctx-1168/changed/actor")}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit(root):
    database = root/".codescout/embeddings/testbed.db"
    sources = [Path(str(database)+suffix) for suffix in ("","-wal","-shm") if Path(str(database)+suffix).is_file()]
    before = {str(path): sha(path) for path in sources}
    with tempfile.TemporaryDirectory(prefix="readonly-index-copy-") as temporary:
        destination = Path(temporary)/"testbed.db"
        for path in sources:
            shutil.copy2(path, Path(temporary)/path.name)
        with sqlite3.connect("file:"+str(destination)+"?mode=ro",uri=True) as connection:
            rows = connection.execute("SELECT chunk_id,file_path,content FROM code_chunk ORDER BY file_path,chunk_id").fetchall()
    assert {str(path): sha(path) for path in sources} == before, "live database changed while copying"
    texts, failures, coherent = {}, [], 0
    for identity, relative, content in rows:
        try:
            path = PurePosixPath(relative)
            assert path.parts and not path.is_absolute() and ".." not in path.parts and path.as_posix()==relative
            target = root/relative
            assert target.resolve().is_relative_to(root.resolve()) and target.is_file()
            if relative not in texts:
                texts[relative] = target.read_bytes().decode("utf-8",errors="replace")
            assert isinstance(content,str) and bool(content)
            if content in texts[relative]:
                coherent += 1
            else:
                failures.append({"chunk_id":identity,"path":relative,"reason":"stored content is not a literal source substring",
                    "chunk_sha256":hashlib.sha256(content.encode()).hexdigest(),"chunk_chars":len(content)})
        except (AssertionError,OSError,TypeError,ValueError) as exc:
            failures.append({"chunk_id":identity,"path":relative,"reason":"invalid source/chunk input: "+type(exc).__name__})
    return {"source":str(root),"database_files":before,
        "predicate":"Every nonempty stored content string is a literal substring of its in-root current file decoded UTF-8 with replacement.",
        "stored_code_chunk_rows":len(rows),"literal_matching_rows":coherent,
        "failing_rows":len(failures),"queried_file_paths":len({row[1] for row in rows}),
        "failures":failures}


def main():
    result = {name:audit(path) for name,path in PROJECTS.items()}
    with OUT.open("x") as stream:
        json.dump({"scope":"Code text coherence only, not vector correctness or complete source coverage.",
            "projects":result,"paid_ready":False},stream,indent=2,sort_keys=True)
        stream.write("\n")
    print(json.dumps({name:{key:value[key] for key in
        ("stored_code_chunk_rows","literal_matching_rows","failing_rows","queried_file_paths")}
        for name,value in result.items()},indent=2))


if __name__=="__main__":
    main()
