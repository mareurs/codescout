"""Real public manifest compile checks with complete build evidence on persistent disk."""
from pathlib import Path
import qualify_public_compilation as control

ROOT = Path("/var/tmp/ep11-01a15")

def main():
    control.PRIOR = ROOT/"native-controls"
    control.OUT = ROOT/"public-compilation"
    control.main()

if __name__ == "__main__":
    main()
