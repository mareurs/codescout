"""Exercise the paid admission command checker on both real, closed build receipts."""
import copy
import hashlib
import json
from pathlib import Path
import sys

WORK=Path("/home/marius/.codex/worktrees/cf66/codescout")
ROOT=Path("/var/tmp/ep11-01a15")
OUT=ROOT/"public-command-admission"
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from paid_admission import verify_public_commands
from receipts import input_digest

def main():
    registration={"tasks":{},"bindings":{}}
    evidence={}
    def bound(path):
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        registration["bindings"][str(path)]=digest
        return {"path":str(path),"sha256":digest}
    for role,stem,relative in (("obscura","obscura-421","private-plan/full-native-v5/full-record.json"),
                               ("lean","lean-ctx-1168","native-controls/full-record.json")):
        record=json.loads((ROOT/"private-package"/role/relative).read_bytes())
        identity=record["instance_id"]
        prior=json.loads((ROOT/"native-controls"/stem/"registration.json").read_bytes())
        directory=ROOT/"public-compilation"/stem
        command=json.loads((directory/"registration.json").read_bytes())["request"]
        public=copy.deepcopy(prior["public"])
        public["public_checks"]=[{key:command[key] for key in ("argv","cwd","test_files")}]
        source=Path(prior["request"]["source"])
        registration["tasks"][identity]={"source":str(source),"source_sha256":input_digest(source),
            "backend":{"public":public}}
        evidence[identity]=[{"registration":bound(directory/"registration.json"),
                             "result":bound(directory/"result.json")}]
    checked=verify_public_commands(registration,evidence)
    OUT.mkdir()
    for name,value in [("registration-inputs.json",registration),("public-command-proof.json",evidence),
                       ("readback.json",{"verified":checked,"provider_calls":0,"paid_ready":False})]:
        with (OUT/name).open("x") as stream:
            json.dump(value,stream,sort_keys=True,indent=2)
            stream.write("\n")
    print(json.dumps({"verified":checked,"provider_calls":0,"paid_ready":False}),flush=True)

if __name__=="__main__":
    main()
