"""Actual read-only public Cargo verification, independent of hidden acceptance."""
import hashlib
import json
from pathlib import Path
import sys

WORK=Path("/home/marius/.codex/worktrees/cf66/codescout")
PRIOR=Path("/tmp/effort-native-composition-v2-20261111-01a15ca9")
OUT=Path("/tmp/effort-public-compilation-v1-20261111-01a15ca9")
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from executor import execute_observation
from receipts import input_digest

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):
    with Path(path).open("x") as stream: json.dump(value,stream,indent=2,sort_keys=True)
def main():
    OUT.mkdir();rows=[]
    bindings={str(path):sha(path) for path in sorted((WORK/"tools/effort_protocol").glob("*.py"))}
    save(OUT/"source-bindings.json",bindings)
    for stem,cwd,manifest in (("obscura-421",".","Cargo.toml"),("lean-ctx-1168","rust","rust/Cargo.toml")):
        old=json.loads((PRIOR/stem/"registration.json").read_bytes())
        public=old["public"];source=Path(old["request"]["source"])
        request={"id":"public-cargo-check","run_id":"public-compilation-"+stem,"phase":"challenge",
            "kind":"verification","image":public["image"],"argv":["cargo","check","--offline","--workspace"],
            "cwd":cwd,"test_files":[manifest],
            "production_files":sorted(path.relative_to(source).as_posix() for path in source.rglob("*")),
            "timeout_s":900,"max_log_bytes":67108864,"execution_profile":public["execution_profile"],
            **({"public_fixture":public["public_fixture"]} if "public_fixture" in public else {})}
        directory=OUT/stem;directory.mkdir()
        save(directory/"registration.json",{"request":request,"source":str(source),
            "source_digest":input_digest(source),"source_bindings":bindings,"paid_ready":False,
            "scope":"Public manifest-driven compile check, no private tests, not semantic acceptance."})
        print(json.dumps({"project":stem,"starting":True}),flush=True)
        try:
            facts=execute_observation(request,source,directory/"commands")
            row={"project":stem,"complete":facts["complete"],"resource_valid":facts["resource_valid"],
                "exit_code":facts["exit_code"],"receipt":facts,"paid_ready":False}
        except BaseException as exc:
            row={"project":stem,"complete":False,"reason":type(exc).__name__+": "+str(exc),"paid_ready":False}
        save(directory/"result.json",row);rows.append(row)
        print(json.dumps({k:v for k,v in row.items() if k!="receipt"}),flush=True)
        if not (row.get("complete") is True and row.get("resource_valid") is True and row.get("exit_code")==0):
            save(OUT/"stopped.json",{"rows":rows,"paid_ready":False})
            raise RuntimeError("public compile qualification failed")
    # Other admission-only modules may be added while this command-only control runs;
    # preserve the source version it actually used rather than claiming later bytes.
    save(OUT/"result.json",{"rows":rows,"provider_calls":0,"paid_ready":False})
if __name__=="__main__": main()
