"""Preserve the current runtime WIP before controller integration."""
from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile
root=Path.cwd()
out=root/".superpowers/sdd/2026-11-10-campaign-integration"
paths=sorted(p for directory in ("tools/effort_protocol","tools/agent_lifecycle")
             for p in (root/directory).rglob("*") if p.is_file()
             and "__pycache__" not in p.parts and p.suffix!=".pyc")
files={str(p.relative_to(root)):{"sha256":hashlib.sha256(p.read_bytes()).hexdigest(),
                               "mode":p.stat().st_mode & 0o7777} for p in paths}
head=subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()
manifest={"head":head,"files":files,"scope":"prior full effort_protocol/lifecycle before integration"}
archive=out/"baseline.tar.gz"
with tarfile.open(archive,"x:gz") as package:
    for p in paths:
        package.inodes.clear()
        package.add(p,arcname=str(p.relative_to(root)),recursive=False)
    raw=json.dumps(manifest,indent=2,sort_keys=True).encode()
    info=tarfile.TarInfo("manifest.json");info.size=len(raw)
    package.addfile(info,io.BytesIO(raw))
with tarfile.open(archive,"r:gz") as package:
    assert json.load(package.extractfile("manifest.json"))==manifest
    assert all(hashlib.sha256(package.extractfile(name).read()).hexdigest()==data["sha256"]
               for name,data in files.items())
receipt={"sha256":hashlib.sha256(archive.read_bytes()).hexdigest(),"source_files":len(files),
         "all_payloads_reopened":True,"head":head,"paid_ready":False}
(out/"baseline-receipt.json").write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt,indent=2))
