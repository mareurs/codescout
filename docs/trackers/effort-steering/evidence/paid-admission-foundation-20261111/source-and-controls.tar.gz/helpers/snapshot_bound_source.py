"""Content-addressed custody of exact campaign-bound files; no mutable run outputs."""
import hashlib
import io
import json
from pathlib import Path
import platform
import stat
import subprocess
import tarfile

WORK=Path("/home/marius/.codex/worktrees/cf66/codescout")
MAIN=Path("/home/marius/work/claude/codescout")
REG=Path("/tmp/effort-native-campaign-qualification-v1-20261111-01a15ca9-registration/registration.json")
OUT=MAIN/"docs/trackers/effort-steering/evidence/campaign-bound-source-20261111"
def sha(data): return hashlib.sha256(data).hexdigest()
def main():
    OUT.mkdir()
    reg=json.loads(REG.read_bytes())
    objects,files,references={},{},{}
    inputs={**reg["bindings"],str(REG):sha(REG.read_bytes())}
    for name,expected in inputs.items():
        path=Path(name)
        assert path.is_file() and not path.is_symlink(),name
        data=path.read_bytes();assert sha(data)==expected,name
        item={"sha256":expected,"bytes":len(data),"mode":stat.S_IMODE(path.stat().st_mode)}
        if path.name.endswith((".tar.gz",".tgz")):
            references[name]=item
        else:
            objects.setdefault(expected,data);files[name]=item
    for role,argv in {
        "git-status": ["git","status","--porcelain=v1"],
        "git-head": ["git","rev-parse","HEAD"],
        "git-diff": ["git","diff","--binary","HEAD","--","tools/effort_protocol","tools/agent_lifecycle"],
    }.items():
        data=subprocess.check_output(argv,cwd=WORK)
        digest=sha(data);objects.setdefault(digest,data)
        files["checkpoint/"+role]={"sha256":digest,"bytes":len(data),"mode":0o600}
    manifest={"schema":"campaign-bound-source-v1","registration_sha256":sha(REG.read_bytes()),
        "files":files,"referenced_archives":references,
        "python":platform.python_version(),"platform":platform.platform(),
        "scope":"Exact campaign file bindings, Git WIP checkpoint and shared reviewed package. Mutable run outputs are NOT included. CLI/plugin/images/LSP/model mounts and semantic stores remain externally qualified references.",
        "paid_ready":False}
    data=json.dumps(manifest,indent=2,sort_keys=True).encode()
    archive=OUT/"source.tar.gz"
    with tarfile.open(archive,"x:gz") as tar:
        for name,body in [("manifest.json",data),*[("objects/"+digest,body) for digest,body in sorted(objects.items())]]:
            item=tarfile.TarInfo(name);item.size=len(body);item.mode=0o600;tar.addfile(item,io.BytesIO(body))
    with tarfile.open(archive) as tar:
        assert tar.extractfile("manifest.json").read()==data
        for digest,body in objects.items():
            assert tar.extractfile("objects/"+digest).read()==body
    for name,expected in inputs.items(): assert sha(Path(name).read_bytes())==expected,name
    result={"archive":str(archive),"bytes":archive.stat().st_size,"sha256":sha(archive.read_bytes()),
        "file_bindings":len(files),"unique_objects":len(objects),"referenced_archives":len(references),
        "every_object_reopened":True,"originals_rechecked":True,"paid_ready":False}
    with (OUT/"closure.json").open("x") as stream: json.dump(result,stream,indent=2,sort_keys=True)
    print(json.dumps(result))
if __name__=="__main__": main()
