"""Capture Task1 source and observed results before native integration changes."""
from pathlib import Path
import hashlib
import io
import json
import tarfile
root=Path.cwd()
out=root/".superpowers/sdd/2026-11-10-campaign-integration"
files={str(p.relative_to(root)):p for directory in ("tools/effort_protocol","tools/agent_lifecycle")
       for p in (root/directory).rglob("*") if p.is_file() and "__pycache__" not in p.parts
       and p.suffix!=".pyc"}
for name in ("runner-red.log","runner-green-1.log","runner-boundaries-red.log",
             "runner-boundaries-green.log","runner-boundaries-green-v2.log","native-limits-red.log",
             "native-limits-green.log","task1-protocol.log","task1-lifecycle.log","task1-gate.log"):
    files["evidence/"+name]=out/name
manifest={name:{"sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"bytes":p.stat().st_size}
          for name,p in sorted(files.items())}
archive=out/"task1-source-evidence.tar.gz"
with tarfile.open(archive,"x:gz") as package:
    for name,p in sorted(files.items()):
        content=p.read_bytes()
        assert hashlib.sha256(content).hexdigest()==manifest[name]["sha256"]
        info=tarfile.TarInfo(name);info.size=len(content)
        package.addfile(info,io.BytesIO(content))
    content=json.dumps(manifest,indent=2,sort_keys=True).encode()
    info=tarfile.TarInfo("manifest.json");info.size=len(content)
    package.addfile(info,io.BytesIO(content))
with tarfile.open(archive,"r:gz") as package:
    assert json.load(package.extractfile("manifest.json"))==manifest
    assert all(hashlib.sha256(package.extractfile(name).read()).hexdigest()==row["sha256"]
               for name,row in manifest.items())
receipt={"sha256":hashlib.sha256(archive.read_bytes()).hexdigest(),
         "source_files":sum(not name.startswith("evidence/") for name in files),
         "evidence_files":sum(name.startswith("evidence/") for name in files),
         "all_payloads_reopened":True,"default_gate_green":False,"paid_ready":False}
(out/"task1-snapshot.json").write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt,indent=2))
