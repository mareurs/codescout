"""Single-variable check: preserve shared memory store during changed-code indexing."""
import json
from pathlib import Path
import sqlite3
import sys
import time
import qualify_public_clone_native as p

OUT = Path("/tmp/effort-shared-store-v2-20261111-01a15ca9")


def main():
    OUT.mkdir(exist_ok=False)
    files = [Path(__file__), Path(p.__file__), p.HELPER] + sorted((p.WORK / "tools/effort_protocol").glob("*.py")) + [
        p.WORK / "tools/effort_protocol/prompts.json"] + sorted((p.WORK / "tools/agent_lifecycle").glob("*.py"))
    p.save(OUT / "source-bindings.json", {str(path): p.sha(path) for path in files})
    stem = "obscura-421"
    parent = p.ROOT / ("common-" + stem + "-v3")
    template = parent / "project"
    image = json.loads((parent / "preparation.json").read_bytes())["image"]
    expected = json.loads((parent / "native-canaries-v11/readiness-raw.json").read_bytes())["expected"]
    fixture = json.loads((parent / "public-fixture.json").read_bytes())
    static = ["project.toml", "system-prompt.md"] + [
        str(path.relative_to(template / ".codescout"))
        for path in sorted((template / ".codescout/memories").glob("*.md"))]
    config = {"template": str(template), "template_sha256": p.input_digest(template),
        "knowledge_paths": static, "knowledge_sha256": p.input_digest(template / ".codescout", static)}
    source = OUT / "source"
    p.shutil.copytree(p.PRIOR / stem / "public-source", source)
    (source / "probes").mkdir(exist_ok=True)
    marker = "print('source-only public observation')\n"
    (source / "probes/public_observation.py").write_text(marker)
    actor = OUT / "actor"
    prepared = p.prepare_public_clone(source, actor, config)
    assert prepared["index_update_required"] and not prepared["derived_index_reset"]
    assert p.input_digest(actor / ".codescout/embeddings") == p.input_digest(template / ".codescout/embeddings")
    p.save(OUT / "preparation.json", prepared)
    subnet = json.loads((p.ROOT / "public-runtime-subnets-v1.json").read_bytes())["subnets"][stem]
    with p.runtime.relay_runtime(OUT, image, subnet) as embedding:
        home = OUT / "native-home"
        home.mkdir()
        argv = p._native_argv(actor, home, {"runtime_manifest": str(parent / "native-runtime.json"),
                                         "native_image": image})
        argv[argv.index("--network") + 1] = embedding["network_id"]
        argv[argv.index("--tmpfs") + 1] = "/tmp:rw,exec,size=16g,uid=1000,gid=1000"
        argv.insert(argv.index("--init"), "--read-only")
        argv[-4:-4] = ["--cap-drop", "ALL", "--security-opt", "no-new-privileges", "-e", "CARGO_TARGET_DIR=/tmp/target"]
        position = argv.index("--entrypoint")
        del argv[position:position + 2]
        argv[-4:-4] = p.public_fixture.fixture_docker_options(fixture, "native")
        options = {key: [argv[i+1] for i, value in enumerate(argv[:-4]) if value == key]
                   for key in ("--network", "--tmpfs", "--cap-drop", "--security-opt")}
        options["--read-only"] = [True]
        p.save(OUT / "embedding-admission.json", p.validate_embedding_profile(embedding, options, image))
        ready = OUT / "readiness"
        ready.mkdir()
        cfg = {"native_image": image, "registered_readiness": {
            key: expected[key] for key in ("project_root", "languages", "tools", "probes")},
            **{key: prepared[key] for key in ("knowledge_paths", "knowledge_sha256", "baseline_commit", "index_update_required")},
            "public_fixture": fixture}
        p.save(OUT / "readiness-registration.json", cfg)
        proof = p._readiness(ready, argv, actor, source, cfg)
        database = actor / ".codescout/embeddings/testbed.db"
        with sqlite3.connect("file:" + str(database) + "?mode=ro", uri=True) as connection:
            rows = connection.execute("SELECT content FROM code_chunk WHERE file_path=?",
                                      ("probes/public_observation.py",)).fetchall()
        assert rows and any(marker.strip() in row[0] for row in rows)
        assert p.input_digest(template) == config["template_sha256"]
        p.save(OUT / "result.json", {"ready": True, "new_probe_stored_chunk_rows": len(rows),
            "new_public_fragment_in_store": True, "raw_onboarding_unchanged": True,
            "onboarding_author_calls": 0, "model_calls": 0, "model_cost_usd": "0",
            "embedding_compute_cost_usd": None, "paid_ready": False})
    for path, expected_hash in json.loads((OUT / "source-bindings.json").read_bytes()).items():
        assert p.sha(path) == expected_hash, path
    print((OUT / "result.json").read_text(), flush=True)


if __name__ == "__main__":
    main()
