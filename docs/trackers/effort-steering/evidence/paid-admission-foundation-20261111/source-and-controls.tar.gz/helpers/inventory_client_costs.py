"""Inventory settled non-scripted native CLI receipt UUIDs; not an all-harness bill."""
from decimal import Decimal, localcontext
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT=Path("/home/marius/.cache/codescout-resident/codescout")
OUT=Path("/home/marius/.codex/worktrees/cf66/codescout/.superpowers/sdd/2026-11-10-campaign-integration/native-client-cost-inventory.json")
UUID=re.compile("[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}")
def main():
    listed=subprocess.run(["rg","--files","-uu",str(ROOT),"-g","receipt.json"],
        check=True,capture_output=True,text=True)
    paths=sorted(listed.stdout.splitlines())
    entries,failures,selected,unknown=[],[],{},{}
    for name in paths:
        path=Path(name)
        try:
            data=path.read_bytes();row=json.loads(data)
        except (OSError,ValueError) as exc:
            failures.append({"path":name,"error":type(exc).__name__+": "+str(exc)})
            continue
        if not isinstance(row,dict): continue
        identity=row.get("session_id")
        if row.get("scripted") is not False or not isinstance(identity,str) or not UUID.fullmatch(identity):
            continue
        item={"path":name,"sha256":hashlib.sha256(data).hexdigest(),"session_id":identity,
            "cost_usd":row.get("cost_usd"),"unknown_provider_cost":row.get("unknown_provider_cost"),
            "forwarded":row.get("forwarded")}
        entries.append(item)
        if row.get("unknown_provider_cost") is not False or row.get("cost_usd") is None:
            unknown.setdefault(identity,[]).append(item)
            continue
        value=Decimal(str(row["cost_usd"]))
        if not value.is_finite() or value<0:
            failures.append({"path":name,"error":"invalid settled amount"})
            continue
        previous=selected.get(identity)
        if previous is None or value>Decimal(previous["cost_usd"]):
            selected[identity]={**item,"cost_usd":str(value)}
    with localcontext() as context:
        context.prec=128
        total=sum((Decimal(row["cost_usd"]) for row in selected.values()),Decimal(0))
    result={"predicate":"Physical receipt.json under this resident root, object, scripted exactly false, UUID-shaped session_id; largest settled receipt amount per UUID. This is an inventory proxy awaiting lineage/coverage calibration.",
        "physical_filenames":len(paths),"selected_receipt_files":len(entries),"selected_settled_session_ids":len(selected),
        "selected_sum_usd":str(total),"unsettled_session_ids":unknown,
        "selected":selected,"all_matching_receipts":entries,"read_failures":failures,
        "complete_series_reconciliation":False,"not_covered":["non-native/older harnesses","orchestrator/reviewer cost","provider invoice","any missing or moved raw receipt"],
        "paid_ready":False}
    with OUT.open("x") as stream: json.dump(result,stream,indent=2,sort_keys=True)
    print(json.dumps({k:v for k,v in result.items() if k not in ("selected","all_matching_receipts","unsettled_session_ids","read_failures")}))
    print(json.dumps({"unsettled_uuid_count":len(unknown),"read_failures":len(failures)}))
if __name__=="__main__": main()
