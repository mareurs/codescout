"""Check unchanged and changed public clones with the real frozen native tools."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import time

WORK = Path("/home/marius/.codex/worktrees/cf66/codescout")
sys.path[:0] = [str(WORK / "tools/effort_protocol"), str(WORK / "tools/agent_lifecycle")]
import native_executor
import public_fixture
from public_clone import prepare_public_clone
from qualify_native import _native_argv, _readiness
from receipts import input_digest
from campaign_resources import measure_host
from embedding_profile import validate_embedding_profile

HELPER = Path("/tmp/shared-public-runtime-correction-20261110/qualify_all_arms_v3.py")
spec = importlib.util.spec_from_file_location("frozen_embedding_runtime", HELPER)
runtime = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runtime)
ROOT = runtime.ROOT
OUT = Path("/tmp/effort-public-clone-native-20261111-01a15ca9")
PRIOR = Path("/tmp/effort-contract-resource-20261111-01a15ca9")


def save(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    OUT.mkdir(exist_ok=False)
    files = [HELPER, Path(__file__)] + sorted((WORK / "tools/effort_protocol").glob("*.py")) + [
        WORK / "tools/effort_protocol/prompts.json"] + sorted((WORK / "tools/agent_lifecycle").glob("*.py"))
    save(OUT / "source-bindings.json", {str(p): sha(p) for p in files})
    results = []
    for stem in ("obscura-421", "lean-ctx-1168"):
        parent = ROOT / ("common-" + stem + "-v3")
        template = parent / "project"
        prior = json.loads((parent / "preparation.json").read_bytes())
        expected = json.loads((parent / "native-canaries-v11/readiness-raw.json").read_bytes())["expected"]
        fixture_path = parent / "public-fixture.json"
        fixture = json.loads(fixture_path.read_bytes()) if fixture_path.exists() else None
        static = ["project.toml", "system-prompt.md"] + [
            str(p.relative_to(template / ".codescout")) for p in sorted((template / ".codescout/memories").glob("*.md"))]
        config = {"template": str(template), "template_sha256": input_digest(template),
                  "knowledge_paths": static, "knowledge_sha256": input_digest(template / ".codescout", static)}
        out = OUT / stem
        out.mkdir()
        subnet = json.loads((ROOT / "public-runtime-subnets-v1.json").read_bytes())["subnets"][stem]
        save(out / "template-registration.json", config)
        with runtime.relay_runtime(out, prior["image"], subnet) as embedding:
            for variant in ("unchanged", "changed"):
                host = measure_host(WORK, "/tmp")
                assert host["tmp_exec"] and host["root_free"] >= 80 * 1024**3 and host["tmp_free"] >= 4 * 1024**3 and host["mem_available"] >= 16 * 1024**3, host
                stage = out / variant
                stage.mkdir()
                save(stage / "host-before.json", host)
                source = stage / "source"
                shutil.copytree(PRIOR / stem / "public-source", source)
                if variant == "changed":
                    (source / "probes").mkdir(exist_ok=True)
                    (source / "probes/public_observation.py").write_text("print('source-only public observation')\n")
                actor = stage / "actor"
                prepared = prepare_public_clone(source, actor, config)
                save(stage / "public-preparation.json", prepared)
                if variant == "unchanged":
                    assert not prepared["index_update_required"], prepared
                else:
                    assert prepared["index_update_required"] and not (actor / ".codescout/embeddings").exists(), prepared
                assert prepared["onboarding_author_calls"] == 0
                home = stage / "native-home"
                home.mkdir()
                argv = _native_argv(actor, home, {"runtime_manifest": str(parent / "native-runtime.json"),
                                                 "native_image": prior["image"]})
                argv[argv.index("--network") + 1] = embedding["network_id"]
                argv[argv.index("--tmpfs") + 1] = "/tmp:rw,exec,size=16g,uid=1000,gid=1000"
                argv.insert(argv.index("--init"), "--read-only")
                argv[-4:-4] = ["--cap-drop", "ALL", "--security-opt", "no-new-privileges", "-e", "CARGO_TARGET_DIR=/tmp/target"]
                if fixture:
                    position = argv.index("--entrypoint")
                    del argv[position:position + 2]
                    argv[-4:-4] = public_fixture.fixture_docker_options(fixture, "native")
                options = {key: [argv[i+1] for i, value in enumerate(argv[:-4]) if value == key]
                           for key in ("--network", "--tmpfs", "--cap-drop", "--security-opt")}
                options["--read-only"] = [True]
                save(stage / "embedding-admission.json", validate_embedding_profile(embedding, options, prior["image"]))
                ready = stage / "readiness"
                ready.mkdir()
                cfg = {"native_image": prior["image"], "registered_readiness": {
                    key: copy.deepcopy(expected[key]) for key in ("project_root", "languages", "tools", "probes")},
                    **{key: prepared[key] for key in ("knowledge_paths", "knowledge_sha256", "baseline_commit", "index_update_required")},
                    **({"public_fixture": fixture} if fixture else {})}
                print(json.dumps({"stem": stem, "variant": variant, "starting": True,
                                  "index_update": prepared["index_update_required"]}), flush=True)
                began = time.monotonic()
                try:
                    proof = _readiness(ready, argv, actor, source, cfg)
                    assert proof["expected"]["binding"]["source_snapshot_sha256"] == input_digest(source)
                    assert input_digest(template) == config["template_sha256"]
                    row = {"stem": stem, "variant": variant, "ready": True,
                        "index_update_required": prepared["index_update_required"],
                        "onboarding_author_calls": 0, "model_calls": 0, "model_cost_usd": "0",
                        "embedding_compute_cost_usd": None, "wall_s": time.monotonic()-began,
                        "paid_ready": False}
                except Exception as exc:
                    row = {"stem": stem, "variant": variant, "ready": False,
                        "error": type(exc).__name__ + ": " + str(exc), "wall_s": time.monotonic()-began,
                        "onboarding_author_calls": 0, "model_calls": 0, "paid_ready": False}
                save(stage / "result.json", row)
                results.append(row)
                print(json.dumps(row), flush=True)
                if not row["ready"]:
                    break
    for path, expected_hash in json.loads((OUT / "source-bindings.json").read_bytes()).items():
        assert sha(path) == expected_hash, path
    save(OUT / "result.json", {"controls": results,
        "all_ready": len(results) == 4 and all(row["ready"] for row in results), "paid_ready": False})


if __name__ == "__main__":
    main()
