"""Host-only evidence checks for the paid boundary; never imported by actor prompts."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile
from decimal import Decimal, localcontext

from campaign import _money, accounting_totals, admit_history, selection_report
from receipts import input_digest, verify_receipt


def _require(condition, reason):
    if not condition:
        raise ValueError(reason)


def _bound_path(registration, descriptor):
    _require(isinstance(descriptor,dict) and isinstance(descriptor.get("path"),str)
             and isinstance(descriptor.get("sha256"),str), "evidence descriptor missing")
    path=Path(descriptor["path"])
    _require(path.is_absolute() and path.resolve(strict=True)==path and path.is_file(),
             "evidence must be a physical regular file")
    expected=descriptor["sha256"]
    _require(len(expected)==64 and registration["bindings"].get(str(path))==expected,
             "evidence is not frozen in campaign bindings")
    with path.open("rb") as stream:
        actual=hashlib.file_digest(stream,"sha256").hexdigest()
    _require(actual==expected,"evidence bytes changed")
    return path


def _bound_json(registration, descriptor):
    path=_bound_path(registration,descriptor)
    _require(path.stat().st_size<=16*1024*1024,"evidence JSON exceeds registered limit")
    return json.loads(path.read_bytes())


def verify_population(registration, descriptor):
    """Reproduce the original public-only selector, including its whole universe."""
    archive=_bound_path(registration,descriptor)
    members=descriptor.get("members")
    roles={"metadata","exposure","status","rule","freeze","selection"}
    _require(isinstance(members,dict) and set(members)==roles and
             all(isinstance(name,str) and name for name in members.values()) and
             len(set(members.values()))==len(roles),"population member roles missing or duplicated")
    for name in members.values():
        rel=PurePosixPath(name)
        _require(not rel.is_absolute() and ".." not in rel.parts,"unsafe population member name")
    records={}
    with tarfile.open(archive) as packed:
        inventory=packed.getmembers()
        _require(len({item.name for item in inventory})==len(inventory),
                 "duplicate frozen population member")
        for role,name in members.items():
            member=packed.getmember(name)
            _require(member.isfile() and member.size<=16*1024*1024,
                     "population member is not a bounded regular JSON")
            records[role]=json.loads(packed.extractfile(member).read())
    original=records["metadata"]["tasks"]
    status=records["status"]
    exposure=set(records["exposure"]["tasks"])
    rule=records["rule"]
    freeze=records["freeze"]
    frozen=records["selection"]
    _require(isinstance(original,list) and isinstance(status,dict)
             and set(status)=={row["id"] for row in original},"public qualification population changed")
    effective=[{**row,"eligible":status[row["id"]]["eligible"],
                "reason":status[row["id"]]["reason"]} for row in original]
    derived=selection_report(effective,exposure,rule["seed"])
    _require(derived==frozen and freeze["selection"]==frozen
             and freeze["selection_rule"]==rule and frozen["complete"] is True
             and freeze["selected_ids"]==[row["id"] for row in frozen["selected"]],
             "frozen population selection or qualification changed")
    _require(freeze.get("private_outcomes_read") is False
             and freeze.get("replacement_after_private_outcomes") is False
             and type(freeze.get("experimental_model_calls")) is int
             and freeze["experimental_model_calls"]==0,
             "population is not frozen before model/private outcomes")
    _require(registration["metadata"]==effective
             and isinstance(registration["exposure"],list)
             and len(registration["exposure"])==len(exposure)
             and set(registration["exposure"])==exposure
             and registration["seed"]==rule["seed"]
             and registration["selected"]==frozen["selected"],
             "paid campaign differs from original public population, exposure, seed or selected order")
    return {"metadata_tasks":len(original),"exposure_ids":len(exposure),
            "excluded_universe_tasks":len({row["id"] for row in original} & exposure),
            "selected_ids":[row["id"] for row in frozen["selected"]],"archive_sha256":descriptor["sha256"]}
def verify_public_commands(registration, evidence):
    """Reopen registered command evidence, including generated build bytes and raw streams."""
    _require(isinstance(evidence,dict) and set(evidence)==set(registration["tasks"]),
             "public command evidence does not cover the exact task population")
    proofs={}
    for identity,task in registration["tasks"].items():
        public=task["backend"]["public"]
        commands=public["public_checks"]
        rows=evidence[identity]
        _require(isinstance(commands,list) and commands and isinstance(rows,list)
                 and len(rows)==len(commands),"public command inventory missing or changed")
        source=Path(task["source"])
        _require(input_digest(source)==task["source_sha256"],"public compile source changed")
        seen=set()
        for index,(command,row) in enumerate(zip(commands,rows)):
            _require(isinstance(row,dict) and set(row)=={"registration","result"},
                     "public command evidence schema invalid")
            registered=_bound_json(registration,row["registration"])
            result=_bound_json(registration,row["result"])
            directory=Path(row["registration"]["path"]).parent
            _require(directory==Path(row["result"]["path"]).parent
                     and str(directory) not in seen,"public command receipts overlap or repeat")
            seen.add(str(directory))
            expected={key:command[key] for key in ("argv","cwd","test_files")}
            request=registered["request"]
            _require({key:request[key] for key in expected}==expected
                     and Path(registered["source"])==source
                     and registered["source_digest"]==task["source_sha256"],
                     "public command or input differs from the registered paid check")
            _require(result.get("complete") is True and result.get("resource_valid") is True
                     and type(result.get("exit_code")) is int and result["exit_code"]==0,
                     "public command did not complete successfully")
            checked=verify_receipt({"id":request["id"]},directory/"commands",source,
                expected_profile=public["execution_profile"],expected_fixture=public.get("public_fixture"))
            _require(checked==result["receipt"] and checked.get("complete") is True
                     and checked.get("resource_valid") is True
                     and type(checked.get("exit_code")) is int and checked["exit_code"]==0,
                     "independent public command readback differs from the frozen result")
        proofs[identity]={"verified_commands":len(rows),"source_sha256":task["source_sha256"]}
    return proofs
def verify_accounting(registration, descriptor):
    """Reopen the historical client evidence; retain the entire registered unknown hold."""
    reconciled=_bound_json(registration,descriptor)
    _require(reconciled.get("schema")=="client-ledger-reconciliation-v1"
             and registration["ledger"]==reconciled["ledger"],
             "paid ledger differs from the frozen historical reconciliation")
    ledger=registration["ledger"]
    totals=accounting_totals(ledger)
    admit_history(ledger,carried_holds=registration.get("carried_holds"),bindings=registration["bindings"])
    opening_path=reconciled["opening_balance_source"]
    opening_sha=reconciled["opening_balance_sha256"]
    opening_rows=[row for row in ledger["charges"] if row["source"]==opening_path]
    _require(len(opening_rows)==1 and opening_rows[0]["receipt_sha256"]==opening_sha,
             "historical opening balance is missing or duplicated")
    opening=_bound_json(registration,{"path":opening_path,"sha256":opening_sha})
    _require(_money(str(opening["prior_campaign_spend_usd"]))==
             _money(opening_rows[0]["cost_usd"])==_money(reconciled["opening_balance_usd"]),
             "historical opening amount differs from its recorded source")
    receipt_bindings={}
    native_count=0
    with localcontext() as context:
        context.prec=128
        native_cost=Decimal(0)
        for row in ledger["charges"]:
            if row is opening_rows[0]:
                continue
            receipt=_bound_json(registration,{"path":row["source"],"sha256":row["receipt_sha256"]})
            _require(isinstance(receipt,dict) and receipt.get("scripted") is False
                     and receipt.get("unknown_provider_cost") is False
                     and isinstance(receipt.get("session_id"),str)
                     and row["id"]=="native-client:"+receipt["session_id"]
                     and _money(str(receipt.get("cost_usd")))==_money(row["cost_usd"]),
                     "historical native charge is not a matching final client receipt")
            receipt_bindings[row["source"]]=row["receipt_sha256"]
            native_count+=1
            native_cost+=_money(row["cost_usd"])
        for row in ledger["holds"]:
            receipt_bindings[row["source"]]=row["receipt_sha256"]
        known=native_cost+_money(opening_rows[0]["cost_usd"])
        held=sum((_money(row["reserved_usd"]) for row in ledger["holds"] if not row["settled"]),Decimal(0))
        allocated=known+held+Decimal("38")
        _require(receipt_bindings==reconciled["receipt_bindings"]
                 and type(reconciled["native_receipts"]) is int
                 and native_count==reconciled["native_receipts"]
                 and native_cost==_money(reconciled["native_client_cost_usd"])
                 and known==_money(reconciled["known_client_cost_usd"])
                 and held==_money(reconciled["unresolved_reserve_usd"])
                 and _money(reconciled["proposed_new_allocation_usd"])==Decimal("38")
                 and allocated==_money(reconciled["commitment_if_new_allocation_usd"])
                 and allocated<=_money(ledger["ceiling_usd"]),
                 "historical receipt coverage, sum, reserve or proposed commitment changed")
    return {"known_client_cost_usd":str(known),"native_receipts":native_count,
            "unresolved_reserve_usd":str(held),"commitment_if_new_allocation_usd":str(allocated),
            "unsettled_hold_ids":totals["unsettled_hold_ids"],
            "earlier_charge_rescan":reconciled.get("earlier_charge_rescan"),
            "provider_invoice_reconciliation":reconciled.get("provider_invoice_reconciliation")}
