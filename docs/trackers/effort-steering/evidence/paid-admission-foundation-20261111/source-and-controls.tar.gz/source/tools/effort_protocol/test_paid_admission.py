"""Paid admission consumes frozen evidence; summaries and synthetic populations cannot substitute."""
import copy
import hashlib
import io
import json
from pathlib import Path
import tarfile
import tempfile
import unittest

from campaign import selection_report
try:
    import paid_admission as subject
except ModuleNotFoundError:
    subject=None


class PopulationAdmissionTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(subject, "paid admission evidence verifier missing")
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        metadata=[{"id":"task"+str(i),"repo":"org/repo"+str(i),"base_commit":"a"*40,
            "image":"registry/task"+str(i),"language":"rust","public_issue_sha256":str(i+1)*64}
            for i in range(4)]
        status={row["id"]:{"eligible":True,"reason":"frozen public qualification"} for row in metadata}
        def raw(value): return (json.dumps(value,sort_keys=True)+"\n").encode()
        self.members={"metadata":"metadata.json","exposure":"exposure.json","status":"status.json",
            "rule":"rule.json","freeze":"freeze.json","selection":"selection.json"}
        self.payloads={"metadata.json":raw({"tasks":metadata}),
            "exposure.json":raw({"tasks":{"task3":["prior exposure"]}}),
            "status.json":raw(status),"rule.json":raw({"seed":"frozen-original-seed"})}
        effective=[{**row,**status[row["id"]]} for row in metadata]
        selected=selection_report(effective,{"task3"},"frozen-original-seed")
        self.payloads["selection.json"]=raw(selected)
        self.payloads["freeze.json"]=raw({"selection":selected,
            "selection_rule":{"seed":"frozen-original-seed"},"selected_ids":[r["id"] for r in selected["selected"]],
            "private_outcomes_read":False,"replacement_after_private_outcomes":False,
            "experimental_model_calls":0})
        self.reg={"metadata":effective,"exposure":["task3"],"seed":"frozen-original-seed",
            "selected":selected["selected"],"bindings":{}}
        self.archive=self.root/"population.tar.gz"
        self.seal()

    def seal(self):
        with tarfile.open(self.archive,"w:gz") as packed:
            for name,raw in self.payloads.items():
                member=tarfile.TarInfo(name)
                member.size=len(raw)
                packed.addfile(member,io.BytesIO(raw))
        digest=hashlib.sha256(self.archive.read_bytes()).hexdigest()
        self.reg["bindings"][str(self.archive)]=digest
        self.proof={"path":str(self.archive),"sha256":digest,"members":copy.deepcopy(self.members)}

    def test_original_universe_exposure_seed_and_selected_order_are_recomputed(self):
        result=subject.verify_population(self.reg,self.proof)
        self.assertEqual(result["metadata_tasks"],4)
        self.assertEqual(result["exposure_ids"],1)
        self.assertEqual(result["excluded_universe_tasks"],1)
        self.assertEqual(result["selected_ids"],[r["id"] for r in self.reg["selected"]])

    def test_external_exposure_ids_are_not_counted_as_excluded_universe_tasks(self):
        exposure={"task3":[],"external-history":[]}
        self.payloads["exposure.json"]=json.dumps({"tasks":exposure}).encode()
        self.reg["exposure"]=sorted(exposure)
        selected=selection_report(self.reg["metadata"],set(exposure),self.reg["seed"])
        self.payloads["selection.json"]=json.dumps(selected).encode()
        freeze=json.loads(self.payloads["freeze.json"])
        freeze["selection"]=selected
        self.payloads["freeze.json"]=json.dumps(freeze).encode()
        self.seal()
        result=subject.verify_population(self.reg,self.proof)
        self.assertEqual(result["exposure_ids"],2)
        self.assertEqual(result["excluded_universe_tasks"],1)

    def test_synthetic_two_row_universe_or_changed_seed_cannot_admit(self):
        original=copy.deepcopy(self.reg)
        for case in ("universe","seed","exposure","order","qualification","unknown-metadata"):
            with self.subTest(case=case):
                self.reg=copy.deepcopy(original)
                if case=="universe": self.reg["metadata"]=self.reg["selected"]
                elif case=="seed": self.reg["seed"]="synthetic-runtime-seed"
                elif case=="exposure": self.reg["exposure"]=[]
                elif case=="order": self.reg["selected"].reverse()
                elif case=="qualification": self.reg["metadata"][0]["eligible"]=False
                else: self.reg["metadata"][0]["private_score"]=1
                with self.assertRaises(ValueError):
                    subject.verify_population(self.reg,self.proof)

    def test_archive_hash_binding_link_and_duplicate_member_are_rejected(self):
        original=self.archive.read_bytes()
        self.reg["bindings"][str(self.archive)]="0"*64
        with self.assertRaises(ValueError): subject.verify_population(self.reg,self.proof)
        self.reg["bindings"][str(self.archive)]=self.proof["sha256"]
        self.archive.write_bytes(original+b"changed")
        with self.assertRaises(ValueError): subject.verify_population(self.reg,self.proof)
        self.archive.write_bytes(original)
        alias=self.root/"alias"
        alias.symlink_to(self.archive)
        linked={**self.proof,"path":str(alias)}
        self.reg["bindings"][str(alias)]=linked["sha256"]
        with self.assertRaises(ValueError): subject.verify_population(self.reg,linked)
        with tarfile.open(self.archive,"w:gz") as packed:
            for name,raw in list(self.payloads.items())+[("metadata.json",self.payloads["metadata.json"])]:
                member=tarfile.TarInfo(name);member.size=len(raw);packed.addfile(member,io.BytesIO(raw))
        digest=hashlib.sha256(self.archive.read_bytes()).hexdigest()
        self.proof["sha256"]=digest;self.reg["bindings"][str(self.archive)]=digest
        with self.assertRaises(ValueError): subject.verify_population(self.reg,self.proof)

    def test_private_outcome_selection_unknown_calls_and_mismatched_freeze_are_refused(self):
        original=copy.deepcopy(self.payloads)
        for case in ("private","replacement","calls","selection","rule","ids","metadata-hash","exposure-hash"):
            with self.subTest(case=case):
                self.payloads=copy.deepcopy(original)
                freeze=json.loads(self.payloads["freeze.json"])
                if case=="private": freeze["private_outcomes_read"]=True
                elif case=="replacement": freeze["replacement_after_private_outcomes"]=True
                elif case=="calls": freeze["experimental_model_calls"]=None
                elif case=="selection": freeze["selection"]["complete"]=False
                elif case=="rule": freeze["selection_rule"]["seed"]="changed"
                elif case=="ids": freeze["selected_ids"].reverse()
                else:
                    selected=json.loads(self.payloads["selection.json"])
                    selected["metadata_sha256" if case=="metadata-hash" else "exposure_sha256"]="0"*64
                    self.payloads["selection.json"]=json.dumps(selected).encode()
                    freeze["selection"]=selected
                self.payloads["freeze.json"]=json.dumps(freeze).encode()
                self.seal()
                with self.assertRaises(ValueError): subject.verify_population(self.reg,self.proof)
class PublicCommandAdmissionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.source=self.root/"source"
        self.source.mkdir()
        (self.source/"Cargo.toml").write_text("[workspace]\n")
        self.command={"argv":["cargo","check","--offline","--workspace"],"cwd":".",
                      "test_files":["Cargo.toml"]}
        self.facts={"id":"public-cargo-check","complete":True,"resource_valid":True,"exit_code":0}
        self.public={"public_checks":[self.command],"execution_profile":"cargo-v2"}
        self.reg={"tasks":{"task":{"source":str(self.source),
            "source_sha256":subject.input_digest(self.source),"backend":{"public":self.public}}},"bindings":{}}
        self.registered={"source":str(self.source),"source_digest":subject.input_digest(self.source),
            "request":{"id":"public-cargo-check",**self.command}}
        self.result={"complete":True,"resource_valid":True,"exit_code":0,"receipt":self.facts}
        self.proof={"task":[{"registration":self.bound("registration.json",self.registered),
                            "result":self.bound("result.json",self.result)}]}

    def bound(self,name,value):
        path=self.root/name
        path.write_text(json.dumps(value))
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        self.reg["bindings"][str(path)]=digest
        return {"path":str(path),"sha256":digest}

    def test_reads_the_actual_source_profile_fixture_and_host_receipt(self):
        from unittest.mock import patch
        self.public["public_fixture"]={"fingerprint":"frozen"}
        with patch.object(subject,"verify_receipt",return_value=self.facts) as verify:
            result=subject.verify_public_commands(self.reg,self.proof)
        verify.assert_called_once_with({"id":"public-cargo-check"},self.root/"commands",self.source,
            expected_profile="cargo-v2",expected_fixture=self.public["public_fixture"])
        self.assertEqual(result["task"]["verified_commands"],1)

    def test_extra_missing_or_different_public_command_cannot_qualify(self):
        from unittest.mock import patch
        original=copy.deepcopy(self.reg)
        for case in ("missing","extra","command","source","profile-result","failed","drift"):
            with self.subTest(case=case):
                self.reg=copy.deepcopy(original)
                self.public=self.reg["tasks"]["task"]["backend"]["public"]
                proof=copy.deepcopy(self.proof)
                result=copy.deepcopy(self.result)
                facts=copy.deepcopy(self.facts)
                if case=="missing": proof={}
                elif case=="extra": proof["extra"]=proof["task"]
                elif case=="command": self.public["public_checks"][0]["argv"]=["true"]
                elif case=="source": self.reg["tasks"]["task"]["source_sha256"]="0"*64
                elif case=="profile-result": facts["execution_profile"]="wrong"
                elif case=="failed":
                    result["exit_code"]=101
                    proof["task"][0]["result"]=self.bound("result.json",result)
                elif case=="drift": (self.root/"result.json").write_text("changed")
                with patch.object(subject,"verify_receipt",return_value=facts):
                    with self.assertRaises(ValueError):
                        subject.verify_public_commands(self.reg,proof)
                self.bound("result.json",self.result)

    def test_incomplete_raw_receipt_is_not_replaced_by_the_positive_summary(self):
        from unittest.mock import patch
        with patch.object(subject,"verify_receipt",side_effect=ValueError("incomplete capture")):
            with self.assertRaisesRegex(ValueError,"incomplete capture"):
                subject.verify_public_commands(self.reg,self.proof)
class AccountingAdmissionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.reg={"bindings":{}}
        self.opening=self.root/"opening.json"
        self.known=self.root/"known.json"
        self.hold=self.root/"hold.json"
        self.opening.write_text(json.dumps({"prior_campaign_spend_usd":"5"}))
        self.known.write_text(json.dumps({"session_id":"known","scripted":False,
            "unknown_provider_cost":False,"cost_usd":"0.25"}))
        self.hold.write_text(json.dumps({"session_id":"legacy","scripted":False,
            "unknown_provider_cost":True,"cost_usd":None,"requests":0,"forwarded":0,
            "campaign_available_usd":"4"}))
        def row(path,identity,**fields):
            digest=hashlib.sha256(path.read_bytes()).hexdigest()
            self.reg["bindings"][str(path)]=digest
            return {"id":identity,"source":str(path),"receipt_sha256":digest,**fields}
        self.ledger={"ceiling_usd":"200","charges":[
            row(self.opening,"recorded-pre-native-opening-balance",cost_usd="5"),
            row(self.known,"native-client:known",cost_usd="0.25")],
            "holds":[row(self.hold,"native-client:legacy",cost_usd=None,reserved_usd="4",settled=False)],
            "reservations":[]}
        self.reg["ledger"]=copy.deepcopy(self.ledger)
        self.reg["carried_holds"]=[{k:self.ledger["holds"][0][k]
            for k in ("id","source","receipt_sha256","reserved_usd")}]
        self.reconciled={"schema":"client-ledger-reconciliation-v1","ledger":self.ledger,
            "opening_balance_source":str(self.opening),
            "opening_balance_sha256":self.ledger["charges"][0]["receipt_sha256"],
            "opening_balance_usd":"5","known_client_cost_usd":"5.25","native_receipts":1,
            "native_client_cost_usd":"0.25","unresolved_reserve_usd":"4",
            "proposed_new_allocation_usd":"38","commitment_if_new_allocation_usd":"47.25",
            "receipt_bindings":{r["source"]:r["receipt_sha256"]
                for r in self.ledger["charges"][1:]+self.ledger["holds"]}}
        self.report=self.root/"reconciliation.json"
        self.seal()

    def seal(self):
        self.report.write_text(json.dumps(self.reconciled))
        digest=hashlib.sha256(self.report.read_bytes()).hexdigest()
        self.reg["bindings"][str(self.report)]=digest
        self.proof={"path":str(self.report),"sha256":digest}

    def test_every_charge_is_reopened_and_the_unknown_hold_is_retained(self):
        original=copy.deepcopy(self.reg["ledger"])
        checked=subject.verify_accounting(self.reg,self.proof)
        self.assertEqual(checked["known_client_cost_usd"],"5.25")
        self.assertEqual(checked["unresolved_reserve_usd"],"4")
        self.assertEqual(checked["native_receipts"],1)
        self.assertEqual(self.reg["ledger"],original)

    def test_omitted_charge_changed_receipt_unbound_opening_and_false_sum_refuse(self):
        original=copy.deepcopy(self.reg)
        original_report=copy.deepcopy(self.reconciled)
        raw=self.known.read_bytes()
        for case in ("omitted","changed","unbound-opening","sum","count","carry","commitment","receipt-coverage"):
            with self.subTest(case=case):
                self.reg=copy.deepcopy(original)
                self.reconciled=copy.deepcopy(original_report)
                self.known.write_bytes(raw)
                if case=="omitted": self.reg["ledger"]["charges"].pop()
                elif case=="changed": self.known.write_bytes(raw+b" ")
                elif case=="unbound-opening": self.reg["bindings"].pop(str(self.opening))
                elif case=="sum": self.reconciled["known_client_cost_usd"]="0"
                elif case=="count": self.reconciled["native_receipts"]=0
                elif case=="carry": self.reg.pop("carried_holds")
                elif case=="commitment": self.reconciled["commitment_if_new_allocation_usd"]="0"
                else: self.reconciled["receipt_bindings"].pop(str(self.known))
                self.seal()
                with self.assertRaises(ValueError):
                    subject.verify_accounting(self.reg,self.proof)

    def test_unknown_or_scripted_receipt_cannot_become_a_known_historical_charge(self):
        original=copy.deepcopy(self.reg)
        for case in ("unknown","scripted","wrong-session","wrong-cost"):
            with self.subTest(case=case):
                self.reg=copy.deepcopy(original)
                raw={"session_id":"known","scripted":False,"unknown_provider_cost":False,"cost_usd":"0.25"}
                if case=="unknown": raw.update(unknown_provider_cost=True,cost_usd=None)
                elif case=="scripted": raw["scripted"]=True
                elif case=="wrong-session": raw["session_id"]="other"
                else: raw["cost_usd"]="0.26"
                self.known.write_text(json.dumps(raw))
                digest=hashlib.sha256(self.known.read_bytes()).hexdigest()
                self.reg["bindings"][str(self.known)]=digest
                self.reg["ledger"]["charges"][1]["receipt_sha256"]=digest
                self.reconciled["ledger"]=copy.deepcopy(self.reg["ledger"])
                self.reconciled["receipt_bindings"][str(self.known)]=digest
                self.seal()
                with self.assertRaises(ValueError):
                    subject.verify_accounting(self.reg,self.proof)


if __name__=="__main__":
    unittest.main()
