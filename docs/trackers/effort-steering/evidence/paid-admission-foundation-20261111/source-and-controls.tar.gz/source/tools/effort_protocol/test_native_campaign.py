"""Consuming campaign/backend boundary tests, without model calls."""
import copy
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import test_runner as fixtures
from receipts import input_digest, publish_exclusive
import runner
try:
    import native_campaign as subject
except ImportError:
    subject = None


class NativeBackendTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(subject, "concrete native backend missing")
        fixtures.RunnerTests.setUp(self)
        self.root = self.out.parent
        self.entry = HERE/"evaluator_entry.py"
        self.private = self.root/"private-config.json"
        self.private.write_text('{"private_expected_marker":"MUST_NOT_ENTER_ACTOR"}')
        self.calls = []
        self.grades = []
        for task in self.reg["tasks"].values():
            task["backend"] = {"public": {"capture_base_commit": "a"*40},
                "private": {"entry": str(self.entry), "entry_sha256": "b"*64,
                    "config": str(self.private), "config_sha256": fixtures.digest(self.private)},
                "scripted_plans": {arm+":"+phase: [] for arm in "LRPX"
                    for phase in ("investigate", "repair", "challenge")}}
        self.backend = subject.NativeCampaignBackend(mode="scripted")

    def invoke(self, request, out, public, **kwargs):
        self.calls.append(copy.deepcopy((request, public, kwargs)))
        self.assertNotIn("MUST_NOT_ENTER_ACTOR", json.dumps((request,public,kwargs)))
        record = fixtures.ScriptedBackend(self.out).invoke(request, out)
        native = out/"native"
        native.mkdir()
        (native/"candidate.patch").write_bytes(b"complete cumulative patch")
        publish_exclusive(native/"candidate-capture.json", {"complete": True,
            "baseline_commit": "a"*40, "sha256": fixtures.digest(native/"candidate.patch"),
            "bytes": (native/"candidate.patch").stat().st_size})
        return record

    def grade_process(self, argv, **kwargs):
        self.assertEqual(len(self.calls), 16)
        self.assertTrue((self.out/"actor-batch-closed.json").is_file())
        request = json.loads(Path(argv[-2]).read_bytes())
        self.grades.append(request)
        self.assertEqual(request["source_digest"], input_digest(request["source"]))
        self.assertEqual(request["patch_sha256"], fixtures.digest(request["patch"]))
        publish_exclusive(Path(argv[-1])/"verdict.json", {"valid": True, "pass": True})
        return subprocess.CompletedProcess(argv, 0)

    def contexts(self):
        return (patch.object(subject, "_verify_public", return_value={"ready": True}),
            patch.object(subject, "_verify_private", return_value={"ready": True}),
            patch.object(subject, "invoke_native", side_effect=self.invoke),
            patch.object(subject.subprocess, "run", side_effect=self.grade_process))

    def run_it(self):
        a,b,c,d = self.contexts()
        with a,b,c,d:
            return runner.run_campaign(self.reg, self.backend)

    def test_actual_controller_uses_sixteen_native_invocations_then_eight_private_processes(self):
        result = self.run_it()
        self.assertEqual(result["status"], "completed")
        self.assertEqual(len(self.calls), 16)
        self.assertEqual(len(self.grades), 8)
        self.assertTrue(all(row["grade"]["pass"] for row in result["attempts"]))
        self.assertTrue(all(kwargs["mode"] == "scripted" and kwargs["scripted_plan"] == []
                            and kwargs.get("token_path") is None for _,_,kwargs in self.calls))

    def test_invocation_requires_verified_campaign_and_exact_schedule_identity(self):
        with patch.object(subject,"invoke_native") as native:
            with self.assertRaises(ValueError):
                self.backend.invoke({}, self.root/"unowned")
            self.assertEqual(native.call_count,0)
        a,b,_,_ = self.contexts()
        with a,b:
            self.backend.verify(self.reg)
        self.out.mkdir()
        out = self.out/"attempts"/"00-L"/"repair"
        out.mkdir(parents=True)
        request = {"task_id": self.reg["selected"][0]["id"], "arm":"X",
            "attempt_index":0, "phase":"repair","invocation_id":"test-campaign::0::repair"}
        with patch.object(subject,"invoke_native") as native:
            with self.assertRaises(ValueError):
                self.backend.invoke(request,out)
            self.assertEqual(native.call_count,0)

    def test_private_grade_before_batch_closure_refuses_without_subprocess(self):
        a,b,_,_ = self.contexts()
        with a,b:
            self.backend.verify(self.reg)
        with patch.object(subject.subprocess,"run") as command:
            with self.assertRaises(ValueError):
                self.backend.grade({"source": str(self.root)},self.root)
            self.assertEqual(command.call_count,0)

    def test_missing_or_changed_patch_cannot_be_graded(self):
        result = self.run_it()
        last = self.grades[-1]
        Path(last["patch"]).write_bytes(b"tampered")
        out = self.root/"new-grade";out.mkdir()
        with patch.object(subject.subprocess,"run") as command:
            with self.assertRaises(ValueError):
                self.backend.grade({key:last[key] for key in
                    ("task_id","arm","source","source_digest")},out)
            self.assertEqual(command.call_count,0)
        self.assertEqual(result["status"],"completed")

    def test_private_process_failure_is_invalid_with_full_output_preserved(self):
        self.grade_process = lambda *args,**kwargs: subprocess.CompletedProcess(args[0],17)
        result = self.run_it()
        self.assertEqual(result["status"],"grading_stopped")
        self.assertEqual(len(self.calls),16)
        self.assertEqual(len(list((self.out/"grades").glob("*"))),1)
        self.assertTrue((self.out/"grades/00/private-process.stdout").is_file())

    def test_unknown_public_descriptor_key_cannot_carry_hidden_fields(self):
        task = next(iter(self.reg["tasks"].values()))
        task["backend"]["public"]["private_expected"] = ["hidden"]
        with patch.object(subject,"_verify_public") as public:
            checked = runner.preflight(self.reg,self.backend)
        self.assertFalse(checked["ready"])
        self.assertEqual(public.call_count,0)

    def test_paid_mode_stays_closed_before_whole_admission_qualification(self):
        self.reg["mode"] = "paid"
        backend = subject.NativeCampaignBackend(mode="paid", token_path="/not/read/token")
        with patch.object(subject,"_verify_public") as public:
            checked = runner.preflight(self.reg,backend)
        self.assertFalse(checked["paid_ready"])
        self.assertFalse(checked["ready"])
        self.assertEqual(public.call_count,0)

    def test_replacing_registration_after_verification_refuses_before_actor(self):
        a,b,_,_ = self.contexts()
        with a,b:
            self.backend.verify(self.reg)
        self.reg["tasks"][self.reg["selected"][0]["id"]]["backend"]["scripted_plans"]["L:repair"] = [["bad",{}]]
        with a,b:
            with self.assertRaises(ValueError):
                self.backend.verify(self.reg)
    def test_public_verification_runs_actual_executable_storage_and_memory_probe(self):
        public = {'template': str(self.root), 'template_sha256': 'a'*64,
            'knowledge_paths':['system-prompt.md'], 'knowledge_sha256':'a'*64,
            'runtime': {}, 'global_rules': str(self.private),
            'global_rules_sha256': fixtures.digest(self.private), 'capture_base_commit':'a'*40,
            'image':'sha256:'+'a'*64, 'resource_root':str(self.root),
            'resource_floors':{'root_free':1,'tmp_free':1,'mem_available':1}}
        with patch.object(subject,'input_digest',return_value='a'*64), \
                patch.object(subject,'_runtime_inputs',return_value={}), \
                patch.object(subject,'_runtime',return_value={}), \
                patch.object(subject,'_git',return_value=subprocess.CompletedProcess([],0,'a'*40+'\n')):
            proof = subject._verify_public(public)
        self.assertTrue(proof['host']['tmp_exec'])
        self.assertGreater(proof['host']['mem_available'],0)
        self.assertEqual(proof['host']['root'],str(self.root))


if __name__ == "__main__":
    unittest.main()
