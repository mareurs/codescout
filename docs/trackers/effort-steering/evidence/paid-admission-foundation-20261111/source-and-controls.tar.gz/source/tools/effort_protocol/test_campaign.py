"""Outcome-blind selection and complete accounting, with no actor boundary."""
import copy
import unittest

try:
    import campaign
except ModuleNotFoundError as exc:
    if exc.name != "campaign":
        raise
    campaign = None


def metadata():
    return [
        {"id": name, "repo": repo, "base_commit": "a" * 40, "image": "local/source:fixed",
         "created_at": "2026-01-01", "language": "rust", "public_issue_sha256": digest * 64,
         "eligible": True, "reason": "public adapter qualified"}
        for name, repo, digest in (
            ("one", "org/a", "1"), ("two", "org/a", "2"),
            ("three", "org/a", "3"), ("four", "org/b", "4"))
    ]


def ledger():
    return {"ceiling_usd": "200",
            "charges": [{"id": "prior", "cost_usd": "64.401093499999998654",
                         "receipt_sha256": "a" * 64},
                        {"id": "startup", "cost_usd": "0", "receipt_sha256": "b" * 64}],
            "holds": [{"id": "startup", "reserved_usd": "4", "settled": True}],
            "reservations": []}


def attempt():
    return {"id": "task-L", "task_id": "task", "arm": "L", "reserved_usd": "3"}


class CampaignTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(campaign, "campaign selection/accounting implementation is absent")

    def test_selection_is_hash_ordered_and_input_order_independent(self):
        # Independently calculated fixture-seed hashes order three,four,two,one.
        rows = metadata()
        for order in (rows, list(reversed(rows))):
            self.assertEqual([r["id"] for r in campaign.select_tasks(order, set(), "fixture-seed")],
                             ["three", "four"])

    def test_exposure_is_excluded_before_selection(self):
        self.assertEqual(
            [r["id"] for r in campaign.select_tasks(metadata(), {"three"}, "fixture-seed")],
            ["four", "two"])

    def test_repository_identity_is_case_insensitive(self):
        rows = metadata()
        rows[3]["repo"] = "ORG/A"
        rows[1]["repo"] = "org/b"
        self.assertEqual([r["id"] for r in campaign.select_tasks(rows, set(), "fixture-seed")],
                         ["three", "two"])

    def test_public_ineligibility_keeps_reason_and_hash_position(self):
        rows = metadata()
        rows[2].update(eligible=False, reason="public image unavailable")
        report = campaign.selection_report(rows, set(), "fixture-seed")
        self.assertEqual([r["id"] for r in report["selected"]], ["four", "two"])
        self.assertEqual(report["decisions"][0]["reason"], "public image unavailable")
        self.assertEqual(report["decisions"][0]["id"], "three")

    def test_pending_earlier_qualification_cannot_be_skipped(self):
        rows = metadata()
        rows[2].update(eligible=None, reason="public qualification pending")
        with self.assertRaises(campaign.CampaignViolation):
            campaign.select_tasks(rows, set(), "fixture-seed")

    def test_two_repositories_are_required_without_partial_success(self):
        rows = metadata()
        rows[3].update(eligible=False, reason="image absent")
        with self.assertRaises(campaign.CampaignViolation):
            campaign.select_tasks(rows, set(), "fixture-seed")

    def test_no_model_outcomes_enter_metadata(self):
        for field, value in (("pass", True), ("low_score", 0), ("gold_patch", "diff"),
                             ("expected_tests", 4)):
            with self.subTest(field=field):
                rows = metadata()
                rows[0][field] = value
                with self.assertRaises(campaign.CampaignViolation):
                    campaign.select_tasks(rows, set(), "fixture-seed")

    def test_malformed_metadata_and_duplicate_ids_refuse(self):
        for mutate in (
            lambda r: r.append(copy.deepcopy(r[0])),
            lambda r: r[0].update(base_commit="unknown"),
            lambda r: r[0].update(public_issue_sha256=""),
            lambda r: r[0].update(eligible=1),
            lambda r: r[0].update(eligible=False, reason=""),
        ):
            with self.subTest(mutate=mutate):
                rows = metadata()
                mutate(rows)
                with self.assertRaises(campaign.CampaignViolation):
                    campaign.select_tasks(rows, set(), "fixture-seed")

    def test_empty_seed_refuses(self):
        with self.assertRaises(campaign.CampaignViolation):
            campaign.select_tasks(metadata(), set(), "")

    def test_selection_does_not_alias_or_modify_inputs(self):
        rows = metadata()
        before = copy.deepcopy(rows)
        chosen = campaign.select_tasks(rows, set(), "fixture-seed")
        chosen[0]["reason"] = "changed"
        self.assertEqual(rows, before)

    def test_schedule_balances_positions_and_reserves_thirty_dollars(self):
        chosen = campaign.select_tasks(metadata(), set(), "fixture-seed")
        schedule = campaign.attempt_schedule(chosen)
        self.assertEqual([(r["task_id"], r["arm"]) for r in schedule],
                         [("three", "L"), ("three", "R"), ("three", "P"), ("three", "X"),
                          ("four", "X"), ("four", "P"), ("four", "R"), ("four", "L")])
        self.assertEqual([r["reserved_usd"] for r in schedule],
                         ["3", "3", "3", "6", "6", "3", "3", "3"])
        self.assertEqual(len({r["id"] for r in schedule}), 8)
        self.assertEqual(schedule[1]["phase_reservations_usd"], ["0.60", "1.80", "0.60"])
        self.assertEqual(schedule[2]["phase_cli_caps_usd"], ["0.55", "1.65", "0.55"])
        self.assertLess(float(schedule[0]["cli_cap_usd"]), 3)

    def test_reservation_preserves_history_and_decimal_precision(self):
        prior = ledger()
        before = copy.deepcopy(prior)
        reserved = campaign.reserve_attempt(prior, attempt())
        self.assertEqual(prior, before)
        self.assertEqual(reserved["reservations"], [attempt()])
        self.assertEqual(campaign.accounting_totals(reserved)["committed_usd"],
                         "67.401093499999998654")

    def test_unknown_charge_or_unsettled_old_hold_blocks_new_attempt(self):
        for field in ("cost", "hold"):
            with self.subTest(field=field):
                prior = ledger()
                if field == "cost":
                    prior["charges"][0]["cost_usd"] = None
                else:
                    prior["holds"][0]["settled"] = False
                with self.assertRaises(campaign.CampaignViolation):
                    campaign.reserve_attempt(prior, attempt())

    def test_unknown_hold_state_is_not_settled(self):
        prior = ledger()
        del prior["holds"][0]["settled"]
        with self.assertRaises(campaign.CampaignViolation):
            campaign.reserve_attempt(prior, attempt())

    def test_duplicate_attempt_or_receipt_cannot_be_counted_twice(self):
        prior = campaign.reserve_attempt(ledger(), attempt())
        with self.assertRaises(campaign.CampaignViolation):
            campaign.reserve_attempt(prior, attempt())
        prior = ledger()
        prior["charges"].append(copy.deepcopy(prior["charges"][0]))
        with self.assertRaises(campaign.CampaignViolation):
            campaign.reserve_attempt(prior, attempt())

    def test_invalid_amount_or_ceiling_crossing_refuses(self):
        for amount in ("NaN", "Infinity", "-1", True, 0.5, "136"):
            with self.subTest(amount=amount):
                request = attempt()
                request["reserved_usd"] = amount
                with self.assertRaises(campaign.CampaignViolation):
                    campaign.reserve_attempt(ledger(), request)

    def test_final_cumulative_charge_is_counted_once_per_invocation(self):
        receipts = [
            {"invocation_id": "phase-a", "sequence": 0, "cumulative_usd": "0.10",
             "terminal": False, "receipt_sha256": "a" * 64},
            {"invocation_id": "phase-a", "sequence": 1, "cumulative_usd": "0.25",
             "terminal": True, "receipt_sha256": "b" * 64},
            {"invocation_id": "phase-b", "sequence": 0, "cumulative_usd": "0.40",
             "terminal": True, "receipt_sha256": "c" * 64},
        ]
        charges = campaign.reconcile_charges(receipts)
        self.assertEqual(charges, [
            {"id": "phase-a", "cost_usd": "0.25", "receipt_sha256": "b" * 64},
            {"id": "phase-b", "cost_usd": "0.40", "receipt_sha256": "c" * 64}])
        self.assertEqual(campaign.reconcile_charges(list(reversed(receipts))), charges)

    def test_missing_terminal_cost_stays_unknown(self):
        for terminal, cost in ((False, "0.10"), (True, None)):
            with self.subTest(terminal=terminal, cost=cost):
                result = campaign.reconcile_charges([
                    {"invocation_id": "phase", "sequence": 0, "cumulative_usd": cost,
                     "terminal": terminal, "receipt_sha256": "a" * 64}])
                self.assertIsNone(result[0]["cost_usd"])
                prior = ledger()
                prior["charges"] = result
                with self.assertRaises(campaign.CampaignViolation):
                    campaign.reserve_attempt(prior, attempt())

    def test_conflicting_duplicate_or_decreasing_cost_refuses(self):
        first = {"invocation_id": "phase", "sequence": 0, "cumulative_usd": "0.20",
                 "terminal": False, "receipt_sha256": "a" * 64}
        for second in (
            dict(first, cumulative_usd="0.30"),
            dict(first, sequence=1, cumulative_usd="0.10", terminal=True),
            dict(first, sequence=True),
        ):
            with self.subTest(second=second):
                with self.assertRaises(campaign.CampaignViolation):
                    campaign.reconcile_charges([first, second])
    def test_pending_report_never_proposes_later_tasks(self):
        rows = metadata()
        rows[2].update(eligible=None, reason="pending")
        report = campaign.selection_report(rows, set(), "fixture-seed")
        self.assertFalse(report["complete"])
        self.assertEqual(report["selected"], [])

    def test_settled_hold_requires_matching_terminal_charge(self):
        prior = ledger()
        prior["charges"] = prior["charges"][:1]
        with self.assertRaises(campaign.CampaignViolation):
            campaign.reserve_attempt(prior, attempt())

    def test_an_invocation_cannot_continue_after_terminal_cost(self):
        first = {"invocation_id": "phase", "sequence": 0, "cumulative_usd": "0.20",
                 "terminal": True, "receipt_sha256": "a" * 64}
        second = dict(first, sequence=1, cumulative_usd="0.25", receipt_sha256="b" * 64)
        with self.assertRaises(campaign.CampaignViolation):
            campaign.reconcile_charges([first, second])
