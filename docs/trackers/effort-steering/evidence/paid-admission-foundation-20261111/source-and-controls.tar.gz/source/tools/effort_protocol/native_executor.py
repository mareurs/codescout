"""Native phase bridge: reuse lifecycle, retain its cost/capture/cleanup evidence.

The default is an offline scripted transport. Paid use requires separate explicit
admission. A scripted actual CLI is a runtime qualification, never an efficacy run.
"""
import hashlib
import json
import shutil
import sys
from pathlib import Path
from decimal import Decimal, InvalidOperation

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "agent_lifecycle"))
import external
from receipts import input_digest, publish_exclusive
import public_fixture

# Explicit runner roles, identical to lifecycle artifact exclusions plus Git and
# the phase submission. These are not inferred from extensions or file contents.
TOOL_ROLES = {".git", ".codescout", ".buddy", ".superpowers", ".claude", "target", "node_modules"}
SYSTEM_PATH = ".codescout/system-prompt.md"
RECON = "codescout-companion:reconnaissance"


def _text(value):
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return "\n".join(_text(item) for item in value)
    if isinstance(value, dict):
        return "\n".join(_text(item) for item in value.values())
    return ""


def _context(out, system_lines, recon_marker):
    """Require successful native calls and the client's actual delivered body."""
    system_ok = recon_ok = False
    for path in sorted(out.glob("request-*.json")):
        body = json.loads(path.read_text())
        calls = {}
        skill_ack = skill_body = False
        for message in body.get("messages", []):
            blocks = message.get("content", [])
            if not isinstance(blocks, list):
                continue
            for block in blocks:
                if not isinstance(block, dict):
                    continue
                if message.get("role") == "assistant" and block.get("type") == "tool_use":
                    calls[block.get("id")] = block
                if message.get("role") == "user" and block.get("type") == "text":
                    text = block.get("text", "")
                    skill_body |= bool(recon_marker) and text.startswith("Base directory for this skill:") and recon_marker in text
                if message.get("role") != "user" or block.get("type") != "tool_result" or block.get("is_error"):
                    continue
                call = calls.get(block.get("tool_use_id"), {})
                args = call.get("input", {})
                text = _text(block.get("content"))
                if call.get("name") == "mcp__codescout__read_file" and args.get("path") == SYSTEM_PATH:
                    system_ok |= bool(system_lines) and all(line in text for line in system_lines)
                if call.get("name") == "Skill" and args.get("skill") == RECON:
                    skill_ack |= "Launching skill: " + RECON in text
        recon_ok |= skill_ack and skill_body
    return {"system_delivered": system_ok, "recon_delivered": recon_ok}


def _public_digest(actor):
    names = []
    for child in actor.iterdir():
        if child.name in TOOL_ROLES or child.name == "submission.json":
            continue
        names.append(child.name)
        if child.is_dir() and not child.is_symlink():
            names.extend(path.relative_to(actor).as_posix() for path in child.rglob("*"))
    return input_digest(actor, sorted(names))


def _options(argv, key):
    return [value.split("=", 1)[1] if value.startswith(key + "=") else argv[index + 1]
            for index, value in enumerate(argv) if value == key or value.startswith(key + "=")]


def _runtime_binding(prepared):
    cfg = json.loads((prepared / "prepared.json").read_text())
    argv = json.loads((prepared / "mcp-native-argv.json").read_text())
    descriptor = cfg.get("public_fixture")
    fixture_binding = {}
    if "public_fixture" in cfg:
        public_fixture.validate_fixture_options(
            {key: _options(argv, key) for key in ("--mount", "--entrypoint", "--add-host")},
            descriptor, "native", actor=Path(cfg["actor"]))
        fixture_binding["public_fixture_sha256"] = descriptor["fingerprint"]
    elif _options(argv, "--entrypoint") != ["/bench/bin/codescout"]:
        raise ValueError("native executable binding requires the registered entrypoint")
    mounts = [dict(part.split("=", 1) if "=" in part else (part, True)
                   for part in mount.split(",")) for mount in _options(argv, "--mount")]
    selected = [mount for mount in mounts if mount.get("dst") == "/bench/bin"]
    if len(selected) != 1 or selected[0].get("readonly") is not True:
        raise ValueError("native executable binding requires a unique read-only mount")
    executable = Path(selected[0]["src"]) / "codescout"
    if executable.is_symlink() or not executable.is_file():
        raise ValueError("native executable binding is not a regular frozen file")
    knowledge = cfg.get("knowledge_paths", ["project.toml", "system-prompt.md"])
    binding = {"image": cfg["image"],
        "executable_sha256": hashlib.sha256(executable.read_bytes()).hexdigest(),
        "source_snapshot_sha256": _public_digest(Path(cfg["actor"])),
        "knowledge_sha256": input_digest(Path(cfg["actor"]) / ".codescout", knowledge),
        **fixture_binding}
    return binding, executable

def _capture(actor, destination):
    destination.mkdir(exist_ok=False)
    for source in actor.iterdir():
        if source.name in TOOL_ROLES or source.name == "submission.json":
            continue
        target = destination / source.name
        if source.is_symlink():
            target.symlink_to(source.readlink())
        elif source.is_dir():
            shutil.copytree(source, target, symlinks=True)
        elif source.is_file():
            shutil.copy2(source, target)
        else:
            raise ValueError("unsupported native source input")
    input_digest(destination)  # Refuses escaping symlinks and special files.
    return str(destination)


def _cli_cap(request):
    value = request.get("cli_cap_usd", request.get("allowance_usd"))
    try:
        cap = Decimal(str(value))
        allowance = Decimal(str(request.get("allowance_usd")))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise ValueError("invalid CLI cap") from exc
    if (not cap.is_finite() or not allowance.is_finite() or cap <= 0 or allowance <= 0
            or cap > allowance or ("cli_cap_usd" in request and cap >= allowance)):
        raise ValueError("invalid CLI cap")
    return str(value)

class NativeExecutor:
    mode = "native"

    def __init__(self, prepared, capture, *, system_lines, recon_marker,
                 scripted_plan=None, allow_paid=False, token_path=None, supervisor=None):
        self.prepared = Path(prepared).resolve()
        self.capture = Path(capture).resolve()
        self.system_lines = list(system_lines)
        self.recon_marker = recon_marker
        self.scripted_plan = scripted_plan
        self.allow_paid = allow_paid
        self.token_path = token_path
        self.supervisor = supervisor

    def readiness_source(self):
        """Return the concrete actor source for source-bound readiness checks."""
        cfg = json.loads((self.prepared / "prepared.json").read_text())
        return Path(cfg["actor"])


    def bind_readiness(self, binding):
        measured, executable = _runtime_binding(self.prepared)
        if measured != binding:
            raise ValueError("native concrete runtime binding mismatch")
        self._bound_readiness = dict(binding)
        path = self.prepared / "prepared.json"
        cfg = json.loads(path.read_text())
        cfg.setdefault("files", {})[str(executable)] = measured["executable_sha256"]
        if "public_fixture" in cfg:
            public_fixture.read_fixture_bundle(cfg["public_fixture"])
            for item in Path(cfg["public_fixture"]["root"]).iterdir():
                cfg["files"][str(item)] = hashlib.sha256(item.read_bytes()).hexdigest()
        path.write_text(json.dumps(cfg, indent=2) + "\n")
        return measured

    def execute(self, request):
        arm = request.get("arm", "P")
        if arm not in ("L", "R", "P", "X"):
            raise ValueError("unsupported native arm")
        if self.scripted_plan is None and not self.allow_paid:
            raise ValueError("paid native execution has not been admitted")
        if getattr(self, "_bound_readiness", None) != _runtime_binding(self.prepared)[0]:
            raise ValueError("native preparation binding is missing or changed")
        if request.get("max_continuations") != 2:
            raise ValueError("native phase requires the registered continuation bound")
        cli_cap = _cli_cap(request)
        cfg_path = self.prepared / "prepared.json"
        cfg = json.loads(cfg_path.read_text())
        if (self.prepared / "started.json").exists():
            raise ValueError("native phase cannot restart an existing attempt")
        cfg["prompt"] = request["prompt"] + "\n\nFrozen public packet:\n" + json.dumps(
            request["public_packet"], sort_keys=True)
        if arm == "P":
            cfg["prompt"] += "\n\nWrite submission.json in the project root."
        cfg["max_continuations"] = 2
        cfg_path.write_text(json.dumps(cfg, indent=2) + "\n")
        kwargs = {"effort": "xhigh" if arm == "X" else "low", "allowance": request["allowance_usd"],
                  "cli_cap": cli_cap, "scripted_plan": self.scripted_plan}
        if self.token_path is not None:
            kwargs["token_path"] = self.token_path
        if self.supervisor is not None:
            kwargs["supervisor"] = self.supervisor
        receipt = external.launch(self.prepared, **kwargs)
        context_error = None
        try:
            context = _context(self.prepared, self.system_lines, self.recon_marker)
        except (ValueError, OSError, TypeError, AttributeError) as exc:
            context = {"system_delivered": False, "recon_delivered": False}
            context_error = type(exc).__name__ + ": " + str(exc)
        actor = Path(cfg["actor"])
        submission = None
        submission_path = actor / "submission.json"
        if submission_path.is_file() and not submission_path.is_symlink():
            try:
                submission = json.loads(submission_path.read_text())
            except (ValueError, OSError):
                pass  # Malformed actor submission is incomplete, not another call.
        captured = False
        capture_error = None
        try:
            _capture(actor, self.capture)
            captured = receipt.get("artifact_evidence", {}).get("complete") is True
        except (ValueError, OSError) as exc:
            capture_error = type(exc).__name__ + ": " + str(exc)
        turns = receipt.get("lifecycle", {}).get("continuations")
        valid_turns = type(turns) is int and 0 <= turns <= 2
        result = {"source": str(self.capture), "submission": submission,
            "cost_usd": receipt.get("cost_usd"),
            "cost_is_final": receipt.get("unknown_provider_cost") is False,
            "context_valid": receipt.get("context_valid") is True and all(context.values()) and valid_turns,
            "cleanup_complete": receipt.get("cleanup_error") is None
                and receipt.get("supervision_error") is None
                and receipt.get("background_evidence", {}).get("complete") is True,
            "capture_complete": captured, "capture_error": capture_error,
            "turns": turns + 1 if valid_turns else None,
            "context_evidence": context, "context_error": context_error, "provider_forwarded": receipt.get("forwarded"),
            "scripted_provider": self.scripted_plan is not None}
        publish_exclusive(self.prepared / "native-executor.json", result)
        return result
