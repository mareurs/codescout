"""Reuse frozen public onboarding; never carry another invocation's mutable index."""
import json
import os
from pathlib import Path
import shutil
import subprocess

from native_executor import TOOL_ROLES, _public_digest
from receipts import input_digest


def _unlinked(path):
    path = Path(path).absolute()
    if any(part.is_symlink() for part in (path, *path.parents)):
        raise ValueError("linked preparation path")
    return path


def _git(actor, *args):
    result = subprocess.run(["git", "--git-dir", str(actor / ".git"), "--work-tree", str(actor),
        "-c", "core.hooksPath=/dev/null", "-c", "user.name=Public phase preparation",
        "-c", "user.email=public-phase@invalid", *args], cwd=actor, capture_output=True,
        text=True, timeout=30, env={"PATH": os.defpath, "HOME": str(actor),
            "LANG": "C.UTF-8", "GIT_CONFIG_GLOBAL": "/dev/null", "GIT_CONFIG_NOSYSTEM": "1"})
    if result.returncode not in (0, 1) or (result.returncode == 1 and args[:2] != ("diff", "--cached")):
        raise ValueError("owned public Git preparation failed: " + result.stderr)
    return result


def prepare_public_clone(source, out, config):
    """Return a physical clone bound to public source and the original raw guidance."""
    source, out = _unlinked(source), _unlinked(out)
    template = _unlinked(config["template"])
    if (not source.is_dir() or not template.is_dir() or out.exists() or
            any(out.is_relative_to(root) or root.is_relative_to(out) for root in (source, template))):
        raise ValueError("public clone paths overlap or are unavailable")
    excluded = set(TOOL_ROLES) | {"submission.json"}
    if any((source / name).exists() or (source / name).is_symlink() for name in excluded):
        raise ValueError("source contains host-excluded tool roles")
    template_digest = input_digest(template)
    source_digest = input_digest(source)
    knowledge = template / ".codescout"
    paths = config["knowledge_paths"]
    if (not (template / ".git").is_dir() or not knowledge.is_dir() or
            template_digest != config["template_sha256"] or
            not isinstance(paths, list) or not paths or
            input_digest(knowledge, paths) != config["knowledge_sha256"]):
        raise ValueError("frozen template or static onboarding changed")
    changed = _public_digest(template) != source_digest
    shutil.copytree(source, out, symlinks=True)
    shutil.copytree(template / ".git", out / ".git", symlinks=True)
    shutil.copytree(knowledge, out / ".codescout", symlinks=True)
    tracked = _git(out, "ls-files", "-z").stdout.split("\0")
    current = [path.relative_to(source).as_posix() for path in source.rglob("*")
               if path.is_file() or path.is_symlink()]
    selected = sorted(set(current) | {name for name in tracked if name and name.split("/")[0] not in excluded})
    if selected:
        _git(out, "add", "--all", "--force", "--", *selected)
    if _git(out, "diff", "--cached", "--quiet").returncode == 1:
        _git(out, "commit", "-qm", "Public phase input")
    head = _git(out, "rev-parse", "HEAD").stdout.strip()
    state_path = out / ".codescout/index-state.json"
    state = json.loads(state_path.read_bytes()) if state_path.is_file() else {}
    update = changed or state.get("last_indexed_commit") != head
    # Code chunks and memory retrieval share the SQLite directory. Preserve both
    # until the native incremental index binds the new public Git head.
    if (input_digest(source) != source_digest or _public_digest(out) != source_digest or
            input_digest(out / ".codescout", paths) != config["knowledge_sha256"] or
            input_digest(template) != template_digest):
        raise ValueError("public preparation inputs changed")
    return {"source": str(out), "source_sha256": source_digest, "baseline_commit": head,
            "knowledge_paths": list(paths), "knowledge_sha256": config["knowledge_sha256"],
            "onboarding_reused": True, "onboarding_author_calls": 0,
            "index_update_required": update, "derived_index_reset": False}
