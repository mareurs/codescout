"""Native composition contract; actual transport qualification is separate."""
import contextlib
import copy
import importlib
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parent))
import native_executor
from receipts import input_digest
try:
    campaign = importlib.import_module("campaign_native")
except ModuleNotFoundError as exc:
    if exc.name != "campaign_native":
        raise
    campaign = None


class NativeCompositionTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(campaign, "native campaign composition missing")
        self.temp = tempfile.TemporaryDirectory(prefix="native-compose-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / "public"
        self.source.mkdir()
        (self.source / "CLAUDE.md").write_text("public project rules")
        (self.source / "source.rs").write_text("pub fn value() -> u8 { 1 }\n")
        self.cli = self.root / "cli"
        self.cli.write_bytes(b"frozen CLI")
        self.rules = self.root / "rules"
        self.rules.write_text("public global rules")
        self.public = {"image": "sha256:" + "a"*64, "template": "unused-frozen-template",
            "runtime_manifest": "frozen-manifest", "runtime": {
                "files": {"cli": {"path": str(self.cli)}}, "plugin": {"path": "frozen-plugin"}},
            "global_rules": str(self.rules), "global_rules_sha256": campaign._sha(self.rules),
            "cli_checks": [{"id": "public-check", "command": "test -f CLAUDE.md"}],
            "timeout_s": 900, "check_timeout_s": 900, "embedding": {},
            "registered_readiness": {}, "execution_profile": "cargo-v2",
            "allowed_probe_prefixes": ["probes/"], "public_checks": [{"argv": ["public"]}],
            "command_timeout_s": 900, "max_log_bytes": 67108864, "lsp_warmup_retries": 1}
        self.request = {"invocation_id": "campaign::0::repair", "arm": "L", "phase": "repair",
            "source": str(self.source), "state": {"run_id": "run", "phase": "investigate",
                "turns_used": 0, "used_receipts": []},
            "allowance_usd": "3.00", "cli_cap_usd": "2.75", "max_continuations": 2,
            "public_packet": {"issue": "Public task", "prior_public_artifacts": []}}
        self.out = self.root / "invocation"
        self.out.mkdir()
        self.calls = []
        self.completed = True
        self.raise_after_actor = False
        self.clean = True
        owner = self

        class Backend:
            mode = "native"
            def __init__(self, prepared, capture, **kwargs):
                self.prepared, self.capture = prepared, capture
                owner.calls.append(("constructor", dict(kwargs)))
            def execute(self, packet):
                owner.calls.append(("actor", copy.deepcopy(packet)))
                native_executor._capture(Path(json.loads((self.prepared / "prepared.json").read_bytes())["actor"]), self.capture)
                result = {"source": str(self.capture), "cost_usd": "0.12", "cost_is_final": True,
                    "context_valid": True, "capture_complete": True, "cleanup_complete": True,
                    "turns": 1, "provider_forwarded": 0}
                (self.prepared / "started.json").write_text("{}")
                (self.prepared / "native-executor.json").write_text(json.dumps(result))
                (self.prepared / "receipt.json").write_text(json.dumps({
                    "cost_usd": "0.12", "unknown_provider_cost": False,
                    "workflow_completed": owner.completed, "context_valid": True,
                    "cleanup_error": None, "supervision_error": None,
                    "lifecycle": {"continuations": 0}}))
                if owner.raise_after_actor:
                    raise RuntimeError("after financial receipt")
                return result
        self.backend = Backend

    def prepare(self, source, actor, config):
        shutil.copytree(source, actor)
        (actor / ".codescout").mkdir()
        (actor / ".codescout/system-prompt.md").write_text("frozen raw guidance")
        return {"baseline_commit": "1"*40, "knowledge_paths": ["system-prompt.md"],
            "knowledge_sha256": "2"*64, "index_update_required": False}

    @contextlib.contextmanager
    def relay(self, out, image, config):
        try:
            yield {"network_id": "3"*64}
        finally:
            (out / "cleanup.json").write_text(json.dumps({"complete": self.clean}))
            if not self.clean:
                raise ValueError("owned relay cleanup failed")

    def protocol(self, request, backend):
        self.calls.append(("phase", copy.deepcopy(request)))
        returned = backend.execute({"arm": request["arm"], "prompt": "protocol prompt",
            "public_packet": request["public_packet"], "allowance_usd": request["phase_budget_usd"],
            "cli_cap_usd": request["cli_cap_usd"], "max_continuations": 2})
        folder = Path(request["out"])
        folder.mkdir()
        shutil.copytree(returned["source"], folder / "candidate")
        state = copy.deepcopy(request["state"])
        state.update(phase="repair", source_digest=input_digest(folder/"candidate"), turns_used=1)
        return {"state": state, "cost": {"known_usd": "0.12", "unknown": False},
            "measurement_invalid": False, "public_artifact": {"public": "observation"}}

    def invoke(self, **kwargs):
        with patch.multiple(campaign, prepare_public_clone=self.prepare, embedding_runtime=self.relay,
                _runtime=lambda value: self.public["runtime"], _runtime_inputs=lambda value: value,
                _native_argv=lambda *args: ["docker","run","--name","placeholder","--label","placeholder",
                    "--network","none","--tmpfs","placeholder","--init","--entrypoint","/bench/bin/codescout",
                    self.public["image"],"start","--project","/testbed"],
                _readiness=lambda *args: {"expected": {}, "wire": {}},
                validate_embedding_profile=lambda *args: {"ready": True}, NativeExecutor=self.backend,
                run_phase=self.protocol, _admit_backend=lambda *args: None):
            return campaign.invoke_native(self.request, self.out, self.public, mode="scripted",
                                          scripted_plan=[], **kwargs)

    def test_low_and_xhigh_use_the_native_boundary_and_final_receipt(self):
        for arm in ("L", "X"):
            with self.subTest(arm=arm):
                self.request["arm"] = arm
                self.request["invocation_id"] = "campaign::" + arm
                self.out = self.root / arm
                self.out.mkdir()
                result = self.invoke()
                self.assertEqual(result["state"]["phase"], "closed")
                self.assertEqual(result["cost_usd"], "0.12")
                self.assertTrue(result["cost_is_final"])
                self.assertEqual(result["turns"], 1)
                self.assertFalse(result["measurement_invalid"])
                self.assertEqual(json.loads((self.out/"invocation.json").read_bytes()), result)
                actor = [packet for kind, packet in self.calls if kind == "actor"][-1]
                self.assertEqual(actor["arm"], arm)
                self.assertEqual(actor["cli_cap_usd"], "2.75")
                self.assertEqual(actor["prompt"], "Public task")
                self.assertNotIn("submission", actor["prompt"])

    def test_ordinary_unfinished_workflow_is_kept_and_counted(self):
        self.completed = False
        result = self.invoke()
        self.assertEqual(result["state"]["phase"], "incomplete")
        self.assertFalse(result["measurement_invalid"])
        self.assertEqual(result["cost_usd"], "0.12")
        self.assertTrue(Path(result["candidate"]).is_dir())

    def test_protocol_uses_host_adapter_and_public_configuration(self):
        self.request.update(arm="P", phase="investigate", allowance_usd="0.60", cli_cap_usd="0.55")
        self.request["state"]["phase"] = "investigate"
        result = self.invoke()
        phase = [packet for kind, packet in self.calls if kind == "phase"][0]
        self.assertEqual(phase["phase_budget_usd"], "0.60")
        self.assertEqual(phase["cli_cap_usd"], "0.55")
        self.assertEqual(phase["allowed_probe_prefixes"], ["probes/"])
        self.assertEqual(phase["command_timeout_s"], 900)
        self.assertNotIn("private", phase)
        self.assertEqual(result["public_artifact"], {"public": "observation"})
        self.assertEqual(result["state"]["phase"], "repair")
    def test_later_phase_captures_against_frozen_task_base_not_phase_input_head(self):
        self.public['capture_base_commit'] = '9'*40
        self.request.update(arm='P', phase='repair', allowance_usd='1.80', cli_cap_usd='1.65')
        self.request['state']['phase'] = 'repair'
        self.invoke()
        prepared = json.loads((self.out/'native/prepared.json').read_bytes())
        readiness = json.loads((self.out/'native/readiness/registration.json').read_bytes())
        self.assertEqual(prepared['baseline_commit'], '9'*40)
        self.assertEqual(readiness['baseline_commit'], '1'*40)

    def test_exception_after_actor_or_runtime_cleanup_keeps_the_settled_charge(self):
        self.raise_after_actor = True
        result = self.invoke()
        self.assertTrue(result["measurement_invalid"])
        self.assertEqual(result["cost_usd"], "0.12")
        self.assertTrue(result["cost_is_final"])
        self.assertTrue(Path(result["candidate"]).is_dir())

    def test_owned_runtime_cleanup_failure_never_becomes_valid(self):
        self.clean = False
        result = self.invoke()
        self.assertTrue(result["measurement_invalid"])
        self.assertFalse(result["cleanup_complete"])
        self.assertEqual(result["cost_usd"], "0.12")
        self.assertTrue(result["cost_is_final"])

    def test_scripted_mode_refuses_real_credential_path_before_effects(self):
        with self.assertRaises(ValueError):
            self.invoke(token_path=self.root / "must-not-read")
        self.assertEqual(self.calls, [])
        self.assertFalse((self.out / "native").exists())

    def test_disk_campaign_root_is_admitted_and_resource_probe_uses_its_filesystem(self):
        with tempfile.TemporaryDirectory(prefix="ep-compose-", dir="/var/tmp") as temp:
            self.out = Path(temp) / "invocation"
            self.out.mkdir()
            with patch.object(campaign, "ResourceSupervisor") as supervisor:
                result = self.invoke()
            self.assertFalse(result["measurement_invalid"])
            self.assertEqual(Path(supervisor.call_args.kwargs["temporary"]), self.out)
            self.assertEqual(Path(result["native_path"]).parent, self.out)

    def test_preparation_failure_preserves_a_zero_call_source_outcome(self):
        self.public["global_rules_sha256"] = "0"*64
        result = self.invoke()
        self.assertTrue(result["measurement_invalid"])
        self.assertEqual(result["cost_usd"], "0")
        self.assertTrue(result["cost_is_final"])
        self.assertEqual(result["actor_started"], False)
        self.assertEqual([kind for kind, packet in self.calls if kind=="actor"], [])
    def test_corrupt_terminal_file_keeps_other_settled_financial_evidence(self):
        execute = self.backend.execute
        def corrupt(backend, packet):
            result = execute(backend, packet)
            (backend.prepared / "receipt.json").write_text("{bad-json")
            return result
        with patch.object(self.backend, "execute", corrupt):
            result = self.invoke()
        self.assertTrue(result["measurement_invalid"])
        self.assertEqual(result["cost_usd"], "0.12")
        self.assertTrue(result["cost_is_final"])
        self.assertTrue((self.out / "invocation.json").is_file())

    def test_missing_post_actor_capture_never_substitutes_baseline_as_valid(self):
        execute = self.backend.execute
        def remove_capture(backend, packet):
            result = execute(backend, packet)
            shutil.rmtree(backend.capture)
            return result
        with patch.object(self.backend, "execute", remove_capture):
            result = self.invoke()
        self.assertTrue(result["measurement_invalid"])
        self.assertFalse(result["capture_complete"])
        self.assertEqual(result["cost_usd"], "0.12")

    def test_actual_adapter_counts_the_turn_of_a_malformed_submission(self):
        import test_adapter as fixtures
        fixture = fixtures.AdapterTests("test_malformed_submission_is_not_a_paid_retry")
        fixture.setUp()
        self.addCleanup(fixture.doCleanups)
        fixture.actor.submission = None
        before = fixture.state["turns_used"]
        result = fixtures.adapter.run_phase(fixture.request, fixture.actor)
        self.assertEqual(result["state"]["phase"], "incomplete")
        self.assertFalse(result["measurement_invalid"])
        self.assertEqual(result["state"]["turns_used"], before + fixture.actor.turns)


if __name__ == "__main__":
    unittest.main()
