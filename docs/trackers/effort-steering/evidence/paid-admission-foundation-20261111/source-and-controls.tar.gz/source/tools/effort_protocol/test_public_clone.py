"""Clone frozen onboarding once; isolate changed-source index state."""
import importlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).parent))
import receipts
import native_executor
try:
    clone = importlib.import_module("public_clone")
except ModuleNotFoundError as exc:
    if exc.name != "public_clone":
        raise
    clone = None


class PublicCloneTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(clone, "public clone preparation missing")
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.template = self.root / "template"
        self.template.mkdir()
        (self.template / "source.rs").write_text("pub fn public_value() -> u8 { 1 }\n")
        (self.template / "CLAUDE.md").write_text("Public project rules\n")
        subprocess.run(["git", "init", "-q", str(self.template)], check=True)
        subprocess.run(["git", "-C", str(self.template), "add", "--", "source.rs", "CLAUDE.md"], check=True)
        subprocess.run(["git", "-C", str(self.template), "-c", "core.hooksPath=/dev/null",
            "-c", "user.name=Fixture", "-c", "user.email=fixture@invalid",
            "commit", "-qm", "Public source"], check=True)
        self.head = subprocess.check_output(["git", "-C", str(self.template), "rev-parse", "HEAD"], text=True).strip()
        knowledge = self.template / ".codescout"
        (knowledge / "memories").mkdir(parents=True)
        (knowledge / "embeddings").mkdir()
        (knowledge / "project.toml").write_text('languages = ["rust"]\n')
        (knowledge / "system-prompt.md").write_text("Raw public project guidance\n")
        (knowledge / "memories/raw-readme.md").write_bytes(b"# Original public documentation\n")
        (knowledge / "embeddings/testbed.db").write_bytes(b"frozen-derived-cache")
        (knowledge / "index-state.json").write_text(json.dumps({"last_indexed_commit": self.head}))
        self.static = ["project.toml", "system-prompt.md", "memories/raw-readme.md"]
        self.source = self.root / "source"
        native_executor._capture(self.template, self.source)
        self.config = {"template": str(self.template),
            "template_sha256": receipts.input_digest(self.template),
            "knowledge_paths": self.static,
            "knowledge_sha256": receipts.input_digest(knowledge, self.static)}
        self.out = self.root / "actor"

    def prepare(self):
        return clone.prepare_public_clone(self.source, self.out, self.config)

    def test_unchanged_source_reuses_exact_static_guidance_and_index(self):
        before = receipts.input_digest(self.template)
        result = self.prepare()
        self.assertEqual(result["source_sha256"], receipts.input_digest(self.source))
        self.assertEqual(result["baseline_commit"], self.head)
        self.assertFalse(result["index_update_required"])
        self.assertEqual(result["onboarding_author_calls"], 0)
        self.assertEqual((self.out / ".codescout/embeddings/testbed.db").read_bytes(), b"frozen-derived-cache")
        self.assertEqual(receipts.input_digest(self.out / ".codescout", self.static),
                         self.config["knowledge_sha256"])
        self.assertEqual(receipts.input_digest(self.template), before)
        self.assertEqual(native_executor._public_digest(self.out), receipts.input_digest(self.source))

    def test_changed_source_preserves_the_shared_retrieval_store_bytes(self):
        (self.source / "source.rs").write_text("pub fn public_value() -> u8 { 2 }\n")
        cached = (self.template / ".codescout/embeddings/testbed.db").read_bytes()
        result = self.prepare()
        self.assertTrue(result["index_update_required"])
        self.assertTrue((self.out / ".codescout/embeddings/testbed.db").is_file())
        self.assertEqual((self.out / ".codescout/embeddings/testbed.db").read_bytes(), cached)
        self.assertEqual((self.out / ".codescout/index-state.json").read_bytes(),
                         (self.template / ".codescout/index-state.json").read_bytes())

    def test_changed_source_reuses_onboarding_and_requires_code_index_update(self):
        (self.source / "source.rs").write_text("pub fn public_value() -> u8 { 2 }\n")
        before = receipts.input_digest(self.template)
        result = self.prepare()
        self.assertTrue(result["index_update_required"])
        self.assertNotEqual(result["baseline_commit"], self.head)
        self.assertTrue((self.out / ".codescout/embeddings").is_dir())
        self.assertFalse(result["derived_index_reset"])
        self.assertTrue((self.out / ".codescout/index-state.json").is_file())
        self.assertEqual(receipts.input_digest(self.out / ".codescout", self.static),
                         self.config["knowledge_sha256"])
        self.assertEqual(receipts.input_digest(self.template), before)
        self.assertEqual((self.out / "source.rs").read_bytes(), (self.source / "source.rs").read_bytes())
        tracked = subprocess.check_output(["git", "-C", str(self.out), "show", "HEAD:source.rs"])
        self.assertEqual(tracked, (self.source / "source.rs").read_bytes())

    def test_deleted_source_and_new_probe_are_reflected_in_owned_git_seed(self):
        (self.source / "source.rs").unlink()
        (self.source / "probes").mkdir()
        (self.source / "probes/standalone.py").write_text("print('public observation')\n")
        result = self.prepare()
        self.assertTrue(result["index_update_required"])
        names = subprocess.check_output(["git", "-C", str(self.out), "ls-tree", "-r", "--name-only", "HEAD"], text=True).splitlines()
        self.assertNotIn("source.rs", names)
        self.assertIn("probes/standalone.py", names)
        self.assertNotIn(".codescout/project.toml", names)
        self.assertEqual(native_executor._public_digest(self.out), receipts.input_digest(self.source))

    def test_input_tool_roles_are_refused_before_output(self):
        for name in (".git", ".codescout", ".buddy", ".claude", ".superpowers",
                     "target", "node_modules", "submission.json"):
            with self.subTest(name=name):
                path = self.source / name
                path.mkdir()
                with self.assertRaises(ValueError):
                    self.prepare()
                self.assertFalse(self.out.exists())
                path.rmdir()

    def test_template_and_static_knowledge_drift_refuse_before_output(self):
        (self.template / ".codescout/memories/raw-readme.md").write_text("different")
        with self.assertRaises(ValueError):
            self.prepare()
        self.assertFalse(self.out.exists())
        self.config["template_sha256"] = receipts.input_digest(self.template)
        with self.assertRaises(ValueError):
            self.prepare()
        self.assertFalse(self.out.exists())

    def test_existing_or_overlapping_destination_refuses_without_changes(self):
        before = receipts.input_digest(self.source)
        self.out = self.source / "nested"
        with self.assertRaises(ValueError):
            self.prepare()
        self.assertEqual(receipts.input_digest(self.source), before)
        self.out = self.root / "occupied"
        self.out.mkdir()
        (self.out / "keep").write_text("keep")
        with self.assertRaises(ValueError):
            self.prepare()
        self.assertEqual((self.out / "keep").read_text(), "keep")

    def test_stale_baseline_commit_requires_update_without_new_authoring(self):
        path = self.template / ".codescout/index-state.json"
        path.write_text(json.dumps({"last_indexed_commit": "0" * 40}))
        self.config["template_sha256"] = receipts.input_digest(self.template)
        result = self.prepare()
        self.assertTrue(result["index_update_required"])
        self.assertEqual(result["baseline_commit"], self.head)
        self.assertEqual(result["onboarding_author_calls"], 0)

    def test_linked_template_or_source_does_not_escape_registered_root(self):
        alias = self.root / "alias"
        alias.symlink_to(self.template, target_is_directory=True)
        self.config["template"] = str(alias)
        with self.assertRaises(ValueError):
            self.prepare()
        self.assertFalse(self.out.exists())


if __name__ == "__main__":
    unittest.main()
