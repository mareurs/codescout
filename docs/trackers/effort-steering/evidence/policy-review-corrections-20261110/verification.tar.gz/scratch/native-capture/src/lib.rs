
#[test]
fn selected_pass() {}
#[test]
fn captured_stderr() {
    eprintln!("error[E0308]: mismatched types\n --> tests/ui/x.rs:3:5");
    eprintln!("write failed: No space left on device");
    eprintln!("open /tmp/fixture.txt: Permission denied");
    eprintln!("rustc: fatal error: terminated with signal 9");
    panic!("controlled unselected test failure");
}
