extern "C" { fn policy_missing_link_symbol(); }
fn main() { unsafe { policy_missing_link_symbol(); } }
