"""Apply the peer's actual mutations on independent source copies; retain every log."""
import argparse
import ast
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

CATALOG = Path("/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/"
               "b3485581-2540-4da8-a440-3bed2e9c517f/scratchpad/probes/mutate.py")


def read_mutants():
    tree = ast.parse(CATALOG.read_text())
    node = next(n.value for n in tree.body if isinstance(n, ast.Assign)
                and any(isinstance(t, ast.Name) and t.id == "M" for t in n.targets))

    class Names(ast.NodeTransformer):
        def visit_Name(self, value):
            return ast.copy_location(ast.Constant(
                {"GP": "grade_policy.py", "GT": "multilang_tasks.py"}[value.id]), value)

    return ast.literal_eval(Names().visit(node))


def test_snapshot(root, tests, log):
    cmd = [sys.executable, "-P", "-m", "pytest", "-q", "-x", "-p", "no:cacheprovider", *tests]
    try:
        result = subprocess.run(cmd, cwd=root, capture_output=True, text=True, timeout=90)
        output = result.stdout + "\n--- STDERR ---\n" + result.stderr
        log.write_text(output)
        if result.returncode == 0:
            outcome = "survived"
        elif result.returncode == 1 and " failed" in result.stdout and " ERROR " not in result.stdout:
            outcome = "killed"
        else:
            outcome = "invalid"
        return {"outcome": outcome, "exit_code": result.returncode,
                "summary": result.stdout.strip().splitlines()[-1:] or [""],
                "argv": cmd, "log": str(log)}
    except subprocess.TimeoutExpired as exc:
        log.write_text(str(exc))
        return {"outcome": "invalid", "reason": "timeout", "log": str(log)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("workspace", type=Path)
    parser.add_argument("label")
    parser.add_argument("--ref")
    parser.add_argument("--overrides", type=Path)
    parser.add_argument("--extra", type=Path)
    parser.add_argument("--select", nargs="+")
    args = parser.parse_args()
    out = Path(__file__).parent / ("mutations-" + args.label)
    out.mkdir(exist_ok=False)
    snapshot = out / "snapshot"
    snapshot.mkdir()
    listing = (["ls-tree", "-r", "--name-only", args.ref, "--", "tools/setup-ab-eval"]
               if args.ref else ["ls-files", "--", "tools/setup-ab-eval"])
    paths = subprocess.check_output(["git", "-C", str(args.workspace), *listing],
                                    text=True).splitlines()
    hashes = {}
    for relative in paths:
        if args.ref:
            data = subprocess.check_output(["git", "-C", str(args.workspace),
                                             "show", args.ref + ":" + relative])
        else:
            data = (args.workspace / relative).read_bytes()
        dest = snapshot / Path(relative).relative_to("tools/setup-ab-eval")
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        hashes[relative] = hashlib.sha256(data).hexdigest()
    (out / "source-hashes.json").write_text(json.dumps(hashes, indent=2) + "\n")
    groups = [["test_grade_policy.py"], ["test_multilang_tasks.py", "test_run.py"]]
    for i, tests in enumerate(groups):
        baseline = test_snapshot(snapshot, tests, out / ("baseline-" + str(i) + ".log"))
        assert baseline["outcome"] == "survived", baseline
    mutants = read_mutants()
    if args.extra:
        mutants += json.loads(args.extra.read_text())
    if args.select:
        mutants = [m for m in mutants if m[0].split()[0] in args.select]
        assert {m[0].split()[0] for m in mutants} == set(args.select)
    overrides = json.loads(args.overrides.read_text()) if args.overrides else {}

    def one(item):
        name, filename, before, after = item
        if name in overrides:
            before, after = overrides[name]
        with tempfile.TemporaryDirectory(prefix="isolated-", dir=out) as temp:
            target = Path(temp)
            shutil.copytree(snapshot, target, dirs_exist_ok=True,
                            ignore=shutil.ignore_patterns("__pycache__", ".pytest_cache"))
            file = target / filename
            text = file.read_text()
            count = text.count(before)
            row = {"name": name, "file": filename, "before": before, "after": after,
                   "pattern_count": count}
            if count != 1:
                row.update(outcome="not_applied", reason="pattern count is not one")
                return row
            changed = text.replace(before, after)
            try:
                ast.parse(changed)
            except SyntaxError as exc:
                row.update(outcome="invalid", reason=str(exc))
                return row
            file.write_text(changed)
            short = name.split()[0].replace("/", "_")
            tests = groups[0] if filename == "grade_policy.py" else groups[1]
            row.update(test_snapshot(target, tests, out / (short + ".log")))
            return row

    results = []
    with ThreadPoolExecutor(max_workers=4) as pool:
        for result in pool.map(one, mutants):
            results.append(result)
            print(result["name"], result["outcome"], result.get("summary", []), flush=True)
    receipt = {"catalog_sha256": hashlib.sha256(CATALOG.read_bytes()).hexdigest(),
               "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               "source_ref": args.ref, "label": args.label,
               "counts": dict(Counter(r["outcome"] for r in results)), "results": results}
    (out / "results.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt["counts"]), flush=True)


if __name__ == "__main__":
    main()
