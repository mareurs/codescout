"""Characterize installed nextest streams using a disposable dependency-free crate."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path(__file__).parent / "native-capture"
root.mkdir(exist_ok=False)
(root / "src").mkdir()
(root / "Cargo.toml").write_text(
    '[package]\nname="policy_capture_probe"\nversion="0.1.0"\nedition="2021"\n')
(root / "src/lib.rs").write_text(r'''
#[test]
fn selected_pass() {}
#[test]
fn captured_stderr() {
    eprintln!("error[E0308]: mismatched types\n --> tests/ui/x.rs:3:5");
    eprintln!("write failed: No space left on device");
    eprintln!("open /tmp/fixture.txt: Permission denied");
    eprintln!("rustc: fatal error: terminated with signal 9");
    panic!("controlled unselected test failure");
}
''')
argv = ["cargo", "nextest", "run", "--offline", "--message-format", "libtest-json-plus",
        "--failure-output", "immediate-final", "--color", "never"]
env = dict(os.environ, CARGO_TARGET_DIR=str(root / "target"),
           NEXTEST_EXPERIMENTAL_LIBTEST_JSON="1")
done = subprocess.run(argv, cwd=root, env=env, capture_output=True, timeout=90)
(root / "stdout.jsonl").write_bytes(done.stdout)
(root / "stderr.log").write_bytes(done.stderr)
receipt = {"argv": argv, "returncode": done.returncode,
           "version": subprocess.check_output(["cargo", "nextest", "--version"], text=True).strip(),
           "stdout_sha256": hashlib.sha256(done.stdout).hexdigest(),
           "stderr_sha256": hashlib.sha256(done.stderr).hexdigest()}
(root / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
print("--- actual stderr ---")
print(done.stderr.decode(errors="replace"))
print("--- actual stdout ---")
print(done.stdout.decode(errors="replace"))
