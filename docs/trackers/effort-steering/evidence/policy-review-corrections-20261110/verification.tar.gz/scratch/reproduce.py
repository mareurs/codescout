"""Deterministic review reproductions; no model, Docker or private candidate."""
import base64
import copy
import json
from pathlib import Path
import sys

sys.path.insert(0, sys.argv[1])
import grade_policy as policy
import multilang_control as control
import test_grade_policy as data

MISSING = object()


def observe(name, log, *, tail=None, raw=MISSING, record=MISSING, rebuild=False):
    original, full = data.fixture(log)
    full["steps"][0]["returncode"] = 101
    if tail is not None:
        full["steps"][0]["tail"] = tail
    if rebuild:
        full["steps"].insert(0, {"name": "grade:rebuild", "returncode": 101, "tail": tail})
        full["steps"][1].update(returncode=0, tail="")
    supplied_raw = original if raw is MISSING else raw
    supplied_record = data.RECORD if record is MISSING else record
    row = {"name": name, "log": log, "raw": supplied_raw, "record": supplied_record,
           "full_evidence": copy.deepcopy(full), "runtime": data.OK}
    try:
        row["result"] = policy.adjudicate_private(
            supplied_raw, full, supplied_record, data.BUNDLE, log=log, runtime=data.OK)
    except Exception as exc:
        row["exception"] = {"type": type(exc).__name__, "message": str(exc)}
    return row


def main():
    out = Path(__file__).parent / ("reproductions-" + sys.argv[2] + ".json")
    assert not out.exists(), out
    rows = []
    nextest = ("    FAIL [   0.010s] crate::ui trybuild_ui\n"
               "--- STDERR:              crate::ui trybuild_ui ---\n"
               "error[E0308]: mismatched types\n --> tests/ui/x.rs:3:5\n")
    rows.append(observe("F1-nextest-review-fixture", data.PASS_LOG, tail=nextest))
    header = "---- unselected stdout ----\n"
    suffix = ("error[E0425]: captured diagnostic\n --> tests/ui/x.rs:3:5\n"
              "failures:\n    unselected\n"
              "test result: FAILED. 2 passed; 1 failed; 0 ignored; 0 measured; 0 filtered out\n")
    # Place a two-byte Unicode character across the real last-4096-byte boundary.
    rest = "\n" + suffix
    padding = "x" * (4095 - len(rest.encode()))
    log = data.PASS_LOG + header + "é" + padding + rest
    tail = control._decode_tail(base64.b64encode(log.encode()).decode())
    assert len(log.encode()) > 4096 and tail.startswith("\ufffd") and not log.endswith(tail)
    rows.append(observe("F1-real-4096-byte-decoder-cut", log, tail=tail))
    for text in ("write failed: No space left on device",
                 "open /tmp/fixture.txt: Permission denied",
                 "rustc: fatal error: terminated with signal 9"):
        captured = header + text + "\ntest result: FAILED. 1 passed; 1 failed; 0 ignored\n"
        rows.append(observe("F2-captured-" + text, data.FAIL_LOG + captured, tail=captured))
    for value in (None, "x", []):
        rows.append(observe("F4-raw-" + repr(value), data.PASS_LOG, raw=value))
    rows.append(observe("F4-record-list", data.PASS_LOG, record=[]))
    rows.append(observe("F5-rebuild-None", data.PASS_LOG,
                        record=dict(data.RECORD, rebuild_cmds=None)))
    linker = ("error: linking with `cc` failed: exit status: 1\n"
              "  = note: /usr/bin/ld: undefined reference to `foo'\n"
              "          collect2: error: ld returned 1 exit status\n")
    rows.append(observe("F6-linker-review-fixture", data.PASS_LOG, tail=linker,
                        rebuild=True, record=dict(data.RECORD, rebuild_cmds=["cargo build"])))
    out.write_text(json.dumps({"source": str(Path(sys.argv[1]).resolve()),
                               "policy_version": policy.POLICY_VERSION, "cases": rows},
                              indent=2) + "\n")
    for row in rows:
        result = row.get("result", row.get("exception"))
        print(row["name"], "=>", {k: result[k] for k in
              ("valid", "pass", "kind", "error", "type", "message") if k in result})
    print("saved", out)


if __name__ == "__main__":
    main()
