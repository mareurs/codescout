import sys, shutil, subprocess, tempfile, os
from concurrent.futures import ThreadPoolExecutor
SRC = sys.argv[1]
GP, GT = "grade_policy.py", "multilang_tasks.py"
M = [
 ("M1 cgroup_probes <2 -> <1", GP, 'runtime["cgroup_probes"] < 2', 'runtime["cgroup_probes"] < 1'),
 ("M2 drop runtime errors check", GP, 'if runtime.get("errors") != []:', 'if False:'),
 ("M3 drop gutter filter", GP, 'if not re.match(r"^\\s*(?:\\d+\\s*\\||\\|)", line)]', 'if True]'),
 ("M4 drop toolchain signal", GP, '    if signal:\n', '    if False:\n'),
 ("M5 drop storage check", GP, 'if re.search(r"(?:^|:\\s)(?:No space', 'if False and re.search(r"(?:^|:\\s)(?:No space'),
 ("M6 drop /tmp perm check", GP, 'if re.search(r"(?:^|\\s)/tmp/', 'if False and re.search(r"(?:^|\\s)/tmp/'),
 ("M7 drop capture scoping", GP, '            test_output = True\n            continue', '            continue'),
 ("M8 drop post-capture raise", GP, '            if after_capture:\n', '            if False:\n'),
 ("M9 error: needs no context", GP, 're.match(r"^error: ", line) and any(', 're.match(r"^error: ", line) and True or any('),
 ("M10 rebuild uses log too", GP, '        return compiler_diagnostic(tail) is not None\n    normalized_log', '        return compiler_diagnostic(tail) is not None or compiler_diagnostic(log) is not None\n    normalized_log'),
 ("M11 drop suffix branch", GP, 'if normalized_tail and normalized_log.endswith(normalized_tail):', 'if False:'),
 ("M11b suffix branch: tail only", GP, '    return compiler_diagnostic(tail) is not None or compiler_diagnostic(log) is not None\n\n', '    return compiler_diagnostic(tail) is not None\n\n'),
 ("M12 public drop exit<0", GP, 'type(exit_code) is not int or exit_code < 0', 'type(exit_code) is not int'),
 ("M13 public drop truncated", GP, 'if issue or truncated or', 'if issue or'),
 ("M14 drop oom_killed check", GP, 'or raw.get("oom_killed") is not False', ''),
 ("M15 drop container_removed", GP, 'or raw.get("container_removed") is not True', ''),
 ("M16 drop raw infra check", GP, '\n                or raw.get("infra") is not None)', ')'),
 ("M17 drop step order check", GP, 'or [s["name"] for s in steps] != expected_steps', ''),
 ("M18 drop print rc check", GP, 'if step["name"].startswith("grade:print[") and code != 0:', 'if False:'),
 ("M19 drop step truncated", GP, 'code < 0 or step.get("truncated")', 'code < 0'),
 ("M20 infra on log only", GP, 'issue = infrastructure_issue(combined)', 'issue = infrastructure_issue(log)'),
 ("M21 drop dup expected check", GP, 'if not f2p or len(set(expected)) != len(expected):', 'if not f2p:'),
 ("M22 drop empty f2p check", GP, 'if not f2p or len(set(expected)) != len(expected):', 'if len(set(expected)) != len(expected):'),
 ("M23 drop raw-vs-parser check", GP, 'if (type(raw.get(key)) is not type(value) or raw.get(key) != value\n                    or full_evidence.get(key) != value):', 'if False:'),
 ("M24 drop full_evidence check", GP, '\n                    or full_evidence.get(key) != value):', '):'),
 ("M25 drop audit original check", GP, 'if result["original"] != original:', 'if False:'),
 ("M26 drop recovered adjust", GP, 'adjusted[recovered["key"]] = recovered["status"]', 'pass'),
 ("M27 drop unknown status check", GP, 'if any(value not in ("pass", "fail", "skip") for value in statuses.values()):', 'if False:'),
 ("M28 drop unknown_rebuild", GP, '        if unknown_rebuild:\n', '        if False:\n'),
 ("M29 drop missing check", GP, 'if result["adjusted"]["missing"] and not compile_failure:', 'if False:'),
 ("M30 compile_failure not failing", GP, 'passed = result["adjusted"]["pass"] and not compile_failure', 'passed = result["adjusted"]["pass"]'),
 ("M32 compile_failure ignores rc", GP, 'step["returncode"] != 0 and step_compiler_failure(step, log)', 'step_compiler_failure(step, log)'),
 ("M33 storage regex no $ anchor", GP, '(?: \\(os error \\d+\\))?$", line)', '(?: \\(os error \\d+\\))?", line)'),
 ("M34 drop cgroup type check", GP, 'type(runtime.get("cgroup_probes")) is not int or ', ''),
 ("M36 drop raw pass bool check", GP, 'if (type(raw.get("pass")) is not bool or raw.get("oom_killed")', 'if (raw.get("oom_killed")'),
 ("M37 capture ends only on ok", GP, '(?:ok|FAILED)\\. \\d+ passed', '(?:ok)\\. \\d+ passed'),
 ("M39 private drop runtime check", GP, '    issue = runtime_issue(runtime)\n    if issue:\n        return invalid(issue, raw)', '    pass'),
 ("M40 drop step code<0", GP, 'if type(code) is not int or code < 0 or', 'if type(code) is not int or'),
 ("M41 drop step code type", GP, 'if type(code) is not int or code < 0 or', 'if code < 0 or'),
 ("M42 drop tail type check", GP, 'if not isinstance(step.get("tail"), str):', 'if False:'),
 ("M43 empty-tail-not-falsy", GP, 'if normalized_tail and normalized_log', 'if normalized_log'),
 ("M44 drop oom_kill check", GP, 'or runtime["oom_kill"] != 0', ''),
 ("M45 drop error[E] header", GP, 'diagnostic = re.match(r"^error\\[E\\d+\\]: ", line) or (', 'diagnostic = None or ('),
 ("M46 rebuild expected even if blank", GP, 'isinstance(cmd, str) and cmd.strip()', 'True'),
 ("G1 glue: crash flagged even with statuses", GT, 'if not statuses and (crash := grade.toolchain_crash(log)):', 'if (crash := grade.toolchain_crash(log)):'),
 ("G2 glue removed", GT, 'if not statuses and (crash := grade.toolchain_crash(log)):', 'if False and (crash := grade.toolchain_crash(log)):'),
 ("G3 glue no error key", GT, ',\n                                   "error": f"toolchain crash with no parsed test statuses: {crash}"', ''),
 ("G4 glue pass not forced False", GT, 'result.update({"pass": False, "infra": "toolchain_crash",', 'result.update({"infra": "toolchain_crash",'),
]
def one(m):
    name, f, old, new = m
    d = tempfile.mkdtemp(dir=os.path.dirname(__file__))
    shutil.copytree(SRC, d, dirs_exist_ok=True)
    p = os.path.join(d, f); s = open(p).read()
    n = s.count(old)
    if n != 1: return f"{name}: PATTERN COUNT {n}"
    open(p, "w").write(s.replace(old, new))
    tests = ["test_grade_policy.py"] if f == GP else ["test_multilang_tasks.py", "test_run.py"]
    r = subprocess.run([sys.executable, "-P", "-m", "pytest", "-q", "-x", "-p", "no:cacheprovider", *tests], cwd=d, capture_output=True, text=True)
    shutil.rmtree(d)
    last = (r.stdout.strip().splitlines() or ["?"])[-1]
    return f"{name}: {'KILLED' if r.returncode else 'SURVIVED'} ({last})"
with ThreadPoolExecutor(8) as ex:
    for line in ex.map(one, M): print(line)
