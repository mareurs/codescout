import sys, copy
sys.path.insert(0, sys.argv[1])
import test_grade_policy as T
import grade_policy as P
import multilang_grade as G

def run(label, log, steps_mut=None, raw=None, record=None):
    r, full = T.fixture(log)
    if steps_mut: steps_mut(full)
    try:
        res = P.adjudicate_private(r if raw is None else raw, full, record or T.RECORD, T.BUNDLE, log=log, runtime=T.OK)
        print(label, "->", {k: res.get(k) for k in ("valid","pass","kind","error")})
    except Exception as e:
        print(label, "-> EXC", type(e).__name__, e)

CAP = "---- f stdout ----\n{}\nfailures:\n    f\ntest result: FAILED. 1 passed; 1 failed; 0 ignored; 0 measured; 0 filtered out\n"
def rc101(full): full["steps"][0]["returncode"] = 101
# P1 captured test data mentioning storage / tmp perms / toolchain signal on a real selected failure
for s in ("write failed: No space left on device", "open /tmp/fixture.txt: Permission denied",
          "rustc: fatal error: terminated with signal 9"):
    run("P1 FAIL_LOG+captured %r" % s, T.FAIL_LOG + CAP.format(s), rc101)
# P2 selected test binary aborts (candidate stack overflow) -> missing status
crash = ("Running tests/main.rs (bin)\ntest p ... ok\n\nthread 'f' has overflowed its stack\nfatal runtime error: stack overflow\n"
         "error: test failed, to rerun pass `--test main`\n\nCaused by:\n  process didn't exit successfully: `/w/target/debug/deps/main-1a2b` (signal: 6, SIGABRT: process abort signal)\n")
run("P2 test-binary abort, f missing", crash, rc101)
run("P2b selected test deleted by candidate", "Running tests/main.rs (bin)\ntest p ... ok\n", None)
# P3 non-dict raw
for bad in (None, "x", []):
    run("P3 raw=%r" % (bad,), T.PASS_LOG, None, raw=bad)
# P4 rebuild linker failure
def link(full):
    full["steps"].insert(0, {"name": "grade:rebuild", "returncode": 101, "tail":
      "error: linking with `cc` failed: exit status: 1\n  |\n  = note: \"cc\" \"-m64\" ...\n  = note: /usr/bin/ld: undefined reference to `foo'\n          collect2: error: ld returned 1 exit status\n\nerror: could not compile `x` (bin \"x\") due to 1 previous error\n"})
run("P4 rebuild linker failure", T.PASS_LOG, link, record=dict(T.RECORD, rebuild_cmds=["cargo build"]))
# P5 tail not exact suffix (utf-8 cut replaced by U+FFFD), headerless captured diagnostic
diag = "error[E0425]: cannot find value missing in this scope\n --> crates/u.rs:1:1\n  |\n1 | missing\n"
log = (T.PASS_LOG + "test crates/u.rs - u (line 1) ... FAILED\n---- crates/u.rs - u (line 1) stdout ----\n"
       "─── note\n" + diag +
       "failures:\n    u\ntest result: FAILED. 2 passed; 1 failed; 0 ignored; 0 measured; 0 filtered out\n")
idx = log.index("─── note")
tail_exact = log[idx:]
tail_cut = "�" + log[idx+1:]   # byte tail cut mid-char then decoded with replacement
def t(tail):
    def m(full): full["steps"][0].update(returncode=101, tail=tail)
    return m
run("P5a tail exact suffix", log, t(tail_exact))
run("P5b tail cut mid utf-8 char", log, t(tail_cut))
# P6 nextest-style capture header in the test step tail (log is JSON, tail is stderr)
nx = ("    FAIL [   0.010s] crate::ui trybuild_ui\n--- STDERR:              crate::ui trybuild_ui ---\n"
      "error[E0308]: mismatched types\n --> tests/ui/x.rs:3:5\n")
run("P6 nextest captured trybuild stderr in tail", T.PASS_LOG, t(nx))
# P7 rebuild_cmds None (control treats as no rebuild)
run("P7 rebuild_cmds=None", T.PASS_LOG, None, record=dict(T.RECORD, rebuild_cmds=None))
# P8 public: exit code 137 / 139
print("P8 public 137", P.classify_public("Killed", 137, runtime=T.OK)["kind"])
# P9 unicode / no trailing newline / empty
run("P9 PASS_LOG no trailing newline", T.PASS_LOG.rstrip("\n"))
run("P9b empty log", "")
