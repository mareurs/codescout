### Task 3: Pin observed mutation gaps and preserve the result

**Files:** policy tests, new dated report/evidence and main bug records. Production changes only for confirmed requested defects.
**Interfaces:** mutation receipt records applied/killed/survived/invalid/not-applied separately, with exact old/new source and per-mutant pytest logs.

- [ ] Read the actual initial survivors before adding tests. Pin cgroup=1; source-gutter storage/permission text; duplicate/empty expected sets; full-evidence verdict mismatch; recovered statuses; unknown parser string; successful-step compiler text; storage suffix anchor; negative and boolean test-step exits; blank rebuild commands.
- [ ] Replay the exact applicable mutants on fresh corrected copies; classify disappeared patterns as not applied, never killed. Add semantic replacements for genuinely moved guards with an explicit mapping; report equivalent/redundant survivors separately.
- [ ] Run the five relevant suites and required full product gate on final source; retain failures and exclusions. The root gate does not collect setup-ab-eval tests.
- [ ] Preserve a new source-bound evidence capsule and normal exact-path commit, without rewriting the old capsule. Update the report, README and bug records with actual SHA/patch-id and remaining F3/F6/F7 limits. Report through the operator; no peer socket send requested for this review response.

## Self-review and execution rulings

Tasks 1/2/3 share the same policy boundary; execute sequentially. Initial mutation evidence is from immutable base 23bd63dca even if current-source corrections start later. The independent Opus review already supplied the requested fresh whole-change review; this is its single bounded RED/GREEN correction pass, not an invitation to loop reviewers. The user's standing autonomous-execution instruction supplies the implementation method; no new approval gate is inferred for reversible local fixes. F3 is excluded from implementation until an explicit operator decision.
