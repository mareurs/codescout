### Task 2: Restore fail-closed input compatibility

**Files:** same policy and test files.
**Interfaces:** adjudicate_private continues returning a result mapping; no exception swallowing beyond known malformed evidence.

- [ ] Add direct-call malformed raw/record mapping tests (including explicit None), and missing/null/empty/whitespace rebuild cases. Run them RED on the existing boundary.
- [ ] Add explicit input validation and match the executor's optional rebuild normalization. Run GREEN and all five related suites.

