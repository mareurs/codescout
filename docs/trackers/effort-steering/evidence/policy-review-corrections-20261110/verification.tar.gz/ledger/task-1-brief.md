### Task 1: Reproduce and correct scoped log evidence

**Files:** tools/setup-ab-eval/grade_policy.py; tools/setup-ab-eval/test_grade_policy.py; small characterized capture fixtures under tools/setup-ab-eval/fixtures/multilang/ when needed.
**Interfaces:** Keep compiler_diagnostic, infrastructure_issue, classify_public, step_compiler_failure and adjudicate_private signatures; introduce scoped_lines(log) and per-step context helper if required.

- [x] Reproduce reviewer F1/F2 on unchanged source and run the actual 4096-byte decoder cut. Retain the uninformative first Unicode fixture separately.
- [x] Run an actual nextest JSON-plus command and retain independent stdout/stderr and their hashes; verify its header shape rather than adopting the assumed one.
- [ ] Apply the peer's original mutation catalog on fresh base-source copies before changing tests; retain all patterns, logs and classifications.
- [ ] Add failing public/private tests for captured libtest and both nextest header shapes, genuine top-level infrastructure controls, separate streams and the real UTF-8 suffix cut; run them RED.
- [ ] Implement the smallest shared scoping/context correction; run those tests GREEN, then the complete policy suite.

