# SDD ledger — plan: /home/marius/work/claude/codescout/docs/trackers/effort-steering/plans/2026-11-10-policy-review-corrections.md

Base: 23bd63dca161eb491190d877a2207303458e8921. Branch: fix/grader-policy-review-20261110.

Pre-flight: Tasks 1/2/3 share grade_policy.py and its test module; execute sequentially. Task 3 baseline mutation evidence is from immutable base source, not later working-tree tests.

Ruling: This is the single correction pass following the independent Opus review already supplied by the operator; do not start another review loop. Fix explicitly requested F4/F5 despite their low review severity. Leave F3 classification and F6/F7 scope unchanged; those decisions are visible in the plan and handoff.

Observed before production edits: F1/F2/F4/F5 reproduced, including the actual decoder cut; source and evidence preserved in resident scratch. Actual nextest 0.9.150 capture format is an indented output block, distinct from the reviewer's assumed legacy STDERR header.

Applied all 48 original catalog mutants to fresh source copies: 31 killed, 17 survived, zero invalid/not-applied. This differs from the peer's reported 33/15; retained full inputs and logs are the evidence. Source excerpts, cgroup=1/float, selected-set coherence, full verdict, recovered statuses, unknown parser strings, returncode guards and blank rebuilds are pending guard regressions. Do not infer equivalence merely from a survivor.
Task 1: complete (commits 23bd63d..23bd63d, tests: python3 -m pytest -q tools/setup-ab-eval/test_grade_policy.py → 35 passed, 52 subtests passed in 10.79s)
Task 2: complete (commits 23bd63d..23bd63d, tests: python3 -m pytest -q tools/setup-ab-eval/test_grade_policy.py -k 'review_input_shapes or review_optional_rebuild' → 3 passed, 35 deselected, 17 subtests passed in 0.86s)

Task 3 verification complete before final commit: final five suites 293 passed / 180 subtests; full product gate exit 0 (1765 Python passed, 1 skipped, 554 subtests; FMT/CLIPPY/LEAN/DEFAULT all 0). Final 59 actual mutants: 55 killed, 4 retained redundant verdict guards, none invalid/not-applied. N10 survived before adding its regression, then was killed. Nested expected-map cases were RED before the narrow guard fix. All 5823 tracked entries and exact patch unchanged across final gate. Source/evidence commit and canonical report close-out pending; no intermediate task commit was created.
