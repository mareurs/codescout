---
id: c60133a0c8103156
kind: plan
status: active
title: Correct reviewed prospective policy evidence boundaries
tags:
- effort-steering
- evaluation
- review-corrections
topic: effort-steering
---

# Prospective Policy Review Corrections Implementation Plan

> **For agentic workers:** Execute inline with superpowers:executing-plans and test-driven-development. This is the bounded correction pass requested by the operator's forwarded review; preserve the reviewed source and frozen studies.

**Goal:** Correct confirmed F1/F2/F4/F5 behavior and verify actual surviving guard mutations without changing the experiment's outcome policy.

**Architecture:** One source-scoped line iterator supplies both compiler and infrastructure classification. Per-step evidence is interpreted independently, with full printed-log context reused when a suffix can be located despite a real UTF-8 replacement at its cut. Explicit mapping validation and executor-compatible optional-rebuild handling keep malformed inputs distinct from functional failures.

**Tech Stack:** Existing Python policy, unittest/pytest, real installed nextest 0.9.150 for an isolated dependency-free capture control. No paid/provider/private-grade calls.

**Spec:** Correction contract below, the forwarded 2026-11-09 review of 23bd63dca, and the existing [policy attribution plan](2026-11-07-policy-diagnostic-attribution.md).

## Correction contract

- Captured libtest and nextest test data cannot become top-level compiler or infrastructure evidence merely because it contains diagnostic text.
- Recognize the real nextest indented output block observed in native-capture/stderr.log; keep the reviewer's older synthetic STDERR-header case separate. Preserve original raw logs and native stdout/stderr hashes.
- Reproduce the actual multilang_control decoder's 4096-byte cut; retain the full capture context when matching its decoded suffix. Do not borrow test diagnostics to explain a failed rebuild.
- Genuine top-level process/storage/permission failure remains invalid; ambiguous compiler provenance remains invalid. Do not turn lack of evidence into success.
- Bad mapping inputs return invalid rather than raising. Missing/null/empty/blank rebuild commands mean no rebuild, matching the executor.
- F3 missing-status/abort treatment remains unchanged and explicitly unresolved for the operator. No dropping or selective rerunning of trials is authorized by this correction. F6 ordinary-linker coverage and F7 shell-encoded signals are recorded limits, outside this bounded production pass.

## Global constraints

Worktree /home/marius/.codex/worktrees/e646/codescout, branch fix/grader-policy-review-20261110, base 23bd63dca161eb491190d877a2207303458e8921. Do not amend preservation/integration commits, add2, the peer branch, any frozen parser, result, policy-v2 receipt or cohort. No main merge or push. Bug records go immediately to the main checkout. Scratch is /home/marius/.cache/codescout-resident/codescout/grader-policy-review-20261110. Test/mutation outcome counts must come from observed full populations; parser/collection errors are not mutation kills.

## Review Focus

1. Headerless tails cut in a multibyte character must use real decoder behavior and preserve complete-log capture scope.
2. Nextest stderr is separate from its JSON print log; actual captured diagnostics and JSON test payloads must not invalidate selected outcomes.
3. Scope must not leak between unrelated steps; a genuine later top-level infrastructure fault must remain visible.
4. Malformed inputs must hit the intended boundary; raw=None and boolean test-step returncodes must not be replaced or preempted by fixture helpers.
5. Surviving guards must be applied before adding their regressions; unknown parser strings, duplicate expected names and full-verdict contradictions require internally coherent inputs that reach the guard.

### Task 1: Reproduce and correct scoped log evidence

**Files:** tools/setup-ab-eval/grade_policy.py; tools/setup-ab-eval/test_grade_policy.py; small characterized capture fixtures under tools/setup-ab-eval/fixtures/multilang/ when needed.
**Interfaces:** Keep compiler_diagnostic, infrastructure_issue, classify_public, step_compiler_failure and adjudicate_private signatures; introduce scoped_lines(log) and per-step context helper if required.

- [x] Reproduce reviewer F1/F2 on unchanged source and run the actual 4096-byte decoder cut. Retain the uninformative first Unicode fixture separately.
- [x] Run an actual nextest JSON-plus command and retain independent stdout/stderr and their hashes; verify its header shape rather than adopting the assumed one.
- [x] Apply the peer's original mutation catalog on fresh base-source copies before changing tests; retain all patterns, logs and classifications.
- [x] Add failing public/private tests for captured libtest and both nextest header shapes, genuine top-level infrastructure controls, separate streams and the real UTF-8 suffix cut; run them RED.
- [x] Implement the smallest shared scoping/context correction; run those tests GREEN, then the complete policy suite.


Observed Task 1: actual initial mutation population is 48, with 31 killed / 17 survived / 0 invalid / 0 not applied, rather than the peer's reported 33/15. Regression RED log retains 15 failed checks; corrected complete policy suite is 35 passed / 52 subtests (task-done replay 10.79s). The shared iterator handles characterized nextest indentation and framed JSON payloads; infrastructure scans independent streams. This does not prove arbitrary unframed/nocapture text has attributable provenance.

### Task 2: Restore fail-closed input compatibility

**Files:** same policy and test files.
**Interfaces:** adjudicate_private continues returning a result mapping; no exception swallowing beyond known malformed evidence.

- [x] Add direct-call malformed raw/record mapping tests (including explicit None), and missing/null/empty/whitespace rebuild cases. Run them RED on the existing boundary.
- [x] Add explicit input validation and match the executor's optional rebuild normalization. Run GREEN and all five related suites.


Observed Task 2: direct malformed-input/optional-rebuild RED is 7 failed checks; corrected five-suite run is 282 passed / 162 subtests in 30.65s. The task-done focused replay is 3 passed / 17 subtests. Explicit None reaches the actual API rather than a default-substituting test helper.

### Task 3: Pin observed mutation gaps and preserve the result

**Files:** policy tests, new dated report/evidence and main bug records. Production changes only for confirmed requested defects.
**Interfaces:** mutation receipt records applied/killed/survived/invalid/not-applied separately, with exact old/new source and per-mutant pytest logs.

- [ ] Read the actual initial survivors before adding tests. Pin cgroup=1; source-gutter storage/permission text; duplicate/empty expected sets; full-evidence verdict mismatch; recovered statuses; unknown parser string; successful-step compiler text; storage suffix anchor; negative and boolean test-step exits; blank rebuild commands.
- [ ] Replay the exact applicable mutants on fresh corrected copies; classify disappeared patterns as not applied, never killed. Add semantic replacements for genuinely moved guards with an explicit mapping; report equivalent/redundant survivors separately.
- [ ] Run the five relevant suites and required full product gate on final source; retain failures and exclusions. The root gate does not collect setup-ab-eval tests.
- [ ] Preserve a new source-bound evidence capsule and normal exact-path commit, without rewriting the old capsule. Update the report, README and bug records with actual SHA/patch-id and remaining F3/F6/F7 limits. Report through the operator; no peer socket send requested for this review response.

## Self-review and execution rulings

Tasks 1/2/3 share the same policy boundary; execute sequentially. Initial mutation evidence is from immutable base 23bd63dca even if current-source corrections start later. The independent Opus review already supplied the requested fresh whole-change review; this is its single bounded RED/GREEN correction pass, not an invitation to loop reviewers. The user's standing autonomous-execution instruction supplies the implementation method; no new approval gate is inferred for reversible local fixes. F3 is excluded from implementation until an explicit operator decision.
