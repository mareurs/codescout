---
id: b4fb2d5681029e7f
kind: bug
status: investigating
title: Prospective policy guard tests do not reach coherent boundary cases
tags:
- cluster/unclassified
- effort-steering
- test-coverage
fix_branch: fix/grader-policy-review-20261110
fix_commit: f586d35f4b0d41768931648dd1a9a33f1cdd450f
fix_patch_id: 53c4b6e6027c6135823b4fc1b0994c1a719b7301
opened: 2026-11-10
severity: medium
---

# Green policy tests leave coherent boundary mutations undetected

## Class fit

Unclassified regression-coverage defect: the suite's fixtures either omit the boundary or fail an earlier check, leaving load-bearing validation unobserved. This is not a claim that every surviving mutation changes behavior; redundant guards must remain distinguished from real gaps.

## Evidence

Independently applied the peer's complete literal catalog to fresh copies of immutable 23bd63dca before changing tests. Actual observed population: 48 applied, 31 killed, 17 survived, zero invalid or not-applied. This differs from the review's stated 33/15; both claims are retained and our per-mutant logs are authoritative for our run. Evidence is /home/marius/.cache/codescout-resident/codescout/grader-policy-review-20261110/mutations-before/results.json and its source hashes/logs.

## Examples and correction

Cgroup=1 is absent; deleting the cgroup type check also admits floating 2.0. Numbered/pipe source excerpts contain no storage/permission counterexample. Expected-set mutations need raw/full receipts whose expected counts agree, otherwise later contradiction checks mask the removed guard. The boolean returncode fixture targets a print step, which rejects it separately. Recovery never asserts returned statuses. The raw/full contradiction and arbitrary-string parser-status guards need their own coherent inputs. The repeated-parser guard must be exercised by an actual nondeterministic parser rather than declared equivalent by reading a deterministic fixture.

New tests are locally green (47 policy tests / 84 subtests) after F1/F2/F4/F5 corrections, but mutation replay is pending. Three old guards appear functionally redundant for ordinary JSON evidence: the initial raw-pass bool check is repeated by the later typed parser-verdict comparison; empty-suffix context is equivalent to the pure fallback for an empty tail; crash-path forced pass=false repeats the already-false empty-status verdict. Do not count a redundant survivor as an uncorrected bug or claim it killed by a coverage argument.

## Resume

Replay the original applicable edits on fresh corrected copies. Explicitly map moved capture/rebuild/stream guards to their new call sites and classify nonmatching edits as not applied, not killed. Also apply mutations to the newly shared scope helper and its two consumers. Retain every observed survivor before adding a regression that closes it. No historical grades or paid model calls.


## Verified local review correction — 2026-11-10

Correction commit f586d35f4b0d41768931648dd1a9a33f1cdd450f, branch fix/grader-policy-review-20261110, stable patch-id 53c4b6e6027c6135823b4fc1b0994c1a719b7301. Coherent guard regressions and returned-status assertions close the observed gaps. N10 was applied and observed surviving before its regression, then killed. Final original 48:44 killed/4 survivors; all 11 new mutations killed. Four remaining verdict-redundant guards have finite differential controls, not universal equivalence proof.

Five related suites: 293 passed / 180 subtests. Full product gate exit 0, all lanes green; its root Python population excludes evaluator tests and retains printed heavy/feature/ONNX limits. Actual applied mutations:59, with55 killed/four retained redundant verdict guards; zero invalid/not-applied. Source and all232 capsule members checked after commit. See the [bounded correction report](../trackers/effort-steering/reports/2026-11-10-policy-review-corrections.md).

Root correction is verified locally. This record remains investigating pending actual experiments integration, with no live claim; do not archive it from unit evidence alone. No historical verdict rewrite, private regrade, model call or push.
