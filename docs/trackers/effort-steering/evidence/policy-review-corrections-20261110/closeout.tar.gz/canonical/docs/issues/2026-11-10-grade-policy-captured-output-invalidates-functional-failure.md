---
id: '8a78631cb04111b2'
kind: bug
status: investigating
title: Prospective grade policy treats captured test data as infrastructure evidence
tags:
- cluster/unclassified
- effort-steering
- evaluation
fix_branch: fix/grader-policy-review-20261110
fix_commit: f586d35f4b0d41768931648dd1a9a33f1cdd450f
fix_patch_id: 53c4b6e6027c6135823b4fc1b0994c1a719b7301
opened: 2026-11-10
severity: medium
---

# Captured test data invalidates a genuine selected failure

## Class fit

Unclassified diagnostic-provenance defect in prospective evaluation policy. Unlike a genuine storage or toolchain failure, the same diagnostic strings originate inside a test's captured output. The selected functional outcome must not be erased by its own test data.

## Reproduction

At commit 23bd63dca, append a libtest captured stdout section to FAIL_LOG and place any of these strings inside it: write failed: No space left on device; open /tmp/fixture.txt: Permission denied; rustc: fatal error: terminated with signal 9. Give the test step returncode 101. Every case returns measurement_invalid rather than the observed selected test_failure.

## Root cause

The prospective policy's infrastructure scan receives a concatenation of the printed log and all step tails. It ignores source gutters but does not retain captured-output scope, unlike the compiler-diagnostic scan. Scope can also leak across otherwise independent streams.

## Evidence

Independently executed on unchanged production source: /home/marius/.cache/codescout-resident/codescout/grader-policy-review-20261110/reproductions-before-v2.json. All three synthetic cases contain complete selected statuses and valid runtime proof. No model, Docker or private candidate grade; the module is currently imported only by its tests.

## Fix

Pending source-scoped regression and correction on fix/grader-policy-review-20261110. Preserve genuine top-level storage, permission and toolchain-fatal rejection. No historical result rewrite.


## Verified local review correction — 2026-11-10

Correction commit f586d35f4b0d41768931648dd1a9a33f1cdd450f, branch fix/grader-policy-review-20261110, stable patch-id 53c4b6e6027c6135823b4fc1b0994c1a719b7301. F2 regressions retain compiler/infrastructure capture scope and independent step streams. Captured fake faults stay test data, while a genuine later top-level storage fault remains invalid.

Five related suites: 293 passed / 180 subtests. Full product gate exit 0, all lanes green; its root Python population excludes evaluator tests and retains printed heavy/feature/ONNX limits. Actual applied mutations:59, with55 killed/four retained redundant verdict guards; zero invalid/not-applied. Source and all232 capsule members checked after commit. See the [bounded correction report](../trackers/effort-steering/reports/2026-11-10-policy-review-corrections.md).

Root correction is verified locally. This record remains investigating pending actual experiments integration, with no live claim; do not archive it from unit evidence alone. No historical verdict rewrite, private regrade, model call or push.
