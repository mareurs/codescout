---
id: '2f8500976a76db35'
kind: bug
status: open
title: Prospective grade policy leaves an ordinary linker failure unclassified
tags:
- cluster/unclassified
- effort-steering
- evaluation
opened: 2026-11-10
severity: low
---

# An ordinary failed link becomes invalid measurement

## Class fit

Unclassified diagnostic-coverage limitation. A compiler's ordinary linker failure is a functional build failure, unlike a fatal toolchain signal or missing capture. The policy currently recognizes Rust source spans but not the linker's own diagnostic layout.

## Reproduction

On 23bd63dca, use a failed rebuild tail containing error: linking with cc failed, an undefined-reference note, and collect2: error: ld returned 1 exit status, without a Rust arrow/numbered source span. The policy returns measurement_invalid: rebuild failed without a classified compiler diagnostic.

## Evidence

Own deterministic reproduction and exact input are in /home/marius/.cache/codescout-resident/codescout/grader-policy-review-20261110/reproductions-before-v2.json, case F6-linker-review-fixture. This was the initial synthetic control. The later dated host characterization below now reproduces the limitation on actual linker output. The current result fails closed and never awards a pass.


## Actual host linker characterization — 2026-11-10

Ran rustc 1.99.1 on a dependency-free generated program referencing an undefined C symbol. The actual compiler exited 1 and emitted an ordinary linking-with-cc failure naming the missing symbol. compiler_diagnostic returns None, and a synthetic rebuild receipt containing that real stderr remains measurement_invalid. Exact argv, version, stderr SHA-256 d78822c004b3211ffcb74ec04b22ca4901faaf330a43b0d078159f1001cc3b9c and result are in linker-native-receipt.json; raw text is linker-native.stderr, under the dated review scratch root. This settles the synthetic-format caveat for one host runtime, not every registered container. Recognition is still deferred outside F1/F2/F4/F5; no source or historical grade changed for F6.

## Resume — 2026-11-10

F6 is separate from the requested F1/F2/F4/F5 correction pass. One actual host linker failure has now been characterized; see the dated section and correction report. Any later recognition widening must preserve captured-output exclusions and distinguish ordinary link failure from toolchain crashes. This pass changes neither production recognition nor historical verdicts for F6.
