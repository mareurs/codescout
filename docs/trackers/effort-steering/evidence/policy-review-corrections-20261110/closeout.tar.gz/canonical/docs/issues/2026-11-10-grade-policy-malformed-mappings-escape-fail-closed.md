---
id: aa8da9f4dc12257c
kind: bug
status: investigating
title: Prospective grade policy raises on malformed mapping inputs
tags:
- cluster/unclassified
- effort-steering
- evaluation
fix_branch: fix/grader-policy-review-20261110
fix_commit: f586d35f4b0d41768931648dd1a9a33f1cdd450f
fix_patch_id: 53c4b6e6027c6135823b4fc1b0994c1a719b7301
opened: 2026-11-10
severity: low
---

# Malformed policy inputs escape the invalid-measurement boundary

## Class fit

Unclassified boundary-validation defect. The prospective adjudicator promises a classified invalid measurement for malformed evidence, but assumes mapping methods before validating input shape. This differs from ordinary candidate failure or an intentionally rejected runtime receipt.

## Reproduction

Directly call adjudicate_private at 23bd63dca with otherwise valid fixtures and raw equal to None, a string or a list, or record equal to a list. All four calls raise AttributeError. They do not return a classified invalid result.

## Root cause

Mapping .get is invoked without an explicit shape check, and AttributeError is outside the existing exception tuple. Fix through explicit boundary validation so programmer defects are not hidden behind a broad catch.

## Evidence

Own direct-call probes are retained in /home/marius/.cache/codescout-resident/codescout/grader-policy-review-20261110/reproductions-before-v2.json. The peer helper replaces raw=None with its default raw receipt, so that helper alone cannot demonstrate the None case; our probe passes None directly. No paid or private grading call.


## Nested mapping follow-up

The first explicit-root fix correctly refuses malformed raw/full/record/bundle roots. Further direct probes confirmed that bundle.expected equal to None, a string or a list still raises AttributeError in expected_sets. A dedicated direct-input test was added and observed RED in nested-mapping-red.log before extending the mapping guard. This is the same boundary defect; generic mapping validation must include this nested mapping rather than only the four reported root examples. No broad AttributeError swallowing is proposed.

## Fix

Pending failing direct-input regression tests and minimal mapping validation on fix/grader-policy-review-20261110.


## Verified local review correction — 2026-11-10

Correction commit f586d35f4b0d41768931648dd1a9a33f1cdd450f, branch fix/grader-policy-review-20261110, stable patch-id 53c4b6e6027c6135823b4fc1b0994c1a719b7301. F4 root mapping and nested expected-mapping probes were RED before narrow validation and GREEN after. Explicit None reaches the actual API; malformed inputs return invalid without broad AttributeError swallowing.

Five related suites: 293 passed / 180 subtests. Full product gate exit 0, all lanes green; its root Python population excludes evaluator tests and retains printed heavy/feature/ONNX limits. Actual applied mutations:59, with55 killed/four retained redundant verdict guards; zero invalid/not-applied. Source and all232 capsule members checked after commit. See the [bounded correction report](../trackers/effort-steering/reports/2026-11-10-policy-review-corrections.md).

Root correction is verified locally. This record remains investigating pending actual experiments integration, with no live claim; do not archive it from unit evidence alone. No historical verdict rewrite, private regrade, model call or push.
