---
id: '7ee0a86c16915ff6'
kind: bug
status: investigating
title: Grade policy attributes an unselected doctest compiler error to selected acceptance
tags:
- cluster/unclassified
fix_branch: fix/grader-policy-review-20261110
fix_commit: f586d35f4b0d41768931648dd1a9a33f1cdd450f
fix_patch_id: 53c4b6e6027c6135823b4fc1b0994c1a719b7301
opened: 2026-11-07
---

# Unselected doctest compile diagnostics override passing selected statuses

## Class fit

Unclassified diagnostic-attribution defect. The prospective wrapper joins complete logs into each failed step's compiler-evidence search and treats a rustc diagnostic as a candidate build failure without determining whether it came from an unselected compile-fail doctest. A correct selected oracle and an unrelated doctest can therefore produce a false failed acceptance.

## Observation

Independently reproduced against policy867c680924cb75575bec7ccd7068b8dfd7fd5889. Start with the existing fixture's two selected statuses both pass; add an unselected FAILED doctest section containing error[E0425] and set the test-step exit to101. adjudicate_private returns valid=true, pass=false, kind=compile_failure while its adjusted selected verdict is pass=true, missing0, not_passing0. The comparable unselected ordinary-test failure with no rustc diagnostic remains valid/pass=true. This contradicts the documented selected-set scope and existing test_selected_expected_pass_can_survive_unselected_test_failures intent.

## Evidence

/home/marius/.cache/codescout-resident/codescout/semantic-contract-policy-review-20261107/{reproduce.py,reproductions.json}. Pure deterministic fixtures with unchanged source hashes; no private paid-grade outcome, Docker, model or provider call. The reproduction confirms the reviewer's description; it does not establish that any pilot candidate encountered this condition.


Follow-up source isolation/add2: the whole-log attribution also let an independently failed rebuild with no compiler diagnostic borrow a genuine compiler error from a different failed test step. New test_failed_test_diagnostic_cannot_explain_unknown_failed_rebuild was run before correction and fails at the intended valid=false assertion (cross-step-red.log in review ROOT). Every failed rebuild must have its own classified evidence; another stage's known compile failure cannot explain an unknown rebuild failure. No private candidate grade inspected.


Focused independent review of the uncommitted v2 delta reproduced a remaining case: an unselected captured stdout section prints nested Cargo's `Compiling ...` then error[E0425], and the provisional parser resumes top-level attribution too early. Result remains adjusted.pass=true but pass=false/compile_failure. This is the same diagnostic-provenance defect; the review artifacts preserve the actual case. Both independently APPLIED coverage mutations (drop stderr header recognition, drop Checking resume) survived71tests/67subtests before any new test fix. The latter guard is implicated in the semantic defect rather than automatically deserving more tests. No v2 admission or private candidate grading has occurred; current source-bound gate is still running, and these pre-fix results remain immutable.

## Containment and ownership

Codex01a15ca9 owns policy follow-up in isolation. No edit of the active pilot's registered grader-validity path, no reinterpretation of historical grades, no hidden selective retry. Genuine failed builds must still be rejected even if stale selected statuses remain, so removing all compiler checks is not a sufficient fix.

Session: codex:01a15ca9-f939-7603-acb5-01c6b02f68e2.

## Fresh policy verification — 2026-11-09

Version distinction verified from actual source and deterministic synthetic calls. Original867c68092 in grader-validity still misclassifies selected-pass plus an unselected doctest error as valid/compile_failure/passfalse, and treats a candidate test-binary SIGABRT as measurement_invalid. The staged add2 policy returns valid/pass for both same synthetic cases. Full current five-suite run263passed/129subtests; no Docker/model/private candidate regrade.

Both old/new prospective policies invalidate a genuine linker SIGBUS even when statuses are present. This is an explicitly declared prospective-adjudicator contract in the semantic-contract design section Prospective policy v1, not the live_grader zero-status-only contract in the earlier classifier plan. These two contracts must remain distinguished. V2 diagnostic attribution and its after-model/before-private-outcome amendment are documented in the policy-attribution plan; this is development evidence, not an original frozen or held-out result.

All six add2 correction paths remain staged/uncommitted. The corrected source is absent from main experiments; neither policy commit nor classifier branch is integrated in its local ancestry. Therefore this record stays open for integration rather than being closed from unit tests. The specific functional cases in the older peer reminder are already corrected locally. No new source edit,commit,push,model call or historical receipt change.


## Commit custody — 2026-11-09

The exact six corrected source/test files are now preserved in commit 1d48e48d58402e77d5af9a7ab5c4bee224bb0949 on fix/grader-policy-preserve-20261109. Stable patch-id: d71f94f9c8eece79f35bf1a807ce9574914c9e44. The new managed worktree is /home/marius/.codex/worktrees/e646/codescout. All six committed blobs match the prior frozen source hashes; all 5,179 tracked source hashes captured by the old final gate matched before and after the new gate. The original add2 tree, its staged state and the dated UNCOMMITTED frozen receipt are retained.

Fresh preservation validation: baseline five-suite run 245 passed / 119 subtests; corrected run 263 passed / 129 subtests. Full gate exited 0 in 427 seconds, with Python light, fmt, clippy, lean and default lanes all green. Its printed heavy/feature/ONNX exclusions remain; the setup-ab-eval suite is separate from the gate Python population. Commit hooks passed without bypass. The commit carries the canonical Codex Session-Id and the peer's bare Co-Authored-Session-Id.

The peer branch subsequently observed at 2794bb196 adds two regression-test changes and a research-note update, with no production-code delta. An integration candidate based on current experiments d124e7738 is being tested separately and includes those tests. This record remains open pending actual main integration. No push, provider call, private regrade, historical result rewrite or modification of the peer branch.


## Tested integration candidate — 2026-11-09

Commit 23bd63dca161eb491190d877a2207303458e8921 on fix/grader-policy-integration-20261109 assembles the correction on experiments base d124e7738 and includes the newer peer regression tests. Stable patch-id 3fc60bac014324590a75b9d6e1d7696b67a31c4b. Fresh five-suite result: 272 passed / 133 subtests; full gate exit 0 in 407 seconds. All 5,818 captured tracked-file hashes remain equal after the gate; the ten committed source blobs match. Evidence capsule and member manifest are committed with the source and independently reopened.

The separate preservation commit and old frozen source remain intact. Main advanced during qualification and does not contain the integration commit at the final ancestry check, so this issue remains open for main integration. The canonical [source-custody report](../trackers/effort-steering/reports/2026-11-09-grader-policy-integration.md) records the committed evidence and exact tested base. No push or model/private grading call.


## Review reopened — 2026-11-10

The operator forwarded a changes-required review of 23bd63dca. Independently reproduced F1 on untouched committed source in the new branch fix/grader-policy-review-20261110: the nextest-shaped captured STDERR tail produces valid/compile_failure despite complete selected passes. More strongly, an actual multilang_control._decode_tail last-4096-byte cut through a UTF-8 character produces a leading replacement character, defeats suffix matching and promotes a captured libtest error into compile_failure. This is the same diagnostic-attribution defect as the original report, now at the step-tail boundary; the preserved commits and old capsule remain immutable.

Evidence: /home/marius/.cache/codescout-resident/codescout/grader-policy-review-20261110/reproductions-before-v2.json and reproduce.py. The first fixture version accidentally put the error text on the padding line and did not reproduce the UTF-8 branch; its before.json is retained as an uninformative control, not counted as a reproduction. The corrected fixture uses the real decoder and a separate physical diagnostic line. Real nextest stream characterization is separate from the reviewer's synthetic header assumption. No new model/private candidate or historical regrade.


## Verified local review correction — 2026-11-10

Correction commit f586d35f4b0d41768931648dd1a9a33f1cdd450f, branch fix/grader-policy-review-20261110, stable patch-id 53c4b6e6027c6135823b4fc1b0994c1a719b7301. F1 regressions use both the actual 4096-byte decoder cut and independently captured real nextest 0.9.150 streams. Both preserve selected outcomes; failed rebuild evidence stays independent.

Five related suites: 293 passed / 180 subtests. Full product gate exit 0, all lanes green; its root Python population excludes evaluator tests and retains printed heavy/feature/ONNX limits. Actual applied mutations:59, with55 killed/four retained redundant verdict guards; zero invalid/not-applied. Source and all232 capsule members checked after commit. See the [bounded correction report](../trackers/effort-steering/reports/2026-11-10-policy-review-corrections.md).

Root correction is verified locally. This record remains investigating pending actual experiments integration, with no live claim; do not archive it from unit evidence alone. No historical verdict rewrite, private regrade, model call or push.
