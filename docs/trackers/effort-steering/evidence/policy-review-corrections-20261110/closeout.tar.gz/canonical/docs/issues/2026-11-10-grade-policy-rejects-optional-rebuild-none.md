---
id: a669f696562c126c
kind: bug
status: investigating
title: Prospective grade policy rejects optional rebuild commands accepted by the executor
tags:
- cluster/unclassified
- effort-steering
- evaluation
fix_branch: fix/grader-policy-review-20261110
fix_commit: f586d35f4b0d41768931648dd1a9a33f1cdd450f
fix_patch_id: 53c4b6e6027c6135823b4fc1b0994c1a719b7301
opened: 2026-11-10
severity: low
---

# Optional rebuild metadata disagrees with native execution

## Class fit

Unclassified execution/adjudication contract mismatch. The controller accepts absent or null rebuild commands as no rebuild; prospective step admission attempts to iterate null and rejects the otherwise valid result. This differs from an actually missing required rebuild step.

## Reproduction

At 23bd63dca, set rebuild_cmds to None in the valid selected-pass fixture. The record has exactly its test and print steps. adjudicate_private returns measurement_invalid with a NoneType iteration error.

## Root cause

The expected-step derivation iterates record.get(rebuild_cmds, []) directly. The existing multilang_control.rebuild instead iterates record.get(rebuild_cmds) or [] and drops blank/non-string entries. The prospective policy must agree about whether a rebuild was required.

## Evidence

Both actual symbols were read and the mismatch was independently executed. Inputs/result are in /home/marius/.cache/codescout-resident/codescout/grader-policy-review-20261110/reproductions-before-v2.json. No historical record or live executor changed.

## Fix

Pending no-rebuild compatibility regression for missing, null, empty and whitespace-only rebuild metadata, followed by the minimal derivation correction.


## Verified local review correction — 2026-11-10

Correction commit f586d35f4b0d41768931648dd1a9a33f1cdd450f, branch fix/grader-policy-review-20261110, stable patch-id 53c4b6e6027c6135823b4fc1b0994c1a719b7301. F5 absent/null/empty/blank rebuild commands match the executor; a nonblank required rebuild cannot disappear.

Five related suites: 293 passed / 180 subtests. Full product gate exit 0, all lanes green; its root Python population excludes evaluator tests and retains printed heavy/feature/ONNX limits. Actual applied mutations:59, with55 killed/four retained redundant verdict guards; zero invalid/not-applied. Source and all232 capsule members checked after commit. See the [bounded correction report](../trackers/effort-steering/reports/2026-11-10-policy-review-corrections.md).

Root correction is verified locally. This record remains investigating pending actual experiments integration, with no live claim; do not archive it from unit evidence alone. No historical verdict rewrite, private regrade, model call or push.
