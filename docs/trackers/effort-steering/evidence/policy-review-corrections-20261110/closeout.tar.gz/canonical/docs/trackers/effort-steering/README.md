---
id: cba97c1270405493
kind: tracker
status: active
title: Effort steering — experiment index, results and historical notes
tags:
- effort-steering
- research-index
topic: effort-steering
---

# Effort-steering experiment

Find a **generic repair workflow that improves low-effort quality toward xhigh at lower complete-workflow cost**. This folder is the canonical home for this experiment's findings, plans and limitations.

## Current state — 2026-11-09

**Research goal: OPEN. Paid admission for the new mechanism: CLOSED. No generic quality improvement is validated yet.**

Candidate: investigate → repair → challenge with executed, source-bound evidence. Planned comparison: ordinary low, continuation-control low, protocol low and ordinary xhigh; identical policy across projects, public adapters may differ.

Scientific results remain negative: earlier two-task repair pilot1/2 across arms; later baseline-first low/xhigh oracle authors both accepted the saved wrong repair. Low uncertainty follow-up did not resolve the missing case. These observations do not establish general equivalence.

[Native phase controls](reports/2026-11-09-native-phase-cli-qualification.md) and [real public-project execution profiles](reports/2026-11-09-real-project-execution-profiles.md) qualified the scripted lifecycle and evidence boundary separately. Latest [common preparation](reports/2026-11-09-common-source-preparation.md): source-only onboarding reused once; existing CodeRank GPU index completed in441.289s after two CPU timeouts; six memories embedded; actual references/definition/LSP call graph/semantic canaries passed in a no-index continuation. Native verify still literally reports incomplete for two zero-byte fixtures; a separately tested source-bound interpretation proves coverage of all nonempty eligible files and preserves that caveat.

One frozen development corpus now has independent L/R/P/X physical copies. All-file inode scan and actual write controls pass. Final protocol suite205passed,2native CLI skips. Current cf66 product gate passed with its printed exclusions, superseding the older failed run. Applied-review initial survivors, corrections and exact replays are retained; selected guard verification does not establish repair quality.

Next: outcome-blind repository-distinct cohort, full charge reconciliation, transitive runtime and actual four-arm native context/evaluator qualification, then immutable no-cost paid preflight. The development source remains exposed and cannot become a fresh task by relabeling it. No new author/repair LLM call or efficacy result; embedding compute cost remains unpriced.


Grader source custody: [reviewed corrections and evidence capsule](reports/2026-11-09-grader-policy-integration.md) are committed as preservation 1d48e48d5 and tested integration candidate 23bd63dca. The latter passes 272 relevant tests / 133 subtests plus a fresh full gate on base d124e7738; main integration remains open. This does not change the scientific result or paid-admission state.


**2026-11-10 grader review correction:** Changes-required findings F1/F2/F4/F5 are corrected locally in f586d35f4, on branch fix/grader-policy-review-20261110. The [correction report](reports/2026-11-10-policy-review-corrections.md) preserves 293 related tests / 180 subtests, full green product gate, source hashes and a checked 232-member capsule. Final applied mutations:59, with55 killed/four retained redundant verdict guards; initial original48 replay was31/17, separately from the peer's33/15. Old source/capsule remain intact; 23bd63dca alone must not be integrated as the reviewed fix. Main integration remains open. F3 missing-status/abort treatment, F6 ordinary linker coverage and F7 encoded signals remain explicit limits. Research efficacy and paid admission remain unchanged.

## Caveats that constrain interpretation

| Caveat | What is established / what remains open |
|---|---|
| **Onboarding is not tool readiness.** | Empty configured languages hide LSP tools. The fixed-process control reproduced 18→21 tools after programmatic onboarding and verified real navigation. All six audited historical root configurations contained Rust and matched launch hashes; that does **not** prove every old active scope or live LSP call worked. Before each admitted prepared version, verify root/languages, complete actual MCP inventory, successful LSP canaries, native index coverage and a source-bound semantic result. [Evidence](reports/2026-11-09-onboarding-readiness-audit.md). |
| **Files on disk are not delivered instructions.** | Project/global CLAUDE.md, authored Codescout guidance and Recon must reach the actual evaluated CLI. Onboarding metadata, settings files and a scripted backend's boolean cannot establish that. Qualify effective context and loaded tools/skills in the exact pinned client/runtime for all relevant arms. [Context investigation](reports/2026-11-04-worker-context-verification.md), [related issues](issues.md). |
| **Same small score is not equivalence.** | A repeated 1/2 result on two tasks does not establish parity, identify a winning mechanism or support a population-level savings claim. Compare paired task outcomes and complete costs on outcome-blind new tasks; reserve independent held-out validation. [Diagnosis](reports/2026-11-07-semantic-contract-diagnosis.md). |
| **An oracle author is not a repair workflow.** | Cheap test-authoring calls and extra probes did not reliably reject a known wrong repair. Their cost is not the cost of a complete repair. Measure repair acceptance and the entire author/continuation/verification workflow separately. [Baseline-first result](reports/2026-11-07-baseline-first-oracle.md), [uncertainty follow-up](reports/2026-11-08-oracle-uncertainty-resolution.md). |
| **Exposed cases are development data.** | We have inspected these tasks, candidate failures and private witnesses. Further tuning on them cannot count as independent validation. Freeze the generic policy before new-task selection; keep private grader material host-only until all candidate sources are frozen. |
| **Tool obedience and receipt structure are not semantic coverage.** | A model can obey an incorrect hint, or submit valid-looking evidence that misses the required behavior. A green suite or complete receipt establishes only its measured predicate. Require discriminating functional outcomes; review the actual guard call sites with applied mutations. |
| **Runtime qualification is narrower than efficacy.** | Current development controls qualify a reused source-only CodeRank corpus, primary-result LSP/semantic canaries and independent physical L/R/P/X copies. Native incomplete is retained for two proven zero-byte omissions; separate source-bound interpretation covers nonempty eligible files. Latest protocol205passed/2native CLI skips; current cf66 gate passed with exclusions. Actual four-arm native instruction/skill/context parity and fresh cohort admission remain open. Earlier profile/export/quota/gate failures stay historical; none establishes repair quality. [Common preparation and limits](reports/2026-11-09-common-source-preparation.md), [runtime profiles](reports/2026-11-09-real-project-execution-profiles.md). |
| **Infrastructure and accounting must remain visible.** | Disk/tmp/toolchain/OOM/cleanup failures are not automatically model-quality failures. Keep invalid measurement, protocol incompleteness and functional failure distinct; preserve raw artifacts and known/unknown charges. Local mitigations or fixed labels do not imply integration or native admission. [Grader source custody and integration](reports/2026-11-09-grader-policy-integration.md), [disk/grade audit](reports/2026-11-06-private-grade-disk-audit.md), [issue records](issues.md). |
| **Reuse has an isolation boundary.** | Generate adequate source-only onboarding once per project/version, then reuse independent writable copies. Refresh affected facts/configuration when inputs change. Never share task diagnoses, patches, grader feedback or run memories between arms. Reuse avoids generation work; it does not imply zero input-token cost. |
| **Historical recovery has a boundary.** | Earlier reports and mechanism ledgers recovered from retained worktrees are archived separately, with exact source hashes. Their old statuses and relative links are historical; raw evidence named only in those trees still requires separate preservation before cleanup. [Archive and unresolved references](retained-worktrees/README.md). |
| **Cost figures have a scope.** | Report complete-workflow model cost, shared preparation and its explicit amortization separately. Keep unresolved reservations and unknown charges visible; orchestration/CPU/provider-invoice costs are not silently zero. Current budget/accounting rules live in the [design](evidence-protocol-design-20261109.md). |

Close or narrow a caveat only with linked, dated evidence that tests the missing proposition. A successful check of a different property does not close it.

## Where to find things

[Session observations](session-log.md) records dated mechanism/verification findings with evidence and limits; formal issue files retain bug lifecycles.

| Material | Canonical location |
|---|---|
| Current generic mechanism and admission rules | [Design](evidence-protocol-design-20261109.md) and [implementation plan](evidence-protocol-plan-20261109.md) |
| Results, failure analyses and earlier literature | [Reports catalog](reports/README.md) |
| Earlier plans and registrations | [Plans catalog](plans/README.md) |
| Original experiment memory snapshots | [Historical notes catalog](notes/README.md) |
| Earlier reports and mechanism ledgers recovered from retained worktrees | [Historical worktree archive](retained-worktrees/README.md) |
| Bugs and review findings | [Issue index](issues.md); original records remain in docs/issues |
| Frozen evidence files and retained storage locations | [Evidence inventory](evidence.md) |
| Reorganization provenance | [Document manifest](document-reorganization-manifest-20261109.json) and [verification](document-reorganization-verification-20261109.json) |

Old report/plan paths contain short compatibility pointers. Raw registered evidence, sealed run directories and source-only onboarding snapshots retain their original paths. Historical notes preserve their original bodies; their ACTIVE/NEXT/budget statements are not current instructions.

## Roadmap

1. Source-only preparation and independent physical copies are qualified on exposed development source. Next freeze the outcome-blind repository-distinct cohort and charges; qualify actual L/R/P/X instruction/tool/skill delivery plus transitive runtime/evaluator controls. Do not repeat the exposed two-task score as progress.
2. Preserve applied reviews, local fixes and failed attempts; integrate reviewed experiment code separately. Current cf66 gate passed with printed exclusions. Keep the native zero-byte coverage caveat visible.
3. Freeze policy, common per-project inputs, grading/resources, exact attempt order, costs and stop rule. Reconcile immutable receipts; run a new no-cost paid preflight.
4. Run the registered paired development pilot once; preserve invalid/incomplete attempts. Failed screen means NO-GO, not tuning exposed tasks until successful.
5. If the screen passes, register independent held-out validation before promotion.

## How to maintain this experiment folder

- Put every new experiment finding in a dated report here, with the question, exact task/arm/input versions, result, evidence and limits. Put its plan here too; update this README's current state, caveats and roadmap in the same change.
- File each implementation or measurement bug immediately in docs/issues, then link it from the report and refresh the issue index. Preserve one canonical bug record.
- Preserve failed runs and raw evidence. Add a separate audit/reparse artifact when interpretation changes; retain the original grade and registration.
- Put journals and hand-backs here or in historical notes, not project memory. Project memory retains only the pointer to this folder.
- This reorganization changes document locations and links, not experimental outcomes, validity decisions, sealed bytes, budgets or launch authorization.

## Historical migration provenance

The [memory migration manifest](migration-manifest.json) and [verification](migration-verification.json) cover the earlier migration of 107 notes; legacy anchor sidecars remain inactive provenance. The separate document-reorganization manifest records the 2026-11-09 report/plan moves, new catalog IDs, compatibility pointers and original hashes.

Refresh this README whenever a mechanism decision, outcome, qualification boundary, caveat disposition or accounting reconciliation changes. Read historical document statuses as dated records; this README and the current implementation plan own the next action.
