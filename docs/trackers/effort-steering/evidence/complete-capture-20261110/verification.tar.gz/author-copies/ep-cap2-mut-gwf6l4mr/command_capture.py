"""Bounded command-stream evidence. Display tails are never provenance.

Runs only inside the caller's supervised container/timeout. Open output pipes
at the post-exit deadline make capture incomplete. Closed pipes do not prove
that arbitrary detached processes terminated; the runtime must attest that.
"""
import base64
import binascii
import hashlib
import json
import shlex

VERSION = "command-stream-v1"
MAX_BYTES = 64 * 1024 * 1024
TAIL_BYTES = 4096


class CaptureError(ValueError):
    """Missing, incomplete or contradictory transport metadata."""


def _limit(value):
    if type(value) is not int or not 0 < value <= MAX_BYTES:
        raise CaptureError("capture limit must be a positive integer at most 64 MiB")
    return value


_READER = r"""
import base64, json, os, selectors, subprocess, sys, tempfile, time
command, limit = sys.argv[1], int(sys.argv[2])
with tempfile.TemporaryDirectory(prefix="sab-capture-", dir=os.environ.get("TMPDIR")):
    process = subprocess.Popen(["bash", "-o", "pipefail", "-c", command],
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    selector = selectors.DefaultSelector()
    buffers = {"stdout": bytearray(), "stderr": bytearray()}
    totals = {"stdout": 0, "stderr": 0}
    for name, stream in (("stdout", process.stdout), ("stderr", process.stderr)):
        os.set_blocking(stream.fileno(), False)
        selector.register(stream, selectors.EVENT_READ, name)
    exited_at = None
    try:
        while selector.get_map():
            for key, _ in selector.select(0.02):
                chunk = os.read(key.fileobj.fileno(), 65536)
                if not chunk:
                    selector.unregister(key.fileobj)
                    key.fileobj.close()
                    continue
                name = key.data
                totals[name] += len(chunk)
                room = max(0, limit + 1 - len(buffers[name]))
                buffers[name].extend(chunk[:room])
            if process.poll() is not None:
                if exited_at is None:
                    exited_at = time.monotonic()
                elif time.monotonic() - exited_at >= 0.15:
                    break
        open_streams = len(selector.get_map())
    finally:
        for key in list(selector.get_map().values()):
            key.fileobj.close()
        selector.close()
    code = process.wait()
    exit_code = 128 - code if code < 0 else code
    result = {"version": "command-stream-v1", "returncode": exit_code,
              "process_returncode": code, "open_streams": open_streams}
    for name in ("stdout", "stderr"):
        result[name] = base64.b64encode(buffers[name]).decode("ascii")
        result[name + "_bytes"] = totals[name]
    print(json.dumps(result, separators=(",", ":")))
    sys.exit(exit_code)
"""

def script(command, limit_bytes=MAX_BYTES):
    """Bound retained pipe data without changing the command's file-size limit."""
    limit = _limit(limit_bytes)
    if not isinstance(command, str) or not command.strip():
        raise CaptureError("capture command is empty")
    return "python3 -c " + shlex.quote(_READER) + " " + shlex.quote(command) + " " + str(limit)


def _integer(value, name):
    if type(value) is not int or value < 0:
        raise CaptureError(f"{name} must be a nonnegative integer")
    return value


def _raw(value, limit):
    if not isinstance(value, str) or len(value) > 4 * ((limit + 3) // 3):
        raise CaptureError("capture base64 missing or oversized")
    try:
        raw = base64.b64decode(value, validate=True)
    except (ValueError, binascii.Error) as exc:
        raise CaptureError("invalid capture base64") from exc
    if len(raw) > limit + 1 or base64.b64encode(raw).decode("ascii") != value:
        raise CaptureError("capture base64 is oversized or noncanonical")
    return raw


def _object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise CaptureError("duplicate capture key: " + key)
        result[key] = value
    return result


def decode(payload, returncode, limit_bytes=MAX_BYTES):
    """Validate wire bytes and derive hash-bound host evidence."""
    limit = _limit(limit_bytes)
    _integer(returncode, "returncode")
    try:
        value = json.loads(payload, object_pairs_hook=_object)
    except (TypeError, ValueError) as exc:
        raise CaptureError("invalid capture envelope") from exc
    fields = {"version", "returncode", "process_returncode", "stdout_bytes", "stderr_bytes",
              "open_streams", "stdout", "stderr"}
    if not isinstance(value, dict) or set(value) != fields or value["version"] != VERSION:
        raise CaptureError("unknown or incomplete capture envelope")
    if type(value["returncode"]) is not int or value["returncode"] != returncode:
        raise CaptureError("capture returncode contradicts process")
    process_code = value["process_returncode"]
    if type(process_code) is not int or not -128 <= process_code <= 255:
        raise CaptureError("invalid command process returncode")
    if returncode != (128 - process_code if process_code < 0 else process_code):
        raise CaptureError("command signal/returncode contradiction")
    open_streams = _integer(value["open_streams"], "open_streams")
    if open_streams > 2:
        raise CaptureError("invalid open stream count")
    streams = {}
    complete = open_streams == 0
    for name in ("stdout", "stderr"):
        raw = _raw(value[name], limit)
        total = _integer(value[name + "_bytes"], name + "_bytes")
        if len(raw) != min(total, limit + 1):
            raise CaptureError("capture byte count contradicts payload")
        complete = complete
        streams[name] = {"base64": value[name], "bytes": len(raw), "total_bytes": total,
                         "sha256": hashlib.sha256(raw).hexdigest()}
    stdout, stderr = (_raw(streams[name]["base64"], limit) for name in ("stdout", "stderr"))
    return dict(capture_version=VERSION, limit_bytes=limit, returncode=returncode,
                process_returncode=process_code, open_streams=open_streams,
                complete=bool(complete), **streams,
                tail=(stdout + stderr)[-TAIL_BYTES:].decode("utf-8", "replace"))


def read_streams(capture):
    """Validate retained evidence and return exact bytes, including incomplete data."""
    keys = {"capture_version", "limit_bytes", "returncode", "process_returncode", "open_streams",
            "complete", "stdout", "stderr", "tail"}
    if not isinstance(capture, dict) or set(capture) != keys or capture["capture_version"] != VERSION:
        raise CaptureError("unknown or incomplete stream evidence")
    limit = _limit(capture["limit_bytes"])
    code = _integer(capture["returncode"], "returncode")
    open_streams = _integer(capture["open_streams"], "open_streams")
    wire = {"version": VERSION, "returncode": code, "open_streams": open_streams,
            "process_returncode": capture["process_returncode"]}
    raw_streams = []
    for name in ("stdout", "stderr"):
        item = capture[name]
        if not isinstance(item, dict) or set(item) != {"base64", "bytes", "total_bytes", "sha256"}:
            raise CaptureError("stream evidence fields missing or unknown")
        raw = _raw(item["base64"], limit)
        if (type(item["bytes"]) is not int or item["bytes"] != len(raw)
                or item["sha256"] != hashlib.sha256(raw).hexdigest()):
            raise CaptureError("stream evidence hash or size mismatch")
        wire[name] = item["base64"]
        wire[name + "_bytes"] = item["total_bytes"]
        raw_streams.append(raw)
    normalized = decode(json.dumps(wire), code, limit)
    if type(capture["complete"]) is not bool or normalized != capture:
        raise CaptureError("stream completeness or display tail contradicts evidence")
    return tuple(raw_streams)
