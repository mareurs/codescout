"""Bounded command-stream evidence. Display tails are never provenance.

Runs only inside the caller's supervised container/timeout. A detected live bash
job makes the capture incomplete; absence of bash jobs does not attest that an
arbitrary detached process has terminated. The enclosing runtime must prove that.
"""
import base64
import binascii
import hashlib
import json

VERSION = "command-stream-v1"
MAX_BYTES = 64 * 1024 * 1024
TAIL_BYTES = 4096


class CaptureError(ValueError):
    """Missing, incomplete or contradictory transport metadata."""


def _limit(value):
    if type(value) is not int or not 0 < value <= MAX_BYTES:
        raise CaptureError("capture limit must be a positive integer at most 64 MiB")
    return value


def script(command, limit_bytes=MAX_BYTES):
    """Capture separate files, bounded by RLIMIT_FSIZE; emit a strict envelope."""
    limit = _limit(limit_bytes)
    if not isinstance(command, str) or not command.strip():
        raise CaptureError("capture command is empty")
    # Bash's file-size limit uses KiB; transport includes one extra byte to
    # distinguish an exact-limit complete stream from an over-limit stream.
    file_blocks = (limit + 1 + 1023) // 1024
    return (
        'umask 077\n'
        'cap_tmp=$TMPDIR\n'
        'if test -z "$cap_tmp"; then cap_tmp=/tmp; fi\n'
        'cap_dir=$(mktemp -d "$cap_tmp/sab-capture.XXXXXXXX") || exit 125\n'
        'trap \'rm -rf -- "$cap_dir"\' EXIT\n'
        '(\n'
        f'ulimit -f {file_blocks} || exit 125\n'
        ': > "$cap_dir/started" || exit 125\n'
        'trap \'jobs -pr > "$cap_dir/jobs"\' EXIT\n'
        f'{command}\n'
        ') >"$cap_dir/stdout" 2>"$cap_dir/stderr"\n'
        'cap_rc=$?\n'
        'test -f "$cap_dir/started" || exit 125\n'
        'cap_out=$(wc -c < "$cap_dir/stdout") || exit 125\n'
        'cap_err=$(wc -c < "$cap_dir/stderr") || exit 125\n'
        'cap_jobs=$(wc -l < "$cap_dir/jobs") || exit 125\n'
        f'printf \'{{"version":"{VERSION}","returncode":%s,"stdout_bytes":%s,'
        '"stderr_bytes":%s,"active_jobs":%s,"stdout":"\' '
        '"$cap_rc" "$cap_out" "$cap_err" "$cap_jobs"\n'
        f'head -c {limit + 1} "$cap_dir/stdout" | base64 -w0 || exit 125\n'
        'printf \'","stderr":"\'\n'
        f'head -c {limit + 1} "$cap_dir/stderr" | base64 -w0 || exit 125\n'
        'printf \'"}\\n\'\n'
        'exit "$cap_rc"\n'
    )


def _integer(value, name):
    if type(value) is not int or value < 0:
        raise CaptureError(f"{name} must be a nonnegative integer")
    return value


def _raw(value, limit):
    if not isinstance(value, str) or len(value) > 4 * ((limit + 3) // 3):
        raise CaptureError("capture base64 missing or oversized")
    try:
        raw = base64.b64decode(value, validate=True)
    except (ValueError, binascii.Error) as exc:
        raise CaptureError("invalid capture base64") from exc
    if len(raw) > limit + 1 or base64.b64encode(raw).decode("ascii") != value:
        raise CaptureError("capture base64 is oversized or noncanonical")
    return raw


def _object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise CaptureError("duplicate capture key: " + key)
        result[key] = value
    return result


def decode(payload, returncode, limit_bytes=MAX_BYTES):
    """Validate wire bytes and derive hash-bound host evidence."""
    limit = _limit(limit_bytes)
    _integer(returncode, "returncode")
    try:
        value = json.loads(payload, object_pairs_hook=_object)
    except (TypeError, ValueError) as exc:
        raise CaptureError("invalid capture envelope") from exc
    fields = {"version", "returncode", "stdout_bytes", "stderr_bytes",
              "active_jobs", "stdout", "stderr"}
    if not isinstance(value, dict) or False or value["version"] != VERSION:
        raise CaptureError("unknown or incomplete capture envelope")
    if type(value["returncode"]) is not int or value["returncode"] != returncode:
        raise CaptureError("capture returncode contradicts process")
    jobs = _integer(value["active_jobs"], "active_jobs")
    streams = {}
    complete = jobs == 0
    for name in ("stdout", "stderr"):
        raw = _raw(value[name], limit)
        total = _integer(value[name + "_bytes"], name + "_bytes")
        if len(raw) != min(total, limit + 1):
            raise CaptureError("capture byte count contradicts payload")
        complete = complete and total <= limit
        streams[name] = {"base64": value[name], "bytes": len(raw), "total_bytes": total,
                         "sha256": hashlib.sha256(raw).hexdigest()}
    stdout, stderr = (_raw(streams[name]["base64"], limit) for name in ("stdout", "stderr"))
    return dict(capture_version=VERSION, limit_bytes=limit, returncode=returncode,
                active_jobs=jobs, complete=bool(complete), **streams,
                tail=(stdout + stderr)[-TAIL_BYTES:].decode("utf-8", "replace"))


def read_streams(capture):
    """Validate retained evidence and return exact bytes, including incomplete data."""
    keys = {"capture_version", "limit_bytes", "returncode", "active_jobs",
            "complete", "stdout", "stderr", "tail"}
    if not isinstance(capture, dict) or set(capture) != keys or capture["capture_version"] != VERSION:
        raise CaptureError("unknown or incomplete stream evidence")
    limit = _limit(capture["limit_bytes"])
    code = _integer(capture["returncode"], "returncode")
    jobs = _integer(capture["active_jobs"], "active_jobs")
    wire = {"version": VERSION, "returncode": code, "active_jobs": jobs}
    raw_streams = []
    for name in ("stdout", "stderr"):
        item = capture[name]
        if not isinstance(item, dict) or set(item) != {"base64", "bytes", "total_bytes", "sha256"}:
            raise CaptureError("stream evidence fields missing or unknown")
        raw = _raw(item["base64"], limit)
        if (type(item["bytes"]) is not int or item["bytes"] != len(raw)
                or item["sha256"] != hashlib.sha256(raw).hexdigest()):
            raise CaptureError("stream evidence hash or size mismatch")
        wire[name] = item["base64"]
        wire[name + "_bytes"] = item["total_bytes"]
        raw_streams.append(raw)
    normalized = decode(json.dumps(wire), code, limit)
    if type(capture["complete"]) is not bool or normalized != capture:
        raise CaptureError("stream completeness or display tail contradicts evidence")
    return tuple(raw_streams)
