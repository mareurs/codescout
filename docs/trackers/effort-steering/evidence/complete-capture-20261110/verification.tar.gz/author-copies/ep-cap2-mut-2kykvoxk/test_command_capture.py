"""Run real bash/coreutils: these tests observe retained bytes, not source strings."""
import base64
import hashlib
import importlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest


class CommandCaptureTests(unittest.TestCase):
    def module(self):
        try:
            return importlib.import_module("command_capture")
        except ModuleNotFoundError:
            self.fail("complete command stream capture is not implemented")

    def run_capture(self, command, limit=16384, timeout=3):
        c = self.module()
        with tempfile.TemporaryDirectory() as directory:
            result = subprocess.run(
                ["bash", "-o", "pipefail", "-c", c.script(command, limit)],
                capture_output=True, text=True, timeout=timeout,
                env=dict(os.environ, TMPDIR=directory))
            self.assertEqual(list(Path(directory).iterdir()), [], "capture left scratch")
        return c, result, c.decode(result.stdout, result.returncode, limit)

    def test_separate_binary_bytes_and_nonzero_exit_survive(self):
        c, result, capture = self.run_capture(
            "printf '\\377A\\000\\033[31m'; printf '\\376B\\r\\n' >&2; exit 7")
        self.assertEqual(result.returncode, 7)
        self.assertEqual(c.read_streams(capture), (b"\xffA\0\x1b[31m", b"\xfeB\r\n"))
        self.assertIs(capture["complete"], True)
        self.assertEqual(capture["returncode"], 7)
        self.assertEqual(capture["capture_version"], "command-stream-v1")
        self.assertEqual(capture["stdout"]["sha256"],
                         hashlib.sha256(b"\xffA\0\x1b[31m").hexdigest())

    def test_header_before_display_tail_is_retained(self):
        c, _, capture = self.run_capture(
            "printf 'capture header\\n'; printf '%05000d' 0; printf '\\nEND\\n'")
        stdout, stderr = c.read_streams(capture)
        self.assertEqual(len(stdout), 5020)
        self.assertTrue(stdout.startswith(b"capture header\n"))
        self.assertTrue(stdout.endswith(b"\nEND\n"))
        self.assertEqual(stderr, b"")
        self.assertNotIn("capture header", capture["tail"])
        self.assertTrue(capture["tail"].endswith("\nEND\n"))

    def test_exact_limit_is_complete_and_one_extra_byte_is_not(self):
        for count, complete in ((32, True), (33, False), (10000, False)):
            with self.subTest(count=count):
                c, _, capture = self.run_capture("printf '%0"+str(count)+"d' 0", limit=32)
                self.assertIs(capture["complete"], complete)
                self.assertLessEqual(len(c.read_streams(capture)[0]), 33)

    def test_stderr_overflow_cannot_borrow_stdout_completeness(self):
        c, _, capture = self.run_capture("printf ok; printf '%05000d' 0 >&2", limit=32)
        self.assertIs(capture["complete"], False)
        self.assertEqual(c.read_streams(capture)[0], b"ok")
        self.assertEqual(len(c.read_streams(capture)[1]), 33)

    def test_bad_or_contradictory_transport_is_refused(self):
        c, result, _ = self.run_capture("printf ok")
        envelope = json.loads(result.stdout)
        for field, value in (("stdout", "***"), ("stdout_bytes", 3),
                             ("stderr_bytes", True), ("returncode", 17),
                             ("complete", True), ("version", "unknown")):
            with self.subTest(field=field):
                data = dict(envelope)
                data[field] = value
                with self.assertRaises(c.CaptureError):
                    c.decode(json.dumps(data), result.returncode, 16384)
        for payload in ("", "[]", "null", "not json", "{}"):
            with self.subTest(payload=payload):
                with self.assertRaises(c.CaptureError):
                    c.decode(payload, 0, 16384)

    def test_evidence_hash_length_and_completeness_are_validated(self):
        c, _, capture = self.run_capture("printf ok")
        for field, value in (("sha256", "0"*64), ("bytes", 3), ("base64", "%%%")):
            changed = json.loads(json.dumps(capture))
            changed["stdout"][field] = value
            with self.subTest(field=field), self.assertRaises(c.CaptureError):
                c.read_streams(changed)
        changed = json.loads(json.dumps(capture))
        changed["complete"] = False
        with self.assertRaises(c.CaptureError):
            c.read_streams(changed)

    def test_invalid_limits_and_boolean_returncodes_are_refused(self):
        c = self.module()
        for value in (0, -1, True, 1.5, 64*1024*1024+1):
            with self.subTest(value=value), self.assertRaises(c.CaptureError):
                c.script("true", value)
        _, result, _ = self.run_capture("true")
        with self.assertRaises(c.CaptureError):
            c.decode(result.stdout, True, 16384)

    def test_missing_scratch_directory_is_a_capture_fault(self):
        c = self.module()
        result = subprocess.run(["bash", "-c", c.script("printf never", 32)],
                                capture_output=True, text=True,
                                env=dict(os.environ,TMPDIR="/nonexistent/ep-capture"))
        self.assertNotEqual(result.returncode, 0)
        with self.assertRaises(c.CaptureError):
            c.decode(result.stdout, result.returncode, 32)

    def test_background_child_does_not_hold_capture_transport_open(self):
        c, result, capture = self.run_capture("sleep 0.5 & printf done; exit 3", timeout=0.3)
        self.assertEqual(result.returncode, 3)
        self.assertEqual(c.read_streams(capture), (b"done", b""))
        self.assertIs(capture["complete"], False, "a live shell job can still write output")
    def test_boolean_exit_one_and_active_job_count_are_not_integers(self):
        c, result, _ = self.run_capture("exit 1")
        with self.assertRaises(c.CaptureError):
            c.decode(result.stdout, True, 16384)
        envelope = json.loads(result.stdout)
        envelope["open_streams"] = True
        with self.assertRaises(c.CaptureError):
            c.decode(json.dumps(envelope), 1, 16384)
    def test_command_artifact_size_is_not_limited_by_output_retention(self):
        c, result, capture = self.run_capture(
            'head -c 4096 /dev/zero > "$TMPDIR/artifact"; '
            'size=$(wc -c < "$TMPDIR/artifact"); rm -f "$TMPDIR/artifact"; printf %s "$size"',
            limit=32)
        self.assertEqual(result.returncode,0)
        self.assertEqual(c.read_streams(capture),(b"4096",b""))
        self.assertIs(capture["complete"],True)
    def test_duplicate_transport_keys_are_refused_even_when_values_agree(self):
        c,result,_=self.run_capture("true")
        duplicate=result.stdout.replace('"version":', '"version":"command-stream-v1","version":',1)
        with self.assertRaises(c.CaptureError):
            c.decode(duplicate,0,16384)

    def test_pipeline_failure_is_not_hidden_by_the_last_command(self):
        c,result,capture=self.run_capture("false | true")
        self.assertEqual(result.returncode,1)
        self.assertEqual(capture["returncode"],1)
        self.assertEqual(c.read_streams(capture),(b"",b""))

    def test_signal_exit_retains_its_measured_process_code(self):
        c,result,capture=self.run_capture('kill -KILL $$')
        self.assertEqual(result.returncode,137)
        self.assertEqual(capture["process_returncode"],-9)
        self.assertEqual(c.read_streams(capture),(b"",b""))


if __name__ == "__main__":
    unittest.main()
