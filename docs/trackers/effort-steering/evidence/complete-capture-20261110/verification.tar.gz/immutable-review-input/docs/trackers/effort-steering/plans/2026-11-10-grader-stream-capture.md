---
id: '8d672ef0b425f5c8'
kind: plan
status: active
title: Prospective grader command stream capture implementation
topic: effort-steering
---

# Prospective Grader Command Stream Capture Implementation Plan

> For agentic workers: use superpowers:executing-plans inline, task by task. The user delegated autonomous execution. Do not replace the main research objective with this instrument correction.

**Goal:** Preserve the command output needed to distinguish captured test text from measurement infrastructure faults.

**Architecture:** Opt-in complete capture for prospective live grading; preserve historical tail-only path. Strict versioned JSON/base64 evidence per command and independent print output. Policy admission follows production wiring and native qualification.

**Tech Stack:** Python stdlib, bash/coreutils in existing Rust task images, pytest.

**Spec:** [Stream provenance report](../reports/2026-11-10-grader-stream-provenance.md), section Prospective capture contract.

## Global constraints

No LLM/provider calls, private candidate regrade, F3 policy change, mutation of frozen evidence, merge or push. Worktree .worktrees/grader-stream-provenance-01a15ca9 starts at f586d35f4. Every meaningful test must first fail against absent/broken behavior; apply mutation probes on independent copies.

## Review focus

Raw binary/ANSI/UTF-8 data, a failed command with complete output, capture-write failure, a background child retaining output descriptors, exact-cap versus excess output, and evidence consistency must be measured through actual shell execution. A successful capture is not successful grading. Keep independent stream boundaries and do not reconstruct scopes from tails.

## Task 1 — Strict bounded command capture

Files: create tools/setup-ab-eval/command_capture.py and test_command_capture.py.

Interface: script(command, limit_bytes) returns bash source; decode(payload, returncode, limit_bytes) returns a step-capture mapping, with capture_version, stdout/stderr base64, lengths, SHA256, complete and tail. read_streams(capture) validates and returns exact stdout/stderr bytes. Malformed envelopes raise CaptureError. Version command-stream-v1. Limit positive integer; at most64MiB per stream for prospective use. The wrapper keeps stdout/stderr separate, limits command-file sizes, records completeness and command returncode, and cleans its own scratch directory.

- [ ] Write real-bash regressions for separated binary output and exit7; output beyond4096bytes; exact cap and over-cap; bad/missing/contradictory envelopes; scratch failure; bounded background-writer behavior.
- [ ] Observe expected RED; implement minimal script/decode/read_streams.
- [ ] Run the new file, then actual guard mutations and fix observed gaps.
- [ ] Preserve commands, red/green outputs and source; source commit only after required review/gate.

## Task 2 — Opt-in production wiring

Files: multilang_control.py, multilang_tasks.py and their tests.

Interfaces: rebuild(...,capture_streams=False), run_tests(...,capture_streams=False), live_grader(...,capture_streams=False). The true path stores complete capture for every rebuild/test/print command, preserves exact independent print parts and writes full grade evidence. False path remains historical replay behavior.

- [ ] Pin consumer-visible source behavior: real command output reaches full grade.json; cap or malformed data produces error; ordering and per-print boundaries survive.
- [ ] Observe RED, wire Task1 at control boundary, keep old suites green.
- [ ] Qualify actual0.9.128 generated-crate capture without model calls.

## Task 3 — Prospective policy admission

Files: grade_policy.py, test_grade_policy.py, measured runner fixture metadata and prospective controller integration where needed.

- [ ] Derive policy inputs from complete stream evidence; refuse missing/contradictory stream proof. Tails cannot award/revoke a verdict.
- [ ] Pin runner version and accepted framing; explicitly refuse ambiguous legacy/nested/unclosed provenance rather than silently pass. Preserve selected statuses and F3 decision.
- [ ] Re-run actual native complete-versus-cut control, multiple commands, top-level faults after captures, UTF-8/ANSI and second-review guard cases.
- [ ] Fresh strong independent review must actually apply mutations and report observed outcomes; then run the prescribed full gate and preserve all evidence.
- [ ] Update tracker readiness and return to the original cohort/controller qualification. No paid admission inferred solely from this correction.
