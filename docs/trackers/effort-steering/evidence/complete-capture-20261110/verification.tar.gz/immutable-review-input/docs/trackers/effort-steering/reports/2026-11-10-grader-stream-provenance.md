---
id: '460728360d3e32ad'
kind: report
status: active
title: Grader stream provenance — native nextest characterization and second review
tags:
- effort-steering
- evaluation
- review
topic: effort-steering
---

# Grader stream provenance

## Current state — 2026-11-10

**Changes required; f586d35f4 is not admitted for a new paid comparison.** Independent reproduction confirms several second-review counterexamples. The failure caused by a cut stderr stream also occurs with the actual nextest version in the provisional Obscura image. No evaluator source was changed in this investigation. The isolated branch is fix/grader-stream-provenance-20261110 at f586d35f4; its worktree is /home/marius/work/claude/codescout/.worktrees/grader-stream-provenance-01a15ca9. The six unrelated runtime-profile WIP files remain on the cf66 branch.

## What was independently verified

Five unchanged evaluator suites give293 passed/180subtests in24.75seconds. Those tests do not establish absence of the reported defects. Running the supplied probe2.py on that exact source independently reproduces: modern cut stderr becoming measurement_invalid; legacy cut stderr becoming compile_failure; a legacy section hiding later top-level ENOSPC; a cut through an ANSI escape becoming compile_failure at each of five tested offsets; and multiple print commands invalidating a genuine selected failure. The nested libtest probe also returns invalid for captured permission text. Review E's particular indented-warning input and the31new mutations were not independently replayed here; the reviewer's22killed/9survived is attributed evidence, not our count.

## Task image versions and native framing

All commands used immutable local image IDs, pull=never, network=none, readonly root, dropped capabilities, no credentials and owned disposable containers. No benchmark task or candidate was executed. The crate below is generated from two independent tests solely to characterize output.

| Image actually inspected | nextest result |
|---|---|
| Obscura provisional dependency image b22988cd6022dd7a428a750799114b9c6f09bcaecc4fd9d8b86a0ef8502772d1 | cargo-nextest0.9.128, commit96bc6d4f4056abd8af1e27f9f18148d0d1f447ae, date2026-02-19 |
| Nushell18863 run/agent image17c4fd82728d1ad59ab92be14ea2e21e213ec4d15f38b9cc700e3ab8d1f38f9e | cargo reports no such command: nextest, rc101 |
| rust-analyzer22992 run image db296171bf8540492772e074d08d0bceecfe0e2444dc99ee5b1808781ea1bc7c | same absence, rc101 |

These are observations of three named images, not all task images or all historical runs. Earlier characterization with host nextest0.9.150 was not a measurement of these images.

The actual Obscura generated-crate run uses --offline --no-fail-fast --message-format libtest-json-plus, returns100, emits separate JSON stdout and indented `output ───` stderr. Its two test events are one pass and one deliberate panic. The panic prints compiler/storage/process-fatal-looking strings after enough padding to exceed4096bytes. Stderr is12502bytes; its final4096bytes lose the capture header.

Applying unchanged f586d35f4 policy to that actual output, with explicit synthetic expected selection and fixture runtime metadata, gives:

| Synthetic selected test | Complete stderr supplied | Actual decoder's4096-byte tail supplied |
|---|---|---|
| Passing test | valid pass | measurement_invalid: planted rustc fatal diagnostic |
| Intentionally failing test | valid test_failure | same measurement_invalid |

This is a native output characterization followed by synthetic policy adjudication. It is not a real candidate's private grade or proof of the full grading wrapper. It establishes that review B does not depend on legacy framing: the installed0.9.128 modern format reproduces it. Legacy framing in these task images remains unobserved.

The first scratch control failed because its probe tmpfs was not writable by the image user; the second failed because rustc's TMPDIR remained on the readonly root. Both failed controls remain preserved. The third explicitly uses a writable probe tmpfs and TMPDIR and reaches the two real test events. Owned-container absence checks succeeded after every version/probe attempt. These temporary failures are not model or benchmark outcomes.

## Mechanism and next bounded change

multilang_control.py retains only the last4096bytes of each test/rebuild command's merged output; the separate print commands provide the parser log. A test command that redirects nextest stdout to a JSON file therefore supplies stderr as an independent tail. grade_policy.contextual_step_output cannot recover its enclosing section by matching it against the unrelated JSON log. Increasing the set of recognized headers cannot reconstruct a discarded header or section boundary.

Revisit the capture contract before another classifier patch: retain separate complete command/print streams within an explicit byte limit, names/order, exact bytes or an unambiguous decoding contract, completeness flags and hashes. Tails remain display data. Register and measure the runner version/format; ambiguous or incomplete provenance must not silently award pass or be selectively discarded. Then qualify the format-specific extraction using actual long captures and injected top-level faults, cut ANSI/UTF-8, multiple print streams, nested output and the review's guard mutations. Complete streams solve the observed information loss; they alone do not prove arbitrary test text cannot mimic a human-output delimiter. That framing trust boundary needs a measured contract too.

F3's missing-status/deletion/abort policy is unchanged and remains an operator decision. F6/F7 are not silently resolved here. The efficacy goal is still open: these are instrument defects, not evidence that low equals xhigh. Freeze all prior outputs and charges; no automatic retry/regrade or new paid run follows from this report.


## Prospective capture contract — implementation choice, 2026-11-10

The operator delegated implementation choices and continued autonomous execution; these details are the implementer's choices, not a claim of individual operator review. Keep the existing frozen tail-only execution path for historical replay. Add an explicit capture_streams option for prospective live grades. A stdlib command_capture module generates a bash wrapper and decodes its strict JSON/base64 envelope. Each stdout/stderr stream carries raw byte length, base64 and SHA256 in host evidence; completeness is explicit, and the last4096decoded bytes remain display-only. Capture limits are enforced and truncation invalidates prospective measurement rather than selecting a different outcome. Decoder errors are control faults, not test failures.

Implement in three independently testable tasks: (1) bounded native command capture and strict evidence validation, (2) opt-in control/live_grader production wiring including each print stream, and (3) prospective policy requiring complete streams and measured runner/framing identity, followed by real nextest long-output controls, actual guard mutations and the full gate. A complete-stream capture by itself is not evaluator readiness. Keep F3 unchanged. No paid run, old receipt rewrite, integration or push follows from a task's unit success.

## Evidence and preservation

[Manifest](../evidence/grader-stream-provenance-20261110/manifest.json), [closure](../evidence/grader-stream-provenance-20261110/closure.json) and [capsule](../evidence/grader-stream-provenance-20261110/verification.tar.gz) preserve41regular members,30616bytes, SHA256758b7cb7c43aa52264f1c17258fd2472370d5493284b980ed24ef3fcd5183bc2. All members were reopened and compared byte-for-byte. The capsule contains the supplied probe, our diagnostic runners, failed/successful controls, stdout/stderr, commands/image IDs, synthetic policy results and exact reviewed source. No credential or model call. The original temporary scratch is /tmp/ep-grader-stream-01a15-20261110; canonical copies are now under this tracker folder.

New host-diagnostic masking bug: [capture lifetime](../../../issues/2026-11-10-grade-policy-capture-hides-later-diagnostics.md). Existing [captured infrastructure bug](../../../issues/2026-11-10-grade-policy-captured-output-invalidates-functional-failure.md) and [guard gap record](../../../issues/2026-11-10-policy-guard-regressions-missing-coherent-inputs.md) have explicit superseding notes. No source fix, new product gate, independent new-mutation replay, merge or push is claimed.
