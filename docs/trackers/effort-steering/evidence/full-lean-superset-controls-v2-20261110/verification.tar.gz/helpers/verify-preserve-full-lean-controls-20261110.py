"""Audit all original selected statuses plus the private specification checks."""
from pathlib import Path
import hashlib,io,json,subprocess,sys,tarfile
sys.dont_write_bytecode=True
W=Path("/home/marius/work/claude/codescout/.worktrees/grader-stream-provenance-01a15ca9")
M=Path("/home/marius/work/claude/codescout")
L=W/".superpowers/sdd/2026-11-10-full-lean-superset-controls-v2"
D=M/"docs/trackers/effort-steering/evidence/full-lean-superset-controls-v2-20261110"
sys.path.insert(0,str(W/"tools/setup-ab-eval"))
import multilang_grade as grade,stream_evidence as streams
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+"\n")
def main():
    reg=json.loads((D/"registration.json").read_text());record=json.loads((L/"full-record.json").read_text())
    data=Path("/home/marius/work/claude/setup-ab-data/live/multilang-rust.jsonl")
    assert sha(data.read_bytes())==reg["original_dataset_sha256"]
    original=next(r for x in data.open() if (r:=json.loads(x)).get("instance_id")==reg["task"])
    assert original["FAIL_TO_PASS"]==reg["original_f2p"] and original["PASS_TO_PASS"]==reg["original_p2p"]
    assert record["FAIL_TO_PASS"]==reg["original_f2p"]+reg["new_f2p"]
    assert record["PASS_TO_PASS"]==reg["original_p2p"]+reg["new_p2p"]
    assert all(record[k]==original[k] for k in ("rebuild_cmds","test_cmds","print_cmds"))
    assert sha((L/"full-record.json").read_bytes())==reg["record_sha256"]
    assert sha(Path("/tmp/qualify-lean-full-superset-20261110.py").read_bytes())==reg["helper_sha256"]
    assert all(sha((W/p).read_bytes())==h for p,h in reg["source_sha256"].items())
    old=reg["original_f2p"]+reg["original_p2p"];new=reg["new_f2p"]+reg["new_p2p"]
    assert len(old)==8587 and len(new)==4 and len(set(old+new))==8591
    controls={};maps={}
    for role in reg["controls"]:
        root=L/role;r=json.loads((root/"result.json").read_text());raw=r["raw"]
        assert not raw.get("error") and raw["expected"]==8591 and raw["missing"]==0
        assert r["complete_stream_contract"] is True and r["applied_source_bytes_verified"] is True and r["source_unchanged"] is True
        assert raw["container_removed"] is True and raw["oom_killed"] is False
        log=Path(raw["log"]);full=json.loads(log.with_name("grade.json").read_text())
        streams.qualify(full,record,log.read_text(),reg["stream_registration"])
        parsed=grade.run_parser(record["log_parser"],log.read_text())
        statuses={k:parsed.get(k) for k in old+new};assert statuses==r["statuses"]
        assert all(v in ("pass","fail") for v in statuses.values())
        failure={k for k,v in statuses.items() if v!="pass"}
        assert failure==(set(reg["new_f2p"]) if role=="base" else set())
        assert raw["not_passing"]==len(failure)
        maps[role]=statuses
        runtime=json.loads((root/"runtime.json").read_text());assert len(runtime)==2
        for item in runtime:
            assert item["inspect_rc"]==item["cgroup_rc"]==0
            cfg=item["inspect"]["HostConfig"]
            assert cfg["Memory"]==cfg["MemorySwap"]==8589934592 and cfg["NanoCpus"]==4000000000
            assert cfg["Init"] is True and cfg["NetworkMode"]=="none"
            assert cfg["CapDrop"]==["ALL"] and cfg["PidsLimit"]==4096
            assert item["inspect"]["Config"]["User"]=="0:0"
            assert not any(m["Type"]=="bind" for m in item["inspect"]["Mounts"])
            assert "oom_kill 0" in item["cgroup"]
        assert runtime[-1]["production_sha256"]==reg["expected_source"]["base" if role=="base" else "reference"]
        p=subprocess.run(["docker","container","inspect",raw["container"]],capture_output=True,text=True,timeout=30)
        assert p.returncode!=0 and "No such container" in p.stderr
        controls[role]={"expected":8591,"old_selected_all_pass":True,"new_statuses":{k:statuses[k] for k in new},
                        "not_passing":len(failure),"missing":0,"wall_seconds":raw["wall_seconds"],
                        "all_step_returncodes":raw["steps"],"complete_streams":True,
                        "actual_source_hashes":True,"runtime_limits_init_and_no_host_binds":True,
                        "oom_zero":True,"fresh_container_absence":True,"log_sha256":sha(log.read_bytes())}
    assert maps["reference"]==maps["reference-repeat"]
    proof={"scope":"Lean full acceptance-superset controls only","original_expected_count":8587,"new_expected_count":4,
           "controls":controls,"reference_repeat_selected_maps_identical":True,
           "native_negative_positive_repeat_predicates_satisfied":True,"original_dataset_and_expected_arrays_unchanged":True,
           "host_resource_floor_qualified":False,"whole_pair_or_actor_admitted":False,"paid_ready":False}
    members={};origins={}
    def add(name,path):
        assert not path.is_symlink(),str(path)
        assert name not in members
        members[name]=path.read_bytes();origins[name]=path
    for label,root in (("native-controls",L),("original-reference-source-binding",Path(reg["binding_source_root"]))):
        for p in sorted(root.rglob("*")):
            if p.is_file() and "__pycache__" not in p.parts:add(label+"/"+str(p.relative_to(root)),p)
    for p in (W/"tools/setup-ab-eval").iterdir():
        if p.is_file() and p.suffix in (".py",".sh"):add("grader-source/"+p.name,p)
    for name in ("qualify-lean-full-superset-20261110.py","qualify-lean-full-superset-20261110.failed-v1.py",Path(__file__).name):
        add("helpers/"+name,Path("/tmp")/name)
    add("failed-registration-v1.json",M/"docs/trackers/effort-steering/evidence/full-lean-superset-controls-v1-20261110/registration-failure.json")
    add("registration.json",D/"registration.json")
    for handle in ("d8","d9","da"):
        p=Path("/tmp/codescout-bg/532382-bfc3fc33-bg_000000"+handle+".json");add("jobs/"+p.name,p)
    members["root-audit.json"]=(json.dumps(proof,indent=2,sort_keys=True)+"\n").encode()
    members["member-manifest.json"]=(json.dumps({n:{"bytes":len(b),"sha256":sha(b)} for n,b in sorted(members.items())},indent=2,sort_keys=True)+"\n").encode()
    archive=D/"verification.tar.gz";assert not archive.exists()
    with tarfile.open(archive,"w:gz") as tar:
        for n,b in sorted(members.items()):
            item=tarfile.TarInfo(n);item.size=len(b);item.mode=0o600;item.mtime=0;tar.addfile(item,io.BytesIO(b))
    with tarfile.open(archive) as tar:
        items=tar.getmembers();assert all(i.isfile() for i in items)
        recovered={i.name:tar.extractfile(i).read() for i in items}
    assert recovered==members and all(origins[n].read_bytes()==members[n] for n in origins)
    closure={"schema":1,"proof":proof,"paid_ready":False,"experimental_model_repair_calls":0,
             "archive":{"sha256":sha(archive.read_bytes()),"bytes":archive.stat().st_size,"regular_members":len(members),
                        "all_members_reopened_byte_equal":True,"all_origin_bytes_unchanged_during_seal":True},
             "retained_prior_oracle_archive_sha256":reg["prior_oracle_archive_sha256"],
             "known_limits":["Obscura fixture/source binding unqualified","host resource floor not qualified",
                             "F6 linker classification","whole actor/context/runtime/controller/accounting and final review pending",
                             "no low/xhigh efficacy observation"]}
    put(D/"closure.json",closure);print(json.dumps(closure,indent=2))
if __name__=="__main__":main()
