"""Prospective full original Lean population AND reviewed private oracle controls."""
from pathlib import Path
import sys,json,hashlib,difflib,time,subprocess
W=Path("/home/marius/work/claude/codescout/.worktrees/grader-stream-provenance-01a15ca9")
L=W/".superpowers/sdd/2026-11-10-full-lean-superset-controls"
M=Path("/home/marius/work/claude/codescout")
D=M/"docs/trackers/effort-steering/evidence/full-lean-superset-controls-v1-20261110"
P=Path("/home/marius/.cache/codescout-resident/codescout/evidence-cohort-20261110/common-lean-ctx-1168-v1/project")
DATA=Path("/home/marius/work/claude/setup-ab-data/live/multilang-rust.jsonl")
IMAGE="sha256:b72f902d24c0a54516e4ef242d8218805f0ea3dc1d26ac809140979ba1f51d56"
sys.path.insert(0,str(W/"tools/setup-ab-eval"))
import multilang_tasks as tasks,multilang_grade as grade
import stream_evidence as streams
TID="yvgude__lean-ctx-1168"
PREFIX="proxy::forward::tests::effort_status_oracle::"
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,value):p.write_text(json.dumps(value,indent=2,sort_keys=True)+"\n")
def source_hashes():return {str(p.relative_to(W)):sha(p.read_bytes()) for p in (W/"tools/setup-ab-eval").glob("*.py")}
def record():
    assert sha(DATA.read_bytes())=="bf2dd8252a07d0f275663ef8f6ab87571dd9bc4ce386abf9ec98d3cd6bb51a81"
    return next(r for line in DATA.open() if (r:=json.loads(line)).get("instance_id")==TID)
def register():
    import tarfile
    assert not D.exists() and not L.exists()
    D.mkdir();L.mkdir()
    prior=M/"docs/trackers/effort-steering/evidence/spec-superset-oracle-v1-20261110"
    closure=json.loads((prior/"closure.json").read_text())
    archive=prior/"verification.tar.gz"
    assert sha(archive.read_bytes())==closure["archive"]["sha256"]
    original=record()
    with tarfile.open(archive) as tar:
        oracle=tar.extractfile("submitted/effort_status_oracle.rs").read()
        supplement=tar.extractfile("submitted/supplement.patch").read()
        oldreg=json.loads(tar.extractfile("registration.json").read())
        expected_source={}
        for role in ("base","reference"):
            packet=json.loads(tar.extractfile("review-evidence/evidence/"+role+"/container-source-sha256.json").read())
            assert packet["returncode"]==0
            expected_source[role]={line.split(maxsplit=1)[1].strip():line.split()[0] for line in packet["stdout"].splitlines()}
        reference_patch=tar.extractfile("review-evidence/evidence/reference/candidate.patch").read()
    assert sha(oracle)==oldreg["oracle_sha256"]
    assert sha(supplement)==oldreg["supplement_sha256"]
    assert sha(original["patch"].encode())==sha(reference_patch)
    assert source_hashes()==oldreg["source_sha256"]
    (L/"effort_status_oracle.rs").write_bytes(oracle)
    (L/"supplement.patch").write_bytes(supplement)
    derived=dict(original)
    derived["test_patch"]=original["test_patch"]+"\n"+supplement.decode()
    extra_f2p=[PREFIX+"status_"+str(s)+"_survives_repeated_request" for s in (400,429,500)]
    extra_p2p=[PREFIX+"status_200_preserves_body_and_cache"]
    derived["FAIL_TO_PASS"]=original["FAIL_TO_PASS"]+extra_f2p
    derived["PASS_TO_PASS"]=original["PASS_TO_PASS"]+extra_p2p
    expected=derived["FAIL_TO_PASS"]+derived["PASS_TO_PASS"]
    assert len(expected)==8591 and len(set(expected))==8591
    assert len(original["FAIL_TO_PASS"]+original["PASS_TO_PASS"])==8587
    assert all(derived[k]==original[k] for k in ("rebuild_cmds","test_cmds","print_cmds"))
    assert not set(tasks.tasks.patch_files(supplement.decode()))&set(tasks.tasks.patch_files(original["patch"]))
    put(L/"full-record.json",derived)
    reg={"schema":1,"task":TID,"scope":"full original selected Lean population AND reviewed specification oracle",
         "acceptance_version":"original-selected-population AND specification-oracle-v1",
         "old_admission_unchanged":True,"original_dataset_sha256":sha(DATA.read_bytes()),
         "original_record_canonical_sha256":sha(json.dumps(original,sort_keys=True).encode()),
         "original_expected_sha256":sha(json.dumps([original["FAIL_TO_PASS"],original["PASS_TO_PASS"]],sort_keys=True).encode()),
         "record_sha256":sha((L/"full-record.json").read_bytes()),
         "source_sha256":source_hashes(),"oracle_sha256":sha(oracle),"supplement_sha256":sha(supplement),
         "helper_sha256":sha(Path(__file__).read_bytes()),"prior_oracle_archive_sha256":sha(archive.read_bytes()),
         "controls":["base","reference","reference-repeat"],"image":IMAGE,"step_timeout_s":900,
         "runtime":{"user":"0:0","network":"none","cpus":4,"memory":"8g","memory_swap":"8g","init":True},
         "original_f2p":original["FAIL_TO_PASS"],"original_p2p":original["PASS_TO_PASS"],
         "new_f2p":extra_f2p,"new_p2p":extra_p2p,"expected_total":8591,
         "expected_source":expected_source,
         "stream_registration":{"version":streams.VERSION,"commands_sha256":streams.commands_digest(derived),
                                "tests":[{"profile":streams.LIB,"reports":[0],"stderr_files":["rust/1"]}]},
         "experimental_model_calls":0,"original_full_expected_population_executed":False,
         "host_resource_floor_qualified":False,"paid_ready":False,
         "decision":"base original tests plus200 case must pass, new400/429/500 must fail; reference/repeat all8591pass and identical selected maps; preserve every outcome, no paid or pair admission"}
    put(D/"registration.json",reg);put(L/"registration.json",reg)
    print(json.dumps({"registration":str(D/"registration.json"),"expected":8591,"paid_ready":False}))
def run(role):
    reg=json.loads((D/"registration.json").read_text());assert role in reg["controls"]
    assert source_hashes()==reg["source_sha256"]
    assert sha(Path(__file__).read_bytes())==reg["helper_sha256"]
    assert sha((L/"effort_status_oracle.rs").read_bytes())==reg["oracle_sha256"]
    assert sha((L/"full-record.json").read_bytes())==reg["record_sha256"]
    r=json.loads((L/"full-record.json").read_text())
    original=record()
    for key in ("rebuild_cmds","test_cmds","print_cmds"):
        assert r[key]==original[key]
    assert r["FAIL_TO_PASS"]==original["FAIL_TO_PASS"]+reg["new_f2p"]
    assert r["PASS_TO_PASS"]==original["PASS_TO_PASS"]+reg["new_p2p"]
    out=L/role;out.mkdir(exist_ok=False)
    observations=[];docker=tasks.pilot.docker
    def observe(name,stage):
        item={"container":name,"stage":stage,"at":time.time()}
        try:
            p=docker("inspect",name,check=False,timeout=120)
            item["inspect_rc"]=p.returncode
            if p.returncode==0:item["inspect"]=json.loads(p.stdout)[0]
            p=docker("exec",name,"sh","-c","for f in /sys/fs/cgroup/memory.events /sys/fs/cgroup/memory.max /sys/fs/cgroup/memory.swap.max /sys/fs/cgroup/cpu.max; do printf '%s\\n' \"$f\"; cat \"$f\"; done",check=False,timeout=120)
            item["cgroup_rc"]=p.returncode;item["cgroup"]=p.stdout;item["cgroup_stderr"]=p.stderr
            if stage=="before-remove":
                paths=list(reg["expected_source"]["base" if role=="base" else "reference"])
                p=docker("exec",name,"sha256sum",*paths,check=False,timeout=120)
                item["production_sha_rc"]=p.returncode
                item["production_sha_stdout"]=p.stdout;item["production_sha_stderr"]=p.stderr
                if p.returncode==0:item["production_sha256"]={line.split(maxsplit=1)[1].strip():line.split()[0] for line in p.stdout.splitlines()}
        except Exception as e:item["error"]=repr(e)
        observations.append(item);put(out/"runtime.json",observations)
    def tracked(*args,**kwargs):
        if args and args[0]=="run":
            args=("run","--user","0:0","--memory-swap","8g","--init",*args[1:])
        if args and args[0]=="rm":
            for a in args[1:]:
                if isinstance(a,str) and a.startswith(tasks.GRADE_PREFIX):observe(a,"before-remove")
        result=docker(*args,**kwargs)
        if args and args[0]=="run" and result.returncode==0:observe(args[args.index("--name")+1],"after-start")
        return result
    tasks.pilot.docker=tracked;tasks.GRADE_STEP_TIMEOUT=reg["step_timeout_s"]
    bundle={"workdir":"/testbed","expected":{"fail_to_pass":len(r["FAIL_TO_PASS"]),"pass_to_pass_kept":len(r["PASS_TO_PASS"]),"dropped":[],"fail_to_pass_dropped":[]}}
    grader=tasks.live_grader(r,bundle,IMAGE,out,capture_streams=True,diagnostic_artifacts={0:["rust/1"]})
    raw=grader("" if role=="base" else r["patch"],role)
    result={"role":role,"raw":raw,"paid_ready":False,"original_full_expected_population_executed":True}
    p=Path(raw.get("log",""))
    if p.is_file():
        log=p.read_text();full=json.loads(p.with_name("grade.json").read_text())
        statuses=grade.run_parser(r["log_parser"],log)
        result["statuses"]={k:statuses.get(k) for k in r["FAIL_TO_PASS"]+r["PASS_TO_PASS"]}
        try:
            diagnostics=streams.qualify(full,r,log,reg["stream_registration"])
            result["complete_stream_contract"]=True;result["diagnostics"]=diagnostics
        except streams.EvidenceError as e:
            result["complete_stream_contract"]=False;result["stream_error"]=str(e)
    p=subprocess.run(["docker","container","inspect",raw["container"]],capture_output=True,text=True,timeout=30)
    result["fresh_container_absent"]=p.returncode!=0 and "No such container" in p.stderr
    result["source_unchanged"]=source_hashes()==reg["source_sha256"]
    expected_source=reg["expected_source"]["base" if role=="base" else "reference"]
    result["applied_source_bytes_verified"]=any(o.get("stage")=="before-remove" and o.get("production_sha256")==expected_source for o in observations)
    put(out/"result.json",result)
    print(json.dumps({"role":role,"raw":raw,"complete_stream_contract":result.get("complete_stream_contract"),
                      "applied_source_bytes_verified":result["applied_source_bytes_verified"],"paid_ready":False},indent=2))
if __name__=="__main__":
    if sys.argv[1]=="register":register()
    else:run(sys.argv[1])
