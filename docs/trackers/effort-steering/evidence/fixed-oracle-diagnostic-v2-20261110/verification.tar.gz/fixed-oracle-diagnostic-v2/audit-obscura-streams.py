"""Audit actual nextest stream framing only; no runtime/paid admission inference."""
from pathlib import Path
import sys,json,hashlib
W=Path("/home/marius/work/claude/codescout/.worktrees/grader-stream-provenance-01a15ca9")
sys.path.insert(0,str(W/"tools/setup-ab-eval"))
import stream_evidence as s,command_capture as c,grade_policy as p
root=W/".superpowers/sdd/2026-11-10-grader-stream-capture/fixed-oracle-diagnostic-v2"
tid="h4ckf0r0day__obscura-421"
dataset=Path("/home/marius/work/claude/setup-ab-data/live/multilang-rust.jsonl")
record=next(r for line in dataset.open() if (r:=json.loads(line)).get("instance_id")==tid)
reg={"version":s.VERSION,"commands_sha256":s.commands_digest(record),"tests":[{"profile":s.NEXT,"reports":[0],"stderr_files":[]}]}
results=json.loads((root/tid/"results.json").read_text());assert len(results)==3
out=[]
for result in results:
    logpath=Path(result["raw"]["log"]);full=json.loads(logpath.with_name("grade.json").read_text())
    log=logpath.read_text()
    diagnostics=s.qualify(full,record,log,reg)
    step=next(x for x in full["steps"] if x["name"]=="grade:test[0]")
    stdout,stderr=c.read_streams(step["capture"])
    text=stderr.decode("utf-8")
    frames=[line for line in text.splitlines() if any(x in line for x in ("STDOUT:","STDERR:","OUTPUT:","output ─","stdout ─","stderr ─"))]
    out.append({"control":result["name"],"qualified_complete_streams":True,
                "report_sha256":hashlib.sha256(logpath.read_bytes()).hexdigest(),
                "test_stdout_bytes":len(stdout),"test_stderr_bytes":len(stderr),
                "observed_frame_headers":frames,
                "diagnostic_bytes":{k:len(v.encode()) for k,v in diagnostics.items()},
                "host_infrastructure_issues":{k:p.infrastructure_issue(v) for k,v in diagnostics.items()},
                "compiler_diagnostics":{k:p.compiler_diagnostic(v) for k,v in diagnostics.items()},
                "f2p":result["f2p_statuses"],"raw_not_passing":result["raw"]["not_passing"],
                "raw_missing":result["raw"]["missing"]})
audit={"scope":"actual nextest complete framing/provenance only, not full runtime or private admission",
       "registered":reg,"controls":out,"experimental_model_calls":0,"paid_ready":False}
(root/tid/"stream-contract-audit.json").write_text(json.dumps(audit,indent=2,sort_keys=True)+"\n")
print(json.dumps(audit,indent=2))
