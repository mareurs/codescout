"""Await the owned registered control, then seal completed evidence without deletion."""
from pathlib import Path
import subprocess,json,hashlib,io,tarfile
W=Path("/home/marius/work/claude/codescout/.worktrees/grader-stream-provenance-01a15ca9")
L=W/".superpowers/sdd/2026-11-10-grader-stream-capture"
M=Path("/home/marius/work/claude/codescout")
D=M/"docs/trackers/effort-steering/evidence/fixed-oracle-diagnostic-v2-20261110"
# Wait only for our known control-job PID, never a process-name expression.
subprocess.run(["tail","--pid=3279766","-f","/dev/null"],timeout=3600,check=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+"\n")
reg=json.loads((D/"registration.json").read_text())
assert all(sha((W/p).read_bytes())==h for p,h in reg["source_sha256"].items())
tasks={}
for tid in reg["selected_ids"]:
    root=L/"fixed-oracle-diagnostic-v2"/tid
    terminal=json.loads((root/"terminal.json").read_text())
    assert terminal["controls_completed"]==3 and terminal["source_unchanged"] is True
    results=json.loads((root/"results.json").read_text());assert len(results)==3
    f2p=list(results[0]["f2p_statuses"])
    selected=set(results[0]["selected_statuses"]);p2p=selected-set(f2p)
    assert len(selected)==reg["records"][tid]["f2p"]+reg["records"][tid]["p2p"]
    summary=[]
    for r in results:
        assert set(r["selected_statuses"])==selected
        raw=r["raw"]
        absent=subprocess.run(["docker","container","inspect",raw["container"]],capture_output=True,text=True,timeout=30)
        assert absent.returncode!=0 and "No such container" in absent.stderr
        summary.append({"control":r["name"],"raw_pass":raw["pass"],"error":raw.get("error"),
                        "expected":raw.get("expected"),"missing":raw.get("missing"),
                        "not_passing":raw.get("not_passing"),"f2p":r["f2p_statuses"],
                        "p2p_not_pass":{k:r["selected_statuses"][k] for k in sorted(p2p) if r["selected_statuses"][k]!="pass"},
                        "log_sha256":r["log_sha256"],"container_removed":raw["container_removed"],
                        "fresh_absence_confirmed":True,"wall_seconds":raw["wall_seconds"]})
    base=results[0];refs=results[1:]
    predicates={"base_all_f2p_fail":all(base["selected_statuses"][k]=="fail" for k in f2p),
                "base_all_p2p_pass":all(base["selected_statuses"][k]=="pass" for k in p2p),
                "references_all_selected_pass":all(all(v=="pass" for v in r["selected_statuses"].values()) for r in refs),
                "reference_repeat_selected_equal":refs[0]["selected_statuses"]==refs[1]["selected_statuses"],
                "all_expected_statuses_present":all(all(v is not None for v in r["selected_statuses"].values()) for r in results),
                "all_controls_setup_error_free":all(not r["raw"].get("error") for r in results)}
    tasks[tid]={"controls":summary,"diagnostic_predicates":predicates,
                "admitted":all(predicates.values())}
members={}
def add(name,p):
    p=Path(p)
    assert not p.is_symlink()
    members[name]=p.read_bytes()
for dirname in ("fixed-oracle-diagnostic-v1","fixed-oracle-diagnostic-v2","orphan-reaping-probe-v1","exact-reaping-probe-v1"):
    for p in (L/dirname).rglob("*"):
        if p.is_file() and "__pycache__" not in p.parts:add(dirname+"/"+str(p.relative_to(L/dirname)),p)
for p in (W/"tools/setup-ab-eval").iterdir():
    if p.is_file() and p.suffix in (".py",".sh"):add("grader-source/"+p.name,p)
for name in ("qualify-fixed-oracle-diagnostic-20261110.py","qualify-fixed-oracle-diagnostic-v2-20261110.py",
             "audit-fixed-oracle-obscura-streams-20261110.py","probe-effort-orphan-reaping-20261110.py",
             "probe-effort-exact-reaping-test-20261110.py","preserve-fixed-oracle-diagnostic-20261110.py"):
    add("helpers/"+name,Path("/tmp")/name)
for handle in ("c3","c4","c5","c6","c7","c8"):
    p=Path("/tmp/codescout-bg/532382-bfc3fc33-bg_000000"+handle+".json");add("job-records/"+p.name,p)
members["member-manifest.json"]=(json.dumps({n:{"bytes":len(b),"sha256":sha(b)} for n,b in sorted(members.items())},indent=2,sort_keys=True)+"\n").encode()
archive=D/"verification.tar.gz"
assert not archive.exists()
with tarfile.open(archive,"w:gz") as tar:
    for n,b in sorted(members.items()):
        item=tarfile.TarInfo(n);item.size=len(b);item.mode=0o600;item.mtime=0
        tar.addfile(item,io.BytesIO(b))
with tarfile.open(archive,"r:gz") as tar:
    reread={i.name:tar.extractfile(i).read() for i in tar.getmembers() if i.isfile()}
assert reread==members
assert all(sha((W/p).read_bytes())==h for p,h in reg["source_sha256"].items())
closure={"schema":1,"scope":"fixed-task diagnostic only; no full runtime/paid admission",
         "tasks":tasks,"pair_admitted":all(t["admitted"] for t in tasks.values()),
         "paid_ready":False,"experimental_model_calls":0,"model_arm_results":[],
         "registration_sha256":sha((D/"registration.json").read_bytes()),
         "source_unchanged":True,"expected_sets_changed":False,"tasks_replaced":False,
         "archive":{"sha256":sha(archive.read_bytes()),"bytes":archive.stat().st_size,
                    "regular_members":len(members),"reopened_all_bytes_equal":True},
         "retained_outside_archive":["416520576-byte exact reaping binary at /tmp/effort-reaping-binary-01a15ca9/lean-tests; hash in probe registration",
                                    "original frozen dataset and task images",
                                    "native input/build caches"],
         "known_limits":["no host resource-floor qualification","network service positive control absent",
                         "same-binary init fixes one test, not whole suite",
                         "no model efficacy or charge reconciliation"]}
put(D/"closure.json",closure)
print(json.dumps(closure,indent=2))
