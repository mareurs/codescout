"""Same actual Rust test binary and image; only Docker --init differs."""
from pathlib import Path
import hashlib,json,subprocess
W=Path("/home/marius/work/claude/codescout/.worktrees/grader-stream-provenance-01a15ca9")
D=W/".superpowers/sdd/2026-11-10-grader-stream-capture/exact-reaping-probe-v1"
D.mkdir(exist_ok=False)
binary=Path("/tmp/effort-reaping-binary-01a15ca9/lean-tests")
image="sha256:b72f902d24c0a54516e4ef242d8218805f0ea3dc1d26ac809140979ba1f51d56"
test="shell::exec::exec_tests::wait_with_limits_group_kill_reaps_grandchildren"
reg={"schema":1,"image":image,"binary":str(binary),"binary_bytes":binary.stat().st_size,
     "binary_sha256":hashlib.sha256(binary.read_bytes()).hexdigest(),
     "binary_origin":"read-only copy from registered live reference container82751f6ed584; copied while tests run, no source/runtime mutation",
     "test":test,"conditions":[False,True],"only_changed_launch_flag":"--init",
     "claim_limit":"one selected P2P runtime symptom only; no complete suite/F2P or paid admission",
     "experimental_model_calls":0,"paid_ready":False}
(D/"registration.json").write_text(json.dumps(reg,indent=2)+"\n")
results=[]
for init in reg["conditions"]:
    name="ep-exact-reap-"+("init" if init else "noinit")+"-01a15ca9"
    args=["docker","run","-d","--name",name,"--network","none","--user","0:0","--cpus","4","--memory","8g","--memory-swap","8g","--pids-limit","4096","--cap-drop","ALL","--security-opt","no-new-privileges","--mount","type=bind,source="+str(binary)+",target=/qualify/lean-tests,readonly"]
    if init:args+=["--init"]
    args+=[image,"sleep","infinity"]
    r={"init":init,"argv":args}
    try:
        p=subprocess.run(args,capture_output=True,text=True,timeout=60);r["start_rc"]=p.returncode;r["start_stderr"]=p.stderr
        if p.returncode:raise RuntimeError("start failed")
        p=subprocess.run(["docker","inspect",name],capture_output=True,text=True,timeout=30)
        (D/("inspect-init.json" if init else "inspect-noinit.json")).write_text(p.stdout)
        p=subprocess.run(["docker","exec",name,"/qualify/lean-tests","--exact",test,"--nocapture"],capture_output=True,text=True,timeout=30)
        r.update({"test_rc":p.returncode,"stdout":p.stdout,"stderr":p.stderr})
    except Exception as exc:r["error"]=repr(exc)
    finally:
        p=subprocess.run(["docker","rm","-f",name],capture_output=True,text=True,timeout=60);r["cleanup_rc"]=p.returncode
        p=subprocess.run(["docker","container","inspect",name],capture_output=True,text=True,timeout=30)
        r["absent"]=p.returncode!=0 and "No such container" in p.stderr
    results.append(r)
(D/"results.json").write_text(json.dumps(results,indent=2)+"\n")
assert hashlib.sha256(binary.read_bytes()).hexdigest()==reg["binary_sha256"]
print(json.dumps({"registration":reg,"results":results},indent=2))
