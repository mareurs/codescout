"""Bounded process lifecycle diagnostic only; no source patch or provider calls."""
from pathlib import Path
import json,hashlib,subprocess,time,io,tarfile
W=Path("/home/marius/work/claude/codescout/.worktrees/grader-stream-provenance-01a15ca9")
D=W/".superpowers/sdd/2026-11-10-grader-stream-capture/orphan-reaping-probe-v1"
D.mkdir(exist_ok=False)
image="sha256:b72f902d24c0a54516e4ef242d8218805f0ea3dc1d26ac809140979ba1f51d56"
probe="""import subprocess,os,signal,time,json
p=subprocess.Popen(["sh","-c","sleep 30 & sleep 30"],start_new_session=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
time.sleep(.2);os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
observations=[]
for _ in range(50):
    try:os.killpg(p.pid,0);exists=True
    except ProcessLookupError:exists=False
    if not exists:break
    time.sleep(.02)
for name in os.listdir("/proc"):
    if not name.isdigit():continue
    try:
        text=open("/proc/"+name+"/stat").read();parts=text[text.rfind(")")+2:].split()
        if int(parts[2])==p.pid:observations.append({"pid":int(name),"state":parts[0],"ppid":int(parts[1]),"pgrp":int(parts[2])})
    except (OSError,ValueError,IndexError):pass
print(json.dumps({"process_group":p.pid,"group_exists_after_grace":exists,"group_processes":observations}))
"""
reg={"schema":1,"image":image,"conditions":[False,True],"only_changed_launch_flag":"--init",
     "probe_sha256":hashlib.sha256(probe.encode()).hexdigest(),"expected":"if orphan zombies cause the selected reaping symptom, no-init retains group while init removes it",
     "selected_task_source_modified":False,"experimental_model_calls":0,"paid_ready":False}
(D/"registration.json").write_text(json.dumps(reg,indent=2)+"\n");(D/"probe.py").write_text(probe)
results=[]
for init in reg["conditions"]:
    name="ep-orphan-probe-"+("init" if init else "noinit")+"-01a15ca9"
    args=["docker","run","-d","--name",name,"--network","none","--user","0:0","--cpus","4","--memory","8g","--memory-swap","8g","--pids-limit","4096","--cap-drop","ALL","--security-opt","no-new-privileges"]
    if init:args+=["--init"]
    args += [image,"sleep","infinity"]
    item={"init":init,"argv":args}
    try:
        p=subprocess.run(args,capture_output=True,text=True,timeout=60);item["start_rc"]=p.returncode;item["start_stderr"]=p.stderr
        if p.returncode:raise RuntimeError("start failed")
        p=subprocess.run(["docker","inspect",name],capture_output=True,text=True,timeout=30)
        (D/("inspect-init.json" if init else "inspect-noinit.json")).write_text(p.stdout)
        p=subprocess.run(["docker","exec",name,"python3","-c",probe],capture_output=True,text=True,timeout=30)
        item.update({"probe_rc":p.returncode,"stdout":p.stdout,"stderr":p.stderr})
        if p.returncode==0:item["result"]=json.loads(p.stdout)
    except Exception as e:item["error"]=repr(e)
    finally:
        p=subprocess.run(["docker","rm","-f",name],capture_output=True,text=True,timeout=60)
        item["cleanup_rc"]=p.returncode
        p=subprocess.run(["docker","container","inspect",name],capture_output=True,text=True,timeout=30)
        item["absent"]=p.returncode!=0 and "No such container" in p.stderr
    results.append(item)
(D/"results.json").write_text(json.dumps(results,indent=2)+"\n")
print(json.dumps({"path":str(D),"results":results},indent=2))
