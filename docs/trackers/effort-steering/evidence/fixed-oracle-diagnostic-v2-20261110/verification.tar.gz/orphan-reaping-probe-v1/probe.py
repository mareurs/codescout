import subprocess,os,signal,time,json
p=subprocess.Popen(["sh","-c","sleep 30 & sleep 30"],start_new_session=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
time.sleep(.2);os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
observations=[]
for _ in range(50):
    try:os.killpg(p.pid,0);exists=True
    except ProcessLookupError:exists=False
    if not exists:break
    time.sleep(.02)
for name in os.listdir("/proc"):
    if not name.isdigit():continue
    try:
        text=open("/proc/"+name+"/stat").read();parts=text[text.rfind(")")+2:].split()
        if int(parts[2])==p.pid:observations.append({"pid":int(name),"state":parts[0],"ppid":int(parts[1]),"pgrp":int(parts[2])})
    except (OSError,ValueError,IndexError):pass
print(json.dumps({"process_group":p.pid,"group_exists_after_grace":exists,"group_processes":observations}))
