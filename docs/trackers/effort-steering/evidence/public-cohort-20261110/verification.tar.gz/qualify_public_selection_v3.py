"""Public metadata only; preserve v1 and failed helper v2."""
import copy
import hashlib
import json
import sys
from pathlib import Path

RESEARCH = Path("/home/marius/.codex/worktrees/cf66/codescout")
RESIDENT = Path("/home/marius/.cache/codescout-resident/codescout/evidence-cohort-20261110")
OUT = Path(__file__).parent / "public-selection-v3"

def main():
    sys.path.insert(0, str(RESEARCH / "tools/effort_protocol"))
    from campaign import selection_report
    from execution_profiles import profile_digest, runtime_contract, validate_runtime_profile
    OUT.mkdir(exist_ok=False)
    names = ["selection-rule.json", "metadata-universe.json", "exposure-exclusions.json",
             "qualification-status-v1.json", "provisional-selection-v1.json",
             "datafusion-registry-image-config.json",
             "remaining-registry-image-config/delta-io__delta-rs-4358.stdout",
             "remaining-registry-image-config/delta-io__delta-rs-4358.receipt.json"]
    evidence = {}
    data = {}
    for name in names:
        raw = (RESIDENT / name).read_bytes()
        evidence[name] = {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}
        data[name] = json.loads(raw)
        dst = OUT / "inputs" / name
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(raw)
    status = copy.deepcopy(data[names[3]])
    contract = runtime_contract("cargo-v1")
    probes = []
    for task, name in [("apache__datafusion-21121", names[5]), ("delta-io__delta-rs-4358", names[6])]:
        volumes = data[name]["config"]["Volumes"]
        assert "/testbed/mnt_tmp" in volumes
        source, build = "/owned/source", "/owned/build"
        row = {
            "HostConfig": {k: v for k, v in contract.items() if k not in ("BuildMounts", "SourceMount", "Environment")},
            "Config": {"User": "1000:1000", "Env": [k+"="+v for k,v in contract["Environment"].items()]},
            "Mounts": [
                {"Type": "bind", "Destination": "/testbed", "Source": source, "RW": False},
                {"Type": "bind", "Destination": "/build", "Source": build, "RW": True},
                {"Type": "bind", "Destination": "/mnt_tmp", "Source": build+"/scratch", "RW": True},
                {"Type": "tmpfs", "Destination": "/tmp"},
            ]}
        assert validate_runtime_profile(row, source, build, "cargo-v1") == contract
        row["Mounts"].append({"Type": "volume", "Destination": "/testbed/mnt_tmp", "RW": True})
        try:
            validate_runtime_profile(row, source, build, "cargo-v1")
        except Exception as exc:
            observed = str(exc)
            assert "unexpected runtime mount" in observed, observed
        else:
            raise AssertionError("unsupported declared mount accepted")
        status[task] = {"eligible": False, "reason": "cargo-v1 rejects image-declared writable volume /testbed/mnt_tmp; public metadata adapter incompatibility"}
        probes.append({"id": task, "config_sha256": evidence[name]["sha256"], "volumes": volumes,
                       "compatible_inspection": "accepted", "declared_volume_inspection": observed,
                       "probe_scope": "synthetic inspect plus actual image metadata; no container run"})
    # Status carries auxiliary public evidence; selector accepts only registered public fields.
    rows = [{**r, "eligible": status[r["id"]]["eligible"], "reason": status[r["id"]]["reason"]}
            for r in data[names[1]]["tasks"]]
    report = selection_report(rows, set(data[names[2]]["tasks"]), data[names[0]]["seed"])
    assert report["selected"] == [] and report["complete"] is False
    changed = [k for k in status if status[k] != data[names[3]][k]]
    assert set(changed) == {"apache__datafusion-21121", "delta-io__delta-rs-4358"}
    receipt = {"inputs": evidence, "changed": changed, "probes": probes,
               "profile_sha256": profile_digest("cargo-v1"), "private_records_read": False,
               "model_calls": 0, "final_cohort_frozen": False,
               "source_sha256": {n: hashlib.sha256((RESEARCH/"tools/effort_protocol"/n).read_bytes()).hexdigest()
                                 for n in ["campaign.py", "execution_profiles.py"]},
               "v2_failure": "unprojected public auxiliary evidence field refused by strict selector; v3 explicitly projects eligible/reason"}
    for name, value in [("qualification-status-v3.json", status), ("provisional-selection-v3.json", report), ("receipt.json", receipt)]:
        (OUT / name).write_text(json.dumps(value, sort_keys=True, indent=2)+"\n")
    for name, proof in evidence.items():
        assert hashlib.sha256((RESIDENT/name).read_bytes()).hexdigest() == proof["sha256"]
    print(json.dumps({"changed": changed, "selected": report["selected"], "complete": report["complete"],
                      "ordered_prefix": report["decisions"][:6]}))

if __name__ == "__main__":
    main()
