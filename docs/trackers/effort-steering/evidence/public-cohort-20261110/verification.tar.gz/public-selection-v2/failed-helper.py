"""Public-only selection-state repair. No private task records, images or outcomes read."""
import copy
import hashlib
import json
import sys
from pathlib import Path

RESEARCH = Path("/home/marius/.codex/worktrees/cf66/codescout")
RESIDENT = Path("/home/marius/.cache/codescout-resident/codescout/evidence-cohort-20261110")
OUT = Path(__file__).parent / "public-selection-v2"

def main():
    sys.path.insert(0, str(RESEARCH / "tools/effort_protocol"))
    from campaign import selection_report
    from execution_profiles import profile_digest, runtime_contract, validate_runtime_profile

    OUT.mkdir(exist_ok=False)
    paths = ["selection-rule.json", "metadata-universe.json", "exposure-exclusions.json",
             "qualification-status-v1.json", "provisional-selection-v1.json",
             "datafusion-registry-image-config.json",
             "remaining-registry-image-config/delta-io__delta-rs-4358.stdout",
             "remaining-registry-image-config/delta-io__delta-rs-4358.receipt.json"]
    evidence = {}
    for name in paths:
        raw = (RESIDENT / name).read_bytes()
        evidence[name] = {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}
        target = OUT / "inputs" / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
    rule = json.loads((RESIDENT / paths[0]).read_text())
    universe = json.loads((RESIDENT / paths[1]).read_text())["tasks"]
    exposure = set(json.loads((RESIDENT / paths[2]).read_text())["tasks"])
    status = json.loads((RESIDENT / paths[3]).read_text())
    original = copy.deepcopy(status)
    contract = runtime_contract("cargo-v1")
    probes = []
    for task, name in [
        ("apache__datafusion-21121", paths[5]),
        ("delta-io__delta-rs-4358", paths[6]),
    ]:
        config = json.loads((RESIDENT / name).read_text())
        volumes = config["config"]["Volumes"]
        assert "/testbed/mnt_tmp" in volumes
        # Check the production validator itself using an otherwise valid inspection.
        # This is a metadata compatibility probe, not an observed container run.
        source, build = "/owned/source", "/owned/build"
        row = {"HostConfig": {k: v for k, v in contract.items()
                             if k not in ("BuildMounts", "SourceMount", "Environment")},
               "Config": {"User": "1000:1000",
                          "Env": [k+"="+v for k,v in contract["Environment"].items()]},
               "Mounts": [
                   {"Type": "bind", "Destination": "/testbed", "Source": source, "RW": False},
                   {"Type": "bind", "Destination": "/build", "Source": build, "RW": True},
                   {"Type": "bind", "Destination": "/mnt_tmp", "Source": build+"/scratch", "RW": True},
                   {"Type": "tmpfs", "Destination": "/tmp"},
               ]}
        assert validate_runtime_profile(row, source, build, "cargo-v1") == contract
        incompatible = copy.deepcopy(row)
        incompatible["Mounts"].append({"Type": "volume", "Destination": "/testbed/mnt_tmp", "RW": True})
        try:
            validate_runtime_profile(incompatible, source, build, "cargo-v1")
        except Exception as exc:
            observed = str(exc)
            assert "unexpected runtime mount" in observed, observed
        else:
            raise AssertionError("declared nested volume was accepted")
        status[task] = {"eligible": False,
                        "reason": "cargo-v1 rejects image-declared writable volume /testbed/mnt_tmp; metadata-only adapter incompatibility"}
        probes.append({"id": task, "volumes": volumes, "baseline_validator": "accepted",
                       "declared_volume_validator": observed, "docker_started": False})
    rows = [{**r, **status[r["id"]]} for r in universe]
    report = selection_report(rows, exposure, rule["seed"])
    assert report["selected"] == [] and report["complete"] is False
    changed = [k for k in status if status[k] != original[k]]
    assert set(changed) == {"apache__datafusion-21121", "delta-io__delta-rs-4358"}
    for name, data in [
        ("qualification-status-v2.json", status),
        ("provisional-selection-v2.json", report),
        ("receipt.json", {"inputs": evidence, "changed": changed, "probes": probes,
                         "profile_sha256": profile_digest("cargo-v1"),
                         "policy": rule["eligibility"],
                         "private_records_read": False, "model_calls": 0,
                         "final_cohort_frozen": False}),
    ]:
        (OUT / name).write_text(json.dumps(data, indent=2, sort_keys=True)+"\n")
    for name, proof in evidence.items():
        assert hashlib.sha256((RESIDENT/name).read_bytes()).hexdigest() == proof["sha256"]
    print(json.dumps({"changed": changed, "selected": report["selected"],
                      "complete": report["complete"], "ordered_prefix": report["decisions"][:6]}))

if __name__ == "__main__":
    main()
