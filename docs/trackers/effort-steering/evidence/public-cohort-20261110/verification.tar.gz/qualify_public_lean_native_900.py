"""Public baseline only; independent wall budget, unchanged cargo-v1 resources.
Not an effort-protocol observation receipt and never a private evaluator outcome.
"""
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time
import uuid
from pathlib import Path

ROOT = Path(__file__).parent / "public-lean-native-900-v1"
RESIDENT = Path("/home/marius/.cache/codescout-resident/codescout/evidence-cohort-20261110")
RESEARCH = Path("/home/marius/.codex/worktrees/cf66/codescout")

def save(name, value):
    (ROOT/name).write_text(json.dumps(value, indent=2, sort_keys=True)+"\n")

def main():
    sys.path.insert(0, str(RESEARCH/"tools/effort_protocol"))
    from executor import _docker, _inspect, _owned, _cleanup, LABEL
    from execution_profiles import get_profile, profile_digest, validate_runtime_profile
    from receipts import input_digest
    ROOT.mkdir(exist_ok=False)
    original = RESIDENT/"lean-ctx-1168-public-v1/source"
    old = RESIDENT/"lean-ctx-1168-public-tests-derived-v1-registration.json"
    request = json.loads(old.read_text())["request"]
    image = request["image"]
    settings = get_profile("cargo-v1")
    name = "effort-protocol-"+uuid.uuid4().hex
    source, build = ROOT.absolute()/"input", ROOT.absolute()/"build"
    source_digest = input_digest(original)
    registration = {
        "id": "lean-public-native-900-v1", "container_name": name, "image": image,
        "argv": request["argv"], "cwd": request["cwd"], "timeout_s": 900,
        "resources_profile": "cargo-v1", "profile_sha256": profile_digest("cargo-v1"),
        "source_before": source_digest, "helper_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "previous_registration_sha256": hashlib.sha256(old.read_bytes()).hexdigest(),
        "model_calls": 0, "private_records_read": False, "automatic_retry": False,
        "scope": "public runtime readiness; standalone runner, not a protocol observation",
    }
    save("registration.json", registration)
    cid = None
    attach = None
    cleanup = False
    failure = None
    terminal = {}
    samples = []
    try:
        shutil.copytree(original, source, symlinks=True)
        (build/"scratch").mkdir(parents=True)
        assert input_digest(source) == source_digest == input_digest(original)
        created = _docker([
            "create", "--pull=never", "--name", name, "--label", LABEL+"="+name,
            "--network", "none", "--read-only", "--memory", str(settings["memory_bytes"]),
            "--memory-swap", str(settings["memory_bytes"]), "--cpus", "4",
            "--pids-limit", str(settings["pids"]), "--init", "--user", "1000:1000",
            "--cap-drop=ALL", "--security-opt", "no-new-privileges",
            "--tmpfs", "/tmp:"+settings["tmpfs"],
            "--mount", "type=bind,src="+str(source)+",dst=/testbed,readonly",
            "--mount", "type=bind,src="+str(build)+",dst=/build",
            "--mount", "type=bind,src="+str(build/"scratch")+",dst=/mnt_tmp",
            "--workdir", "/testbed/"+request["cwd"],
            *[part for k,v in sorted(settings["env"].items()) for part in ("--env", k+"="+v)],
            "--entrypoint", request["argv"][0], image, *request["argv"][1:]])
        assert created.returncode == 0, created.stderr
        cid = created.stdout.strip()
        assert re.fullmatch("[0-9a-f]{64}", cid)
        before = _inspect(cid)
        _owned(before, cid, name, image)
        validate_runtime_profile(before, source, build, "cargo-v1")
        save("container-before.json", before)
        deadline = time.monotonic()+900
        with (ROOT/"stdout").open("xb") as stdout, (ROOT/"stderr").open("xb") as stderr:
            attach = subprocess.Popen(["docker", "start", "--attach", cid],
                                      stdout=stdout, stderr=stderr, start_new_session=True)
            while attach.poll() is None:
                assert time.monotonic() < deadline, "public_runtime_timeout_900"
                assert all((ROOT/s).stat().st_size <= 4*1024*1024 for s in ("stdout","stderr")), "public_log_limit"
                row = _inspect(cid)
                _owned(row, cid, name, image)
                assert not row["State"]["OOMKilled"], "public_oom"
                samples.append({"at_monotonic":time.monotonic(),"state":row["State"]})
                time.sleep(.5)
            attach.wait(timeout=5)
        final = _inspect(cid)
        _owned(final, cid, name, image)
        validate_runtime_profile(final, source, build, "cargo-v1")
        save("container-after.json", final)
        assert not final["State"]["Running"] and final["State"]["Status"] == "exited"
        assert not final["State"]["OOMKilled"] and not final["State"].get("Error")
        code = final["State"]["ExitCode"]
        assert attach.returncode in (0, code)
        assert all((ROOT/s).stat().st_size <= 4*1024*1024 for s in ("stdout","stderr"))
        assert input_digest(source) == source_digest == input_digest(original)
        terminal = {"command_closed": True, "exit_code": code,
                    "docker_attach_exit": attach.returncode, "capture_complete": True,
                    "resource_valid": True, "source_after": source_digest,
                    "stdout_sha256": hashlib.sha256((ROOT/"stdout").read_bytes()).hexdigest(),
                    "stderr_sha256": hashlib.sha256((ROOT/"stderr").read_bytes()).hexdigest()}
    except Exception as exc:
        failure = {"type":type(exc).__name__,"reason":str(exc)}
    finally:
        try:
            cleanup = _cleanup(cid, name, image)
        except Exception as exc:
            failure = failure or {"type":type(exc).__name__,"reason":"cleanup: "+str(exc)}
        if attach is not None and attach.poll() is None:
            try:
                os.killpg(attach.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            try:
                attach.wait(timeout=5)
            except subprocess.TimeoutExpired:
                cleanup = False
        save("samples.json", samples)
        terminal.update({"failure":failure, "cleanup_complete":cleanup, "container_id":cid,
                         "valid_public_execution":failure is None and cleanup,
                         "model_calls":0, "private_records_read":False})
        save("terminal.json", terminal)
    print(json.dumps(terminal), flush=True)
    if failure is not None or not cleanup:
        raise SystemExit(1)

if __name__ == "__main__":
    main()
