"""One registered public-runtime extension; no model/private evaluation."""
import hashlib
import json
import sys
from pathlib import Path

RESEARCH = Path("/home/marius/.codex/worktrees/cf66/codescout")
RESIDENT = Path("/home/marius/.cache/codescout-resident/codescout/evidence-cohort-20261110")
OUT = Path(__file__).parent / "public-lean-900-v1"

def main():
    sys.path.insert(0, str(RESEARCH / "tools/effort_protocol"))
    from executor import execute_observation
    from execution_profiles import profile_digest

    OUT.mkdir(exist_ok=False)
    previous = RESIDENT / "lean-ctx-1168-public-tests-derived-v1-registration.json"
    raw = previous.read_bytes()
    request = json.loads(raw)["request"]
    request["run_id"] = "cohort-public-lean-ctx-1168-derived-900-v1"
    request["timeout_s"] = 900
    source = RESIDENT / "lean-ctx-1168-public-v1/source"
    registration = {
        "request": request, "previous_registration_sha256": hashlib.sha256(raw).hexdigest(),
        "source": str(source), "profile_sha256": profile_digest("cargo-v1"),
        "reason": "300s control compiled in 227s but did not reach terminal public test status; one bounded extension with identical commands/image/resources",
        "previous_control_retained": True, "private_records_read": False,
        "model_calls": 0, "automatic_retry": False,
        "helper_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    (OUT / "registration.json").write_text(json.dumps(registration, indent=2)+"\n")
    try:
        result = execute_observation(request, source, OUT)
    except Exception as exc:
        (OUT / "terminal.json").write_text(json.dumps({
            "completed": False, "reason": str(exc),
            "exception": type(exc).__name__, "automatic_retry": False,
        }, indent=2)+"\n")
        raise
    (OUT / "terminal.json").write_text(json.dumps({"completed": True, "receipt": result}, indent=2)+"\n")
    print(json.dumps({"completed": True, "exit_code": result["exit_code"],
                      "cleanup_complete": result["cleanup_complete"]}))

if __name__ == "__main__":
    main()
