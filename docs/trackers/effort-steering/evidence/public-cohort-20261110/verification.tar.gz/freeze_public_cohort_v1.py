"""Freeze public eligibility before private oracle/model outcomes; retain normal public failures."""
import hashlib
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).parent.absolute()
RESIDENT = Path("/home/marius/.cache/codescout-resident/codescout/evidence-cohort-20261110")
RESEARCH = Path("/home/marius/.codex/worktrees/cf66/codescout")
OUT = HERE/"frozen-public-cohort-v1"

def main():
    sys.path.insert(0,str(RESEARCH/"tools/effort_protocol"))
    from campaign import selection_report
    from receipts import input_digest, verify_receipt
    from executor import _docker, _owned
    from execution_profiles import validate_runtime_profile, profile_digest

    OUT.mkdir(exist_ok=False)
    evidence = {}
    def load(path):
        path = Path(path)
        raw = path.read_bytes()
        evidence[str(path)] = {"sha256":hashlib.sha256(raw).hexdigest(),"bytes":len(raw)}
        return json.loads(raw)

    rule = load(RESIDENT/"selection-rule.json")
    universe = load(RESIDENT/"metadata-universe.json")["tasks"]
    exposure = set(load(RESIDENT/"exposure-exclusions.json")["tasks"])
    status = load(HERE/"public-selection-v3/qualification-status-v3.json")
    disposition = load(HERE/"public-readiness-disposition.json")
    before_status = json.loads(json.dumps(status))
    lean = HERE/"public-lean-native-900-v1"
    terminal = load(lean/"terminal.json")
    registration = load(lean/"registration.json")
    assert terminal["valid_public_execution"] is True and terminal["failure"] is None
    assert all(terminal[k] is True for k in ("capture_complete","cleanup_complete","resource_valid","command_closed"))
    assert terminal["exit_code"] == 101
    assert terminal["source_after"] == registration["source_before"] == input_digest(lean/"input")
    for stream in ("stdout","stderr"):
        raw = (lean/stream).read_bytes()
        evidence[str(lean/stream)] = {"sha256":hashlib.sha256(raw).hexdigest(),"bytes":len(raw)}
        assert evidence[str(lean/stream)]["sha256"] == terminal[stream+"_sha256"]
    for moment in ("before","after"):
        row = load(lean/("container-"+moment+".json"))
        _owned(row,terminal["container_id"],registration["container_name"],registration["image"])
        validate_runtime_profile(row,lean/"input",lean/"build","cargo-v1")
    absent = _docker(["ps","-a","--no-trunc","--format","{{.ID}}","--filter","id="+terminal["container_id"]])
    assert absent.returncode == 0 and not absent.stdout.strip()
    lines=(lean/"stdout").read_text().splitlines()
    outer=[x for x in lines if x.startswith("test result:")][-1]
    match = re.fullmatch(r"test result: FAILED\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in ([0-9.]+)s",outer)
    assert match
    passed,failed,ignored,measured,filtered=map(int,match.groups()[:5])
    assert measured == filtered == 0
    starts = [int(m[1]) for x in lines if (m:=re.fullmatch(r"running (\d+) tests?",x))]
    assert starts[0] == passed+failed+ignored
    # Child-process tests print their own suites: do not add these to the outer census.
    lean_summary={"native_outer_summary":outer,"declared_outer_tests":starts[0],
                  "scope":"outer native libtest suite only; nested child summaries not added"}

    obscura = RESIDENT/"obscura-421-public-tests-derived-v2"
    obscura_execution = verify_receipt({"id":"public-lib-tests"},obscura,obscura/"public-lib-tests/input",expected_profile="cargo-v1")
    assert obscura_execution["complete"] and obscura_execution["resource_valid"]
    load(obscura/"public-lib-tests/receipt.json")
    records = []
    for task, short, public in [
        ("yvgude__lean-ctx-1168","lean-ctx-1168",lean_summary),
        ("h4ckf0r0day__obscura-421","obscura-421",{"native_summary":"251 tests run: 183 passed, 68 failed, 0 skipped","execution":obscura_execution}),
    ]:
        common = RESIDENT/("common-"+short+"-v1")
        prep = load(common/"preparation.json")
        ready = load(common/"native-canaries-v6/readiness-result.json")
        cleanup = load(common/"native-canaries-v6/cleanup.json")
        assert prep["source_unchanged"] is True and prep["programmatic_onboarding_calls"] == 1
        assert ready["ready"] is True and ready["probes_verified"] == 4
        assert cleanup["complete"] is True and cleanup["errors"] == []
        assert ready["binding"]["image"] == prep["image"]
        assert ready["binding"]["source_snapshot_sha256"] == prep["prepared_public_digest"]
        assert set(["references","symbol_at","call_graph","semantic_search"]) <= set(ready["tools"])
        status[task] = {"eligible":True,"reason":"public source, pinned compatible runtime, native readiness and complete ordinary public suite execution qualified; public failures retained, not a pass-count selection"}
        records.append({"id":task,"public_source_sha256":prep["original_source_digest"],
                        "prepared_source_sha256":prep["prepared_public_digest"],"qualified_image":prep["image"],
                        "native_binding":ready["binding"],"public_execution":public,
                        "onboarding_reused":True,"paid_ready":False})
    rows=[{**r,"eligible":status[r["id"]]["eligible"],"reason":status[r["id"]]["reason"]} for r in universe]
    report=selection_report(rows,exposure,rule["seed"])
    assert report["complete"] is True and len(report["selected"]) == 2
    changed=[k for k in status if status[k] != before_status[k]]
    assert set(changed) == {r["id"] for r in records}
    selected_ids=[r["id"] for r in report["selected"]]
    registration={"schema":1,"selected_ids":selected_ids,"qualified":[next(v for v in records if v["id"]==i) for i in selected_ids],
                  "selection":report,"selection_rule":rule,"public_readiness_disposition":disposition,
                  "profile_sha256":profile_digest("cargo-v1"),"inputs":evidence,
                  "known_limits":["public failure causation not established","ordinary linker policy F6 open",
                                  "300-second useful observation readiness open","private evaluator base/reference/repeat open",
                                  "exact all-arm context/runtime/controller admission open"],
                  "private_outcomes_read":False,"experimental_model_calls":0,"paid_ready":False,
                  "replacement_after_private_outcomes":False}
    for name,obj in [("qualification-status-v4.json",status),("selection-final-v1.json",report),("registration.json",registration)]:
        (OUT/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+"\n")
    for path,proof in evidence.items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == proof["sha256"]
    print(json.dumps({"selected_ids":selected_ids,"selection_complete":True,"paid_ready":False,
                      "private_outcomes_read":False,"lean_public_outer":lean_summary}))

if __name__=="__main__":
    main()
