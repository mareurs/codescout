"""Repair-only sixteen-slot controller; feedback remains in the existing native engine."""
import copy
from decimal import Decimal, localcontext
import json
from pathlib import Path

import campaign
import feedback_admission
import feedback_policy
import runner as legacy
from receipts import input_digest, publish_exclusive

CLOSURE_SCHEMA = "native-public-feedback-batch-v1"


def _reserve(registration):
    ledger = copy.deepcopy(registration["ledger"])
    legacy._require(campaign._money(ledger["ceiling_usd"]) == Decimal("200"), "series ceiling differs")
    history = {"carried_holds": registration.get("carried_holds"), "bindings": registration["bindings"]}
    campaign.admit_history(ledger, **history)
    for index, attempt in enumerate(registration["schedule"]):
        ledger = campaign.reserve_attempt(
            ledger, dict(attempt, id=registration["campaign_id"] + "::" + str(index)), **history)
    ledger["reservations"].append({"id": registration["campaign_id"] + "::setup", "reserved_usd": "4"})
    campaign.accounting_totals(ledger)
    return ledger


def preflight(registration: dict, backend) -> dict:
    """Check exact selection, immutable inputs and112USDallocation before backend effects."""
    try:
        feedback_admission.validate_registration(registration)
        legacy._require(getattr(backend, "mode", None) == registration["mode"], "backend mode differs")
        if registration["mode"] == "paid":
            from native_campaign import NativeCampaignBackend
            legacy._require(type(backend) is NativeCampaignBackend, "paid mode requires the concrete native backend")
        root = legacy._unlinked(registration["output_root"])
        legacy._require(not root.exists(), "campaign output already exists")
        selected = campaign.selection_report(registration["metadata"], set(registration["exposure"]),
                                             registration["seed"], task_count=4)
        legacy._require(selected["complete"] is True and registration["selected"] == selected["selected"],
                        "outcome-blind population or selected order changed")
        legacy._verify_inputs(registration)
        for name in registration["bindings"]:
            path = Path(name).absolute()
            legacy._require(not path.is_relative_to(root) and not root.is_relative_to(path),
                            "output overlaps an immutable input")
        shared = registration["shared_preparation"]
        legacy._require(isinstance(shared, dict) and legacy._digest(shared.get("receipt_sha256"))
                        and isinstance(shared.get("cost_usd"), str)
                        and campaign._money(shared["cost_usd"]) <= Decimal("4"), "shared cost is unknown or over budget")
        ledger = _reserve(registration)
        proof = backend.verify(copy.deepcopy(registration))
        legacy._require(isinstance(proof, dict) and proof.get("ready") is True
                        and proof.get("mode") == registration["mode"], "native backend verification failed")
        legacy._verify_inputs(registration)
        return {"ready": True, "paid_ready": registration["mode"] == "paid", "output_root": str(root),
                "reserved_ledger": ledger, "backend": proof}
    except (campaign.CampaignViolation, KeyError, ValueError, TypeError, OSError) as exc:
        return {"ready": False, "paid_ready": False, "reason": str(exc)}


def verify_closed(registration, root, closed):
    """All planned slots are terminal: attempted prefix plus explicitly unexecuted suffix."""
    legacy._verify_inputs(registration)
    root = Path(root)
    legacy._require(registration.get("schema") == feedback_policy.SCHEMA
                    and root == Path(registration["output_root"])
                    and closed.get("schema") == CLOSURE_SCHEMA
                    and closed.get("schedule_sha256") == feedback_admission._identity(registration["schedule"]),
                    "repair-only closure policy or schedule differs")
    items = closed["attempts"]
    legacy._require(isinstance(items, list) and len(items) <= 16
                    and closed["unexecuted"] == registration["schedule"][len(items):]
                    and len(items) + len(closed["unexecuted"]) == 16,
                    "closed batch does not account for all sixteen schedule slots")
    legacy._require(legacy._sha(root / "ledger-final.json") == closed["ledger_sha256"], "closed ledger changed")
    rows = []
    for index, item in enumerate(items):
        expected = registration["schedule"][index]
        receipt = root / "attempts" / (str(index).zfill(2) + "-" + expected["arm"]) / "attempt.json"
        legacy._require(Path(item["attempt_receipt"]) == receipt and not receipt.is_symlink()
                        and legacy._sha(receipt) == item["receipt_sha256"], "closed attempt receipt changed")
        row = json.loads(receipt.read_bytes())
        legacy._require(row["attempt_index"] == index and row["task_id"] == expected["task_id"]
                        and row["arm"] == expected["arm"] and len(row["invocations"]) == 1
                        and row["invocations"][0]["record"].get("cleanup_complete") is True,
                        "attempt is not an exact terminal repair")
        legacy._require(row["candidate"] == item["candidate"] and row["source_digest"] == item["source_digest"],
                        "closed candidate identity differs")
        if item["candidate"] is None:
            legacy._require(row["measurement_invalid"] is True and item["source_digest"] is None,
                            "missing valid candidate at closure")
        else:
            legacy._require(input_digest(item["candidate"]) == item["source_digest"], "closed candidate changed")
        rows.append(row)
    return rows


def analyze_result(result):
    """Unknown private outcomes remain unknown; all costs and paired denominators survive NO-GO."""
    rows = []
    for row in result["attempts"]:
        grade = row.get("grade")
        graded = isinstance(grade, dict) and grade.get("valid") is True and type(grade.get("pass")) is bool
        rows.append({"task_id": row["task_id"], "arm": row["arm"],
                     "accepted": grade["pass"] if graded else None,
                     "workflow_completed": row["workflow_state"] == "closed",
                     "measurement_invalid": row["measurement_invalid"] or not graded,
                     "cost_usd": row["cost"]["known_usd"] if not row["cost"]["unknown"] else None})
    report = feedback_policy.development_screen(rows)
    report["campaign_status"] = result["status"]
    report["unexecuted"] = len(result["unexecuted"])
    setup = campaign._money(result["setup_cost_usd"])
    with localcontext() as context:
        context.prec = 128
        report["standalone_client_usd"] = {
            arm: str(Decimal(row["client_cost_usd"]) + setup) if row["client_cost_usd"] is not None else None
            for arm, row in report["totals"].items()}
    report["setup_client_usd"] = str(setup)
    report["cost_scope"] = "complete attempt client charges, including incomplete/invalid attempts;common preparation separate;invoices/root/review/embedding/CPU unmeasured"
    return report


def analyze(registration: dict, root: str) -> dict:
    root = Path(root)
    closed = json.loads((root / "actor-batch-closed.json").read_bytes())
    verify_closed(registration, root, closed)
    return analyze_result(json.loads((root / "result.json").read_bytes()))


def _run(registration, backend):
    registered = copy.deepcopy(registration)
    checked = preflight(registered, backend)
    legacy._require(checked["ready"], checked.get("reason", "repair-only campaign not admitted"))
    root = Path(checked["output_root"])
    root.mkdir(parents=True, exist_ok=False)
    publish_exclusive(root / "registration.json", registered)
    ledger = checked["reserved_ledger"]
    publish_exclusive(root / "ledger-reserved.json", dict(
        ledger, committed_usd=campaign.accounting_totals(ledger)["committed_usd"]))
    campaign_id = registered["campaign_id"]
    ledger["charges"].append({"id": campaign_id + "::shared-charge", **registered["shared_preparation"]})
    ledger["reservations"] = [r for r in ledger["reservations"] if r["id"] != campaign_id + "::setup"]
    rows, frozen, stopped = [], [], None
    for index, attempt in enumerate(registered["schedule"]):
        try:
            legacy._verify_inputs(registered)
            legacy._require(all(input_digest(p) == d for p, d in frozen), "earlier captured source changed")
        except (campaign.CampaignViolation, ValueError, OSError) as exc:
            stopped = str(exc)
            break
        directory = root / "attempts" / (str(index).zfill(2) + "-" + attempt["arm"])
        directory.mkdir(parents=True)
        task = registered["tasks"][attempt["task_id"]]
        selected = feedback_policy.condition_spec(attempt["arm"], task["backend"]["public"]["feedback_policy"]["workspace"])
        state = {"run_id": campaign_id + "-" + str(index), "phase": "repair", "turns_used": 0,
                 "baseline_digest": task["source_sha256"], "source_digest": task["source_sha256"], "used_receipts": []}
        request = {"invocation_id": campaign_id + "::" + str(index) + "::repair",
                   "task_id": attempt["task_id"], "arm": attempt["arm"], "attempt_index": index,
                   "phase": "repair", "state": state, "source": task["source"],
                   "public_packet": copy.deepcopy(task["public_packet"]), "feedback_policy": selected,
                   "allowance_usd": attempt["reserved_usd"], "cli_cap_usd": attempt["cli_cap_usd"],
                   "max_continuations": 4, "effort": selected["effort"]}
        reservation = campaign_id + "::" + str(index)
        decision = legacy._invocation(backend, request, directory / "repair", ledger, reservation, repair_only=True)
        record = decision["record"]
        if decision["candidate"]:
            frozen.append((Path(decision["candidate"]), decision["source_digest"]))
        try:
            legacy._verify_inputs(registered)
            legacy._require(all(input_digest(p) == d for p, d in frozen), "frozen capture drift")
            campaign.accounting_totals(ledger)
        except (campaign.CampaignViolation, ValueError, OSError) as exc:
            stopped = str(exc)
        if decision["measurement_invalid"]:
            stopped = stopped or "; ".join(str(f) for f in decision["faults"])
        if not stopped and not decision["cost"]["unknown"]:
            ledger["reservations"] = [r for r in ledger["reservations"] if r["id"] != reservation]
        row = {"task_id": attempt["task_id"], "arm": attempt["arm"], "attempt_index": index,
               "workflow_state": "measurement_invalid" if stopped else record["state"]["phase"],
               "measurement_invalid": bool(stopped), "reason": stopped, "cost": decision["cost"],
               "candidate": decision["candidate"], "source_digest": decision["source_digest"],
               "invocations": [decision], "attempt_receipt": str(directory / "attempt.json"), "grade": None,
               "native_lifecycle": copy.deepcopy(record.get("lifecycle")),
               "public_verification": copy.deepcopy(record.get("public_verification"))}
        publish_exclusive(directory / "attempt.json", row)
        rows.append(row)
        if stopped:
            break
    publish_exclusive(root / "ledger-final.json", ledger)
    result = {"schema": feedback_policy.SCHEMA, "status": "stopped" if stopped else "completed",
              "reason": stopped, "paid_ready": checked["paid_ready"],
              "setup_cost_usd": registered["shared_preparation"]["cost_usd"], "attempts": rows,
              "unexecuted": copy.deepcopy(registered["schedule"][len(rows):])}
    closed = {"schema": CLOSURE_SCHEMA, "schedule_sha256": feedback_admission._identity(registered["schedule"]),
              "attempts": [{"attempt_receipt": r["attempt_receipt"], "receipt_sha256": legacy._sha(r["attempt_receipt"]),
                            "candidate": r["candidate"], "source_digest": r["source_digest"]} for r in rows],
              "unexecuted": result["unexecuted"], "ledger_sha256": legacy._sha(root / "ledger-final.json")}
    try:
        verify_closed(registered, root, closed)
        publish_exclusive(root / "actor-batch-closed.json", closed)
        result["closure"] = {"complete": True}
    except (campaign.CampaignViolation, KeyError, TypeError, ValueError, OSError) as exc:
        result["closure"] = {"complete": False, "reason": str(exc)}
        if not stopped:
            result.update(status="stopped", reason="actor closure: " + str(exc))
    if result["closure"]["complete"]:
        for row in rows:
            if row["candidate"] is None or row["invocations"][0]["record"].get("capture_complete") is not True:
                continue
            try:
                verify_closed(registered, root, closed)
                grade_root = root / "grades" / str(row["attempt_index"]).zfill(2)
                grade_root.mkdir(parents=True)
                packet = {key: row[key] for key in ("task_id", "arm", "source_digest")}
                packet["source"] = row["candidate"]
                grade = backend.grade(packet, grade_root)
                legacy._require(isinstance(grade, dict) and grade.get("valid") is True
                                and type(grade.get("pass")) is bool, "independent grade invalid")
                verify_closed(registered, root, closed)
                row["grade"] = grade
            except BaseException as exc:
                result.update(status="grading_stopped", reason=type(exc).__name__ + ": " + str(exc))
                break
    result["analysis"] = analyze_result(result)
    publish_exclusive(root / "result.json", result)
    return result


def run_campaign(registration: dict, backend) -> dict:
    with localcontext() as context:
        context.prec = 128
        return _run(registration, backend)
