"""External prepared-task entry validates pinned inputs before credential access."""
import hashlib
import json
import pathlib
import tempfile
import unittest
from unittest.mock import patch
try:
    import external
except ModuleNotFoundError:
    external = None


class ExternalEntryTests(unittest.TestCase):
    def fixture(self, root):
        image = "sha256:" + "a" * 64
        actor = root / "actor"; actor.mkdir()
        (actor / "CLAUDE.md").write_text("PROJECT")
        glob = root / "global.md"; glob.write_text("GLOBAL")
        cli = root / "cli"; cli.write_text("fixture")
        plugin = root / "plugin"; plugin.mkdir()
        native = root / "mcp-native-argv.json"
        native.write_text(json.dumps(["docker", "run", "--init", "--cpus", "4", "--memory", "32g",
            "--tmpfs", "/tmp:rw,exec,size=4g,uid=1000,gid=1000",
            "--pids-limit", "4096", "--network", "none", "--user", "1000:1000",
            "--name", "placeholder", "--label", "codescout.hfa=placeholder",
            image, "start", "--project", "/testbed"]))
        cfg = {"image": image, "baseline_commit": "b" * 40, "actor": str(actor),
            "cli": str(cli), "plugin": str(plugin), "global_rules": str(glob),
            "prompt": "Repair the supplied public task.", "checks": [{"id": "build", "command": "cargo build"}],
            "files": {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                      for p in (native, glob, cli, actor / "CLAUDE.md")}}
        (root / "prepared.json").write_text(json.dumps(cfg))
        return cfg
    def test_context_preload_is_hash_bound_and_appended_to_system(self):
        with tempfile.TemporaryDirectory() as temp:
            root=pathlib.Path(temp)
            cfg=self.fixture(root)
            context=root/'context.txt'; context.write_text('<prepared-context>\n<codescout-onboarding>\nONBOARDING\n</codescout-onboarding>\n<reconnaissance-instructions>\nSupporting files: .codescout/prepared-context/reconnaissance\nRECON\n</reconnaissance-instructions>\n</prepared-context>\n')
            system=root/'actor/.codescout/system-prompt.md'
            system.parent.mkdir(); system.write_text('ONBOARDING')
            skill=root/'actor/.codescout/prepared-context/reconnaissance/SKILL.md'
            skill.parent.mkdir(parents=True); skill.write_text('RECON')
            files={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (context,system,skill)}
            cfg['context_preload']={'path':str(context),'system_path':str(system),'skill_path':str(skill),'files':files}
            cfg['files'].update(files)
            (root/'prepared.json').write_text(json.dumps(cfg))
            seen={}
            def execute(runtime,config,out,actor,argv,env,server,sid,hook,available,**kwargs):
                seen['argv']=argv
                return {'workflow_completed':True}
            with patch.object(external.workflow,'execute',side_effect=execute):
                external.launch(root,effort='low',allowance='1',scripted_plan=[])
            self.assertEqual(seen['argv'][seen['argv'].index('--append-system-prompt')+1],context.read_text())
            expected=json.loads((root/'expected.json').read_text())
            self.assertEqual(expected['preload_visible'],external.worker.visible(context.read_text()))
            self.assertEqual(json.loads((root/'launch.json').read_text())['context_preload_sha256'],files[str(context)])
            cfg['files'].pop(str(skill))
            (root/'prepared.json').write_text(json.dumps(cfg))
            with self.assertRaises(ValueError):
                external.validate_prepared(root,'low','1','1')
            cfg['files'].update(files)
            context.write_text('ONBOARDING ONLY')
            cfg['files'][str(context)]=hashlib.sha256(context.read_bytes()).hexdigest()
            cfg['context_preload']['files'][str(context)]=cfg['files'][str(context)]
            (root/'prepared.json').write_text(json.dumps(cfg))
            with self.assertRaises(ValueError):
                external.validate_prepared(root,'low','1','1')

    def test_public_fixture_native_options_and_hashes_are_admitted_exactly(self):
        with tempfile.TemporaryDirectory(prefix="external-public-fixture-") as directory:
            root = pathlib.Path(directory)
            cfg = self.fixture(root)
            descriptor = external.public_fixture.create_fixture_bundle(
                root / "fixture",
                {"version": "public-http-fixture-v1", "hostname": "fixture.sample.test",
                 "port": 18081, "routes": {"/": {
                     "status": 200, "content_type": "text/plain", "body": "public"}}})
            cfg["public_fixture"] = descriptor
            argv_path = root / "mcp-native-argv.json"
            argv = json.loads(argv_path.read_text())
            argv[-4:-4] = external.public_fixture.fixture_docker_options(descriptor, "native")
            argv_path.write_text(json.dumps(argv))
            for path in (argv_path, *pathlib.Path(descriptor["root"]).iterdir()):
                cfg["files"][str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
            (root / "prepared.json").write_text(json.dumps(cfg))
            external.validate_prepared(root, "low", "1.00", None)
            original = argv_path.read_text()
            for before, after in (
                    ("fixture.sample.test:127.0.0.1", "example.com:127.0.0.1"),
                    ("/bench/public-fixture/launch-native", "/bench/bin/codescout"),
                    (f"type=bind,src={descriptor['root']},dst=/bench/public-fixture,readonly",
                     f"type=bind,src={descriptor['root']},dst=/bench/public-fixture")):
                bad = [after if x == before else x for x in json.loads(original)]
                argv_path.write_text(json.dumps(bad))
                cfg["files"][str(argv_path)] = hashlib.sha256(argv_path.read_bytes()).hexdigest()
                (root / "prepared.json").write_text(json.dumps(cfg))
                with self.subTest(before=before), self.assertRaises(ValueError):
                    external.validate_prepared(root, "low", "1.00", None)
            argv_path.write_text(original)
            cfg["files"][str(argv_path)] = hashlib.sha256(argv_path.read_bytes()).hexdigest()
            del cfg["files"][str(pathlib.Path(descriptor["root"]) / "spec.json")]
            (root / "prepared.json").write_text(json.dumps(cfg))
            with self.assertRaises(ValueError):
                external.validate_prepared(root, "low", "1.00", None)

    def test_drift_and_empty_checks_block_before_credentials_or_start_marker(self):
        self.assertIsNotNone(external, "external entry is not implemented")
        class Forbidden:
            def stat(self):raise AssertionError("credential access")
        for defect in ("drift", "checks"):
            with self.subTest(defect=defect), tempfile.TemporaryDirectory() as temp:
                root = pathlib.Path(temp); cfg = self.fixture(root)
                if defect == "drift":
                    pathlib.Path(cfg["global_rules"]).write_text("CHANGED")
                else:
                    cfg["checks"] = []
                    (root / "prepared.json").write_text(json.dumps(cfg))
                with self.assertRaises(ValueError):
                    external.launch(root, effort="low", allowance="8", token_path=Forbidden())
                self.assertFalse((root / "started.json").exists())

    def test_budget_effort_and_native_boundary_reject_before_credentials(self):
        self.assertIsNotNone(external, "external entry is not implemented")
        for change in ("cap", "effort", "network"):
            with self.subTest(change=change), tempfile.TemporaryDirectory() as temp:
                root = pathlib.Path(temp); cfg = self.fixture(root)
                if change == "network":
                    native = root / "mcp-native-argv.json"
                    native.write_text(native.read_text().replace('"none"', '"host"'))
                    cfg["files"][str(native)] = hashlib.sha256(native.read_bytes()).hexdigest()
                    (root / "prepared.json").write_text(json.dumps(cfg))
                kwargs = {"effort": "medium" if change == "effort" else "low", "allowance": "8"}
                if change == "cap":kwargs["cli_cap"] = "9"
                with self.assertRaises(ValueError):
                    external.launch(root, **kwargs)
                self.assertFalse((root / "started.json").exists())
    def test_conflicting_native_options_reject_before_credentials(self):
        class Forbidden:
            def stat(self):
                raise AssertionError("credential access")
        for option in ("--memory=1g", "--cpus=99", "--network=host", "--user=0:0",
                       "--privileged", "--net=host", "--cpus", "--name=other"):
            with self.subTest(option=option), tempfile.TemporaryDirectory() as temp:
                root = pathlib.Path(temp); cfg = self.fixture(root)
                native = root / "mcp-native-argv.json"
                argv = json.loads(native.read_text())
                argv.insert(-4, option)
                native.write_text(json.dumps(argv))
                cfg["files"][str(native)] = hashlib.sha256(native.read_bytes()).hexdigest()
                (root / "prepared.json").write_text(json.dumps(cfg))
                with self.assertRaises(ValueError):
                    external.launch(root, effort="low", allowance="8", token_path=Forbidden())
                self.assertFalse((root / "started.json").exists())
    def test_external_profile_rejects_legacy_or_nonexecutable_temporary_storage(self):
        for value in (None, "/tmp:rw,size=4g,uid=1000,gid=1000",
                      "/tmp:rw,noexec,size=4g,uid=1000,gid=1000",
                      "/tmp:rw,exec,size=1g,uid=1000,gid=1000",
                      "/tmp:rw,exec,size=4g,uid=0,gid=0"):
            with self.subTest(tmpfs=value), tempfile.TemporaryDirectory() as temp:
                root = pathlib.Path(temp); cfg = self.fixture(root)
                native = root / "mcp-native-argv.json"
                argv = json.loads(native.read_text())
                index = argv.index("--tmpfs")
                if value is None:
                    del argv[index:index + 2]
                else:
                    argv[index + 1] = value
                native.write_text(json.dumps(argv))
                cfg["files"][str(native)] = hashlib.sha256(native.read_bytes()).hexdigest()
                (root / "prepared.json").write_text(json.dumps(cfg))
                with self.assertRaisesRegex(ValueError, "temporary"):
                    external.validate_prepared(root, "low", "8", None)

    def test_new_external_profile_accepts_32_gib_and_rejects_legacy_24_gib(self):
        with tempfile.TemporaryDirectory() as temp:
            root = pathlib.Path(temp); cfg = self.fixture(root)
            external.validate_prepared(root, "low", "8", None)
            native = root / "mcp-native-argv.json"
            argv = json.loads(native.read_text())
            argv[argv.index("--memory") + 1] = "24g"
            native.write_text(json.dumps(argv))
            cfg["files"][str(native)] = hashlib.sha256(native.read_bytes()).hexdigest()
            (root / "prepared.json").write_text(json.dumps(cfg))
            with self.assertRaisesRegex(ValueError, "--memory"):
                external.validate_prepared(root, "low", "8", None)
    def test_external_swap_cap_matches_32_gib_memory(self):
        for option in ([], ["--memory-swap", "32g"], ["--memory-swap=32g"],
                       ["--memory-swap", "24g"], ["--memory-swap=64g"],
                       ["--memory-swap=-1"]):
            with self.subTest(option=option), tempfile.TemporaryDirectory() as temp:
                root = pathlib.Path(temp); cfg = self.fixture(root)
                native = root / "mcp-native-argv.json"
                argv = json.loads(native.read_text())
                argv[-4:-4] = option
                native.write_text(json.dumps(argv))
                cfg["files"][str(native)] = hashlib.sha256(native.read_bytes()).hexdigest()
                (root / "prepared.json").write_text(json.dumps(cfg))
                if option in ([], ["--memory-swap", "32g"], ["--memory-swap=32g"]):
                    external.validate_prepared(root, "low", "8", None)
                else:
                    with self.assertRaisesRegex(ValueError, "swap"):
                        external.validate_prepared(root, "low", "8", None)

    def test_disk_actor_is_admitted_and_launch_uses_private_short_temporary(self):
        with tempfile.TemporaryDirectory(prefix="ep-disk-", dir="/var/tmp") as temp:
            root = pathlib.Path(temp)
            self.fixture(root)
            seen = {}
            def execute(runtime, config, out, actor, argv, env, server, sid, hook, available, **kwargs):
                seen.update(env=env)
                return {"workflow_completed": False}
            with patch.object(external.workflow, "execute", side_effect=execute):
                external.launch(root, effort="low", allowance="1", scripted_plan=[])
            scratch = pathlib.Path(seen["env"]["TMPDIR"])
            self.addCleanup(lambda: __import__("shutil").rmtree(scratch))
            self.assertEqual(scratch.parent, pathlib.Path("/var/tmp"))
            self.assertLess(len(str(scratch)), 40)
            self.assertEqual(scratch.stat().st_mode & 0o777, 0o700)
            launch = json.loads((root / "launch.json").read_bytes())
            self.assertEqual(launch["client_temporary"], str(scratch))

    def test_actor_ancestry_cannot_inherit_rules_workspace_or_symlink(self):
        with tempfile.TemporaryDirectory(prefix="ep-context-", dir="/var/tmp") as temp:
            root = pathlib.Path(temp)
            nested = root / "nested"
            nested.mkdir()
            self.fixture(nested)
            external.validate_prepared(nested, "low", "1", None)
            for name in ("CLAUDE.md", "AGENTS.md", ".git", ".claude", "Cargo.toml"):
                with self.subTest(name=name):
                    marker = root / name
                    marker.write_text("parent context")
                    try:
                        with self.assertRaisesRegex(ValueError, "ancestry"):
                            external.validate_prepared(nested, "low", "1", None)
                        self.assertFalse((nested / "started.json").exists())
                    finally:
                        marker.unlink()
            link = root / "linked"
            link.symlink_to(nested / "actor", target_is_directory=True)
            cfg = json.loads((nested / "prepared.json").read_bytes())
            cfg["actor"] = str(link)
            (nested / "prepared.json").write_text(json.dumps(cfg))
            with self.assertRaisesRegex(ValueError, "ancestry"):
                external.validate_prepared(nested, "low", "1", None)

    def test_scripted_launch_wires_full_context_budget_and_required_capture(self):
        self.assertIsNotNone(external, "external entry is not implemented")
        with tempfile.TemporaryDirectory() as temp:
            root = pathlib.Path(temp); cfg = self.fixture(root)
            seen = {}
            def execute(runtime, config, out, actor, argv, env, server, sid, hook, available, **kwargs):
                seen.update(argv=argv, env=env, available=str(available), image=runtime.IMAGE,
                            checks=config["checks"], capture=kwargs["capture_artifacts"])
                server.shutdown();server.server_close()
                return {"workflow_completed": True}
            with patch.object(external.workflow, "execute", side_effect=execute), \
                 patch.object(external, "capture_patch", return_value={"complete": True}) as capture:
                result = external.launch(root, effort="low", allowance="8", cli_cap="7", scripted_plan=[])
                seen["capture"]()
                capture.assert_called_once_with(root, cfg["image"], cfg["baseline_commit"])
            self.assertFalse(result["workflow_completed"])  # no actual request can certify context
            self.assertFalse(result["context_valid"])
            argv=seen["argv"]
            self.assertEqual(argv[argv.index("--setting-sources")+1], "user,project,local")
            self.assertEqual(argv[argv.index("--max-budget-usd")+1], "7")
            self.assertNotIn("--max-turns", argv)
            self.assertEqual(seen["available"], "8")
            self.assertEqual(seen["image"], cfg["image"])
            self.assertEqual(seen["checks"], cfg["checks"])
            self.assertNotIn("CLAUDE_CODE_OAUTH_TOKEN", seen["env"])
            self.assertEqual(json.loads((root / "expected.json").read_text())["project_visible"], ["PROJECT"])
            self.assertTrue((root / "started.json").exists())
            with self.assertRaises((ValueError, FileExistsError)):
                external.launch(root, effort="low", allowance="8", scripted_plan=[])
    def test_cli_legacy_protocol_and_per_connection_stdio_are_explicit(self):
        with tempfile.TemporaryDirectory() as temp:
            root = pathlib.Path(temp)
            self.fixture(root)
            seen = {}
            def execute(runtime, config, out, actor, argv, env, server, sid, hook, available, **kwargs):
                seen.update(env=dict(env))
                server.shutdown()
                server.server_close()
                return {"workflow_completed": True}
            with patch.object(external.workflow, "execute", side_effect=execute):
                external.launch(root, effort="low", allowance="8", cli_cap="7", scripted_plan=[])
            self.assertEqual(seen["env"].get("MCP_PROTOCOL_NEGOTIATION"), "legacy")
            config = json.loads((root / "mcp.json").read_bytes())
            wrapper = pathlib.Path(external.__file__).with_name("native_stdio.py")
            self.assertEqual(config["mcpServers"]["codescout"]["args"][1], str(wrapper))
            launch = json.loads((root / "launch.json").read_bytes())
            self.assertEqual(launch["mcp_protocol_negotiation"], "legacy")
            self.assertEqual(launch["native_stdio_sha256"], hashlib.sha256(wrapper.read_bytes()).hexdigest())

    def test_launch_forwards_runtime_supervisor_to_workflow(self):
        from types import SimpleNamespace
        with tempfile.TemporaryDirectory() as temp:
            root = pathlib.Path(temp)
            self.fixture(root)
            observed = []
            supervisor = SimpleNamespace(check=lambda: observed.append("checked"))
            def execute(*args, supervisor=None, **kwargs):
                if supervisor is not None:
                    supervisor.check()
                return {"workflow_completed": False}
            with patch.object(external.workflow, "execute", side_effect=execute):
                external.launch(root, effort="low", allowance="8",
                                scripted_plan=[], supervisor=supervisor)
            self.assertEqual(observed, ["checked"])

    def test_registered_embedding_profile_preserves_fail_before_launch_boundary(self):
        import embedding_profile
        from test_embedding_profile import EmbeddingProfileTests
        fixture = EmbeddingProfileTests("test_only_registered_owned_internal_relay_graph_is_admitted")
        fixture.setUp()
        self.addCleanup(fixture.temp.cleanup)
        with tempfile.TemporaryDirectory(prefix="external-relay-profile-") as td:
            root = pathlib.Path(td)
            cfg = self.fixture(root)
            native_path = root / "mcp-native-argv.json"
            native = json.loads(native_path.read_text())
            native[native.index("--network") + 1] = fixture.net
            native[native.index("--tmpfs") + 1] = "/tmp:rw,exec,size=16g,uid=1000,gid=1000"
            native[2:2] = ["--read-only", "--cap-drop", "ALL", "--security-opt", "no-new-privileges"]
            native_path.write_text(json.dumps(native))
            cfg["files"][str(native_path)] = hashlib.sha256(native_path.read_bytes()).hexdigest()
            cfg["embedding_profile"] = fixture.profile
            (root / "prepared.json").write_text(json.dumps(cfg))
            with patch.object(embedding_profile, "_inspect", side_effect=lambda kind, identity: fixture.rows[identity]):
                try:
                    actual = external.validate_prepared(root, "low", "0.50", None)
                except ValueError as exc:
                    self.fail("registered live relay should validate: " + str(exc))
                self.assertEqual(actual[0]["embedding_profile"]["network_id"], fixture.net)
                fixture.rows[fixture.net]["Internal"] = False
                with self.assertRaises(ValueError):
                    external.launch(root, effort="low", allowance="0.50", token_path="/must-not-read-token")
            self.assertFalse((root / "started.json").exists())

    def test_unregistered_embedding_declaration_cannot_hide_behind_default_network_none(self):
        with tempfile.TemporaryDirectory(prefix="external-bad-relay-profile-") as td:
            root = pathlib.Path(td)
            cfg = self.fixture(root)
            cfg["embedding_profile"] = {"version": "arbitrary-network"}
            (root / "prepared.json").write_text(json.dumps(cfg))
            with self.assertRaises(ValueError):
                external.validate_prepared(root, "low", "0.50", None)

    def test_profile_only_flags_cannot_be_admitted_on_default_network_none(self):
        for extra in [
            ["--read-only"], ["--cap-drop", "ALL"], ["--security-opt", "no-new-privileges"],
        ]:
            with self.subTest(extra=extra), tempfile.TemporaryDirectory(prefix="external-default-option-") as td:
                root = pathlib.Path(td)
                cfg = self.fixture(root)
                path = root / "mcp-native-argv.json"
                argv = json.loads(path.read_text())
                argv[2:2] = extra
                path.write_text(json.dumps(argv))
                cfg["files"][str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
                (root / "prepared.json").write_text(json.dumps(cfg))
                with self.assertRaises(ValueError):
                    external.validate_prepared(root, "low", "0.50", None)
                self.assertFalse((root / "started.json").exists())
