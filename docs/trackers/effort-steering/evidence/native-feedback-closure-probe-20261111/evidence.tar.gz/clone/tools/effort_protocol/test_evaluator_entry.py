"""Private entry seams with real Git, snapshots and frozen-package custody."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from receipts import input_digest
try:
    import evaluator_entry as entry
except ImportError:
    entry = None


class PrivateEntryTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(entry, "isolated private entry missing")
        self.temp = tempfile.TemporaryDirectory(prefix="private-entry-test-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.base = self.root/"base";self.base.mkdir()
        (self.base/"old").write_text("before\n")
        (self.base/"gone").write_bytes(b"remove\n")
        self.git(self.base,"init","-q")
        self.git(self.base,"add",".")
        self.git(self.base,"-c","user.name=fixture","-c","user.email=fixture@invalid",
                 "commit","-qm","base")
        self.changed = self.root/"changed"
        shutil.copytree(self.base,self.changed)
        (self.changed/"old").write_text("after\n")
        (self.changed/"gone").unlink()
        (self.changed/"new.bin").write_bytes(bytes(range(256)))
        self.git(self.changed,"add","-A")
        self.patch = self.root/"candidate.patch"
        self.patch.write_bytes(self.git(self.changed,"diff","--cached","--binary","HEAD").stdout)
        for source in (self.base,self.changed): shutil.rmtree(source/".git")
        self.proof = self.root/"proof.json"
        self.proof.write_text(json.dumps({"complete":True,"sha256":self.sha(self.patch),
            "bytes":self.patch.stat().st_size,"baseline_commit":"a"*40,
            "edited":["old","gone","new.bin"]}))
        self.request = {"source":str(self.changed),"source_digest":input_digest(self.changed),
            "public_baseline":str(self.base),"public_baseline_sha256":input_digest(self.base),
            "patch":str(self.patch),"patch_sha256":self.sha(self.patch),
            "capture_proof":str(self.proof),"capture_proof_sha256":self.sha(self.proof)}

    def git(self,path,*args):
        return subprocess.run(["git","-C",str(path),*args],check=True,capture_output=True)

    def sha(self,path):
        return hashlib.sha256(Path(path).read_bytes()).hexdigest()

    def test_digest_calibrates_against_controller_modes_directories_and_internal_links(self):
        directory=self.changed/"empty";directory.mkdir()
        (self.changed/"old").chmod(0o751)
        (self.changed/"alias").symlink_to("old")
        self.assertEqual(entry._input_digest(self.changed),input_digest(self.changed))

    def test_binary_add_delete_patch_reconstructs_captured_source(self):
        entry.verify_candidate(self.request,self.root/"verify")
        self.assertEqual((self.root/"verify/new.bin").read_bytes(),bytes(range(256)))
        self.assertFalse((self.root/"verify/gone").exists())

    def test_source_patch_disagreement_is_rejected_even_with_updated_source_digest(self):
        (self.changed/"old").write_text("unrecorded edit\n")
        self.request["source_digest"]=input_digest(self.changed)
        with self.assertRaisesRegex(ValueError,"patch.*source"):
            entry.verify_candidate(self.request,self.root/"verify")

    def test_changed_capture_or_baseline_refuses_before_patch_application(self):
        for field in ("capture_proof_sha256","public_baseline_sha256","patch_sha256","source_digest"):
            with self.subTest(field=field):
                request=dict(self.request,**{field:"0"*64})
                with self.assertRaises(ValueError):
                    entry.verify_candidate(request,self.root/field)
                self.assertFalse((self.root/field).exists())

    def test_protocol_submission_is_explicitly_excluded_from_source_manifest(self):
        (self.base/"submission.json").write_text("host protocol data")
        (self.changed/"submission.json").write_text("new protocol data")
        self.request.update(public_baseline_sha256=input_digest(self.base),
                            source_digest=input_digest(self.changed))
        entry.verify_candidate(self.request,self.root/"verify")

    def test_package_manifest_requires_exact_99_regular_files_and_bytes(self):
        package=self.root/"package";package.mkdir()
        files={}
        for index in range(99):
            path=package/(str(index)+".txt");path.write_text(str(index))
            files[path.name]=self.sha(path)
        self.assertEqual(entry.verify_package(package,files),package.resolve())
        (package/"0.txt").write_text("mutant")
        with self.assertRaises(ValueError): entry.verify_package(package,files)
        (package/"0.txt").write_text("0")
        (package/"extra.py").write_text("side effect")
        with self.assertRaises(ValueError): entry.verify_package(package,files)
        (package/"extra.py").unlink()
        (package/"0.txt").unlink()
        (package/"0.txt").symlink_to(package/"1.txt")
        with self.assertRaises(ValueError): entry.verify_package(package,files)

    def test_escaping_link_never_enters_source_digest(self):
        (self.changed/"escape").symlink_to(self.root/"proof.json")
        with self.assertRaises(ValueError): entry._input_digest(self.changed)

    def test_cgroup_faults_are_not_suppressed_by_successful_test_metadata(self):
        for text in ("oom 0\noom_kill 1\n", "oom_kill 0\noom_kill 0\n",
                     "oom_kill nope\n", "oom 0\n"):
            with self.subTest(text=text):
                with self.assertRaises(ValueError): entry.memory_events(text)
        self.assertEqual(entry.memory_events("low 0\noom 0\noom_kill 0\n")["oom_kill"],0)
    def test_fresh_absence_consumes_frozen_pilot_merged_stream_contract(self):
        from unittest.mock import Mock
        docker=Mock(return_value=subprocess.CompletedProcess([],1,"Error: No such container: owned\n",None))
        self.assertTrue(entry.fresh_absence(docker,"owned"))
        docker.assert_called_once_with("container","inspect","owned",check=False,timeout=60)
        for code,text in ((1,"permission denied"),(0,"No such container"),(1,"daemon unavailable")):
            docker=Mock(return_value=subprocess.CompletedProcess([],code,text,None))
            self.assertFalse(entry.fresh_absence(docker,"owned"))
    def test_full_private_grade_checks_merged_absence_after_actual_observer_calls(self):
        from types import SimpleNamespace
        out=self.root/"grade";out.mkdir()
        image="sha256:"+"a"*64
        identity={"Id":"owned-cid","Image":image,"Config":{"User":"0:0"},
            "HostConfig":{"NetworkMode":"none","Memory":8*1024**3,"MemorySwap":8*1024**3,
                "NanoCpus":4*10**9,"Init":True,"PidsLimit":4096,"Binds":None,
                "CapDrop":["ALL"],"SecurityOpt":["no-new-privileges"]}}
        calls=[]
        def docker(*args,**kwargs):
            calls.append(args)
            if args[0]=="run": value="owned-cid"
            elif args[0]=="inspect": value=json.dumps([identity])
            elif args[:3]==("exec","owned","cat"): value="oom_kill 0\n"
            elif args[:3]==("exec","owned","python3"): value=json.dumps({"/testbed/old":self.sha(self.changed/"old")})
            elif args[0]=="container":
                return subprocess.CompletedProcess(args,1,"No such container: owned",None)
            else: value=""
            return subprocess.CompletedProcess(args,0,value,None)
        pilot=SimpleNamespace(docker=docker)
        def make_grader(record,bundle,image,gdir,**kwargs):
            def grade(patch,name):
                pilot.docker("run","--name","owned",image,"sleep","infinity")
                pilot.docker("rm","-f","owned")
                path=out/"grade.log";path.write_text("selected fail")
                path.with_name("grade.json").write_text("{}")
                return {"log":str(path),"pass":False}
            return grade
        tasks=SimpleNamespace(pilot=pilot,tasks=SimpleNamespace(patch_files=lambda text:[]),live_grader=make_grader)
        def adjudicate(*args,**kwargs):
            self.assertTrue(kwargs["runtime"]["complete"])
            self.assertEqual(kwargs["runtime"]["cgroup_probes"],2)
            self.assertEqual(kwargs["runtime"]["fresh_absence"],[True])
            return {"valid":True,"pass":False}
        modules=(tasks,SimpleNamespace(adjudicate_streams=adjudicate),None,
            {"FAIL_TO_PASS":["f"],"PASS_TO_PASS":["p"],"test_patch":""})
        result=entry._run_grade(self.request,{"image":image,"production_paths":["old"],
            "fixed_test_sha256":{},"diagnostic_artifacts":{},"stream_registration":{}},
            out,{"edited":[]},modules)
        self.assertTrue(result["valid"])
        self.assertIs(pilot.docker,docker)
        self.assertEqual(sum(args[0]=="container" for args in calls),1)


if __name__=="__main__": unittest.main()
