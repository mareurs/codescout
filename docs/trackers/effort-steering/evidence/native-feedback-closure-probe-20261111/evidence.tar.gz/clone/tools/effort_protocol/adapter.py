"""Host phase orchestration over a trusted CLOSED actor boundary.

The backend must return actual native receipts/captured source; the tests use a
scripted backend and real Docker evidence commands. This module is not a provider
adapter and cannot by itself admit a paid run.
"""
import copy
import hashlib
import json
import re
import shutil
from decimal import Decimal, InvalidOperation
from pathlib import Path

from executor import ExecutionInvalid, execute_observation
from policy import ProtocolViolation, validate_transition
from receipts import ReceiptViolation, input_digest, publish_exclusive
from readiness import ReadinessViolation, validate_readiness
from public_artifacts import build_public_artifact
from execution_profiles import (ProfileViolation, get_profile, profile_digest,
                                validate_command_budget, validate_profile_fixture)

_ACTIVE = {"investigate": "repair", "repair": "challenge", "challenge": "closed"}
_PUBLIC_KEYS = {"issue", "project_rules", "global_rules", "onboarding", "prior_public_artifacts"}

class PhaseInvalid(ValueError):
    """Host/context/cost/runtime validity failed; no favorable retry is allowed."""

def _require(condition, message):
    if not condition:
        raise ProtocolViolation(message)

def _amount(value):
    try:
        result = Decimal(str(value))
    except InvalidOperation:
        return None
    return result if result.is_finite() and result >= 0 else None

def packet_digest(value) -> str:
    """Bind the exact canonical public packet or generic prompt before an actor call."""
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

def _cost(result):
    value = _amount(result.get("cost_usd"))
    final = result.get("cost_is_final") is True and value is not None
    return {"known_usd": str(value) if value is not None else None, "unknown": not final}

def _phase_zero(state, source, prefixes):
    try:
        if input_digest(source, state["baseline_paths"]) != state["baseline_digest"]:
            return False
        originals = set(state["baseline_paths"])
        for path in source.rglob("*"):
            name = path.relative_to(source).as_posix()
            if name not in originals and not any(name == p.rstrip("/") or name.startswith(p)
                                               for p in prefixes):
                return False
        return True
    except (KeyError, OSError, ReceiptViolation):
        return False

def _commands(commands, phase):
    _require(isinstance(commands, list) and 0 < len(commands) <= 8, "missing or excessive commands")
    used = set()
    admitted = []
    for item in commands:
        _require(isinstance(item, dict), "invalid command object")
        local = item.get("id")
        _require(isinstance(local, str) and re.fullmatch(r"[A-Za-z0-9_-]{1,80}", local)
                 and not local.startswith("public-") and local not in used,
                 "missing, repeated or reserved command ID")
        used.add(local)
        admitted.append((local, phase + "--" + local, item))
    return admitted

def _admit_backend(request, executor):
    mode = request.get("execution_mode")
    if mode not in ("native", "scripted") or getattr(executor, "mode", None) != mode:
        raise PhaseInvalid("backend execution mode is missing or mismatched")
    if mode == "scripted":
        return None
    proof = request.get("native_preflight")
    if not isinstance(proof, dict) or set(proof) != {"expected", "wire"}:
        raise PhaseInvalid("native preparation evidence missing")
    try:
        source_reader = getattr(executor, "readiness_source", None)
        source = source_reader() if callable(source_reader) else None
        ready = validate_readiness(proof["expected"], proof["wire"], source=source)
        fixture = validate_profile_fixture(request.get("execution_profile", "fixture-v1"),
                                           request.get("public_fixture"))
        native_fixture = ready["binding"].get("public_fixture_sha256")
        command_fixture = fixture["fingerprint"] if fixture is not None else None
        if native_fixture != command_fixture:
            raise ValueError("native and command public fixture bindings differ")
        binder = getattr(executor, "bind_readiness", None)
        if not callable(binder):
            raise ValueError("native backend cannot bind concrete preparation")
        binder(ready["binding"])
        return ready
    except (ValueError, ReadinessViolation, TypeError, KeyError, AttributeError, OSError) as exc:
        raise PhaseInvalid("native preparation not ready: " + str(exc)) from exc


def _submission_contract(phase, execution_profile, prefixes, timeout_s, max_log_bytes):
    """Deliver the generic public producer/consumer contract before actor work."""
    if not isinstance(prefixes, list) or not all(
            isinstance(p, str) and p.endswith("/") and
            all(part not in ("", ".", "..") for part in p[:-1].split("/")) and
            not any(ord(ch) < 32 or ch == "\\" for ch in p)
            for p in prefixes) or len(set(prefixes)) != len(prefixes):
        raise PhaseInvalid("invalid public probe locations")
    profile = get_profile(execution_profile)
    string = {"type": "string", "minLength": 1}
    contract = {
        "version": "public-submission-contract-v1",
        "output_path": "submission.json",
        "phase": phase,
        "submission_schema": {
            "type": "object", "required": ["status", "clauses", "commands"],
            "properties": {
                "status": {"enum": ["submitted", "incomplete", "budget_exhausted"]},
                "clauses": {"type": "array", "items": {
                    "type": "object", "required": ["id", "kind", "role", "receipts"],
                    "properties": {
                        "id": {**string, "description": "Unique clause ID."},
                        "kind": {"enum": ["requirement", "preservation", "uncertainty"]},
                        "role": {**string, "description":
                            "Use reproduction and legitimate for the two investigation roles."},
                        "receipts": {"type": "array", "minItems": 1, "items": string,
                            "description": "Local command IDs from this submission; the host supplies receipts."},
                        "unresolved": {"type": "boolean", "default": False},
                        "statement": {**string, "description":
                            "Public-source justification and intended behavior, distinguished from observations."}}}},
                "commands": {"type": "array", "maxItems": 8, "items": {
                    "type": "object", "required": ["id", "argv", "cwd", "test_files"],
                    "properties": {
                        "id": {"type": "string", "pattern": "^(?!public-)[A-Za-z0-9_-]{1,80}$",
                            "description": "Unique local command ID; public- is reserved."},
                        "argv": {"type": "array", "minItems": 1, "items": {"type": "string"},
                            "description": "Executable and arguments; argv[0] must be nonempty. No implicit shell."},
                        "cwd": {**string, "description":
                            "Existing source-relative directory, such as ., without absolute paths or .. components."},
                        "test_files": {"type": "array", "minItems": 1, "items": string,
                            "description": "Existing regular source-relative files read by this command."}}}}},
            "allOf": [{"if": {"properties": {"status": {"const": "submitted"}}},
                       "then": {"properties": {
                           "clauses": {"minItems": 1}, "commands": {"minItems": 1}}}}]},
        "execution": {
            "source_mount": profile["source_mount"], "source_read_only": True,
            "allowed_probe_prefixes": list(prefixes), "build_directory": "/build",
            "environment": copy.deepcopy(profile["env"]),
            "timeout_s": timeout_s, "max_log_bytes": max_log_bytes,
            "description": "The host replays commands in a separate container with frozen source. "
                "Use the source mount for absolute paths and the writable build or temporary directories for outputs. "
                "Submit observed failures truthfully; a reproduction command may fail."},
        "phase_rules": {
            "investigate": {"required_roles": ["reproduction", "legitimate"],
                "description": "Keep every existing file unchanged, including tests. New standalone probe files "
                    "and their directories must be under allowed_probe_prefixes. Empty prefixes allow no new files."},
            "repair": {"description": "Submit commands for the captured current source and declare uncertainty."},
            "challenge": {"no_unresolved_uncertainty": True,
                "description": "The host independently runs registered public checks on final source. "
                    "Do not invent final_receipts; the host creates them."}},
        "incomplete_example": {"status": "incomplete", "clauses": [], "commands": []},
    }
    return "\n<submission-contract>\n" + json.dumps(contract, sort_keys=True, separators=(",", ":")) + "\n</submission-contract>"

def run_phase(request: dict, executor) -> dict:
    """Invoke an actor once, preserve charges, then gate on host-executed evidence."""
    readiness = _admit_backend(request, executor)
    state = copy.deepcopy(request.get("state", {}))
    phase = state.get("phase")
    if phase not in _ACTIVE:
        raise PhaseInvalid("phase is not active")
    arm = request.get("arm", "P")
    execution_profile = request.get("execution_profile", "fixture-v1")
    try:
        get_profile(execution_profile)
        validate_profile_fixture(execution_profile, request.get("public_fixture"))
    except ProfileViolation as exc:
        raise PhaseInvalid("unregistered execution profile") from exc
    if arm not in ("P", "R"):
        raise PhaseInvalid("phase adapter supports protocol and continuation-control arms only")
    if arm == "P" or "command_timeout_s" in request or "max_log_bytes" in request:
        try:
            validate_command_budget(execution_profile, request.get("command_timeout_s"),
                                    request.get("max_log_bytes"))
        except ProfileViolation as exc:
            raise PhaseInvalid(str(exc)) from exc
    budget = _amount(request.get("phase_budget_usd"))
    if budget is None or budget <= 0:
        raise PhaseInvalid("invalid phase budget")
    if "cli_cap_usd" in request:
        cap = _amount(request["cli_cap_usd"])
        if cap is None or cap <= 0 or cap >= budget:
            raise PhaseInvalid("invalid CLI cap")
    packet = request.get("public_packet")
    if not isinstance(packet, dict) or not set(packet) <= _PUBLIC_KEYS:
        raise PhaseInvalid("unregistered public packet fields")
    prompts = json.loads(Path(__file__).with_name("prompts.json").read_text())
    prompt = prompts[phase] if arm == "P" else prompts["continuation"]
    prefixes = request.get("allowed_probe_prefixes", [])
    if arm == "P":
        prompt += _submission_contract(phase, execution_profile, prefixes,
                                       request["command_timeout_s"], request["max_log_bytes"])
    out = Path(request["out"]).resolve()
    out.mkdir(parents=True, exist_ok=False)
    publish_exclusive(out / "started.json", {"run_id": state.get("run_id"),
        "phase": phase, "arm": arm, "phase_budget_usd": str(budget),
        **({"cli_cap_usd": request["cli_cap_usd"]} if "cli_cap_usd" in request else {}),
        "prompt_sha256": packet_digest(prompt), "public_packet_sha256": packet_digest(packet),
        "native_readiness_sha256": packet_digest(readiness) if readiness else None,
        "execution_profile": execution_profile,
        "execution_profile_sha256": profile_digest(execution_profile)})
    actor_packet = {"run_id": state.get("run_id"), "phase": phase, "arm": arm,
                    "prompt": prompt, "public_packet": copy.deepcopy(packet),
                    "allowance_usd": str(budget), "max_continuations": 2,
                    **({"cli_cap_usd": request["cli_cap_usd"]} if "cli_cap_usd" in request else {})}
    # Bind command execution separately from actor-controlled submission fields.
    publish_exclusive(out / "execution-profile.json",
                      {"execution_profile": execution_profile,
                       "execution_profile_sha256": profile_digest(execution_profile)})
    publish_exclusive(out / "actor-packet.json", actor_packet)
    try:
        returned = executor.execute(actor_packet)
    except Exception as exc:
        publish_exclusive(out / "cost.json", {"known_usd": None, "unknown": True})
        publish_exclusive(out / "failure.json", {"reason": "actor boundary raised",
                          "exception": type(exc).__name__, "measurement_invalid": True})
        raise PhaseInvalid("actor boundary failed with unknown charge") from exc
    if not isinstance(returned, dict):
        publish_exclusive(out / "cost.json", {"known_usd": None, "unknown": True})
        raise PhaseInvalid("actor boundary returned no cost receipt")
    cost = _cost(returned)
    publish_exclusive(out / "cost.json", cost)
    try:
        if cost["unknown"]:
            raise PhaseInvalid("charge is unsettled")
        if Decimal(cost["known_usd"]) > budget:
            raise PhaseInvalid("phase budget exceeded")
        if not all(returned.get(k) is True for k in
                   ("context_valid", "cleanup_complete", "capture_complete")):
            raise PhaseInvalid("actor context/capture/cleanup is not valid")
        source = Path(returned["source"]).resolve()
        if out.is_relative_to(source) or source.is_relative_to(out):
            raise PhaseInvalid("actor capture overlaps host evidence")
        before = input_digest(source)
        candidate = out / "candidate"
        shutil.copytree(source, candidate, symlinks=True)
        digest = input_digest(candidate)
        if before != digest or before != input_digest(source):
            raise PhaseInvalid("actor capture source changed")
        publish_exclusive(out / "capture.json", {"source_digest": digest, "source": str(candidate)})
        facts = {}
        final_ids = []
        submission = returned.get("submission")
        counted_turns = None
        try:
            turns = returned.get("turns")
            _require(type(turns) is int and 1 <= turns <= 3, "invalid phase turn count")
            previous = state.get("turns_used", 0)
            _require(type(previous) is int and 0 <= previous and previous + turns <= 9,
                     "workflow turn limit")
            counted_turns = previous + turns
            if arm == "P":
                _require(isinstance(submission, dict), "malformed phase submission")
                if phase == "investigate":
                    _require(_phase_zero(state, candidate, prefixes),
                             "investigation modified production or added unadmitted inputs")
                status = submission.get("status")
                _require(status in ("submitted", "incomplete", "budget_exhausted"), "invalid actor status")
                commands = _commands(submission.get("commands"), phase) if status == "submitted" else []
            else:
                status, commands = "submitted", []
            production = state["baseline_paths"] if phase == "investigate" and arm == "P" else [
                p.relative_to(candidate).as_posix() for p in candidate.rglob("*")]
            def observe(rid, command, kind):
                execution_request = {"id": rid, "run_id": state["run_id"], "phase": phase,
                    "argv": command.get("argv"), "cwd": command.get("cwd"),
                    "test_files": command.get("test_files"), "production_files": production,
                    "image": request["image"], "kind": kind,
                    "timeout_s": request["command_timeout_s"],
                    "max_log_bytes": request["max_log_bytes"], "execution_profile": execution_profile,
                    **({"public_fixture": request["public_fixture"]} if "public_fixture" in request else {})}
                try:
                    return execute_observation(execution_request, candidate, out / "commands")
                except ExecutionInvalid as exc:
                    if exc.reason.startswith(("unsupported_", "missing_", "mutable_")):
                        raise ProtocolViolation(exc.reason) from exc
                    raise PhaseInvalid("evidence command invalid: " + exc.reason) from exc
            for local, rid, command in commands:
                facts[rid] = observe(rid, command, "observation")
            if phase == "challenge" and status == "submitted":
                checks = request.get("public_checks")
                _require(isinstance(checks, list) and bool(checks), "missing registered public checks")
                for index, command in enumerate(checks):
                    rid = phase + "--public-" + str(index)
                    facts[rid] = observe(rid, command, "verification")
                    final_ids.append(rid)
                    _require(facts[rid]["exit_code"] == 0, "final public verification failed")
            if arm == "P":
                clauses = copy.deepcopy(submission.get("clauses"))
                _require(isinstance(clauses, list), "missing clauses")
                for clause in clauses:
                    _require(isinstance(clause, dict) and isinstance(clause.get("receipts"), list),
                             "malformed clause receipt references")
                    clause["receipts"] = [phase + "--" + rid if isinstance(rid, str) else None
                                          for rid in clause["receipts"]]
                result = {"run_id": state["run_id"], "phase": phase, "status": status,
                          "turns": turns, "clauses": clauses, "source_digest": digest,
                          "final_receipts": final_ids}
                next_state = validate_transition(state, result, list(facts.values()))
            else:
                next_state = copy.deepcopy(state)
                next_state.update(phase=_ACTIVE[phase], source_digest=digest, turns_used=previous+turns)
                next_state["used_receipts"] = state.get("used_receipts", []) + list(facts)
            outcome = {"state": next_state, "receipts": facts, "final_receipts": final_ids,
                       "cost": cost, "measurement_invalid": False}
            public_artifact = build_public_artifact(
                run_id=state["run_id"], phase=phase, arm=arm, source=candidate,
                commands=out / "commands", receipt_ids=list(facts),
                submission=submission if arm == "P" else None,
                expected_profile=execution_profile, expected_fixture=request.get("public_fixture"))
            publish_exclusive(out / "public-artifact.json", public_artifact)
            outcome["public_artifact"] = public_artifact
        except ProtocolViolation as exc:
            next_state = copy.deepcopy(state)
            next_state["phase"] = "incomplete"
            if counted_turns is not None:
                next_state["turns_used"] = counted_turns
            outcome = {"state": next_state, "receipts": facts, "final_receipts": final_ids,
                       "cost": cost, "measurement_invalid": False, "reason": str(exc)}
        publish_exclusive(out / "outcome.json", outcome)
        return outcome
    except Exception as exc:
        publish_exclusive(out / "failure.json", {"reason": str(exc), "measurement_invalid": True,
                          "known_usd": cost["known_usd"], "unknown": cost["unknown"]})
        if isinstance(exc, PhaseInvalid):
            raise
        raise PhaseInvalid("host phase boundary failed") from exc
