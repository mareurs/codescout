"""Actual isolated-command tests. Enable only with an existing pinned image."""
import importlib
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
try:
    executor = importlib.import_module("executor")
except ModuleNotFoundError as exc:
    if exc.name != "executor":
        raise
    executor = None
import receipts

IMAGE = os.environ.get("EFFORT_PROTOCOL_TEST_IMAGE")
@unittest.skipUnless(IMAGE, "actual Docker tests require EFFORT_PROTOCOL_TEST_IMAGE")
class ExecutorTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(executor, "isolated command executor is not implemented")
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / "public-source"
        self.source.mkdir()
        (self.source / "program.txt").write_text("original production")
        (self.source / "probe.py").write_text("print('observed-value')\n")
        self.out = self.root / "host-only"
        self.request = {"id": "one", "run_id": "run", "phase": "investigate",
                        "argv": ["python3", "-I", "/work/probe.py"], "cwd": ".",
                        "test_files": ["probe.py"], "production_files": ["program.txt"],
                        "image": IMAGE, "kind": "observation",
                        "timeout_s": 10, "max_log_bytes": 1024 * 1024}

    def run_command(self):
        return executor.execute_observation(self.request, self.source, self.out)

    def record(self):
        return json.loads((self.out / "one" / "receipt.json").read_text())

    def test_actual_execution_is_source_bound_and_removed(self):
        result = self.run_command()
        self.assertEqual(result["exit_code"], 0)
        self.assertIn(b"observed-value", (self.out / "one" / "stdout").read_bytes())
        data = self.record()
        self.assertTrue(data["cleanup_complete"])
        self.assertEqual(data["source_before"], data["source_after"])
        self.assertEqual(data["source_before"], receipts.input_digest(self.out / "one" / "input"))
        self.assertEqual(data["image"], IMAGE)
        self.assertFalse(data["final_container_state"]["Running"])
        self.assertFalse(data["final_container_state"]["OOMKilled"])
        self.assertEqual(data["production_digest"], receipts.input_digest(self.source, ["program.txt"]))

    def test_production_snapshot_is_kernel_read_only(self):
        (self.source / "probe.py").write_text(
            "from pathlib import Path\n"
            "try:\n Path('/work/program.txt').write_text('altered')\n"
            "except OSError as e:\n print('read-only', e.errno)\n"
            "else:\n raise RuntimeError('source was writable')\n")
        self.assertEqual(self.run_command()["exit_code"], 0)
        self.assertEqual((self.source / "program.txt").read_text(), "original production")
        self.assertIn(b"read-only", (self.out / "one" / "stdout").read_bytes())

    def test_actor_cannot_read_host_receipt_namespace(self):
        hidden = self.out / "host-canary"
        hidden.parent.mkdir()
        hidden.write_text("controller-only")
        (self.source / "probe.py").write_text(
            "from pathlib import Path\n"
            f"assert not Path({str(hidden)!r}).exists()\n"
            "assert not Path('/home/marius').exists()\nprint('isolated')\n")
        self.assertEqual(self.run_command()["exit_code"], 0)

    def test_build_and_temporary_directories_are_writable(self):
        (self.source / "probe.py").write_text(
            "from pathlib import Path\n"
            "Path('/build/generated.txt').write_text('generated')\n"
            "Path('/tmp/probe.txt').write_text('temporary')\nprint('build-ok')\n")
        self.assertEqual(self.run_command()["exit_code"], 0)
        self.assertEqual((self.out / "one" / "build/generated.txt").read_text(), "generated")
        self.assertNotEqual(self.record()["build_before"], self.record()["build_after"])

    def test_functional_failure_retains_nonzero_observation(self):
        (self.source / "probe.py").write_text("print('assertion-failure'); raise SystemExit(7)\n")
        self.assertEqual(self.run_command()["exit_code"], 7)
        self.assertTrue(self.record()["resource_valid"])

    def test_same_policy_executes_a_shell_probe(self):
        (self.source / "probe.sh").write_text("printf 'shell-observation\\n'\n")
        self.request["argv"] = ["/bin/sh", "/work/probe.sh"]
        self.request["test_files"] = ["probe.sh"]
        self.assertEqual(self.run_command()["exit_code"], 0)
        self.assertIn(b"shell-observation", (self.out / "one" / "stdout").read_bytes())

    def test_container_cannot_use_host_network(self):
        (self.source / "probe.py").write_text(
            "import socket\ns=socket.socket(); s.settimeout(0.3)\n"
            "try:\n s.connect(('192.0.2.1',80))\n"
            "except OSError:\n print('network-disabled')\n"
            "else:\n raise RuntimeError('unexpected network connection')\n")
        self.assertEqual(self.run_command()["exit_code"], 0)
        self.assertEqual(self.record()["container_profile"]["NetworkMode"], "none")

    def test_timeout_is_invalid_and_container_is_removed(self):
        (self.source / "probe.py").write_text("import time\nprint('started', flush=True)\ntime.sleep(30)\n")
        self.request["timeout_s"] = 0.5
        with self.assertRaises(executor.ExecutionInvalid):
            self.run_command()
        failure = json.loads((self.out / "one" / "failure.json").read_text())
        self.assertTrue(failure["cleanup_complete"])
        self.assertEqual(failure["reason"], "timeout")
        self.assertFalse((self.out / "one" / "receipt.json").exists())

    def test_log_limit_is_not_a_complete_observation(self):
        (self.source / "probe.py").write_text("print('x'*50000)\n")
        self.request["max_log_bytes"] = 1000
        with self.assertRaises(executor.ExecutionInvalid):
            self.run_command()
        failure = json.loads((self.out / "one" / "failure.json").read_text())
        self.assertTrue(failure["cleanup_complete"])
        self.assertEqual(failure["reason"], "log_limit")

    def test_cgroup_oom_is_invalid_and_removed(self):
        (self.source / 'probe.py').write_text("print('allocating', flush=True)\nblock = bytearray(512 * 1024 * 1024)\nprint(len(block))\n")
        with self.assertRaises(executor.ExecutionInvalid):
            self.run_command()
        failure = json.loads((self.out / 'one' / 'failure.json').read_text())
        self.assertEqual(failure['reason'], 'oom')
        self.assertTrue(failure['cleanup_complete'])


    def test_generated_executable_inputs_are_bound(self):
        (self.source / 'probe.py').write_text("from pathlib import Path\nimport subprocess\nPath('/build/generated.py').write_text(\"print('generated-observation')\\n\")\nsubprocess.run(['python3','-I','/build/generated.py'], check=True)\n")
        self.assertEqual(self.run_command()['exit_code'], 0)
        self.assertEqual(self.record()['build_after'], receipts.input_digest(self.out / 'one' / 'build'))
        self.assertIn(b'generated-observation', (self.out / 'one' / 'stdout').read_bytes())

    def test_actor_cannot_overwrite_or_replay_a_receipt(self):
        self.run_command()
        before = (self.out / "one" / "receipt.json").read_bytes()
        with self.assertRaises(FileExistsError):
            self.run_command()
        self.assertEqual((self.out / "one" / "receipt.json").read_bytes(), before)

    def test_mutable_image_is_rejected_before_effect(self):
        self.request["image"] = "python:3.12-slim"
        with self.assertRaises(executor.ExecutionInvalid):
            self.run_command()
        self.assertFalse(self.out.exists())

    def test_test_path_escape_is_rejected_before_effect(self):
        self.request["test_files"] = ["../secret"]
        with self.assertRaises(executor.ExecutionInvalid):
            self.run_command()
        self.assertFalse(self.out.exists())

    def test_host_outputs_cannot_overlap_source(self):
        self.out = self.source / "host-only"
        with self.assertRaises(executor.ExecutionInvalid):
            self.run_command()
        self.assertFalse(self.out.exists())

    def test_generated_input_tampering_is_rejected_on_readback(self):
        (self.source / 'probe.py').write_text("from pathlib import Path\nPath('/build/generated.py').write_text(\"print('original')\\n\")\nprint('generated')\n")
        self.run_command()
        (self.out / 'one' / 'build' / 'generated.py').write_text("print('changed')\n")
        with self.assertRaises(receipts.ReceiptViolation):
            receipts.verify_receipt({'id': 'one'}, self.out, self.out / 'one' / 'input')

    def test_receipt_readback_uses_actual_frozen_copy(self):
        self.run_command()
        (self.source / "program.txt").write_text("later actor edits")
        result = receipts.verify_receipt({"id": "one"}, self.out, self.out / "one" / "input")
        self.assertEqual(result["exit_code"], 0)
        (self.out / "one" / "input" / "program.txt").write_text("frozen copy tampered")
        with self.assertRaises(receipts.ReceiptViolation):
            receipts.verify_receipt({"id": "one"}, self.out, self.out / "one" / "input")

if __name__ == "__main__":
    unittest.main()
