"""Read controller-owned evidence and bind it to exact execution inputs.

Authenticity depends on the runtime keeping execution_root outside all actor mounts.
These routines validate readback integrity; they do not prove execution, snapshot
immutability during a command, or semantic coverage without the runtime adapter.
"""
import hashlib
import json
import os
import re
import stat
from pathlib import Path

class ReceiptViolation(ValueError):
    """Evidence is absent, altered, unsupported or from the wrong boundary."""

def _require(condition, message):
    if not condition:
        raise ReceiptViolation(message)

def _hash(data):
    return hashlib.sha256(data).hexdigest()

def _is_digest(value):
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None

def _relative(value):
    _require(isinstance(value, str) and bool(value), "missing relative input path")
    path = Path(value)
    _require(not path.is_absolute() and ".." not in path.parts, "input path escape")
    return path

def input_digest(root: Path, selected: list[str] | None = None) -> str:
    """Hash every admitted input, including modes, untracked files and link targets."""
    root = Path(root)
    _require(root.is_dir() and not root.is_symlink(), "invalid input root")
    resolved = root.resolve()
    if selected is None:
        paths = sorted(root.rglob("*"))
    else:
        _require(isinstance(selected, list) and bool(selected)
                 and all(isinstance(p, str) for p in selected)
                 and len(set(selected)) == len(selected), "invalid test input inventory")
        paths = [root / _relative(name) for name in sorted(selected)]
    entries = {}
    for path in paths:
        relative = path.relative_to(root).as_posix()
        try:
            mode = path.lstat().st_mode
            _require(path.resolve().is_relative_to(resolved), "input symlink escapes snapshot")
            if stat.S_ISLNK(mode):
                entries[relative] = {"kind": "link", "target": os.readlink(path)}
            elif stat.S_ISREG(mode):
                entries[relative] = {"kind": "file", "mode": stat.S_IMODE(mode),
                                     "sha256": _hash(path.read_bytes())}
            elif stat.S_ISDIR(mode):
                entries[relative] = {"kind": "directory", "mode": stat.S_IMODE(mode)}
            else:
                raise ReceiptViolation("unsupported execution input")
        except OSError as exc:
            raise ReceiptViolation("execution input unavailable") from exc
    return _hash(json.dumps(entries, sort_keys=True, separators=(",", ":")).encode())

def _host_file(directory, name, limit):
    path = directory / name
    _require(not path.is_symlink() and path.is_file(), "missing or linked host evidence")
    _require(path.stat().st_size <= limit, "host evidence exceeds complete-capture limit")
    return path.read_bytes()

def verify_receipt(receipt: dict, execution_root: Path, source_snapshot: Path) -> dict:
    """Resolve an opaque receipt ID in host storage; never trust actor-supplied facts."""
    _require(isinstance(receipt, dict) and set(receipt) == {"id"},
             "actor may reference an ID only")
    rid = receipt["id"]
    _require(isinstance(rid, str) and re.fullmatch(r"[A-Za-z0-9_-]{1,128}", rid) is not None,
             "invalid receipt identifier")
    execution_root, source_snapshot = Path(execution_root), Path(source_snapshot)
    _require(not execution_root.is_symlink(), "linked host namespace")
    _require(not execution_root.resolve().is_relative_to(source_snapshot.resolve()),
             "host evidence namespace overlaps actor source")
    directory = execution_root / rid
    _require(not directory.is_symlink() and directory.is_dir(), "missing host receipt directory")
    try:
        record = json.loads(_host_file(directory, "receipt.json", 1024 * 1024))
    except (OSError, ValueError) as exc:
        raise ReceiptViolation("unreadable host receipt") from exc
    _require(isinstance(record, dict) and record.get("id") == rid, "host receipt identity mismatch")
    _require(record.get("capture_complete") is True and record.get("resource_valid") is True
             and record.get("cleanup_complete") is True, "incomplete or invalid execution")
    _require(type(record.get("exit_code")) is int, "missing raw exit status")
    argv = record.get("argv")
    _require(isinstance(argv, list) and bool(argv) and all(isinstance(x, str) for x in argv)
             and bool(argv[0]), "missing command")
    _relative(record.get("cwd"))
    _require(record.get("kind") in ("observation", "verification"), "unsupported evidence kind")
    for key in ("production_digest", "toolchain_digest", "dependency_digest"):
        _require(_is_digest(record.get(key)), "missing registered input binding")
    current = input_digest(source_snapshot)
    _require(record.get("source_before") == current and record.get("source_after") == current,
             "execution input snapshot drift")
    _require(isinstance(record.get("test_files"), list) and bool(record["test_files"]),
             "missing explicit test input inventory")
    _require(record.get("test_digest") == input_digest(source_snapshot, record.get("test_files")),
             "test input snapshot drift")
    _require(_is_digest(record.get("build_before")) and _is_digest(record.get("build_after")),
             "missing generated input inventory")
    _require(record["build_after"] == input_digest(directory / "build"),
             "generated execution input drift")
    streams = {}
    for name in ("stdout", "stderr"):
        streams[name] = _host_file(directory, name, 64 * 1024 * 1024)
        _require(record.get(name + "_sha256") == _hash(streams[name]), "execution log drift")
    if record["kind"] == "observation":
        _require(bool(streams["stdout"] or streams["stderr"]), "empty observation")
    _require(isinstance(record.get("run_id"), str) and bool(record["run_id"])
             and record.get("phase") in ("investigate", "repair", "challenge"),
             "missing execution identity")
    return {"id": rid, "run_id": record["run_id"], "phase": record["phase"],
            "source_digest": current, "production_digest": record["production_digest"],
            "test_digest": record["test_digest"], "exit_code": record["exit_code"],
            "complete": True, "resource_valid": True, "kind": record["kind"]}

def publish_exclusive(path: Path, record: dict) -> None:
    """Reserve and write a new immutable record; never overwrite an existing attempt."""
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(record, stream, sort_keys=True)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
