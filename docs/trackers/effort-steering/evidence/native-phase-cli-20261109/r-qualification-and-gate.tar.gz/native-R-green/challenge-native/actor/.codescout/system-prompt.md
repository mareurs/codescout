# Public fixture guidance
Use the source interfaces and public tests.
