from pathlib import Path
import sys
value=Path('fixed.txt').read_text().strip()
print('actual fixed value', value, 'case', sys.argv[1])
raise SystemExit(0 if sys.argv[1]=='keep' or value=='1' else 1)
