pub fn double(value: i32) -> i32 { value * 2 }
pub fn use_double() -> i32 { double(3) }
