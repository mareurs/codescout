# Public readiness fixture
Use the configured Codescout project.
