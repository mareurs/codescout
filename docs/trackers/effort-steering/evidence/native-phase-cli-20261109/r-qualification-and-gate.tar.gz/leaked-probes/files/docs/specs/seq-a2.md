---
id: c08ad3256166def0
kind: spec
status: draft
title: docs/specs/seq-a.md
---

fixture body
