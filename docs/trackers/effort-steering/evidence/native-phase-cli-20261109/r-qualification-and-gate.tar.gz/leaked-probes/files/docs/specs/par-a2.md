---
id: ea3e176236b61248
kind: spec
status: draft
title: docs/specs/par-a.md
---

fixture body
