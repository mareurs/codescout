---
id: 4ae6e898ddabfac7
kind: spec
status: draft
title: gate fixture
---

fixture body
