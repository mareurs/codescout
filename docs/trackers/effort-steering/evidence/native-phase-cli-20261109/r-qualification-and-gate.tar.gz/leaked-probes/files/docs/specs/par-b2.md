---
id: 86031184c4d345b5
kind: spec
status: draft
title: docs/specs/par-b.md
---

fixture body
