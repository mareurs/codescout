---
id: 7911304aa8236a0b
kind: bug
status: open
title: archive budget probe
---

probe body
