---
id: 535954121825b1a0
kind: spec
status: draft
title: docs/specs/whole-a.md
---

fixture body
