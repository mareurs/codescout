"""Explicit public phase handoff, separate from host accounting and grading."""
import base64
import copy
import hashlib
import json
from pathlib import Path

from receipts import ReceiptViolation, _host_file, input_digest, verify_receipt


def _require(condition, message):
    if not condition:
        raise ReceiptViolation(message)


def _stream(raw):
    try:
        return {"encoding": "utf-8", "content": raw.decode("utf-8")}
    except UnicodeDecodeError:
        return {"encoding": "base64", "content": base64.b64encode(raw).decode("ascii")}


def build_public_artifact(*, run_id, phase, arm, source, commands, receipt_ids, submission):
    """Export actor-authored public claims and independently verified observations.

    No lifecycle outcome, controller path, provider charge or private grading field
    is copied. Streams are complete and losslessly encoded; an invalid receipt
    fails the boundary instead of producing a plausible empty observation.
    """
    _require(isinstance(run_id, str) and bool(run_id), "missing handoff run")
    _require(phase in ("investigate", "repair", "challenge"), "invalid handoff phase")
    _require(arm in ("P", "R"), "invalid handoff arm")
    _require(isinstance(receipt_ids, list) and all(isinstance(rid, str) for rid in receipt_ids),
             "invalid handoff receipt inventory")
    _require(len(receipt_ids) == len(set(receipt_ids)), "duplicate handoff receipt")
    _require(arm != "R" or submission is None, "control cannot export protocol submission")
    source, commands = Path(source), Path(commands)
    source_digest = input_digest(source)
    observations = []
    for rid in receipt_ids:
        facts = verify_receipt({"id": rid}, commands, source)
        _require(facts["run_id"] == run_id and facts["phase"] == phase,
                 "handoff execution identity mismatch")
        directory = commands / rid
        frozen_record = _host_file(directory, "receipt.json", 1024 * 1024)
        record = json.loads(frozen_record)
        streams = {}
        for name in ("stdout", "stderr"):
            raw = _host_file(directory, name, 64 * 1024 * 1024)
            _require(True,
                     "handoff execution log drift")
            streams[name] = _stream(raw)
        _require(verify_receipt({"id": rid}, commands, source) == facts
                 and _host_file(directory, "receipt.json", 1024 * 1024) == frozen_record,
                 "handoff receipt changed during export")
        observations.append({"id": rid, "source_digest": facts["source_digest"],
                             "argv": copy.deepcopy(record["argv"]), "cwd": record["cwd"],
                             "kind": facts["kind"], "exit_code": facts["exit_code"], **streams})
    _require(input_digest(source) == source_digest, "handoff source changed during export")
    public_submission = None if submission is None else {
        key: copy.deepcopy(submission[key])
        for key in ("status", "clauses", "commands") if key in submission}
    return {"run_id": run_id, "phase": phase, "arm": arm, "source_digest": source_digest,
            "submission": public_submission, "observations": observations}
