"""Scratch review probes added only after observing all three mutants survive."""
import unittest
from unittest.mock import patch
import public_artifacts
from test_public_artifacts import PublicArtifactTests
from test_adapter import AdapterTests

class ReviewEdges(unittest.TestCase):
    def public_fixture(self):
        fixture = PublicArtifactTests()
        fixture.setUp()
        self.addCleanup(fixture.doCleanups)
        return fixture

    def test_source_changes_during_empty_control_export(self):
        fixture = self.public_fixture()
        original = public_artifacts.input_digest
        calls = 0
        def change_after_initial_hash(source):
            nonlocal calls
            digest = original(source)
            calls += 1
            if calls == 1:
                (fixture.source / "probe.py").write_text("changed during export")
            return digest
        with patch.object(public_artifacts, "input_digest", side_effect=change_after_initial_hash):
            with self.assertRaisesRegex(ValueError, "handoff source changed during export"):
                fixture.build(arm="R", receipt_ids=[], submission=None)

    def test_exported_bytes_match_verified_stream_hash(self):
        fixture = self.public_fixture()
        original = public_artifacts._host_file
        def transient_export_read(directory, name, limit):
            raw = original(directory, name, limit)
            return b"unverified transient bytes" if name == "stdout" else raw
        with patch.object(public_artifacts, "_host_file", side_effect=transient_export_read):
            with self.assertRaisesRegex(ValueError, "handoff execution log drift"):
                fixture.build()

    def test_challenge_verifications_are_present_in_public_artifact(self):
        fixture = AdapterTests()
        fixture.setUp()
        self.addCleanup(fixture.doCleanups)
        fixture.challenge()
        result = fixture.run_phase()
        self.assertEqual(result["state"]["phase"], "closed")
        observed = {row["id"]: row for row in result["public_artifact"]["observations"]}
        self.assertTrue(result["final_receipts"])
        self.assertEqual(set(observed), set(result["receipts"]))
        for rid in result["final_receipts"]:
            self.assertEqual(observed[rid]["kind"], "verification")
            self.assertEqual(observed[rid]["exit_code"], 0)
            self.assertEqual(observed[rid]["stdout"]["content"], "observed keep\n")
