"""Actual CLI + native Codescout + scripted zero-provider phase qualification."""
import importlib
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
try:
    native = importlib.import_module("qualify_native")
except ModuleNotFoundError as exc:
    if exc.name != "qualify_native":
        raise
    native = None

ENABLED = all(os.environ.get(k) for k in (
    "EFFORT_PROTOCOL_CLI", "EFFORT_PROTOCOL_NATIVE_IMAGE",
    "EFFORT_PROTOCOL_PLUGIN", "EFFORT_PROTOCOL_GLOBAL_RULES",
    "EFFORT_PROTOCOL_TEST_IMAGE", "EFFORT_PROTOCOL_RUNTIME_MANIFEST",
    "EFFORT_PROTOCOL_KNOWLEDGE"))

@unittest.skipUnless(ENABLED, "actual CLI qualification requires explicit frozen runtime paths")
class NativeQualificationTests(unittest.TestCase):
    def test_three_native_phases_zero_provider_and_context_bound(self):
        self.assertIsNotNone(native, "native phase qualification is not implemented")
        # Keep even a failed native control; automatic rmtree must not mask its error.
        tmp = Path(tempfile.mkdtemp(prefix="ep-native-qualification-", dir="/tmp"))
        result = native.qualify(tmp / "qualification", {
            "cli": os.environ["EFFORT_PROTOCOL_CLI"],
            "native_image": os.environ["EFFORT_PROTOCOL_NATIVE_IMAGE"],
            "plugin": os.environ["EFFORT_PROTOCOL_PLUGIN"],
            "global_rules": os.environ["EFFORT_PROTOCOL_GLOBAL_RULES"],
            "evidence_image": os.environ["EFFORT_PROTOCOL_TEST_IMAGE"],
            "runtime_manifest": os.environ["EFFORT_PROTOCOL_RUNTIME_MANIFEST"],
            "knowledge": os.environ["EFFORT_PROTOCOL_KNOWLEDGE"]})
        self.assertEqual(result["state"]["phase"], "closed")
        self.assertEqual(result["native_invocations"], 3)
        self.assertEqual(result["provider_forwarded"], 0)
        self.assertEqual(result["model_cost_usd"], "0")
        self.assertTrue(result["all_context_valid"])
        self.assertTrue(result["all_cleanup_complete"])
        self.assertEqual((Path(result["final_source"]) / "fixed.txt").read_text(), "1\n")

if __name__ == "__main__":
    unittest.main()
