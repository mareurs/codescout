# Generic effort protocol — implementation checkpoint

The generic policy, receipt verifier, immutable Docker evidence executor, phase orchestrator and native readiness guard are implemented in this isolated development worktree. No provider backend or automatic paid entry point is implemented. Paid readiness remains false.

The host must execute and capture real evidence; dictionary arguments do not authenticate actor claims. Native phase execution requires explicit backend classification and host-captured readiness before the actor call: correct root and source languages, complete MCP inventory, successful public LSP and semantic canaries, native index coverage, and executable/image/source/common-knowledge binding. The started receipt pins the readiness hash.

Programmatic onboarding restores configured languages and tool eligibility; it does not author a substantive project knowledge corpus or build an index. Reuse frozen source-only onboarding once per project/version with independent per-arm copies. Qualify actual CLI instruction delivery separately. Small actual native MCP controls passed; three-phase native CLI qualification and strongest independent applied-mutation review are pending.

For pure policy/readback/readiness tests, ordinary unittest discovery is sufficient. Set EFFORT_PROTOCOL_TEST_IMAGE to an existing immutable Python Docker image ID to also execute the real Docker executor/adapter controls. Native CLI tests require their separate explicit environment inputs; absent those, the native test is skipped. Report skips explicitly.

Canonical design/plan and the measured onboarding audit live in the main checkout. The execution ledger is .superpowers/sdd/evidence-protocol-plan-20261109/progress.md. New code is uncommitted. No real repair quality or low/xhigh parity is established by these preparation tests.
