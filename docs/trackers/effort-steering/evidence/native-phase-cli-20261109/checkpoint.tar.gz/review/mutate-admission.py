import json,os,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
p=root/'tools/effort_protocol/adapter.py';original=p.read_text()
cmd=['python3','-B','-m','unittest','-v','test_adapter.AdapterTests.test_native_backend_needs_real_preparation_before_actor_call']
env=dict(os.environ,TMPDIR=str(root),PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(root/'tools/effort_protocol'),EFFORT_PROTOCOL_TEST_IMAGE='sha256:02108f5d322dd89f1c9e552442c25acb0543dfdbc455693a5599624f20d9155d')
base=subprocess.run(cmd,env=env,capture_output=True,text=True);(root/'M11-baseline.log').write_text(base.stdout+base.stderr);assert base.returncode==0
find='readiness = _admit_backend(request, executor)';assert original.count(find)==1
try:
 p.write_text(original.replace(find,'readiness = None'))
 run=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180)
 (root/'M11-native-admission.log').write_text(run.stdout+run.stderr)
 record={'name':'M11-native-admission','find':find,'replace':'readiness = None','command':cmd,'exit_code':run.returncode,'verdict':'survived' if run.returncode==0 else 'killed'}
 print(json.dumps(record))
 rows=json.loads((root/'mutations.json').read_text());rows.append(record);(root/'mutations.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(original)
