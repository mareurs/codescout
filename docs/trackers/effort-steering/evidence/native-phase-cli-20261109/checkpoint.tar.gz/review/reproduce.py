import sys,json,errno,tempfile
from pathlib import Path
from unittest.mock import patch,MagicMock
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools/effort_protocol'))
import native_executor,adapter,qualify_native
from test_native_executor import NativeExecutorTests
results={}
# Known settled receipt is returned, then a corrupt context capture is parsed.
t=NativeExecutorTests();t.setUp()
try:
 (t.prepared/'request-0.json').write_text('{')
 request={'state':{'run_id':'r','phase':'repair'},'out':str(t.root/'phase'),'arm':'P',
  'phase_budget_usd':'0.50','public_packet':{'issue':'public'},'execution_mode':'native',
  'native_preflight':{}}
 with patch.object(adapter,'_admit_backend',return_value={'ready':True}),patch.object(native_executor.external,'launch',side_effect=t.launch) as launch:
  try: adapter.run_phase(request,t.executor)
  except adapter.PhaseInvalid as exc: results['known_charge_loss']={'error':str(exc),'raw_returned_cost':'0.07','adapter_cost':json.loads((t.root/'phase/cost.json').read_text()),'launch_calls':launch.call_count}
finally:t.doCleanups()
# Real captured readiness from v3 is accepted for a different prepared native actor.
t=NativeExecutorTests();t.setUp()
try:
 proof=json.loads(Path('/tmp/effort-native-cli-20261109-01a15ca9-v3/investigate-native/readiness.json').read_text())
 proof={k:proof[k] for k in ('expected','wire')}
 cfg=json.loads((t.prepared/'prepared.json').read_text());cfg['image']='sha256:'+'f'*64;(t.prepared/'prepared.json').write_text(json.dumps(cfg))
 request={'state':{'run_id':'different-run','phase':'repair'},'out':str(t.root/'phase'),'arm':'P',
  'phase_budget_usd':'0.50','public_packet':{'issue':'different public source'},'execution_mode':'native','native_preflight':proof}
 with patch.object(native_executor.external,'launch',side_effect=RuntimeError('intercepted before provider')) as launch:
  try:adapter.run_phase(request,t.executor)
  except adapter.PhaseInvalid as exc:results['stale_readiness_admits_launch']={'error':str(exc),'launch_calls':launch.call_count,'readiness_image':proof['expected']['binding']['image'],'prepared_image':cfg['image'],'readiness_source':proof['expected']['binding']['source_snapshot_sha256'],'actor_source':native_executor.input_digest(t.actor)}
finally:t.doCleanups()
# Failure writing audit bytes must not prevent cleanup; current code does.
with tempfile.TemporaryDirectory() as tmp:
 out=Path(tmp);proc=MagicMock();proc.stdin.write.side_effect=RuntimeError('forced RPC fault')
 with patch.object(qualify_native.subprocess,'Popen',return_value=proc),patch.object(qualify_native,'_save',side_effect=OSError(errno.EDQUOT,'Disk quota exceeded')),patch.object(qualify_native.subprocess,'run') as docker:
  try:qualify_native._readiness(out,['docker','--name','placeholder','--label','placeholder'],out,out,{'native_image':'sha256:'+'a'*64})
  except Exception as exc:results['readiness_cleanup_bypassed']={'error':repr(exc),'stdin_close_calls':proc.stdin.close.call_count,'wait_calls':proc.wait.call_count,'kill_calls':proc.kill.call_count,'docker_inspect_remove_calls':docker.call_count}
(root/'reproductions.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
