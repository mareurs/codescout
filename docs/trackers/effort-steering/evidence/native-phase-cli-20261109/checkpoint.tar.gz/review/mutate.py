from pathlib import Path
import os,json,subprocess
root=Path(__file__).resolve().parent
p=root/'tools/effort_protocol/native_executor.py'
original=p.read_text()
env=dict(os.environ,TMPDIR=str(root),PYTHONDONTWRITEBYTECODE='1')
cmd=['python3','-B','-m','unittest','discover','-s',str(root/'tools/effort_protocol'),'-p','test_native_executor.py','-v']
mutants=[
 ('M1-capture-tool-state','if source.name in TOOL_ROLES or source.name == "submission.json":','if source.name == "submission.json":'),
 ('M2-capture-git-state','if source.name in TOOL_ROLES or source.name == "submission.json":','if source.name in (TOOL_ROLES - {".git"}) or source.name == "submission.json":'),
 ('M3-context-consumer','and all(context.values()) and valid_turns','and valid_turns'),
 ('M4-cost-finality','"cost_is_final": receipt.get("unknown_provider_cost") is False','"cost_is_final": True'),
 ('M5-supervision-cleanup','and receipt.get("supervision_error") is None','and True'),
 ('M6-background-cleanup','and receipt.get("background_evidence", {}).get("complete") is True','and True'),
 ('M7-artifact-completeness','captured = receipt.get("artifact_evidence", {}).get("complete") is True','captured = True'),
 ('M8-continuation-bound','valid_turns = type(turns) is int and 0 <= turns <= 2','valid_turns = type(turns) is int'),
 ('M9-paid-admission','if self.scripted_plan is None and not self.allow_paid:','if False:'),
 ('M10-capture-input-binding','input_digest(destination)  # Refuses escaping symlinks and special files.','pass  # mutant bypasses capture validation'),
]
records=[]
try:
 for name,find,replace in mutants:
  assert original.count(find)==1,(name,original.count(find))
  p.write_text(original.replace(find,replace))
  result=subprocess.run(cmd,env=env,capture_output=True,text=True)
  (root/(name+'.log')).write_text(result.stdout+result.stderr)
  record={'name':name,'find':find,'replace':replace,'command':cmd,'exit_code':result.returncode,'verdict':'survived' if result.returncode==0 else 'killed'}
  records.append(record);print(name,record['verdict'],result.returncode,flush=True)
finally:
 p.write_text(original)
(root/'mutations.json').write_text(json.dumps(records,indent=2))
