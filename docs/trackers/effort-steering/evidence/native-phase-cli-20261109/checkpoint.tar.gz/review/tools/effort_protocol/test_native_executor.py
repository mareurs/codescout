"""Consumer checks for the native CLI phase boundary, with real file capture."""
import importlib
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parent))
try:
    native = importlib.import_module("native_executor")
except ModuleNotFoundError as exc:
    if exc.name != "native_executor":
        raise
    native = None


class NativeExecutorTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(native, "native CLI executor is not implemented")
        self.temp = tempfile.TemporaryDirectory(prefix="ep-native-unit-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.actor = self.root / "actor"
        self.actor.mkdir()
        (self.actor / "program.txt").write_text("original\n")
        (self.actor / ".codescout").mkdir()
        (self.actor / ".codescout/system-prompt.md").write_text("Shared source-only guidance.\n")
        self.prepared = self.root / "prepared"
        self.prepared.mkdir()
        cfg = {"actor": str(self.actor), "prompt": "unused public task", "max_continuations": 2}
        (self.prepared / "prepared.json").write_text(json.dumps(cfg))
        self.packet = {"run_id": "r", "phase": "repair", "prompt": "Repair from public evidence.",
                       "public_packet": {"issue": "Public request"}, "allowance_usd": "0.50",
                       "max_continuations": 2}
        self.receipt = {"context_valid": True, "cost_usd": "0.07", "unknown_provider_cost": False,
            "cleanup_error": None, "supervision_error": None,
            "background_evidence": {"complete": True}, "artifact_evidence": {"complete": True},
            "lifecycle": {"continuations": 1}, "forwarded": 0, "transport_errors": []}
        self.executor = native.NativeExecutor(self.prepared, self.root / "captured",
            system_lines=["Shared source-only guidance."], recon_marker="RECON_LOADED", scripted_plan=[])
        request = {"system": [{"type": "text", "text": "CLI system"}], "messages": [
            {"role": "assistant", "content": [
                {"type": "tool_use", "id": "s", "name": "mcp__codescout__read_file",
                 "input": {"path": ".codescout/system-prompt.md"}},
                {"type": "tool_use", "id": "k", "name": "Skill",
                 "input": {"skill": "codescout-companion:reconnaissance"}}]},
            {"role": "user", "content": [
                {"type": "tool_result", "tool_use_id": "s", "content": "Shared source-only guidance."},
                {"type": "tool_result", "tool_use_id": "k", "content": "Launching skill: codescout-companion:reconnaissance"}]},
        {"role": "user", "content": [{"type": "text", "text": "Base directory for this skill: /frozen/plugin/skills/reconnaissance\\n\\nRECON_LOADED"}]}]}
        (self.prepared / "request-0.json").write_text(json.dumps(request))

    def launch(self, *args, **kwargs):
        self.launched = kwargs
        (self.actor / "program.txt").write_text("repaired\n")
        (self.actor / "submission.json").write_text(json.dumps({"status": "submitted", "clauses": [], "commands": []}))
        return self.receipt

    def test_real_capture_excludes_tool_state_and_submission_and_preserves_cost(self):
        with patch.object(native.external, "launch", side_effect=self.launch):
            result = self.executor.execute(self.packet)
        captured = Path(result["source"])
        self.assertEqual((captured / "program.txt").read_text(), "repaired\n")
        self.assertFalse((captured / ".codescout").exists())
        self.assertFalse((captured / "submission.json").exists())
        self.assertEqual(result["cost_usd"], "0.07")
        self.assertEqual(result["turns"], 2)
        self.assertTrue(result["context_valid"])
        self.assertEqual(result["submission"]["status"], "submitted")
        cfg = json.loads((self.prepared / "prepared.json").read_text())
        self.assertEqual(cfg["max_continuations"], 2)
        self.assertIn("Public request", cfg["prompt"])
        self.assertIn("Repair from public evidence.", cfg["prompt"])
        self.assertEqual(self.launched["allowance"], "0.50")
        self.assertEqual(self.launched["scripted_plan"], [])

    def test_absent_native_context_is_not_replaced_by_receipt_boolean(self):
        (self.prepared / "request-0.json").unlink()
        with patch.object(native.external, "launch", side_effect=self.launch):
            result = self.executor.execute(self.packet)
        self.assertFalse(result["context_valid"])
        self.assertEqual(result["cost_usd"], "0.07")

    def test_echoing_context_in_an_unrelated_command_does_not_prove_delivery(self):
        p = self.prepared / "request-0.json"
        raw = json.loads(p.read_text())
        for block in raw["messages"][0]["content"]:
            block["name"] = "mcp__codescout__run_command"
            block["input"] = {"command": "echo pretend"}
        p.write_text(json.dumps(raw))
        with patch.object(native.external, "launch", side_effect=self.launch):
            result = self.executor.execute(self.packet)
        self.assertFalse(result["context_valid"])

    def test_real_cli_injects_skill_body_separately_from_its_acknowledgement(self):
        self.executor.recon_marker = "# /codescout-companion:reconnaissance"
        p = self.prepared / "request-0.json"
        raw = json.loads(p.read_text())
        raw["messages"][1]["content"][1]["content"] = "Launching skill: codescout-companion:reconnaissance"
        raw["messages"].append({"role": "user", "content": [{"type": "text", "text":
            "Base directory for this skill: /frozen/plugin/skills/reconnaissance\n\n"
            "# /codescout-companion:reconnaissance\n\nActual loaded skill body."}]})
        p.write_text(json.dumps(raw))
        with patch.object(native.external, "launch", side_effect=self.launch):
            result = self.executor.execute(self.packet)
        self.assertTrue(result["context_valid"])

    def test_skill_acknowledgement_without_its_body_is_not_delivery(self):
        self.executor.recon_marker = "# /codescout-companion:reconnaissance"
        p = self.prepared / "request-0.json"
        raw = json.loads(p.read_text())
        raw["messages"][1]["content"][1]["content"] = "Launching skill: codescout-companion:reconnaissance"
        p.write_text(json.dumps(raw))
        with patch.object(native.external, "launch", side_effect=self.launch):
            result = self.executor.execute(self.packet)
        self.assertFalse(result["context_valid"])

    def test_error_tool_result_does_not_prove_system_or_skill_delivery(self):
        p = self.prepared / "request-0.json"
        raw = json.loads(p.read_text())
        for block in raw["messages"][1]["content"]:
            block["is_error"] = True
        p.write_text(json.dumps(raw))
        with patch.object(native.external, "launch", side_effect=self.launch):
            result = self.executor.execute(self.packet)
        self.assertFalse(result["context_valid"])

    def test_missing_submission_is_returned_for_protocol_incomplete_without_retry(self):
        def launch(*args, **kwargs):
            return self.receipt
        with patch.object(native.external, "launch", side_effect=launch) as call:
            result = self.executor.execute(self.packet)
        self.assertIsNone(result["submission"])
        self.assertEqual(call.call_count, 1)
        self.assertTrue(result["capture_complete"])

    def test_cleanup_failure_and_unsettled_cost_are_not_silently_success(self):
        self.receipt["cleanup_error"] = "owned container removal not confirmed"
        self.receipt["unknown_provider_cost"] = True
        with patch.object(native.external, "launch", side_effect=self.launch):
            result = self.executor.execute(self.packet)
        self.assertFalse(result["cleanup_complete"])
        self.assertFalse(result["cost_is_final"])

    def test_source_symlink_escape_is_rejected_after_cost_is_preserved(self):
        outside = self.root / "outside"
        outside.write_text("host-private")
        (self.actor / "escape").symlink_to(outside)
        with patch.object(native.external, "launch", side_effect=self.launch):
            result = self.executor.execute(self.packet)
        self.assertFalse(result["capture_complete"])
        self.assertEqual(result["cost_usd"], "0.07")

    def test_default_executor_cannot_start_a_paid_call(self):
        executor = native.NativeExecutor(self.prepared, self.root / "captured",
            system_lines=["Shared source-only guidance."], recon_marker="RECON_LOADED")
        with patch.object(native.external, "launch") as call:
            with self.assertRaisesRegex(ValueError, "paid"):
                executor.execute(self.packet)
        call.assert_not_called()
