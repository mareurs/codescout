"""Native phase bridge: reuse lifecycle, retain its cost/capture/cleanup evidence.

The default is an offline scripted transport. Paid use requires separate explicit
admission. A scripted actual CLI is a runtime qualification, never an efficacy run.
"""
import json
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "agent_lifecycle"))
import external
from receipts import input_digest, publish_exclusive

# Explicit runner roles, identical to lifecycle artifact exclusions plus Git and
# the phase submission. These are not inferred from extensions or file contents.
TOOL_ROLES = {".git", ".codescout", ".buddy", ".superpowers", ".claude", "target", "node_modules"}
SYSTEM_PATH = ".codescout/system-prompt.md"
RECON = "codescout-companion:reconnaissance"


def _text(value):
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return "\n".join(_text(item) for item in value)
    if isinstance(value, dict):
        return "\n".join(_text(item) for item in value.values())
    return ""


def _context(out, system_lines, recon_marker):
    """Require successful native calls and the client's actual delivered body."""
    system_ok = recon_ok = False
    for path in sorted(out.glob("request-*.json")):
        body = json.loads(path.read_text())
        calls = {}
        skill_ack = skill_body = False
        for message in body.get("messages", []):
            blocks = message.get("content", [])
            if not isinstance(blocks, list):
                continue
            for block in blocks:
                if not isinstance(block, dict):
                    continue
                if message.get("role") == "assistant" and block.get("type") == "tool_use":
                    calls[block.get("id")] = block
                if message.get("role") == "user" and block.get("type") == "text":
                    text = block.get("text", "")
                    skill_body |= bool(recon_marker) and text.startswith("Base directory for this skill:") and recon_marker in text
                if message.get("role") != "user" or block.get("type") != "tool_result" or block.get("is_error"):
                    continue
                call = calls.get(block.get("tool_use_id"), {})
                args = call.get("input", {})
                text = _text(block.get("content"))
                if call.get("name") == "mcp__codescout__read_file" and args.get("path") == SYSTEM_PATH:
                    system_ok |= bool(system_lines) and all(line in text for line in system_lines)
                if call.get("name") == "Skill" and args.get("skill") == RECON:
                    skill_ack |= "Launching skill: " + RECON in text
        recon_ok |= skill_ack and skill_body
    return {"system_delivered": system_ok, "recon_delivered": recon_ok}


def _capture(actor, destination):
    destination.mkdir(exist_ok=False)
    for source in actor.iterdir():
        if source.name in TOOL_ROLES or source.name == "submission.json":
            continue
        target = destination / source.name
        if source.is_symlink():
            target.symlink_to(source.readlink())
        elif source.is_dir():
            shutil.copytree(source, target, symlinks=True)
        elif source.is_file():
            shutil.copy2(source, target)
        else:
            raise ValueError("unsupported native source input")
    input_digest(destination)  # Refuses escaping symlinks and special files.
    return str(destination)


class NativeExecutor:
    mode = "native"

    def __init__(self, prepared, capture, *, system_lines, recon_marker,
                 scripted_plan=None, allow_paid=False, token_path=None):
        self.prepared = Path(prepared).resolve()
        self.capture = Path(capture).resolve()
        self.system_lines = list(system_lines)
        self.recon_marker = recon_marker
        self.scripted_plan = scripted_plan
        self.allow_paid = allow_paid
        self.token_path = token_path

    def execute(self, request):
        if self.scripted_plan is None and not self.allow_paid:
            raise ValueError("paid native execution has not been admitted")
        if request.get("max_continuations") != 2:
            raise ValueError("native phase requires the registered continuation bound")
        cfg_path = self.prepared / "prepared.json"
        cfg = json.loads(cfg_path.read_text())
        if (self.prepared / "started.json").exists():
            raise ValueError("native phase cannot restart an existing attempt")
        cfg["prompt"] = request["prompt"] + "\n\nFrozen public packet:\n" + json.dumps(
            request["public_packet"], sort_keys=True) + "\n\nWrite submission.json in the project root."
        cfg["max_continuations"] = 2
        cfg_path.write_text(json.dumps(cfg, indent=2) + "\n")
        kwargs = {"effort": "low", "allowance": request["allowance_usd"],
                  "cli_cap": request["allowance_usd"], "scripted_plan": self.scripted_plan}
        if self.token_path is not None:
            kwargs["token_path"] = self.token_path
        receipt = external.launch(self.prepared, **kwargs)
        context = _context(self.prepared, self.system_lines, self.recon_marker)
        actor = Path(cfg["actor"])
        submission = None
        submission_path = actor / "submission.json"
        if submission_path.is_file() and not submission_path.is_symlink():
            try:
                submission = json.loads(submission_path.read_text())
            except (ValueError, OSError):
                pass  # Malformed actor submission is incomplete, not another call.
        captured = False
        capture_error = None
        try:
            _capture(actor, self.capture)
            captured = receipt.get("artifact_evidence", {}).get("complete") is True
        except (ValueError, OSError) as exc:
            capture_error = type(exc).__name__ + ": " + str(exc)
        turns = receipt.get("lifecycle", {}).get("continuations")
        valid_turns = type(turns) is int and 0 <= turns <= 2
        result = {"source": str(self.capture), "submission": submission,
            "cost_usd": receipt.get("cost_usd"),
            "cost_is_final": receipt.get("unknown_provider_cost") is False,
            "context_valid": receipt.get("context_valid") is True and all(context.values()) and valid_turns,
            "cleanup_complete": receipt.get("cleanup_error") is None
                and receipt.get("supervision_error") is None
                and receipt.get("background_evidence", {}).get("complete") is True,
            "capture_complete": captured, "capture_error": capture_error,
            "turns": turns + 1 if valid_turns else None,
            "context_evidence": context, "provider_forwarded": receipt.get("forwarded"),
            "scripted_provider": self.scripted_plan is not None}
        publish_exclusive(self.prepared / "native-executor.json", result)
        return result
