import sys
print('observed', sys.argv[-1]); raise SystemExit(1 if sys.argv[-1]=='bug' else 0)
