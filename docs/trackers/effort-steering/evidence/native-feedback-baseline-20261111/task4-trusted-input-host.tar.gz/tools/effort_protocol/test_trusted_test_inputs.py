"""Behavioral regressions for independent, canonical standalone test inputs."""
from pathlib import Path
import importlib
import os
import tempfile
import unittest

class TrustedTestInputsTests(unittest.TestCase):
    def setUp(self):
        self.api = importlib.import_module("trusted_test_inputs")
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.canonical = self.root / "canonical"
        self.candidate = self.root / "candidate"
        self.sealed = self.root / "sealed"
        for base in (self.canonical, self.candidate):
            (base / "tests/snapshots").mkdir(parents=True)
            (base / "src").mkdir()
            (base / "tests/snapshots/original.snap").write_text("original expectation\n")
            (base / "tests/existing.rs").write_text("original assertion\n")
            (base / "src/lib.rs").write_text("original production\n")
        (self.canonical / "tests/official-new.rs").write_text("official independent assertion\n")
        (self.candidate / "src/lib.rs").write_text("candidate repair\n")

    def seal(self, roots=None):
        return self.api.seal_test_inputs(self.canonical, roots or ["tests"], self.sealed)

    def test_restores_oracles_and_official_new_tests_without_changing_candidate_production(self):
        descriptor = self.seal()
        (self.candidate / "tests/snapshots/original.snap").write_text("candidate expectation\n")
        (self.candidate / "tests/existing.rs").unlink()
        result = self.api.restore_test_inputs(descriptor, self.candidate)
        self.assertEqual((self.candidate / "tests/snapshots/original.snap").read_text(), "original expectation\n")
        self.assertEqual((self.candidate / "tests/existing.rs").read_text(), "original assertion\n")
        self.assertEqual((self.candidate / "tests/official-new.rs").read_text(), "official independent assertion\n")
        self.assertEqual((self.candidate / "src/lib.rs").read_text(), "candidate repair\n")
        self.assertTrue(result["complete"])

    def test_removes_candidate_added_test_inputs_and_preserves_modes(self):
        descriptor = self.seal()
        (self.candidate / "tests/snapshots/addition.snap").write_text("candidate added oracle")
        self.api.restore_test_inputs(descriptor, self.candidate)
        self.assertFalse((self.candidate / "tests/snapshots/addition.snap").exists())
        self.assertEqual((self.candidate / "tests/existing.rs").stat().st_mode & 0o777,
                         (self.canonical / "tests/existing.rs").stat().st_mode & 0o777)

    def test_exact_file_root_does_not_reset_its_unrelated_sibling(self):
        descriptor = self.seal(["tests/snapshots/original.snap"])
        (self.candidate / "tests/existing.rs").write_text("other candidate test")
        (self.candidate / "tests/snapshots/original.snap").write_text("bad expected")
        self.api.restore_test_inputs(descriptor, self.candidate)
        self.assertEqual((self.candidate / "tests/existing.rs").read_text(), "other candidate test")
        self.assertEqual((self.candidate / "tests/snapshots/original.snap").read_text(), "original expectation\n")

    def test_archive_drift_refused_before_any_candidate_path_changes(self):
        descriptor = self.seal()
        archive = Path(descriptor["archive"])
        archive.write_bytes(archive.read_bytes() + b"corruption")
        (self.candidate / "tests/existing.rs").write_text("candidate remains")
        with self.assertRaises(ValueError):
            self.api.restore_test_inputs(descriptor, self.candidate)
        self.assertEqual((self.candidate / "tests/existing.rs").read_text(), "candidate remains")

    def test_manifest_drift_refused_before_any_candidate_path_changes(self):
        descriptor = self.seal()
        Path(descriptor["manifest"]).write_text("{}")
        with self.assertRaises(ValueError):
            self.api.restore_test_inputs(descriptor, self.candidate)
        self.assertFalse((self.candidate / "tests/official-new.rs").exists())
    def test_archive_under_destination_root_is_refused_without_losing_either_tree(self):
        descriptor = self.api.seal_test_inputs(
            self.canonical, ["tests"], self.candidate / "tests/sealed")
        with self.assertRaises(ValueError):
            self.api.restore_test_inputs(descriptor, self.candidate)
        self.assertTrue(Path(descriptor["archive"]).is_file())
        self.assertTrue(Path(descriptor["manifest"]).is_file())
        self.assertEqual((self.candidate / "tests/existing.rs").read_text(), "original assertion\n")

    def test_root_escape_overlap_and_tool_roles_rejected(self):
        for roots in ([], ["."], ["../outside"], ["/tests"], ["tests", "tests/snapshots"],
                      [".git"], [".codescout"], ["missing"]):
            with self.subTest(roots=roots), self.assertRaises(ValueError):
                self.api.seal_test_inputs(self.canonical, roots, self.sealed)

    def test_destination_parent_symlink_cannot_redirect_restoration(self):
        (self.canonical / "src/tests").mkdir()
        (self.canonical / "src/tests/check.rs").write_text("private assertion")
        descriptor = self.seal(["src/tests"])
        import shutil
        shutil.rmtree(self.candidate / "src")
        outside = self.root / "outside"
        outside.mkdir()
        (outside / "marker").write_text("preserve")
        (self.candidate / "src").symlink_to(outside, target_is_directory=True)
        with self.assertRaises(ValueError):
            self.api.restore_test_inputs(descriptor, self.candidate)
        self.assertEqual((outside / "marker").read_text(), "preserve")
        self.assertFalse((outside / "tests").exists())

    def test_leaf_link_is_restored_without_freezing_its_candidate_production_referent(self):
        (self.canonical / "tests/source-link").symlink_to("../src/lib.rs")
        descriptor = self.seal()
        (self.candidate / "tests/source-link").write_text("candidate link replacement")
        self.api.restore_test_inputs(descriptor, self.candidate)
        self.assertTrue((self.candidate / "tests/source-link").is_symlink())
        self.assertEqual(os.readlink(self.candidate / "tests/source-link"), "../src/lib.rs")
        self.assertEqual((self.candidate / "src/lib.rs").read_text(), "candidate repair\n")

    def test_escaping_canonical_link_refused(self):
        (self.canonical / "tests/escape").symlink_to("../../outside")
        with self.assertRaises(ValueError):
            self.seal()

if __name__ == "__main__":
    unittest.main()
