"""Seal and restore canonical standalone test inputs without changing candidate production.

Coverage is the explicitly registered roots, not every possible inline assertion.
The archive and complete inventory are checked before any destination is changed.
"""
from pathlib import Path, PurePosixPath
import hashlib
import json
import os
import shutil
import stat
import tarfile

SCHEMA = "trusted-test-input-tree-v1"
FORBIDDEN = {".git", ".codescout", ".claude", ".superpowers"}


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _hash_stream(stream):
    digest = hashlib.sha256()
    for block in iter(lambda: stream.read(1024 * 1024), b""):
        digest.update(block)
    return digest.hexdigest()


def _sha(path):
    with Path(path).open("rb") as stream:
        return _hash_stream(stream)


def _relative(name):
    _require(isinstance(name, str) and name and "\0" not in name, "test input path missing")
    path = PurePosixPath(name)
    _require(not path.is_absolute() and str(path) == name and name != "."
             and ".." not in path.parts and not FORBIDDEN.intersection(path.parts),
             "unsafe test input path")
    return path


def _roots(values):
    _require(isinstance(values, list) and values and len(set(values)) == len(values),
             "nonempty unique test roots required")
    roots = sorted(str(_relative(value)) for value in values)
    for index, name in enumerate(roots):
        _require(not any(PurePosixPath(name).is_relative_to(parent) for parent in roots[:index]),
                 "overlapping test input roots")
    return roots


def _physical_directory(path):
    path = Path(path).absolute()
    _require(path.is_dir() and not path.is_symlink() and path.resolve() == path,
             "physical test input directory required")
    return path


def _inventory(base, roots):
    entries = {}
    for root in roots:
        selected = base / root
        _require(selected.exists() or selected.is_symlink(), "test input root missing")
        names = [selected]
        if selected.is_dir() and not selected.is_symlink():
            names.extend(selected.rglob("*"))
        for path in sorted(names):
            relative = path.relative_to(base).as_posix()
            _relative(relative)
            mode = path.lstat().st_mode
            permissions = stat.S_IMODE(mode)
            if stat.S_ISLNK(mode):
                target = os.readlink(path)
                _require(not Path(target).is_absolute() and path.resolve().is_relative_to(base),
                         "canonical test link escapes repository")
                entries[relative] = {"kind": "link", "mode": permissions, "target": target}
            elif stat.S_ISDIR(mode):
                entries[relative] = {"kind": "directory", "mode": permissions}
            elif stat.S_ISREG(mode):
                entries[relative] = {"kind": "file", "mode": permissions,
                                     "size": path.stat().st_size, "sha256": _sha(path)}
            else:
                raise ValueError("unsupported test input entry")
    return dict(sorted(entries.items()))


def _json(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")


def seal_test_inputs(source, roots, out):
    source = _physical_directory(source)
    roots = _roots(roots)
    entries = _inventory(source, roots)
    out = Path(out).absolute()
    _require(not out.exists() and not out.is_symlink()
             and out.parent.resolve() == out.parent and out.parent.is_dir()
             and not out.is_relative_to(source) and not source.is_relative_to(out),
             "test input archive paths overlap or exist")
    out.mkdir()
    archive = out / "inputs.tar"
    with tarfile.open(archive, "w") as tar:
        for name, value in entries.items():
            info = tarfile.TarInfo(name)
            info.mode, info.mtime = value["mode"], 0
            if value["kind"] == "directory":
                info.type = tarfile.DIRTYPE
                tar.addfile(info)
            elif value["kind"] == "link":
                info.type, info.linkname = tarfile.SYMTYPE, value["target"]
                tar.addfile(info)
            else:
                info.size = value["size"]
                with (source / name).open("rb") as stream:
                    tar.addfile(info, stream)
    _require(_inventory(source, roots) == entries, "canonical inputs changed during seal")
    manifest = out / "manifest.json"
    _json(manifest, {"schema": SCHEMA, "roots": roots, "entries": entries,
                     "archive_sha256": _sha(archive),
                     "coverage": "Registered standalone roots only; inline assertions require separate audit."})
    descriptor = {"schema": SCHEMA, "manifest": str(manifest), "manifest_sha256": _sha(manifest),
                  "archive": str(archive), "archive_sha256": _sha(archive)}
    _validated(descriptor)
    return descriptor


def _unique_pairs(pairs):
    result = {}
    for key, value in pairs:
        _require(key not in result, "duplicate test input metadata key")
        result[key] = value
    return result


def _validated(descriptor):
    _require(isinstance(descriptor, dict) and set(descriptor) == {
        "schema", "manifest", "manifest_sha256", "archive", "archive_sha256"},
        "test input descriptor incomplete")
    _require(descriptor["schema"] == SCHEMA, "test input schema differs")
    manifest, archive = Path(descriptor["manifest"]), Path(descriptor["archive"])
    _require(all(path.is_absolute() and path.is_file() and not path.is_symlink()
                 and path.resolve() == path for path in (manifest, archive)), "unbound test input artifacts")
    _require(_sha(manifest) == descriptor["manifest_sha256"] and
             _sha(archive) == descriptor["archive_sha256"], "trusted test input bytes changed")
    try:
        value = json.loads(manifest.read_bytes(), object_pairs_hook=_unique_pairs)
        roots, entries = _roots(value["roots"]), value["entries"]
        _require(value["schema"] == SCHEMA and value["archive_sha256"] == descriptor["archive_sha256"]
                 and isinstance(entries, dict) and entries, "invalid test inventory")
        for name in entries:
            path = _relative(name)
            _require(any(path.is_relative_to(root) for root in roots), "input outside registered roots")
        with tarfile.open(archive, "r:") as tar:
            members = tar.getmembers()
            _require(len(members) == len(entries) and
                     len({member.name for member in members}) == len(members),
                     "test input archive membership differs")
            actual = {}
            for member in members:
                _relative(member.name)
                if member.isdir():
                    item = {"kind": "directory", "mode": member.mode}
                elif member.issym():
                    item = {"kind": "link", "mode": member.mode, "target": member.linkname}
                elif member.isfile():
                    with tar.extractfile(member) as stream:
                        item = {"kind": "file", "mode": member.mode, "size": member.size,
                                "sha256": _hash_stream(stream)}
                else:
                    raise ValueError("unsupported archive member")
                actual[member.name] = item
            _require(actual == entries, "test input archive contradicts its inventory")
    except (KeyError, TypeError, OSError, tarfile.TarError) as exc:
        raise ValueError("invalid trusted test inputs") from exc
    return roots, entries, archive


def restore_test_inputs(descriptor, destination):
    roots, entries, archive = _validated(descriptor)
    destination = _physical_directory(destination)
    _require(not any(Path(descriptor[role]).is_relative_to(destination / name)
                     for role in ("manifest", "archive") for name in roots),
             "trusted artifacts overlap a destination input root")
    # Preflight every parent before deleting any registered input.
    for name in roots:
        parent = destination
        for part in PurePosixPath(name).parts[:-1]:
            parent = parent / part
            _require(not parent.is_symlink() and (not parent.exists() or parent.is_dir()),
                     "candidate test input parent is not a physical directory")
    for name in roots:
        target = destination / name
        if target.is_symlink() or target.is_file():
            target.unlink()
        elif target.exists():
            _require(target.is_dir(), "unexpected candidate input type")
            shutil.rmtree(target)
    directories = sorted((name for name, item in entries.items() if item["kind"] == "directory"),
                         key=lambda name: len(PurePosixPath(name).parts))
    for name in directories:
        (destination / name).mkdir(parents=True, exist_ok=True)
    with tarfile.open(archive, "r:") as tar:
        for member in tar.getmembers():
            item = entries[member.name]
            if item["kind"] != "file":
                continue
            target = destination / member.name
            target.parent.mkdir(parents=True, exist_ok=True)
            with tar.extractfile(member) as source, target.open("xb") as stream:
                shutil.copyfileobj(source, stream, 1024 * 1024)
            target.chmod(item["mode"])
    for name, item in entries.items():
        if item["kind"] == "link":
            target = destination / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.symlink_to(item["target"])
    for name in reversed(directories):
        (destination / name).chmod(entries[name]["mode"])
    _require(_inventory(destination, roots) == entries, "restored canonical inputs differ")
    return {"complete": True, "roots": roots, "entries_verified": len(entries),
            "manifest_sha256": descriptor["manifest_sha256"],
            "coverage": "Registered standalone inputs; no inline assertion claim"}
