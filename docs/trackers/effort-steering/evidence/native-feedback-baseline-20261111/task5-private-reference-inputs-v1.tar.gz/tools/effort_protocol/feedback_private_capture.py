"""Generic captured libtest transport layered over the frozen literal-shell preparation.

Only the test framework output policy changes. Original selected tests, assertions,
labels, source patches, report/parser/print and compiler-prefix selection remain.
"""
import shlex
import feedback_private_commands as shell

def prepare_captured_shell_record(original,*,image,bootstrap=None):
    prepared=shell.prepare_shell_record(original,image=image,bootstrap=bootstrap)
    commands=[];environments=[]
    for command in prepared["record"]["test_cmds"]:
        words=shlex.split(command)
        if words[-4:-1]==["2>&1","|","tee"]:
            transport=" 2>&1 | tee "+words[-1];words=words[:-4]
        elif words[-3]==">" and words[-1]=="2>&1":
            transport=" > "+words[-2]+" 2>&1";words=words[:-3]
        else:
            raise ValueError("prepared report transport differs")
        environment,cargo=shell._literal_cargo(words,{"test"})
        inherited=[value for value in environment if value.startswith("RUST_TEST_NOCAPTURE=")]
        if inherited and inherited!=["RUST_TEST_NOCAPTURE=0"]:
            raise ValueError("source environment forces unqualified nocapture")
        if "--" in cargo:
            index=cargo.index("--");compilation,binary=cargo[:index],cargo[index+1:]
        else:
            compilation,binary=cargo,[]
        output_flags=("--format","--quiet","-q","--list","--help","-h")
        if (any(word in output_flags or word.startswith("--format=") for word in binary+compilation[2:])
                or sum(word in ("--nocapture","--no-capture") for word in binary)>1
                or binary.count("--show-output")>1):
            raise ValueError("source output policy requires another measured contract")
        binary=[word for word in binary if word not in ("--nocapture","--no-capture","--show-output")]
        environment=[value for value in environment if not value.startswith("RUST_TEST_NOCAPTURE=")]
        environment.append("RUST_TEST_NOCAPTURE=0")
        commands.append(shell._cargo_shell(environment,[*compilation,"--",*binary,"--show-output"])+transport)
        environments.append(environment)
    prepared["parent_preparation_schema"]=prepared["schema"]
    prepared["schema"]="captured-libtest-shell-preparation-v1"
    prepared["record"]["test_cmds"]=commands
    prepared["test_environments"]=environments
    prepared["capture_mode"]="show-output"
    return prepared
