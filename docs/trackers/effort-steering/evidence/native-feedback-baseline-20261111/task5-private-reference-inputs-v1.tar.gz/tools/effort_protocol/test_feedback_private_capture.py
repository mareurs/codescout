"""Regression: nocapture must not corrupt the registered original libtest status population."""
from pathlib import Path
import copy,importlib,os,shlex,subprocess,sys,tempfile,unittest
try:
    subject=importlib.import_module("feedback_private_capture")
except ModuleNotFoundError:
    subject=None

class CapturedPrivateCommandsTests(unittest.TestCase):
    IMAGE="sha256:"+"a"*64
    def setUp(self):
        self.assertIsNotNone(subject,"captured-output transport adapter is missing")
    def record(self,command):
        return {"instance_id":"other-project","FAIL_TO_PASS":["alpha"],"PASS_TO_PASS":["beta"],
            "patch":"implementation","test_patch":"official assertions","log_parser":"original literal parser",
            "test_cmds":[command],"rebuild_cmds":[],"print_cmds":["cd /testbed && cat reports/result.log"]}
    def prepare(self,record):
        return subject.prepare_captured_shell_record(record,image=self.IMAGE)
    def test_output_mode_changes_without_altering_selectors_labels_or_compile_prefix(self):
        original=self.record('cd /testbed && FLAGS="a b" cargo test --workspace --lib --exclude unrelated -- alpha --exact --nocapture --test-threads=3 2>&1 | tee reports/result.log')
        before=copy.deepcopy(original);plan=self.prepare(original);record=plan["record"]
        self.assertEqual(original,before)
        self.assertEqual(record["rebuild_cmds"],["env 'FLAGS=a b' cargo test --workspace --lib --exclude unrelated --no-run"])
        self.assertEqual(shlex.split(record["test_cmds"][0]),["env","FLAGS=a b","RUST_TEST_NOCAPTURE=0",
            "cargo","test","--no-fail-fast","--workspace","--lib","--exclude","unrelated","--","alpha",
            "--exact","--test-threads=3","--show-output","2>&1","|","tee","reports/result.log"])
        for key in original.keys()-{"test_cmds","rebuild_cmds"}:
            self.assertEqual(record[key],original[key])
    def test_real_shell_delivers_capture_mode_and_preserves_log_and_failure_code(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);binary=root/"bin";binary.mkdir();(root/"reports").mkdir()
            cargo=binary/"cargo"
            cargo.write_text("#!"+sys.executable+chr(10)+"import json,os,sys"+chr(10)+
                "print(json.dumps({'argv':sys.argv[1:],'flag':os.environ.get('FLAGS'),'capture':os.environ.get('RUST_TEST_NOCAPTURE')}))"+chr(10)+
                "print('outer diagnostic',file=sys.stderr)"+chr(10)+"raise SystemExit(23)"+chr(10))
            cargo.chmod(0o755)
            env={**os.environ,"PATH":str(binary)+os.pathsep+os.environ["PATH"],"RUST_TEST_NOCAPTURE":"1"}
            for transport in ("2>&1 | tee reports/result.log","> reports/result.log 2>&1"):
                with self.subTest(transport=transport):
                    record=self.prepare(self.record('FLAGS="a b" cargo test --lib -- --no-capture '+transport))["record"]
                    run=subprocess.run(["bash","-o","pipefail","-c",record["test_cmds"][0]],
                        cwd=root,env=env,capture_output=True,text=True)
                    self.assertEqual(run.returncode,23)
                    lines=(root/"reports/result.log").read_text().splitlines()
                    import json
                    actual=next(json.loads(line) for line in lines if line.startswith("{"))
                    self.assertEqual(actual,{"argv":["test","--no-fail-fast","--lib","--","--show-output"],
                        "flag":"a b","capture":"0"})
                    self.assertIn("outer diagnostic",lines)
    def test_default_and_already_captured_modes_remain_one_explicit_captured_mode(self):
        for suffix in (""," -- --show-output"," -- --nocapture --show-output"):
            with self.subTest(suffix=suffix):
                record=self.prepare(self.record("cargo test --lib"+suffix+" > reports/result.log 2>&1"))["record"]
                argv=shlex.split(record["test_cmds"][0])
                self.assertEqual(argv.count("--show-output"),1)
                self.assertNotIn("--nocapture",argv)
                self.assertEqual(argv[-3:],[">","reports/result.log","2>&1"])
    def test_conflicting_output_policies_and_environment_are_refused(self):
        commands=("RUST_TEST_NOCAPTURE=1 cargo test -- --nocapture",
            "cargo test -- --format=json","cargo test -- --format terse","cargo test -- --quiet",
            "cargo test -q","cargo test -- --list","cargo test -- --help","cargo test -- --nocapture --no-capture")
        for command in commands:
            with self.subTest(command=command),self.assertRaises(ValueError):
                self.prepare(self.record(command+" > reports/result.log 2>&1"))
if __name__=="__main__":unittest.main()
