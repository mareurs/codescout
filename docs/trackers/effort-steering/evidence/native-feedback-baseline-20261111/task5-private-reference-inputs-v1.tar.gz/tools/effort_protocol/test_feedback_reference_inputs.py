"""Complete private references must never substitute for actor baseline inputs."""
import copy
import importlib
import json
import os
from pathlib import Path
import tempfile
import unittest

from receipts import input_digest
from trusted_test_inputs import seal_test_inputs

try:
    subject = importlib.import_module("feedback_reference_inputs")
except ModuleNotFoundError:
    subject = None


class ReferenceInputTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(subject, "versioned complete-reference constructor is missing")
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.baseline = self.root / "actor-baseline"
        (self.baseline / "src").mkdir(parents=True)
        (self.baseline / "tests").mkdir()
        (self.baseline / "empty").mkdir(mode=0o750)
        (self.baseline / "src/lib.rs").write_text("old implementation\n")
        (self.baseline / "tests/check.txt").write_text("old assertion\n")
        self.record = {
            "instance_id": "generic-task",
            "patch": "diff --git a/src/lib.rs b/src/lib.rs\n--- a/src/lib.rs\n+++ b/src/lib.rs\n@@ -1 +1 @@\n-old implementation\n+new implementation\n",
            "test_patch": "diff --git a/tests/check.txt b/tests/check.txt\n--- a/tests/check.txt\n+++ b/tests/check.txt\n@@ -1 +1 @@\n-old assertion\n+official assertion\n"
                "diff --git a/tests/support.txt b/tests/support.txt\nnew file mode 100644\n--- /dev/null\n+++ b/tests/support.txt\n@@ -0,0 +1 @@\n+official support\n",
            "FAIL_TO_PASS": ["official"], "PASS_TO_PASS": ["unchanged"],
        }
        self.canonical = self.root / "canonical"
        (self.canonical / "tests").mkdir(parents=True)
        (self.canonical / "tests/check.txt").write_text("official assertion\n")
        (self.canonical / "tests/support.txt").write_text("official support\n")
        self.trusted = seal_test_inputs(self.canonical, ["tests"], self.root / "sealed")
        self.before = input_digest(self.baseline)

    def test_full_original_patch_pair_is_required_and_original_baseline_is_untouched(self):
        original = copy.deepcopy(self.record)
        trusted_before = copy.deepcopy(self.trusted)
        descriptor = subject.prepare_reference(self.baseline, self.record, self.trusted, self.root / "private")
        ref = Path(descriptor["reference"])
        self.assertEqual(descriptor["schema"], "private-reference-inputs-v1")
        self.assertEqual(descriptor["role"], "private-reference-only")
        self.assertEqual(descriptor["baseline"], str(self.baseline))
        self.assertEqual(descriptor["baseline_sha256"], self.before)
        self.assertNotEqual(ref, self.baseline)
        self.assertEqual((ref / "src/lib.rs").read_text(), "new implementation\n")
        self.assertEqual((ref / "tests/check.txt").read_text(), "official assertion\n")
        self.assertEqual((ref / "tests/support.txt").read_text(), "official support\n")
        self.assertEqual((ref / "empty").stat().st_mode & 0o777, 0o750)
        self.assertEqual(input_digest(self.baseline), self.before)
        self.assertEqual(self.record, original)
        self.assertEqual(self.trusted, trusted_before)
        verified = subject.verify_reference(descriptor, self.baseline, self.record, self.trusted)
        self.assertTrue(verified["complete"])
        self.assertEqual(verified["reference_sha256"], input_digest(ref))
        # Matching self-reported hashes cannot make implementation-only a full reference.
        (ref / "tests/support.txt").unlink()
        descriptor["reference_sha256"] = input_digest(ref)
        with self.assertRaises(ValueError):
            subject.verify_reference(descriptor, self.baseline, self.record, self.trusted)

    def test_rehashed_production_file_or_empty_directory_mode_is_not_an_original_reference(self):
        for mutation in ("implementation", "empty-directory-mode", "extra-untracked-file"):
            with self.subTest(mutation=mutation):
                descriptor = subject.prepare_reference(self.baseline, self.record, self.trusted, self.root / mutation)
                ref = Path(descriptor["reference"])
                if mutation == "implementation":
                    (ref / "src/lib.rs").write_text("silently dropped implementation\n")
                elif mutation == "empty-directory-mode":
                    (ref / "empty").chmod(0o700)
                else:
                    (ref / "extra").write_text("unregistered\n")
                descriptor["reference_sha256"] = input_digest(ref)
                with self.assertRaises(ValueError):
                    subject.verify_reference(descriptor, self.baseline, self.record, self.trusted)

    def test_both_original_patch_bytes_and_role_are_mandatory(self):
        descriptor = subject.prepare_reference(self.baseline, self.record, self.trusted, self.root / "private")
        for field, value in (("role", "public-actor"), ("test_patch_sha256", "0" * 64),
                             ("patch_sha256", "0" * 64), ("record_sha256", "0" * 64)):
            with self.subTest(field=field):
                changed = dict(descriptor, **{field: value})
                with self.assertRaises(ValueError):
                    subject.verify_reference(changed, self.baseline, self.record, self.trusted)
        for key in ("patch", "test_patch"):
            with self.subTest(key=key):
                original = Path(descriptor[key]).read_bytes()
                Path(descriptor[key]).write_bytes(original + b"\n")
                with self.assertRaises(ValueError):
                    subject.verify_reference(descriptor, self.baseline, self.record, self.trusted)
                Path(descriptor[key]).write_bytes(original)
        for key in ("patch", "test_patch"):
            for value in (None, ""):
                with self.subTest(key=key, value=value):
                    with self.assertRaises(ValueError):
                        subject.prepare_reference(self.baseline, dict(self.record, **{key: value}),
                                                  self.trusted, self.root / ("missing-" + key))

    def test_alias_overlap_and_existing_output_are_refused_without_touching_baseline(self):
        alias = self.root / "alias"
        alias.symlink_to(self.baseline, target_is_directory=True)
        for baseline, output in ((alias, self.root / "out"), (self.baseline, self.baseline / "inside"),
                                 (self.baseline, self.root), (self.baseline, alias / "out")):
            with self.subTest(baseline=str(baseline), output=str(output)):
                with self.assertRaises(ValueError):
                    subject.prepare_reference(baseline, self.record, self.trusted, output)
        self.assertEqual(input_digest(self.baseline), self.before)

    def test_file_modes_internal_links_and_official_fixture_deletions_are_preserved(self):
        (self.baseline / "lib-link").symlink_to("src/lib.rs")
        (self.baseline / "tests/obsolete.txt").write_text("obsolete\n")
        record = copy.deepcopy(self.record)
        record["patch"] = record["patch"].replace("--- a/src/lib.rs",
            "old mode 100644\nnew mode 100755\n--- a/src/lib.rs")
        record["test_patch"] += ("diff --git a/tests/obsolete.txt b/tests/obsolete.txt\n"
            "deleted file mode 100644\n--- a/tests/obsolete.txt\n+++ /dev/null\n@@ -1 +0,0 @@\n-obsolete\n")
        descriptor = subject.prepare_reference(self.baseline, record, self.trusted, self.root / "private")
        ref = Path(descriptor["reference"])
        self.assertEqual((ref / "src/lib.rs").stat().st_mode & 0o777, 0o755)
        self.assertEqual(os.readlink(ref / "lib-link"), "src/lib.rs")
        self.assertFalse((ref / "tests/obsolete.txt").exists())
        self.assertTrue((self.baseline / "tests/obsolete.txt").exists())
        self.assertEqual(subject.verify_reference(descriptor, self.baseline, record, self.trusted)
                         ["reference_sha256"], input_digest(ref))

    def test_changed_actor_baseline_or_canonical_archive_is_rejected(self):
        descriptor = subject.prepare_reference(self.baseline, self.record, self.trusted, self.root / "private")
        (self.baseline / "src/lib.rs").write_text("changed baseline\n")
        with self.assertRaises(ValueError):
            subject.verify_reference(descriptor, self.baseline, self.record, self.trusted)
        (self.baseline / "src/lib.rs").write_text("old implementation\n")
        archive = Path(self.trusted["archive"])
        archive.write_bytes(archive.read_bytes() + b"changed")
        with self.assertRaises(ValueError):
            subject.verify_reference(descriptor, self.baseline, self.record, self.trusted)

    def test_official_support_patch_is_not_replaced_by_unrelated_canonical_inputs(self):
        record = dict(self.record, test_patch=self.record["test_patch"].replace("official support", "wrong support"))
        with self.assertRaises(ValueError):
            subject.prepare_reference(self.baseline, record, self.trusted, self.root / "private")

    def test_escaping_links_are_not_copied_or_followed(self):
        outside = self.root / "outside"
        outside.write_text("sentinel")
        (self.baseline / "escape").symlink_to("../outside")
        with self.assertRaises(ValueError):
            subject.prepare_reference(self.baseline, self.record, self.trusted, self.root / "private")
        self.assertEqual(outside.read_text(), "sentinel")
