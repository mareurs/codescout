"""Private benchmark reference composition; never an actor/public source constructor."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

from receipts import input_digest
from trusted_test_inputs import verify_test_inputs

SCHEMA = "private-reference-inputs-v1"
ROLE = "private-reference-only"


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _physical(path, *, directory=True):
    path = Path(path).absolute()
    _require(path.resolve() == path and not path.is_symlink()
             and (path.is_dir() if directory else path.is_file()), "reference input path is not physical")
    return path


def _patches(record):
    _require(isinstance(record, dict), "original reference record is missing")
    result = {}
    for key in ("patch", "test_patch"):
        value = record.get(key)
        _require(isinstance(value, str) and value.strip(), "both original reference patches are required")
        result[key] = value.encode("utf-8")
    return result


def _record_sha(record):
    return _sha(json.dumps(record, sort_keys=True, separators=(",", ":"), allow_nan=False).encode())


def _compose(baseline, patches, reference):
    # input_digest rejects unsupported files and escaping symlinks before copying.
    before = input_digest(baseline)
    shutil.copytree(baseline, reference, symlinks=True)
    _require(input_digest(reference) == before, "reference copy changed original source inventory")
    env = {"PATH": os.defpath, "HOME": "/nonexistent", "GIT_CONFIG_NOSYSTEM": "1",
           "GIT_CONFIG_GLOBAL": "/dev/null", "GIT_CEILING_DIRECTORIES": str(reference)}
    for patch in patches.values():
        completed = subprocess.run(
            ["git", "-c", "core.autocrlf=false", "apply", "--binary", "--whitespace=nowarn", "-"],
            input=patch, cwd=reference, env=env, capture_output=True, timeout=120, umask=0o022)
        _require(completed.returncode == 0, "original reference patch did not apply: "
                 + completed.stderr.decode("utf-8", "replace")[-2000:])
    _require(input_digest(baseline) == before, "actor baseline changed while composing reference")
    return input_digest(reference)


def prepare_reference(baseline: Path, record: dict, trusted_test_inputs: dict, output: Path) -> dict:
    """Compose the entire official patch pair in a fresh private-only directory."""
    baseline = _physical(baseline)
    patches = _patches(record)
    before = input_digest(baseline)
    output = Path(output).absolute()
    _physical(output.parent)
    _require(not output.exists() and not output.is_symlink()
             and not output.is_relative_to(baseline) and not baseline.is_relative_to(output),
             "reference output exists or overlaps actor baseline")
    output.mkdir(mode=0o700)
    reference = output / "source"
    digest = _compose(baseline, patches, reference)
    verify_test_inputs(trusted_test_inputs, reference)
    descriptor = {"schema": SCHEMA, "role": ROLE, "record_sha256": _record_sha(record),
                  "baseline": str(baseline), "baseline_sha256": before,
                  "reference": str(reference), "reference_sha256": digest,
                  "trusted_test_inputs": json.loads(json.dumps(trusted_test_inputs))}
    for key, patch in patches.items():
        path = output / (key + ".diff")
        with path.open("xb") as stream:
            stream.write(patch)
        descriptor[key] = str(path)
        descriptor[key + "_sha256"] = _sha(patch)
    _require(input_digest(baseline) == before, "actor baseline changed during preparation")
    return descriptor


def verify_reference(descriptor: dict, baseline: Path, record: dict, trusted_test_inputs: dict) -> dict:
    """Independently replay both originals; self-consistent descriptor hashes are insufficient."""
    _require(isinstance(descriptor, dict) and set(descriptor) == {
        "schema", "role", "record_sha256", "baseline", "baseline_sha256", "reference",
        "reference_sha256", "trusted_test_inputs", "patch", "patch_sha256",
        "test_patch", "test_patch_sha256"}, "reference descriptor is incomplete")
    _require(descriptor["schema"] == SCHEMA and descriptor["role"] == ROLE,
             "reference input role differs")
    baseline = _physical(baseline)
    reference = _physical(descriptor["reference"])
    _require(not reference.is_relative_to(baseline) and not baseline.is_relative_to(reference),
             "reference overlaps actor baseline")
    before = input_digest(baseline)
    _require(descriptor["baseline"] == str(baseline) and descriptor["baseline_sha256"] == before,
             "reference actor baseline binding changed")
    patches = _patches(record)
    _require(descriptor["record_sha256"] == _record_sha(record)
             and descriptor["trusted_test_inputs"] == trusted_test_inputs,
             "reference original record or trusted input binding changed")
    for key, patch in patches.items():
        path = _physical(descriptor[key], directory=False)
        _require(path == reference.parent / (key + ".diff")
                 and path.read_bytes() == patch and descriptor[key + "_sha256"] == _sha(patch),
                 "reference original patch bytes changed")
    actual = input_digest(reference)
    _require(descriptor["reference_sha256"] == actual, "reference source digest changed")
    proof = verify_test_inputs(trusted_test_inputs, reference)
    with tempfile.TemporaryDirectory(prefix="reference-replay-") as temporary:
        expected = _compose(baseline, patches, Path(temporary) / "source")
    _require(actual == expected and input_digest(reference) == actual
             and input_digest(baseline) == before, "reference does not equal complete original patch pair")
    return {"complete": True, "schema": SCHEMA, "role": ROLE,
            "baseline_sha256": before, "reference_sha256": actual,
            "protected_entries_verified": proof["entries_verified"]}
