"""Outcome-blind selection and accounting only; no actor or paid launch entry point."""
import copy
import hashlib
import json
import re
from decimal import Decimal, localcontext
from pathlib import Path


class CampaignViolation(ValueError):
    """A campaign input or accounting boundary is not qualified."""


_PUBLIC_FIELDS = {"id", "repo", "base_commit", "image", "created_at", "language",
                  "public_issue_sha256", "eligible", "reason"}


def _require(condition, message):
    if not condition:
        raise CampaignViolation(message)


def _hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _digest(value):
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None


def _metadata(rows):
    _require(isinstance(rows, list) and bool(rows), "metadata universe missing")
    seen = set()
    for row in rows:
        _require(isinstance(row, dict) and not (set(row) - _PUBLIC_FIELDS),
                 "metadata contains nonpublic or unregistered fields")
        for key in ("id", "repo", "image", "language", "reason"):
            _require(isinstance(row.get(key), str) and bool(row[key].strip()), "metadata text missing")
        _require(re.fullmatch(r"[^/\s]+/[^/\s]+", row["repo"]) is not None, "repository invalid")
        _require(isinstance(row.get("base_commit"), str)
                 and re.fullmatch(r"[0-9a-f]{40}", row["base_commit"]) is not None,
                 "base commit invalid")
        _require(_digest(row.get("public_issue_sha256")), "public issue digest invalid")
        _require("eligible" in row and (row["eligible"] is None or type(row["eligible"]) is bool),
                 "eligibility must be qualified, rejected or pending")
        _require(row["id"] not in seen, "duplicate task identity")
        seen.add(row["id"])


def selection_report(metadata, exposure, seed):
    """Retain every ranked decision; pending earlier qualification blocks later picks."""
    _metadata(metadata)
    _require(isinstance(exposure, set) and all(isinstance(x, str) for x in exposure),
             "exposure must be an explicit ID set")
    _require(isinstance(seed, str) and bool(seed.strip()), "selection seed missing")
    rows = sorted(metadata, key=lambda r: (
        hashlib.sha256((seed + "\0" + r["id"]).encode()).hexdigest(), r["id"]))
    selected, decisions, repositories = [], [], set()
    pending = False
    for row in rows:
        key = hashlib.sha256((seed + "\0" + row["id"]).encode()).hexdigest()
        if row["id"] in exposure:
            reason = "research_exposure"
        elif row["eligible"] is False:
            reason = row["reason"]
        elif len(selected) == 2:
            reason = "selection_quota_reached"
        elif row["eligible"] is None:
            pending = True
            reason = "qualification_pending"
        elif pending:
            reason = "earlier_qualification_pending"
        elif row["repo"].casefold() in repositories:
            reason = "repository_already_selected"
        else:
            selected.append(copy.deepcopy(row))
            repositories.add(row["repo"].casefold())
            reason = "selected"
        decisions.append({"id": row["id"], "repo": row["repo"], "rank_sha256": key,
                          "reason": reason})
    return {"seed": seed, "metadata_sha256": _hash(sorted(metadata, key=lambda r: r["id"])),
            "exposure_sha256": _hash(sorted(exposure)), "selected": selected,
            "decisions": decisions, "complete": len(selected) == 2 and not pending}


def select_tasks(metadata, exposure, seed):
    report = selection_report(metadata, exposure, seed)
    _require(report["complete"], "two ordered repository-distinct qualified tasks unavailable")
    return report["selected"]


def attempt_schedule(selected):
    """Mirror arm positions; stage1-headroom-v2 changes transport reserves only."""
    _metadata(selected)
    _require(len(selected) == 2 and selected[0]["id"] != selected[1]["id"]
             and selected[0]["repo"].casefold() != selected[1]["repo"].casefold()
             and all(r["eligible"] is True for r in selected), "selected cohort invalid")
    result = []
    for row, arms in zip(selected, (("L", "R", "P", "X"), ("X", "P", "R", "L"))):
        for arm in arms:
            entry = {"id": row["id"] + "::" + arm, "task_id": row["id"], "arm": arm,
                     "reserved_usd": "9" if arm == "X" else "10" if arm in ("P", "R") else "6",
                     "cli_cap_usd": "5.50" if arm == "X" else "2.75"}
            if arm in ("P", "R"):
                entry["phase_reservations_usd"] = ["3", "4", "3"]
                entry["phase_cli_caps_usd"] = ["0.55", "1.65", "0.55"]
            result.append(entry)
    return result


def _money(value):
    _require(isinstance(value, str) and len(value) <= 100
             and re.fullmatch(r"(?:0|[1-9][0-9]*)(?:\.[0-9]+)?", value) is not None,
             "cost must be a finite nonnegative decimal string")
    return Decimal(value)


def _identity(row):
    _require(isinstance(row, dict) and isinstance(row.get("id"), str) and bool(row["id"]),
             "accounting identity missing")
    return row["id"]


def accounting_totals(ledger):
    """Known commitments and unknown charges are separate, never zero-filled costs."""
    _require(isinstance(ledger, dict), "ledger missing")
    ceiling = _money(ledger.get("ceiling_usd"))
    _require(ceiling > 0, "series ceiling invalid")
    for key in ("charges", "holds", "reservations"):
        _require(isinstance(ledger.get(key), list), "ledger collection missing")
    charges, unknown, holds, reservations = {}, [], [], []
    with localcontext() as context:
        context.prec = 128
        total = Decimal(0)
        for row in ledger["charges"]:
            identity = _identity(row)
            _require(identity not in charges and _digest(row.get("receipt_sha256")),
                     "duplicate charge or absent receipt binding")
            value = row.get("cost_usd")
            _require("cost_usd" in row, "charge value missing")
            charges[identity] = value
            if value is None:
                unknown.append(identity)
            else:
                total += _money(value)
        for row in ledger["holds"]:
            identity = _identity(row)
            _require(identity not in holds, "duplicate hold")
            holds.append(identity)
            amount = _money(row.get("reserved_usd"))
            _require(type(row.get("settled")) is bool, "hold settlement unknown")
            if row["settled"]:
                _require(identity in charges and charges[identity] is not None,
                         "hold lacks a settled terminal charge")
            else:
                total += amount
        for row in ledger["reservations"]:
            identity = _identity(row)
            _require(identity not in reservations and identity not in charges and identity not in holds,
                     "duplicate reservation identity")
            reservations.append(identity)
            total += _money(row.get("reserved_usd"))
        _require(total <= ceiling, "standing series ceiling exceeded")
        return {"committed_usd": str(total), "unknown_charge_ids": unknown,
                "unsettled_hold_ids": [r["id"] for r in ledger["holds"] if not r["settled"]],
                "ceiling_usd": str(ceiling)}


def admit_history(ledger, *, carried_holds=None, bindings=None):
    """Carry only explicitly frozen pre-provider unknown holds, at their full reservation."""
    totals = accounting_totals(ledger)
    _require(not totals["unknown_charge_ids"], "unknown prior charge blocks admission")
    proofs = [] if carried_holds is None else carried_holds
    _require(isinstance(proofs, list), "historical hold proofs must be a list")
    bindings = {} if bindings is None else bindings
    _require(isinstance(bindings, dict), "historical receipt bindings missing")
    by_id = {}
    for proof in proofs:
        _require(isinstance(proof, dict) and
                 set(proof) == {"id", "source", "receipt_sha256", "reserved_usd"},
                 "historical hold proof schema invalid")
        identity = _identity(proof)
        _require(identity not in by_id, "duplicate historical hold proof")
        by_id[identity] = proof
    _require(set(by_id) == set(totals["unsettled_hold_ids"]),
             "unknown prior hold is not exactly covered by frozen carry proofs")
    for hold in ledger["holds"]:
        if hold["settled"]:
            continue
        proof = by_id[hold["id"]]
        _require(all(hold.get(key) == proof[key] for key in proof) and
                 hold.get("cost_usd") is None and
                 _money(proof["reserved_usd"]) > 0 and
                 _digest(proof["receipt_sha256"]),
                 "historical hold amount, source or receipt drift")
        _require(isinstance(proof["source"], str) and
                 bindings.get(proof["source"]) == proof["receipt_sha256"],
                 "historical receipt is not bound by campaign registration")
        path = Path(proof["source"])
        try:
            _require(path.is_absolute() and path.resolve(strict=True) == path and path.is_file(),
                     "historical receipt must be a physical regular file")
            raw = path.read_bytes()
            _require(hashlib.sha256(raw).hexdigest() == proof["receipt_sha256"],
                     "historical receipt bytes changed")
            receipt = json.loads(raw)
            _require(isinstance(receipt, dict) and
                     isinstance(receipt.get("session_id"), str) and
                     hold["id"] == "native-client:" + receipt["session_id"] and
                     receipt.get("scripted") is False and
                     receipt.get("cost_usd") is None and
                     receipt.get("unknown_provider_cost") is True and
                     type(receipt.get("requests")) is int and receipt["requests"] == 0 and
                     type(receipt.get("forwarded")) is int and receipt["forwarded"] == 0 and
                     _money(receipt.get("campaign_available_usd")) == _money(proof["reserved_usd"]),
                     "historical receipt does not prove the registered startup hold")
        except (OSError, ValueError, TypeError, KeyError) as exc:
            raise CampaignViolation("invalid historical hold evidence: " + str(exc)) from exc
    return frozenset(by_id)

def reserve_attempt(ledger, attempt, *, carried_holds=None, bindings=None):
    """Return a new ledger; no hold is forgiven or unknown charge zero-filled."""
    admit_history(ledger, carried_holds=carried_holds, bindings=bindings)
    identity = _identity(attempt)
    _require(attempt.get("arm") in ("L", "R", "P", "X")
             and isinstance(attempt.get("task_id"), str) and bool(attempt["task_id"]),
             "attempt identity invalid")
    _require(_money(attempt.get("reserved_usd")) > 0, "reservation must be positive")
    known = {r["id"] for key in ("charges", "holds", "reservations") for r in ledger[key]}
    _require(identity not in known, "duplicate attempt")
    result = copy.deepcopy(ledger)
    result["reservations"].append(copy.deepcopy(attempt))
    accounting_totals(result)
    return result


def reconcile_charges(receipts):
    """One final cumulative cost per invocation; earlier continuations are not extra charges."""
    _require(isinstance(receipts, list), "cost receipts missing")
    grouped = {}
    for row in receipts:
        _require(isinstance(row, dict) and isinstance(row.get("invocation_id"), str)
                 and bool(row["invocation_id"]), "invocation identity missing")
        _require(type(row.get("sequence")) is int and row["sequence"] >= 0
                 and type(row.get("terminal")) is bool and _digest(row.get("receipt_sha256")),
                 "cost receipt metadata invalid")
        _require("cumulative_usd" in row, "cost field missing")
        if row["cumulative_usd"] is not None:
            _money(row["cumulative_usd"])
        group = grouped.setdefault(row["invocation_id"], {})
        previous = group.get(row["sequence"])
        _require(previous is None or previous == row, "conflicting cumulative receipt")
        group[row["sequence"]] = row
    charges = []
    for identity, group in sorted(grouped.items()):
        ordered = [group[k] for k in sorted(group)]
        known = None
        for index, row in enumerate(ordered):
            _require(not row["terminal"] or index == len(ordered) - 1,
                     "invocation continued after terminal receipt")
            if row["cumulative_usd"] is not None:
                amount = _money(row["cumulative_usd"])
                _require(known is None or amount >= known, "cumulative cost decreased")
                known = amount
        last = ordered[-1]
        charges.append({"id": identity,
                        "cost_usd": last["cumulative_usd"] if last["terminal"] else None,
                        "receipt_sha256": last["receipt_sha256"]})
    return charges
