"""Versioned preparation for the measured literal Cargo-test/report runner grammar.

This changes scheduling and makes test compilation observable before test payloads.
Expected names, assertions, selectors, reports and source patches are untouched.
"""
import copy
import re
import shlex

def prepare_record(original):
    if (not isinstance(original, dict) or not isinstance(original.get("test_cmds"), list)
            or not original["test_cmds"]):
        raise ValueError("literal Cargo test command inventory required")
    rebuild = original.get("rebuild_cmds")
    if rebuild is not None and (not isinstance(rebuild, list) or any(not isinstance(x, str) for x in rebuild)):
        raise ValueError("invalid original rebuild inventory")
    result = copy.deepcopy(original)
    result["rebuild_cmds"] = list(rebuild or [])
    prepared_tests = []
    for command in original["test_cmds"]:
        if not isinstance(command, str):
            raise ValueError("invalid test command")
        report = re.fullmatch(r"(?P<prefix>.+?)\s+2>&1\s*\|\s*tee\s+[A-Za-z0-9_./-]+\s*", command)
        if report is None:
            raise ValueError("unregistered test/report shell grammar")
        prefix = report["prefix"]
        if any(char in prefix for char in "|;&<>$\x60*?~\n\r"):
            raise ValueError("shell expansion or operators require a separate runner registration")
        try:
            words = shlex.split(prefix)
        except ValueError as exc:
            raise ValueError("invalid literal Cargo arguments") from exc
        if words[:2] != ["cargo", "test"]:
            raise ValueError("unregistered test runner")
        compile_words = words[:words.index("--")] if "--" in words else words
        if any(word in ("--no-run", "--doc") or word.startswith("--message-format") for word in compile_words[2:]):
            raise ValueError("test-only or structured diagnostic mode needs its own contract")
        result["rebuild_cmds"].append(shlex.join([*compile_words, "--no-run"]))
        if "--no-fail-fast" in compile_words[2:]:
            prepared_tests.append(command)
        else:
            marker = re.match(r"^\s*cargo\s+test(?=\s|$)", command)
            if marker is None:
                raise ValueError("literal Cargo prefix differs")
            prepared_tests.append(command[:marker.end()] + " --no-fail-fast" + command[marker.end():])
    result["test_cmds"] = prepared_tests
    return result
