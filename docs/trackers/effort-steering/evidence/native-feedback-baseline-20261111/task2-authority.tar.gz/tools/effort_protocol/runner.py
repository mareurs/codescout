"""Immutable campaign orchestration; hidden grading starts after all actors close."""
import copy
import hashlib
import json
import re
import shutil
from decimal import Decimal, localcontext
from pathlib import Path

from campaign import (CampaignViolation, _money, accounting_totals, attempt_schedule,
                      admit_history, reserve_attempt, select_tasks)
from receipts import input_digest, publish_exclusive

_PUBLIC_KEYS = {"issue", "project_rules", "global_rules", "onboarding", "prior_public_artifacts"}
_NEXT = {"investigate":"repair", "repair":"challenge", "challenge":"closed"}
_TERMINAL = {"closed", "incomplete", "budget_exhausted"}


def _require(condition, reason):
    if not condition:
        raise CampaignViolation(reason)


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _digest(value):
    return isinstance(value,str) and re.fullmatch(r"[0-9a-f]{64}",value) is not None


def _unlinked(path):
    path = Path(path).absolute()
    _require(not any(p.is_symlink() for p in (path,*path.parents)), "symlink in owned path")
    return path


def _verify_inputs(registration):
    bindings = registration["bindings"]
    _require(isinstance(bindings,dict) and bool(bindings), "runtime bindings missing")
    for name, expected in bindings.items():
        path = _unlinked(name)
        _require(Path(name).is_absolute() and path.is_file() and _digest(expected)
                 and _sha(path)==expected, "registered runtime input drift")
    for task in registration["tasks"].values():
        source = _unlinked(task["source"])
        _require(source.is_dir() and input_digest(source)==task["source_sha256"],
                 "frozen baseline changed")


def _reserve(registration):
    ledger = copy.deepcopy(registration["ledger"])
    _require(_money(ledger["ceiling_usd"])==Decimal("200"), "unregistered series ceiling")
    history = {"carried_holds": registration.get("carried_holds"),
               "bindings": registration.get("bindings")}
    admit_history(ledger, **history)
    campaign_id = registration["campaign_id"]
    for index, attempt in enumerate(registration["schedule"]):
        ledger = reserve_attempt(ledger,dict(attempt,id=campaign_id+"::"+str(index)), **history)
    for role in ("setup","contingency"):
        ledger["reservations"].append({"id":campaign_id+"::"+role,"reserved_usd":"4"})
    accounting_totals(ledger)
    return ledger


def _validate(registration, backend):
    _require(isinstance(registration,dict) and registration.get("schema")=="evidence-campaign-v1",
             "unregistered campaign schema")
    _require(registration.get("mode") in ("scripted","paid")
             and getattr(backend,"mode",None)==registration["mode"], "backend mode mismatch")
    if registration["mode"]=="paid":
        try:
            from native_campaign import NativeCampaignBackend
        except ImportError as exc:
            raise CampaignViolation("concrete paid native backend is unavailable") from exc
        _require(type(backend) is NativeCampaignBackend, "paid campaign requires concrete native backend")
    _require(isinstance(registration.get("campaign_id"),str)
             and re.fullmatch(r"[a-z0-9][a-z0-9-]{0,100}",registration["campaign_id"]),
             "invalid campaign identity")
    root = _unlinked(registration["output_root"])
    _require(Path(registration["output_root"]).is_absolute() and not root.exists(),
             "campaign output already exists or is not absolute")
    selected = select_tasks(registration["metadata"],set(registration["exposure"]),registration["seed"])
    _require(registration["selected"]==selected
             and registration["schedule"]==attempt_schedule(selected), "selection or schedule drift")
    _require(isinstance(registration["tasks"],dict)
             and set(registration["tasks"])=={row["id"] for row in selected}, "task population drift")
    for row in selected:
        task = registration["tasks"][row["id"]]
        _require(isinstance(task,dict) and set(task)=={"source","source_sha256","public_packet","backend"},
                 "task record schema invalid")
        source = _unlinked(task["source"])
        _require(not root.is_relative_to(source) and not source.is_relative_to(root),
                 "campaign output overlaps frozen source")
        packet = task["public_packet"]
        _require(isinstance(packet,dict) and set(packet)<=_PUBLIC_KEYS
                 and isinstance(packet.get("issue"),str)
                 and hashlib.sha256(packet["issue"].encode()).hexdigest()==row["public_issue_sha256"],
                 "private/unregistered public packet or issue drift")
        _require(isinstance(task["backend"],dict), "backend task descriptor missing")
    _verify_inputs(registration)
    for name in registration["bindings"]:
        path = Path(name).absolute()
        _require(not path.is_relative_to(root) and not root.is_relative_to(path),
                 "output overlaps immutable runtime input")
    shared = registration["shared_preparation"]
    _require(isinstance(shared,dict) and _digest(shared.get("receipt_sha256"))
             and isinstance(shared.get("cost_usd"),str)
             and _money(shared["cost_usd"])<=Decimal("4"), "shared preparation cost is unknown or over budget")
    return root, _reserve(registration)


def preflight(registration, backend):
    """Check pure invariants before any live backend verification or actor effect."""
    try:
        root, ledger = _validate(registration,backend)
        proof = backend.verify(copy.deepcopy(registration))
        _require(isinstance(proof,dict) and proof.get("ready") is True
                 and proof.get("mode")==registration["mode"], "concrete backend verification failed")
        _verify_inputs(registration)
        return {"ready":True,"paid_ready":registration["mode"]=="paid",
                "output_root":str(root),"reserved_ledger":ledger,"backend":proof}
    except (CampaignViolation,KeyError,TypeError,ValueError,OSError) as exc:
        return {"ready":False,"paid_ready":False,"reason":str(exc)}


def _reservation(ledger, identity):
    return next(row for row in ledger["reservations"] if row["id"]==identity)


def _cost(record):
    value = record.get("cost_usd")
    if value is not None:
        _require(isinstance(value,str), "cost must retain decimal text")
        _money(value)
    final = record.get("cost_is_final") is True and value is not None
    return {"known_usd":value,"unknown":not final}


def _settle(ledger, reservation_id, invocation_id, record, receipt_sha):
    cost = _cost(record)
    _require(not any(row["id"]==invocation_id for row in ledger["charges"]),
             "invocation charge already settled")
    ledger["charges"].append({"id":invocation_id,
        "cost_usd":None if cost["unknown"] else cost["known_usd"],"receipt_sha256":receipt_sha})
    if not cost["unknown"]:
        held = _reservation(ledger,reservation_id)
        held["reserved_usd"] = str(max(Decimal(0),_money(held["reserved_usd"])-_money(cost["known_usd"])))
    return cost


def _candidate(record, phase_root):
    candidate = _unlinked(record["candidate"])
    _require(candidate.is_relative_to(phase_root) and candidate!=phase_root
             and candidate.is_dir() and record.get("capture_complete") is True,
             "candidate capture missing or outside owned invocation")
    digest = input_digest(candidate)
    _require(record.get("source_digest")==digest, "candidate source binding mismatch")
    return candidate,digest


def _invocation(backend,request,out,ledger,reservation_id):
    """Always preserve financial evidence before classifying the host/protocol result."""
    out.mkdir()
    publish_exclusive(out/"intent.json",request)
    before = input_digest(Path(request["source"]))
    returned, boundary_error = None,None
    try:
        returned = backend.invoke(copy.deepcopy(request),out)
    except BaseException as exc:
        boundary_error = type(exc).__name__+": "+str(exc)
    path = out/"invocation.json"
    record = None
    faults = [boundary_error] if boundary_error else []
    try:
        _require(path.is_file() and not path.is_symlink(), "host invocation receipt missing")
        record = json.loads(path.read_text())
        _require(isinstance(record,dict), "host invocation receipt malformed")
    except (CampaignViolation,OSError,ValueError) as exc:
        faults.append(str(exc))
        record = {"cost_usd":None,"cost_is_final":False}
    receipt_sha = _sha(path) if path.is_file() and not path.is_symlink() else hashlib.sha256(
        json.dumps(record,sort_keys=True).encode()).hexdigest()
    try:
        cost = _settle(ledger,reservation_id,request["invocation_id"],record,receipt_sha)
    except (CampaignViolation,KeyError,TypeError,ValueError) as exc:
        faults.append(str(exc))
        record = dict(record,cost_usd=None,cost_is_final=False)
        cost = _settle(ledger,reservation_id,request["invocation_id"],record,receipt_sha)
    candidate,source_digest = None,None
    try:
        candidate,source_digest = _candidate(record,out)
    except (CampaignViolation,KeyError,TypeError,OSError) as exc:
        faults.append(str(exc))
    try:
        _require(boundary_error is None and returned==record, "backend return/receipt boundary failed")
        _require(record.get("invocation_id")==request["invocation_id"], "invocation identity mismatch")
        _require(not cost["unknown"], "invocation cost is unsettled")
        _require(_money(cost["known_usd"])<=_money(request["allowance_usd"]), "invocation budget exceeded")
        _require(all(record.get(key) is True for key in
                     ("context_valid","capture_complete","cleanup_complete")), "invalid context/capture/cleanup")
        _require(record.get("measurement_invalid") is False, "backend reported infrastructure invalid")
        turns = record["turns"]
        state = record["state"]
        _require(type(turns) is int and 1<=turns<=3 and isinstance(state,dict),
                 "phase turn/state invalid")
        previous = request["state"]
        _require(state.get("run_id")==previous["run_id"]
                 and type(state.get("turns_used")) is int
                 and state["turns_used"]==previous["turns_used"]+turns
                 and state["turns_used"]<=9, "cumulative turn or run mismatch")
        expected = _NEXT[request["phase"]] if request["arm"] in ("P","R") else "closed"
        _require(state.get("phase") in (expected,"incomplete","budget_exhausted"), "illegal phase transition")
        if state["phase"] not in _TERMINAL:
            _require(state.get("source_digest")==source_digest, "next phase source is stale")
        _require(input_digest(Path(request["source"]))==before, "frozen phase input mutated")
        artifact = record.get("public_artifact")
        if request["arm"] in ("P","R") and state["phase"] not in ("incomplete","budget_exhausted"):
            _require(isinstance(artifact,dict) and set(artifact)<=
                {"run_id","phase","arm","source_digest","submission","observations"}
                and artifact.get("run_id")==state["run_id"]
                and artifact.get("phase")==request["phase"] and artifact.get("arm")==request["arm"]
                and artifact.get("source_digest")==source_digest, "public handoff is absent or unbound")
    except (CampaignViolation,KeyError,TypeError,OSError,ValueError) as exc:
        faults.append(str(exc))
    decision = {"invocation_id":request["invocation_id"],"cost":cost,
                "measurement_invalid":bool(faults),"faults":faults,
                "candidate":str(candidate) if candidate else None,"source_digest":source_digest,
                "record":record,"receipt_sha256":receipt_sha}
    publish_exclusive(out/"decision.json",decision)
    return decision


def _verify_closed(registration,root,closed):
    _verify_inputs(registration)
    _require(_sha(root/"ledger-final.json")==closed["ledger_sha256"],"closed costs changed")
    for item in closed["attempts"]:
        _require(_sha(item["attempt_receipt"])==item["receipt_sha256"]
                 and input_digest(Path(item["candidate"]))==item["source_digest"],
                 "batch closure source or attempt receipt changed")

def _run_campaign(registration,backend):
    registered = copy.deepcopy(registration)
    checked = preflight(registered,backend)
    _require(checked["ready"],checked.get("reason","campaign is not admitted"))
    root = Path(checked["output_root"])
    root.mkdir(parents=True,exist_ok=False)
    publish_exclusive(root/"registration.json",registered)
    ledger = checked["reserved_ledger"]
    publish_exclusive(root/"ledger-reserved.json",
        dict(ledger,committed_usd=accounting_totals(ledger)["committed_usd"]))
    campaign_id = registered["campaign_id"]
    ledger["charges"].append({"id":campaign_id+"::shared-charge",
        **registered["shared_preparation"]})
    ledger["reservations"]=[row for row in ledger["reservations"] if row["id"]!=campaign_id+"::setup"]
    attempts = []
    stopped = None
    frozen = []
    for index,attempt in enumerate(registered["schedule"]):
        if stopped:
            break
        directory = root/"attempts"/(str(index).zfill(2)+"-"+attempt["arm"])
        directory.mkdir(parents=True)
        task = registered["tasks"][attempt["task_id"]]
        source = Path(task["source"])
        state = {"run_id":campaign_id+"-"+str(index),"phase":"investigate","turns_used":0,
                 "baseline_digest":task["source_sha256"],"source_digest":task["source_sha256"],
                 "baseline_paths":sorted(p.relative_to(source).as_posix() for p in source.rglob("*")),
                 "used_receipts":[]}
        phases = ("investigate","repair","challenge") if attempt["arm"] in ("P","R") else ("repair",)
        artifacts,costs,decisions = [],[],[]
        reservation_id = campaign_id+"::"+str(index)
        for phase_index,phase in enumerate(phases):
            try:
                _verify_inputs(registered)
                _require(all(input_digest(path)==digest for path,digest in frozen), "earlier captured source changed")
            except (CampaignViolation,ValueError,OSError) as exc:
                stopped = str(exc)
                break
            budget = attempt["phase_reservations_usd"][phase_index] if len(phases)==3 else attempt["reserved_usd"]
            cap = attempt["phase_cli_caps_usd"][phase_index] if len(phases)==3 else attempt["cli_cap_usd"]
            packet = copy.deepcopy(task["public_packet"])
            packet["prior_public_artifacts"] = copy.deepcopy(artifacts)
            request = {"invocation_id":campaign_id+"::"+str(index)+"::"+phase,
                "task_id":attempt["task_id"],"arm":attempt["arm"],"attempt_index":index,
                "phase":phase,"state":copy.deepcopy(state),"source":str(source),
                "public_packet":packet,"allowance_usd":budget,"cli_cap_usd":cap,
                "max_continuations":2,"effort":"xhigh" if attempt["arm"]=="X" else "low"}
            decision = _invocation(backend,request,directory/phase,ledger,reservation_id)
            decisions.append(decision)
            costs.append(decision["cost"])
            if decision["candidate"]:
                source = Path(decision["candidate"])
                frozen.append((source,decision["source_digest"]))
            try:
                _verify_inputs(registered)
                _require(all(input_digest(path)==digest for path,digest in frozen), "frozen capture drift")
                accounting_totals(ledger)
            except (CampaignViolation,ValueError,OSError) as exc:
                stopped = str(exc)
            if decision["measurement_invalid"] or stopped:
                stopped = stopped or "; ".join(str(f) for f in decision["faults"])
                break
            state = decision["record"]["state"]
            if decision["record"].get("public_artifact") is not None:
                artifacts.append(decision["record"]["public_artifact"])
            if state["phase"] in _TERMINAL:
                break
        observed_amounts = [_money(cost["known_usd"]) for cost in costs if cost["known_usd"] is not None]
        known = sum(observed_amounts,Decimal(0)) if observed_amounts else None
        unknown = not costs or any(cost["unknown"] for cost in costs)
        if not stopped and not unknown:
            ledger["reservations"]=[r for r in ledger["reservations"] if r["id"]!=reservation_id]
        captured = source!=Path(task["source"])
        row = {"task_id":attempt["task_id"],"arm":attempt["arm"],"attempt_index":index,
            "workflow_state":"measurement_invalid" if stopped else state["phase"],
            "measurement_invalid":bool(stopped),"reason":stopped,
            "cost":{"known_usd":str(known) if known is not None else None,"unknown":unknown},
            "candidate":str(source) if captured else None,
            "source_digest":input_digest(source) if captured else None,"invocations":decisions,
            "attempt_receipt":str(directory/"attempt.json"),"grade":None}
        publish_exclusive(directory/"attempt.json",row)
        attempts.append(row)
    if not stopped and len(attempts)==8:
        ledger["reservations"]=[r for r in ledger["reservations"] if r["id"]!=campaign_id+"::contingency"]
    publish_exclusive(root/"ledger-final.json",ledger)
    result = {"status":"stopped" if stopped else "completed","reason":stopped,
              "paid_ready":checked["paid_ready"],"setup_cost_usd":registered["shared_preparation"]["cost_usd"],
              "attempts":attempts,"unexecuted":copy.deepcopy(registered["schedule"][len(attempts):])}
    if not stopped:
        _verify_inputs(registered)
        _require(all(input_digest(path)==digest for path,digest in frozen), "source drift before batch closure")
        closed = {"attempts":[{"attempt_receipt":row["attempt_receipt"],
                    "receipt_sha256":_sha(row["attempt_receipt"]),"source_digest":row["source_digest"],
                    "candidate":row["candidate"]} for row in attempts],
                  "ledger_sha256":_sha(root/"ledger-final.json")}
        publish_exclusive(root/"actor-batch-closed.json",closed)
        for row in attempts:
            try:
                _verify_closed(registered,root,closed)
                grade_root = root/"grades"/str(row["attempt_index"]).zfill(2)
                grade_root.mkdir(parents=True)
                grade_request = {key:row[key] for key in ("task_id","arm","source_digest")}
                grade_request["source"] = row["candidate"]
                grade = backend.grade(grade_request,grade_root)
                _require(isinstance(grade,dict) and grade.get("valid") is True
                         and type(grade.get("pass")) is bool,"independent grade invalid")
                _verify_closed(registered,root,closed)
                row["grade"] = grade
            except BaseException as exc:
                result.update(status="grading_stopped",reason=type(exc).__name__+": "+str(exc))
                break
    result["analysis"] = analyze(result)
    publish_exclusive(root/"result.json",result)
    return result


def run_campaign(registration,backend):
    with localcontext() as context:
        context.prec = 128
        return _run_campaign(registration,backend)


def analyze(result):
    """Apply the preregistered two-task screen; never infer equivalence from a tie."""
    with localcontext() as analysis_context:
        analysis_context.prec = 128
        report = {"advance":False,"decision":"NO-GO","paired":{}}
        try:
            _require(result.get("status")=="completed" and len(result["attempts"])==8,"campaign incomplete")
            rows = result["attempts"]
            ids = {row["task_id"] for row in rows}
            _require(len(ids)==2,"wrong task unit")
            table = {}
            totals = {arm:Decimal(0) for arm in ("L","R","P","X")}
            for row in rows:
                key = (row["task_id"],row["arm"])
                _require(key not in table and row["arm"] in totals,"duplicate or unsupported arm")
                _require(row["measurement_invalid"] is False and row["cost"]["unknown"] is False
                         and row["grade"]["valid"] is True and type(row["grade"]["pass"]) is bool,
                         "uninterpretable attempt")
                totals[row["arm"]] += _money(row["cost"]["known_usd"])
                table[key] = row
            _require(set(table)=={(task,arm) for task in ids for arm in totals},"missing paired arm")
            _require(all(table[(task,"P")]["workflow_state"]=="closed" for task in ids),"protocol incomplete")
            for arm in ("L","R","X"):
                comparisons = [(table[(task,"P")]["grade"]["pass"],table[(task,arm)]["grade"]["pass"])
                               for task in ids]
                report["paired"]["P-"+arm] = {"wins":sum(p and not other for p,other in comparisons),
                    "losses":sum(other and not p for p,other in comparisons),"ties":sum(p==other for p,other in comparisons)}
            setup = _money(result["setup_cost_usd"])
            with localcontext() as context:
                context.prec=128
                report["model_usd"]={arm:str(value) for arm,value in totals.items()}
                report["standalone_pair_usd"]={arm:str(value+setup) for arm,value in totals.items()}
                report["amortized_pair_usd"]={arm:str(value+setup/4) for arm,value in totals.items()}
                report["batch_model_usd"]=str(sum(totals.values(),setup))
            gains = all(report["paired"]["P-"+arm]["wins"]>=1
                        and report["paired"]["P-"+arm]["losses"]==0 for arm in ("L","R"))
            count = lambda arm:sum(table[(task,arm)]["grade"]["pass"] for task in ids)
            report["advance"]=bool(gains and count("P")>=count("X") and totals["P"]<totals["X"])
            report["decision"]="ADVANCE_TO_REGISTERED_VALIDATION" if report["advance"] else "NO-GO"
        except (CampaignViolation,KeyError,TypeError,ValueError) as exc:
            report["reason"]=str(exc)
        return report
