"""Prospective repair-only public-feedback contract, distinct from legacy phases."""
from decimal import Decimal, InvalidOperation, localcontext
from pathlib import PurePosixPath
import random
import shlex

SCHEMA = "native-public-feedback-v1"
ARMS = ("L", "R", "P", "X")
COMMON = ("For negative tests, use a separate writable copy and preserve the production "
          "candidate. Report checks actually executed and remaining uncertainty.")
PLAN = ("Before completing, run cargo check --offline --workspace --all-targets in "
        "the source-qualified primary Rust workspace {workspace!r}. Correct any "
        "diagnostics relevant to the repair and rerun this check. Do not enable "
        "all features automatically.")


def condition_spec(arm: str, workspace: str) -> dict:
    """Return fresh descriptors; readiness must independently qualify the workspace."""
    if not isinstance(arm, str) or arm not in ARMS:
        raise ValueError("unknown public-feedback condition")
    if (not isinstance(workspace, str) or not workspace
            or any(c in workspace for c in ("\\", "\x00", "\n", "\r"))
            or PurePosixPath(workspace).is_absolute()
            or ".." in PurePosixPath(workspace).parts
            or str(PurePosixPath(workspace)) != workspace):
        raise ValueError("primary workspace must be a canonical relative path")
    argv = ["cargo", "check", "--offline", "--workspace"]
    if arm in ("P", "X"):
        argv.append("--all-targets")
    return {"schema": SCHEMA, "arm": arm, "effort": "xhigh" if arm == "X" else "low",
            "phase": "repair", "max_continuations": 4,
            "cli_cap_usd": "5.50" if arm == "X" else "2.75",
            "reserve_usd": "9" if arm == "X" else "6",
            "common_instruction": COMMON,
            "plan_instruction": PLAN.format(workspace=workspace) if arm != "L" else "",
            "check": {"argv": argv, "cwd": workspace}}


def validated_request(request: dict):
    """Reject changes to the selected policy before any native side effect."""
    if "feedback_policy" not in request:
        return None
    selected = request["feedback_policy"]
    try:
        expected = condition_spec(request["arm"], selected["check"]["cwd"])
        if (selected != expected or request["phase"] != "repair"
                or type(request["max_continuations"]) is not int
                or request["max_continuations"] != 4 or request["effort"] != expected["effort"]
                or request["cli_cap_usd"] != expected["cli_cap_usd"]
                or request["allowance_usd"] != expected["reserve_usd"]):
            raise ValueError("repair-only invocation differs from its condition")
    except (KeyError, TypeError) as exc:
        raise ValueError("malformed repair-only invocation") from exc
    return expected


def completion_checks(selected: dict) -> list[dict]:
    """Compile check consumed by the existing PublicVerifier shell boundary."""
    try:
        expected = condition_spec(selected["arm"], selected["check"]["cwd"])
    except (KeyError, TypeError) as exc:
        raise ValueError("malformed feedback condition") from exc
    if selected != expected:
        raise ValueError("feedback condition changed")
    command = shlex.join(expected["check"]["argv"])
    cwd = expected["check"]["cwd"]
    if cwd != ".":
        command = "cd " + shlex.quote(cwd) + " && " + command
    return [{"id": "public-feedback-compile", "command": command}]


def balanced_schedule(task_ids: list[str], seed: int) -> list[dict]:
    """Seeded Latin-square order: every arm occupies every position once."""
    if (not isinstance(task_ids, list) or len(task_ids) != 4
            or any(not isinstance(t, str) or not t.strip() for t in task_ids)
            or len(set(task_ids)) != 4 or type(seed) is not int or seed < 0):
        raise ValueError("four distinct task IDs and a nonnegative integer seed required")
    rng = random.Random(seed)
    tasks, arms, rotations = list(task_ids), list(ARMS), list(range(4))
    rng.shuffle(tasks)
    rng.shuffle(arms)
    rng.shuffle(rotations)
    return [{"attempt_index": block * 4 + position, "task_id": task,
             "arm": arms[(rotation + position) % 4]}
            for block, (task, rotation) in enumerate(zip(tasks, rotations))
            for position in range(4)]


def _amount(value):
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (str, int, float)):
        raise ValueError("invalid client charge")
    try:
        result = Decimal(str(value))
    except InvalidOperation as exc:
        raise ValueError("invalid client charge") from exc
    if not result.is_finite() or result < 0:
        raise ValueError("client charge must be finite and nonnegative")
    return result


def development_screen(rows: list[dict]) -> dict:
    """Descriptive paired screen; a selected candidate still needs held-out validation."""
    if not isinstance(rows, list):
        raise ValueError("outcomes must be a list")
    indexed, costs = {}, {}
    required = {"task_id", "arm", "accepted", "workflow_completed", "measurement_invalid", "cost_usd"}
    for row in rows:
        if (not isinstance(row, dict) or not required <= row.keys()
                or not isinstance(row["task_id"], str) or not row["task_id"].strip()
                or row["arm"] not in ARMS
                or any(type(row[k]) is not bool for k in
                       ("accepted", "workflow_completed", "measurement_invalid"))):
            raise ValueError("malformed outcome")
        key = (row["task_id"], row["arm"])
        if key in indexed:
            raise ValueError("duplicate task-condition outcome")
        indexed[key] = dict(row)
        costs[key] = _amount(row["cost_usd"])
    tasks = sorted({task for task, _ in indexed})
    complete = len(tasks) == 4 and set(indexed) == {(t, a) for t in tasks for a in ARMS}
    interpretable = complete and all(not r["measurement_invalid"] for r in indexed.values())
    interpretable = interpretable and all(c is not None for c in costs.values())
    # Preserve exact client decimals even when their scale exceeds the default context.
    known = [c for c in costs.values() if c is not None]
    min_exp = min([0] + [c.as_tuple().exponent for c in known])
    max_adjusted = max([0] + [c.adjusted() for c in known])
    with localcontext() as context:
        context.prec = max(128, max_adjusted - min_exp + len(str(len(known) or 1)) + 2)
        totals = {}
        for arm in ARMS:
            entries = [(key, value) for key, value in indexed.items() if key[1] == arm]
            amounts = [costs[key] for key, _ in entries]
            total = None if any(c is None for c in amounts) else sum(amounts, Decimal(0))
            totals[arm] = {"observed": len(entries), "accepted": sum(r["accepted"] for _, r in entries),
                           "completed": sum(r["workflow_completed"] for _, r in entries),
                           "client_cost_usd": str(total) if total is not None else None}
        pairs = {}
        for left, right in (("R", "L"), ("P", "L"), ("P", "R"), ("R", "X"), ("P", "X")):
            differences = [int(indexed[t, left]["accepted"]) - int(indexed[t, right]["accepted"])
                           for t in tasks if (t, left) in indexed and (t, right) in indexed]
            pairs[left + "-" + right] = {"wins": differences.count(1), "losses": differences.count(-1),
                                         "ties": differences.count(0)}
        eligible = []
        if interpretable:
            for arm in ("R", "P"):
                paired = pairs[arm + "-L"]
                if (totals[arm]["completed"] == 4 and paired["wins"] >= 1 and paired["losses"] == 0
                        and totals[arm]["accepted"] >= totals["X"]["accepted"]
                        and Decimal(totals[arm]["client_cost_usd"]) < Decimal(totals["X"]["client_cost_usd"])):
                    eligible.append(arm)
        selected = min(eligible, key=lambda a: (Decimal(totals[a]["client_cost_usd"]), a != "R")) if eligible else None
    return {"schema": SCHEMA, "interpretable": interpretable, "selected": selected,
            "eligible": eligible, "decision": "ADVANCE-TO-HELD-OUT" if selected else "NO-GO",
            "totals": totals, "pairs": pairs, "goal_achieved": False}
