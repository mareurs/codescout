"""Versioned backend dispatch; only native runtime/evaluator side effects are replaced."""
import copy
from contextlib import ExitStack
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import feedback_admission
import native_campaign as subject
from test_feedback_admission import registration, request


class FeedbackBackendTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.reg = registration(self.root)
        for task in self.reg["tasks"].values():
            task["backend"]["scripted_plans"] = {arm + ":repair": [] for arm in "LRPX"}
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.stack.enter_context(patch.object(subject, "_verify_public", return_value={"ready": True}))
        self.stack.enter_context(patch.object(subject, "_verify_private", return_value={"ready": True}))
        self.calls = []
        self.stack.enter_context(patch.object(subject, "invoke_native", side_effect=self.native))
        self.backend = subject.NativeCampaignBackend(mode="scripted")

    def native(self, packet, out, public, **kwargs):
        self.calls.append((copy.deepcopy(packet), str(out), copy.deepcopy(public), kwargs))
        return {"invocation_id": packet["invocation_id"], "arm": packet["arm"]}

    def test_each_of_sixteen_conditions_has_one_repair_and_no_private_actor_input(self):
        self.backend.verify(self.reg)
        for index, row in enumerate(self.reg["schedule"]):
            packet, out, public = request(self.reg, index)
            result = self.backend.invoke(packet, out)
            self.assertEqual(result["arm"], row["arm"])
            self.assertEqual(self.calls[-1][0], packet)
            self.assertEqual(self.calls[-1][2], public)
            self.assertEqual(self.calls[-1][3], {"mode": "scripted", "scripted_plan": []})
        self.assertEqual(len(self.calls), 16)
        self.assertEqual(len(self.backend.invocations), 16)
        self.assertTrue(all(call[0]["phase"] == "repair" for call in self.calls))

    def test_phase_budget_source_and_context_changes_refuse_before_native(self):
        self.backend.verify(self.reg)
        packet, out, _ = request(self.reg)
        for change in [{"phase": "investigate"}, {"max_continuations": 2}, {"allowance_usd": "100"},
                       {"source": str(self.root)}, {"public_packet": {"issue": "different"}},
                       {"invocation_id": "unregistered"}, {"attempt_index": True}]:
            value = copy.deepcopy(packet)
            value.update(change)
            with self.subTest(change=change), self.assertRaises(ValueError):
                self.backend.invoke(value, out)
        self.assertEqual(self.calls, [])
        self.assertEqual(self.backend.invocations, {})

    def test_duplicate_invocation_and_drifted_backend_registration_refuse(self):
        self.backend.verify(self.reg)
        packet, out, _ = request(self.reg)
        self.backend.invoke(packet, out)
        with self.assertRaises(ValueError):
            self.backend.invoke(packet, out)
        self.backend.registration["schedule"][1]["reserved_usd"] = "100"
        other, directory, _ = request(self.reg, 1)
        with self.assertRaises(ValueError):
            self.backend.invoke(other, directory)
        self.assertEqual(len(self.calls), 1)

    def test_marker_cannot_be_injected_into_the_legacy_registration(self):
        self.reg["schema"] = "evidence-campaign-v1"
        with self.assertRaises(ValueError):
            self.backend.verify(self.reg)

    def test_new_paid_schema_selects_the_separate_authority_type(self):
        self.reg["mode"] = "paid"
        for task in self.reg["tasks"].values():
            task["backend"]["scripted_plans"] = {}
        created = []

        class Authority:
            def __init__(self, reg, token_path):
                created.append((reg, token_path))
        with patch.object(feedback_admission, "FeedbackAdmission", Authority):
            backend = subject.NativeCampaignBackend(mode="paid", token_path="/unit-placeholder")
            backend.verify(self.reg)
            packet, out, _ = request(self.reg)
            backend.invoke(packet, out)
        self.assertEqual(len(created), 1)
        self.assertEqual(created[0], (self.reg, "/unit-placeholder"))
        self.assertIsInstance(self.calls[-1][3]["admission"], Authority)
        self.assertEqual(self.calls[-1][3]["token_path"], "/unit-placeholder")
        self.assertEqual(self.calls[-1][3]["mode"], "paid")


if __name__ == "__main__":
    unittest.main()
