"""Explicit repair-only policy admission; legacy PaidAdmission stays unchanged."""
import copy
from decimal import Decimal, localcontext
import hashlib
import json
import os
from pathlib import Path
import re
import stat

import feedback_policy as policy
import paid_admission as legacy
from paid_admission import (verify_population, verify_public_commands, verify_runtime,
                            verify_verification, verify_review, verify_shared_preparation)
from receipts import input_digest

_PUBLIC_KEYS = {"issue", "project_rules", "global_rules", "onboarding", "prior_public_artifacts"}
_ROLES = {"population", "public_commands", "accounting", "runtime", "verification", "review",
          "shared_preparation"}


def _require(condition, reason):
    if not condition:
        raise ValueError(reason)


def validate_registration(registration: dict) -> dict:
    """Validate the versioned shape, without pretending it supplies concrete proofs."""
    try:
        _require(isinstance(registration, dict) and registration.get("schema") == policy.SCHEMA
                 and registration.get("mode") in ("scripted", "paid"), "repair-only campaign schema or mode differs")
        identity = registration["campaign_id"]
        _require(isinstance(identity, str) and re.fullmatch(r"[a-z0-9][a-z0-9-]{0,100}", identity),
                 "invalid campaign identity")
        root = Path(registration["output_root"])
        _require(root.is_absolute() and root.resolve() == root, "output root is not physical and absolute")
        selected = registration["selected"]
        tasks = registration["tasks"]
        _require(isinstance(selected, list) and len(selected) == 4 and isinstance(tasks, dict),
                 "repair-only population requires four tasks")
        ids, repos = [], []
        for row in selected:
            _require(isinstance(row, dict) and isinstance(row.get("id"), str) and row["id"]
                     and isinstance(row.get("repo"), str) and row["repo"].strip()
                     and row.get("eligible") is True, "selected public task is not qualified")
            ids.append(row["id"])
            repos.append(row["repo"].casefold())
            task = tasks[row["id"]]
            _require(isinstance(task, dict) and set(task) == {"source", "source_sha256", "public_packet", "backend"},
                     "task schema differs")
            source = Path(task["source"])
            _require(source.is_absolute() and source.resolve(strict=True) == source and source.is_dir()
                     and not root.is_relative_to(source) and not source.is_relative_to(root),
                     "source is not isolated physical input")
            _require(isinstance(task["source_sha256"], str)
                     and re.fullmatch("[0-9a-f]{64}", task["source_sha256"]), "source digest missing")
            packet = task["public_packet"]
            _require(isinstance(packet, dict) and set(packet) <= _PUBLIC_KEYS
                     and isinstance(packet.get("issue"), str)
                     and hashlib.sha256(packet["issue"].encode()).hexdigest() == row["public_issue_sha256"]
                     and packet.get("prior_public_artifacts", []) == [],
                     "public issue or packet provenance differs")
            backend = task["backend"]
            _require(isinstance(backend, dict) and set(backend) == {"public", "private", "scripted_plans"}
                     and all(isinstance(backend[key], dict) for key in backend), "backend descriptor differs")
            marker = backend["public"]["feedback_policy"]
            config = policy.condition_spec("L", marker["workspace"])
            _require(marker == {"schema": policy.SCHEMA, "workspace": config["check"]["cwd"]},
                     "public feedback policy differs")
        _require(len(set(ids)) == 4 and len(set(repos)) == 4 and set(tasks) == set(ids),
                 "task IDs and repositories must be distinct and exact")
        schedule = []
        for row in policy.balanced_schedule(ids, registration["order_seed"]):
            config = policy.condition_spec(row["arm"], ".")
            schedule.append(dict(row, cli_cap_usd=config["cli_cap_usd"], reserved_usd=config["reserve_usd"]))
        _require(registration["schedule"] == schedule, "condition schedule, cardinality or budget differs")
    except (KeyError, TypeError, AttributeError, IndexError, OSError) as exc:
        raise ValueError("malformed repair-only registration") from exc
    return {"attempts": 16, "tasks": 4, "native_invocations": 16,
            "max_continuations": 4, "allocation_usd": "112"}


def verify_accounting(registration, descriptor):
    """Consume canonical client receipts and retain their original fifty-row provenance."""
    checked = legacy.verify_accounting(registration, descriptor, allocation_usd="112")
    evidence = legacy._bound_json(registration, descriptor)
    history = legacy._bound_json(registration, evidence["canonical_history"])
    anchor = legacy._bound_json(registration, evidence["history_anchor"])
    _require(history.get("schema") == "client-session-reconciliation-audit-v2"
             and history.get("native_receipts") == 48 and checked["native_receipts"] == 48,
             "canonical historical session coverage differs")
    ledger = registration["ledger"]
    opening = [r for r in ledger["charges"] if r["id"] == "recorded-pre-native-opening-balance"]
    native = [r for r in ledger["charges"] if r["id"].startswith("native-client:")]
    _require(len(opening) == 1 and len(native) == 48 and len(ledger["charges"]) == 49
             and history["canonical_charges"] == native and history["historical_opening"] == opening[0]
             and history["holds_unchanged"] == ledger["holds"]
             and history["known_client_cost_usd"] == checked["known_client_cost_usd"],
             "canonical history was dropped, duplicated or changed")
    _require(anchor.get("schema") == "client-session-reconciliation-anchor-v1"
             and anchor["reconciliation"] == evidence["canonical_history"]["path"]
             and anchor["reconciliation_sha256"] == evidence["canonical_history"]["sha256"],
             "historical audit anchor differs")
    previous = legacy._bound_json(registration, {
        "path": anchor["closed_audit"], "sha256": anchor["closed_audit_sha256"]})
    for path, digest in previous["bindings"].items():
        legacy._bound_path(registration, {"path": path, "sha256": digest})
    old = legacy._bound_json(registration, {
        "path": history["original_ledger"], "sha256": history["original_ledger_sha256"]})
    _require(len(history["original_row_mappings"]) == len(old["charges"]) == 50
             and {r["ledger_id"] for r in history["original_row_mappings"]} == {r["id"] for r in old["charges"]}
             and history["holds_unchanged"] == old["holds"] and len(history["shared_zero_evidence"]) == 1,
             "original historical row or unknown reserve is missing")
    with localcontext() as context:
        context.prec = 128
        _require(Decimal(legacy.accounting_totals(old)["committed_usd"]) ==
                 Decimal(checked["known_client_cost_usd"]) + Decimal(checked["unresolved_reserve_usd"]),
                 "historical commitment changed")
    return checked


def verify_paid(registration):
    """Only concrete seven-role evidence can authorize the new repair-only version."""
    validate_registration(registration)
    _require(registration["mode"] == "paid", "paid repair-only mode required")
    admission = registration.get("admission")
    _require(isinstance(admission, dict) and set(admission) == _ROLES | {"credential_path"}
             and isinstance(admission["credential_path"], str)
             and Path(admission["credential_path"]).is_absolute(), "complete paid admission inventory required")
    _require(all(task["backend"]["scripted_plans"] == {} for task in registration["tasks"].values()),
             "paid campaign cannot contain scripted actor plans")
    checks = {"population": (verify_population, {"task_count": 4}),
              "public_commands": (verify_public_commands, {}),
              "accounting": (verify_accounting, {}), "runtime": (verify_runtime, {"feedback": True}),
              "verification": (verify_verification, {}), "review": (verify_review, {}),
              "shared_preparation": (verify_shared_preparation, {})}
    try:
        proofs = {name: checker(registration, admission[name], **kwargs)
                  for name, (checker, kwargs) in checks.items()}
    except (KeyError, TypeError, AttributeError, IndexError) as exc:
        raise ValueError("malformed repair-only admission evidence") from exc
    return {"ready": True, "proofs": proofs}


def _identity(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _credential(expected, supplied):
    _require(supplied is not None and str(Path(supplied)) == expected,
             "credential identity differs from admission")
    path = Path(expected)
    _require(path.is_absolute() and path.resolve(strict=True) == path and path.is_file()
             and not path.is_symlink() and path.stat().st_uid == os.getuid()
             and stat.S_IMODE(path.stat().st_mode) == 0o600, "credential must remain owned physical0600file")


def validate_invocation(registration, request, out, public):
    """Common pre-effect request guard for scripted qualification and paid execution."""
    try:
        selected = policy.validated_request(request)
        _require(selected is not None, "explicit repair-only condition required")
        index = request["attempt_index"]
        _require(type(index) is int and 0 <= index < 16, "attempt index differs")
        attempt = registration["schedule"][index]
        task = registration["tasks"][attempt["task_id"]]
        identity = registration["campaign_id"] + "::" + str(index) + "::repair"
        expected = Path(registration["output_root"]) / "attempts" / (
            str(index).zfill(2) + "-" + attempt["arm"]) / "repair"
        state = request["state"]
        _require(request["task_id"] == attempt["task_id"] and request["arm"] == attempt["arm"]
                 and request["invocation_id"] == identity
                 and Path(out).absolute() == expected and Path(out).resolve() == expected
                 and request["allowance_usd"] == attempt["reserved_usd"]
                 and request["cli_cap_usd"] == attempt["cli_cap_usd"]
                 and public == task["backend"]["public"]
                 and public["feedback_policy"] == {"schema": policy.SCHEMA, "workspace": selected["check"]["cwd"]}
                 and request["public_packet"] == task["public_packet"],
                 "invocation identity, output, condition, budget or public context differs")
        _require(request["source"] == task["source"] and input_digest(task["source"]) == task["source_sha256"]
                 and state["run_id"] == registration["campaign_id"] + "-" + str(index)
                 and type(state["turns_used"]) is int and state["turns_used"] == 0
                 and state["baseline_digest"] == task["source_sha256"],
                 "repair-only invocation source or state differs")
    except (KeyError, TypeError, AttributeError, IndexError) as exc:
        raise ValueError("malformed repair-only invocation") from exc
    return identity



class FeedbackAdmission:
    """Separate authority type; cannot be substituted for the legacy three-phase policy."""
    def __init__(self, registration, token_path):
        self.registration = copy.deepcopy(registration)
        validate_registration(self.registration)
        self.proof = verify_paid(self.registration)
        _require(isinstance(self.proof, dict) and self.proof.get("ready") is True,
                 "concrete repair-only evidence did not pass")
        self.token_path = self.registration["admission"]["credential_path"]
        _credential(self.token_path, token_path)
        self.fingerprint = _identity(self.registration)
        self.used = set()

    def authorize(self, request, out, public, token_path):
        _require(_identity(self.registration) == self.fingerprint, "admission registration changed")
        _credential(self.token_path, token_path)
        for name, digest in self.registration["bindings"].items():
            legacy._bound_path(self.registration, {"path": name, "sha256": digest})
        identity = validate_invocation(self.registration, request, out, public)
        _require(identity not in self.used, "repair-only authorization is single-use")
        self.used.add(identity)
        return {"authorized_invocation": identity}
