"""Host-only prospective evaluator process. No imports from the public actor runtime."""
import hashlib
import importlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import subprocess
import sys
import time
import traceback


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _write(path, value):
    with Path(path).open("x") as stream:
        json.dump(value,stream,indent=2,sort_keys=True)
        stream.write("\n")


def _relative(name):
    if (not isinstance(name,str) or not name or PurePosixPath(name).is_absolute() or
            any(part in ("",".","..") for part in name.split("/")) or
            "\\" in name or any(ord(char)<32 for char in name)):
        raise ValueError("noncanonical private source path")
    return name


def _entries(root):
    root = Path(root)
    if not root.is_dir() or root.is_symlink():
        raise ValueError("invalid source root")
    resolved, entries = root.resolve(), {}
    for path in sorted(root.rglob("*")):
        if not path.resolve().is_relative_to(resolved):
            raise ValueError("source link escapes")
        mode = path.lstat().st_mode
        relative = path.relative_to(root).as_posix()
        if stat.S_ISLNK(mode):
            entries[relative] = {"kind":"link","target":os.readlink(path)}
        elif stat.S_ISREG(mode):
            entries[relative] = {"kind":"file","mode":stat.S_IMODE(mode),"sha256":_sha(path)}
        elif stat.S_ISDIR(mode):
            entries[relative] = {"kind":"directory","mode":stat.S_IMODE(mode)}
        else:
            raise ValueError("unsupported source entry")
    return entries


def _input_digest(root):
    entries = _entries(root)
    return hashlib.sha256(json.dumps(entries,sort_keys=True,separators=(",",":")).encode()).hexdigest()


def _source_files(root):
    return {name:value for name,value in _entries(root).items()
        if value["kind"] != "directory" and name != "submission.json" and
        name.split("/")[0] != ".git"}


def verify_package(package, expected):
    package = Path(package)
    if (not package.is_dir() or package.is_symlink() or not isinstance(expected,dict) or
            len(expected)!=99 or any(_relative(name)!=name for name in expected)):
        raise ValueError("exact reviewed 99-source package missing")
    actual = {path.relative_to(package).as_posix():_sha(path) for path in package.rglob("*")
        if path.is_file() and not path.is_symlink()}
    if any(path.is_symlink() for path in package.rglob("*")) or actual != expected:
        raise ValueError("reviewed evaluator package bytes changed")
    return package.resolve()


def verify_candidate(request, destination):
    for name in ("patch","capture_proof"):
        path = Path(request[name])
        if path.is_symlink() or _sha(path) != request[name+"_sha256"]:
            raise ValueError("candidate artifact binding changed")
    if (_input_digest(request["source"]) != request["source_digest"] or
            _input_digest(request["public_baseline"]) != request["public_baseline_sha256"]):
        raise ValueError("captured source or public baseline changed")
    proof = json.loads(Path(request["capture_proof"]).read_bytes())
    if (proof.get("complete") is not True or proof.get("sha256") != request["patch_sha256"] or
            proof.get("bytes") != Path(request["patch"]).stat().st_size):
        raise ValueError("candidate patch proof is incomplete")
    destination = Path(destination)
    shutil.copytree(request["public_baseline"],destination,symlinks=True)
    env = {"PATH":os.environ["PATH"],"GIT_CONFIG_NOSYSTEM":"1","GIT_CONFIG_GLOBAL":"/dev/null"}
    patch_bytes = Path(request["patch"]).read_bytes()
    if patch_bytes:
        result = subprocess.run(["git","-c","core.autocrlf=false","apply","--binary",
            "--whitespace=nowarn",str(Path(request["patch"]).resolve())],
            cwd=destination,env=env,capture_output=True,timeout=60)
        (destination.parent/"patch-apply.stdout").write_bytes(result.stdout)
        (destination.parent/"patch-apply.stderr").write_bytes(result.stderr)
        if result.returncode:
            raise ValueError("cumulative candidate patch does not apply to public baseline")
    if _source_files(destination) != _source_files(request["source"]):
        raise ValueError("cumulative patch differs from captured source")
    return proof


def memory_events(text):
    result = {}
    for line in text.splitlines():
        words = line.split()
        if len(words)!=2 or not words[1].isdigit() or words[0] in result:
            raise ValueError("malformed cgroup memory events")
        result[words[0]]=int(words[1])
    if result.get("oom_kill") != 0:
        raise ValueError("cgroup OOM count unknown or nonzero")
    return result


def _load(config):
    for name,expected in config["bindings"].items():
        if Path(name).is_symlink() or _sha(name)!=expected:
            raise ValueError("private acceptance/control binding changed")
    package = verify_package(config["package_root"],config["package_files"])
    sys.path.insert(0,str(package))
    tasks = importlib.import_module("multilang_tasks")
    policy = importlib.import_module("grade_policy")
    streams = importlib.import_module("stream_evidence")
    for module in (tasks,policy,streams):
        if not Path(module.__file__).resolve().is_relative_to(package):
            raise ValueError("private evaluator import escaped reviewed package")
    record = json.loads(Path(config["record"]).read_bytes())
    accepted = json.loads(Path(config["acceptance_registration"]).read_bytes())
    f2p = accepted["original_f2p"]+accepted.get("new_f2p",[])
    p2p = accepted["original_p2p"]+accepted.get("new_p2p",[])
    expected = f2p+p2p
    if (record["FAIL_TO_PASS"]!=f2p or record["PASS_TO_PASS"]!=p2p or
            len(expected)!=len(set(expected)) or not f2p or
            record["instance_id"]!=accepted["task"] or config["image"]!=accepted["image"] or
            _sha(config["record"])!=accepted["record_sha256"] or
            streams.commands_digest(record)!=config["stream_registration"]["commands_sha256"]):
        raise ValueError("frozen complete acceptance population or command binding changed")
    if any(spec.get("profile") == "nextest-junit-host-only-v1" for spec in config["stream_registration"].get("tests", [])):
        from feedback_nextest import translate_registration
        translate_registration(record, config["stream_registration"], streams)
    return tasks,policy,streams,record


def _fixture_start(docker,name,fixture,out):
    program = Path(fixture["program"])
    if _sha(program)!=fixture["program_sha256"]:
        raise ValueError("private fixture service changed")
    install = "from pathlib import Path;import sys;Path('/tmp/effort-loopback-page.py').write_bytes(sys.stdin.buffer.read())"
    docker("exec","-i",name,"python3","-c",install,data=program.read_text(),timeout=60)
    docker("exec","-d",name,"python3","-u","/tmp/effort-loopback-page.py","good",timeout=60)
    probe = """import hashlib,json,os,socket,time,urllib.request,sys
host,port=sys.argv[1],int(sys.argv[2])
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
packet={'global_private_env':os.environ.get('OBSCURA_ALLOW_PRIVATE_NETWORK'),'resolved':sorted({x[4][0] for x in socket.getaddrinfo(host,port)})}
for attempt in range(50):
    try:
        response=opener.open('http://'+host+':'+str(port),timeout=1);body=response.read()
        packet.update(reachable=True,status=response.status,body_sha256=hashlib.sha256(body).hexdigest());break
    except OSError as exc:
        packet.update(reachable=False,error=str(exc));time.sleep(.05)
print(json.dumps(packet))
"""
    result=docker("exec",name,"python3","-c",probe,fixture["hostname"],str(fixture["port"]),timeout=30)
    packet=json.loads(result.stdout)
    _write(out/"fixture-startup.json",packet)
    if (packet.get("global_private_env") is not None or packet.get("resolved")!=["127.0.0.1"] or
            packet.get("reachable") is not True or packet.get("status")!=200 or
            packet.get("body_sha256")!=fixture["body_sha256"]):
        raise ValueError("private fixture readiness mismatch")


def fresh_absence(docker, name):
    result=docker("container","inspect",name,check=False,timeout=60)
    return (result.returncode!=0 and isinstance(result.stdout,str)
            and "No such container" in result.stdout)

def _run_grade(request,config,out,proof,modules):
    tasks,policy,streams,record = modules
    docker = tasks.pilot.docker
    observations,errors,owners = [],[],{}
    fixture = config.get("fixture")
    host_nextest = any(spec.get("profile") == "nextest-junit-host-only-v1"
                       for spec in config["stream_registration"].get("tests", []))
    trusted = config.get("trusted_test_inputs")
    installations = {}
    rebuild = tasks.control.rebuild if trusted else None
    roots = []
    if trusted:
        from trusted_test_inputs import _validated
        roots, _, _ = _validated(trusted)
    restored = set(tasks.tasks.patch_files(record["test_patch"]))
    selected = set(config["production_paths"]) | set(proof["edited"])
    selected -= restored | {"submission.json"}
    selected = {name for name in selected if not any(PurePosixPath(name).is_relative_to(root) for root in roots)}
    expected_source = {}
    for name in sorted(selected):
        _relative(name)
        path = Path(request["source"])/name
        expected_source["/testbed/"+name] = ({"link":os.readlink(path)} if path.is_symlink()
            else _sha(path) if path.is_file() else None)
    expected_source.update(config["fixed_test_sha256"])
    for name in expected_source:
        if not name.startswith("/testbed/"):
            raise ValueError("source observation escaped testbed")
        _relative(name[len("/testbed/"):])

    def observe(name,stage):
        item={"name":name,"stage":stage,"at":time.time()}
        try:
            inspect=docker("inspect",name,timeout=60)
            rows=json.loads(inspect.stdout)
            if len(rows)!=1: raise ValueError("private container identity ambiguous")
            identity=rows[0]
            item["inspect"]=identity
            host=identity["HostConfig"]
            if (identity["Id"]!=owners[name] or identity["Image"]!=config["image"] or
                    identity["Config"]["User"]!="0:0" or host["NetworkMode"]!="none" or
                    host["Memory"]!=8*1024**3 or host["MemorySwap"]!=8*1024**3 or
                    host["NanoCpus"]!=4*10**9 or host["Init"] is not True or
                    host["PidsLimit"]!=4096 or host.get("Binds") or
                    host["CapDrop"]!=["ALL"] or host["SecurityOpt"]!=["no-new-privileges"]):
                raise ValueError("private container profile or identity mismatch")
            events=docker("exec",name,"cat","/sys/fs/cgroup/memory.events",timeout=60)
            item["memory_events"]=memory_events(events.stdout)
            if stage=="after-start" and host_nextest:
                from feedback_nextest import runtime_probes
                item["runner_versions"] = []
                for argv, expected in runtime_probes(record, config["stream_registration"]):
                    result = docker("exec", owners[name], *argv, timeout=60)
                    actual = result.stdout.rstrip("\n")
                    item["runner_versions"].append({"argv": argv, "actual": actual, "expected": expected})
                    if result.returncode != 0 or actual != expected:
                        raise ValueError("registered nextest runner version differs")
            if stage=="before-remove":
                if trusted:
                    from feedback_trusted_inputs import verify_inputs
                    item["trusted_test_inputs"] = verify_inputs(docker, installations[name])
                code="""import hashlib,json,os,sys
from pathlib import Path
result={}
for name in json.loads(sys.argv[1]):
    p=Path(name)
    result[name]={'link':os.readlink(p)} if p.is_symlink() else hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
print(json.dumps(result))
"""
                result=docker("exec",name,"python3","-c",code,json.dumps(list(expected_source)),timeout=60)
                item["source_sha256"]=json.loads(result.stdout)
                if item["source_sha256"]!=expected_source:
                    raise ValueError("candidate production/private test bytes differ")
                if fixture:
                    result=docker("exec",name,"sha256sum","/tmp/effort-loopback-page.py",timeout=60)
                    item["service_sha256"]=result.stdout.split()[0]
                    if item["service_sha256"]!=fixture["program_sha256"]:
                        raise ValueError("private fixture program changed during grade")
        except Exception as exc:
            item["error"]=type(exc).__name__+": "+str(exc)
            errors.append(item["error"])
        observations.append(item)
        with (out/"runtime-observations.jsonl").open("a") as stream:
            stream.write(json.dumps(item,sort_keys=True)+"\n")

    def watched(*args,**kwargs):
        if args and args[0]=="run":
            if args[-3]!=config["image"]:
                raise ValueError("private image changed")
            extra=["--user","0:0","--memory-swap","8g","--init"]
            if fixture:
                extra += ["--add-host",fixture["hostname"]+":127.0.0.1"]
            args=("run",*extra,*args[1:])
        if args and args[0]=="rm":
            for name in owners:
                if name in args: observe(name,"before-remove")
        result=docker(*args,**kwargs)
        if args and args[0]=="run" and result.returncode==0:
            name=args[args.index("--name")+1]
            owners[name]=result.stdout.strip()
            if fixture: _fixture_start(docker,name,fixture,out)
            observe(name,"after-start")
        return result

    def trusted_rebuild(container, workdir, *args, **kwargs):
        if container not in owners or workdir != "/testbed" or container in installations or errors:
            raise ValueError("trusted input restoration has no unique verified grade boundary")
        from feedback_trusted_inputs import install_inputs
        installations[container] = install_inputs(docker, owners[container], trusted)
        _write(out/"trusted-input-installation.json", installations[container])
        return rebuild(container, workdir, *args, **kwargs)

    bundle={"workdir":"/testbed","expected":{"fail_to_pass":len(record["FAIL_TO_PASS"]),
        "pass_to_pass_kept":len(record["PASS_TO_PASS"]),"dropped":[],"fail_to_pass_dropped":[]}}
    tasks.pilot.docker=watched
    if trusted:
        tasks.control.rebuild=trusted_rebuild
    tasks.GRADE_STEP_TIMEOUT=900
    try:
        grader=tasks.live_grader(record,bundle,config["image"],out/"native",capture_streams=True,
            diagnostic_artifacts={int(k):v for k,v in config["diagnostic_artifacts"].items()})
        raw=grader(Path(request["patch"]).read_text(),"candidate")
    finally:
        tasks.pilot.docker=docker
        if trusted:
            tasks.control.rebuild=rebuild
    _write(out/"raw-grade.json",raw)
    absent=[]
    for name in owners:
        absent.append(fresh_absence(docker,name))
    probes=[item for item in observations if "memory_events" in item and "error" not in item]
    before=[item for item in probes if item["stage"]=="before-remove"]
    runtime={"complete":bool(owners) and len(owners)==1 and all(absent) and len(before)==1 and not errors,
        "resource_ok":not errors,"cgroup_probes":len(probes),
        "oom_kill":max((item["memory_events"]["oom_kill"] for item in probes),default=-1),"errors":errors,
        "fresh_absence":absent}
    _write(out/"runtime-proof.json",runtime)
    path=Path(raw["log"])
    log=path.read_text()
    full=json.loads(path.with_name("grade.json").read_bytes())
    registered = config["stream_registration"]
    if host_nextest:
        from feedback_nextest import qualify_registration
        registered = qualify_registration(record, registered, full, streams)
        _write(out/"stream-profile-translation.json",
               {"declared": config["stream_registration"], "structural_grammar": registered,
                "scope": "Explicit measured compatibility; no installed libtest version claim."})
    verdict=policy.adjudicate_streams(raw,full,record,bundle,log=log,runtime=runtime,
        registered=registered)
    return verdict


def evaluate(request,out):
    out=Path(out)
    if _sha(request["config"])!=request["config_sha256"]:
        raise ValueError("private configuration changed")
    config=json.loads(Path(request["config"]).read_bytes())
    modules=_load(config)
    proof=verify_candidate(request,out/"patch-verification")
    verdict=_run_grade(request,config,out,proof,modules)
    verify_package(config["package_root"],config["package_files"])
    for name,expected in config["bindings"].items():
        if _sha(name)!=expected: raise ValueError("private input changed during grading")
    if _input_digest(request["source"])!=request["source_digest"]:
        raise ValueError("frozen candidate changed during grading")
    return verdict


def main():
    request_path,out=Path(sys.argv[1]),Path(sys.argv[2])
    _write(out/"private-entry-started.json",{"request_sha256":_sha(request_path),
        "entry_sha256":_sha(__file__),"provider_calls":0})
    try:
        verdict=evaluate(json.loads(request_path.read_bytes()),out)
    except BaseException as exc:
        traceback.print_exc(file=sys.stderr)
        verdict={"valid":False,"pass":False,"kind":"measurement_invalid",
            "reason":type(exc).__name__+": "+str(exc),"policy_version":"semantic-stream-contract-v2"}
    _write(out/"verdict.json",verdict)
    print(json.dumps({"valid":verdict.get("valid"),"pass":verdict.get("pass"),
        "kind":verdict.get("kind"),"provider_calls":0}))
    return 0


if __name__=="__main__": raise SystemExit(main())
