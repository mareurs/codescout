"""Required context is prepared independently of any model-selected tool call."""
import hashlib
from pathlib import Path
import tempfile
import unittest

from native_executor import _public_digest
try:
    import context_inputs as subject
except ModuleNotFoundError:
    subject=None


class PreparedContextTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(subject,"context preparation missing")
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.stage=self.root/"stage";self.stage.mkdir()
        self.actor=self.stage/"actor";(self.actor/".codescout").mkdir(parents=True)
        (self.actor/"source.rs").write_text("fn main() {}")
        (self.actor/".codescout/system-prompt.md").write_text("Public onboarding\nUse public symbols.\n")
        self.plugin=self.root/"plugin"
        self.skill=self.plugin/"skills/reconnaissance"
        (self.skill/"references").mkdir(parents=True)
        (self.skill/"SKILL.md").write_text("# Reconnaissance\nInspect the interface before changing it.\n")
        (self.skill/"references/seams.md").write_text("# Seams\nUse actual source.\n")

    def test_complete_preload_and_references_preserve_public_source_and_raw_inputs(self):
        before=_public_digest(self.actor)
        checked=subject.prepare_context(self.stage,self.actor,self.plugin)
        body=Path(checked["path"]).read_text()
        self.assertIn((self.actor/".codescout/system-prompt.md").read_text(),body)
        self.assertIn((self.skill/"SKILL.md").read_text(),body)
        reference=self.actor/".codescout/prepared-context/reconnaissance/references/seams.md"
        self.assertEqual(reference.read_bytes(),(self.skill/"references/seams.md").read_bytes())
        self.assertIn(".codescout/prepared-context/reconnaissance",body)
        self.assertEqual(_public_digest(self.actor),before)
        self.assertNotIn("Launching skill:",body)
        for name,digest in checked["files"].items():
            self.assertEqual(hashlib.sha256(Path(name).read_bytes()).hexdigest(),digest)

    def test_linked_supporting_file_and_empty_required_context_are_refused(self):
        link=self.skill/"references/link"
        link.symlink_to(self.root/"outside")
        with self.assertRaises(ValueError):
            subject.prepare_context(self.stage,self.actor,self.plugin)
        link.unlink()
        (self.actor/".codescout/system-prompt.md").write_text("")
        with self.assertRaises(ValueError):
            subject.prepare_context(self.stage,self.actor,self.plugin)


if __name__=="__main__":
    unittest.main()
