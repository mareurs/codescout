"""Host-only installation of sealed test inputs in an already owned private container."""
from pathlib import Path
import hashlib
import json
import re

import trusted_test_inputs as core


def _checked(docker, *args):
    result = docker(*args, timeout=300, check=False)
    if result.returncode != 0:
        raise ValueError("trusted test input transport failed: " + str(result.stdout)[-1000:])
    return result.stdout


def _container(value):
    if not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{64}", value):
        raise ValueError("trusted input operation requires an immutable container ID")
    return value


def _operate(docker, packet, operation):
    if operation not in ("restore_test_inputs", "verify_test_inputs"):
        raise ValueError("unknown trusted input operation")
    cid = _container(packet["container"])
    # Isolated Python excludes candidate working-directory imports/environment.
    # Check helper bytes before executing them, then validate the sealed inputs.
    code = (
        "import hashlib,json,runpy,sys\n"
        "from pathlib import Path\n"
        "p=Path(sys.argv[1])\n"
        "if p.is_symlink() or hashlib.sha256(p.read_bytes()).hexdigest()!=sys.argv[2]:\n"
        "    raise ValueError('trusted input helper bytes changed')\n"
        "api=runpy.run_path(str(p))\n"
        "result=api[" + repr(operation) + "](json.loads(sys.argv[3]),'/testbed')\n"
        "print(json.dumps(result,sort_keys=True))\n"
    )
    text = _checked(docker, "exec", cid, "python3", "-I", "-B", "-c", code,
                    packet["helper"], packet["helper_sha256"], json.dumps(packet["descriptor"]))
    value = json.loads(text)
    if value.get("complete") is not True or value.get("manifest_sha256") != packet["descriptor"]["manifest_sha256"]:
        raise ValueError("trusted input remote receipt incomplete or changed")
    return value


def install_inputs(docker, container, descriptor):
    cid = _container(container)
    core._validated(descriptor)
    helper = Path(core.__file__).resolve()
    if not helper.is_file() or helper.is_symlink():
        raise ValueError("trusted input helper is not a physical source file")
    helper_sha = hashlib.sha256(helper.read_bytes()).hexdigest()
    directory = _checked(docker, "exec", cid, "mktemp", "-d", "/tmp/effort-trusted-XXXXXXXX").strip()
    if not re.fullmatch(r"/tmp/effort-trusted-[A-Za-z0-9]{8}", directory):
        raise ValueError("unexpected trusted input temporary path")
    remote = dict(descriptor)
    for role in ("manifest", "archive"):
        target = directory + "/" + Path(descriptor[role]).name
        _checked(docker, "cp", descriptor[role], cid + ":" + target)
        remote[role] = target
    target = directory + "/trusted_test_inputs.py"
    _checked(docker, "cp", str(helper), cid + ":" + target)
    packet = {"container": cid, "helper": target, "helper_sha256": helper_sha, "descriptor": remote}
    packet["restoration"] = _operate(docker, packet, "restore_test_inputs")
    return packet


def verify_inputs(docker, installed):
    """Read-only check before the owned container is removed."""
    return _operate(docker, installed, "verify_test_inputs")
