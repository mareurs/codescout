"""Native mount/readback and candidate-source controls; no live CLI claim."""
import copy
import os
from pathlib import Path
import sys
import tempfile
import unittest
sys.path.insert(0,str(Path(__file__).parent))
import public_build_inputs as inputs
import native_executor
import receipts

class NativeBuildContractTests(unittest.TestCase):
    def setUp(self):
        temporary=tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.base=Path(temporary.name)
        self.actor=self.base/"actor"
        self.actor.mkdir()
        (self.actor/"node_modules").mkdir(mode=0o750)
        (self.actor/"frontend/node_modules").mkdir(parents=True)
        (self.actor/"main.rs").write_bytes(b"production edit")
        self.seed=self.base/"seed"
        (self.seed/"store").mkdir(parents=True)
        (self.seed/"store/dependency").write_bytes(b"locked")
        self.image="sha256:"+"a"*64
        self.raw={"schema":"public-build-inputs-v1","image":self.image,
                  "seed":{"path":str(self.seed),"sha256":inputs.generated_digest(self.seed)},
                  "dependency_dirs":["node_modules","frontend/node_modules"],
                  "cache_mounts":[{"seed_relative":"store","destination":"/bench/public-dependencies/store"}]}
        self.stage=inputs.stage_inputs(self.raw,self.actor,self.image,self.base/"stage")
        self.options={"--mount":["type=bind,src="+str(self.actor)+",dst=/testbed"]+
                      ["type=bind,src="+r["source"]+",dst="+r["destination"] for r in self.stage["mounts"]]}
        self.row={"Image":self.image,"Mounts":[{"Type":"bind","Source":str(self.actor),
                                               "Destination":"/testbed","RW":True}]+
                  [{"Type":"bind","Source":r["source"],"Destination":r["destination"],"RW":True}
                   for r in self.stage["mounts"]]}

    def test_options_and_actual_runtime_bind_same_expected_descriptor(self):
        for result in (inputs.validate_native_options(self.options,self.raw,self.stage,self.actor,self.image),
                       inputs.validate_native_runtime(self.row,self.raw,self.stage,self.actor,self.image)):
            self.assertEqual(result["fingerprint"],self.stage["fingerprint"])

    def test_missing_duplicate_shadow_and_readonly_dependency_mounts_fail(self):
        for variant in ("missing","duplicate","shadow","readonly"):
            options=copy.deepcopy(self.options)
            if variant=="missing":
                options["--mount"].pop()
            elif variant=="duplicate":
                options["--mount"].append(options["--mount"][-1])
            elif variant=="shadow":
                options["--mount"].append("type=bind,src="+str(self.seed)+",dst=/testbed/unregistered")
            else:
                options["--mount"][-1]+=",readonly"
            with self.subTest(variant=variant),self.assertRaises(ValueError):
                inputs.validate_native_options(options,self.raw,self.stage,self.actor,self.image)

    def test_actual_runtime_image_source_or_mount_drift_fails(self):
        for variant in ("image","source","readonly","extra"):
            row=copy.deepcopy(self.row)
            if variant=="image": row["Image"]="sha256:"+"b"*64
            elif variant=="source": row["Mounts"][-1]["Source"]=str(self.seed)
            elif variant=="readonly": row["Mounts"][0]["RW"]=False
            else: row["Mounts"].append({"Type":"bind","Source":str(self.seed),
                                        "Destination":"/bench/public-dependencies/extra","RW":True})
            with self.subTest(variant=variant),self.assertRaises(ValueError):
                inputs.validate_native_runtime(row,self.raw,self.stage,self.actor,self.image)

    def test_different_valid_descriptor_cannot_borrow_another_stage(self):
        expected={**self.raw,"dependency_dirs":["node_modules"]}
        with self.assertRaises(ValueError):
            inputs.validate_native_options(self.options,expected,self.stage,self.actor,self.image)

    def test_option_parser_rejects_duplicate_or_ambiguous_attributes(self):
        for mount in ("type=bind,src=/a,src=/b,dst=/testbed",
                      "type=bind,src=/a,dst=/testbed,readonly=false",
                      "type=bind,src=/a,target=/testbed,dst=/testbed",
                      "type=bind,src=/a,dst=/testbed,unknown"):
            options={"--mount":[mount,*self.options["--mount"][1:]]}
            with self.subTest(mount=mount),self.assertRaises(ValueError):
                inputs.validate_native_options(options,self.raw,self.stage,self.actor,self.image)

    def test_public_digest_preserves_declared_empty_root_dependency_target(self):
        self.assertEqual(native_executor._public_digest(self.actor,dependency_dirs=self.raw["dependency_dirs"]),
                         receipts.input_digest(self.actor))

    def test_candidate_keeps_production_edit_and_empty_declared_directories(self):
        root_dep=next(Path(r["source"]) for r in self.stage["mounts"]
                      if r["destination"]=="/testbed/node_modules")
        (root_dep/"generated.js").write_bytes(b"generated dependency")
        captured=self.base/"captured"
        native_executor._capture(self.actor,captured,dependency_dirs=self.raw["dependency_dirs"])
        self.assertEqual((captured/"main.rs").read_bytes(),b"production edit")
        self.assertTrue((captured/"node_modules").is_dir())
        self.assertEqual(list((captured/"node_modules").iterdir()),[])
        self.assertEqual((captured/"node_modules").stat().st_mode&0o777,0o750)
        self.assertFalse((captured/"node_modules/generated.js").exists())
        self.assertEqual(receipts.input_digest(captured),receipts.input_digest(self.actor))

    def test_nonempty_host_dependency_target_is_invalid_not_silently_discarded(self):
        (self.actor/"node_modules/unexpected.js").write_bytes(b"unmounted host write")
        with self.assertRaises(ValueError):
            native_executor._capture(self.actor,self.base/"captured",dependency_dirs=self.raw["dependency_dirs"])


    def test_live_runtime_mount_check_does_not_inventory_mutating_outputs(self):
        cache = next(Path(row["source"]) for row in self.stage["mounts"] if row["role"] == "cache")
        os.mkfifo(cache / "transient.pipe")
        # A transient producer entry is not a completed generated-evidence capsule.
        checked = inputs.validate_native_runtime(self.row, self.raw, self.stage, self.actor, self.image)
        self.assertEqual(checked["fingerprint"], self.stage["fingerprint"])
        self.assertIsNone(checked["generated_sha256"])
        with self.assertRaisesRegex(ValueError, "unsupported"):
            inputs.verify_staged(self.stage, self.actor, self.image)

if __name__=="__main__":
    unittest.main()
