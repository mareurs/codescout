"""Preserve canonical Gitlinks when creating an isolated synthetic source repository.

Only the index is changed. Populated public data directories remain byte-for-byte
unchanged, and no historical commit objects are copied into the synthetic repo.
"""
import argparse
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess

SCHEMA = "source-gitlinks-v1"

def _git(repo, *args, data=None):
    result = subprocess.run(["git", "--literal-pathspecs", *args], cwd=repo,
        input=data, capture_output=True, timeout=30)
    if result.returncode:
        raise ValueError("Git preparation command failed: " + result.stderr.decode(errors="replace")[-500:])
    return result.stdout

def _root(repo):
    root = Path(repo)
    if not root.is_absolute() or root.resolve(strict=True) != root or not root.is_dir():
        raise ValueError("physical absolute source repository required")
    return root

def _entries(repo):
    result = []
    for raw in _git(repo, "ls-files", "--stage", "-z").split(b"\0"):
        if not raw:
            continue
        header, name = raw.split(b"\t", 1)
        mode, digest, stage = header.split()
        if stage != b"0":
            raise ValueError("unmerged source index")
        result.append((mode.decode("ascii"), digest.decode("ascii"), os.fsdecode(name)))
    return result

def _validate(snapshot, object_format):
    if (not isinstance(snapshot, dict) or set(snapshot) != {"schema", "object_format", "gitlinks"}
            or snapshot["schema"] != SCHEMA or snapshot["object_format"] != object_format
            or object_format not in {"sha1", "sha256"} or not isinstance(snapshot["gitlinks"], list)):
        raise ValueError("Gitlink snapshot schema or object format differs")
    width = 40 if object_format == "sha1" else 64
    paths = []
    for row in snapshot["gitlinks"]:
        if not isinstance(row, dict) or set(row) != {"path", "object"}:
            raise ValueError("invalid Gitlink row")
        path, digest = row["path"], row["object"]
        if (not isinstance(path, str) or not path or "\0" in path
                or PurePosixPath(path).is_absolute() or ".." in PurePosixPath(path).parts
                or path != PurePosixPath(path).as_posix() or path == "."
                or not isinstance(digest, str) or re.fullmatch("[0-9a-f]{" + str(width) + "}", digest) is None):
            raise ValueError("invalid Gitlink path or object")
        if any(path == old or path.startswith(old + "/") or old.startswith(path + "/") for old in paths):
            raise ValueError("duplicate or overlapping Gitlink paths")
        paths.append(path)
    return snapshot["gitlinks"]

def capture_gitlinks(repo):
    """Read canonical stage-zero Gitlink metadata before the old Git history is removed."""
    repo = _root(repo)
    object_format = _git(repo, "rev-parse", "--show-object-format").decode("ascii").strip()
    snapshot = {"schema": SCHEMA, "object_format": object_format,
        "gitlinks": [{"path": name, "object": digest} for mode, digest, name in _entries(repo)
            if mode == "160000"]}
    _validate(snapshot, object_format)
    return snapshot

def restore_gitlinks(repo, snapshot):
    """Replace flattened descendant entries with their original commit entries, in one index update."""
    repo = _root(repo)
    object_format = _git(repo, "rev-parse", "--show-object-format").decode("ascii").strip()
    links = _validate(snapshot, object_format)
    entries = _entries(repo)
    paths = [row["path"] for row in links]
    width = 40 if object_format == "sha1" else 64
    removed = [name for _, _, name in entries
        if any(name == path or name.startswith(path + "/") for path in paths)]
    records = [b"0 " + b"0" * width + b"\t" + os.fsencode(name) + b"\0" for name in removed]
    records += [b"160000 " + row["object"].encode("ascii") + b"\t" + os.fsencode(row["path"]) + b"\0"
        for row in links]
    if records:
        _git(repo, "update-index", "-z", "--index-info", data=b"".join(records))
    if capture_gitlinks(repo) != snapshot:
        raise ValueError("restored Gitlink inventory differs from the canonical snapshot")

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("capture", "restore"))
    parser.add_argument("repository", type=Path)
    parser.add_argument("snapshot", type=Path)
    args = parser.parse_args()
    root = _root(args.repository)
    path = args.snapshot.absolute()
    if path.is_relative_to(root) or path.is_symlink():
        raise ValueError("Gitlink snapshot must be outside the source repository")
    if args.action == "capture":
        value = capture_gitlinks(root)
        with path.open("x") as stream:
            json.dump(value, stream, sort_keys=True)
            stream.write("\n")
        path.chmod(0o644)
    else:
        restore_gitlinks(root, json.loads(path.read_bytes()))

if __name__ == "__main__":
    main()
