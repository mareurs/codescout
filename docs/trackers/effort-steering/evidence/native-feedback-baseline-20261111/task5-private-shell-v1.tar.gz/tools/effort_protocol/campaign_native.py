"""Public native invocation composition; private grading never enters this module."""
import copy
import hashlib
import json
from pathlib import Path
import shutil
import uuid
import feedback_policy
import public_build_inputs
from execution_profiles import validate_profile_build_inputs

from adapter import run_phase, _admit_backend
from campaign_resources import ResourceSupervisor
from context_inputs import prepare_context
from embedding_runtime import embedding_runtime
from native_executor import NativeExecutor, _capture, external
from preparation import _runtime, _runtime_inputs
from public_clone import prepare_public_clone, verify_source_baseline
from public_fixture import fixture_docker_options
from qualify_native import _native_argv, _readiness
from receipts import input_digest, publish_exclusive

validate_embedding_profile = external.validate_embedding_profile


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _host_record(path, faults):
    if not path.exists():
        return None
    try:
        if path.is_symlink() or not path.is_file():
            raise ValueError("not an owned regular receipt")
        value = json.loads(path.read_bytes())
        if not isinstance(value, dict):
            raise ValueError("not a receipt object")
        return value
    except (OSError, ValueError) as exc:
        faults.append(path.name + ": " + type(exc).__name__)
        return None

def prepare_native_build_inputs(stage, actor, argv, public):
    admitted = validate_profile_build_inputs(public["execution_profile"], public.get("public_build_inputs"),
                                             actor, public["image"])
    if admitted is None:
        return list(argv), {}, {}
    if argv[-4:] != [public["image"], "start", "--project", "/testbed"]:
        raise ValueError("native build inputs require the exact registered worker boundary")
    state = public_build_inputs.stage_inputs(admitted["descriptor"], actor, public["image"],
                                             stage / "public-build-state")
    helper = stage / "public-build-inputs-helper.py"
    data = Path(public_build_inputs.__file__).read_bytes()
    with helper.open("xb") as stream:
        stream.write(data)
    fields = {"execution_profile": public["execution_profile"],
              "public_build_inputs": admitted["descriptor"], "public_build_stage": state,
              "public_build_inputs_helper": str(helper)}
    selected = list(argv)
    selected[-4:-4] = [part for mount in state["mounts"]
                       for part in ("--mount", "type=bind,src=" + mount["source"] + ",dst=" + mount["destination"])]
    return selected, fields, {str(helper): hashlib.sha256(data).hexdigest()}


def invoke_native(request, out, public, *, mode, scripted_plan=None, token_path=None, admission=None):
    """Return the durable host receipt, including known charges on every failure."""
    if mode not in ("scripted", "paid"):
        raise ValueError("native campaign mode must be explicit")
    selected = feedback_policy.validated_request(request)
    marker = public.get("feedback_policy")
    if selected is None:
        if marker is not None:
            raise ValueError("repair-only public configuration requires an explicit policy request")
    elif marker != {"schema": feedback_policy.SCHEMA, "workspace": selected["check"]["cwd"]}:
        raise ValueError("repair-only public and request policies differ")
    bound = 4 if selected is not None else 2
    if mode == "scripted" and (not isinstance(scripted_plan, list) or token_path is not None or admission is not None):
        raise ValueError("scripted campaign requires a plan and prohibits real credentials")
    if mode == "paid":
        if selected is not None:
            from feedback_admission import FeedbackAdmission
            expected_authority = FeedbackAdmission
        else:
            from paid_admission import PaidAdmission
            expected_authority = PaidAdmission
        if scripted_plan is not None or type(admission) is not expected_authority:
            raise ValueError("verified paid admission object required for the selected policy")
        admission.authorize(request, out, public, token_path)
    if request.get("arm") not in ("L", "R", "P", "X") or request.get("max_continuations") != bound:
        raise ValueError("unregistered native arm or continuation bound")
    out, source = Path(out).resolve(strict=True), Path(request["source"]).resolve(strict=True)
    external.validate_context_path(out)
    if out.is_relative_to(source) or source.is_relative_to(out):
        raise ValueError("native CLI stage must have isolated temporary ancestry")
    stage, captured, protocol = out / "native", out / "native-captured", out / "protocol"
    state = copy.deepcopy(request["state"])
    record = {"invocation_id": request["invocation_id"], "cost_usd": None, "cost_is_final": False,
        "context_valid": False, "capture_complete": False, "cleanup_complete": False,
        "measurement_invalid": True, "state": state, "turns": 0, "candidate": None,
        "source_digest": None, "public_artifact": None, "native_path": str(stage),
        "actor_started": False, "reason": None}
    failure, outcome, returned = None, None, None
    try:
        runtime = public["runtime"]
        if _runtime(_runtime_inputs(runtime)) != runtime or _sha(public["global_rules"]) != public["global_rules_sha256"]:
            raise ValueError("frozen public runtime or global rules changed")
        baseline_sha256 = verify_source_baseline(public)
        stage.mkdir()
        relay = stage / "embedding"
        relay.mkdir()
        with embedding_runtime(relay, public["image"], public["embedding"]) as embedding:
            actor = stage / "actor"
            prepared = prepare_public_clone(source, actor, public)
            publish_exclusive(stage / "public-preparation.json", prepared)
            home = stage / "native-home"
            home.mkdir()
            argv = _native_argv(actor, home, {"runtime_manifest": public["runtime_manifest"],
                                            "native_image": public["image"]})
            name = "ep-cli-" + uuid.uuid4().hex
            argv[argv.index("--name")+1] = name
            argv[argv.index("--label")+1] = "codescout.hfa=" + name
            argv[argv.index("--network")+1] = embedding["network_id"]
            argv[argv.index("--tmpfs")+1] = "/tmp:rw,exec,size=16g,uid=1000,gid=1000"
            argv.insert(argv.index("--init"), "--read-only")
            argv[-4:-4] = ["--cap-drop", "ALL", "--security-opt", "no-new-privileges",
                           "-e", "CARGO_TARGET_DIR=/tmp/target"]
            fixture = public.get("public_fixture")
            if fixture is not None:
                position = argv.index("--entrypoint")
                del argv[position:position+2]
                argv[-4:-4] = fixture_docker_options(fixture, "native")
            argv, build_fields, build_files = prepare_native_build_inputs(stage, actor, argv, public)
            options = {key: [argv[i+1] for i, value in enumerate(argv[:-4]) if value == key]
                       for key in ("--network", "--tmpfs", "--cap-drop", "--security-opt")}
            options["--read-only"] = [True]
            publish_exclusive(stage / "embedding-admission.json",
                              validate_embedding_profile(embedding, options, public["image"]))
            native_path = stage / "mcp-native-argv.json"
            publish_exclusive(native_path, argv)
            ready = stage / "readiness"
            ready.mkdir()
            readiness_cfg = {"native_image": public["image"],
                "registered_readiness": copy.deepcopy(public["registered_readiness"]),
                **build_fields, "files": build_files,
                **{key: prepared[key] for key in ("knowledge_paths", "knowledge_sha256",
                                                  "baseline_commit", "index_update_required")},
                "lsp_warmup_retries": public.get("lsp_warmup_retries", 0),
                **({"source_baseline_sha256": baseline_sha256} if baseline_sha256 is not None else {}),
                **({"public_fixture": fixture} if fixture is not None else {})}
            publish_exclusive(ready / "registration.json", readiness_cfg)
            proof = _readiness(ready, argv, actor, source, readiness_cfg)
            context = prepare_context(stage, actor, runtime["plugin"]["path"])
            config = {"actor": str(actor), "image": public["image"], **build_fields,
                "baseline_commit": public.get("capture_base_commit", prepared["baseline_commit"]),
                "cli": runtime["files"]["cli"]["path"], "plugin": runtime["plugin"]["path"],
                "global_rules": public["global_rules"], "prompt": request["public_packet"]["issue"],
                "checks": feedback_policy.completion_checks(selected) if selected is not None else copy.deepcopy(public["cli_checks"]),
                **({"feedback_policy": selected} if selected is not None else {}),
                "timeout_s": public["timeout_s"],
                "check_timeout_s": public["check_timeout_s"], "max_continuations": bound,
                "knowledge_paths": prepared["knowledge_paths"], "embedding_profile": embedding,
                "context_preload": context,
                **({"public_fixture": fixture} if fixture is not None else {}),
                "files": {str(path): _sha(path) for path in
                    (native_path, Path(public["global_rules"]), Path(runtime["files"]["cli"]["path"]), actor / "CLAUDE.md")}}
            config["files"].update(context["files"])
            config["files"].update(build_files)
            publish_exclusive(stage / "prepared.json", config)
            profile = {"Memory": 32*1024**3, "MemorySwap": 32*1024**3, "NanoCpus": 4*10**9,
                "PidsLimit": 4096, "ReadonlyRootfs": True, "NetworkMode": embedding["network_id"],
                "CapDrop": ["ALL"], "SecurityOpt": ["no-new-privileges"],
                "Tmpfs": {"/tmp": "rw,exec,size=16g,uid=1000,gid=1000"}}
            supervisor = ResourceSupervisor(
                floors=public.get("resource_floors", {"root_free": 80*1024**3,
                    "tmp_free": 4*1024**3, "mem_available": 16*1024**3}),
                native_profile=profile, root=public.get("resource_root", "."), temporary=out)
            backend = NativeExecutor(stage, captured,
                system_lines=external.worker.visible((actor / ".codescout/system-prompt.md").read_text()),
                recon_marker="Base directory for this skill:", scripted_plan=scripted_plan,
                allow_paid=mode == "paid", token_path=token_path, supervisor=supervisor)
            common = {"arm": request["arm"], "execution_mode": "native", "native_preflight": proof,
                "execution_profile": public["execution_profile"],
                **({"public_build_inputs": build_fields["public_build_inputs"]} if build_fields else {}),
                **({"public_fixture": fixture} if fixture is not None else {})}
            if selected is None and request["arm"] in ("P", "R"):
                phase_request = {**common, "state": state, "out": str(protocol),
                    "phase_budget_usd": request["allowance_usd"], "cli_cap_usd": request["cli_cap_usd"],
                    "image": public["image"], "public_packet": copy.deepcopy(request["public_packet"]),
                    **{key: copy.deepcopy(public[key]) for key in ("allowed_probe_prefixes",
                        "public_checks", "command_timeout_s", "max_log_bytes")}}
                outcome = run_phase(phase_request, backend)
                state = outcome["state"]
                record["public_artifact"] = outcome.get("public_artifact")
            else:
                _admit_backend(common, backend)
                returned = backend.execute({"arm": request["arm"], "phase": request["phase"],
                    "prompt": request["public_packet"]["issue"], "public_packet": copy.deepcopy(request["public_packet"]),
                    "allowance_usd": request["allowance_usd"], "cli_cap_usd": request["cli_cap_usd"],
                    "max_continuations": bound,
                    **({"feedback_policy": selected, "effort": selected["effort"]} if selected is not None else {})})
        if _runtime(_runtime_inputs(runtime)) != runtime:
            raise ValueError("public runtime changed during invocation")
    except BaseException as exc:
        failure = type(exc).__name__ + ": " + str(exc)

    # Native and adapter receipts survive a boundary exception; read them before classification.
    receipt_faults = []
    native = _host_record(stage/"native-executor.json", receipt_faults)
    if native is None:
        native = returned
    receipt = _host_record(stage/"receipt.json", receipt_faults)
    if receipt_faults:
        failure = "; ".join(([failure] if failure else []) + receipt_faults)
    started = (stage/"started.json").is_file()
    record["actor_started"] = started
    if isinstance(receipt, dict):
        record["workflow_completed"] = receipt.get("workflow_completed") is True
        record["public_verification"] = copy.deepcopy(receipt.get("public_verification"))
        record["lifecycle"] = copy.deepcopy(receipt.get("lifecycle"))
        record["cost_usd"], record["cost_is_final"] = receipt.get("cost_usd"), receipt.get("unknown_provider_cost") is False
    elif isinstance(native, dict):
        record["cost_usd"], record["cost_is_final"] = native.get("cost_usd"), native.get("cost_is_final") is True
    elif not started:
        record["cost_usd"], record["cost_is_final"] = "0", True
    if isinstance(native, dict):
        record.update({key: native.get(key) is True for key in
                       ("context_valid", "capture_complete", "cleanup_complete")})
        record["turns"] = native.get("turns")
    relay_cleanup = stage / "embedding/cleanup.json"
    cleanup_faults = []
    cleanup_record = _host_record(relay_cleanup, cleanup_faults)
    relay_ok = isinstance(cleanup_record, dict) and cleanup_record.get("complete") is True
    if cleanup_faults:
        failure = "; ".join(([failure] if failure else []) + cleanup_faults)
    record["cleanup_complete"] = record["cleanup_complete"] and relay_ok
    candidate = protocol/"candidate" if (protocol/"candidate").is_dir() else captured
    if not candidate.is_dir():
        if started:
            record["capture_complete"] = False
            failure = failure or "post-actor source capture missing"
        candidate = out/"preparation-source"
        _capture(source, candidate, dependency_dirs=(public["public_build_inputs"]["dependency_dirs"]
                     if public.get("public_build_inputs") is not None else []),
                 preserve_project_context=public.get("public_build_inputs") is not None)
    record["candidate"], record["source_digest"] = str(candidate), input_digest(candidate)
    if outcome is not None:
        state = copy.deepcopy(outcome["state"])
    else:
        state = copy.deepcopy(request["state"])
        turns = record["turns"]
        state["turns_used"] = state.get("turns_used", 0) + (turns if type(turns) is int else 0)
        state.update(phase="closed" if receipt and receipt.get("workflow_completed") is True and not failure else "incomplete",
                     source_digest=record["source_digest"])
    record["state"] = state
    record["measurement_invalid"] = (failure is not None or
        not all(record[key] is True for key in ("context_valid", "capture_complete", "cleanup_complete", "cost_is_final")) or
        bool(outcome and outcome.get("measurement_invalid")))
    record["reason"] = failure or (outcome.get("reason") if outcome else None)
    publish_exclusive(out/"invocation.json", record)
    return record
