"""Transport checks; real Docker qualification remains a separate control."""
from pathlib import Path
import importlib
import json
import subprocess
import tempfile
import unittest


class TrustedInputTransportTests(unittest.TestCase):
    def setUp(self):
        self.api = importlib.import_module("feedback_trusted_inputs")
        self.core = importlib.import_module("trusted_test_inputs")
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        source = root / "source"
        (source / "tests").mkdir(parents=True)
        (source / "tests/expected.snap").write_text("canonical")
        self.descriptor = self.core.seal_test_inputs(source, ["tests"], root / "sealed")
        self.cid = "a" * 64
        self.calls = []

    def docker(self, *args, **kwargs):
        self.calls.append(args)
        if args[:3] == ("exec", self.cid, "mktemp"):
            value = "/tmp/effort-trusted-AbCd1234\n"
        elif args[0] == "cp":
            value = ""
        else:
            value = json.dumps({"complete": True, "manifest_sha256": self.descriptor["manifest_sha256"]})
        return subprocess.CompletedProcess(args, 0, value, None)

    def test_copies_exact_inputs_and_helper_to_immutable_container_then_verifies(self):
        installed = self.api.install_inputs(self.docker, self.cid, self.descriptor)
        self.assertTrue(installed["restoration"]["complete"])
        self.assertEqual(installed["container"], self.cid)
        self.assertEqual(installed["descriptor"]["manifest_sha256"], self.descriptor["manifest_sha256"])
        copies = [call for call in self.calls if call[0] == "cp"]
        self.assertEqual(len(copies), 3)
        self.assertEqual({Path(call[1]).name for call in copies},
                         {"manifest.json", "inputs.tar", "trusted_test_inputs.py"})
        self.assertTrue(all(call[2].startswith(self.cid + ":/tmp/effort-trusted-") for call in copies))
        self.assertTrue(self.api.verify_inputs(self.docker, installed)["complete"])
        self.assertIn("verify_test_inputs", self.calls[-1][self.calls[-1].index("-c") + 1])
        self.assertNotIn("restore_test_inputs", self.calls[-1][self.calls[-1].index("-c") + 1])

    def test_drift_is_rejected_before_any_container_operation(self):
        Path(self.descriptor["archive"]).write_bytes(b"changed")
        with self.assertRaises(ValueError):
            self.api.install_inputs(self.docker, self.cid, self.descriptor)
        self.assertEqual(self.calls, [])

    def test_bad_container_or_unexpected_temporary_path_is_rejected(self):
        for cid in ["", "named-container", "a"*63, "g"*64]:
            with self.subTest(cid=cid), self.assertRaises(ValueError):
                self.api.install_inputs(self.docker, cid, self.descriptor)
        def bad(*args, **kwargs):
            return subprocess.CompletedProcess(args, 0, "/testbed/tests/escape\n", None)
        with self.assertRaises(ValueError):
            self.api.install_inputs(bad, self.cid, self.descriptor)

    def test_failed_copy_cannot_be_reported_as_complete(self):
        def fail(*args, **kwargs):
            if args[0] == "cp":
                return subprocess.CompletedProcess(args, 1, "copy failed", None)
            return self.docker(*args, **kwargs)
        with self.assertRaises(ValueError):
            self.api.install_inputs(fail, self.cid, self.descriptor)

    def test_changed_or_incomplete_remote_receipt_is_rejected(self):
        for receipt in [{"complete": False}, {"complete": True, "manifest_sha256": "f"*64}]:
            def bad(*args, **kwargs):
                if args[:3] == ("exec", self.cid, "python3"):
                    return subprocess.CompletedProcess(args, 0, json.dumps(receipt), None)
                return self.docker(*args, **kwargs)
            with self.subTest(receipt=receipt), self.assertRaises(ValueError):
                self.api.install_inputs(bad, self.cid, self.descriptor)
