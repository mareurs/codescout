"""Actual CLI/MCP three-phase qualification with a zero-provider transport.

This is a synthetic runtime control, not a repair-quality experiment. All native
paths/images are explicit, existing inputs. No credential, pull or onboarding call.
"""
import hashlib
import json
import os
import select
import shutil
import subprocess
import time
import uuid
from pathlib import Path
from unittest.mock import patch

from adapter import run_phase
from native_executor import NativeExecutor, TOOL_ROLES, external, _public_digest
from readiness import validate_readiness
from receipts import input_digest, publish_exclusive


def _save(path, value):
    publish_exclusive(path, value)


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _docker(*args, timeout=60):
    return subprocess.run(["docker", *args], capture_output=True, text=True, timeout=timeout, check=True)


def _native_argv(actor, home, cfg):
    (Path(home) / ".cache/codescout/fastembed").mkdir(parents=True, exist_ok=True)
    manifest = json.loads(Path(cfg["runtime_manifest"]).read_text())
    args = ["docker", "run", "--pull", "never", "--init", "-i", "--network", "none",
            "--user", "1000:1000", "--cpus", "4", "--memory", "32g", "--memory-swap", "32g",
            "--pids-limit", "4096", "--tmpfs", "/tmp:rw,exec,size=4g,uid=1000,gid=1000",
            "--name", "placeholder", "--label", "codescout.hfa=placeholder",
            "--entrypoint", "/bench/bin/codescout", "--workdir", "/testbed"]
    expected = {"/bench/bin", "/bench/lsp", "/bench/runtime", "/bench-home/.cache/codescout/fastembed"}
    found = set()
    for mount in manifest["Mounts"]:
        if mount["Destination"] in expected:
            if not Path(mount["Source"]).is_dir():
                raise ValueError("frozen runtime mount unavailable")
            args += ["--mount", "type=bind,src=" + mount["Source"] + ",dst=" + mount["Destination"] + ",readonly"]
            found.add(mount["Destination"])
    if found != expected or manifest["Image"] != cfg["native_image"]:
        raise ValueError("frozen runtime manifest mismatch")
    args += ["--mount", f"type=bind,src={actor},dst=/testbed",
             "--mount", f"type=bind,src={home},dst=/bench-home"]
    keys = {"HOME", "USER", "PATH", "CARGO_NET_OFFLINE", "HF_HUB_OFFLINE", "CODESCOUT_DISABLE_SPARSE",
            "FASTEMBED_CACHE_PATH", "CODESCOUT_VECTOR_BACKEND", "CODESCOUT_ARTIFACT_BACKEND",
            "CODESCOUT_SQLITE_DIR", "MCP_PROTOCOL_NEGOTIATION",
            "CODESCOUT_EMBED_MODEL", "CODESCOUT_EMBED_URL"}
    for value in manifest["Config"]["Env"]:
        if value.split("=")[0] in keys:
            args += ["-e", value]
    return args + [cfg["native_image"], "start", "--project", "/testbed"]


def _readiness(out, argv, actor, public_source, cfg):
    """Measure each prepared clone in the exact image before starting its actor."""
    build_cfg = {**cfg, "image": cfg["native_image"]}
    build_options = {"--mount": [argv[i+1] for i, value in enumerate(argv[:-4]) if value == "--mount"]}
    build_contract = external.public_build_contract(build_cfg, build_options, actor)
    dependency_dirs = cfg["public_build_inputs"]["dependency_dirs"] if build_contract is not None else []
    warmup_limit = cfg.get("lsp_warmup_retries", 0)
    if type(warmup_limit) is not int or warmup_limit not in (0, 1):
        raise ValueError("native startup retry bound must be integer zero or one")
    registered_keys = {"registered_readiness", "knowledge_paths", "knowledge_sha256",
                       "baseline_commit", "index_update_required"}
    registered = None
    if registered_keys.intersection(cfg) or "source_baseline_sha256" in cfg:
        if not registered_keys <= set(cfg) or type(cfg["index_update_required"]) is not bool:
            raise ValueError("incomplete registered readiness contract")
        registered = cfg["registered_readiness"]
        if (not isinstance(registered, dict) or
                not {"project_root", "languages", "tools", "probes"} <= set(registered) or
                    not set(registered) <= {"project_root", "languages", "tools", "probes", "index_omission_policy"} or
                input_digest(actor / ".codescout", cfg["knowledge_paths"]) != cfg["knowledge_sha256"]):
            raise ValueError("registered public readiness or static knowledge changed")
        if input_digest(public_source) != _public_digest(actor, dependency_dirs=dependency_dirs, preserve_project_context=build_contract is not None):
            raise ValueError("prepared public source differs from registered input")
    name = "ep-ready-" + uuid.uuid4().hex
    argv = list(argv)
    argv[argv.index("--name") + 1] = name
    argv[argv.index("--label") + 1] = "codescout.hfa=" + name
    raw = b""
    calls = []
    cid = None
    stderr = (out / "readiness.stderr").open("xb")
    proc = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr)
    def rpc(method, params, number):
        nonlocal raw
        proc.stdin.write((json.dumps({"jsonrpc": "2.0", "id": number, "method": method, "params": params}) + "\n").encode())
        proc.stdin.flush()
        deadline = time.monotonic() + 120
        while time.monotonic() < deadline:
            while b"\n" in raw:
                line, raw = raw.split(b"\n", 1)
                if line.strip():
                    result = json.loads(line)
                    if result.get("id") == number:
                        calls.append({"method": method, "params": params, "response": result})
                        return result
            ready, _, _ = select.select([proc.stdout], [], [], max(0, deadline-time.monotonic()))
            if ready:
                chunk = os.read(proc.stdout.fileno(), 65536)
                if not chunk:
                    raise ValueError("native readiness EOF")
                raw += chunk
        raise TimeoutError("native readiness " + method)
    try:
        rpc("initialize", {"protocolVersion": "2025-06-18", "capabilities": {},
            "clientInfo": {"name": "effort-protocol-qualification", "version": "1"}}, 1)
        proc.stdin.write(b'{"jsonrpc":"2.0","method":"notifications/initialized"}\n')
        proc.stdin.flush()
        row = json.loads(_docker("inspect", name).stdout)[0]
        cid = row["Id"]
        if row["Image"] != cfg["native_image"] or row["Config"]["Labels"].get("codescout.hfa") != name:
            raise ValueError("readiness worker identity mismatch")
        if build_contract is not None:
            _save(out / "public-build-runtime-raw.json", row)
            observed_build = external.public_build_runtime(build_cfg, row, actor)
            _save(out / "public-build-runtime.json", {"binding": observed_build,
                  "scope": "Live mount/seed contract only; generated outputs inventory requires closed writers."})
        update = cfg["index_update_required"] if registered is not None else True
        if update:
            indexed = _docker("exec", cid, "/bench/bin/codescout", "index", "-p", "/testbed", timeout=1800)
            (out / "index.stdout").write_text(indexed.stdout)
            (out / "index.stderr").write_text(indexed.stderr)
            _save(out / "index-result.json", {"actual_index_calls": 1, "exit_code": indexed.returncode})
            if indexed.returncode != 0:
                raise ValueError("native index update failed")
        else:
            _save(out / "index-reused.json", {"actual_index_calls": 0})
        if registered is not None:
            indexed_state = json.loads((actor / ".codescout/index-state.json").read_bytes())
            if indexed_state.get("last_indexed_commit") != cfg["baseline_commit"]:
                raise ValueError("native index does not bind the prepared public Git head")
            _save(out / "index-commit-binding.json", {
                "last_indexed_commit": indexed_state["last_indexed_commit"],
                "source_head": cfg["baseline_commit"]})
        number = 2
        pages = []
        cursor = None
        while True:
            page = rpc("tools/list", {"cursor": cursor} if cursor else {}, number)
            number += 1
            page["cursor"] = cursor
            pages.append(page)
            cursor = page["result"].get("nextCursor")
            if not cursor:
                break
        def tool(name, args):
            nonlocal number
            result = rpc("tools/call", {"name": name, "arguments": args}, number)
            number += 1
            return result
        status = tool("workspace", {"action": "status"})
        specs = [
            {"tool": "references", "arguments": {"path": "src/lib.rs", "symbol": "double"},
             "must_contain": ["src/lib.rs", "use_double"]},
            {"tool": "symbol_at", "arguments": {"path": "src/lib.rs", "line": 2, "col": 34},
             "must_contain": ["pub fn double"]},
            {"tool": "call_graph", "arguments": {"path": "src/lib.rs", "symbol": "double", "direction": "callers"},
             "must_contain": ["use_double", "lsp"]},
            {"tool": "semantic_search", "arguments": {"query": "double the input value", "limit": 3},
             "must_contain": ["src/lib.rs", "double"]}]
        if registered is not None:
            specs = registered["probes"]
        observations, warmups = [], []
        def startup_timeout(spec, response):
            if spec["tool"] not in ("references", "symbol_at", "call_graph"):
                return False
            try:
                payload = json.loads(response["result"]["content"][0]["text"])
                return (isinstance(payload, dict) and payload.get("ok") is False and
                        isinstance(payload.get("error"), str) and
                        payload["error"].startswith("LSP request timed out after 30s:"))
            except (KeyError, IndexError, TypeError, ValueError):
                return False
        for spec in specs:
            response = tool(spec["tool"], spec["arguments"])
            if len(warmups) < warmup_limit and startup_timeout(spec, response):
                entry = {"tool": spec["tool"], "arguments": spec["arguments"],
                         "prior_response": response, "retry_response": None,
                         "reason": "registered max-one model-free LSP startup timeout retry"}
                warmups.append(entry)
                _save(out / "readiness-warmup-started.json", warmups)
                response = tool(spec["tool"], spec["arguments"])
                entry["retry_response"] = response
            observations.append({"tool": spec["tool"], "arguments": spec["arguments"], "response": response})
        _save(out / "readiness-warmup-retries.json", warmups)
        binding = {"image": cfg["native_image"], "executable_sha256": _docker(
            "exec", cid, "sha256sum", "/bench/bin/codescout").stdout.split()[0],
            "source_snapshot_sha256": input_digest(public_source),
            "knowledge_sha256": input_digest(actor / ".codescout",
                cfg["knowledge_paths"] if registered is not None else ["project.toml", "system-prompt.md"])}
        if build_contract is not None:
            binding["public_build_inputs_sha256"] = build_contract["fingerprint"]
        if "public_fixture" in cfg:
            binding["public_fixture_sha256"] = cfg["public_fixture"]["fingerprint"]
        expected = {"project_root": "/testbed", "languages": ["rust"],
            "tools": ["symbols", "references", "symbol_at", "call_graph", "semantic_search"],
            "binding": binding, "probes": specs}
        if registered is not None:
            expected = {**registered, "binding": binding}
        if build_contract is not None:
            expected["public_build_inputs"] = cfg["public_build_inputs"]
        if "source_baseline_sha256" in cfg:
            expected["source_baseline_sha256"] = cfg["source_baseline_sha256"]
        wire = {"binding": binding, "status": status, "tool_pages": pages, "probes": observations,
                "index_verification": tool("index", {"action": "verify"})}
        result = validate_readiness(expected, wire, source=actor)
        if registered is not None and binding["knowledge_sha256"] != cfg["knowledge_sha256"]:
            raise ValueError("static onboarding changed during native readiness")
        _save(out / "readiness.json", {"expected": expected, "wire": wire, "result": result})
        return {"expected": expected, "wire": wire}
    finally:
        errors = []
        try:
            proc.stdin.close()
        except Exception as exc:
            errors.append(exc)
        try:
            try:
                proc.wait(timeout=15)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=15)
        except Exception as exc:
            errors.append(exc)
        try:
            proc.stdout.close()
        except Exception as exc:
            errors.append(exc)
        try:
            stderr.close()
        except Exception as exc:
            errors.append(exc)
        cleanup = {"name": name, "absent": False}
        try:
            inspected = subprocess.run(["docker", "inspect", name], capture_output=True, text=True, timeout=10)
            if inspected.returncode == 0:
                row = json.loads(inspected.stdout)[0]
                if row["Image"] != cfg["native_image"] or row["Config"]["Labels"].get("codescout.hfa") != name:
                    raise ValueError("cleanup identity mismatch")
                _docker("rm", "-f", row["Id"])
            absent = subprocess.run(["docker", "inspect", name], capture_output=True, text=True, timeout=10)
            cleanup["absent"] = absent.returncode != 0 and "no such" in absent.stderr.lower()
            if not cleanup["absent"]:
                raise ValueError("readiness container removal not confirmed")
        except Exception as exc:
            errors.append(exc)
            cleanup["error"] = type(exc).__name__ + ": " + str(exc)
        # Evidence persistence has no authority to skip independent resource cleanup.
        for path, value in ((out / "readiness-calls.json", calls),
                            (out / "readiness-cleanup.json", cleanup)):
            try:
                _save(path, value)
            except Exception as exc:
                errors.append(exc)
        if errors:
            raise ExceptionGroup("native readiness finalization failed", errors)


def _qualification_plan(plan, arm):
    if arm not in ("P", "R"):
        raise ValueError("unsupported qualification arm")
    if arm == "P":
        return list(plan)
    return [(name, args) for name, args in plan
            if not (name == "mcp__codescout__create_file" and args.get("path") == "submission.json")]

def qualify(out, cfg):
    out = Path(out).resolve()
    if not out.is_relative_to("/tmp"):
        raise ValueError("native qualification requires a scratch path under /tmp")
    out.mkdir(parents=True, exist_ok=False)
    # Reuse source-only preparation; never copy historical task feedback.
    source = out / "baseline"
    source.mkdir()
    knowledge = Path(cfg["knowledge"]).resolve()
    for name in ("src", "Cargo.toml", "CLAUDE.md"):
        src = knowledge / name
        shutil.copytree(src, source / name) if src.is_dir() else shutil.copy2(src, source / name)
    # These deterministic preparation outputs are public execution inputs, not caches.
    (source / ".gitignore").write_text(".codescout/private-memories/\n")
    (source / "Cargo.lock").write_text(
        '# This file is automatically @generated by Cargo.\n'
        '# It is not intended for manual editing.\nversion = 3\n\n'
        '[[package]]\nname = "readiness_fixture"\nversion = "0.1.0"\n')
    (source / "fixed.txt").write_text("0\n")
    (source / "probe.py").write_text(
        "from pathlib import Path\nimport sys\nvalue=Path('fixed.txt').read_text().strip()\n"
        "print('actual fixed value', value, 'case', sys.argv[1])\n"
        "raise SystemExit(0 if sys.argv[1]=='keep' or value=='1' else 1)\n")
    state = {"run_id": "qualification-" + uuid.uuid4().hex, "phase": "investigate",
        "baseline_paths": sorted(p.relative_to(source).as_posix() for p in source.rglob("*")),
        "baseline_digest": input_digest(source), "used_receipts": [], "turns_used": 0}
    input_source = source
    summaries = []
    public_artifacts = []
    system_text = "# Public fixture guidance\nUse the source interfaces and public tests.\n"
    for phase in ("investigate", "repair", "challenge"):
        prepared = out / (phase + "-native")
        prepared.mkdir()
        actor = prepared / "actor"
        shutil.copytree(input_source, actor, symlinks=True)
        knowledge_dst = actor / ".codescout"
        knowledge_dst.mkdir()
        shutil.copy2(knowledge / ".codescout/project.toml", knowledge_dst / "project.toml")
        (knowledge_dst / "system-prompt.md").write_text(system_text)
        # Freeze this fixture's shared guidance, not another study's task memories.
        toml = (knowledge_dst / "project.toml").read_text()
        import re
        toml = re.sub(r'system_prompt_sha256 = "[0-9a-f]+"',
                      'system_prompt_sha256 = "' + _sha(knowledge_dst / "system-prompt.md") + '"', toml)
        (knowledge_dst / "project.toml").write_text(toml)
        # Git metadata is an explicitly excluded tool role, initialized per invocation.
        subprocess.run(["git", "init", "-q"], cwd=actor, check=True)
        subprocess.run(["git", "add", "--", "."], cwd=actor, check=True)
        subprocess.run(["git", "-c", "user.name=Offline fixture", "-c", "user.email=fixture@invalid",
                        "commit", "-qm", "Public phase input"], cwd=actor, check=True)
        baseline = subprocess.run(["git", "rev-parse", "HEAD"], cwd=actor,
                                  capture_output=True, text=True, check=True).stdout.strip()
        home = prepared / "native-home"
        home.mkdir()
        argv = _native_argv(actor, home, cfg)
        native_path = prepared / "mcp-native-argv.json"
        _save(native_path, argv)
        proof = _readiness(prepared, argv, actor, input_source, cfg)
        config = {"actor": str(actor), "image": cfg["native_image"], "baseline_commit": baseline,
            "cli": cfg["cli"], "plugin": cfg["plugin"], "global_rules": cfg["global_rules"],
            "prompt": "public fixture", "checks": [{"id": "fixture-runtime", "command": "test -f fixed.txt"}],
            "timeout_s": 180, "check_timeout_s": 30, "max_continuations": 2,
            "files": {str(p): _sha(p) for p in (native_path, Path(cfg["global_rules"]),
                      Path(cfg["cli"]), actor / "CLAUDE.md")}}
        _save(prepared / "prepared.json", config)
        commands = [{"id": "bug", "argv": ["python3", "-I", "/work/probe.py", "bug"],
                     "cwd": ".", "test_files": ["probe.py"]},
                    {"id": "keep", "argv": ["python3", "-I", "/work/probe.py", "keep"],
                     "cwd": ".", "test_files": ["probe.py"]}]
        submission = {"status": "submitted", "clauses": [
            {"id": "bug", "kind": "requirement", "role": "reproduction", "receipts": ["bug"]},
            {"id": "keep", "kind": "preservation", "role": "legitimate", "receipts": ["keep"]}],
            "commands": commands}
        plan = [("Skill", {"skill": "codescout-companion:reconnaissance"}),
                ("mcp__codescout__read_file", {"path": ".codescout/system-prompt.md", "force": True,
                                             "start_line": 1, "end_line": 30})]
        if phase == "repair":
            plan.append(("mcp__codescout__create_file", {"path": "fixed.txt", "content": "1\n", "overwrite": True}))
        plan.append(("mcp__codescout__create_file", {"path": "submission.json", "content": json.dumps(submission)}))
        executor = NativeExecutor(prepared, out / (phase + "-captured"),
            system_lines=external.worker.visible(system_text), recon_marker="Base directory for this skill:",
            scripted_plan=_qualification_plan(plan, cfg.get("arm", "P")))
        request = {"state": state, "out": str(out / (phase + "-phase")), "arm": cfg.get("arm", "P"),
            "phase_budget_usd": "0.50", "image": cfg["evidence_image"],
            "execution_mode": "native", "native_preflight": proof,
            "public_packet": {"issue": "Set the fixture value to one, preserving its adjacent public behavior.",
                              "prior_public_artifacts": public_artifacts},
            "allowed_probe_prefixes": ["probes/"], "public_checks": [commands[0]],
            "command_timeout_s": 15, "max_log_bytes": 1048576}
        def no_upstream(*args, **kwargs):
            raise AssertionError("provider forwarding is prohibited in offline qualification")
        with patch.object(external.transport.Proxy, "upstream", no_upstream):
            outcome = run_phase(request, executor)
        state = outcome["state"]
        input_source = Path(request["out"]) / "candidate"
        native_result = json.loads((prepared / "native-executor.json").read_text())
        if "public_artifact" in outcome:
            public_artifacts.append(outcome["public_artifact"])
        summaries.append({"phase": phase, "state": state["phase"], "context_valid": native_result["context_valid"],
            "cleanup_complete": native_result["cleanup_complete"], "cost_usd": native_result["cost_usd"],
            "provider_forwarded": native_result["provider_forwarded"]})
        if state["phase"] in ("incomplete", "budget_exhausted"):
            break
    result = {"state": state, "arm": cfg.get("arm", "P"), "native_invocations": len(summaries),
        "provider_forwarded": sum(s["provider_forwarded"] for s in summaries),
        "model_cost_usd": str(sum(__import__("decimal").Decimal(s["cost_usd"]) for s in summaries)),
        "all_context_valid": all(s["context_valid"] for s in summaries),
        "all_cleanup_complete": all(s["cleanup_complete"] for s in summaries),
        "final_source": str(input_source), "phases": summaries, "paid_ready": False,
        "onboarding_author_calls": 0, "scope": "synthetic actual CLI, scripted zero-provider runtime control"}
    _save(out / "qualification.json", result)
    return result
