"""Prepare frozen onboarding and skill inputs before a client's first model request."""
import hashlib
from pathlib import Path
import shutil


def prepare_context(stage, actor, plugin):
    stage,actor,plugin=Path(stage),Path(actor),Path(plugin)
    skill=plugin/"skills/reconnaissance"
    system=actor/".codescout/system-prompt.md"
    if (not skill.is_dir() or not system.is_file()
            or any(path.is_symlink() for root in (skill,system) for path in (root,*root.parents))):
        raise ValueError("physical frozen context inputs required")
    source_files=[path for path in skill.rglob("*") if not path.is_dir()]
    if any(path.is_symlink() or not path.is_file() for path in skill.rglob("*")):
        # Directories are allowed; links and other special nodes are not.
        if any(path.is_symlink() or not(path.is_file() or path.is_dir()) for path in skill.rglob("*")):
            raise ValueError("linked or special skill input refused")
    main=skill/"SKILL.md"
    if not main.is_file() or not main.read_text().strip() or not system.read_text().strip():
        raise ValueError("nonempty onboarding and skill body required")
    before={str(path.relative_to(skill)):hashlib.sha256(path.read_bytes()).hexdigest() for path in source_files}
    target=actor/".codescout/prepared-context/reconnaissance"
    target.parent.mkdir(exist_ok=False)
    shutil.copytree(skill,target)
    for relative,digest in before.items():
        if (hashlib.sha256((skill/relative).read_bytes()).hexdigest()!=digest
                or hashlib.sha256((target/relative).read_bytes()).hexdigest()!=digest):
            raise ValueError("frozen skill changed during context preparation")
    body=("<prepared-context>\n<codescout-onboarding>\n"+system.read_text()+
          "\n</codescout-onboarding>\n<reconnaissance-instructions>\n"
          "Supporting files: .codescout/prepared-context/reconnaissance\n"+
          (target/"SKILL.md").read_text()+
          "\n</reconnaissance-instructions>\n</prepared-context>\n")
    path=stage/"context-preload.txt"
    with path.open("x") as stream: stream.write(body)
    files=[system,path,*[target/relative for relative in before]]
    return {"path":str(path),"system_path":str(system),"skill_path":str(target/"SKILL.md"),
            "files":{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
