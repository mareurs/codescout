"""Explicit JUnit nextest host-only diagnostics; reuse a structural grammar, not a runner identity."""
import copy
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import shlex

PROFILE = "nextest-junit-host-only-v1"
EXPECTED_CASES = {
    "noisy-test-failure": {"valid": True, "pass": False, "kind": "test_failure"},
    "noisy-pass": {"valid": True, "pass": True, "kind": "pass"},
    "compile-failure": {"valid": True, "pass": False, "kind": "compile_failure"},
}


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _runner(command, *, guarded):
    _require(isinstance(command, str) and not any(c in command for c in "\n\r"), "nonliteral nextest command")
    words = shlex.split(command)
    indices = [i for i, word in enumerate(words) if word == "cargo"]
    _require(len(indices) == 1, "unique cargo runner missing")
    index = indices[0]
    start = index + 1
    if start < len(words) and words[start].startswith("+"):
        _require(re.fullmatch(r"\+[A-Za-z0-9_.-]+", words[start]), "nonliteral toolchain")
        start += 1
    _require(words[start:start+2] == ["nextest", "run"], "unsupported runner")
    args = words[start+2:]
    _require(not any(c in word for word in args for c in ";|&$\x60<>\n\r"), "nonliteral runner arguments")
    _require(not any(word == "--" or word in ("--nocapture", "--no-capture") or word.startswith("--message-format")
                     for word in args), "unregistered capture mode")
    if guarded:
        for option in ("--success-output", "--failure-output"):
            _require(args.count(option) == 1 and args.index(option)+1 < len(args)
                     and args[args.index(option)+1] == "never"
                     and not any(word.startswith(option+"=") for word in args), "output suppression missing or ambiguous")
        _require(args.count("--no-fail-fast") == 1, "complete test execution guard missing")
    else:
        _require(not any(word.startswith(("--success-output", "--failure-output")) for word in args),
                 "original output override requires separate registration")
    return words[index:start] + ["nextest", "--version"], words[index:]


def prepare_record(original):
    _require(isinstance(original, dict) and isinstance(original.get("test_cmds"), list)
             and isinstance(original.get("print_cmds"), list)
             and len(original["test_cmds"]) == len(original["print_cmds"]) > 0, "paired literal command/report inventory required")
    prepared = copy.deepcopy(original)
    commands = []
    for command, printed in zip(original["test_cmds"], original["print_cmds"]):
        match = re.fullmatch(r"cd /testbed && rm -rf target/nextest && (?P<env>(?:[A-Z_][A-Z_0-9]*=[A-Za-z0-9_./-]+ )*)(?P<cargo>cargo .+)", command)
        report = re.fullmatch(r"cd /testbed && cat (?P<path>target/nextest/[A-Za-z0-9_.-]+/junit\.xml)", printed)
        _require(match is not None and report is not None, "unregistered nextest/JUnit shell grammar")
        path = report["path"]
        _require(".." not in PurePosixPath(path).parts, "escaping JUnit report")
        _, cargo = _runner(match["cargo"], guarded=False)
        if "--no-fail-fast" not in cargo:
            cargo.append("--no-fail-fast")
        cargo.extend(["--success-output", "never", "--failure-output", "never"])
        environment = match["env"]
        for token in environment.split():
            if token.startswith("INSTA_UPDATE="):
                _require(token in ("INSTA_UPDATE=new", "INSTA_UPDATE=no", "INSTA_UPDATE=auto"), "snapshot auto-accept mode unsupported")
                environment = environment.replace(token+" ", "INSTA_UPDATE=no ")
        commands.append("cd /testbed && rm -rf target/nextest && mkdir -p " +
            str(PurePosixPath(path).parent) + " && printf %s '<testsuites/>' > " + path +
            " && " + environment + shlex.join(cargo))
    prepared["test_cmds"] = commands
    return prepared


def _physical(path):
    value = Path(path)
    _require(value.is_absolute() and value.resolve() == value and value.is_file() and not value.is_symlink(),
             "format proof requires a physical absolute file")
    return value


def _check_proof(spec, record):
    descriptor = spec["compatibility"]
    path = _physical(descriptor["path"])
    _require(hashlib.sha256(path.read_bytes()).hexdigest() == descriptor["sha256"], "format proof bytes changed")
    proof = json.loads(path.read_bytes())
    _require(proof.get("profile") == PROFILE and proof.get("qualified") is True
             and proof.get("runner_version") == spec["runner_version"]
             and proof.get("parser_sha256") == hashlib.sha256(record["log_parser"].encode()).hexdigest()
             and proof.get("cases") == EXPECTED_CASES, "format proof/parser/runner mismatch")
    bindings = proof.get("bindings")
    _require(isinstance(bindings, dict) and bindings, "format proof raw bindings missing")
    for name, digest in bindings.items():
        _require(hashlib.sha256(_physical(name).read_bytes()).hexdigest() == digest, "format proof raw input changed")


def translate_registration(record, registered, streams):
    result = copy.deepcopy(registered)
    _require(len(result["tests"]) == len(record["test_cmds"]), "incomplete nextest profile inventory")
    for command, spec in zip(record["test_cmds"], result["tests"]):
        if spec.get("profile") != PROFILE:
            continue
        _runner(command, guarded=True)
        _require(spec.get("stderr_files") == [], "host-only runner cannot borrow diagnostic artifacts")
        _require(isinstance(spec.get("runner_version"), str)
                 and spec["runner_version"].startswith("cargo-nextest "), "actual runner version missing")
        _check_proof(spec, record)
        reports = spec["reports"]
        spec.clear()
        spec.update({"profile": streams.LIB, "reports": reports, "stderr_files": []})
    return result


def runtime_probes(record, registered):
    probes = []
    for command, spec in zip(record["test_cmds"], registered["tests"]):
        if spec.get("profile") == PROFILE:
            argv, _ = _runner(command, guarded=True)
            item = (argv, spec["runner_version"])
            _require(not any(old[0] == argv and old[1] != item[1] for old in probes), "contradictory runner version bindings")
            if item not in probes:
                probes.append(item)
    return probes


def qualify_registration(record, registered, full, streams):
    translated = translate_registration(record, registered, streams)
    for i, spec in enumerate(registered["tests"]):
        if spec.get("profile") != PROFILE:
            continue
        matches = [step for step in full["steps"] if step["name"] == "grade:test["+str(i)+"]"]
        _require(len(matches) == 1, "missing unique host-only nextest step")
        stdout, _ = streams.capture.read_streams(matches[0]["capture"])
        _require(stdout == b"", "host-only nextest has unexpected stdout")
    return translated
