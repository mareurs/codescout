"""Prospective contract tests; no model calls or repository outcomes."""
import copy
import unittest

try:
    import feedback_policy as policy
except ModuleNotFoundError:
    policy = None


class FeedbackPolicyTests(unittest.TestCase):
    def require_policy(self):
        self.assertIsNotNone(policy, "repair-only feedback policy is not implemented")
        return policy

    def test_dispatch_separates_offered_plan_from_enforced_targets(self):
        p = self.require_policy()
        values = {arm: p.condition_spec(arm, "rust") for arm in "LRPX"}
        self.assertEqual(values["L"]["check"], {
            "argv": ["cargo", "check", "--offline", "--workspace"], "cwd": "rust"})
        self.assertEqual(values["R"]["check"], values["L"]["check"])
        self.assertEqual(values["P"]["check"], {
            "argv": ["cargo", "check", "--offline", "--workspace", "--all-targets"], "cwd": "rust"})
        self.assertEqual(values["X"]["check"], values["P"]["check"])
        self.assertEqual(values["L"]["plan_instruction"], "")
        self.assertTrue(values["R"]["plan_instruction"])
        self.assertEqual(values["R"]["plan_instruction"], values["P"]["plan_instruction"])
        self.assertEqual(values["X"]["plan_instruction"], values["P"]["plan_instruction"])
        for arm, value in values.items():
            self.assertEqual(value["schema"], "native-public-feedback-v1")
            self.assertEqual(value["phase"], "repair")
            self.assertEqual(value["max_continuations"], 4)
            self.assertEqual(value["effort"], "xhigh" if arm == "X" else "low")
            self.assertEqual(value["cli_cap_usd"], "5.50" if arm == "X" else "2.75")
            self.assertEqual(value["reserve_usd"], "9" if arm == "X" else "6")
            self.assertTrue(value["common_instruction"])
        self.assertEqual(len({v["common_instruction"] for v in values.values()}), 1)

    def test_returned_descriptors_do_not_mutate_future_policy(self):
        p = self.require_policy()
        value = p.condition_spec("P", ".")
        value["check"]["argv"].clear()
        value["phase"] = "challenge"
        self.assertEqual(p.condition_spec("P", ".")["check"]["argv"],
                         ["cargo", "check", "--offline", "--workspace", "--all-targets"])
        self.assertEqual(p.condition_spec("P", ".")["phase"], "repair")

    def test_bad_workspace_or_arm_is_not_dispatchable(self):
        p = self.require_policy()
        for arm, cwd in [("A", "."), (None, "."), ("P", ""), ("P", "/testbed"),
                         ("P", "../rust"), ("P", "rust/../other"), ("P", "a//b"),
                         ("P", "a\\b"), ("P", "a\nb"), ("P", None)]:
            with self.subTest(arm=arm, cwd=cwd), self.assertRaises(ValueError):
                p.condition_spec(arm, cwd)

    def test_schedule_covers_every_condition_once_per_task_and_position(self):
        p = self.require_policy()
        tasks = ["a__repo-1", "b__repo-2", "c__repo-3", "d__repo-4"]
        schedule = p.balanced_schedule(tasks, 101)
        self.assertEqual(schedule, p.balanced_schedule(tasks, 101))
        self.assertEqual([r["attempt_index"] for r in schedule], list(range(16)))
        self.assertEqual({(r["task_id"], r["arm"]) for r in schedule},
                         {(task, arm) for task in tasks for arm in "LRPX"})
        for pos in range(4):
            self.assertEqual({schedule[i * 4 + pos]["arm"] for i in range(4)}, set("LRPX"))
        self.assertNotEqual(schedule, p.balanced_schedule(tasks, 102))
        self.assertEqual(tasks, ["a__repo-1", "b__repo-2", "c__repo-3", "d__repo-4"])

    def test_schedule_rejects_missing_duplicate_and_bad_seed(self):
        p = self.require_policy()
        for tasks, seed in [(["a"] * 4, 1), (["a", "b", "c"], 1),
                            (["a", "b", "c", ""], 1), (["a", "b", "c", None], 1),
                            (["a", "b", "c", "d"], True), (["a", "b", "c", "d"], -1)]:
            with self.subTest(tasks=tasks, seed=seed), self.assertRaises(ValueError):
                p.balanced_schedule(tasks, seed)

    def rows(self):
        rows = []
        for task in range(4):
            for arm, accepted, cost in [
                ("L", task == 0, "0.1"), ("R", task < 2, "0.2"),
                ("P", task < 3, "0.3"), ("X", task < 2, "0.4")]:
                rows.append({"task_id": str(task), "arm": arm, "accepted": accepted,
                             "workflow_completed": True, "measurement_invalid": False,
                             "cost_usd": cost})
        return rows

    def test_selects_cheapest_eligible_candidate_and_emits_paired_counts(self):
        p = self.require_policy()
        result = p.development_screen(self.rows())
        self.assertEqual(result["selected"], "R")
        self.assertEqual(result["totals"]["L"]["client_cost_usd"], "0.4")
        self.assertEqual(result["totals"]["R"]["accepted"], 2)
        self.assertEqual(result["pairs"]["R-L"], {"wins": 1, "losses": 0, "ties": 3})
        self.assertEqual(result["pairs"]["P-L"], {"wins": 2, "losses": 0, "ties": 2})
        self.assertEqual(result["pairs"]["P-R"], {"wins": 1, "losses": 0, "ties": 3})
        self.assertEqual(result["pairs"]["R-X"], {"wins": 0, "losses": 0, "ties": 4})
        self.assertEqual(result["pairs"]["P-X"], {"wins": 1, "losses": 0, "ties": 3})
        self.assertFalse(result["goal_achieved"])

    def test_equal_candidate_cost_selects_simpler_R(self):
        p = self.require_policy()
        rows = self.rows()
        for row in rows:
            if row["arm"] == "P":
                row["cost_usd"] = "0.2"
        self.assertEqual(p.development_screen(rows)["selected"], "R")

    def test_sole_eligible_P_wins_when_R_has_no_gain(self):
        p = self.require_policy()
        rows = self.rows()
        for row in rows:
            if row["arm"] == "R":
                row["accepted"] = row["task_id"] == "0"
        self.assertEqual(p.development_screen(rows)["selected"], "P")

    def test_incomplete_candidate_cannot_qualify_but_cost_is_retained(self):
        p = self.require_policy()
        rows = self.rows()
        for row in rows:
            if row["arm"] in "RP":
                row["workflow_completed"] = False
        result = p.development_screen(rows)
        self.assertIsNone(result["selected"])
        self.assertEqual(result["decision"], "NO-GO")
        self.assertEqual(result["totals"]["P"]["client_cost_usd"], "1.2")
        self.assertEqual(result["pairs"]["P-L"]["wins"], 2)

    def test_gain_with_loss_is_ineligible_even_if_accepted_count_is_higher(self):
        p = self.require_policy()
        rows = self.rows()
        for row in rows:
            if row["arm"] in "RP":
                row["accepted"] = row["task_id"] != "0"
        self.assertIsNone(p.development_screen(rows)["selected"])

    def test_equal_or_higher_cost_than_X_is_not_cheaper(self):
        p = self.require_policy()
        for cost in ["0.4", "0.5"]:
            rows = self.rows()
            for row in rows:
                if row["arm"] in "RP":
                    row["cost_usd"] = cost
            with self.subTest(cost=cost):
                self.assertIsNone(p.development_screen(rows)["selected"])

    def test_fewer_acceptances_than_X_is_not_eligible(self):
        p = self.require_policy()
        rows = self.rows()
        for row in rows:
            if row["arm"] == "X":
                row["accepted"] = True
        self.assertIsNone(p.development_screen(rows)["selected"])

    def test_any_invalid_measurement_or_unknown_cost_prevents_selection(self):
        p = self.require_policy()
        for change in [{"measurement_invalid": True}, {"cost_usd": None}]:
            rows = self.rows()
            rows[-1].update(change)
            with self.subTest(change=change):
                result = p.development_screen(rows)
                self.assertIsNone(result["selected"])
                self.assertFalse(result["interpretable"])
                self.assertEqual(result["pairs"]["P-L"]["wins"], 2)

    def test_missing_or_duplicated_attempt_cannot_be_silently_dropped(self):
        p = self.require_policy()
        rows = self.rows()
        self.assertFalse(p.development_screen(rows[:-1])["interpretable"])
        with self.assertRaises(ValueError):
            p.development_screen(rows[:-1] + [copy.deepcopy(rows[0])])

    def test_malformed_fields_and_nonfinite_money_are_rejected(self):
        p = self.require_policy()
        for change in [{"accepted": 1}, {"workflow_completed": "yes"}, {"measurement_invalid": 0},
                       {"arm": "a"}, {"cost_usd": "-1"}, {"cost_usd": "NaN"},
                       {"cost_usd": "Infinity"}, {"cost_usd": True}, {"task_id": None}]:
            rows = self.rows()
            rows[0].update(change)
            with self.subTest(change=change), self.assertRaises(ValueError):
                p.development_screen(rows)

    def test_decimal_comparison_does_not_round_a_real_cost_advantage(self):
        p = self.require_policy()
        rows = self.rows()
        for row in rows:
            if row["arm"] == "R":
                row["cost_usd"] = "0.39999999999999999999999999999999999999"
            if row["arm"] == "P":
                row["cost_usd"] = "0.5"
        self.assertEqual(p.development_screen(rows)["selected"], "R")

    def test_ungraded_invalid_slot_is_unknown_and_never_a_quality_loss(self):
        p = self.require_policy()
        rows = self.rows()
        rows[-1].update(accepted=None, measurement_invalid=True, cost_usd=None)
        result = p.development_screen(rows)
        self.assertFalse(result["interpretable"])
        self.assertIsNone(result["selected"])
        self.assertEqual(result["pairs"]["P-X"], {"wins": 1, "losses": 0, "ties": 2})
        self.assertEqual(result["paired_observations"]["P-X"], 3)
        self.assertEqual(result["totals"]["X"]["graded"], 3)
        self.assertEqual(result["totals"]["X"]["valid_observed"], 3)
        self.assertIsNone(result["totals"]["X"]["client_cost_usd"])

    def test_invalid_grade_is_retained_but_excluded_from_valid_paired_quality(self):
        p = self.require_policy()
        rows = self.rows()
        rows[1]["measurement_invalid"] = True
        result = p.development_screen(rows)
        self.assertEqual(result["totals"]["R"]["client_cost_usd"], "0.8")
        self.assertEqual(result["totals"]["R"]["raw_accepted"], 2)
        self.assertEqual(result["totals"]["R"]["accepted"], 1)
        self.assertEqual(result["paired_observations"]["R-L"], 3)
        self.assertEqual(result["pairs"]["R-L"], {"wins": 1, "losses": 0, "ties": 2})
        self.assertIsNone(result["selected"])

    def test_missing_acceptance_without_explicit_invalidity_is_rejected(self):
        p = self.require_policy()
        rows = self.rows()
        rows[0]["accepted"] = None
        with self.assertRaises(ValueError):
            p.development_screen(rows)


if __name__ == "__main__":
    unittest.main()
