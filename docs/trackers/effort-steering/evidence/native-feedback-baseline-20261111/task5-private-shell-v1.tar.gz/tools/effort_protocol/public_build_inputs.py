"""Controller-owned public dependency state and generated evidence inventories.

Standard library only: safe to load from a frozen lifecycle helper path.
Generated inventory hashes link text without following it. Source receipts retain
their separate, stricter escaping-link rejection policy.
"""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat


def _fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _metadata(value):
    return (value.st_dev, value.st_ino, value.st_mode, value.st_size,
            value.st_mtime_ns, value.st_ctime_ns)


def _physical_directory(path):
    root = Path(path)
    try:
        if root.is_symlink() or not root.is_dir() or root.absolute() != root.resolve(strict=True):
            raise ValueError("generated root must be a physical directory")
    except OSError as exc:
        raise ValueError("generated root unavailable") from exc
    return root


def generated_inventory(root: Path) -> dict:
    """Inventory every entry, including empty directories and opaque link text."""
    root = _physical_directory(root)
    entries = {}

    def visit(directory):
        before_directory = directory.lstat()
        with os.scandir(directory) as scan:
            children = sorted((Path(entry.path) for entry in scan), key=lambda value: value.name)
        for path in children:
            relative = path.relative_to(root).as_posix()
            before = path.lstat()
            mode = stat.S_IMODE(before.st_mode)
            if stat.S_ISLNK(before.st_mode):
                entries[relative] = {"kind": "link", "mode": mode, "target": os.readlink(path)}
            elif stat.S_ISREG(before.st_mode):
                descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
                with os.fdopen(descriptor, "rb") as stream:
                    opened = os.fstat(stream.fileno())
                    if _metadata(opened) != _metadata(before):
                        raise ValueError("generated file changed before reading")
                    digest = hashlib.sha256()
                    while chunk := stream.read(1024 * 1024):
                        digest.update(chunk)
                    if _metadata(os.fstat(stream.fileno())) != _metadata(before):
                        raise ValueError("generated file changed while reading")
                entries[relative] = {"kind": "file", "mode": mode, "sha256": digest.hexdigest()}
            elif stat.S_ISDIR(before.st_mode):
                entries[relative] = {"kind": "directory", "mode": mode}
                visit(path)
            else:
                raise ValueError("unsupported generated artifact entry")
            if _metadata(path.lstat()) != _metadata(before):
                raise ValueError("generated entry changed while inventorying")
        if _metadata(directory.lstat()) != _metadata(before_directory):
            raise ValueError("generated directory changed while inventorying")

    try:
        visit(root)
    except OSError as exc:
        raise ValueError("generated artifacts unavailable or changed") from exc
    return entries


def generated_digest(root: Path) -> str:
    """Canonical inventory digest; equal to strict source digest on link-free overlap."""
    return _fingerprint(generated_inventory(root))


def _check(condition, message):
    if not condition:
        raise ValueError("public build inputs: " + message)


def _relative_name(value):
    _check(type(value) is str and value and not any(c in value for c in (",", "\n", "\r", "\x00")),
           "invalid relative path")
    path = PurePosixPath(value)
    _check(not path.is_absolute() and ".." not in path.parts and path.as_posix() == value
           and value != ".", "invalid relative path")
    return path


def _no_overlap(paths):
    for index, path in enumerate(paths):
        for other in paths[index + 1:]:
            _check(not path.is_relative_to(other) and not other.is_relative_to(path),
                   "overlapping paths")


def dependency_directories(source, names):
    """Admit only empty physical dependency targets, never agent-context metadata."""
    _check(type(names) in (list, tuple), "dependency inventory must be an array")
    if not names:
        return []
    source = _physical_directory(source)
    relative_paths = []
    reserved = {".git", ".codescout", ".claude", ".buddy", ".superpowers", "CLAUDE.md", "AGENTS.md"}
    for name in names:
        relative = _relative_name(name)
        _check(not reserved.intersection(relative.parts), "dependency mount shadows agent context")
        target = _physical_directory(source / relative)
        _check(not any(target.iterdir()), "dependency target is not empty")
        relative_paths.append(relative)
    _no_overlap(relative_paths)
    return relative_paths


def validate_descriptor(raw, source: Path, image: str) -> dict:
    """Validate immutable controller inputs; never create directories or follow seed links."""
    _check(type(raw) is dict and set(raw) ==
           {"schema", "image", "seed", "dependency_dirs", "cache_mounts"}, "descriptor fields differ")
    _check(raw["schema"] == "public-build-inputs-v1", "unknown descriptor schema")
    _check(type(image) is str and image.startswith("sha256:") and len(image) == 71
           and all(c in "0123456789abcdef" for c in image[7:]) and raw["image"] == image,
           "immutable image differs")
    source = _physical_directory(source)
    _check("," not in str(source), "source path cannot be represented as a Docker mount")
    _check(type(raw["dependency_dirs"]) is list and type(raw["cache_mounts"]) is list,
           "mount inventories must be arrays")
    dependency_directories(source, raw["dependency_dirs"])
    seed = raw["seed"]
    if seed is None:
        _check(not raw["cache_mounts"], "cache mounts require an immutable seed")
        seed_root = None
    else:
        _check(type(seed) is dict and set(seed) == {"path", "sha256"}
               and type(seed["path"]) is str and Path(seed["path"]).is_absolute(),
               "seed fields differ")
        seed_root = _physical_directory(seed["path"])
        _no_overlap([source, seed_root])
        _check("," not in str(seed_root), "seed path cannot be represented as a Docker mount")
        _check(generated_digest(seed_root) == seed["sha256"], "immutable seed changed")
        _check(bool(raw["cache_mounts"]), "unused seed is not admitted")
    prefix = PurePosixPath("/bench/public-dependencies")
    destinations, relatives = [], []
    for row in raw["cache_mounts"]:
        _check(type(row) is dict and set(row) == {"seed_relative", "destination"},
               "cache mount fields differ")
        relative = _relative_name(row["seed_relative"])
        _physical_directory(seed_root / relative)
        destination = row["destination"]
        _check(type(destination) is str and not any(c in destination for c in (",", "\n", "\r", "\x00")),
               "invalid cache destination")
        target = PurePosixPath(destination)
        _check(target.is_absolute() and target.as_posix() == destination and ".." not in target.parts
               and target != prefix and target.is_relative_to(prefix), "cache mount shadows protected runtime")
        destinations.append(target)
        relatives.append(relative)
    _no_overlap(destinations)
    _no_overlap(relatives)
    # Round-trip detaches the admitted immutable value from a caller's mutable object.
    descriptor = json.loads(json.dumps(raw))
    return {"descriptor": descriptor, "fingerprint": _fingerprint(descriptor)}


def _staged_mounts(descriptor, output):
    generated = Path(output) / "generated"
    mounts = []
    for index, relative in enumerate(descriptor["dependency_dirs"]):
        mounts.append({"source": str(generated / ("dependency-" + str(index))),
                       "destination": "/testbed/" + relative, "rw": True, "role": "dependency"})
    for index, row in enumerate(descriptor["cache_mounts"]):
        mounts.append({"source": str(generated / ("cache-" + str(index))),
                       "destination": row["destination"], "rw": True, "role": "cache"})
    return mounts


def stage_inputs(raw, source: Path, image: str, output: Path) -> dict:
    """Create one invocation's private writable state; canonical inputs remain untouched."""
    admitted = validate_descriptor(raw, source, image)
    source = _physical_directory(source)
    output = Path(output)
    _check(output.is_absolute() and not output.exists() and not output.is_symlink(),
           "staging output must be fresh and absolute")
    _physical_directory(output.parent)
    _check(output.absolute() == output.parent / output.name and "," not in str(output),
           "invalid staging path")
    seed = admitted["descriptor"]["seed"]
    _no_overlap([source, output] + ([Path(seed["path"])] if seed is not None else []))
    output.mkdir()
    generated = output / "generated"
    generated.mkdir()
    mounts = _staged_mounts(admitted["descriptor"], output)
    for mount in mounts:
        destination = Path(mount["source"])
        if mount["role"] == "dependency":
            destination.mkdir()
        else:
            index = int(destination.name.split("-")[1])
            relative = admitted["descriptor"]["cache_mounts"][index]["seed_relative"]
            shutil.copytree(Path(seed["path"]) / relative, destination, symlinks=True)
    # The seed is reopened after copying; a concurrently changed seed is not a valid stage.
    validate_descriptor(admitted["descriptor"], source, image)
    stage = {"schema": "public-build-stage-v1", **admitted, "source": str(source),
             "image": image, "output": str(output), "mounts": mounts,
             "seed_before_sha256": seed["sha256"] if seed is not None else None,
             "initial_generated_sha256": generated_digest(generated)}
    with (output / "manifest.json").open("x") as stream:
        json.dump(stage, stream, sort_keys=True, indent=2)
    return stage


def verify_staged(stage, source: Path, image: str, *, collect_outputs=True) -> dict:
    """Reopen custody and current generated evidence without requiring outputs to be unchanged."""
    _check(type(collect_outputs) is bool, "generated evidence collection policy must be boolean")
    _check(type(stage) is dict and set(stage) ==
           {"schema", "descriptor", "fingerprint", "source", "image", "output", "mounts",
            "seed_before_sha256", "initial_generated_sha256"}, "stage fields differ")
    _check(stage["schema"] == "public-build-stage-v1", "unknown stage schema")
    source = _physical_directory(source)
    admitted = validate_descriptor(stage["descriptor"], source, image)
    _check(stage["source"] == str(source) and stage["image"] == image
           and stage["fingerprint"] == admitted["fingerprint"], "stage input binding differs")
    output = _physical_directory(stage["output"])
    seed = admitted["descriptor"]["seed"]
    _no_overlap([source, output] + ([Path(seed["path"])] if seed is not None else []))
    _check(set(path.name for path in output.iterdir()) == {"manifest.json", "generated"},
           "unexpected staging artifacts")
    manifest = output / "manifest.json"
    _check(not manifest.is_symlink() and manifest.is_file()
           and json.loads(manifest.read_bytes()) == stage, "staging manifest changed")
    expected = _staged_mounts(admitted["descriptor"], output)
    _check(stage["mounts"] == expected, "staged mounts differ")
    generated = _physical_directory(output / "generated")
    _check(set(path.name for path in generated.iterdir()) ==
           {Path(row["source"]).name for row in expected}, "staged output namespace differs")
    for row in expected:
        _physical_directory(row["source"])
    _check(stage["seed_before_sha256"] == (seed["sha256"] if seed is not None else None),
           "seed binding differs")
    _check(type(stage["initial_generated_sha256"]) is str and len(stage["initial_generated_sha256"]) == 64
           and all(c in "0123456789abcdef" for c in stage["initial_generated_sha256"]),
           "invalid initial generated digest")
    return {"fingerprint": admitted["fingerprint"], "seed_sha256": stage["seed_before_sha256"],
            "generated_sha256": generated_digest(generated) if collect_outputs else None, "mounts": expected}


def _validate_native_mounts(mounts, descriptor, stage, source, image, *, collect_outputs=True):
    admitted = validate_descriptor(descriptor, source, image)
    checked = verify_staged(stage, source, image, collect_outputs=collect_outputs)
    _check(admitted["fingerprint"] == checked["fingerprint"], "native and stage descriptors differ")
    expected = {"/testbed": {"source": str(Path(source)), "rw": True}}
    expected.update({row["destination"]: row for row in checked["mounts"]})
    seen = set()
    observed = {}
    for mount in mounts:
        _check(type(mount) is dict and type(mount.get("destination")) is str,
               "invalid native mount")
        destination = PurePosixPath(mount["destination"])
        _check(destination.is_absolute() and ".." not in destination.parts
               and destination.as_posix() == mount["destination"], "invalid native mount destination")
        _check(str(destination) not in seen, "duplicate native mount destination")
        seen.add(str(destination))
        relevant = (destination.is_relative_to("/testbed")
                    or destination.is_relative_to("/bench/public-dependencies"))
        if relevant:
            _check(str(destination) in expected and mount.get("type") == "bind",
                   "unregistered native dependency/source mount")
            observed[str(destination)] = mount
    _check(set(observed) == set(expected), "native dependency/source mount missing")
    for destination, wanted in expected.items():
        actual = observed[destination]
        _check(actual.get("source") == wanted["source"] and actual.get("rw") is True,
               "native dependency/source mount differs")
    return checked


def validate_native_options(options, descriptor, stage, source, image):
    """Validate declared writable dependencies in a parsed native Docker argv."""
    _check(type(options) is dict and type(options.get("--mount")) is list, "native mount options missing")
    mounts = []
    for text in options["--mount"]:
        _check(type(text) is str, "invalid native mount string")
        attributes = {}
        for part in text.split(","):
            key, equals, value = part.partition("=")
            _check(key in {"type", "src", "dst", "readonly"} and key not in attributes,
                   "unsupported or duplicate native mount attribute")
            if key == "readonly":
                _check(not equals, "readonly mount flag cannot take a value")
                attributes[key] = True
            else:
                _check(equals and value, "native mount attribute value missing")
                attributes[key] = value
        _check({"type", "src", "dst"} <= set(attributes) and attributes["type"] == "bind",
               "native mount must be an explicit bind")
        mounts.append({"type": "bind", "source": attributes["src"], "destination": attributes["dst"],
                       "rw": attributes.get("readonly") is not True})
    return _validate_native_mounts(mounts, descriptor, stage, source, image)


def validate_native_runtime(row, descriptor, stage, source, image):
    """Independently validate the same boundary from actual Docker inspect."""
    _check(type(row) is dict and row.get("Image") == image and type(row.get("Mounts")) is list,
           "native dependency image or mounts differ")
    mounts = [{"type": item.get("Type"), "source": item.get("Source"),
               "destination": item.get("Destination"), "rw": item.get("RW")}
              for item in row["Mounts"]]
    return _validate_native_mounts(mounts, descriptor, stage, source, image, collect_outputs=False)
