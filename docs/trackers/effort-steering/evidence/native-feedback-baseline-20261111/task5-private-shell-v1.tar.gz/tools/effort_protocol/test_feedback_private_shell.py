"""Original command selection/environment survives generic prospective shell preparation."""
import copy,json,os,shlex,stat,subprocess,sys,tempfile,unittest
from pathlib import Path
import feedback_private_commands as subject
class PrivateShellPreparationTests(unittest.TestCase):
    IMAGE="sha256:"+"a"*64
    def record(self,test=None,rebuild=None):
        return {"instance_id":"unrelated-project","FAIL_TO_PASS":["one"],"PASS_TO_PASS":["two"],
            "patch":"opaque implementation","test_patch":"opaque assertions","log_parser":"original parser",
            "print_cmds":["cd /testbed && cat reports/cargo.log"],
            "test_cmds":[test or "cd /testbed && mkdir -p reports && cargo test --workspace --lib --exclude unrelated-cli -- --nocapture 2>&1 | tee reports/cargo.log"],
            "rebuild_cmds":rebuild if rebuild is not None else ["cd /testbed ; apt-get update -qq ; apt-get install -y -qq pkg-config libssl-dev ; cargo check --workspace"]}
    def prepare(self,record,bootstrap=None):
        return subject.prepare_shell_record(record,image=self.IMAGE,bootstrap=bootstrap)
    def test_declared_setup_needs_matching_image_packages_then_keeps_complete_selection(self):
        original=self.record();before=copy.deepcopy(original)
        good={"image":self.IMAGE,"apt_packages":{"pkg-config":"1.0","libssl-dev":"3.0"}}
        for proof in (None,{},dict(good,image="sha256:"+"b"*64),
                      dict(good,apt_packages={"pkg-config":"1.0"}),
                      dict(good,apt_packages={"pkg-config":"","libssl-dev":"3.0"})):
            with self.subTest(proof=proof),self.assertRaises(ValueError):self.prepare(original,proof)
        result=self.prepare(original,good);record=result["record"]
        self.assertEqual(original,before)
        self.assertEqual(record["rebuild_cmds"],["cargo check --workspace",
            "cargo test --workspace --lib --exclude unrelated-cli --no-run"])
        self.assertEqual(record["test_cmds"],[
            "cargo test --no-fail-fast --workspace --lib --exclude unrelated-cli -- --nocapture 2>&1 | tee reports/cargo.log"])
        for key in original.keys()-{"test_cmds","rebuild_cmds"}:self.assertEqual(record[key],original[key])
        self.assertEqual(result["bootstrap"],good)
        self.assertEqual(result["schema"],"source-shell-command-preparation-v1")
    def test_quoted_environment_reaches_both_compile_and_test_without_binary_flags_in_compile(self):
        original=self.record(
            'cd /testbed ; FLAGS="-C linker=clang -C link-arg=--ld-path=/usr/bin/mold" DEBUG=0 cargo test --workspace -- --nocapture --test-threads=1 > test-output.log 2>&1',
            ['cd /testbed && FLAGS="-C linker=clang -C link-arg=--ld-path=/usr/bin/mold" DEBUG=0 cargo build'])
        record=self.prepare(original)["record"]
        rebuilt=[shlex.split(command) for command in record["rebuild_cmds"]]
        self.assertEqual(rebuilt[0],["env","FLAGS=-C linker=clang -C link-arg=--ld-path=/usr/bin/mold","DEBUG=0","cargo","build"])
        self.assertEqual(rebuilt[1],["env","FLAGS=-C linker=clang -C link-arg=--ld-path=/usr/bin/mold","DEBUG=0","cargo","test","--workspace","--no-run"])
        self.assertIn("-- --nocapture --test-threads=1",record["test_cmds"][0])
        self.assertTrue(record["test_cmds"][0].endswith("> test-output.log 2>&1"))
        self.assertIsNone(self.prepare(original)["bootstrap"])
    def test_real_shell_preserves_argv_environment_merged_log_and_nonzero_status(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);binary=root/"bin";binary.mkdir();(root/"reports").mkdir()
            cargo=binary/"cargo"
            cargo.write_text("#!"+sys.executable+"\nimport json,os,sys\nprint(json.dumps({'argv':sys.argv[1:],'flag':os.environ.get('FLAGS')}))\nprint('diagnostic',file=sys.stderr)\nraise SystemExit(23)\n")
            cargo.chmod(0o755)
            environment={**os.environ,"PATH":str(binary)+os.pathsep+os.environ.get("PATH","")}
            for transport in ("2>&1 | tee reports/cargo.log","> reports/cargo.log 2>&1"):
                original=self.record('cd /testbed && FLAGS="a b" cargo test --lib -- --nocapture '+transport,[])
                result=self.prepare(original)["record"]
                run=subprocess.run(["bash","-o","pipefail","-c",result["test_cmds"][0]],
                    cwd=root,env=environment,capture_output=True,text=True)
                self.assertEqual(run.returncode,23)
                lines=(root/"reports/cargo.log").read_text().splitlines()
                actual=next(json.loads(line) for line in lines if line.startswith("{"))
                self.assertEqual(actual,{"argv":["test","--no-fail-fast","--lib","--","--nocapture"],"flag":"a b"})
                self.assertIn("diagnostic",lines)
                compile_run=subprocess.run(["bash","-o","pipefail","-c",result["rebuild_cmds"][-1]],
                    cwd=root,env=environment,capture_output=True,text=True)
                self.assertEqual(compile_run.returncode,23)
                self.assertEqual(json.loads(compile_run.stdout)["argv"],["test","--lib","--no-run"])
    def test_unsupported_shell_cannot_change_meaning_or_escape_report(self):
        commands=("cd /different && cargo test 2>&1 | tee reports/x",
            "cargo test $FILTER 2>&1 | tee reports/x",
            "cargo test; true 2>&1 | tee reports/x",
            "X=1 X=2 cargo test 2>&1 | tee reports/x",
            "cargo test --doc 2>&1 | tee reports/x",
            "cargo test --no-run 2>&1 | tee reports/x",
            "cargo test --message-format=json 2>&1 | tee reports/x",
            "cargo test 2>&1 | tee ../x","cargo test > /tmp/x 2>&1",
            "mkdir -p elsewhere && cargo test 2>&1 | tee reports/x",
            "cargo nextest run 2>&1 | tee reports/x","echo cargo test 2>&1 | tee reports/x",
            "cargo test 2> reports/x")
        for command in commands:
            with self.subTest(command=command),self.assertRaises(ValueError):
                self.prepare(self.record(command,[]))
    def test_no_duplicate_scheduling_flag_and_original_none_stays_none(self):
        record=self.record("cargo test --no-fail-fast --lib 2>&1 | tee reports/x",[])
        record["rebuild_cmds"]=None
        result=self.prepare(record)["record"]
        self.assertIsNone(record["rebuild_cmds"])
        self.assertEqual(result["test_cmds"][0].count("--no-fail-fast"),1)
        self.assertEqual(result["rebuild_cmds"],["cargo test --no-fail-fast --lib --no-run"])
if __name__=="__main__":unittest.main()
