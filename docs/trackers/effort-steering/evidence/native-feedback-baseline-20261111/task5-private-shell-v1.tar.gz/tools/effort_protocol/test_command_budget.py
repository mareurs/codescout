"""Consumer-level budget regression tests; Docker is not needed for fail-before-effect."""
import copy
import json
import math
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parent))
import adapter
import executor
import execution_profiles as profiles
import receipts


class ScriptedActor:
    mode = "scripted"

    def __init__(self, source):
        self.source = source
        self.calls = 0

    def execute(self, request):
        self.calls += 1
        return {"cost_usd":"0.01", "cost_is_final":True, "context_valid":True,
                "cleanup_complete":True, "capture_complete":True, "turns":1,
                "source":str(self.source), "submission":{"status":"incomplete"}}


class CommandBudgetTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root/"source"
        self.source.mkdir()
        (self.source/"probe.py").write_text("print('public')\n")
        self.request = {
            "id":"budget", "run_id":"run", "phase":"investigate", "kind":"observation",
            "image":"sha256:"+"a"*64, "argv":["python3","/testbed/probe.py"],
            "cwd":".", "test_files":["probe.py"], "production_files":["probe.py"],
            "execution_profile":"cargo-v2", "timeout_s":900, "max_log_bytes":1024}

    def validate(self, profile, timeout, limit=1024):
        request={**self.request,"execution_profile":profile,"timeout_s":timeout,"max_log_bytes":limit}
        return executor._request(request,self.source,self.root/"host")

    def phase(self, profile, timeout, limit=1024):
        self.phase_count = getattr(self, "phase_count", 0) + 1
        state={"run_id":"run","phase":"investigate","baseline_paths":["probe.py"],
               "baseline_digest":receipts.input_digest(self.source,["probe.py"]),
               "used_receipts":[],"turns_used":0}
        request={"state":state,"out":str(self.root/("phase-"+str(self.phase_count))),"arm":"R",
                 "execution_mode":"scripted","execution_profile":profile,
                 "phase_budget_usd":"0.10","image":self.request["image"],
                 "public_packet":{"issue":"public issue"},
                 "command_timeout_s":timeout,"max_log_bytes":limit}
        return request,ScriptedActor(self.source)

    def test_new_profile_accepts_observed_cold_build_budget_at_executor_boundary(self):
        try:
            actual=self.validate("cargo-v2",900)
        except executor.ExecutionInvalid as exc:
            self.fail("registered long-command profile rejected: "+str(exc))
        self.assertEqual(actual[3],900)
        self.assertEqual(actual[4],"cargo-v2")

    def test_legacy_profiles_keep_their_exact_receipt_identities_and_boundaries(self):
        for name,digest in [
            ("fixture-v1","bdb14292da261a564d7081dd10504524832e346e79026160c91b517878cc12ab"),
            ("cargo-v1","847ebb408fd0debfc249345cd9a84d146fa53c6eecf8a4e5add1201a3259abb8")]:
            with self.subTest(profile=name):
                self.assertEqual(profiles.profile_digest(name),digest)
                self.assertEqual(self.validate(name,300)[3],300)
                with self.assertRaisesRegex(executor.ExecutionInvalid,"^unsupported_timeout$"):
                    self.validate(name,300.001)

    def test_new_profile_has_same_runtime_resources_and_distinct_budget_identity(self):
        try:
            contract=profiles.runtime_contract("cargo-v2")
        except profiles.ProfileViolation as exc:
            self.fail("missing registered long-command runtime: "+str(exc))
        self.assertEqual(contract,profiles.runtime_contract("cargo-v1"))
        self.assertNotEqual(profiles.profile_digest("cargo-v2"),profiles.profile_digest("cargo-v1"))
        owned=profiles.get_profile("cargo-v2")
        owned["env"]["CARGO_TARGET_DIR"]="/shared"
        self.assertEqual(profiles.get_profile("cargo-v1")["env"]["CARGO_TARGET_DIR"],"/build/target")
        self.assertEqual(profiles.get_profile("cargo-v2")["env"]["CARGO_TARGET_DIR"],"/build/target")

    def test_timeout_refusal_precedes_docker_and_host_output_for_each_profile(self):
        for name,maximum in [("fixture-v1",300),("cargo-v1",300),("cargo-v2",900)]:
            for value in [0,-1,True,False,None,"900",maximum+.001,math.inf,math.nan]:
                with self.subTest(profile=name,timeout=value):
                    request={**self.request,"execution_profile":name,"timeout_s":value}
                    with patch.object(executor,"_docker",side_effect=AssertionError("Docker effect")) as docker:
                        with self.assertRaisesRegex(executor.ExecutionInvalid,"^unsupported_timeout$"):
                            executor.execute_observation(request,self.source,self.root/"host")
                        docker.assert_not_called()
                    self.assertFalse((self.root/"host").exists())

    def test_log_budget_types_and_inclusive_maximum_are_checked_by_executor(self):
        self.assertEqual(self.validate("cargo-v2",1,67108864)[2],67108864)
        for value in [0,-1,True,False,None,"1024",1.0,67108865]:
            with self.subTest(limit=value):
                with self.assertRaisesRegex(executor.ExecutionInvalid,"^unsupported_log_limit$"):
                    self.validate("cargo-v2",1,value)

    def test_invalid_host_time_budget_stops_before_actor_charge_and_phase_directory(self):
        for name,timeout in [("fixture-v1",300.001),("cargo-v1",900),("cargo-v2",900.001),
                             ("cargo-v2",math.nan),("cargo-v2",True)]:
            with self.subTest(profile=name,timeout=timeout):
                request,actor=self.phase(name,timeout)
                try:
                    adapter.run_phase(request,actor)
                except adapter.PhaseInvalid:
                    pass
                self.assertEqual(actor.calls,0,"invalid host budget reached actor.execute")
                self.assertFalse(Path(request["out"]).exists())

    def test_invalid_host_log_budget_stops_before_actor_charge_and_phase_directory(self):
        for value in [0,True,1.0,67108865]:
            with self.subTest(limit=value):
                request,actor=self.phase("cargo-v1",10,value)
                try:
                    adapter.run_phase(request,actor)
                except adapter.PhaseInvalid:
                    pass
                self.assertEqual(actor.calls,0,"invalid host log budget reached actor.execute")
                self.assertFalse(Path(request["out"]).exists())

    def test_registered_long_budget_reaches_scripted_continuation_and_keeps_cost(self):
        request,actor=self.phase("cargo-v2",900)
        try:
            result=adapter.run_phase(request,actor)
        except adapter.PhaseInvalid as exc:
            self.fail("registered long budget did not reach actor: "+str(exc))
        self.assertEqual(actor.calls,1)
        self.assertEqual(result["state"]["phase"],"repair")
        self.assertEqual(result["cost"]["known_usd"],"0.01")
        started=json.loads((Path(request["out"])/"started.json").read_text())
        self.assertEqual(started["execution_profile"],"cargo-v2")
        self.assertEqual(started["execution_profile_sha256"],profiles.profile_digest("cargo-v2"))

    def test_control_without_unused_command_budget_retains_existing_api(self):
        request,actor=self.phase("fixture-v1",10)
        request.pop("command_timeout_s")
        request.pop("max_log_bytes")
        try:
            result=adapter.run_phase(request,actor)
        except adapter.PhaseInvalid as exc:
            self.fail("continuation without evidence commands must remain compatible: "+str(exc))
        self.assertEqual(actor.calls,1)
        self.assertEqual(result["state"]["phase"],"repair")
        self.assertEqual(result["cost"]["known_usd"],"0.01")

    def test_control_with_each_partial_host_budget_is_rejected_before_actor(self):
        for missing,reason in [("command_timeout_s","unsupported_timeout"),
                               ("max_log_bytes","unsupported_log_limit")]:
            with self.subTest(missing=missing):
                request,actor=self.phase("fixture-v1",10)
                request.pop(missing)
                with self.assertRaisesRegex(adapter.PhaseInvalid,"^"+reason+"$"):
                    adapter.run_phase(request,actor)
                self.assertEqual(actor.calls,0)
                self.assertFalse(Path(request["out"]).exists())

    def test_protocol_requires_both_host_command_limits_before_actor(self):
        for missing in ["command_timeout_s","max_log_bytes"]:
            with self.subTest(missing=missing):
                request,actor=self.phase("fixture-v1",10)
                request["arm"]="P"
                request.pop(missing)
                with self.assertRaises(adapter.PhaseInvalid):
                    adapter.run_phase(request,actor)
                self.assertEqual(actor.calls,0)
                self.assertFalse(Path(request["out"]).exists())
