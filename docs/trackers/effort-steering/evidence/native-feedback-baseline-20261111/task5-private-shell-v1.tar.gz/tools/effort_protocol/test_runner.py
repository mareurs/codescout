"""Campaign boundary tests observe actual files, call order and retained charges."""
import copy
import hashlib
import json
import shutil
import tempfile
import unittest
from pathlib import Path
from decimal import Decimal

from campaign import accounting_totals, attempt_schedule, select_tasks
from receipts import input_digest, publish_exclusive

try:
    import runner as subject
except ModuleNotFoundError:
    subject = None


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class ScriptedBackend:
    mode = "scripted"

    def __init__(self, root, hook=None):
        self.root = root
        self.hook = hook
        self.calls = []
        self.grades = []
        self.verifies = 0
        self.events = []

    def verify(self, registration):
        self.verifies += 1
        return {"ready": True, "mode": self.mode}

    def invoke(self, request, out):
        self.calls.append(copy.deepcopy(request))
        self.events.append("actor")
        source = Path(request["source"])
        candidate = out / "candidate"
        shutil.copytree(source, candidate)
        if request["phase"] == "repair":
            (candidate / "program.txt").write_text("repaired public input\n")
        state = copy.deepcopy(request["state"])
        state.update(phase={"investigate":"repair", "repair":"challenge", "challenge":"closed"}[
            request["phase"]] if request["arm"] in ("P", "R") else "closed",
            turns_used=state["turns_used"] + 1, source_digest=input_digest(candidate))
        record = {"invocation_id": request["invocation_id"], "cost_usd":"0.10", "cost_is_final":True,
                  "context_valid":True, "capture_complete":True, "cleanup_complete":True,
                  "measurement_invalid":False, "candidate":str(candidate),
                  "source_digest":input_digest(candidate), "state":state, "turns":1,
                  "public_artifact":None, "reason":None}
        if request["arm"] in ("P", "R"):
            record["public_artifact"] = {"run_id":state["run_id"],"phase":request["phase"],
                "arm":request["arm"],"source_digest":record["source_digest"],"submission":None,"observations":[]}
        if self.hook:
            self.hook(request, out, record)
        publish_exclusive(out / "invocation.json", record)
        if record.pop("raise_after_receipt", False):
            raise RuntimeError("boundary interrupted after preserved receipt")
        return record

    def grade(self, request, out):
        self.events.append("grade")
        self.grades.append(copy.deepcopy(request))
        self.assert_closed()
        self.assert_candidate(request)
        result = {"valid":True, "pass":"repaired" in Path(request["source"],"program.txt").read_text()}
        publish_exclusive(out / "verdict.json", result)
        return result

    def assert_closed(self):
        closed = json.loads((self.root / "actor-batch-closed.json").read_text())
        assert len(closed["attempts"]) == 8
        assert all(Path(row["attempt_receipt"]).is_file() for row in closed["attempts"])

    def assert_candidate(self, request):
        assert input_digest(Path(request["source"])) == request["source_digest"]


class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(subject, "campaign controller is not implemented")
        self.temp = tempfile.TemporaryDirectory(prefix="ep-campaign-unit-")
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        self.out = root / "campaign"
        self.reg = {"schema":"evidence-campaign-v1", "campaign_id":"test-campaign", "mode":"scripted",
                    "output_root":str(self.out), "metadata":[], "exposure":[], "seed":"frozen-pilot",
                    "tasks":{}, "bindings":{},
                    "ledger":{"ceiling_usd":"200","charges":[],"holds":[],"reservations":[]},
                    "shared_preparation":{"cost_usd":"0.40","receipt_sha256":"b"*64}}
        for index in (0,1):
            identity = "task" + str(index)
            source = root / identity
            source.mkdir()
            (source / "program.txt").write_text("public baseline " + identity + "\n")
            issue = "Repair the public behavior " + identity
            self.reg["metadata"].append({"id":identity,"repo":"org/repo"+str(index),"base_commit":"a"*40,
                "image":"sha256:"+str(index+1)*64,"created_at":"2026-01-01","language":"rust",
                "public_issue_sha256":hashlib.sha256(issue.encode()).hexdigest(),
                "eligible":True,"reason":"public adapter qualified"})
            self.reg["tasks"][identity] = {"source":str(source),"source_sha256":input_digest(source),
                "public_packet":{"issue":issue},"backend":{"host_private_marker":"must not enter actor packet"}}
        self.reg["selected"] = select_tasks(self.reg["metadata"],set(),self.reg["seed"])
        self.reg["schedule"] = attempt_schedule(self.reg["selected"])
        self.bound = root / "runtime.bin"
        self.bound.write_bytes(b"frozen generic runtime")
        self.reg["bindings"][str(self.bound)] = digest(self.bound)
        self.backend = ScriptedBackend(self.out)

    def run_it(self, hook=None):
        if hook is not None:
            self.backend.hook = hook
        return subject.run_campaign(self.reg,self.backend)

    def test_exact_schedule_and_all_actor_outputs_close_before_first_private_grade(self):
        result = self.run_it()
        expected = [(row["task_id"],row["arm"]) for row in self.reg["schedule"]]
        self.assertEqual([(row["task_id"],row["arm"]) for row in result["attempts"]], expected)
        self.assertEqual(len(self.backend.calls),16)
        self.assertEqual(len(self.backend.grades),8)
        self.assertEqual(self.backend.events,["actor"]*16+["grade"]*8)
        self.assertEqual(result["status"],"completed")
        self.assertFalse(result["paid_ready"])
        self.assertEqual(json.loads((self.out/"ledger-reserved.json").read_text())["committed_usd"],"78")
        for index,row in enumerate(self.reg["schedule"]):
            calls=[call for call in self.backend.calls if call["attempt_index"]==index]
            self.assertEqual([c["phase"] for c in calls],
                             ["investigate","repair","challenge"] if row["arm"] in ("R","P") else ["repair"])
            self.assertEqual([c["allowance_usd"] for c in calls],
                             ["3","4","3"] if row["arm"] in ("R","P") else [row["reserved_usd"]])
            self.assertEqual([c["cli_cap_usd"] for c in calls],
                             ["0.55","1.65","0.55"] if row["arm"] in ("R","P") else [row["cli_cap_usd"]])
            self.assertTrue(all(c["max_continuations"]==2 for c in calls))
            self.assertTrue(all(c["effort"]==("xhigh" if row["arm"]=="X" else "low") for c in calls))
        payload=json.dumps([c["public_packet"] for c in self.backend.calls])
        self.assertNotIn("host_private_marker",payload)
        self.assertNotIn("must not enter actor packet",payload)

    def test_rerunning_existing_root_cannot_repeat_any_backend_effect(self):
        self.run_it()
        before=(len(self.backend.calls),self.backend.verifies)
        with self.assertRaises(subject.CampaignViolation):
            self.run_it()
        self.assertEqual((len(self.backend.calls),self.backend.verifies),before)

    def test_initial_drift_refuses_before_backend_verification_or_invocation(self):
        self.bound.write_text("changed")
        with self.assertRaises(subject.CampaignViolation):
            self.run_it()
        self.assertFalse(self.out.exists())
        self.assertEqual((self.backend.verifies,len(self.backend.calls)),(0,0))

    def test_private_public_packet_key_and_issue_tampering_fail_before_effect(self):
        identity=self.reg["selected"][0]["id"]
        self.reg["tasks"][identity]["public_packet"]["private_grade"]="hidden"
        with self.assertRaises(subject.CampaignViolation):
            self.run_it()
        self.assertEqual(len(self.backend.calls),0)
        del self.reg["tasks"][identity]["public_packet"]["private_grade"]
        self.reg["tasks"][identity]["public_packet"]["issue"] += "tampered"
        with self.assertRaises(subject.CampaignViolation):
            self.run_it()
        self.assertEqual(self.backend.verifies,0)

    def test_schedule_or_selection_drift_cannot_choose_another_trial(self):
        self.reg["schedule"].reverse()
        with self.assertRaises(subject.CampaignViolation):
            self.run_it()
        self.assertEqual(len(self.backend.calls),0)

    def test_source_overlap_and_changed_baseline_refuse_before_effect(self):
        identity=self.reg["selected"][0]["id"]
        self.reg["output_root"]=self.reg["tasks"][identity]["source"]
        with self.assertRaises(subject.CampaignViolation):
            self.run_it()
        self.assertEqual(self.backend.verifies,0)
        self.reg["output_root"]=str(self.out)
        Path(self.reg["tasks"][identity]["source"],"program.txt").write_text("changed")
        with self.assertRaises(subject.CampaignViolation):
            self.run_it()
        self.assertEqual(len(self.backend.calls),0)

    def test_unsettled_history_is_preserved_and_blocks_admission(self):
        self.reg["ledger"]["holds"]=[{"id":"legacy","reserved_usd":"4","settled":False}]
        original=copy.deepcopy(self.reg["ledger"])
        with self.assertRaises(subject.CampaignViolation):
            self.run_it()
        self.assertEqual(self.reg["ledger"],original)
        self.assertEqual(len(self.backend.calls),0)
    def legacy_history(self):
        receipt = self.bound.parent / "legacy-receipt.json"
        session = "98aaa6c0-110a-4a19-8789-b39df522284b"
        receipt.write_text(json.dumps({"session_id":session, "scripted":False,
            "cost_usd":None, "unknown_provider_cost":True, "campaign_available_usd":"4",
            "requests":0, "forwarded":0}))
        proof = {"id":"native-client:"+session, "source":str(receipt),
            "receipt_sha256":digest(receipt), "reserved_usd":"4"}
        self.reg["bindings"][str(receipt)] = digest(receipt)
        self.reg["ledger"]["holds"] = [{**proof, "cost_usd":None, "settled":False}]
        self.reg["carried_holds"] = [proof]
        return receipt

    def test_explicit_hash_bound_legacy_hold_stays_reserved_through_full_campaign(self):
        self.legacy_history()
        original = copy.deepcopy(self.reg["ledger"]["holds"])
        checked = subject.preflight(self.reg, self.backend)
        self.assertTrue(checked["ready"], checked)
        self.assertEqual(checked["reserved_ledger"]["holds"], original)
        self.assertEqual(Decimal(accounting_totals(checked["reserved_ledger"])["committed_usd"]), Decimal("82"))
        result = self.run_it()
        self.assertEqual(result["status"], "completed")
        ledger = json.loads((self.out/"ledger-final.json").read_bytes())
        self.assertEqual(ledger["holds"], original)
        self.assertIsNone(ledger["holds"][0]["cost_usd"])
        self.assertFalse(ledger["holds"][0]["settled"])

    def test_legacy_carry_proof_cannot_forge_omit_reduce_or_hide_unknown_cost(self):
        receipt = self.legacy_history()
        original = copy.deepcopy(self.reg)
        raw = receipt.read_bytes()
        for case in ("omitted-proof", "omitted-hold", "extra-hold", "amount", "hash",
                     "unbound", "settled", "duplicate", "new-unknown", "ceiling",
                     "changed-receipt", "final-cost", "forwarded", "source"):
            with self.subTest(case=case):
                self.reg = copy.deepcopy(original)
                receipt.write_bytes(raw)
                if case == "omitted-proof": self.reg.pop("carried_holds")
                elif case == "omitted-hold": self.reg["ledger"]["holds"] = []
                elif case == "extra-hold": self.reg["ledger"]["holds"].append(
                    {"id":"new", "reserved_usd":"4", "settled":False})
                elif case == "amount": self.reg["ledger"]["holds"][0]["reserved_usd"] = "3"
                elif case == "hash": self.reg["carried_holds"][0]["receipt_sha256"] = "0"*64
                elif case == "unbound": self.reg["bindings"].pop(str(receipt))
                elif case == "settled": self.reg["ledger"]["holds"][0]["settled"] = True
                elif case == "duplicate": self.reg["carried_holds"] *= 2
                elif case == "new-unknown": self.reg["ledger"]["charges"].append(
                    {"id":"new-charge", "cost_usd":None, "receipt_sha256":"f"*64})
                elif case == "ceiling": self.reg["ledger"]["charges"].append(
                    {"id":"old", "cost_usd":"165", "receipt_sha256":"f"*64})
                elif case == "changed-receipt": receipt.write_bytes(raw+b" ")
                elif case in ("final-cost", "forwarded"):
                    changed = json.loads(raw)
                    changed.update({"cost_usd":"0", "unknown_provider_cost":False} if case=="final-cost"
                                   else {"forwarded":1})
                    receipt.write_text(json.dumps(changed))
                    self.reg["bindings"][str(receipt)] = digest(receipt)
                    self.reg["carried_holds"][0]["receipt_sha256"] = digest(receipt)
                    self.reg["ledger"]["holds"][0]["receipt_sha256"] = digest(receipt)
                elif case == "source": self.reg["ledger"]["holds"][0]["source"] = str(self.bound)
                with self.assertRaises(subject.CampaignViolation):
                    subject._reserve(self.reg)
                self.assertEqual(len(self.backend.calls), 0)

    def test_new_unknown_charge_still_stops_with_explicit_historical_carry(self):
        self.legacy_history()
        def unknown(backend, request, returned):
            returned["cost_usd"] = None
            returned["cost_is_final"] = False
        self.backend.hook = unknown
        result = self.run_it()
        self.assertEqual(result["status"], "stopped")
        self.assertEqual(len(self.backend.calls), 1)
        ledger = json.loads((self.out/"ledger-final.json").read_bytes())
        self.assertFalse(ledger["holds"][0]["settled"])
        self.assertTrue(ledger["reservations"])

    def test_an_arbitrary_scripted_backend_cannot_admit_payment(self):
        self.reg["mode"]="paid"
        self.backend.mode="paid"
        with self.assertRaises(subject.CampaignViolation):
            self.run_it()
        self.assertEqual((self.backend.verifies,len(self.backend.calls)),(0,0))

    def test_unknown_new_charge_stops_and_retains_reservation_and_receipt(self):
        def hook(request,out,record):
            record.update(cost_usd=None,cost_is_final=False)
        result=self.run_it(hook)
        self.assertEqual(result["status"],"stopped")
        self.assertEqual(len(self.backend.calls),1)
        self.assertEqual(len(self.backend.grades),0)
        self.assertTrue(result["attempts"][0]["cost"]["unknown"])
        self.assertIsNone(result["attempts"][0]["cost"]["known_usd"])
        ledger=json.loads((self.out/"ledger-final.json").read_text())
        self.assertTrue(any(r["cost_usd"] is None for r in ledger["charges"]))
        self.assertTrue(ledger["reservations"])
        self.assertFalse((self.out/"actor-batch-closed.json").exists())

    def test_known_cost_and_candidate_survive_exception_without_another_invocation(self):
        def hook(request,out,record):
            record["raise_after_receipt"]=True
        result=self.run_it(hook)
        self.assertEqual(result["status"],"stopped")
        self.assertEqual(len(self.backend.calls),1)
        row=result["attempts"][0]
        self.assertEqual(row["cost"],{"known_usd":"0.10","unknown":False})
        self.assertTrue(Path(row["candidate"]).is_dir())
        self.assertEqual(len(self.backend.grades),0)

    def test_exception_without_receipt_is_unknown_instead_of_zero(self):
        def interrupted(request,out):
            self.backend.calls.append(request)
            raise RuntimeError("no terminal capture")
        self.backend.invoke=interrupted
        result=self.run_it()
        self.assertEqual(result["status"],"stopped")
        self.assertTrue(result["attempts"][0]["cost"]["unknown"])
        self.assertEqual(len(self.backend.calls),1)
        self.assertEqual(len(self.backend.grades),0)

    def test_incomplete_protocol_keeps_candidate_and_quality_denominator(self):
        def hook(request,out,record):
            if request["arm"]=="P" and request["phase"]=="repair":
                record["state"]["phase"]="incomplete"
                record["reason"]="malformed public submission"
        result=self.run_it(hook)
        rows=[row for row in result["attempts"] if row["arm"]=="P"]
        self.assertEqual(len(result["attempts"]),8)
        self.assertTrue(all(row["workflow_state"]=="incomplete" for row in rows))
        self.assertTrue(all(row["grade"]["pass"] is True for row in rows))
        self.assertTrue(all(row["measurement_invalid"] is False for row in rows))
        self.assertEqual(len(self.backend.calls),14)
        self.assertEqual(len(self.backend.grades),8)
        self.assertFalse(result["analysis"]["advance"])

    def test_context_cleanup_overbudget_and_phase_drift_stop_before_next_actor(self):
        for key,value in (("context_valid",False),("cleanup_complete",False),("cost_usd","7")):
            with self.subTest(key=key):
                temp=Path(self.temp.name)/key
                self.reg["output_root"]=str(temp)
                backend=ScriptedBackend(temp,lambda req,out,record:record.update({key:value}))
                result=subject.run_campaign(self.reg,backend)
                self.assertEqual(result["status"],"stopped")
                self.assertEqual((len(backend.calls),len(backend.grades)),(1,0))
                self.assertTrue(Path(result["attempts"][0]["candidate"]).is_dir())

    def test_mutating_frozen_source_after_call_stops_even_with_fresh_candidate(self):
        def hook(request,out,record):
            Path(request["source"],"program.txt").write_text("illegal alias mutation")
        result=self.run_it(hook)
        self.assertEqual(result["status"],"stopped")
        self.assertEqual(len(self.backend.calls),1)
        self.assertEqual(len(self.backend.grades),0)

    def test_wrong_invocation_id_or_turn_limit_cannot_advance(self):
        for label in ("identity","turns","phase"):
            with self.subTest(label=label):
                out=Path(self.temp.name)/label
                self.reg["output_root"]=str(out)
                directories=[]
                def hook(request,directory,record):
                    directories.append(directory)
                    if label=="identity":
                        record["invocation_id"]="another-invocation"
                    elif label=="turns":
                        record["turns"]=4
                        record["state"]["turns_used"]=request["state"]["turns_used"]+4
                    else:
                        record["state"]["phase"]="invented"
                backend=ScriptedBackend(out,hook)
                result=subject.run_campaign(self.reg,backend)
                self.assertEqual(result["status"],"stopped")
                self.assertEqual((len(backend.calls),len(backend.grades)),(1,0))
                if label=="turns":
                    decision=json.loads((directories[0]/"decision.json").read_text())
                    self.assertEqual(decision["faults"],["phase turn/state invalid"])
    def test_three_self_consistent_turns_per_invocation_close_the_campaign(self):
        def hook(request,directory,record):
            record["turns"]=3
            record["state"]["turns_used"]=request["state"]["turns_used"]+3
        backend=ScriptedBackend(self.out,hook)
        result=subject.run_campaign(self.reg,backend)
        self.assertEqual(result["status"],"completed")
        self.assertEqual((len(backend.calls),len(backend.grades)),(16,8))
        self.assertEqual([row["state"]["turns_used"] for row in backend.calls[:1]],[0])

    def test_frozen_binding_drift_after_first_actor_cannot_reach_second(self):
        def hook(request,out,record):
            self.bound.write_bytes(b"changed while running")
        result=self.run_it(hook)
        self.assertEqual(result["status"],"stopped")
        self.assertEqual(len(self.backend.calls),1)
        self.assertEqual(len(self.backend.grades),0)

    def test_independent_grade_failure_stops_remaining_grades_without_more_actors(self):
        original=self.backend.grade
        def invalid(request,out):
            result=original(request,out)
            result.update(valid=False,pass_=False)
            return result
        self.backend.grade=invalid
        result=self.run_it()
        self.assertEqual(result["status"],"grading_stopped")
        self.assertEqual(len(self.backend.calls),16)
        self.assertEqual(len(self.backend.grades),1)
        self.assertFalse(result["analysis"]["advance"])

    def test_last_grader_cannot_mutate_the_frozen_candidate_or_costs(self):
        original=self.backend.grade
        def altered(request,out):
            result=original(request,out)
            if len(self.backend.grades)==8:
                Path(request["source"],"program.txt").write_text("changed during last grade")
            return result
        self.backend.grade=altered
        result=self.run_it()
        self.assertEqual(result["status"],"grading_stopped")
        self.assertEqual((len(self.backend.calls),len(self.backend.grades)),(16,8))
        self.assertFalse(result["analysis"]["advance"])


class AnalysisTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(subject, "campaign controller is not implemented")
        self.result={"status":"completed","setup_cost_usd":"0.80","attempts":[]}
        for task in ("a","b"):
            for arm,cost in (("L","1"),("R","1"),("P","0.20"),("X","2")):
                accepted=arm in ("P","X") or (arm=="L" and task=="b") or (arm=="R" and task=="a")
                self.result["attempts"].append({"task_id":task,"arm":arm,"workflow_state":"closed",
                    "measurement_invalid":False,"grade":{"valid":True,"pass":accepted},
                    "cost":{"known_usd":cost,"unknown":False}})

    def test_exact_preregistered_screen_and_setup_amortization(self):
        result=subject.analyze(self.result)
        self.assertTrue(result["advance"])
        self.assertEqual(result["paired"]["P-L"],{"wins":1,"losses":0,"ties":1})
        self.assertEqual(result["paired"]["P-R"],{"wins":1,"losses":0,"ties":1})
        self.assertEqual(result["paired"]["P-X"],{"wins":0,"losses":0,"ties":2})
        self.assertEqual(result["standalone_pair_usd"]["P"],"1.20")
        self.assertEqual(result["amortized_pair_usd"]["P"],"0.60")

    def test_tie_incomplete_missing_duplicate_unknown_or_uninterpretable_never_advances(self):
        for variant in ("tie","incomplete","missing","duplicate","unknown","invalid","stopped"):
            with self.subTest(variant=variant):
                result=copy.deepcopy(self.result)
                row=next(r for r in result["attempts"] if r["arm"]=="P")
                if variant=="tie":
                    for item in result["attempts"]:
                        item["grade"]["pass"]=True
                elif variant=="incomplete":row["workflow_state"]="incomplete"
                elif variant=="missing":result["attempts"].pop()
                elif variant=="duplicate":result["attempts"][-1]=copy.deepcopy(result["attempts"][0])
                elif variant=="unknown":row["cost"]={"known_usd":None,"unknown":True}
                elif variant=="invalid":row["measurement_invalid"]=True
                else:result["status"]="stopped"
                self.assertFalse(subject.analyze(result)["advance"])

    def test_one_acceptance_loss_or_cost_tie_fails_the_screen(self):
        row=next(r for r in self.result["attempts"] if r["task_id"]=="b" and r["arm"]=="P")
        row["grade"]["pass"]=False
        self.assertFalse(subject.analyze(self.result)["advance"])
        row["grade"]["pass"]=True
        for item in self.result["attempts"]:
            if item["arm"]=="P":item["cost"]["known_usd"]="2"
        self.assertFalse(subject.analyze(self.result)["advance"])

    def test_cost_comparison_keeps_registered_decimal_precision(self):
        for row in self.result["attempts"]:
            if row["arm"]=="P":
                row["cost"]["known_usd"]="0.100000000000000000000000000000000000000000000001"
            elif row["arm"]=="X":
                row["cost"]["known_usd"]="0.100000000000000000000000000000000000000000000002"
        result=subject.analyze(self.result)
        self.assertTrue(result["advance"],result)
        self.assertEqual(result["model_usd"]["P"],"0.200000000000000000000000000000000000000000000002")
        self.assertEqual(result["model_usd"]["X"],"0.200000000000000000000000000000000000000000000004")
