"""Resource admission is based on measured host and owned container evidence."""
import copy
import importlib
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).parent))
try:
    resources = importlib.import_module("campaign_resources")
except ModuleNotFoundError as exc:
    if exc.name != "campaign_resources":
        raise
    resources = None

IMAGE = "sha256:" + "a" * 64
CID = "b" * 64
NAME = "hfa-native-" + "c" * 32
PROFILE = {"Memory": 32 * 1024**3, "MemorySwap": 32 * 1024**3,
           "NanoCpus": 4 * 10**9, "PidsLimit": 4096, "ReadonlyRootfs": True,
           "NetworkMode": "frozen-network", "CapDrop": ["ALL"],
           "SecurityOpt": ["no-new-privileges"], "Tmpfs": {"/tmp": "rw,exec,size=16g"}}


class ResourceTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(resources, "concrete resource supervisor missing")
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.floors = {"root_free": 80, "tmp_free": 4, "mem_available": 16}
        self.host = dict(root_free=100, tmp_free=10, mem_available=30, tmp_exec=True)
        self.info = {"Id": CID, "Image": IMAGE, "Name": "/" + NAME,
            "Config": {"Labels": {"codescout.hfa": NAME}, "User": "1000:1000"},
            "HostConfig": copy.deepcopy(PROFILE),
            "State": {"Running": True, "OOMKilled": False, "Error": ""}}
        self.events = "low 0\nhigh 0\nmax 0\noom 0\noom_kill 0\noom_group_kill 0\n"
        self.commands = []
        self.inspection_error = None
        self.server = SimpleNamespace(request_guard=None)
        self.supervisor = None

    def docker(self, args):
        self.commands.append(list(args))
        if args[0] == "inspect":
            if self.inspection_error:
                return SimpleNamespace(returncode=1, stdout="", stderr=self.inspection_error)
            return SimpleNamespace(returncode=0, stdout=json.dumps([self.info]), stderr="")
        if args[:3] == ["exec", CID, "cat"]:
            return SimpleNamespace(returncode=0, stdout=self.events, stderr="")
        if args == ["kill", CID]:
            return SimpleNamespace(returncode=0, stdout=CID, stderr="")
        raise AssertionError("unexpected Docker operation: " + repr(args))

    def bind(self):
        self.supervisor = resources.ResourceSupervisor(
            floors=self.floors, native_profile=PROFILE,
            host=lambda: copy.deepcopy(self.host), docker=self.docker, interval_s=60)
        self.supervisor.bind(out=self.root, image=IMAGE, server=self.server)
        self.addCleanup(self.supervisor.stop_monitor)
        (self.root / "mcp-launch-1.json").write_text(json.dumps({"name": NAME}))
        return self.supervisor

    def test_real_host_probe_checks_executability_and_removes_owned_probe(self):
        before = sorted(p.name for p in self.root.iterdir())
        measured = resources.measure_host(self.root, self.root)
        for key in ("root_free", "tmp_free", "mem_available"):
            self.assertIs(type(measured[key]), int)
            self.assertGreater(measured[key], 0)
        self.assertIs(measured["tmp_exec"], True)
        self.assertEqual(sorted(p.name for p in self.root.iterdir()), before)

    def test_two_actual_cgroup_observations_and_final_state_are_required(self):
        sup = self.bind()
        self.assertFalse(sup.proof()["complete"])
        sup.sample("one", required=True)
        self.assertEqual(sup.proof()["cgroup_probes"], 1)
        self.assertFalse(sup.proof()["complete"])
        sup.before_public()
        self.assertEqual(sup.proof()["cgroup_probes"], 2)
        self.assertFalse(sup.proof()["complete"])
        sup.finish()
        proof = json.loads((self.root / "supervision-final.json").read_text())
        self.assertTrue(proof["complete"])
        self.assertEqual(proof["container_id"], CID)
        self.assertEqual(proof["oom_kill"], 0)
        self.assertGreaterEqual(proof["cgroup_probes"], 3)
        self.assertIs(self.server.request_guard.__self__, sup)

    def test_each_measured_host_floor_and_noexec_refuses_at_bind(self):
        original = copy.deepcopy(self.host)
        for field in (*self.floors, "tmp_exec"):
            with self.subTest(field=field):
                self.host = copy.deepcopy(original)
                self.host[field] = False if field == "tmp_exec" else self.floors[field] - 1
                sup = resources.ResourceSupervisor(floors=self.floors, native_profile=PROFILE,
                    host=lambda: copy.deepcopy(self.host), docker=self.docker, interval_s=60)
                with self.assertRaises(ValueError):
                    sup.bind(out=self.root, image=IMAGE, server=self.server)
                sup.stop_monitor()
                self.assertFalse(sup.proof()["complete"])
        self.assertEqual(self.commands, [])

    def test_floors_are_finite_integer_configuration(self):
        for value in (True, 0, -1, float("nan"), float("inf"), "80"):
            with self.subTest(value=value):
                floors = dict(self.floors, root_free=value)
                with self.assertRaises(ValueError):
                    resources.ResourceSupervisor(floors=floors, native_profile=PROFILE)
        for floors in ({}, dict(self.floors, typo=1)):
            with self.assertRaises(ValueError):
                resources.ResourceSupervisor(floors=floors, native_profile=PROFILE)

    def test_malformed_host_sample_does_not_become_healthy(self):
        sup = self.bind()
        for field in self.floors:
            with self.subTest(field=field):
                self.host[field] = True
                sup.sample("malformed", required=True)
                with self.assertRaises(ValueError):
                    sup.check()
        self.assertFalse(sup.proof()["complete"])

    def test_bad_identity_or_profile_never_authorizes_a_kill(self):
        for field, value in (("Id", "d" * 63), ("Image", "sha256:" + "e" * 64),
                             ("Name", "/foreign"), ("User", "0"), ("label", "foreign"),
                             ("Memory", 8 * 1024**3), ("MemorySwap", -1),
                             ("NanoCpus", 10**9), ("PidsLimit", 1024),
                             ("ReadonlyRootfs", False), ("NetworkMode", "bridge"),
                             ("CapDrop", []), ("SecurityOpt", []), ("Tmpfs", {})):
            with self.subTest(field=field):
                current = copy.deepcopy(self.info)
                if field == "User":
                    self.info["Config"]["User"] = value
                elif field == "label":
                    self.info["Config"]["Labels"]["codescout.hfa"] = value
                elif field in PROFILE:
                    self.info["HostConfig"][field] = value
                else:
                    self.info[field] = value
                sup = self.bind()
                sup.sample("bad-identity", required=True)
                with self.assertRaises(ValueError):
                    sup.check()
                self.assertIsNone(sup.proof()["container_id"])
                self.assertNotIn(["kill", CID], self.commands)
                sup.stop_monitor()
                self.info = current

    def test_owned_oom_stops_requests_and_only_owned_container(self):
        sup = self.bind()
        sup.sample("initial", required=True)
        self.events = self.events.replace("oom_kill 0", "oom_kill 1")
        sup.sample("oom", required=True)
        with self.assertRaises(ValueError):
            self.server.request_guard()
        self.assertIn(["kill", CID], self.commands)
        self.assertFalse(sup.proof()["complete"])
        self.assertEqual(sup.proof()["oom_kill"], 1)

    def test_malformed_or_missing_cgroup_events_invalidates(self):
        for events in ("", "oom_kill x\n", "oom_kill -1\n", "oom_kill 0\noom_kill 0\n",
                       "low 0\n", "oom_kill 0 extra\n"):
            with self.subTest(events=events):
                sup = self.bind()
                self.events = events
                sup.sample("events", required=True)
                with self.assertRaises(ValueError):
                    sup.check()
                self.assertEqual(sup.proof()["cgroup_probes"], 0)
                sup.stop_monitor()

    def test_loss_of_previously_owned_worker_is_not_clean_success(self):
        sup = self.bind()
        sup.sample("initial", required=True)
        self.inspection_error = "Error: No such object: " + NAME
        sup.sample("lost-worker")
        with self.assertRaises(ValueError):
            sup.finish()
        self.assertFalse(sup.proof()["complete"])
    def test_two_declared_workers_are_invalid_even_if_first_was_never_sampled(self):
        sup = self.bind()
        second = "hfa-native-" + "d" * 32
        (self.root / "mcp-launch-2.json").write_text(json.dumps({"name": second}))
        def docker(args):
            self.commands.append(args)
            if args == ["inspect", NAME]:
                return SimpleNamespace(returncode=1, stdout="", stderr="Error: No such object: " + NAME)
            if args == ["inspect", second]:
                row = copy.deepcopy(self.info)
                row.update(Id="e" * 64, Name="/" + second)
                row["Config"]["Labels"]["codescout.hfa"] = second
                return SimpleNamespace(returncode=0, stdout=json.dumps([row]), stderr="")
            if args[:3] == ["exec", "e" * 64, "cat"]:
                return SimpleNamespace(returncode=0, stdout=self.events, stderr="")
            raise AssertionError(args)
        sup.docker = docker
        sup.sample("late-first-observation")
        with self.assertRaises(ValueError):
            sup.check()
        self.assertIsNone(sup.proof()["container_id"])

    def test_unknown_inspection_failure_is_not_absence(self):
        sup = self.bind()
        self.inspection_error = "permission denied"
        sup.sample("bad-inspection")
        with self.assertRaises(ValueError):
            sup.check()
        self.assertNotIn(["kill", CID], self.commands)

    def test_public_test_output_cannot_impersonate_host_resource_observation(self):
        sup = self.bind()
        sup.before_public()
        log = self.root / "public.log"
        log.write_text("---- test stdout ----\nerror: No space left on device\n"
                       "rustc: fatal error: terminated with signal 9\n")
        sup.after_public("public test", log, 101)
        sup.finish()
        self.assertTrue(sup.proof()["complete"])
        checks = json.loads((self.root / "public-resource-captures.json").read_text())
        self.assertEqual(checks[0]["exit_code"], 101)
        self.assertEqual(checks[0]["bytes"], log.stat().st_size)

    def test_public_capture_escape_or_symlink_is_invalid(self):
        sup = self.bind()
        sup.before_public()
        outside = self.root.parent / (self.root.name + "-outside")
        outside.write_text("public")
        self.addCleanup(outside.unlink)
        link = self.root / "public.log"
        link.symlink_to(outside)
        with self.assertRaises(ValueError):
            sup.after_public("test", link, 0)
        self.assertFalse(sup.proof()["complete"])


if __name__ == "__main__":
    unittest.main()
