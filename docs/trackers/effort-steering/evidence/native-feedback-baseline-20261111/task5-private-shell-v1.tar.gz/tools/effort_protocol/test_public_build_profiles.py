"""Independent runtime-shape rejection for versioned build-input mounts."""
import copy
from pathlib import Path
import sys
import tempfile
import unittest
sys.path.insert(0, str(Path(__file__).parent))
import public_build_inputs as inputs
import execution_profiles as profiles
import executor


class PublicBuildProfileTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.base = Path(temporary.name)
        self.source = self.base / "source"
        self.source.mkdir()
        (self.source / "node_modules").mkdir()
        (self.source / "main.rs").write_bytes(b"original")
        self.seed = self.base / "seed"
        (self.seed / "store").mkdir(parents=True)
        (self.seed / "store/payload").write_bytes(b"locked")
        self.build = self.base / "build"
        (self.build / "scratch").mkdir(parents=True)
        self.image = "sha256:" + "a" * 64
        self.descriptor = {"schema":"public-build-inputs-v1", "image":self.image,
            "seed":{"path":str(self.seed),"sha256":inputs.generated_digest(self.seed)},
            "dependency_dirs":["node_modules"],
            "cache_mounts":[{"seed_relative":"store","destination":"/bench/public-dependencies/store"}]}
        self.stage = inputs.stage_inputs(self.descriptor,self.source,self.image,self.base/"stage")
        self.row = {"Image":self.image, "HostConfig":{
            "ReadonlyRootfs":True,"NetworkMode":"none","Memory":8589934592,"MemorySwap":8589934592,
            "NanoCpus":4000000000,"PidsLimit":512,"Init":True,"CapDrop":["ALL"],
            "SecurityOpt":["no-new-privileges"],"Tmpfs":{"/tmp":"rw,exec,size=1073741824,mode=1777"}},
            "Config":{"User":"1000:1000","Env":["HOME=/tmp","PYTHONDONTWRITEBYTECODE=1",
                "TMPDIR=/mnt_tmp","CARGO_TARGET_DIR=/build/target","CARGO_NET_OFFLINE=true"]},
            "Mounts":[{"Type":"bind","Source":str(self.source),"Destination":"/testbed","RW":False},
                      {"Type":"bind","Source":str(self.build),"Destination":"/build","RW":True},
                      {"Type":"bind","Source":str(self.build/"scratch"),"Destination":"/mnt_tmp","RW":True}]}
        self.row["Mounts"] += [{"Type":"bind","Source":r["source"],"Destination":r["destination"],"RW":True}
                               for r in self.stage["mounts"]]
        self.request = {"id":"observation", "run_id":"run","phase":"repair","image":self.image,
            "argv":["cargo","check","--offline","--workspace"],"cwd":".","kind":"observation",
            "timeout_s":900,"max_log_bytes":67108864,"test_files":["main.rs"],"production_files":["main.rs"],
            "execution_profile":"cargo-v3","public_build_inputs":self.descriptor}

    def validate(self,row=None,stage=None,name="cargo-v3"):
        return profiles.validate_runtime_profile(row or self.row,self.source,self.build,name,
                                                 public_build_inputs=self.stage if stage is None else stage)

    def test_exact_declared_runtime_has_descriptor_fingerprint(self):
        observed = self.validate()
        self.assertEqual(observed["PublicBuildInputs"], self.stage["fingerprint"])

    def test_new_profile_requires_stage_and_old_profile_forbids_it(self):
        with self.assertRaises(profiles.ProfileViolation):
            profiles.validate_runtime_profile(self.row,self.source,self.build,"cargo-v3")
        with self.assertRaises(profiles.ProfileViolation):
            self.validate(name="cargo-v2")

    def test_missing_wrong_or_extra_mount_is_rejected(self):
        for index in range(len(self.row["Mounts"])):
            row = copy.deepcopy(self.row)
            row["Mounts"].pop(index)
            with self.subTest(missing=index), self.assertRaises(profiles.ProfileViolation):
                self.validate(row)
        for key,value in (("Source",str(self.seed)),("RW",False)):
            row = copy.deepcopy(self.row)
            row["Mounts"][-1][key] = value
            with self.subTest(key=key), self.assertRaises(profiles.ProfileViolation):
                self.validate(row)
        row = copy.deepcopy(self.row)
        row["Mounts"].append({"Type":"bind","Source":str(self.seed),"Destination":"/extra","RW":True})
        with self.assertRaises(profiles.ProfileViolation):
            self.validate(row)

    def test_duplicate_mount_destination_is_not_hidden_by_dictionary(self):
        row = copy.deepcopy(self.row)
        row["Mounts"].append(copy.deepcopy(row["Mounts"][-1]))
        with self.assertRaises(profiles.ProfileViolation):
            self.validate(row)

    def test_writable_original_source_is_rejected(self):
        row = copy.deepcopy(self.row)
        row["Mounts"][0]["RW"] = True
        with self.assertRaises(profiles.ProfileViolation):
            self.validate(row)

    def test_runtime_image_and_mutated_seed_are_rejected(self):
        row = copy.deepcopy(self.row)
        row["Image"] = "sha256:" + "b" * 64
        with self.assertRaises(profiles.ProfileViolation):
            self.validate(row)
        (self.seed/"store/payload").write_bytes(b"changed")
        with self.assertRaises(profiles.ProfileViolation):
            self.validate()

    def test_request_requires_bound_descriptor_and_legacy_profile_forbids_it(self):
        accepted = executor._request(self.request,self.source,self.base/"observations")
        self.assertEqual(accepted[-1],"cargo-v3")
        for request in ({k:v for k,v in self.request.items() if k!="public_build_inputs"},
                        {**self.request,"execution_profile":"cargo-v2"},
                        {**self.request,"public_build_inputs":{**self.descriptor,"image":"latest"}}):
            with self.subTest(request=request), self.assertRaises(executor.ExecutionInvalid):
                executor._request(request,self.source,self.base/"observations")


if __name__ == "__main__":
    unittest.main()
