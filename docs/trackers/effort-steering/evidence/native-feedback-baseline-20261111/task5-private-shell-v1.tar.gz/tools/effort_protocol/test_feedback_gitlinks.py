"""A synthetic Git baseline must retain populated submodules as commit entries."""
import copy
import hashlib
import importlib
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

try:
    subject = importlib.import_module("feedback_gitlinks")
except ModuleNotFoundError:
    subject = None

class GitlinkPreparationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.repo = self.root / "repo"
        self.repo.mkdir()
        self.initialize()
        (self.repo / "main.rs").write_text("public baseline\n")
        (self.repo / "data-other").mkdir()
        (self.repo / "data-other/source.rs").write_text("unrelated sibling\n")
        (self.repo / "main-link").symlink_to("main.rs")
        self.git("add", ".")
        self.git("commit", "-qm", "public root")
        self.link = "data"
        self.populate(self.link)
        self.git("update-index", "--add", "--cacheinfo", "160000," + "1" * 40 + "," + self.link)
        self.git("commit", "-qm", "public submodule")
        self.expected = self.git("rev-parse", "HEAD^{tree}")
        self.files = self.physical()

    def git(self, *args, data=None):
        return subprocess.check_output(["git", "--literal-pathspecs", *args],
            cwd=self.repo, input=data).decode().strip()

    def initialize(self, object_format="sha1"):
        self.git("init", "-q", "--object-format=" + object_format)
        self.git("config", "user.name", "fixture")
        self.git("config", "user.email", "fixture@invalid")
        self.git("config", "core.autocrlf", "false")

    def populate(self, name):
        path = self.repo / name
        path.mkdir(parents=True)
        (path / "README.md").write_text("declared public data\n")
        (path / "sample.bin").write_bytes(b"public\x00fixture\n")
        (path / "alias").symlink_to("sample.bin")

    def physical(self):
        return {p.relative_to(self.repo).as_posix():
            ("link", str(p.readlink())) if p.is_symlink() else
            ("file", p.stat().st_mode, hashlib.sha256(p.read_bytes()).hexdigest())
            for p in self.repo.rglob("*") if p.relative_to(self.repo).parts[0] != ".git"
            and (p.is_file() or p.is_symlink())}

    def flatten(self, object_format="sha1"):
        shutil.rmtree(self.repo / ".git")
        self.initialize(object_format)
        self.git("add", ".")
        self.git("commit", "-qm", "synthetic root")

    def module(self):
        self.assertIsNotNone(subject, "missing generic Gitlink preparation helper")
        return subject

    def test_populated_submodule_is_reproduced_then_restored_without_changing_data(self):
        helper = self.module()
        snapshot = helper.capture_gitlinks(self.repo)
        self.flatten()
        self.assertNotEqual(self.git("rev-parse", "HEAD^{tree}"), self.expected)
        self.assertIn("data/README.md", self.git("ls-files"))
        helper.restore_gitlinks(self.repo, snapshot)
        self.assertEqual(self.git("write-tree"), self.expected)
        self.assertEqual(self.physical(), self.files)
        self.assertEqual(helper.capture_gitlinks(self.repo), snapshot)

    def test_unrelated_prefix_and_regular_symlink_entries_survive(self):
        helper = self.module()
        snapshot = helper.capture_gitlinks(self.repo)
        self.flatten()
        helper.restore_gitlinks(self.repo, snapshot)
        entries = self.git("ls-files", "--stage")
        self.assertIn("data-other/source.rs", entries)
        self.assertIn("120000", entries)
        self.assertNotIn("data/sample.bin", entries)
        self.assertEqual(self.git("write-tree"), self.expected)

    def test_empty_and_unpopulated_gitlinks_are_preserved_too(self):
        helper = self.module()
        shutil.rmtree(self.repo / self.link)
        (self.repo / self.link).mkdir()
        snapshot = helper.capture_gitlinks(self.repo)
        self.flatten()
        helper.restore_gitlinks(self.repo, snapshot)
        self.assertEqual(self.git("write-tree"), self.expected)

    def test_nul_transport_preserves_tabs_newlines_spaces_and_glob_characters(self):
        helper = self.module()
        name = "vendor/odd\t name\n[branch]"
        self.populate(name)
        self.git("update-index", "--add", "--cacheinfo", "160000," + "2" * 40 + "," + name)
        expected = self.git("write-tree")
        snapshot = helper.capture_gitlinks(self.repo)
        self.flatten()
        helper.restore_gitlinks(self.repo, snapshot)
        self.assertEqual(self.git("write-tree"), expected)

    def test_snapshot_validation_rejects_bad_paths_hashes_duplicates_and_format_before_write(self):
        helper = self.module()
        snapshot = helper.capture_gitlinks(self.repo)
        self.flatten()
        before = self.git("write-tree")
        for case in ("escape", "absolute", "nul", "object", "duplicate", "ancestor", "format", "unknown"):
            with self.subTest(case=case):
                value = copy.deepcopy(snapshot)
                row = value["gitlinks"][0]
                if case == "escape": row["path"] = "../outside"
                elif case == "absolute": row["path"] = "/outside"
                elif case == "nul": row["path"] = "bad\0path"
                elif case == "object": row["object"] = "not-a-hash"
                elif case == "duplicate": value["gitlinks"].append(dict(row))
                elif case == "ancestor": value["gitlinks"].append({"path": row["path"] + "/child", "object": row["object"]})
                elif case == "format": value["object_format"] = "sha256"
                else: value["unknown"] = True
                with self.assertRaises(ValueError):
                    helper.restore_gitlinks(self.repo, value)
                self.assertEqual(self.git("write-tree"), before)

    def test_unmerged_index_is_refused(self):
        helper = self.module()
        blob = self.git("hash-object", "main.rs")
        rows = ("0 " + "0" * 40 + "\tmain.rs\n100644 " + blob + " 1\tmain.rs\n").encode()
        self.git("update-index", "--index-info", data=rows)
        with self.assertRaises(ValueError):
            helper.capture_gitlinks(self.repo)

    def test_no_gitlinks_does_not_change_a_regular_index(self):
        helper = self.module()
        self.git("update-index", "--force-remove", "--", self.link)
        snapshot = helper.capture_gitlinks(self.repo)
        before = self.git("write-tree")
        helper.restore_gitlinks(self.repo, snapshot)
        self.assertEqual(snapshot["gitlinks"], [])
        self.assertEqual(self.git("write-tree"), before)

    def test_sha256_repository_uses_its_own_object_format(self):
        helper = self.module()
        shutil.rmtree(self.repo / ".git")
        self.initialize("sha256")
        self.git("add", "main.rs", "main-link", "data-other")
        self.git("update-index", "--add", "--cacheinfo", "160000," + "a" * 64 + "," + self.link)
        expected = self.git("write-tree")
        snapshot = helper.capture_gitlinks(self.repo)
        self.assertEqual(snapshot["object_format"], "sha256")
        self.flatten("sha256")
        helper.restore_gitlinks(self.repo, snapshot)
        self.assertEqual(self.git("write-tree"), expected)

if __name__ == "__main__":
    unittest.main()
