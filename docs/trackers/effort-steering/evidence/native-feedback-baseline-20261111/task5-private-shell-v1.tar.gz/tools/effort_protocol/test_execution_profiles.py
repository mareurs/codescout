"""Host execution contracts are independent of project/task identity."""
import unittest
try:
    import execution_profiles as profiles
except ImportError:
    profiles = None


class ExecutionProfileTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(profiles, "registered execution profiles are not implemented")

    def test_default_fixture_contract_is_preserved(self):
        profile = profiles.get_profile("fixture-v1")
        self.assertEqual(profile["memory_bytes"], 256 * 1024 * 1024)
        self.assertEqual(profile["nano_cpus"], 1_000_000_000)
        self.assertEqual(profile["pids"], 128)
        self.assertEqual(profile["source_mount"], "/work")
        self.assertEqual(profile["tmpfs"], "rw,exec,size=64m,mode=1777")

    def test_cargo_contract_is_generic_and_copies_are_independent(self):
        profile = profiles.get_profile("cargo-v1")
        self.assertEqual(profile["source_mount"], "/testbed")
        self.assertEqual(profile["memory_bytes"], 8 * 1024**3)
        self.assertEqual(profile["nano_cpus"], 4_000_000_000)
        self.assertEqual(profile["pids"], 512)
        self.assertEqual(profile["env"]["CARGO_TARGET_DIR"], "/build/target")
        digest = profiles.profile_digest("cargo-v1")
        profile["env"]["CARGO_TARGET_DIR"] = "/wrong"
        self.assertEqual(profiles.get_profile("cargo-v1")["env"]["CARGO_TARGET_DIR"], "/build/target")
        self.assertEqual(digest, profiles.profile_digest("cargo-v1"))
        self.assertNotEqual(digest, profiles.profile_digest("fixture-v1"))

    def test_unknown_or_structured_actor_profile_is_not_admitted(self):
        for name in ("unknown", None, {}, {"name": "cargo-v1"}, True):
            with self.subTest(name=name), self.assertRaises(ValueError):
                profiles.get_profile(name)
