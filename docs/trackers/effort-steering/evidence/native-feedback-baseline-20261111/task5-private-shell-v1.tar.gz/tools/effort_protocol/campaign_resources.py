"""Sample actual host floors and one owned native worker; no log-text inference."""
import copy
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import tempfile
import threading
import time
from pathlib import Path

FLOOR_KEYS = {"root_free", "tmp_free", "mem_available"}
PROFILE_KEYS = {"Memory", "MemorySwap", "NanoCpus", "PidsLimit", "ReadonlyRootfs",
                "NetworkMode", "CapDrop", "SecurityOpt", "Tmpfs"}


def measure_host(root, temporary):
    """Measure free bytes, MemAvailable and an actual executable temporary file."""
    root, temporary = Path(root).resolve(strict=True), Path(temporary).resolve(strict=True)
    memory = {}
    for line in Path("/proc/meminfo").read_text().splitlines():
        words = line.split()
        if len(words) == 3 and words[2] == "kB" and words[1].isdigit():
            memory[words[0].rstrip(":")] = int(words[1]) * 1024
    fd, name = tempfile.mkstemp(prefix="effort-exec-", dir=temporary)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(b"#!/bin/sh\nexit 0\n")
        os.chmod(name, 0o700)
        try:
            result = subprocess.run([name], capture_output=True, timeout=5)
            executable = result.returncode == 0
            detail = {"returncode": result.returncode, "stderr": result.stderr.decode(errors="replace")}
        except (OSError, subprocess.TimeoutExpired) as exc:
            executable = False
            detail = {"error": type(exc).__name__ + ": " + str(exc)}
    finally:
        os.unlink(name)
    return {"root_free": shutil.disk_usage(root).free,
            "tmp_free": shutil.disk_usage(temporary).free,
            "mem_available": memory["MemAvailable"], "tmp_exec": executable,
            "tmp_exec_probe": detail, "root": str(root), "temporary": str(temporary),
            "pressure": {key: (Path("/proc/pressure") / key).read_text()
                         for key in ("cpu", "memory", "io")}}


def _docker(args):
    return subprocess.run(["docker", *args], capture_output=True, text=True, timeout=15)


class ResourceSupervisor:
    def __init__(self, *, floors, native_profile, root=".", temporary="/tmp",
                 host=None, docker=_docker, interval_s=2):
        if (not isinstance(floors, dict) or set(floors) != FLOOR_KEYS or
                any(type(value) is not int or value <= 0 for value in floors.values())):
            raise ValueError("resource floors must be positive integer byte configuration")
        if not isinstance(native_profile, dict) or set(native_profile) != PROFILE_KEYS:
            raise ValueError("complete registered native profile required")
        if type(interval_s) not in (int, float) or not 0 < interval_s <= 60:
            raise ValueError("invalid monitor interval")
        self.floors, self.profile = dict(floors), copy.deepcopy(native_profile)
        self.host = host if host is not None else lambda: measure_host(root, temporary)
        self.docker, self.interval = docker, interval_s
        self.out = self.image = self.server = self.proc = self.cid = self.name = None
        self.errors, self.public_captures = [], []
        self.probes, self.oom = 0, 0
        self.finished = False
        self.stop = threading.Event()
        self.lock = threading.RLock()
        self.thread = None

    def _save(self, name, value):
        (self.out / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")

    def bind(self, *, out, image, server):
        if self.out is not None:
            raise ValueError("supervisor already bound")
        self.out = Path(out).resolve(strict=True)
        self.image, self.server = image, server
        server.request_guard = self.guard
        self.sample("initial-host", discover=False)
        self.check()
        self.thread = threading.Thread(target=self._watch, daemon=True)
        self.thread.start()

    def stop_monitor(self):
        self.stop.set()
        if self.thread is not None and self.thread is not threading.current_thread():
            self.thread.join(timeout=45)
            if self.thread.is_alive():
                self._fault("resource monitor did not stop")

    def _watch(self):
        while not self.stop.wait(self.interval):
            self.sample("periodic")
            if self.errors:
                return

    def _fault(self, message):
        if message not in self.errors:
            self.errors.append(message)
        self.stop.set()
        if self.proc is not None and self.proc.poll() is None:
            try:
                os.killpg(self.proc.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            except OSError as exc:
                self.errors.append("owned client abort failed: " + str(exc))
        if self.cid is not None:
            try:
                result = self.docker(["kill", self.cid])
                if result.returncode:
                    self.errors.append("owned native abort failed")
            except Exception as exc:
                self.errors.append("owned native abort failed: " + str(exc))

    def check(self):
        if self.errors:
            raise ValueError("runtime supervision failed: " + "; ".join(self.errors))

    def guard(self):
        self.sample("before-provider-request")
        self.check()

    def client_started(self, proc):
        if self.proc is not None or not isinstance(proc, subprocess.Popen):
            raise ValueError("one actual Popen is required for client ownership")
        argv = json.loads((self.out / "launch.json").read_text())["argv"]
        if proc.poll() is not None or proc.args != argv or os.getpgid(proc.pid) != proc.pid:
            raise ValueError("client ownership or argv mismatch")
        self.proc = proc
        self._save("client-ownership.json", {"pid": proc.pid, "pgid": proc.pid, "argv": argv})
        self.check()

    def _identify(self, required):
        live = []
        names = set()
        for path in sorted(self.out.glob("mcp-launch-*.json")):
            if path.is_symlink() or not path.is_file():
                raise ValueError("native launch is not a host regular record")
            name = json.loads(path.read_text())["name"]
            if not isinstance(name, str) or not re.fullmatch(r"hfa-native-[0-9a-f]{32}", name):
                raise ValueError("native launch name invalid")
            names.add(name)
        if len(names) > 1:
            raise ValueError("multiple declared native worker launches")
        for name in sorted(names):
            result = self.docker(["inspect", name])
            with (self.out / "native-inspections.jsonl").open("a") as trace:
                trace.write(json.dumps({"time": time.time(), "name": name,
                    "exit_code": result.returncode, "stdout": result.stdout, "stderr": result.stderr}) + "\n")
            if result.returncode:
                absent = r"(?:error(?: response from daemon)?:\s*)?no such (?:object|container):\s*" + re.escape(name)
                if re.fullmatch(absent, result.stderr.strip(), re.IGNORECASE):
                    continue
                raise ValueError("native inspection failed")
            rows = json.loads(result.stdout)
            if not isinstance(rows, list) or len(rows) != 1:
                raise ValueError("native inspection ambiguous")
            row = rows[0]
            if row.get("State", {}).get("Running") is True:
                live.append((name, row))
        if not live:
            if required or self.cid is not None:
                raise ValueError("owned native worker missing")
            return None
        if len(live) != 1:
            raise ValueError("multiple live native workers")
        name, row = live[0]
        cid = row.get("Id")
        if (not isinstance(cid, str) or not re.fullmatch(r"[0-9a-f]{64}", cid)
                or row.get("Image") != self.image or row.get("Name") != "/" + name
                or row.get("Config", {}).get("Labels", {}).get("codescout.hfa") != name
                or row.get("Config", {}).get("User") != "1000:1000"
                or any(row.get("HostConfig", {}).get(key) != value for key, value in self.profile.items())):
            raise ValueError("native identity or registered resource profile mismatch")
        if self.cid is not None and (self.cid != cid or self.name != name):
            raise ValueError("immutable native worker identity changed")
        # Only the fully checked identity grants authority to abort this container.
        self.cid, self.name = cid, name
        if row["State"].get("OOMKilled") is not False or row["State"].get("Error"):
            raise ValueError("native runtime error or OOM")
        return row

    def sample(self, phase, *, discover=True, required=False):
        with self.lock:
            row = {"time": time.time(), "monotonic": time.monotonic(), "phase": phase}
            try:
                host = self.host()
                row["host"] = host
                if (not isinstance(host, dict) or host.get("tmp_exec") is not True or
                        any(type(host.get(key)) is not int or host[key] < floor
                            for key, floor in self.floors.items())):
                    raise ValueError("host floor or executable temporary storage invalid")
                info = self._identify(required) if discover else None
                if info is not None:
                    row["container"] = info
                    result = self.docker(["exec", self.cid, "cat", "/sys/fs/cgroup/memory.events"])
                    if result.returncode:
                        raise ValueError("native cgroup probe failed")
                    pairs = [line.split() for line in result.stdout.splitlines()]
                    if any(len(pair) != 2 for pair in pairs):
                        raise ValueError("malformed cgroup counters")
                    events = {key: int(value) for key, value in pairs}
                    if len(events) != len(pairs) or "oom_kill" not in events or any(value < 0 for value in events.values()):
                        raise ValueError("unknown cgroup counters")
                    row["memory_events"] = events
                    self.probes += 1
                    self.oom = max(self.oom, events["oom_kill"] + events.get("oom_group_kill", 0))
                    if self.oom:
                        raise ValueError("native OOM kill observed")
            except Exception as exc:
                row["error"] = type(exc).__name__ + ": " + str(exc)
                self._fault(row["error"])
            finally:
                try:
                    with (self.out / "resource-samples.jsonl").open("a") as stream:
                        stream.write(json.dumps(row, sort_keys=True) + "\n")
                        stream.flush()
                except Exception as exc:
                    self._fault("cannot preserve resource sample: " + str(exc))

    def proof(self):
        return {"complete": not self.errors and self.probes >= 2 and self.finished,
                "resource_ok": not self.errors, "cgroup_probes": self.probes,
                "oom_kill": self.oom, "errors": list(self.errors), "container_id": self.cid,
                "container_name": self.name, "finished": self.finished,
                "floors": dict(self.floors), "native_profile": copy.deepcopy(self.profile),
                "nominal_interval_s": self.interval,
                "limits": "Sampled host and owned cgroup observations, not a continuous guarantee or peer census."}

    def before_public(self):
        self.sample("before-public", required=True)
        self.check()

    def after_public(self, command, log, code):
        self.sample("after-public", required=True)
        self.check()
        try:
            log = Path(log)
            if (log.is_symlink() or not log.is_file() or
                    not log.resolve().is_relative_to(self.out) or type(code) is not int):
                raise ValueError("public capture is not an owned complete regular file")
            size = log.stat().st_size
            if size > 64 * 1024 * 1024:
                raise ValueError("public capture exceeds full-log bound")
            raw = log.read_bytes()
            if len(raw) != size or log.stat().st_size != size:
                raise ValueError("public capture changed during preservation")
            self.public_captures.append({"command": command, "log": str(log), "exit_code": code,
                "bytes": size, "sha256": hashlib.sha256(raw).hexdigest()})
            self._save("public-resource-captures.json", self.public_captures)
        except Exception as exc:
            self._fault(type(exc).__name__ + ": " + str(exc))
            raise

    def finish(self):
        if self.finished:
            self.check()
            return
        self.stop_monitor()
        self.sample("final", required=True)
        self.finished = True
        proof = self.proof()
        self._save("supervision-final.json", proof)
        if not proof["complete"]:
            raise ValueError("final resource proof incomplete: " + "; ".join(self.errors))
