"""Sixteen-slot orchestration tests with physical captures and a scripted boundary."""
import copy
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import unittest

import campaign
from receipts import input_digest, publish_exclusive
from test_feedback_admission import registration

try:
    import feedback_runner as subject
except ModuleNotFoundError as exc:
    if exc.name != "feedback_runner":
        raise
    subject = None


class Boundary:
    mode = "scripted"

    def __init__(self, root):
        self.root, self.calls, self.grades, self.events = root, [], [], []
        self.hook = self.grade_hook = None

    def verify(self, reg):
        self.registration = copy.deepcopy(reg)
        return {"ready": True, "mode": "scripted"}

    def invoke(self, packet, out):
        self.calls.append(copy.deepcopy(packet))
        self.events.append("actor")
        candidate = out / "candidate"
        shutil.copytree(packet["source"], candidate)
        (candidate / "code.rs").write_text("pub fn repaired() {}")
        state = dict(packet["state"], phase="closed", turns_used=5, source_digest=input_digest(candidate))
        record = {"invocation_id": packet["invocation_id"], "cost_usd": "0.10", "cost_is_final": True,
                  "context_valid": True, "capture_complete": True, "cleanup_complete": True,
                  "measurement_invalid": False, "candidate": str(candidate), "source_digest": input_digest(candidate),
                  "state": state, "turns": 5, "public_artifact": None, "reason": None,
                  "workflow_completed": True, "public_verification": {"passed": True},
                  "lifecycle": {"status": "settled", "continuations": 4}}
        if self.hook:
            self.hook(packet, out, record)
        publish_exclusive(out / "invocation.json", record)
        return record

    def grade(self, packet, out):
        self.events.append("grade")
        self.grades.append(copy.deepcopy(packet))
        closed = json.loads((self.root / "actor-batch-closed.json").read_bytes())
        if len(closed["attempts"]) + len(closed["unexecuted"]) != 16:
            raise AssertionError("grading before complete schedule closure")
        subject.verify_closed(self.registration, self.root, closed)
        if self.grade_hook:
            self.grade_hook(packet, out)
        verdict = {"valid": True, "pass": True}
        publish_exclusive(out / "verdict.json", verdict)
        return verdict


class FeedbackRunnerTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(subject, "repair-only controller is not implemented")
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.reg = registration(self.root)
        self.reg["selected"] = campaign.selection_report(
            self.reg["metadata"], set(), self.reg["seed"], task_count=4)["selected"]
        import feedback_policy
        self.reg["schedule"] = [dict(row, cli_cap_usd=feedback_policy.condition_spec(row["arm"], ".")["cli_cap_usd"],
                                    reserved_usd=feedback_policy.condition_spec(row["arm"], ".")["reserve_usd"])
                               for row in feedback_policy.balanced_schedule(
                                   [r["id"] for r in self.reg["selected"]], self.reg["order_seed"])]
        self.out = Path(self.reg["output_root"])
        self.bound = self.root / "frozen-runtime"
        self.bound.write_text("frozen runtime")
        self.hold = self.root / "unknown-old-client.json"
        self.hold.write_text(json.dumps({"session_id": "old", "scripted": False,
            "cost_usd": None, "unknown_provider_cost": True, "requests": 0, "forwarded": 0,
            "campaign_available_usd": "4"}))
        self.reg["bindings"] = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in (self.bound, self.hold)}
        held = {"id": "native-client:old", "source": str(self.hold),
                "receipt_sha256": self.reg["bindings"][str(self.hold)], "reserved_usd": "4",
                "settled": False, "cost_usd": None}
        self.reg["ledger"] = {"ceiling_usd": "200", "charges": [], "holds": [held], "reservations": []}
        self.reg["carried_holds"] = [{k: held[k] for k in ("id", "source", "receipt_sha256", "reserved_usd")}]
        self.backend = Boundary(self.out)

    def test_sixteen_repair_actors_and_costs_freeze_before_sixteen_grades(self):
        result = subject.run_campaign(self.reg, self.backend)
        self.assertEqual(result["status"], "completed")
        self.assertEqual(len(result["attempts"]), 16)
        self.assertEqual(self.backend.events, ["actor"] * 16 + ["grade"] * 16)
        self.assertTrue(all(c["phase"] == "repair" and c["max_continuations"] == 4 for c in self.backend.calls))
        closed = json.loads((self.out / "actor-batch-closed.json").read_bytes())
        self.assertEqual(len(closed["attempts"]), 16)
        self.assertEqual(closed["unexecuted"], [])
        ledger = json.loads((self.out / "ledger-final.json").read_bytes())
        self.assertEqual(campaign.accounting_totals(ledger)["committed_usd"], "5.60")
        self.assertEqual(ledger["holds"], self.reg["ledger"]["holds"])
        self.assertEqual(ledger["reservations"], [])
        self.assertEqual(result["analysis"]["pairs"]["P-L"], {"wins": 0, "losses": 0, "ties": 4})
        self.assertEqual(result["analysis"]["paired_observations"]["P-R"], 4)
        self.assertEqual(result["analysis"]["decision"], "NO-GO")

    def test_reservation_is_108_for_actors_plus_4_setup_and_preserves_old_4(self):
        checked = subject.preflight(self.reg, self.backend)
        self.assertTrue(checked["ready"])
        self.assertFalse(checked["paid_ready"])
        self.assertEqual(campaign.accounting_totals(checked["reserved_ledger"])["committed_usd"], "116")
        self.assertEqual(len(checked["reserved_ledger"]["reservations"]), 17)

    def test_incomplete_candidate_is_still_graded_and_its_cost_is_not_dropped(self):
        def incomplete(packet, out, record):
            if packet["arm"] == "P":
                record["state"]["phase"] = "incomplete"
                record["workflow_completed"] = False
                record["lifecycle"] = {"status": "incomplete", "continuations": 4, "error": "bounded runtime"}
        self.backend.hook = incomplete
        result = subject.run_campaign(self.reg, self.backend)
        self.assertEqual(len(self.backend.grades), 16)
        self.assertTrue(all(row["grade"]["pass"] for row in result["attempts"]))
        self.assertEqual(result["analysis"]["totals"]["P"]["client_cost_usd"], "0.40")
        self.assertEqual(result["analysis"]["totals"]["P"]["completed"], 0)
        self.assertEqual(len(result["analysis"]["pairs"]), 5)
        self.assertEqual(result["analysis"]["decision"], "NO-GO")
        self.assertTrue(all(row["native_lifecycle"]["error"] == "bounded runtime"
                            for row in result["attempts"] if row["arm"] == "P"))

    def test_unknown_charge_stops_later_actors_and_keeps_its_reservation(self):
        def unknown(packet, out, record):
            record["cost_is_final"] = False
            record["cost_usd"] = None
        self.backend.hook = unknown
        result = subject.run_campaign(self.reg, self.backend)
        self.assertEqual(result["status"], "stopped")
        self.assertEqual(len(self.backend.calls), 1)
        self.assertEqual(len(result["unexecuted"]), 15)
        ledger = json.loads((self.out / "ledger-final.json").read_bytes())
        totals = campaign.accounting_totals(ledger)
        self.assertEqual(totals["unknown_charge_ids"], [self.reg["campaign_id"] + "::0::repair"])
        current = next(row for row in ledger["reservations"] if row["id"] == self.reg["campaign_id"] + "::0")
        self.assertEqual(current["reserved_usd"], self.reg["schedule"][0]["reserved_usd"])
        self.assertEqual(ledger["holds"], self.reg["ledger"]["holds"])
        self.assertIsNone(result["analysis"]["selected"])
        self.assertFalse(result["analysis"]["interpretable"])

    def test_unverified_cleanup_defers_all_private_grading(self):
        def bad_cleanup(packet, out, record):
            record["cleanup_complete"] = False
        self.backend.hook = bad_cleanup
        result = subject.run_campaign(self.reg, self.backend)
        self.assertEqual(result["status"], "stopped")
        self.assertEqual(self.backend.grades, [])
        self.assertFalse((self.out / "actor-batch-closed.json").exists())
        self.assertIn("closure", result)

    def test_changed_runtime_stops_without_more_actors_or_private_feedback(self):
        def change(packet, out, record):
            self.bound.write_text("changed runtime")
        self.backend.hook = change
        result = subject.run_campaign(self.reg, self.backend)
        self.assertEqual(result["status"], "stopped")
        self.assertEqual(len(self.backend.calls), 1)
        self.assertEqual(self.backend.grades, [])
        self.assertEqual(result["attempts"][0]["cost"]["known_usd"], "0.10")

    def test_existing_campaign_cannot_restart_a_paid_or_scripted_attempt(self):
        subject.run_campaign(self.reg, self.backend)
        before = len(self.backend.calls)
        self.assertFalse(subject.preflight(self.reg, self.backend)["ready"])
        with self.assertRaises(ValueError):
            subject.run_campaign(self.reg, self.backend)
        self.assertEqual(len(self.backend.calls), before)

    def test_drift_during_grading_is_retained_and_stops_the_remaining_grades(self):
        def change(packet, out):
            (Path(packet["source"]) / "code.rs").write_text("late drift")
        self.backend.grade_hook = change
        result = subject.run_campaign(self.reg, self.backend)
        self.assertEqual(result["status"], "grading_stopped")
        self.assertEqual(len(self.backend.calls), 16)
        self.assertEqual(len(self.backend.grades), 1)
        self.assertIsNone(result["analysis"]["selected"])
        self.assertEqual(result["analysis"]["pairs"]["P-L"], {"wins": 0, "losses": 0, "ties": 0})

    def test_all_private_verdicts_are_unknown_if_no_grade_was_observed(self):
        self.backend.grade_hook = lambda packet, out: (_ for _ in ()).throw(RuntimeError("grader unavailable"))
        result = subject.run_campaign(self.reg, self.backend)
        self.assertFalse(result["analysis"]["interpretable"])
        self.assertTrue(all(value["raw_accepted"] == 0 and value["graded"] == 0
                            for value in result["analysis"]["totals"].values()))
        self.assertEqual(result["analysis"]["paired_observations"]["R-L"], 0)

    def test_noncompleted_campaign_cannot_advance_even_with_complete_synthetic_grades(self):
        rows = []
        for task in range(4):
            for arm, accepted, cost in [("L", task == 0, "0.1"), ("R", task < 2, "0.2"),
                                        ("P", task < 3, "0.3"), ("X", task < 2, "0.4")]:
                rows.append({"task_id": str(task), "arm": arm, "workflow_state": "closed",
                             "measurement_invalid": False, "cost": {"known_usd": cost, "unknown": False},
                             "grade": {"valid": True, "pass": accepted}})
        result = {"status": "grading_stopped", "reason": "unfinished control", "attempts": rows,
                  "setup_cost_usd": "0", "unexecuted": []}
        report = subject.analyze_result(result)
        self.assertFalse(report["interpretable"])
        self.assertIsNone(report["selected"])
        self.assertEqual(report["pairs"]["R-L"], {"wins": 1, "losses": 0, "ties": 3})

    def test_replayed_analysis_reopens_private_verdicts_instead_of_trusting_result_copy(self):
        result = subject.run_campaign(self.reg, self.backend)
        self.assertEqual(subject.analyze(self.reg, str(self.out))["totals"]["L"]["accepted"], 4)
        result["attempts"][0]["grade"]["pass"] = False
        (self.out / "result.json").write_text(json.dumps(result))
        with self.assertRaises(ValueError):
            subject.analyze(self.reg, str(self.out))

    def test_paid_flag_cannot_promote_a_scripted_boundary(self):
        self.reg["mode"] = "paid"
        self.backend.mode = "paid"
        self.assertFalse(subject.preflight(self.reg, self.backend)["ready"])

    def test_native_grading_barrier_consumes_sixteen_slot_closure_and_rejects_truncation(self):
        from unittest.mock import patch
        import native_campaign
        subject.run_campaign(self.reg, self.backend)
        reg = copy.deepcopy(self.reg)
        for task in reg["tasks"].values():
            task["backend"]["scripted_plans"] = {arm + ":repair": [] for arm in "LRPX"}
        with patch.object(native_campaign, "_verify_public", return_value={"ready": True}), \
             patch.object(native_campaign, "_verify_private", return_value={"ready": True}):
            backend = native_campaign.NativeCampaignBackend(mode="scripted")
            backend.verify(reg)
        self.assertEqual(len(backend._closed()["attempts"]), 16)
        path = self.out / "actor-batch-closed.json"
        closed = json.loads(path.read_bytes())
        closed["attempts"].pop()
        path.write_text(json.dumps(closed))
        with self.assertRaises(ValueError):
            backend._closed()


if __name__ == "__main__":
    unittest.main()
