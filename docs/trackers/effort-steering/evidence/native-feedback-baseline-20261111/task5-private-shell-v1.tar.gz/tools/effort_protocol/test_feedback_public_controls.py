"""New public admission must establish both compile scopes on base and gold reference."""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import feedback_admission as subject
from receipts import input_digest

GOLD = """diff --git a/lib.rs b/lib.rs
index 3367afd..3e75765 100644
--- a/lib.rs
+++ b/lib.rs
@@ -1 +1 @@
-before
+after
"""

class FeedbackPublicControlTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.base = self.root / "base"
        self.reference = self.root / "reference"
        for path, content in ((self.base, "before\n"), (self.reference, "after\n")):
            path.mkdir()
            (path / "Cargo.toml").write_text("[workspace]\n")
            (path / "lib.rs").write_text(content)
        self.reg = {"bindings": {}, "tasks": {}}
        record = self.bound("private-record.json", {"patch": GOLD})
        config = self.bound("private-config.json", {"record": record["path"]})
        self.commands = [{"argv": ["cargo", "check", "--offline", "--workspace"] + extra,
            "cwd": ".", "test_files": ["Cargo.toml"]} for extra in ([], ["--all-targets"])]
        self.reg["tasks"]["task"] = {"source": str(self.base), "source_sha256": input_digest(self.base),
            "backend": {"public": {"feedback_policy": {"workspace": "."}, "public_checks": self.commands,
                "execution_profile": "cargo-v2"}, "private": {"config": config["path"],
                "config_sha256": config["sha256"]}}}
        self.facts = {"complete": True, "resource_valid": True, "exit_code": 0}
        self.proof = {"task": {"baseline": self.rows("baseline", self.base),
            "reference": {"source": str(self.reference), "source_sha256": input_digest(self.reference),
                "record_sha256": record["sha256"], "commands": self.rows("reference", self.reference)}}}

    def bound(self, name, value):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value))
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        self.reg["bindings"][str(path)] = digest
        return {"path": str(path), "sha256": digest}

    def rows(self, state, source):
        result = []
        for index, command in enumerate(self.commands):
            prefix = "evidence/" + state + "/" + str(index) + "/"
            result.append({"registration": self.bound(prefix + "registration.json",
                {"request": {"id": "public-" + str(index), **command}, "source": str(source),
                    "source_digest": input_digest(source)}),
                "result": self.bound(prefix + "result.json", {**self.facts, "receipt": self.facts})})
        return result

    def invoke(self, proof=None):
        with patch.object(subject.legacy, "verify_receipt", return_value=self.facts) as verifier:
            result = subject.verify_public_commands(self.reg, self.proof if proof is None else proof)
        return result, verifier

    def test_legacy_baseline_only_shape_cannot_satisfy_the_new_role(self):
        with self.assertRaises(ValueError):
            self.invoke({"task": self.proof["task"]["baseline"]})

    def test_two_exact_scopes_on_both_actual_sources_are_reopened(self):
        result, verifier = self.invoke()
        self.assertEqual(result["task"]["baseline"]["verified_commands"], 2)
        self.assertEqual(result["task"]["reference"]["verified_commands"], 2)
        self.assertEqual(verifier.call_count, 4)
        self.assertEqual([call.args[2] for call in verifier.call_args_list],
            [self.base, self.base, self.reference, self.reference])

    def test_missing_scope_reference_or_different_commands_are_rejected(self):
        for case in ("reference", "baseline-scope", "reference-scope", "no-op", "different-cwd"):
            with self.subTest(case=case):
                proof = copy.deepcopy(self.proof)
                commands = copy.deepcopy(self.commands)
                self.reg["tasks"]["task"]["backend"]["public"]["public_checks"] = commands
                if case == "reference": del proof["task"]["reference"]
                elif case == "baseline-scope": proof["task"]["baseline"].pop()
                elif case == "reference-scope": proof["task"]["reference"]["commands"].pop()
                elif case == "no-op": commands[1]["argv"] = ["true"]
                else: commands[1]["cwd"] = "other"
                with self.assertRaises(ValueError):
                    self.invoke(proof)
        self.reg["tasks"]["task"]["backend"]["public"]["public_checks"] = self.commands

    def test_reference_is_derived_from_the_bound_private_gold_not_a_named_directory(self):
        for case in ("baseline", "wrong-code", "wrong-record"):
            with self.subTest(case=case):
                proof = copy.deepcopy(self.proof)
                if case == "baseline":
                    proof["task"]["reference"].update(source=str(self.base), source_sha256=input_digest(self.base))
                elif case == "wrong-code":
                    (self.reference / "lib.rs").write_text("unrelated\n")
                    proof["task"]["reference"]["source_sha256"] = input_digest(self.reference)
                    proof["task"]["reference"]["commands"] = self.rows("wrong-reference", self.reference)
                else:
                    proof["task"]["reference"]["record_sha256"] = "0" * 64
                with self.assertRaises(ValueError):
                    self.invoke(proof)
                (self.reference / "lib.rs").write_text("after\n")

    def test_reference_receipts_cannot_be_borrowed_from_baseline_or_hide_failure(self):
        proof = copy.deepcopy(self.proof)
        proof["task"]["reference"]["commands"] = proof["task"]["baseline"]
        with self.assertRaises(ValueError):
            self.invoke(proof)
        proof = copy.deepcopy(self.proof)
        proof["task"]["reference"]["commands"][1]["result"] = self.bound(
            "failed-reference/result.json", {**self.facts, "exit_code": 101, "receipt": self.facts})
        with self.assertRaises(ValueError):
            self.invoke(proof)

    def test_record_config_and_reference_drift_are_reopened(self):
        for path in (self.root / "private-record.json", self.root / "private-config.json",
                     self.reference / "lib.rs"):
            with self.subTest(path=path.name):
                before = path.read_bytes()
                path.write_bytes(before + b"\n")
                with self.assertRaises(ValueError):
                    self.invoke()
                path.write_bytes(before)

    def test_malformed_proofs_fail_as_value_errors(self):
        for proof in (None, [], {"task": None}, {"task": {}}, {"task": {"baseline": [], "reference": None}}):
            with self.subTest(proof=proof), self.assertRaises(ValueError):
                # invoke(None) means the normal proof, so call directly here.
                subject.verify_public_commands(self.reg, proof)

if __name__ == "__main__":
    unittest.main()
