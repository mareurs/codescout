"""Public fixture contracts: real bytes, custody and process exit semantics."""
import copy
import importlib.util
import json
import os
from pathlib import Path
import socket
import uuid
import subprocess
import sys
import tempfile
import time
import unittest

MODULE = Path(__file__).with_name("public_fixture.py")


class PublicFixtureTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="public-fixture-test-")
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        self.spec = {
            "version": "public-http-fixture-v1",
            "hostname": "fixture.sample.test",
            "port": port,
            "routes": {
                "/": {"status": 200, "content_type": "text/plain; charset=utf-8",
                      "body": "frozen public café\n"},
                "/extra": {"status": 201, "content_type": "text/plain", "body": "extra"},
            },
        }

    def bundle(self, name="bundle", spec=None):
        source = self.root / (name + ".json")
        source.write_text(json.dumps(self.spec if spec is None else spec))
        target = self.root / name
        result = subprocess.run(
            [sys.executable, "-I", "-B", str(MODULE), "bundle", str(target), str(source)],
            capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 0, result.stderr)
        descriptor = json.loads(result.stdout)
        loaded = importlib.util.spec_from_file_location("public_fixture_under_test", MODULE)
        self.api = importlib.util.module_from_spec(loaded)
        loaded.loader.exec_module(self.api)
        return target, descriptor

    def runtime(self, target):
        return {
            "HostConfig": {"ExtraHosts": ["fixture.sample.test:127.0.0.1"]},
            "Config": {"Entrypoint": ["/bench/public-fixture/launch-command"]},
            "Mounts": [
                {"Type": "bind", "Source": str(target),
                 "Destination": "/bench/public-fixture", "RW": False},
                {"Type": "bind", "Source": "/tmp/source", "Destination": "/testbed", "RW": False},
            ],
        }

    def test_roundtrip_and_location_independent_fingerprint(self):
        first, a = self.bundle("a")
        _, b = self.bundle("b")
        self.assertEqual(a["fingerprint"], b["fingerprint"])
        self.assertEqual(self.api.read_fixture_bundle(a), self.spec)
        self.assertEqual(set(p.name for p in first.iterdir()),
                         {"public_fixture.py", "launch-native", "launch-command",
                          "spec.json", "manifest.json"})
        self.assertNotEqual(a["root"], b["root"])

    def test_changed_payload_code_manifest_mode_and_extra_file_are_rejected(self):
        target, desc = self.bundle()
        for name in ("spec.json", "public_fixture.py", "launch-command", "manifest.json"):
            path = target / name
            original = path.read_bytes()
            with self.subTest(name=name):
                path.write_bytes(original + b"\n")
                with self.assertRaises(ValueError):
                    self.api.read_fixture_bundle(desc)
                path.write_bytes(original)
        (target / "surprise").write_text("not registered")
        with self.assertRaises(ValueError):
            self.api.read_fixture_bundle(desc)
        (target / "surprise").unlink()
        launcher = target / "launch-command"
        launcher.chmod(0o644)
        with self.assertRaises(ValueError):
            self.api.read_fixture_bundle(desc)

    def test_invalid_spec_does_not_create_output(self):
        _, _ = self.bundle()
        bads = []
        for key, value in (("port", True), ("port", 80), ("port", 65536),
                           ("hostname", "example.com"), ("hostname", "fixture.real.com"),
                           ("hostname", "fixture.a.test\nother"), ("extra", "unknown")):
            bad = copy.deepcopy(self.spec)
            bad[key] = value
            bads.append(bad)
        for route in ({"status": True, "content_type": "text/plain", "body": "x"},
                      {"status": 200, "content_type": "text/plain\r\nBad: y", "body": "x"},
                      {"status": 200, "content_type": "text/plain", "body": "x", "file": "/etc/passwd"}):
            bad = copy.deepcopy(self.spec)
            bad["routes"]["/"] = route
            bads.append(bad)
        for index, bad in enumerate(bads):
            out = self.root / f"invalid-{index}"
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                self.api.create_fixture_bundle(out, bad)
            self.assertFalse(out.exists())

    def test_symlink_file_root_and_parent_are_rejected(self):
        target, desc = self.bundle()
        payload = target / "spec.json"
        original = payload.read_bytes()
        outside = self.root / "outside"
        outside.write_bytes(original)
        payload.unlink()
        payload.symlink_to(outside)
        with self.assertRaises(ValueError):
            self.api.read_fixture_bundle(desc)
        payload.unlink()
        payload.write_bytes(original)
        alias = self.root / "alias"
        alias.symlink_to(target, target_is_directory=True)
        bad = dict(desc, root=str(alias))
        with self.assertRaises(ValueError):
            self.api.read_fixture_bundle(bad)
        parent = self.root / "parent"
        parent.symlink_to(self.root, target_is_directory=True)
        with self.assertRaises(ValueError):
            self.api.read_fixture_bundle(dict(desc, root=str(parent / "bundle")))
        with self.assertRaises(ValueError):
            self.api.create_fixture_bundle(parent / "new", self.spec)
        self.assertFalse((self.root / "new").exists())

    def test_descriptor_tampering_is_rejected(self):
        _, desc = self.bundle()
        for bad in (dict(desc, fingerprint="0" * 64), dict(desc, extra=True),
                    dict(desc, files={}), None, []):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                self.api.read_fixture_bundle(bad)

    def test_runtime_requires_exact_readonly_mount_hostname_and_launcher(self):
        target, desc = self.bundle()
        row = self.runtime(target)
        bound = self.api.validate_fixture_runtime(row, desc, "command")
        self.assertEqual(bound["fingerprint"], desc["fingerprint"])
        options = self.api.fixture_docker_options(desc, "command")
        self.assertIn("fixture.sample.test:127.0.0.1", options)
        self.assertIn("/bench/public-fixture/launch-command", options)
        cases = []
        bad = copy.deepcopy(row); bad["Mounts"][0]["RW"] = True; cases.append(bad)
        bad = copy.deepcopy(row); bad["Mounts"][0]["Source"] = "/tmp/wrong"; cases.append(bad)
        bad = copy.deepcopy(row); bad["HostConfig"]["ExtraHosts"] += ["example.com:127.0.0.1"]; cases.append(bad)
        bad = copy.deepcopy(row); bad["Config"]["Entrypoint"] = ["/bin/sh"]; cases.append(bad)
        for dest in ("/bench", "/bench/public-fixture/spec.json"):
            bad = copy.deepcopy(row)
            bad["Mounts"].append({"Type": "bind", "Source": "/tmp/other", "Destination": dest, "RW": False})
            cases.append(bad)
        for bad in cases:
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                self.api.validate_fixture_runtime(bad, desc, "command")
        with self.assertRaises(ValueError):
            self.api.fixture_docker_options(desc, "other")

    def launch(self, target, argv, cwd=None):
        return subprocess.run([str(target / "launch-command"), *argv],
                              cwd=cwd, capture_output=True, text=True, timeout=15)

    def test_launch_serves_bytes_preserves_argv_cwd_stdout_and_nonzero_exit(self):
        target, _ = self.bundle()
        # Removing readiness or replacing exec with success would fail this assertion.
        program = (
            "import json,os,sys,urllib.request;"
            f"u='http://127.0.0.1:{self.spec['port']}';"
            "print(json.dumps([os.getcwd(),sys.argv[1:],"
            "urllib.request.urlopen(u).read().decode(),"
            "urllib.request.urlopen(u+'/extra').status]));"
            "sys.exit(7)"
        )
        literal = "space ; $(echo should-not-run)"
        result = self.launch(target, [sys.executable, "-I", "-c", program, literal], self.root)
        self.assertEqual(result.returncode, 7, result.stderr)
        self.assertEqual(json.loads(result.stdout),
                         [str(self.root), [literal], "frozen public café\n", 201])
        self.assertIn("public-fixture-ready", result.stderr)
        # The fixture cannot remain an orphan after its exec'd owner exits.
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline:
            with socket.socket() as probe:
                if probe.connect_ex(("127.0.0.1", self.spec["port"])) != 0:
                    break
            time.sleep(.05)
        else:
            self.fail("fixture survived its owner")

    def test_occupied_port_refuses_before_command_even_if_other_server_exists(self):
        target, _ = self.bundle()
        sentinel = self.root / "ran"
        with socket.socket() as occupied:
            occupied.bind(("127.0.0.1", self.spec["port"]))
            occupied.listen()
            result = self.launch(target, [sys.executable, "-c",
                                         f"from pathlib import Path;Path({str(sentinel)!r}).touch()"])
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("public-fixture-failed", result.stderr)
        self.assertFalse(sentinel.exists())
        self.assertEqual(result.stdout, "")

    @unittest.skipUnless(os.environ.get("EFFORT_FIXTURE_TEST_IMAGE"),
                         "set a pinned local Docker image for native qualification")
    def test_actual_docker_loopback_bytes_alias_readonly_mount_and_exit(self):
        target, desc = self.bundle()
        image = os.environ["EFFORT_FIXTURE_TEST_IMAGE"]
        self.assertRegex(image, r"^sha256:[0-9a-f]{64}$")
        name = "public-fixture-test-" + uuid.uuid4().hex
        args = ["docker", "create", "--pull", "never", "--name", name,
                "--label", "codescout.public-fixture-test=true",
                "--network", "none", "--read-only", "--user", "1000:1000",
                "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
                "--tmpfs", "/tmp:rw,exec,size=64m,mode=1777",
                *self.api.fixture_docker_options(desc, "command"), image,
                "python3", "-I", "-c",
                "import socket,urllib.request,sys;"
                "print(socket.gethostbyname('fixture.sample.test'));"
                f"print(urllib.request.urlopen('http://127.0.0.1:{self.spec['port']}/').read().decode(),end='');"
                "sys.exit(9)"]
        created = subprocess.run(args, capture_output=True, text=True, timeout=30)
        self.assertEqual(created.returncode, 0, created.stderr)
        cid = created.stdout.strip()
        try:
            before = subprocess.run(["docker", "inspect", cid], capture_output=True, text=True, timeout=10)
            self.assertEqual(before.returncode, 0, before.stderr)
            self.api.validate_fixture_runtime(json.loads(before.stdout)[0], desc, "command")
            result = subprocess.run(["docker", "start", "--attach", cid],
                                    capture_output=True, text=True, timeout=30)
            self.assertEqual(result.returncode, 9, result.stderr)
            self.assertEqual(result.stdout, "127.0.0.1\nfrozen public café\n")
            self.assertTrue(result.stderr.startswith("public-fixture-ready "), result.stderr)
            final = subprocess.run(["docker", "inspect", cid], capture_output=True, text=True, timeout=10)
            self.assertEqual(final.returncode, 0, final.stderr)
            row = json.loads(final.stdout)[0]
            self.assertEqual(row["State"]["ExitCode"], 9)
            self.assertFalse(row["State"]["OOMKilled"])
            self.api.validate_fixture_runtime(row, desc, "command")
        finally:
            removed = subprocess.run(["docker", "rm", "--force", "--volumes", cid],
                                     capture_output=True, text=True, timeout=30)
            self.assertEqual(removed.returncode, 0, removed.stderr)
            absent = subprocess.run(["docker", "inspect", cid], capture_output=True, text=True, timeout=10)
            self.assertNotEqual(absent.returncode, 0)

    @unittest.skipUnless(os.environ.get("EFFORT_FIXTURE_TEST_IMAGE"),
                         "set a pinned local Docker image for native qualification")
    def test_actual_native_dispatch_preserves_argv_cwd_exit_and_refuses_bad_startup(self):
        target, desc = self.bundle()
        image = os.environ["EFFORT_FIXTURE_TEST_IMAGE"]
        self.assertRegex(image, r"^sha256:[0-9a-f]{64}$")
        self.root.chmod(0o755)
        binary = self.root / "codescout"
        binary.write_text("#!/usr/bin/env python3\nimport json,os,sys\n"
                          "print(json.dumps({'argv':sys.argv,'cwd':os.getcwd()},sort_keys=True))\n"
                          "sys.exit(19)\n")
        binary.chmod(0o555)
        original = (target / "spec.json").read_bytes()
        for bad_startup in (False, True):
            with self.subTest(bad_startup=bad_startup):
                name = "public-fixture-native-test-" + uuid.uuid4().hex
                created = subprocess.run(
                    ["docker", "create", "--pull=never", "--name", name,
                     "--label", "codescout.public-fixture-test=true", "--network", "none",
                     "--read-only", "--user", "1000:1000", "--cap-drop=ALL",
                     "--security-opt", "no-new-privileges", "--workdir", "/tmp",
                     "--tmpfs", "/tmp:rw,exec,size=64m,mode=1777",
                     "--mount", "type=bind,src=" + str(binary) + ",dst=/bench/bin/codescout,readonly",
                     *self.api.fixture_docker_options(desc, "native"), image,
                     "start", "--project", "/testbed"],
                    capture_output=True, text=True, timeout=30)
                self.assertEqual(created.returncode, 0, created.stderr)
                cid = created.stdout.strip()
                try:
                    if bad_startup:
                        (target / "spec.json").write_bytes(original + b" ")
                    result = subprocess.run(["docker", "start", "--attach", cid],
                                            capture_output=True, text=True, timeout=30)
                    if bad_startup:
                        self.assertEqual(result.returncode, 78, result.stderr)
                        self.assertEqual(result.stdout, "")
                        self.assertIn("public-fixture-failed", result.stderr)
                        self.assertNotIn("public-fixture-ready", result.stderr)
                    else:
                        self.assertEqual(result.returncode, 19, result.stderr)
                        self.assertEqual(json.loads(result.stdout),
                                         {"argv": ["/bench/bin/codescout", "start", "--project", "/testbed"],
                                          "cwd": "/tmp"})
                        self.assertTrue(result.stderr.startswith("public-fixture-ready "), result.stderr)
                    inspected = subprocess.run(["docker", "inspect", cid], capture_output=True,
                                               text=True, timeout=10)
                    self.assertEqual(inspected.returncode, 0, inspected.stderr)
                    final = json.loads(inspected.stdout)[0]["State"]
                    self.assertEqual(final["ExitCode"], 78 if bad_startup else 19)
                    self.assertFalse(final["Running"])
                    self.assertFalse(final["OOMKilled"])
                finally:
                    (target / "spec.json").write_bytes(original)
                    removed = subprocess.run(["docker", "rm", "--force", "--volumes", cid],
                                             capture_output=True, text=True, timeout=30)
                    self.assertEqual(removed.returncode, 0, removed.stderr)
                    absent = subprocess.run(["docker", "inspect", cid], capture_output=True,
                                            text=True, timeout=10)
                    self.assertNotEqual(absent.returncode, 0)


if __name__ == "__main__":
    unittest.main()
