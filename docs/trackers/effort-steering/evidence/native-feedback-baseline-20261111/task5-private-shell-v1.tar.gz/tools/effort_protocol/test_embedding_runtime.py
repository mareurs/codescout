"""Owned relay lifecycle without changing the evidence executor namespace."""
import importlib
import json
from pathlib import Path
import sys
import subprocess
import tempfile
from types import SimpleNamespace
import unittest

sys.path.insert(0, str(Path(__file__).parent))
import executor
try:
    runtime = importlib.import_module("embedding_runtime")
except ModuleNotFoundError as exc:
    if exc.name != "embedding_runtime":
        raise
    runtime = None

CID, NET, SERVICE = "b"*64, "c"*64, "d"*64
IMAGE, SERVICE_IMAGE = "sha256:"+"a"*64, "sha256:"+"e"*64


class EmbeddingRuntimeTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(runtime, "generic owned embedding lifecycle missing")
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.out = Path(self.temp.name)
        self.config = {"service_id": SERVICE, "service_image": SERVICE_IMAGE,
            "upstream_network": "codescout-retrieval_retrieval_net", "subnet": "100.109.5.0/28"}
        self.commands = []
        self.owner = None
        self.removed = False
        self.net_removed = False
        self.drift = False

    def row(self):
        return {"Id": CID, "Image": IMAGE, "Name": "/" + self.owner,
            "Config": {"Labels": {"codescout.hfa": "foreign" if self.drift else self.owner}},
            "State": {"Running": True}, "Mounts": []}

    def inspect(self, identity):
        if identity == SERVICE:
            return {"Id": SERVICE, "Image": SERVICE_IMAGE, "State": {"Running": True, "StartedAt": "frozen"},
                "NetworkSettings": {"Networks": {self.config["upstream_network"]:
                    {"NetworkID": "f"*64, "IPAddress": "172.21.0.2"}}}}
        if identity == CID:
            return self.row()
        raise AssertionError(identity)

    def docker(self, args):
        self.commands.append(args)
        data = ""
        if args[:2] == ["network", "create"]:
            self.owner = args[args.index("--label")+1].split("=",1)[1]
            data = NET
        elif args[:2] == ["network", "inspect"]:
            data = json.dumps([{"Id": NET, "Internal": True, "Labels": {"codescout.hfa": self.owner},
                "IPAM": {"Config": [{"Subnet": self.config["subnet"]}]},
                "Containers": {} if self.removed else {CID: {}}}])
        elif args[0] == "create":
            data = CID
        elif args[:2] == ["network", "connect"] or args[0] == "start":
            pass
        elif args[0] == "exec":
            data = "200"
        elif args[0] == "logs":
            pass
        elif args[0] == "rm":
            self.removed = True
        elif args[0] == "ps":
            data = "" if self.removed else CID
        elif args[:2] == ["network", "rm"]:
            self.net_removed = True
        elif args[:2] == ["network", "ls"]:
            data = "" if self.net_removed else NET
        else:
            raise AssertionError(args)
        return SimpleNamespace(returncode=0, stdout=data, stderr="")

    def context(self):
        return runtime.embedding_runtime(self.out, IMAGE, self.config, docker=self.docker, inspect=self.inspect)

    def test_import_preserves_public_command_namespace_in_a_fresh_process(self):
        program = ("import sys; sys.path[:0]=" + repr(sys.path) + "; "
                   "import executor; before=executor.LABEL; import embedding_runtime; "
                   "assert executor.LABEL == before, (before, executor.LABEL)")
        result = subprocess.run([sys.executable, "-I", "-B", "-c", program],
                                capture_output=True, text=True, timeout=15)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_context_binds_descriptor_and_removes_only_owned_objects(self):
        label = executor.LABEL
        with self.context() as descriptor:
            self.assertEqual(descriptor["network_id"], NET)
            self.assertEqual(descriptor["relay_id"], CID)
            self.assertEqual(descriptor["service_id"], SERVICE)
            self.assertEqual(executor.LABEL, label)
        self.assertEqual(executor.LABEL, label)
        self.assertTrue(self.removed and self.net_removed)
        self.assertFalse(any(args[0] == "rm" and SERVICE in args for args in self.commands))
        self.assertTrue(json.loads((self.out / "cleanup.json").read_bytes())["complete"])

    def test_body_exception_still_cleans_owned_network_and_relay(self):
        with self.assertRaisesRegex(RuntimeError, "caller fault"):
            with self.context():
                raise RuntimeError("caller fault")
        self.assertTrue(self.removed and self.net_removed)

    def test_identity_drift_refuses_destructive_cleanup(self):
        with self.assertRaises(ValueError):
            with self.context():
                self.drift = True
        self.assertFalse(self.removed)
        self.assertFalse(self.net_removed)
        self.assertFalse(json.loads((self.out / "cleanup.json").read_bytes())["complete"])

    def test_mismatched_shared_service_refuses_before_creating_objects(self):
        self.config["service_image"] = "sha256:" + "9"*64
        with self.assertRaises(ValueError):
            with self.context():
                self.fail("unverified shared service was yielded")
        self.assertEqual(self.commands, [])


if __name__ == "__main__":
    unittest.main()
