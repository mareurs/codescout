"""Trusted-host receipt/readback tests; no model or Docker boundary is claimed."""
import hashlib
import importlib
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
try:
    receipts = importlib.import_module("receipts")
except ModuleNotFoundError as exc:
    if exc.name != "receipts":
        raise
    receipts = None

class ReceiptTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(receipts, "trusted receipt reader is not implemented")
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / "source"
        self.source.mkdir()
        (self.source / "program.txt").write_text("public source")
        (self.source / "probe.txt").write_text("public probe")
        self.executor = self.root / "host-only"
        self.record_dir = self.executor / "one"
        self.record_dir.mkdir(parents=True)
        (self.record_dir / "stdout").write_bytes(b"actual observation")
        (self.record_dir / "stderr").write_bytes(b"")
        (self.record_dir / "build").mkdir()
        digest = receipts.input_digest(self.source)
        self.record = {"id": "one", "run_id": "run", "phase": "investigate",
                       "argv": ["python3", "probe.txt"], "cwd": ".",
                       "source_before": digest, "source_after": digest,
                       "production_digest": "a" * 64,
                       "test_files": ["probe.txt"],
                       "test_digest": receipts.input_digest(self.source, ["probe.txt"]),
                       "toolchain_digest": "b" * 64, "dependency_digest": "c" * 64,
                       "build_before": receipts.input_digest(self.record_dir / "build"),
                       "build_after": receipts.input_digest(self.record_dir / "build"),
                       "capture_complete": True, "resource_valid": True,
                       "cleanup_complete": True, "exit_code": 0, "kind": "observation"}
        self.save()

    def save(self):
        for name in ("stdout", "stderr"):
            self.record[name + "_sha256"] = hashlib.sha256((self.record_dir / name).read_bytes()).hexdigest()
        (self.record_dir / "receipt.json").write_text(json.dumps(self.record))

    def verify(self, ref=None):
        return receipts.verify_receipt(ref or {"id": "one"}, self.executor, self.source)

    def reject(self, ref=None):
        with self.assertRaises(receipts.ReceiptViolation):
            self.verify(ref)

    def test_reads_actual_host_record_and_content(self):
        result = self.verify()
        self.assertEqual(result["id"], "one")
        self.assertEqual(result["source_digest"], receipts.input_digest(self.source))
        self.assertTrue(result["complete"])

    def test_actor_cannot_supply_receipt_fields(self):
        self.reject({"id": "one", "resource_valid": True})

    def test_actor_cannot_escape_receipt_namespace(self):
        self.reject({"id": "../one"})

    def test_record_symlink_is_rejected(self):
        target = self.root / "other.json"
        target.write_text(json.dumps(self.record))
        (self.record_dir / "receipt.json").unlink()
        (self.record_dir / "receipt.json").symlink_to(target)
        self.reject()

    def test_log_symlink_is_rejected(self):
        target = self.root / "outside"
        target.write_bytes(b"actual observation")
        (self.record_dir / "stdout").unlink()
        (self.record_dir / "stdout").symlink_to(target)
        self.reject()

    def test_log_tampering_is_rejected(self):
        (self.record_dir / "stdout").write_bytes(b"not the recorded observation")
        self.reject()

    def test_source_tampering_is_rejected(self):
        (self.source / "program.txt").write_text("different source")
        self.reject()

    def test_untracked_source_file_changes_the_digest(self):
        before = receipts.input_digest(self.source)
        (self.source / "untracked.txt").write_text("executable input")
        self.assertNotEqual(before, receipts.input_digest(self.source))
        self.reject()

    def test_file_mode_is_bound(self):
        before = receipts.input_digest(self.source)
        (self.source / "program.txt").chmod(0o755)
        self.assertNotEqual(before, receipts.input_digest(self.source))
        self.reject()

    def test_input_symlink_cannot_escape_snapshot(self):
        outside = self.root / "outside.txt"
        outside.write_text("not part of the registered source")
        (self.source / "escape").symlink_to(outside)
        with self.assertRaises(receipts.ReceiptViolation):
            receipts.input_digest(self.source)

    def test_incomplete_capture_is_rejected(self):
        self.record["capture_complete"] = False
        self.save()
        self.reject()

    def test_mutable_input_during_execution_is_rejected(self):
        self.record["source_before"] = "d" * 64
        self.save()
        self.reject()

    def test_wrong_test_digest_is_rejected(self):
        self.record["test_digest"] = "d" * 64
        self.save()
        self.reject()

    def test_empty_observation_is_rejected(self):
        (self.record_dir / "stdout").write_bytes(b"")
        self.save()
        self.reject()

    def test_silent_verification_can_use_its_exit_status(self):
        (self.record_dir / "stdout").write_bytes(b"")
        self.record["kind"] = "verification"
        self.save()
        self.assertEqual(self.verify()["exit_code"], 0)

    def test_functional_failure_is_not_infrastructure(self):
        self.record["exit_code"] = 1
        self.save()
        self.assertEqual(self.verify()["exit_code"], 1)

    def test_resource_fault_is_rejected(self):
        self.record["resource_valid"] = False
        self.save()
        self.reject()

    def test_unconfirmed_cleanup_is_rejected(self):
        self.record["cleanup_complete"] = False
        self.save()
        self.reject()

    def test_host_namespace_cannot_live_in_actor_source(self):
        with self.assertRaises(receipts.ReceiptViolation):
            receipts.verify_receipt({"id": "one"}, self.source / "host-only", self.source)

    def test_missing_test_inventory_cannot_fall_back_to_whole_source(self):
        del self.record['test_files']
        self.record['test_digest'] = receipts.input_digest(self.source)
        self.save()
        self.reject()

    def test_exclusive_manifest_cannot_be_overwritten(self):
        target = self.root / "phase.json"
        receipts.publish_exclusive(target, {"phase": "repair"})
        before = target.read_bytes()
        with self.assertRaises(FileExistsError):
            receipts.publish_exclusive(target, {"phase": "closed"})
        self.assertEqual(target.read_bytes(), before)

if __name__ == "__main__":
    unittest.main()
