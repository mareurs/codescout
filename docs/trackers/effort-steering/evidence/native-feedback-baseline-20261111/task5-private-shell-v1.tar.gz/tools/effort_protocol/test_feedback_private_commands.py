"""Source-bound test scheduling/provenance preparation preserves the expected population."""
import copy
import importlib
import unittest
try:
    subject = importlib.import_module("feedback_private_commands")
except ModuleNotFoundError:
    subject = None

class PrivateCommandPreparationTests(unittest.TestCase):
    def record(self, command="cargo test --workspace --exclude arbitrary-python 2>&1 | tee reports/tests.log"):
        return {"instance_id": "unrelated-project", "test_cmds": [command],
            "rebuild_cmds": ["cargo build --workspace"], "print_cmds": ["cat reports/tests.log"],
            "FAIL_TO_PASS": ["a", "b"], "PASS_TO_PASS": ["c"], "patch": "opaque gold",
            "test_patch": "opaque fixed tests", "problem_statement": "opaque public issue"}

    def helper(self):
        self.assertIsNotNone(subject)
        return subject

    def test_compilation_is_separate_and_all_original_selectors_and_labels_are_retained(self):
        original = self.record()
        before = copy.deepcopy(original)
        result = self.helper().prepare_record(original)
        self.assertEqual(original, before)
        self.assertEqual(result["rebuild_cmds"], ["cargo build --workspace",
            "cargo test --workspace --exclude arbitrary-python --no-run"])
        self.assertEqual(result["test_cmds"], [
            "cargo test --no-fail-fast --workspace --exclude arbitrary-python 2>&1 | tee reports/tests.log"])
        for key in original.keys() - {"test_cmds", "rebuild_cmds"}:
            self.assertEqual(result[key], original[key])

    def test_already_complete_test_run_is_not_given_duplicate_scheduling_flag(self):
        result = self.helper().prepare_record(self.record(
            "cargo test --no-fail-fast --lib 2>&1 | tee reports/tests.log"))
        self.assertEqual(result["test_cmds"][0].count("--no-fail-fast"), 1)
        self.assertEqual(result["rebuild_cmds"][-1], "cargo test --no-fail-fast --lib --no-run")

    def test_test_binary_arguments_do_not_leak_into_compile_only_prefix(self):
        result = self.helper().prepare_record(self.record(
            "cargo test --lib -- --test-threads=1 2>&1 | tee reports/tests.log"))
        self.assertEqual(result["rebuild_cmds"][-1], "cargo test --lib --no-run")
        self.assertIn("-- --test-threads=1", result["test_cmds"][0])

    def test_each_literal_cargo_test_has_its_own_prefix(self):
        record = self.record()
        record["test_cmds"].append("cargo test --test 'with space' 2>&1 | tee reports/second.log")
        record["print_cmds"].append("cat reports/second.log")
        result = self.helper().prepare_record(record)
        self.assertEqual(result["rebuild_cmds"][-1], "cargo test --test 'with space' --no-run")
        self.assertEqual(len(result["rebuild_cmds"]), 3)
        self.assertEqual(len(result["test_cmds"]), 2)

    def test_no_rebuild_is_supported_without_mutating_original_none(self):
        record = self.record()
        record["rebuild_cmds"] = None
        result = self.helper().prepare_record(record)
        self.assertIsNone(record["rebuild_cmds"])
        self.assertEqual(result["rebuild_cmds"], ["cargo test --workspace --exclude arbitrary-python --no-run"])

    def test_unsupported_shell_or_runner_contract_is_refused_before_execution(self):
        for command in ("echo cargo test", "cargo nextest run > reports/x",
                "cargo test $SELECTOR 2>&1 | tee reports/tests.log",
                "cargo test --doc 2>&1 | tee reports/tests.log",
                "cargo test --no-run 2>&1 | tee reports/tests.log",
                "cargo test --lib; true 2>&1 | tee reports/tests.log",
                "cargo test 'fake|filter' 2>&1 | tee reports/tests.log"):
            with self.subTest(command=command), self.assertRaises(ValueError):
                self.helper().prepare_record(self.record(command))

if __name__ == "__main__":
    unittest.main()
