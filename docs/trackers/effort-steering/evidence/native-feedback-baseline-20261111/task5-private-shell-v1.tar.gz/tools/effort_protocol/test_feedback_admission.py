"""Admission/authorization boundaries; fixtures cannot authorize real paid work."""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from contextlib import ExitStack
from unittest.mock import patch

import feedback_policy as policy
from receipts import input_digest

try:
    import feedback_admission as subject
except ModuleNotFoundError as exc:
    if exc.name != "feedback_admission":
        raise
    subject = None


def registration(root, mode="scripted"):
    selected, tasks = [], {}
    for index in range(4):
        identity = "task" + str(index)
        source = root / identity
        source.mkdir()
        (source / "code.rs").write_text("pub fn value() -> u8 { 1 }")
        issue = "Public issue " + str(index)
        selected.append({"id": identity, "repo": "org/repo" + str(index), "language": "rust",
                         "base_commit": "a" * 40, "image": "sha256:" + "a" * 64,
                         "public_issue_sha256": hashlib.sha256(issue.encode()).hexdigest(),
                         "eligible": True, "reason": "qualified source-only controls"})
        tasks[identity] = {"source": str(source), "source_sha256": input_digest(source),
                          "public_packet": {"issue": issue},
                          "backend": {"public": {"feedback_policy": {
                              "schema": "native-public-feedback-v1", "workspace": "."}},
                              "private": {}, "scripted_plans": {}}}
    schedule = []
    for row in policy.balanced_schedule([r["id"] for r in selected], 101):
        config = policy.condition_spec(row["arm"], ".")
        schedule.append(dict(row, cli_cap_usd=config["cli_cap_usd"], reserved_usd=config["reserve_usd"]))
    return {"schema": "native-public-feedback-v1", "campaign_id": "feedback-unit", "mode": mode,
            "output_root": str(root / "outputs"), "selected": selected, "tasks": tasks,
            "metadata": copy.deepcopy(selected), "exposure": [], "seed": "public-frozen-unit",
            "order_seed": 101, "schedule": schedule, "bindings": {},
            "shared_preparation": {"cost_usd": "0", "receipt_sha256": "a" * 64}}


def request(reg, index=0):
    attempt = reg["schedule"][index]
    task = reg["tasks"][attempt["task_id"]]
    selected = policy.condition_spec(attempt["arm"], task["backend"]["public"]["feedback_policy"]["workspace"])
    packet = {"attempt_index": index, "task_id": attempt["task_id"], "arm": attempt["arm"], "phase": "repair",
              "invocation_id": reg["campaign_id"] + "::" + str(index) + "::repair",
              "source": task["source"], "state": {"run_id": reg["campaign_id"] + "-" + str(index),
              "turns_used": 0, "baseline_digest": task["source_sha256"]},
              "effort": selected["effort"], "feedback_policy": selected, "max_continuations": 4,
              "cli_cap_usd": attempt["cli_cap_usd"], "allowance_usd": attempt["reserved_usd"],
              "public_packet": copy.deepcopy(task["public_packet"])}
    out = Path(reg["output_root"]) / "attempts" / (str(index).zfill(2) + "-" + attempt["arm"]) / "repair"
    return packet, out, task["backend"]["public"]


class FeedbackRegistrationTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(subject, "explicit repair-only admission is missing")
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.reg = registration(self.root)

    def test_exact_four_repo_sixteen_attempt_shape_is_supported(self):
        self.assertEqual(subject.validate_registration(self.reg), {
            "attempts": 16, "tasks": 4, "native_invocations": 16,
            "max_continuations": 4, "allocation_usd": "112"})

    def test_old_schema_eight_attempt_proof_and_three_phase_fields_are_rejected(self):
        for change in [{"schema": "evidence-campaign-v1"}, {"schedule": self.reg["schedule"][:8]},
                       {"schedule": [dict(r, phase_cli_caps_usd=["2.75"] * 3)
                                     for r in self.reg["schedule"]]}]:
            altered = copy.deepcopy(self.reg)
            altered.update(change)
            with self.subTest(change=list(change)), self.assertRaises(ValueError):
                subject.validate_registration(altered)

    def test_repository_identity_and_condition_order_cannot_drift(self):
        for change in ["repo", "seed", "cap", "condition", "issue", "private", "policy"]:
            altered = copy.deepcopy(self.reg)
            if change == "repo":
                altered["selected"][1]["repo"] = altered["selected"][0]["repo"].upper()
            elif change == "seed":
                altered["order_seed"] = 102
            elif change == "cap":
                altered["schedule"][0]["reserved_usd"] = "100"
            elif change == "condition":
                altered["schedule"][0]["arm"] = altered["schedule"][1]["arm"]
            elif change == "issue":
                altered["tasks"]["task0"]["public_packet"]["issue"] = "changed"
            elif change == "private":
                altered["tasks"]["task0"]["public_packet"]["private_expected"] = ["secret"]
            else:
                altered["tasks"]["task0"]["backend"]["public"]["feedback_policy"]["schema"] = "legacy"
            with self.subTest(change=change), self.assertRaises(ValueError):
                subject.validate_registration(altered)

    def test_malformed_registration_fails_as_validation_error(self):
        for value in [None, [], {}, {"schema": policy.SCHEMA}, dict(self.reg, schedule=None)]:
            with self.subTest(value=value), self.assertRaises(ValueError):
                subject.validate_registration(value)


class FeedbackAuthorizationTests(unittest.TestCase):
    def setUp(self):
        FeedbackRegistrationTests.setUp(self)
        self.reg["mode"] = "paid"
        self.token = self.root / "unit-credential"
        self.token.write_text("not a real token")
        self.token.chmod(0o600)
        self.reg["admission"] = {"credential_path": str(self.token)}
        self.bound = self.root / "bound-input"
        self.bound.write_text("frozen")
        self.reg["bindings"][str(self.bound)] = hashlib.sha256(self.bound.read_bytes()).hexdigest()

    def admitted(self):
        with patch.object(subject, "verify_paid", return_value={"ready": True, "proofs": {}}):
            return subject.FeedbackAdmission(self.reg, self.token)

    def test_exact_repair_authorization_is_single_use_and_preserves_arm(self):
        authorization = self.admitted()
        packet, out, public = request(self.reg)
        self.assertEqual(authorization.authorize(packet, out, public, self.token),
                         {"authorized_invocation": packet["invocation_id"]})
        with self.assertRaises(ValueError):
            authorization.authorize(packet, out, public, self.token)

    def test_budget_effort_phase_source_state_and_output_are_bound(self):
        packet, out, public = request(self.reg)
        for changes in [{"max_continuations": 2}, {"effort": "other"}, {"phase": "investigate"},
                        {"allowance_usd": "100"}, {"cli_cap_usd": "0.01"}, {"attempt_index": True},
                        {"invocation_id": "other"}, {"source": str(self.root)},
                        {"public_packet": {"issue": "other"}},
                        {"state": dict(packet["state"], turns_used=1)}]:
            bad = copy.deepcopy(packet)
            bad.update(changes)
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                self.admitted().authorize(bad, out, public, self.token)
        with self.assertRaises(ValueError):
            self.admitted().authorize(packet, out / "elsewhere", public, self.token)

    def test_source_and_runtime_drift_are_reopened_before_authorization(self):
        packet, out, public = request(self.reg)
        authorization = self.admitted()
        self.bound.write_text("changed")
        with self.assertRaises(ValueError):
            authorization.authorize(packet, out, public, self.token)
        self.bound.write_text("frozen")
        (Path(packet["source"]) / "code.rs").write_text("changed candidate")
        with self.assertRaises(ValueError):
            authorization.authorize(packet, out, public, self.token)

    def test_registration_mutation_and_changed_credential_cannot_reuse_authority(self):
        authorization = self.admitted()
        packet, out, public = request(self.reg)
        authorization.registration["schedule"][0]["reserved_usd"] = "100"
        with self.assertRaises(ValueError):
            authorization.authorize(packet, out, public, self.token)
        with self.assertRaises(ValueError):
            self.admitted().authorize(packet, out, public, self.token.with_name("other"))
        authorization = self.admitted()
        self.token.chmod(0o644)
        with self.assertRaises(ValueError):
            authorization.authorize(packet, out, public, self.token)

    def test_terminal_campaign_marker_revokes_unused_authorizations(self):
        authorization = self.admitted()
        packet, out, public = request(self.reg)
        root = Path(self.reg["output_root"])
        root.mkdir()
        for name in ("ledger-final.json", "actor-batch-closed.json"):
            marker = root / name
            marker.write_text("{}")
            with self.subTest(name=name), self.assertRaises(ValueError):
                authorization.authorize(packet, out, public, self.token)
            marker.unlink()
        self.assertEqual(authorization.used, set())

    def test_failed_verification_or_ready_flag_never_constructs_authority(self):
        with self.assertRaises(ValueError):
            subject.FeedbackAdmission(self.reg, self.token)
        with patch.object(subject, "verify_paid", return_value={"ready": False}):
            with self.assertRaises(ValueError):
                subject.FeedbackAdmission(self.reg, self.token)


class FeedbackProofCompositionTests(unittest.TestCase):
    setUp = FeedbackAuthorizationTests.setUp

    ROLES = ("population", "public_commands", "accounting", "runtime", "verification", "review",
             "shared_preparation")

    def test_all_seven_real_verifiers_are_required_and_failure_propagates(self):
        self.reg["admission"].update({name: {"fixture": name} for name in self.ROLES})
        with ExitStack() as stack:
            validators = {name: stack.enter_context(patch.object(subject, "verify_" + name,
                          return_value={"checked": name})) for name in self.ROLES}
            result = subject.verify_paid(self.reg)
            self.assertTrue(result["ready"])
            self.assertEqual(set(result["proofs"]), set(self.ROLES))
            validators["population"].assert_called_once_with(
                self.reg, self.reg["admission"]["population"], task_count=4)
            validators["runtime"].assert_called_once_with(
                self.reg, self.reg["admission"]["runtime"], feedback=True)
            for name, validator in validators.items():
                validator.side_effect = ValueError(name + " invalid")
                with self.subTest(name=name), self.assertRaisesRegex(ValueError, name + " invalid"):
                    subject.verify_paid(self.reg)
                validator.side_effect = None

    def test_missing_or_boolean_proof_cannot_replace_exact_inventory(self):
        self.reg["admission"].update({name: {"fixture": name} for name in self.ROLES})
        for name in self.ROLES:
            altered = copy.deepcopy(self.reg)
            del altered["admission"][name]
            with self.subTest(name=name), self.assertRaises(ValueError):
                subject.verify_paid(altered)
        self.reg["admission"] = {"ready": True, "credential_path": str(self.token)}
        with self.assertRaises(ValueError):
            subject.verify_paid(self.reg)


if __name__ == "__main__":
    unittest.main()
