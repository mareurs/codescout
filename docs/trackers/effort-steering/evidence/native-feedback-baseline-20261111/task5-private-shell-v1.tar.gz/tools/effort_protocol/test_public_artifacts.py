"""Public handoff contains actual source-bound evidence, never host outcomes."""
import base64
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import receipts
try:
    import public_artifacts as handoff
except ImportError:
    handoff = None


class PublicArtifactTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(handoff, "public evidence handoff is not implemented")
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.root = Path(tmp.name)
        self.source = self.root / "source"
        self.source.mkdir()
        (self.source / "probe.py").write_text("public probe")
        self.commands = self.root / "commands"
        self.directory = self.commands / "investigate--one"
        self.directory.mkdir(parents=True)
        (self.directory / "build").mkdir()
        (self.directory / "stdout").write_bytes(b"actual observation\n")
        (self.directory / "stderr").write_bytes(b"public diagnostic\n")
        digest = receipts.input_digest(self.source)
        self.record = {
            "id": "investigate--one", "run_id": "run", "phase": "investigate",
            "argv": ["python3", "probe.py"], "cwd": ".", "kind": "observation",
            "source_before": digest, "source_after": digest,
            "production_digest": digest, "test_files": ["probe.py"],
            "test_digest": digest, "toolchain_digest": "b" * 64,
            "dependency_digest": "c" * 64,
            "build_before": receipts.input_digest(self.directory / "build"),
            "build_after": receipts.input_digest(self.directory / "build"),
            "capture_complete": True, "resource_valid": True,
            "cleanup_complete": True, "exit_code": 1,
            "private_expected": "HOST-ONLY", "cost_usd": "99"}
        self.save()
        self.submission = {"status": "submitted",
                           "clauses": [{"id": "rule", "receipts": ["one"], "text": "public requirement"}],
                           "commands": [{"id": "one", "argv": ["python3", "probe.py"]}],
                           "host_grade": "HOST-ONLY"}

    def save(self):
        for name in ("stdout", "stderr"):
            self.record[name + "_sha256"] = hashlib.sha256((self.directory / name).read_bytes()).hexdigest()
        (self.directory / "receipt.json").write_text(json.dumps(self.record))

    def build(self, **changes):
        args = dict(run_id="run", phase="investigate", arm="P", source=self.source,
                    commands=self.commands, receipt_ids=["investigate--one"],
                    submission=self.submission)
        args.update(changes)
        return handoff.build_public_artifact(**args)

    def test_actual_observations_and_actor_clauses_survive_json_transfer(self):
        artifact = json.loads(json.dumps(self.build()))
        self.assertEqual(artifact["submission"]["clauses"], self.submission["clauses"])
        observed = artifact["observations"][0]
        self.assertEqual(observed["argv"], ["python3", "probe.py"])
        self.assertEqual(observed["cwd"], ".")
        self.assertEqual(observed["exit_code"], 1)
        self.assertEqual(observed["stdout"], {"encoding": "utf-8", "content": "actual observation\n"})
        self.assertEqual(observed["stderr"], {"encoding": "utf-8", "content": "public diagnostic\n"})
        self.assertEqual(artifact["source_digest"], receipts.input_digest(self.source))
        self.assertEqual(set(artifact), {"run_id", "phase", "arm", "source_digest", "submission", "observations"})

    def test_host_private_fields_and_cost_are_not_exported(self):
        encoded = json.dumps(self.build())
        self.assertNotIn("HOST-ONLY", encoded)
        self.assertNotIn("cost_usd", encoded)
        self.assertNotIn("private_expected", encoded)
        self.assertNotIn("host_grade", encoded)

    def test_binary_logs_are_exact_and_explicitly_encoded(self):
        raw = b"\xff\x00\xfe"
        (self.directory / "stdout").write_bytes(raw)
        self.save()
        stream = self.build()["observations"][0]["stdout"]
        self.assertEqual(stream["encoding"], "base64")
        self.assertEqual(base64.b64decode(stream["content"], validate=True), raw)

    def test_tampered_stream_or_receipt_is_rejected(self):
        (self.directory / "stdout").write_bytes(b"forged")
        with self.assertRaises(ValueError):
            self.build()

    def test_wrong_run_and_phase_are_rejected(self):
        for key, value in (("run_id", "other"), ("phase", "repair")):
            with self.subTest(key=key):
                with self.assertRaises(ValueError):
                    self.build(**{key: value})

    def test_duplicate_receipt_ids_and_source_drift_are_rejected(self):
        with self.assertRaises(ValueError):
            self.build(receipt_ids=["investigate--one", "investigate--one"])
        (self.source / "probe.py").write_text("changed")
        with self.assertRaises(ValueError):
            self.build()

    def test_R_has_no_protocol_submission_and_cannot_export_one(self):
        artifact = self.build(arm="R", receipt_ids=[], submission=None)
        self.assertIsNone(artifact["submission"])
        self.assertEqual(artifact["observations"], [])
        with self.assertRaises(ValueError):
            self.build(arm="R")
    def test_source_changes_during_empty_control_export(self):
        original = handoff.input_digest
        calls = 0
        def change_after_initial_hash(source):
            nonlocal calls
            digest = original(source)
            calls += 1
            if calls == 1:
                (self.source / "probe.py").write_text("changed during export")
            return digest
        with patch.object(handoff, "input_digest", side_effect=change_after_initial_hash):
            with self.assertRaisesRegex(ValueError, "handoff source changed during export"):
                self.build(arm="R", receipt_ids=[], submission=None)

    def test_exported_bytes_match_verified_stream_hash(self):
        original = handoff._host_file
        def transient_export_read(directory, name, limit):
            raw = original(directory, name, limit)
            return b"unverified transient bytes" if name == "stdout" else raw
        with patch.object(handoff, "_host_file", side_effect=transient_export_read):
            with self.assertRaisesRegex(ValueError, "handoff execution log drift"):
                self.build()
