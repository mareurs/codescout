"""Own one embedding relay without changing any public command executor globals."""
import contextlib
import hashlib
import json
from pathlib import Path
import re
import time
import uuid

from executor import _docker, _inspect
from native_executor import external
from embedding_profile import RELAY_SHA256
from receipts import publish_exclusive


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _owned(row, cid, name, image):
    _require(isinstance(cid, str) and re.fullmatch(r"[0-9a-f]{64}", cid) and
             row.get("Id") == cid and row.get("Image") == image and row.get("Name") == "/" + name and
             row.get("Config", {}).get("Labels", {}).get("codescout.hfa") == name,
             "owned embedding relay identity mismatch")


def _remove_relay(cid, name, image, docker, inspect):
    if cid is None:
        found = docker(["ps", "-a", "--no-trunc", "--format", "{{.ID}}", "--filter", "name=^/" + name + "$"])
        _require(found.returncode == 0, "relay cleanup discovery failed")
        names = found.stdout.split()
        _require(len(names) <= 1, "relay cleanup identity ambiguous")
        if not names:
            return
        cid = names[0]
    row = inspect(cid)
    _owned(row, cid, name, image)
    volumes = [mount["Name"] for mount in row.get("Mounts", []) if mount.get("Type") == "volume"]
    removed = docker(["rm", "--volumes", "--force", cid])
    _require(removed.returncode == 0, "owned relay removal failed")
    absent = docker(["ps", "-a", "--no-trunc", "--format", "{{.ID}}", "--filter", "id=" + cid])
    _require(absent.returncode == 0 and not absent.stdout.strip(), "owned relay absence unconfirmed")
    for volume in volumes:
        present = docker(["volume", "ls", "--quiet", "--filter", "name=" + volume])
        _require(present.returncode == 0 and volume not in present.stdout.split(),
                 "owned anonymous relay volume absence unconfirmed")


@contextlib.contextmanager
def embedding_runtime(out, image, config, *, docker=_docker, inspect=_inspect):
    """Yield a measured service descriptor; every exit closes only owned objects."""
    out = Path(out).resolve(strict=True)
    _require(isinstance(image, str) and re.fullmatch(r"sha256:[0-9a-f]{64}", image),
             "immutable relay image required")
    service = inspect(config["service_id"])
    _require(service["Id"] == config["service_id"] and service["Image"] == config["service_image"] and
             service["State"]["Running"] is True, "registered shared embedding service unavailable")
    upstream = config["upstream_network"]
    service_network = service["NetworkSettings"]["Networks"][upstream]
    name, network = "ep-relay-" + uuid.uuid4().hex, "ep-cli-net-" + uuid.uuid4().hex
    relay = out / "embedding_relay.py"
    raw = Path(__file__).with_name("embedding_relay.py").read_bytes()
    _require(hashlib.sha256(raw).hexdigest() == RELAY_SHA256, "registered relay source changed")
    with relay.open("xb") as stream:
        stream.write(raw)
    proxy = network_id = None
    try:
        made = docker(["network", "create", "--internal", "--subnet", config["subnet"],
                       "--label", "codescout.hfa=" + name, network])
        _require(made.returncode == 0, "internal embedding network creation failed")
        network_id = made.stdout.strip()
        _require(re.fullmatch(r"[0-9a-f]{64}", network_id), "immutable network ID missing")
        row = json.loads(docker(["network", "inspect", network_id]).stdout)[0]
        _require(row["Id"] == network_id and row["Internal"] is True and
                 row["Labels"].get("codescout.hfa") == name and
                 [part["Subnet"] for part in row["IPAM"]["Config"]] == [config["subnet"]],
                 "internal embedding network binding mismatch")
        publish_exclusive(out / "network-before.json", row)
        made = docker(["create", "--pull=never", "--init", "--read-only",
            "--tmpfs", "/mnt_tmp:ro,noexec,nosuid,nodev,size=1m", "--user", "1000:1000",
            "--network", upstream, "--memory", "512m", "--memory-swap", "512m",
            "--cpus", "1", "--pids-limit", "64", "--cap-drop=ALL",
            "--security-opt", "no-new-privileges", "--name", name, "--label", "codescout.hfa=" + name,
            "--mount", "type=bind,src=" + str(relay) + ",dst=/relay.py,readonly",
            "--entrypoint", "python3", image, "-I", "-B", "/relay.py", "--upstream",
            "http://" + service_network["IPAddress"] + ":8080/v1/embeddings",
            "--model", "CodeRankEmbed", "--dimensions", "768"])
        _require(made.returncode == 0, "owned embedding relay creation failed")
        proxy = made.stdout.strip()
        connected = docker(["network", "connect", "--alias", "source-embeddings", network_id, proxy])
        _require(connected.returncode == 0, "owned embedding relay connection failed")
        before = inspect(proxy)
        _owned(before, proxy, name, image)
        publish_exclusive(out / "relay-before.json", before)
        _require(docker(["start", proxy]).returncode == 0, "owned embedding relay startup failed")
        for attempt in range(20):
            health = docker(["exec", proxy, "python3", "-I", "-c",
                "import urllib.request;print(urllib.request.urlopen('http://127.0.0.1:8000/health',timeout=2).status)"])
            if health.returncode == 0 and health.stdout.strip() == "200":
                break
            time.sleep(0.2)
        publish_exclusive(out / "relay-health.json",
                          {"exit_code": health.returncode, "stdout": health.stdout, "stderr": health.stderr})
        _require(health.returncode == 0 and health.stdout.strip() == "200", "owned relay health unproved")
        descriptor = {"version": "embedding-relay-v1", "owner": name, "network_id": network_id,
            "relay_id": proxy, "service_id": service["Id"], "service_image": service["Image"],
            "service_started_at": service["State"]["StartedAt"],
            "upstream_network_id": service_network["NetworkID"], "service_ip": service_network["IPAddress"],
            "upstream_network": upstream, "relay_script": str(relay), "relay_sha256": RELAY_SHA256}
        publish_exclusive(out / "embedding-descriptor.json", descriptor)
        yield descriptor
    finally:
        errors = []
        if network_id is not None:
            try:
                if proxy is not None:
                    logs = docker(["logs", proxy])
                    (out / "relay.stdout").write_text(logs.stdout)
                    (out / "relay.stderr").write_text(logs.stderr)
                    publish_exclusive(out / "relay-after.json", inspect(proxy))
                _remove_relay(proxy, name, image, docker, inspect)
            except Exception as exc:
                errors.append("relay: " + type(exc).__name__ + ": " + str(exc))
            try:
                row = json.loads(docker(["network", "inspect", network_id]).stdout)[0]
                _require(row["Id"] == network_id and row["Labels"].get("codescout.hfa") == name
                         and not row.get("Containers"), "owned network is occupied or changed")
                removed = docker(["network", "rm", network_id])
                _require(removed.returncode == 0, "owned network removal failed")
                absent = docker(["network", "ls", "--quiet", "--filter", "name=^" + network + "$"])
                _require(absent.returncode == 0 and not absent.stdout.strip(), "owned network absence unconfirmed")
            except Exception as exc:
                errors.append("network: " + type(exc).__name__ + ": " + str(exc))
        publish_exclusive(out / "cleanup.json", {"complete": not errors, "errors": errors,
                          "proxy": proxy, "network_id": network_id})
        if errors:
            raise ValueError("owned embedding runtime cleanup failed: " + "; ".join(errors))
