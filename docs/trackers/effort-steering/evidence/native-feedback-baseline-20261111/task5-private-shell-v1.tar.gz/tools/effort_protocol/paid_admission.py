"""Host-only evidence checks for the paid boundary; never imported by actor prompts."""
import hashlib
import copy
import os
import stat
import json
import re
from pathlib import Path, PurePosixPath
import tarfile
from decimal import Decimal, localcontext

from campaign import _money, accounting_totals, admit_history, selection_report
from receipts import input_digest, verify_receipt
from execution_profiles import validate_profile_build_inputs
from readiness import validate_readiness
from native_executor import _text


def _require(condition, reason):
    if not condition:
        raise ValueError(reason)


def _bound_path(registration, descriptor):
    _require(isinstance(descriptor,dict) and isinstance(descriptor.get("path"),str)
             and isinstance(descriptor.get("sha256"),str), "evidence descriptor missing")
    path=Path(descriptor["path"])
    _require(path.is_absolute() and path.resolve(strict=True)==path and path.is_file(),
             "evidence must be a physical regular file")
    expected=descriptor["sha256"]
    _require(len(expected)==64 and registration["bindings"].get(str(path))==expected,
             "evidence is not frozen in campaign bindings")
    with path.open("rb") as stream:
        actual=hashlib.file_digest(stream,"sha256").hexdigest()
    _require(actual==expected,"evidence bytes changed")
    return path


def _bound_json(registration, descriptor):
    path=_bound_path(registration,descriptor)
    _require(path.stat().st_size<=16*1024*1024,"evidence JSON exceeds registered limit")
    return json.loads(path.read_bytes())


def verify_population(registration, descriptor, *, task_count=2):
    """Reproduce the original public-only selector, including its whole universe."""
    archive=_bound_path(registration,descriptor)
    members=descriptor.get("members")
    roles={"metadata","exposure","status","rule","freeze","selection"}
    _require(isinstance(members,dict) and set(members)==roles and
             all(isinstance(name,str) and name for name in members.values()) and
             len(set(members.values()))==len(roles),"population member roles missing or duplicated")
    for name in members.values():
        rel=PurePosixPath(name)
        _require(not rel.is_absolute() and ".." not in rel.parts,"unsafe population member name")
    records={}
    with tarfile.open(archive) as packed:
        inventory=packed.getmembers()
        _require(len({item.name for item in inventory})==len(inventory),
                 "duplicate frozen population member")
        for role,name in members.items():
            member=packed.getmember(name)
            _require(member.isfile() and member.size<=16*1024*1024,
                     "population member is not a bounded regular JSON")
            records[role]=json.loads(packed.extractfile(member).read())
    original=records["metadata"]["tasks"]
    status=records["status"]
    exposure=set(records["exposure"]["tasks"])
    rule=records["rule"]
    freeze=records["freeze"]
    frozen=records["selection"]
    _require(isinstance(original,list) and isinstance(status,dict)
             and set(status)=={row["id"] for row in original},"public qualification population changed")
    effective=[{**row,"eligible":status[row["id"]]["eligible"],
                "reason":status[row["id"]]["reason"]} for row in original]
    _require(rule.get("task_count",2)==task_count, "population quota differs from the frozen rule")
    derived=selection_report(effective,exposure,rule["seed"],task_count=task_count)
    _require(derived==frozen and freeze["selection"]==frozen
             and freeze["selection_rule"]==rule and frozen["complete"] is True
             and freeze["selected_ids"]==[row["id"] for row in frozen["selected"]],
             "frozen population selection or qualification changed")
    _require(freeze.get("private_outcomes_read") is False
             and freeze.get("replacement_after_private_outcomes") is False
             and type(freeze.get("experimental_model_calls")) is int
             and freeze["experimental_model_calls"]==0,
             "population is not frozen before model/private outcomes")
    _require(registration["metadata"]==effective
             and isinstance(registration["exposure"],list)
             and len(registration["exposure"])==len(exposure)
             and set(registration["exposure"])==exposure
             and registration["seed"]==rule["seed"]
             and registration["selected"]==frozen["selected"],
             "paid campaign differs from original public population, exposure, seed or selected order")
    return {"metadata_tasks":len(original),"exposure_ids":len(exposure),
            "excluded_universe_tasks":len({row["id"] for row in original} & exposure),
            "selected_ids":[row["id"] for row in frozen["selected"]],"archive_sha256":descriptor["sha256"]}
def verify_public_commands(registration, evidence):
    """Reopen registered command evidence, including generated build bytes and raw streams."""
    _require(isinstance(evidence,dict) and set(evidence)==set(registration["tasks"]),
             "public command evidence does not cover the exact task population")
    proofs={}
    for identity,task in registration["tasks"].items():
        public=task["backend"]["public"]
        commands=public["public_checks"]
        rows=evidence[identity]
        _require(isinstance(commands,list) and commands and isinstance(rows,list)
                 and len(rows)==len(commands),"public command inventory missing or changed")
        source=Path(task["source"])
        _require(input_digest(source)==task["source_sha256"],"public compile source changed")
        seen=set()
        for index,(command,row) in enumerate(zip(commands,rows)):
            _require(isinstance(row,dict) and set(row)=={"registration","result"},
                     "public command evidence schema invalid")
            registered=_bound_json(registration,row["registration"])
            result=_bound_json(registration,row["result"])
            directory=Path(row["registration"]["path"]).parent
            _require(directory==Path(row["result"]["path"]).parent
                     and str(directory) not in seen,"public command receipts overlap or repeat")
            seen.add(str(directory))
            expected={key:command[key] for key in ("argv","cwd","test_files")}
            request=registered["request"]
            build_inputs=public.get("public_build_inputs")
            if build_inputs is not None:
                validate_profile_build_inputs(public["execution_profile"], build_inputs, source, public["image"])
                _require(request.get("execution_profile")==public["execution_profile"]
                         and request.get("public_build_inputs")==build_inputs,
                         "registered public build descriptor or profile differs")
            _require({key:request[key] for key in expected}==expected
                     and Path(registered["source"])==source
                     and registered["source_digest"]==task["source_sha256"],
                     "public command or input differs from the registered paid check")
            _require(result.get("complete") is True and result.get("resource_valid") is True
                     and type(result.get("exit_code")) is int and result["exit_code"]==0,
                     "public command did not complete successfully")
            checked=verify_receipt({"id":request["id"]},directory/"commands",source,
                expected_profile=public["execution_profile"],expected_fixture=public.get("public_fixture"),
                **({"expected_build_inputs":build_inputs} if build_inputs is not None else {}))
            _require(checked==result["receipt"] and checked.get("complete") is True
                     and checked.get("resource_valid") is True
                     and type(checked.get("exit_code")) is int and checked["exit_code"]==0,
                     "independent public command readback differs from the frozen result")
        proofs[identity]={"verified_commands":len(rows),"source_sha256":task["source_sha256"]}
    return proofs
def verify_accounting(registration, descriptor, *, allocation_usd="78"):
    """Reopen the historical client evidence; retain the entire registered unknown hold."""
    _require(allocation_usd in ("78","112"), "unsupported explicit allocation")
    reconciled=_bound_json(registration,descriptor)
    _require(reconciled.get("schema")=="client-ledger-reconciliation-v1"
             and registration["ledger"]==reconciled["ledger"],
             "paid ledger differs from the frozen historical reconciliation")
    ledger=registration["ledger"]
    totals=accounting_totals(ledger)
    admit_history(ledger,carried_holds=registration.get("carried_holds"),bindings=registration["bindings"])
    opening_path=reconciled["opening_balance_source"]
    opening_sha=reconciled["opening_balance_sha256"]
    opening_rows=[row for row in ledger["charges"] if row["source"]==opening_path]
    _require(len(opening_rows)==1 and opening_rows[0]["receipt_sha256"]==opening_sha,
             "historical opening balance is missing or duplicated")
    opening=_bound_json(registration,{"path":opening_path,"sha256":opening_sha})
    _require(_money(str(opening["prior_campaign_spend_usd"]))==
             _money(opening_rows[0]["cost_usd"])==_money(reconciled["opening_balance_usd"]),
             "historical opening amount differs from its recorded source")
    receipt_bindings={}
    native_count=0
    with localcontext() as context:
        context.prec=128
        native_cost=Decimal(0)
        for row in ledger["charges"]:
            if row is opening_rows[0]:
                continue
            receipt=_bound_json(registration,{"path":row["source"],"sha256":row["receipt_sha256"]})
            _require(isinstance(receipt,dict) and receipt.get("scripted") is False
                     and receipt.get("unknown_provider_cost") is False
                     and isinstance(receipt.get("session_id"),str)
                     and row["id"]=="native-client:"+receipt["session_id"]
                     and _money(str(receipt.get("cost_usd")))==_money(row["cost_usd"]),
                     "historical native charge is not a matching final client receipt")
            receipt_bindings[row["source"]]=row["receipt_sha256"]
            native_count+=1
            native_cost+=_money(row["cost_usd"])
        for row in ledger["holds"]:
            receipt_bindings[row["source"]]=row["receipt_sha256"]
        known=native_cost+_money(opening_rows[0]["cost_usd"])
        held=sum((_money(row["reserved_usd"]) for row in ledger["holds"] if not row["settled"]),Decimal(0))
        allocated=known+held+Decimal(allocation_usd)
        _require(receipt_bindings==reconciled["receipt_bindings"]
                 and type(reconciled["native_receipts"]) is int
                 and native_count==reconciled["native_receipts"]
                 and native_cost==_money(reconciled["native_client_cost_usd"])
                 and known==_money(reconciled["known_client_cost_usd"])
                 and held==_money(reconciled["unresolved_reserve_usd"])
                 and _money(reconciled["proposed_new_allocation_usd"])==Decimal(allocation_usd)
                 and allocated==_money(reconciled["commitment_if_new_allocation_usd"])
                 and allocated<=_money(ledger["ceiling_usd"]),
                 "historical receipt coverage, sum, reserve or proposed commitment changed")
    return {"known_client_cost_usd":str(known),"native_receipts":native_count,
            "unresolved_reserve_usd":str(held),"commitment_if_new_allocation_usd":str(allocated),
            "unsettled_hold_ids":totals["unsettled_hold_ids"],
            "earlier_charge_rescan":reconciled.get("earlier_charge_rescan"),
            "provider_invoice_reconciliation":reconciled.get("provider_invoice_reconciliation")}
def _at(registration, path):
    path=Path(path)
    return _bound_json(registration,{"path":str(path),"sha256":registration["bindings"].get(str(path))})


def _argument(argv, name):
    _require(isinstance(argv,list) and all(isinstance(value,str) for value in argv)
             and argv.count(name)==1,"missing or repeated CLI argument: "+name)
    index=argv.index(name)
    _require(index+1<len(argv),"CLI argument value missing: "+name)
    return argv[index+1]


def verify_preloaded_context(registration, native, prepared, launch, public, requests):
    from native_executor import external
    descriptor=prepared.get("context_preload")
    _require(isinstance(descriptor,dict),"qualified runtime lacks preloaded mandatory context")
    for name,digest in descriptor["files"].items():
        _bound_path(registration,{"path":name,"sha256":digest})
    actor=Path(prepared["actor"])
    body=external.context_preload(prepared,actor)
    _require(body is not None and _argument(launch["argv"],"--append-system-prompt")==body
             and launch.get("context_preload_sha256")==hashlib.sha256(body.encode()).hexdigest(),
             "qualified CLI does not append the bound context body")
    frozen=Path(public["runtime"]["plugin"]["path"])/"skills/reconnaissance"
    copied=Path(descriptor["skill_path"]).parent
    originals={p.relative_to(frozen).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
               for p in frozen.rglob("*") if p.is_file()}
    actual={p.relative_to(copied).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
            for p in copied.rglob("*") if p.is_file()}
    _require(originals and originals==actual,"qualified copied recon differs from frozen skill/support inputs")
    expected=_at(registration,native/"expected.json")
    _require(expected.get("preload_visible")==external.worker.visible(body),
             "qualified pre-forward expectation differs from full frozen context")
    first=_at(registration,native/"request-0.json")
    _require(requests and requests[0]==first,"qualified first provider request is missing")
    for request in requests:
        external.transport.audit_request(request,expected)
    return True

def verify_native_build_inputs(registration, native, prepared, backend, ready, public):
    """Reopen the new build-input contract; legacy evidence keeps its original contract."""
    import public_build_inputs as build
    profile=public.get("execution_profile","fixture-v1")
    actor=Path(prepared["actor"])
    admitted=validate_profile_build_inputs(profile,public.get("public_build_inputs"),actor,public["image"])
    fields={"public_build_inputs","public_build_stage","public_build_inputs_helper"}
    if admitted is None:
        _require(not fields.intersection(prepared) and
                 not {"public_build_inputs","public_build_stage","public_build_generated_after"}.intersection(backend)
                 and "public_build_inputs" not in ready["expected"]
                 and "public_build_inputs_sha256" not in ready["expected"].get("binding",{}),
                 "legacy native proof carries undeclared public build inputs")
        return None
    _require(fields <= set(prepared) and prepared.get("execution_profile")==profile
             and prepared.get("image")==public["image"]
             and prepared["public_build_inputs"]==admitted["descriptor"],
             "native prepared build descriptor or profile differs")
    helper=_bound_path(registration,{"path":prepared["public_build_inputs_helper"],
        "sha256":prepared.get("files",{}).get(prepared["public_build_inputs_helper"])})
    canonical=Path(build.__file__).resolve(strict=True)
    _bound_path(registration,{"path":str(canonical),"sha256":registration["bindings"].get(str(canonical))})
    _require(helper.read_bytes()==canonical.read_bytes(),"native helper differs from frozen canonical implementation")
    stage=prepared["public_build_stage"]
    _require(isinstance(stage,dict) and stage.get("descriptor")==admitted["descriptor"],
             "native staged descriptor differs")
    closed=build.verify_staged(stage,actor,public["image"])
    _require(_at(registration,Path(stage["output"])/"manifest.json")==stage,
             "native stage manifest is not the frozen manifest")
    argv=_at(registration,native/"mcp-native-argv.json")
    _require(isinstance(argv,list) and all(isinstance(v,str) for v in argv)
             and argv[-4:]==[public["image"],"start","--project","/testbed"],
             "native build argv has a different worker boundary")
    mounts=[]
    for i,value in enumerate(argv[:-4]):
        if value=="--mount":
            _require(i+1<len(argv)-4 and not argv[i+1].startswith("--"),"native mount argument missing")
            mounts.append(argv[i+1])
    configured=build.validate_native_options({"--mount":mounts},admitted["descriptor"],stage,actor,public["image"])
    raw=_at(registration,native/"readiness/public-build-runtime-raw.json")
    runtime=build.validate_native_runtime(raw,admitted["descriptor"],stage,actor,public["image"])
    observed=_at(registration,native/"readiness/public-build-runtime.json")
    _require(observed.get("binding")==runtime and runtime["generated_sha256"] is None,
             "native live runtime is not the observed mount contract")
    _require(ready["expected"].get("public_build_inputs")==admitted["descriptor"]
             and ready["expected"].get("binding",{}).get("public_build_inputs_sha256")==admitted["fingerprint"],
             "native readiness does not bind the registered build inputs")
    _require(backend.get("public_build_inputs")==admitted["fingerprint"]
             and backend.get("public_build_stage")==stage
             and backend.get("public_build_generated_after")==closed["generated_sha256"]
             and configured==closed,
             "native closed generated evidence differs")
    return {"public_build_inputs_sha256":admitted["fingerprint"],
            "public_build_generated_after":closed["generated_sha256"]}

def verify_native_invocation(registration, directory, intent, public, *, feedback=False):
    """Reopen real CLI requests, source/capture, readiness, accounting and owned cleanup."""
    if type(feedback) is not bool:
        raise ValueError("native proof policy must be explicit")
    selected = None
    if feedback:
        import feedback_policy
        _require(registration.get("schema")==feedback_policy.SCHEMA, "native feedback proof schema differs")
        selected=feedback_policy.validated_request(intent)
        _require(selected is not None and public.get("feedback_policy")==
                 {"schema":feedback_policy.SCHEMA,"workspace":selected["check"]["cwd"]},
                 "native feedback public policy differs")
    bound=4 if feedback else 2
    directory=Path(directory)
    native=directory/"native"
    record=_at(registration,directory/"invocation.json")
    launch=_at(registration,native/"launch.json")
    receipt=_at(registration,native/"receipt.json")
    backend=_at(registration,native/"native-executor.json")
    prepared=_at(registration,native/"prepared.json")
    preparation=_at(registration,native/"public-preparation.json")
    monitor=_at(registration,native/"supervision-final.json")
    capture=_at(registration,native/"candidate-capture.json")
    cleanup=_at(registration,native/"cleanup.json")
    ready=_at(registration,native/"readiness/readiness.json")
    expected_effort="xhigh" if intent["arm"]=="X" else "low"
    argv=launch["argv"]
    _require(record["invocation_id"]==intent["invocation_id"]
             and Path(record["native_path"])==native and record.get("measurement_invalid") is False
             and all(record.get(key) is True for key in
                     ("context_valid","capture_complete","cleanup_complete","cost_is_final")),
             "qualified invocation has invalid identity, context, capture or settlement")
    _require(launch.get("scripted") is True and launch.get("real_credentials_read") is False
             and launch["source_image"]==public["image"]
             and launch.get("mcp_protocol_negotiation")=="legacy"
             and argv[0]==public["runtime"]["files"]["cli"]["path"]
             and _argument(argv,"--effort")==expected_effort
             and _argument(argv,"--model")=="claude-sonnet-5-5"
             and _argument(argv,"--setting-sources")=="user,project,local"
             and _argument(argv,"--plugin-dir")==public["runtime"]["plugin"]["path"]
             and _money(_argument(argv,"--max-budget-usd"))==_money(intent["cli_cap_usd"])
             and prepared["max_continuations"]==intent["max_continuations"]==bound
             and prepared["cli"]==public["runtime"]["files"]["cli"]["path"],
             "qualified CLI effort, cap, context, skill or continuation boundary differs")
    _require(receipt.get("scripted") is True and receipt.get("context_valid") is True
             and receipt["session_id"]==launch["session_id"]
             and receipt.get("unknown_provider_cost") is False
             and type(receipt.get("forwarded")) is int and receipt["forwarded"]==0
             and type(receipt.get("requests")) is int and receipt["requests"]>0
             and receipt.get("transport_errors")==[]
             and receipt.get("cleanup_error") is None and receipt.get("supervision_error") is None
             and _money(str(receipt["cost_usd"]))==_money(str(record["cost_usd"]))==Decimal(0),
             "qualified native financial or context receipt is invalid")
    expected_context={"recon_delivered":True,"system_delivered":True}
    if feedback:
        expected_context["feedback_prompt_delivered"]=True
        _require(prepared.get("feedback_policy")==selected
                 and prepared.get("checks")==feedback_policy.completion_checks(selected)
                 and receipt.get("workflow_completed") is True and backend.get("workflow_completed") is True
                 and receipt.get("public_verification",{}).get("status")=="completed"
                 and receipt.get("public_verification",{}).get("passed") is True,
                 "native feedback check scope, policy or completion differs")
    _require(backend.get("context_evidence")==expected_context
             and all(backend.get(key) is True for key in
                     ("context_valid","capture_complete","cleanup_complete","cost_is_final","scripted_provider"))
             and backend.get("provider_forwarded")==0,
             "native context or capture evidence is missing")
    _require(monitor.get("complete") is True and monitor.get("resource_ok") is True
             and monitor.get("errors")==[] and type(monitor.get("cgroup_probes")) is int
             and monitor["cgroup_probes"]>=2 and type(monitor.get("oom_kill")) is int
             and monitor["oom_kill"]==0,
             "qualified native runtime has incomplete or invalid resource samples")
    connections=list(native.glob("mcp-launch-*.json"))
    _require(len(connections)==1,"qualified native invocation has ambiguous worker identity")
    connection=_at(registration,connections[0])
    _require(isinstance(cleanup,list) and len(cleanup)==1 and cleanup[0].get("absent") is True
             and cleanup[0].get("name")==connection["name"],
             "qualified native cleanup has no unique independent absence")
    source=Path(intent["source"])
    _require(preparation["source_sha256"]==input_digest(source)
             and preparation.get("onboarding_reused") is True
             and preparation.get("onboarding_author_calls")==0
             and preparation["knowledge_sha256"]==public["knowledge_sha256"],
             "qualified invocation source or reused onboarding changed")
    _require(ready["expected"].get("index_omission_policy")==
             public.get("registered_readiness",{}).get("index_omission_policy"),
             "native index omission policy is not the registered public policy")
    baseline=public.get("source_baseline")
    _require(ready["expected"].get("source_baseline_sha256")==
             (baseline["sha256"] if baseline is not None else None),
             "native readiness uses an unregistered source baseline")
    checked_ready=validate_readiness(ready["expected"],ready["wire"],source=source)
    _require(checked_ready==ready["result"],"qualified native readiness differs on independent readback")
    patch=_bound_path(registration,{"path":str(native/"candidate.patch"),
        "sha256":registration["bindings"].get(str(native/"candidate.patch"))})
    _require(capture.get("complete") is True and capture["image"]==public["image"]
             and capture["baseline_commit"]==public.get("capture_base_commit",prepared["baseline_commit"])
             and capture["sha256"]==registration["bindings"][str(patch)]
             and type(capture.get("bytes")) is int and capture["bytes"]==patch.stat().st_size
             and input_digest(record["candidate"])==record["source_digest"],
             "qualified cumulative patch or physical candidate is not bound")
    requests=[_at(registration,path) for path in sorted(native.glob("request-*.json"))]
    efforts=[body["output_config"]["effort"] for body in requests
             if "effort" in body.get("output_config",{})]
    _require(efforts and all(value==expected_effort for value in efforts),
             "actual native request effort differs")
    if feedback:
        prompt=intent["public_packet"]["issue"]+"\n\nFrozen public packet:\n"+json.dumps(intent["public_packet"],sort_keys=True)
        prompt+="\n\n"+selected["common_instruction"]
        if selected["plan_instruction"]:
            prompt+="\n\n"+selected["plan_instruction"]
        _require(prepared.get("prompt")==prompt and requests
                 and any(message.get("role")=="user" and prompt in _text(message.get("content"))
                         for message in requests[0].get("messages",[]) if isinstance(message,dict)),
                 "actual first request lacks the exact feedback task and instructions")
    build_proof=verify_native_build_inputs(registration,native,prepared,backend,ready,public)
    verify_preloaded_context(registration,native,prepared,launch,public,requests)
    return {**(build_proof or {}), **({"max_continuations":bound} if feedback else {}),
            "effort":expected_effort,"cli_cap_usd":intent["cli_cap_usd"],
            "cgroup_probes":monitor["cgroup_probes"],"oom_kill":0,"context_preloaded":True,
            "source_digest":record["source_digest"],"provider_forwarded":0}
def _runtime_sources():
    # The post-run paid verifier is checked by final review, not executed by scripted actors.
    tools=Path(__file__).resolve().parent.parent
    paths=[]
    for folder in ("effort_protocol","agent_lifecycle","hint_authority_pilot"):
        paths.extend(path for path in (tools/folder).glob("*.py")
                     if not path.name.startswith("test_") and path.name!="paid_admission.py")
    paths.append(tools/"effort_protocol/prompts.json")
    return sorted(paths)


def verify_private_test_inputs(registration, private, grade_root):
    """Require canonical standalone inputs before rebuild and unchanged bytes after grading."""
    import trusted_test_inputs as core
    config=_bound_json(registration,{"path":private["config"],"sha256":private["config_sha256"]})
    descriptor=config.get("trusted_test_inputs")
    _require(isinstance(descriptor,dict),"prospective private evaluation requires trusted test inputs")
    roots,entries,_=core._validated(descriptor)
    for role in ("manifest","archive"):
        _bound_path(registration,{"path":descriptor[role],"sha256":descriptor[role+"_sha256"]})
    canonical=Path(__file__).resolve().parent
    for name in ("evaluator_entry.py","trusted_test_inputs.py","feedback_trusted_inputs.py"):
        matches=[(path,digest) for path,digest in config.get("bindings",{}).items() if Path(path).name==name]
        _require(len(matches)==1,"trusted private helper coverage differs: "+name)
        path,digest=matches[0]
        frozen=_bound_path(registration,{"path":path,"sha256":digest})
        _require(frozen.read_bytes()==(canonical/name).read_bytes(),
                 "trusted private helper differs from current frozen implementation: "+name)
    installed=_at(registration,Path(grade_root)/"trusted-input-installation.json")
    expected={"complete":True,"roots":roots,"entries_verified":len(entries),
              "manifest_sha256":descriptor["manifest_sha256"],
              "coverage":"Registered standalone inputs; no inline assertion claim"}
    remote=installed.get("descriptor")
    _require(isinstance(remote,dict) and set(remote)==set(descriptor)
             and all(remote[key]==descriptor[key] for key in
                     ("schema","manifest_sha256","archive_sha256"))
             and isinstance(installed.get("helper"),str)
             and re.fullmatch(r"/tmp/effort-trusted-[A-Za-z0-9]{8}/trusted_test_inputs.py",installed["helper"])
             and installed.get("helper_sha256")==hashlib.sha256((canonical/"trusted_test_inputs.py").read_bytes()).hexdigest()
             and installed.get("restoration")==expected,
             "trusted input restoration or helper differs")
    parent=PurePosixPath(installed["helper"]).parent
    _require(all(remote[role]==str(parent/Path(descriptor[role]).name) for role in ("manifest","archive"))
             and isinstance(installed.get("container"),str)
             and re.fullmatch(r"[0-9a-f]{64}",installed["container"]),
             "trusted input installation paths or container differ")
    path=Path(grade_root)/"runtime-observations.jsonl"
    observed=_bound_path(registration,{"path":str(path),"sha256":registration["bindings"].get(str(path))})
    rows=[json.loads(line) for line in observed.read_text().splitlines() if line.strip()]
    before=[row for row in rows if row.get("stage")=="before-remove"]
    _require(len(before)==1 and "error" not in before[0]
             and before[0].get("inspect",{}).get("Id")==installed["container"]
             and before[0].get("trusted_test_inputs")==expected,
             "trusted inputs lack unique matching postgrade byte verification")
    return expected

def verify_runtime(registration, descriptor, *, feedback=False):
    """Independently consume the closed, exact-schedule zero-forward native campaign."""
    if type(feedback) is not bool:
        raise ValueError("runtime proof policy must be explicit")
    if feedback:
        import feedback_policy
        _require(registration.get("schema")==feedback_policy.SCHEMA, "runtime feedback schema differs")
    attempts_expected=16 if feedback else 8
    keys={"root","registration","result","qualification","closure","ledger","producer"}
    _require(isinstance(descriptor,dict) and set(descriptor)==keys,"runtime qualification descriptor missing")
    root=Path(descriptor["root"])
    _require(root.is_absolute() and root.resolve(strict=True)==root and root.is_relative_to("/var/tmp")
             and root!=Path(registration["output_root"]),"qualification must be a distinct physical persistent root")
    names={"registration":"registration.json","result":"result.json",
           "qualification":"runtime-qualification.json","closure":"actor-batch-closed.json",
           "ledger":"ledger-final.json"}
    data={}
    for role,name in names.items():
        _require(Path(descriptor[role]["path"])==root/name,"runtime qualification file is outside its root")
        data[role]=_bound_json(registration,descriptor[role])
    qualified=data["registration"]
    if feedback:
        _require(qualified.get("schema")==feedback_policy.SCHEMA, "historical runtime proof cannot authorize feedback")
    result=data["result"]
    closed=data["closure"]
    summary=data["qualification"]
    _require(qualified["mode"]=="scripted" and qualified["selected"]==registration["selected"]
             and qualified["schedule"]==registration["schedule"]
             and set(qualified["tasks"])==set(registration["tasks"]),
             "qualified runtime does not use the exact original paid schedule and population")
    _require(qualified.get("qualification_driver")==descriptor["producer"],
             "qualified producer identity differs")
    _bound_path(registration,descriptor["producer"])
    for dependency in qualified.get("qualification_driver_dependencies",[]):
        _bound_path(registration,dependency)
    for path in _runtime_sources():
        name=str(path)
        expected=qualified["bindings"].get(name)
        _require(isinstance(expected,str) and registration["bindings"].get(name)==expected,
                 "qualified runtime source changed: "+name)
        _bound_path(registration,{"path":name,"sha256":expected})
    for identity,task in registration["tasks"].items():
        old=qualified["tasks"][identity]
        _require(old["source"]==task["source"] and old["source_sha256"]==task["source_sha256"]
                 and old["public_packet"]==task["public_packet"]
                 and old["backend"]["public"]==task["backend"]["public"]
                 and old["backend"]["private"]==task["backend"]["private"],
                 "qualified public/private task runtime differs from the paid task")
    _require(result.get("status")=="completed" and result.get("unexecuted")==[]
             and isinstance(result.get("attempts"),list) and len(result["attempts"])==attempts_expected
             and len(closed["attempts"])==attempts_expected and closed["ledger_sha256"]==descriptor["ledger"]["sha256"],
             "runtime qualification is incomplete or lacks full cost/source batch closure")
    _require(summary.get("attempts")==attempts_expected and summary.get("native_invocations")==16
             and summary.get("private_evaluator_processes")==attempts_expected and summary.get("provider_forwarded")==0
             and summary.get("all_workflows_closed" if feedback else "all_protocol_workflows_closed") is True
             and summary.get("efficacy_claim") is None
             and _money(str(summary["model_cost_usd"]))==Decimal(0),
             "runtime summary does not describe the complete zero-forward qualification")
    count=0
    trusted_count=0
    for index,(row,attempt,item) in enumerate(zip(result["attempts"],registration["schedule"],closed["attempts"])):
        directory=root/"attempts"/(str(index).zfill(2)+"-"+attempt["arm"])
        receipt_path=directory/"attempt.json"
        _require(Path(row["attempt_receipt"])==receipt_path
                 and Path(item["attempt_receipt"])==receipt_path
                 and item["receipt_sha256"]==registration["bindings"].get(str(receipt_path))
                 and row["task_id"]==attempt["task_id"] and row["arm"]==attempt["arm"]
                 and row["attempt_index"]==index and row.get("workflow_state")=="closed"
                 and row.get("measurement_invalid") is False and row.get("reason") is None,
                 "qualified attempt identity, workflow or closure changed")
        stored=_at(registration,receipt_path)
        _require({k:v for k,v in row.items() if k!="grade"}=={k:v for k,v in stored.items() if k!="grade"}
                 and item["candidate"]==row["candidate"] and item["source_digest"]==row["source_digest"]
                 and input_digest(row["candidate"])==row["source_digest"],
                 "qualified captured source or attempt receipt changed")
        phases=("repair",) if feedback else (("investigate","repair","challenge") if attempt["arm"] in ("P","R") else ("repair",))
        _require(len(row["invocations"])==len(phases),"qualified native phase inventory changed")
        public=registration["tasks"][attempt["task_id"]]["backend"]["public"]
        for phase_index,(decision,phase) in enumerate(zip(row["invocations"],phases)):
            phase_root=directory/phase
            intent=_at(registration,phase_root/"intent.json")
            expected_id=qualified["campaign_id"]+"::"+str(index)+"::"+phase
            cap=attempt["phase_cli_caps_usd"][phase_index] if len(phases)==3 else attempt["cli_cap_usd"]
            allowance=attempt["phase_reservations_usd"][phase_index] if len(phases)==3 else attempt["reserved_usd"]
            _require(intent["invocation_id"]==expected_id and intent["phase"]==phase
                     and intent["arm"]==attempt["arm"] and intent["task_id"]==attempt["task_id"]
                     and intent["cli_cap_usd"]==cap and intent["allowance_usd"]==allowance
                     and decision["record"]==_at(registration,phase_root/"invocation.json")
                     and decision.get("measurement_invalid") is False
                     and decision["cost"]=={"known_usd":"0","unknown":False},
                     "qualified phase identity, cap, allocation or settlement changed")
            if feedback:
                selected=feedback_policy.validated_request(intent)
                _require(selected is not None, "qualified repair-only invocation lacks its policy")
                verify_native_invocation(registration,phase_root,intent,public,feedback=True)
            else:
                verify_native_invocation(registration,phase_root,intent,public)
            count+=1
        grade_root=root/"grades"/str(index).zfill(2)
        packet=_at(registration,grade_root/"private-request.json")
        started=_at(registration,grade_root/"private-entry-started.json")
        grade=_at(registration,grade_root/"verdict.json")
        private=registration["tasks"][attempt["task_id"]]["backend"]["private"]
        _require(packet["source"]==row["candidate"] and packet["source_digest"]==row["source_digest"]
                 and packet["config"]==private["config"] and packet["config_sha256"]==private["config_sha256"]
                 and started["request_sha256"]==registration["bindings"].get(str(grade_root/"private-request.json"))
                 and started["entry_sha256"]==private["entry_sha256"]
                 and grade==row["grade"] and grade.get("valid") is True and type(grade.get("pass")) is bool,
                 "qualified independent evaluator process, input or complete verdict differs")
        if feedback:
            verify_private_test_inputs(registration,private,grade_root)
            trusted_count+=1
    _require(count==16,"qualified native invocation census differs")
    return {**({"trusted_input_attempts":trusted_count} if feedback else {}),"attempts":attempts_expected,"native_invocations":count,"private_evaluator_processes":attempts_expected,
            "provider_forwarded":0,"qualified_registration_sha256":descriptor["registration"]["sha256"]}
def verification_contract(registration):
    """Current Python runtime/tests plus the exact private evaluator and required project gate."""
    from evaluator_entry import verify_package
    tools=Path(__file__).resolve().parent.parent
    root=tools.parent
    sources=[p for folder in ("effort_protocol","agent_lifecycle","hint_authority_pilot")
             for p in (tools/folder).glob("*.py")]
    sources.append(tools/"effort_protocol/prompts.json")
    packages=set()
    for task in registration["tasks"].values():
        descriptor=task["backend"]["private"]
        config=_bound_json(registration,{"path":descriptor["config"],"sha256":descriptor["config_sha256"]})
        package=verify_package(config["package_root"],config["package_files"])
        packages.add(package)
        sources.extend(package/name for name in config["package_files"])
    _require(len(packages)==1,"final verification must use the same frozen private evaluator package")
    package=next(iter(packages))
    unit=["python3","-B","-m","unittest","discover","-s"]
    commands={
        "protocol":{"cwd":str(root),"argv":unit+["tools/effort_protocol","-p","test_*.py"]},
        "lifecycle":{"cwd":str(root),"argv":unit+["tools/agent_lifecycle","-p","test_*.py"]},
        "evaluator":{"cwd":str(package),"argv":unit+[".","-p","test_*.py"]},
        "gate":{"cwd":str(root),"argv":["./scripts/gate.sh","--check"]}}
    return sorted(set(sources)),commands

def verify_verification(registration, descriptor):
    evidence=_bound_json(registration,descriptor)
    _require(evidence.get("schema")=="effort-verification-v1","final verification schema differs")
    sources,commands=verification_contract(registration)
    before=evidence.get("source_before")
    _require(isinstance(before,dict) and set(before)=={str(p) for p in sources}
             and before==evidence.get("source_after"),"final verification source coverage or before/after differs")
    for name,digest in before.items():
        _bound_path(registration,{"path":name,"sha256":digest})
    _bound_path(registration,evidence["producer"])
    executions=evidence.get("executions")
    _require(isinstance(executions,dict) and set(executions)==set(commands),
             "required final verification lane missing")
    for role,command in commands.items():
        row=executions[role]
        _require(row.get("argv")==command["argv"] and row.get("cwd")==command["cwd"]
                 and type(row.get("exit_code")) is int and row["exit_code"]==0
                 and row.get("timed_out") is False,"final verification command, cwd or result differs: "+role)
        environment=row.get("environment",{})
        temporary=Path(environment.get("TMPDIR","/missing"))
        _require(environment.get("PYTHONDONTWRITEBYTECODE")=="1" and temporary.is_absolute()
                 and temporary.is_dir() and temporary.resolve()==temporary and temporary.is_relative_to("/var/tmp"),
                 "final verification requires physical external temporary storage and no package bytecode writes")
        if role=="gate":
            _require(all(environment.get(key)==value for key,value in
                         {"CODESCOUT_WIP_ATTRIBUTION_TIMEOUT_MS":"120000","NEXTEST_TEST_THREADS":"4","RUST_TEST_THREADS":"4"}.items()),
                     "final gate environment differs")
        if role=="protocol":
            _require(all(isinstance(environment.get(key),str)
                         and len(environment[key])==71 and environment[key].startswith("sha256:")
                         for key in ("EFFORT_PROTOCOL_TEST_IMAGE","EFFORT_FIXTURE_TEST_IMAGE")),
                     "final protocol Docker controls were not explicitly enabled")
        log=_bound_path(registration,row["log"])
        _require(log.stat().st_size>0,"final verification log is empty")
    return {"executions":sorted(executions),"source_files":len(before)}

def review_target(registration):
    """Protect the experiment while avoiding a report/verification self-reference."""
    value=copy.deepcopy(registration)
    value.pop("bindings",None)
    for name in ("review","verification"):
        value.get("admission",{}).pop(name,None)
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(",",":")).encode()).hexdigest()

def _review_log(registration, descriptor):
    path=_bound_path(registration,descriptor)
    _require(path.stat().st_size>0,"observed review test log is empty")

def _observed_mutation(registration, mutation, sources):
    _require(isinstance(mutation,dict) and isinstance(mutation.get("id"),str) and mutation["id"],
             "review mutation identity missing")
    source=mutation.get("source")
    _require(source in sources and mutation["original"]["sha256"]==sources[source],
             "review mutation was not applied to the reviewed source")
    _bound_path(registration,mutation["original"])
    changed=_bound_path(registration,mutation["mutated"])
    _require(mutation["mutated"]["sha256"]!=sources[source] and changed.stat().st_size>0,
             "review mutation did not change source bytes")
    _review_log(registration,mutation["log"])
    code=mutation.get("test_exit_code")
    valid=(type(mutation.get("syntax_exit_code")) is int and mutation["syntax_exit_code"]==0
           and mutation.get("syntax_timed_out") is False and mutation.get("timed_out") is False
           and type(code) is int and code in (0,1))
    if not valid:
        return None
    equivalent=mutation.get("equivalent") is True
    _require(not equivalent or (isinstance(mutation.get("equivalence_reason"),str)
                                and mutation["equivalence_reason"].strip()),
             "equivalent survivor lacks an explicit reviewed reason")
    return "killed" if code>0 else "equivalent" if equivalent else "survived"

def verify_review(registration, descriptor):
    _require(isinstance(descriptor,dict) and set(descriptor)=={"report","resolution"},
             "whole-admission review descriptor missing")
    report=_bound_json(registration,descriptor["report"])
    target=review_target(registration)
    _require(report.get("schema")=="effort-whole-admission-review-v1"
             and report.get("scope")=="whole-admission" and report.get("target_sha256")==target
             and isinstance(report.get("reviewer"),dict) and report["reviewer"].get("id")
             and report["reviewer"].get("model") and report.get("verdict") in ("approve","changes_required"),
             "whole-admission review does not cover this exact experiment")
    paths,_=verification_contract(registration)
    before=report.get("source_before")
    _require(isinstance(before,dict) and set(before)=={str(p) for p in paths},
             "whole-admission review source coverage differs")
    current={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    for name,digest in current.items():
        _bound_path(registration,{"path":name,"sha256":digest})
    baseline=report["baseline"]
    _require(type(baseline.get("exit_code")) is int and baseline["exit_code"]==0
             and baseline.get("timed_out") is False,
             "review mutation baseline did not pass")
    _review_log(registration,baseline["log"])
    mutants=report.get("mutations",[])
    _require(isinstance(mutants,list),"observed applied mutations missing")
    observed={}
    changed=set()
    for mutation in mutants:
        result=_observed_mutation(registration,mutation,before)
        _require(mutation["id"] not in observed,"duplicate review mutation identity")
        if result is not None:
            signature=(mutation["source"],mutation["mutated"]["sha256"])
            _require(signature not in changed,"duplicate applied mutation bytes")
            changed.add(signature)
        observed[mutation["id"]]=result
    valid=sum(value is not None for value in observed.values())
    _require(valid>=8,"fewer than eight valid actually applied review mutations")
    findings=report.get("findings")
    _require(isinstance(findings,list) and all(isinstance(row,dict) and row.get("id")
                                             and row.get("severity") in ("high","medium","low") for row in findings),
             "review findings inventory is invalid")
    important={row["id"] for row in findings if row["severity"] in ("high","medium")}
    survivors={identity for identity,result in observed.items() if result=="survived"}
    resolution=descriptor["resolution"]
    if resolution is None:
        _require(report["verdict"]=="approve" and not important and not survivors and current==before,
                 "whole-admission review requires a bounded correction or current-source replay")
        rounds=0
    else:
        correction=_bound_json(registration,resolution)
        _require(correction.get("schema")=="effort-bounded-review-correction-v1"
                 and type(correction.get("correction_rounds")) is int and correction["correction_rounds"]==1
                 and correction.get("review_sha256")==descriptor["report"]["sha256"]
                 and correction.get("target_sha256")==target and correction.get("source_before")==before
                 and correction.get("source_after")==current and correction.get("outstanding")==[]
                 and important<=set(correction.get("findings_closed",[])),
                 "bounded correction does not resolve the exact review against current source")
        replayed=set()
        for mutation in correction.get("replays",[]):
            _require(mutation["id"] in survivors and mutation["id"] not in replayed,
                     "correction replay is duplicate or was not an observed survivor")
            original=next(row for row in mutants if row["id"]==mutation["id"])
            _require(mutation.get("source")==original["source"]
                     and mutation.get("original",{}).get("sha256")==original["original"]["sha256"]
                     and mutation.get("mutated",{}).get("sha256")==original["mutated"]["sha256"],
                     "correction replay differs from the original survivor mutation")
            _require(_observed_mutation(registration,mutation,current)=="killed",
                     "original surviving mutant was not observed killed after correction")
            replayed.add(mutation["id"])
        _require(replayed==survivors,"bounded correction lacks exact survivor replays")
        rounds=1
    return {"valid_applied_mutants":valid,"original_survivors":len(survivors),
            "bounded_correction_rounds":rounds,"reviewer":report["reviewer"]}

def verify_build_preparation(registration, public, row):
    """Bind public setup custody while preserving its unknown non-author compute costs."""
    import public_build_inputs as build
    template=Path(public["template"])
    admitted=validate_profile_build_inputs(public.get("execution_profile","fixture-v1"),
        public.get("public_build_inputs"),template,public.get("image",""))
    if admitted is None:
        _require(not {"public_build_inputs","public_build_preparation"}.intersection(row),
                 "legacy shared preparation carries undeclared build inputs")
        return {},None
    _require(row.get("public_build_inputs")==admitted["descriptor"] and "public_build_preparation" in row,
             "shared preparation lacks registered public build inputs")
    evidence=_bound_json(registration,row["public_build_preparation"])
    _require(set(evidence)=={"schema","image","descriptor_sha256","helper","producer",
                             "source_manifests","version_probes","seed"}
             and evidence["schema"]=="public-build-preparation-v1"
             and evidence["image"]==public["image"] and evidence["seed"]==admitted["descriptor"]["seed"]
             and evidence["descriptor_sha256"]==admitted["fingerprint"],
             "public build preparation identity differs")
    _bound_path(registration,evidence["producer"])
    helper=_bound_path(registration,evidence["helper"])
    _require(helper.read_bytes()==Path(build.__file__).read_bytes(),
             "shared helper differs from canonical implementation")
    names={"Cargo.toml","Cargo.lock","package.json","package-lock.json","pnpm-lock.yaml",
           "pnpm-workspace.yaml","yarn.lock",".npmrc","rust-toolchain","rust-toolchain.toml"}
    manifests=sorted(str(p.relative_to(template)) for p in template.rglob("*")
                     if p.is_file() and p.name in names and
                     not {".git",".codescout",".claude",".buddy",".superpowers"}.intersection(p.relative_to(template).parts))
    rows=evidence["source_manifests"]
    _require(isinstance(rows,list) and all(isinstance(r,dict) and set(r)=={"relative","path","sha256"} for r in rows)
             and [r["relative"] for r in rows]==manifests,
             "public manifest inventory is incomplete or noncanonical")
    for item in rows:
        _require(item["path"]==str(template/item["relative"]),"public manifest path differs")
        _bound_path(registration,item)
    versions=evidence["version_probes"]
    _require(isinstance(versions,list) and versions and
             len({v.get("path") for v in versions if isinstance(v,dict)})==len(versions),
             "public tool version evidence missing or repeated")
    for descriptor in versions:
        probe=_bound_json(registration,descriptor)
        _require(probe.get("image")==public["image"] and type(probe.get("returncode")) is int
                 and probe["returncode"]==0 and isinstance(probe.get("argv"),list) and probe["argv"]
                 and all(isinstance(v,str) and v for v in probe["argv"])
                 and isinstance(probe.get("stdout"),str) and probe["stdout"].strip()
                 and isinstance(probe.get("stderr"),str),"public tool version probe is invalid")
    return {"public_build_inputs":admitted["descriptor"],
            "public_build_preparation":row["public_build_preparation"]},admitted["fingerprint"]

def verify_shared_preparation(registration, descriptor):
    evidence=_bound_json(registration,descriptor)
    charged=registration["shared_preparation"]
    _require(evidence.get("schema")=="effort-shared-reuse-v1"
             and type(evidence.get("client_author_calls")) is int and evidence["client_author_calls"]==0
             and _money(evidence.get("new_client_model_cost_usd"))==Decimal(0)
             and _money(charged["cost_usd"])==Decimal(0)
             and charged["receipt_sha256"]==descriptor["sha256"],
             "shared preparation is not the bound zero-author reuse receipt")
    _bound_path(registration,evidence["producer"])
    _require(evidence.get("excluded_costs")=={name:{"status":"unmeasured","usd":None}
                                             for name in ("root","review","embedding_compute")},
             "unmeasured non-actor costs must remain explicit unknowns")
    _require(isinstance(evidence.get("tasks"),dict) and set(evidence["tasks"])==set(registration["tasks"]),
             "shared reuse task coverage differs")
    build_proofs={}
    for identity,task in registration["tasks"].items():
        public=task["backend"]["public"]
        expected={name:public[name] for name in ("template","template_sha256","knowledge_sha256")}
        extra,fingerprint=verify_build_preparation(registration,public,evidence["tasks"][identity])
        expected.update(extra)
        if fingerprint is not None:
            build_proofs[identity]=fingerprint
        template=Path(public["template"])
        _require(evidence["tasks"][identity]==expected and template.is_absolute()
                 and template.resolve(strict=True)==template and input_digest(template)==public["template_sha256"]
                 and input_digest(template/".codescout",public["knowledge_paths"])==public["knowledge_sha256"],
                 "shared frozen source or onboarding changed")
        for relative in public["knowledge_paths"]:
            path=template/".codescout"/relative
            _bound_path(registration,{"path":str(path),"sha256":registration["bindings"].get(str(path))})
    return {**({"public_build_inputs":build_proofs} if build_proofs else {}),"client_author_calls":0,"new_client_model_cost_usd":"0","excluded_costs":evidence["excluded_costs"]}

def verify_paid(registration):
    """Require consuming evidence at every paid boundary; a ready flag has no authority."""
    checks={"population":verify_population,"public_commands":verify_public_commands,
            "accounting":verify_accounting,"runtime":verify_runtime,
            "verification":verify_verification,"review":verify_review,
            "shared_preparation":verify_shared_preparation}
    admission=registration.get("admission")
    _require(registration.get("schema")=="evidence-campaign-v1" and registration.get("mode")=="paid"
             and isinstance(admission,dict) and set(admission)==set(checks)|{"credential_path"},
             "complete paid admission evidence is not yet qualified")
    _require(isinstance(admission["credential_path"],str) and Path(admission["credential_path"]).is_absolute()
             and all(task["backend"].get("scripted_plans")=={} for task in registration["tasks"].values()),
             "paid credential identity or actor mode differs")
    proofs={name:check(registration,admission[name]) for name,check in checks.items()}
    return {"ready":True,"proofs":proofs}


class PaidAdmission:
    """A verified host registration, never a caller-supplied admission boolean."""
    def __init__(self, registration, token_path):
        self.registration=copy.deepcopy(registration)
        self.proof=verify_paid(self.registration)
        _require(isinstance(self.proof,dict) and self.proof.get("ready") is True,
                 "paid evidence verification did not succeed")
        expected=self.registration["admission"]["credential_path"]
        _require(token_path is not None and str(Path(token_path))==expected,
                 "credential path differs from reviewed registration")
        path=Path(expected)
        _require(path.is_absolute() and path.resolve(strict=True)==path and path.is_file()
                 and path.stat().st_uid==os.getuid() and stat.S_IMODE(path.stat().st_mode)==0o600,
                 "registered credential must be an owned physical0600file")
        self.token_path=expected
        self.fingerprint=self._identity(self.registration)
        self.used=set()

    @staticmethod
    def _identity(value):
        return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(",",":")).encode()).hexdigest()

    def authorize(self, request, out, public, token_path):
        _require(self._identity(self.registration)==self.fingerprint,"paid authorization registration changed")
        _require(token_path is not None and str(Path(token_path))==self.token_path,
                 "paid credential changed after admission")
        for name,digest in self.registration["bindings"].items():
            _bound_path(self.registration,{"path":name,"sha256":digest})
        index=request["attempt_index"]
        _require(type(index) is int and 0<=index<len(self.registration["schedule"]),
                 "paid attempt index invalid")
        attempt=self.registration["schedule"][index]
        phases=("investigate","repair","challenge") if attempt["arm"] in ("P","R") else ("repair",)
        phase=request["phase"]
        _require(phase in phases,"paid phase invalid")
        phase_index=phases.index(phase)
        identity=self.registration["campaign_id"]+"::"+str(index)+"::"+phase
        directory=Path(self.registration["output_root"])/"attempts"/(str(index).zfill(2)+"-"+attempt["arm"])
        task=self.registration["tasks"][attempt["task_id"]]
        cap=attempt["phase_cli_caps_usd"][phase_index] if len(phases)==3 else attempt["cli_cap_usd"]
        allowance=attempt["phase_reservations_usd"][phase_index] if len(phases)==3 else attempt["reserved_usd"]
        packet=copy.deepcopy(request["public_packet"])
        prior=packet.pop("prior_public_artifacts",[])
        registered_packet=copy.deepcopy(task["public_packet"])
        registered_packet.pop("prior_public_artifacts",None)
        _require(request["task_id"]==attempt["task_id"] and request["arm"]==attempt["arm"]
                 and request["invocation_id"]==identity and identity not in self.used
                 and Path(out).resolve()==(directory/phase).resolve()
                 and request["cli_cap_usd"]==cap and request["allowance_usd"]==allowance
                 and request["effort"]==("xhigh" if attempt["arm"]=="X" else "low")
                 and request["max_continuations"]==2 and public==task["backend"]["public"]
                 and packet==registered_packet,
                 "paid invocation differs from the reviewed schedule, budget or public packet")
        expected_prior=[]
        source=task["source"]
        digest=task["source_sha256"]
        turns=0
        for earlier in phases[:phase_index]:
            earlier_id=self.registration["campaign_id"]+"::"+str(index)+"::"+earlier
            _require(earlier_id in self.used,"paid phase cannot skip an earlier authorized phase")
            path=directory/earlier/"invocation.json"
            _require(not path.is_symlink() and path.is_file(),"prior paid phase receipt missing")
            record=json.loads(path.read_bytes())
            _require(record.get("measurement_invalid") is False and record.get("cost_is_final") is True
                     and record["state"]["phase"] in phases and record.get("public_artifact") is not None,
                     "prior paid phase did not close with settled evidence")
            source,digest,turns=record["candidate"],record["source_digest"],record["state"]["turns_used"]
            expected_prior.append(record["public_artifact"])
        _require(request["source"]==source and input_digest(source)==digest
                 and request["state"]["turns_used"]==turns and prior==expected_prior
                 and request["state"]["baseline_digest"]==task["source_sha256"]
                 and request["state"]["run_id"]==self.registration["campaign_id"]+"-"+str(index),
                 "paid invocation source, prior evidence or cumulative state changed")
        self.used.add(identity)
        return {"authorized_invocation":identity}
