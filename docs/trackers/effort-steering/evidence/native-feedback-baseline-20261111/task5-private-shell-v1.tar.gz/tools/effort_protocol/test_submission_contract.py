"""Public contract delivery checks; no Docker or provider is needed."""
import copy
import json
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import test_adapter as fixtures

adapter = fixtures.adapter
ClosedActor = fixtures.ClosedActor


class SubmissionContractTests(unittest.TestCase):
    setUp = fixtures.AdapterTests.setUp
    run_phase = fixtures.AdapterTests.run_phase

    def test_public_submission_contract_reaches_all_protocol_phases(self):
        for phase in ("investigate", "repair", "challenge"):
            with self.subTest(phase=phase):
                request = copy.deepcopy(self.request)
                request["state"]["phase"] = phase
                request["out"] = str(self.root / ("contract-" + phase))
                actor = ClosedActor(self.source, None)
                adapter.run_phase(request, actor)
                packet = actor.calls[0]
                text = packet["prompt"]
                self.assertIn("<submission-contract>", text)
                contract = json.loads(text.split("<submission-contract>\n", 1)[1]
                                      .split("\n</submission-contract>", 1)[0])
                self.assertEqual(contract["version"], "public-submission-contract-v1")
                self.assertEqual(contract["output_path"], "submission.json")
                schema = contract["submission_schema"]
                self.assertEqual(set(schema["required"]), {"status", "clauses", "commands"})
                self.assertEqual(schema["properties"]["status"]["enum"],
                                 ["submitted", "incomplete", "budget_exhausted"])
                clause = schema["properties"]["clauses"]["items"]
                self.assertEqual(set(clause["required"]), {"id", "kind", "role", "receipts"})
                self.assertEqual(clause["properties"]["kind"]["enum"],
                                 ["requirement", "preservation", "uncertainty"])
                command = schema["properties"]["commands"]
                self.assertEqual(command["maxItems"], 8)
                self.assertEqual(set(command["items"]["required"]), {"id", "argv", "cwd", "test_files"})
                execution = contract["execution"]
                self.assertEqual(execution["source_mount"], "/work")
                self.assertTrue(execution["source_read_only"])
                self.assertEqual(execution["allowed_probe_prefixes"], ["probes/"])
                self.assertEqual(execution["timeout_s"], 10)
                self.assertEqual(execution["max_log_bytes"], 1048576)
                self.assertEqual(contract["phase"], phase)
                self.assertIn("reproduction", contract["phase_rules"]["investigate"]["required_roles"])
                self.assertIn("legitimate", contract["phase_rules"]["investigate"]["required_roles"])
                self.assertTrue(contract["phase_rules"]["challenge"]["no_unresolved_uncertainty"])
                self.assertNotIn(str(self.root), text)
                started = json.loads((Path(request["out"]) / "started.json").read_text())
                self.assertEqual(started["prompt_sha256"], adapter.packet_digest(text))
                saved = json.loads((Path(request["out"]) / "actor-packet.json").read_text())
                self.assertEqual(saved, packet)

    def test_continuation_control_does_not_receive_protocol_submission_contract(self):
        self.request["arm"] = "R"
        self.actor.submission = None
        self.run_phase()
        packet = self.actor.calls[0]
        self.assertNotIn("submission-contract", packet["prompt"])
        self.assertNotIn("submission.json", packet["prompt"])
        self.assertNotIn("allowed_probe_prefixes", packet)

    def test_invalid_public_probe_locations_refuse_before_actor(self):
        for index, prefixes in enumerate((None, "probes/", ["/"], ["../"], ["./"],
                                          ["probes//"], ["probes/../"], ["probes\\x/"],
                                          ["probes\n/"], ["probes/", "probes/"])):
            with self.subTest(prefixes=prefixes):
                request = copy.deepcopy(self.request)
                request["out"] = str(self.root / ("bad-probe-" + str(index)))
                request["allowed_probe_prefixes"] = prefixes
                actor = ClosedActor(self.source, None)
                with self.assertRaises(adapter.PhaseInvalid):
                    adapter.run_phase(request, actor)
                self.assertEqual(actor.calls, [])
                self.assertFalse(Path(request["out"]).exists())

if __name__ == "__main__":
    unittest.main()
