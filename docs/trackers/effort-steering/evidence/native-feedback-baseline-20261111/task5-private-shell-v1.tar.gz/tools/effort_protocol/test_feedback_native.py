"""Real native-composition/executor code with only external runtime calls doubled."""
import copy
import json
import unittest
from unittest.mock import patch

import campaign_native as campaign
import feedback_policy as policy
import native_executor as native
import test_campaign_native as composition_fixtures
import test_native_executor as executor_fixtures


class FeedbackCompositionTests(unittest.TestCase):
    setUp = composition_fixtures.NativeCompositionTests.setUp
    prepare = composition_fixtures.NativeCompositionTests.prepare
    relay = composition_fixtures.NativeCompositionTests.relay
    protocol = composition_fixtures.NativeCompositionTests.protocol
    invoke = composition_fixtures.NativeCompositionTests.invoke

    def configure(self, arm):
        selected = policy.condition_spec(arm, "rust")
        self.request.update(arm=arm, phase="repair", effort=selected["effort"],
                            feedback_policy=selected, max_continuations=4,
                            cli_cap_usd=selected["cli_cap_usd"], allowance_usd=selected["reserve_usd"])
        self.public["feedback_policy"] = {"schema": "native-public-feedback-v1", "workspace": "rust"}
        return selected

    def check_condition(self, arm, command):
        selected = self.configure(arm)
        result = self.invoke()
        self.assertFalse(result["measurement_invalid"])
        self.assertEqual(result["state"]["phase"], "closed")
        actors = [packet for kind, packet in self.calls if kind == "actor"]
        self.assertEqual(len(actors), 1)
        self.assertEqual(actors[0]["feedback_policy"], selected)
        self.assertEqual(actors[0]["max_continuations"], 4)
        self.assertEqual(actors[0]["phase"], "repair")
        cfg = json.loads((self.out / "native/prepared.json").read_text())
        self.assertEqual(cfg["max_continuations"], 4)
        self.assertEqual(cfg["feedback_policy"], selected)
        self.assertEqual(cfg["checks"], [{"id": "public-feedback-compile", "command": command}])
        self.assertFalse(any(kind == "protocol" for kind, _ in self.calls))

    def test_P_is_one_ordinary_repair_with_enforced_all_targets(self):
        self.check_condition("P", "cd rust && cargo check --offline --workspace --all-targets")

    def test_raw_native_lifecycle_survives_incomplete_workflow_for_operational_audit(self):
        self.configure("P")
        self.completed = False
        result = self.invoke()
        self.assertEqual(result["state"]["phase"], "incomplete")
        self.assertFalse(result["workflow_completed"])
        self.assertEqual(result["lifecycle"], {"continuations": 0})

    def test_R_gets_same_plan_but_ordinary_completion_check(self):
        self.check_condition("R", "cd rust && cargo check --offline --workspace")

    def test_L_keeps_ordinary_completion_check(self):
        self.check_condition("L", "cd rust && cargo check --offline --workspace")

    def test_X_uses_the_same_check_scope_as_P(self):
        self.check_condition("X", "cd rust && cargo check --offline --workspace --all-targets")

    def test_policy_mismatch_is_rejected_before_runtime_effects(self):
        self.configure("P")
        self.public["feedback_policy"]["workspace"] = "."
        with self.assertRaises(ValueError):
            self.invoke()
        self.assertEqual(self.calls, [])

    def test_new_policy_cannot_be_supplied_only_on_one_side(self):
        self.configure("P")
        del self.public["feedback_policy"]
        with self.assertRaises(ValueError):
            self.invoke()
        self.assertEqual(self.calls, [])

    def test_mutated_effective_fields_are_rejected_before_runtime(self):
        self.configure("P")
        self.request["feedback_policy"]["check"]["argv"].remove("--all-targets")
        with self.assertRaises(ValueError):
            self.invoke()
        self.assertEqual(self.calls, [])


class FeedbackExecutorTests(unittest.TestCase):
    setUp = executor_fixtures.NativeExecutorTests.setUp

    def configure(self, arm="P"):
        selected = policy.condition_spec(arm, ".")
        self.packet.update(arm=arm, phase="repair", effort=selected["effort"],
                           feedback_policy=selected, max_continuations=4,
                           cli_cap_usd=selected["cli_cap_usd"], allowance_usd=selected["reserve_usd"])
        cfg = json.loads((self.prepared / "prepared.json").read_text())
        cfg.update(feedback_policy=selected, max_continuations=4,
                   checks=[{"id": "public-feedback-compile",
                            "command": "cargo check --offline --workspace" +
                            (" --all-targets" if arm in ("P", "X") else "")}])
        (self.prepared / "prepared.json").write_text(json.dumps(cfg))
        self.receipt["workflow_completed"] = True
        self.receipt["lifecycle"]["continuations"] = 4
        return selected

    def launch(self, *args, **kwargs):
        receipt = executor_fixtures.NativeExecutorTests.launch(self, *args, **kwargs)
        if not getattr(self, "omit_actual_prompt", False):
            cfg = json.loads((self.prepared / "prepared.json").read_text())
            path = self.prepared / "request-0.json"
            actual = json.loads(path.read_text())
            actual["messages"].append({"role": "user", "content": [
                {"type": "text", "text": cfg["prompt"]}]})
            path.write_text(json.dumps(actual))
        return receipt

    def test_repair_only_P_has_no_submission_requirement_and_accepts_fifth_turn(self):
        selected = self.configure()
        with patch.object(native.external, "launch", self.launch):
            result = self.executor.execute(self.packet)
        cfg = json.loads((self.prepared / "prepared.json").read_text())
        self.assertEqual(result["turns"], 5)
        self.assertTrue(result["context_valid"])
        self.assertTrue(result["workflow_completed"])
        self.assertIn(selected["common_instruction"], cfg["prompt"])
        self.assertIn(selected["plan_instruction"], cfg["prompt"])
        self.assertNotIn("Write submission.json", cfg["prompt"])
        self.assertIsNone(result["submission"])
        self.assertEqual(self.launched["effort"], "low")

    def test_L_does_not_receive_the_optional_plan(self):
        self.configure("L")
        with patch.object(native.external, "launch", self.launch):
            result = self.executor.execute(self.packet)
        cfg = json.loads((self.prepared / "prepared.json").read_text())
        self.assertTrue(result["context_valid"])
        self.assertNotIn("--all-targets", cfg["prompt"])

    def test_missing_actual_prompt_delivery_preserves_cost_but_invalidates_context(self):
        self.configure()
        self.omit_actual_prompt = True
        with patch.object(native.external, "launch", self.launch):
            result = self.executor.execute(self.packet)
        self.assertFalse(result["context_valid"])
        self.assertEqual(result["cost_usd"], "0.07")
        self.assertTrue(result["capture_complete"])

    def test_changed_prepared_check_is_rejected_before_external_launch(self):
        self.configure()
        cfg = json.loads((self.prepared / "prepared.json").read_text())
        cfg["checks"][0]["command"] = "true"
        (self.prepared / "prepared.json").write_text(json.dumps(cfg))
        with patch.object(native.external, "launch", side_effect=AssertionError("must not launch")):
            with self.assertRaises(ValueError):
                self.executor.execute(self.packet)

    def test_mismatched_effort_continuation_and_cap_fail_before_launch(self):
        self.configure()
        for changes in [{"effort": "xhigh"}, {"max_continuations": 2},
                        {"cli_cap_usd": "5.50"}, {"phase": "challenge"}]:
            packet = copy.deepcopy(self.packet)
            packet.update(changes)
            with self.subTest(changes=changes):
                with patch.object(native.external, "launch", side_effect=AssertionError("must not launch")):
                    with self.assertRaises(ValueError):
                        self.executor.execute(packet)

    def test_over_bound_turns_remain_invalid_and_incomplete_is_preserved(self):
        self.configure()
        self.receipt["workflow_completed"] = False
        self.receipt["lifecycle"]["continuations"] = 5
        with patch.object(native.external, "launch", self.launch):
            result = self.executor.execute(self.packet)
        self.assertFalse(result["context_valid"])
        self.assertFalse(result["workflow_completed"])
        self.assertEqual(result["cost_usd"], "0.07")


if __name__ == "__main__":
    unittest.main()
