"""Failures in evidence persistence must not leave actual clients running."""
import errno
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parent))
import qualify_native as native


class QualificationCleanupTests(unittest.TestCase):
    def test_trace_write_failure_still_stops_client_and_removes_owned_worker(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            proc = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(60)"],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
            self.addCleanup(lambda: proc.kill() if proc.poll() is None else None)
            self.addCleanup(proc.stdout.close)
            actual_wait = proc.wait
            waited = []
            def wait(timeout=None):
                waited.append(timeout)
                if len(waited) == 1:
                    raise subprocess.TimeoutExpired("fixture client", timeout)
                return actual_wait(timeout=timeout)
            removed = []
            def docker_run(argv, **kwargs):
                if argv[1:3] == ["rm", "-f"]:
                    removed.append(argv[-1])
                    return subprocess.CompletedProcess(argv, 0, "", "")
                if removed:
                    return subprocess.CompletedProcess(argv, 1, "", "Error: No such object")
                name = argv[-1]
                row = {"Id": "owned-cid", "Image": "sha256:" + "a" * 64,
                       "Config": {"Labels": {"codescout.hfa": name}}}
                return subprocess.CompletedProcess(argv, 0, json.dumps([row]), "")
            with patch.object(native.subprocess, "Popen", return_value=proc), \
                 patch.object(native.subprocess, "run", side_effect=docker_run), \
                 patch.object(native.select, "select", side_effect=OSError("readiness startup failed")), \
                 patch.object(native, "_save", side_effect=OSError(errno.EDQUOT, "Disk quota exceeded")), \
                 patch.object(proc, "wait", side_effect=wait):
                with self.assertRaises(Exception):
                    native._readiness(root,
                        ["docker", "run", "--name", "placeholder", "--label", "placeholder"],
                        root, root, {"native_image": "sha256:" + "a" * 64})
            self.assertIsNotNone(proc.poll(), "audit failure left the real client alive")
            self.assertTrue(proc.stdin.closed)
            self.assertEqual(removed, ["owned-cid"])

    def test_nested_readonly_mountpoints_are_owned_before_docker_starts(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            home = root / "native-home"
            home.mkdir()
            mounts = []
            for number, destination in enumerate((
                    "/bench/bin", "/bench/lsp", "/bench/runtime", "/bench-home/.cache/codescout/fastembed")):
                source = root / ("runtime-" + str(number))
                source.mkdir()
                mounts.append({"Source": str(source), "Destination": destination})
            manifest = root / "runtime.json"
            manifest.write_text(json.dumps({"Image": "sha256:" + "a" * 64,
                "Mounts": mounts, "Config": {"Env": []}}))
            native._native_argv(root / "actor", home,
                {"runtime_manifest": str(manifest), "native_image": "sha256:" + "a" * 64})
            cache = home / ".cache/codescout/fastembed"
            self.assertTrue(cache.is_dir(), "Docker would create the nested host parents as root")
            self.assertEqual(cache.stat().st_uid, home.stat().st_uid)

    def test_control_plan_keeps_the_repair_without_protocol_artifact_creation(self):
        plan = [("Skill", {"skill": "codescout-companion:reconnaissance"}),
                ("mcp__codescout__create_file", {"path": "fixed.txt", "content": "1\n"}),
                ("mcp__codescout__create_file", {"path": "submission.json", "content": "{}"})]
        function = getattr(native, "_qualification_plan", None)
        self.assertTrue(callable(function), "control qualification plan is not implemented")
        self.assertEqual(function(plan, "R"), [
            ("Skill", {"skill": "codescout-companion:reconnaissance"}),
            ("mcp__codescout__create_file", {"path": "fixed.txt", "content": "1\n"})])
        self.assertEqual(function(plan, "P"), plan)
        with self.assertRaises(ValueError):
            function(plan, "X")
