"""Nextest command preservation and explicit no-test-output grammar adapter."""
from pathlib import Path
from types import SimpleNamespace
import copy
import hashlib
import importlib
import json
import shlex
import tempfile
import unittest


class NextestCommandsTests(unittest.TestCase):
    def setUp(self):
        self.api = importlib.import_module("feedback_nextest")
        self.original = {"instance_id": "unrelated",
            "test_cmds": ["cd /testbed && rm -rf target/nextest && LC_ALL=en_US.UTF-8 TERM=xterm-256color INSTA_UPDATE=new cargo +stable nextest run --status-level all -p sample --test integration -E 'test(snapshot)'"],
            "print_cmds": ["cd /testbed && cat target/nextest/default/junit.xml"],
            "rebuild_cmds": ["cd /testbed && cargo +stable build"],
            "FAIL_TO_PASS": ["original::f"], "PASS_TO_PASS": ["original::p"],
            "patch": "production bytes", "test_patch": "assertion bytes", "log_parser": "original parser"}

    def test_original_assertions_labels_parser_and_selectors_are_preserved(self):
        before = copy.deepcopy(self.original)
        prepared = self.api.prepare_record(self.original)
        self.assertEqual(self.original, before)
        for key in set(before) - {"test_cmds"}:
            self.assertEqual(prepared[key], before[key])
        words = shlex.split(prepared["test_cmds"][0])
        index = words.index("cargo")
        self.assertEqual(words[index:index+3], ["cargo", "+stable", "nextest"])
        self.assertIn("-E 'test(snapshot)'", prepared["test_cmds"][0])
        for option in ("--success-output", "--failure-output"):
            self.assertEqual(words[words.index(option)+1], "never")
        self.assertEqual(words.count("--no-fail-fast"), 1)
        self.assertIn("INSTA_UPDATE=no", words)
        self.assertIn("mkdir -p target/nextest/default", prepared["test_cmds"][0])
        self.assertIn("<testsuites/>", prepared["test_cmds"][0])

    def test_existing_no_fail_fast_is_not_duplicated_and_no_snapshot_env_is_invented(self):
        self.original["test_cmds"][0] = self.original["test_cmds"][0].replace("INSTA_UPDATE=new ", "").replace("nextest run", "nextest run --no-fail-fast")
        prepared = self.api.prepare_record(self.original)
        self.assertEqual(shlex.split(prepared["test_cmds"][0]).count("--no-fail-fast"), 1)
        self.assertNotIn("INSTA_UPDATE=", prepared["test_cmds"][0])

    def test_capture_overrides_shell_expansion_and_unbound_reports_are_refused(self):
        command = self.original["test_cmds"][0]
        for suffix in (" --nocapture", " --no-capture", " -- --nocapture", " --message-format json",
                       " --failure-output immediate", " ; echo injected", " $(echo injected)", " | tee log"):
            self.original["test_cmds"] = [command+suffix]
            with self.subTest(suffix=suffix), self.assertRaises(ValueError):
                self.api.prepare_record(self.original)
        self.original["test_cmds"] = [command]
        for report in ("cd /testbed && cat /etc/passwd", "cd /testbed && cat target/nextest/../junit.xml"):
            self.original["print_cmds"] = [report]
            with self.subTest(report=report), self.assertRaises(ValueError):
                self.api.prepare_record(self.original)


class NextestProfileTests(unittest.TestCase):
    def setUp(self):
        self.api = importlib.import_module("feedback_nextest")
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.anchor = self.root/"evidence.json"
        self.anchor.write_text("actual raw control placeholder")
        self.record = {"test_cmds": ["cargo +stable nextest run --no-fail-fast --success-output never --failure-output never"],
                       "log_parser": "original parser"}
        self.proof = self.root/"proof.json"
        self.proof.write_text(json.dumps({"profile": self.api.PROFILE, "qualified": True,
            "runner_version": "cargo-nextest 0.9.133 fixture",
            "parser_sha256": hashlib.sha256(self.record["log_parser"].encode()).hexdigest(),
            "cases": {"noisy-test-failure": {"valid": True, "pass": False, "kind": "test_failure"},
                      "noisy-pass": {"valid": True, "pass": True, "kind": "pass"},
                      "compile-failure": {"valid": True, "pass": False, "kind": "compile_failure"}},
            "bindings": {str(self.anchor): hashlib.sha256(self.anchor.read_bytes()).hexdigest()}}))
        self.spec = {"profile": self.api.PROFILE, "reports": [0], "stderr_files": [],
            "runner_version": "cargo-nextest 0.9.133 fixture",
            "compatibility": {"path": str(self.proof), "sha256": hashlib.sha256(self.proof.read_bytes()).hexdigest()}}
        self.registration = {"version": "frozen", "commands_sha256": "bound-by-frozen-checker", "tests": [self.spec]}
        self.streams = SimpleNamespace(LIB="literal-old-structural-grammar",
            capture=SimpleNamespace(read_streams=lambda value: (value["stdout"], value["stderr"])))
        self.full = {"steps": [{"name": "grade:test[0]", "capture": {"stdout": b"", "stderr": b"host diagnostics"}}]}

    def test_explicit_profile_translates_only_structural_grammar_and_probes_actual_runner(self):
        original = copy.deepcopy(self.registration)
        translated = self.api.qualify_registration(self.record, self.registration, self.full, self.streams)
        self.assertEqual(self.registration, original)
        self.assertEqual(translated["tests"][0], {"profile": self.streams.LIB, "reports": [0], "stderr_files": []})
        self.assertEqual(self.api.runtime_probes(self.record, self.registration),
                         [(["cargo", "+stable", "nextest", "--version"], self.spec["runner_version"])])

    def test_missing_output_guard_or_extra_stdout_cannot_enter_legacy_grammar(self):
        self.full["steps"][0]["capture"]["stdout"] = b"uncaptured test data"
        with self.assertRaisesRegex(ValueError, "stdout"):
            self.api.qualify_registration(self.record, self.registration, self.full, self.streams)
        self.full["steps"][0]["capture"]["stdout"] = b""
        for suffix in (" --failure-output immediate", " --no-capture"):
            altered = copy.deepcopy(self.record)
            altered["test_cmds"][0] += suffix
            with self.subTest(suffix=suffix), self.assertRaises(ValueError):
                self.api.qualify_registration(altered, self.registration, self.full, self.streams)

    def test_changed_proof_parser_and_bound_raw_input_are_rejected(self):
        self.anchor.write_text("changed")
        with self.assertRaises(ValueError):
            self.api.qualify_registration(self.record, self.registration, self.full, self.streams)
        self.anchor.write_text("actual raw control placeholder")
        self.record["log_parser"] = "changed parser"
        with self.assertRaises(ValueError):
            self.api.qualify_registration(self.record, self.registration, self.full, self.streams)
        self.record["log_parser"] = "original parser"
        self.proof.write_text("{}")
        with self.assertRaises(ValueError):
            self.api.qualify_registration(self.record, self.registration, self.full, self.streams)

    def test_other_profiles_are_not_relabelled(self):
        self.registration["tests"][0] = {"profile": "original", "reports": [0], "stderr_files": []}
        self.assertEqual(self.api.qualify_registration(self.record, self.registration, self.full, self.streams),
                         self.registration)
        self.assertEqual(self.api.runtime_probes(self.record, self.registration), [])
