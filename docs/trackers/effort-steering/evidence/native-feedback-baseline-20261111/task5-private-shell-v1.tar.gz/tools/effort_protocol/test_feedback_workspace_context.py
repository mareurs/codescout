"""Native workspace metadata must not enter a product snapshot or change its model."""
import json
from pathlib import Path
import shutil
import tempfile
import unittest
import native_executor as native
import qualify_native
import public_clone
from receipts import input_digest

class WorkspaceContextTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / "source"
        (self.source / "member/target").mkdir(parents=True)
        (self.source / "member/lib.rs").write_text("public source\n")
        (self.source / "member/target/fixture.txt").write_text("legitimate nested fixture\n")
        self.actor = self.root / "actor"
        shutil.copytree(self.source, self.actor)
        (self.actor / "member/.codescout").mkdir()
        (self.actor / "member/.codescout/index-state.json").write_text('{"source":"runtime metadata"}')

    def test_nested_codescout_metadata_does_not_change_public_digest(self):
        self.assertEqual(native._public_digest(self.actor), input_digest(self.source))

    def test_capture_prunes_nested_codescout_but_preserves_other_public_paths(self):
        destination = self.root / "captured"
        native._capture(self.actor, destination)
        self.assertFalse((destination / "member/.codescout").exists())
        self.assertEqual((destination / "member/target/fixture.txt").read_text(),
            "legitimate nested fixture\n")
        self.assertEqual(input_digest(destination), input_digest(self.source))

    def test_declared_runtime_embedding_overrides_reach_native_container(self):
        image = "sha256:" + "a" * 64
        mounts = []
        for index, target in enumerate(("/bench/bin", "/bench/lsp", "/bench/runtime",
                "/bench-home/.cache/codescout/fastembed")):
            path = self.root / ("mount-" + str(index))
            path.mkdir()
            mounts.append({"Source": str(path), "Destination": target})
        values = ["CODESCOUT_EMBED_MODEL=CodeRankEmbed",
                  "CODESCOUT_EMBED_URL=http://source-embeddings:8000/v1"]
        manifest = self.root / "runtime.json"
        manifest.write_text(json.dumps({"Image": image, "Mounts": mounts, "Config": {"Env": values}}))
        args = qualify_native._native_argv(self.actor, self.root / "home",
            {"native_image": image, "runtime_manifest": str(manifest)})
        observed = [args[index+1] for index, flag in enumerate(args[:-1]) if flag == "-e"]
        self.assertEqual(observed, values)

    def test_public_source_cannot_silently_contain_excluded_nested_tool_state(self):
        # Refuse before inspecting template metadata: source authority must not be silently narrowed.
        source = self.root / "invalid-source"
        shutil.copytree(self.actor, source)
        template = self.root / "template"
        template.mkdir()
        with self.assertRaisesRegex(ValueError, "source contains host-excluded tool roles"):
            public_clone.prepare_public_clone(source, self.root / "out", {"template": str(template)})

if __name__ == "__main__":
    unittest.main()
