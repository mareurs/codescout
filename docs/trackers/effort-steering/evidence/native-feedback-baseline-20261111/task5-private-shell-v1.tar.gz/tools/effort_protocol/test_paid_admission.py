"""Paid admission consumes frozen evidence; summaries and synthetic populations cannot substitute."""
import copy
import hashlib
import io
import json
from pathlib import Path
import tarfile
import tempfile
import unittest

from campaign import attempt_schedule, selection_report
from receipts import input_digest
from unittest.mock import patch
try:
    import paid_admission as subject
except ModuleNotFoundError:
    subject=None


class PopulationAdmissionTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(subject, "paid admission evidence verifier missing")
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        metadata=[{"id":"task"+str(i),"repo":"org/repo"+str(i),"base_commit":"a"*40,
            "image":"registry/task"+str(i),"language":"rust","public_issue_sha256":str(i+1)*64}
            for i in range(4)]
        status={row["id"]:{"eligible":True,"reason":"frozen public qualification"} for row in metadata}
        def raw(value): return (json.dumps(value,sort_keys=True)+"\n").encode()
        self.members={"metadata":"metadata.json","exposure":"exposure.json","status":"status.json",
            "rule":"rule.json","freeze":"freeze.json","selection":"selection.json"}
        self.payloads={"metadata.json":raw({"tasks":metadata}),
            "exposure.json":raw({"tasks":{"task3":["prior exposure"]}}),
            "status.json":raw(status),"rule.json":raw({"seed":"frozen-original-seed"})}
        effective=[{**row,**status[row["id"]]} for row in metadata]
        selected=selection_report(effective,{"task3"},"frozen-original-seed")
        self.payloads["selection.json"]=raw(selected)
        self.payloads["freeze.json"]=raw({"selection":selected,
            "selection_rule":{"seed":"frozen-original-seed"},"selected_ids":[r["id"] for r in selected["selected"]],
            "private_outcomes_read":False,"replacement_after_private_outcomes":False,
            "experimental_model_calls":0})
        self.reg={"metadata":effective,"exposure":["task3"],"seed":"frozen-original-seed",
            "selected":selected["selected"],"bindings":{}}
        self.archive=self.root/"population.tar.gz"
        self.seal()

    def seal(self):
        with tarfile.open(self.archive,"w:gz") as packed:
            for name,raw in self.payloads.items():
                member=tarfile.TarInfo(name)
                member.size=len(raw)
                packed.addfile(member,io.BytesIO(raw))
        digest=hashlib.sha256(self.archive.read_bytes()).hexdigest()
        self.reg["bindings"][str(self.archive)]=digest
        self.proof={"path":str(self.archive),"sha256":digest,"members":copy.deepcopy(self.members)}

    def test_original_universe_exposure_seed_and_selected_order_are_recomputed(self):
        result=subject.verify_population(self.reg,self.proof)
        self.assertEqual(result["metadata_tasks"],4)
        self.assertEqual(result["exposure_ids"],1)
        self.assertEqual(result["excluded_universe_tasks"],1)
        self.assertEqual(result["selected_ids"],[r["id"] for r in self.reg["selected"]])

    def test_external_exposure_ids_are_not_counted_as_excluded_universe_tasks(self):
        exposure={"task3":[],"external-history":[]}
        self.payloads["exposure.json"]=json.dumps({"tasks":exposure}).encode()
        self.reg["exposure"]=sorted(exposure)
        selected=selection_report(self.reg["metadata"],set(exposure),self.reg["seed"])
        self.payloads["selection.json"]=json.dumps(selected).encode()
        freeze=json.loads(self.payloads["freeze.json"])
        freeze["selection"]=selected
        self.payloads["freeze.json"]=json.dumps(freeze).encode()
        self.seal()
        result=subject.verify_population(self.reg,self.proof)
        self.assertEqual(result["exposure_ids"],2)
        self.assertEqual(result["excluded_universe_tasks"],1)

    def test_synthetic_two_row_universe_or_changed_seed_cannot_admit(self):
        original=copy.deepcopy(self.reg)
        for case in ("universe","seed","exposure","order","qualification","unknown-metadata"):
            with self.subTest(case=case):
                self.reg=copy.deepcopy(original)
                if case=="universe": self.reg["metadata"]=self.reg["selected"]
                elif case=="seed": self.reg["seed"]="synthetic-runtime-seed"
                elif case=="exposure": self.reg["exposure"]=[]
                elif case=="order": self.reg["selected"].reverse()
                elif case=="qualification": self.reg["metadata"][0]["eligible"]=False
                else: self.reg["metadata"][0]["private_score"]=1
                with self.assertRaises(ValueError):
                    subject.verify_population(self.reg,self.proof)

    def test_archive_hash_binding_link_and_duplicate_member_are_rejected(self):
        original=self.archive.read_bytes()
        self.reg["bindings"][str(self.archive)]="0"*64
        with self.assertRaises(ValueError): subject.verify_population(self.reg,self.proof)
        self.reg["bindings"][str(self.archive)]=self.proof["sha256"]
        self.archive.write_bytes(original+b"changed")
        with self.assertRaises(ValueError): subject.verify_population(self.reg,self.proof)
        self.archive.write_bytes(original)
        alias=self.root/"alias"
        alias.symlink_to(self.archive)
        linked={**self.proof,"path":str(alias)}
        self.reg["bindings"][str(alias)]=linked["sha256"]
        with self.assertRaises(ValueError): subject.verify_population(self.reg,linked)
        with tarfile.open(self.archive,"w:gz") as packed:
            for name,raw in list(self.payloads.items())+[("metadata.json",self.payloads["metadata.json"])]:
                member=tarfile.TarInfo(name);member.size=len(raw);packed.addfile(member,io.BytesIO(raw))
        digest=hashlib.sha256(self.archive.read_bytes()).hexdigest()
        self.proof["sha256"]=digest;self.reg["bindings"][str(self.archive)]=digest
        with self.assertRaises(ValueError): subject.verify_population(self.reg,self.proof)

    def test_private_outcome_selection_unknown_calls_and_mismatched_freeze_are_refused(self):
        original=copy.deepcopy(self.payloads)
        for case in ("private","replacement","calls","selection","rule","ids","metadata-hash","exposure-hash"):
            with self.subTest(case=case):
                self.payloads=copy.deepcopy(original)
                freeze=json.loads(self.payloads["freeze.json"])
                if case=="private": freeze["private_outcomes_read"]=True
                elif case=="replacement": freeze["replacement_after_private_outcomes"]=True
                elif case=="calls": freeze["experimental_model_calls"]=None
                elif case=="selection": freeze["selection"]["complete"]=False
                elif case=="rule": freeze["selection_rule"]["seed"]="changed"
                elif case=="ids": freeze["selected_ids"].reverse()
                else:
                    selected=json.loads(self.payloads["selection.json"])
                    selected["metadata_sha256" if case=="metadata-hash" else "exposure_sha256"]="0"*64
                    self.payloads["selection.json"]=json.dumps(selected).encode()
                    freeze["selection"]=selected
                self.payloads["freeze.json"]=json.dumps(freeze).encode()
                self.seal()
                with self.assertRaises(ValueError): subject.verify_population(self.reg,self.proof)
class PublicCommandAdmissionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.source=self.root/"source"
        self.source.mkdir()
        (self.source/"Cargo.toml").write_text("[workspace]\n")
        self.command={"argv":["cargo","check","--offline","--workspace"],"cwd":".",
                      "test_files":["Cargo.toml"]}
        self.facts={"id":"public-cargo-check","complete":True,"resource_valid":True,"exit_code":0}
        self.public={"public_checks":[self.command],"execution_profile":"cargo-v2"}
        self.reg={"tasks":{"task":{"source":str(self.source),
            "source_sha256":subject.input_digest(self.source),"backend":{"public":self.public}}},"bindings":{}}
        self.registered={"source":str(self.source),"source_digest":subject.input_digest(self.source),
            "request":{"id":"public-cargo-check",**self.command}}
        self.result={"complete":True,"resource_valid":True,"exit_code":0,"receipt":self.facts}
        self.proof={"task":[{"registration":self.bound("registration.json",self.registered),
                            "result":self.bound("result.json",self.result)}]}

    def bound(self,name,value):
        path=self.root/name
        path.write_text(json.dumps(value))
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        self.reg["bindings"][str(path)]=digest
        return {"path":str(path),"sha256":digest}

    def test_reads_the_actual_source_profile_fixture_and_host_receipt(self):
        from unittest.mock import patch
        self.public["public_fixture"]={"fingerprint":"frozen"}
        with patch.object(subject,"verify_receipt",return_value=self.facts) as verify:
            result=subject.verify_public_commands(self.reg,self.proof)
        verify.assert_called_once_with({"id":"public-cargo-check"},self.root/"commands",self.source,
            expected_profile="cargo-v2",expected_fixture=self.public["public_fixture"])
        self.assertEqual(result["task"]["verified_commands"],1)

    def test_extra_missing_or_different_public_command_cannot_qualify(self):
        from unittest.mock import patch
        original=copy.deepcopy(self.reg)
        for case in ("missing","extra","command","source","profile-result","failed","drift"):
            with self.subTest(case=case):
                self.reg=copy.deepcopy(original)
                self.public=self.reg["tasks"]["task"]["backend"]["public"]
                proof=copy.deepcopy(self.proof)
                result=copy.deepcopy(self.result)
                facts=copy.deepcopy(self.facts)
                if case=="missing": proof={}
                elif case=="extra": proof["extra"]=proof["task"]
                elif case=="command": self.public["public_checks"][0]["argv"]=["true"]
                elif case=="source": self.reg["tasks"]["task"]["source_sha256"]="0"*64
                elif case=="profile-result": facts["execution_profile"]="wrong"
                elif case=="failed":
                    result["exit_code"]=101
                    proof["task"][0]["result"]=self.bound("result.json",result)
                elif case=="drift": (self.root/"result.json").write_text("changed")
                with patch.object(subject,"verify_receipt",return_value=facts):
                    with self.assertRaises(ValueError):
                        subject.verify_public_commands(self.reg,proof)
                self.bound("result.json",self.result)

    def test_incomplete_raw_receipt_is_not_replaced_by_the_positive_summary(self):
        from unittest.mock import patch
        with patch.object(subject,"verify_receipt",side_effect=ValueError("incomplete capture")):
            with self.assertRaisesRegex(ValueError,"incomplete capture"):
                subject.verify_public_commands(self.reg,self.proof)


    def test_new_profile_forwards_and_matches_the_registered_build_descriptor(self):
        from unittest.mock import patch
        raw = {"schema":"public-build-inputs-v1", "image":"sha256:"+"a"*64, "seed":None,
               "dependency_dirs":[], "cache_mounts":[]}
        self.public.update(execution_profile="cargo-v3", image=raw["image"], public_build_inputs=raw)
        self.registered["request"].update(execution_profile="cargo-v3", public_build_inputs=raw)
        self.proof["task"][0]["registration"] = self.bound("registration.json", self.registered)
        def read_bound(*args, expected_build_inputs=None, **kwargs):
            if expected_build_inputs != raw:
                raise ValueError("independent reader did not receive its registered build descriptor")
            return self.facts
        with patch.object(subject, "verify_receipt", side_effect=read_bound):
            self.assertEqual(subject.verify_public_commands(self.reg, self.proof)["task"]["verified_commands"], 1)
        self.registered["request"]["public_build_inputs"] = {**raw, "image":"sha256:"+"b"*64}
        self.proof["task"][0]["registration"] = self.bound("registration.json", self.registered)
        with patch.object(subject, "verify_receipt", return_value=self.facts):
            with self.assertRaises(ValueError):
                subject.verify_public_commands(self.reg, self.proof)

class AccountingAdmissionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.reg={"bindings":{}}
        self.opening=self.root/"opening.json"
        self.known=self.root/"known.json"
        self.hold=self.root/"hold.json"
        self.opening.write_text(json.dumps({"prior_campaign_spend_usd":"5"}))
        self.known.write_text(json.dumps({"session_id":"known","scripted":False,
            "unknown_provider_cost":False,"cost_usd":"0.25"}))
        self.hold.write_text(json.dumps({"session_id":"legacy","scripted":False,
            "unknown_provider_cost":True,"cost_usd":None,"requests":0,"forwarded":0,
            "campaign_available_usd":"4"}))
        def row(path,identity,**fields):
            digest=hashlib.sha256(path.read_bytes()).hexdigest()
            self.reg["bindings"][str(path)]=digest
            return {"id":identity,"source":str(path),"receipt_sha256":digest,**fields}
        self.ledger={"ceiling_usd":"200","charges":[
            row(self.opening,"recorded-pre-native-opening-balance",cost_usd="5"),
            row(self.known,"native-client:known",cost_usd="0.25")],
            "holds":[row(self.hold,"native-client:legacy",cost_usd=None,reserved_usd="4",settled=False)],
            "reservations":[]}
        self.reg["ledger"]=copy.deepcopy(self.ledger)
        self.reg["carried_holds"]=[{k:self.ledger["holds"][0][k]
            for k in ("id","source","receipt_sha256","reserved_usd")}]
        self.reconciled={"schema":"client-ledger-reconciliation-v1","ledger":self.ledger,
            "opening_balance_source":str(self.opening),
            "opening_balance_sha256":self.ledger["charges"][0]["receipt_sha256"],
            "opening_balance_usd":"5","known_client_cost_usd":"5.25","native_receipts":1,
            "native_client_cost_usd":"0.25","unresolved_reserve_usd":"4",
            "proposed_new_allocation_usd":"78","commitment_if_new_allocation_usd":"87.25",
            "receipt_bindings":{r["source"]:r["receipt_sha256"]
                for r in self.ledger["charges"][1:]+self.ledger["holds"]}}
        self.report=self.root/"reconciliation.json"
        self.seal()

    def seal(self):
        self.report.write_text(json.dumps(self.reconciled))
        digest=hashlib.sha256(self.report.read_bytes()).hexdigest()
        self.reg["bindings"][str(self.report)]=digest
        self.proof={"path":str(self.report),"sha256":digest}

    def test_every_charge_is_reopened_and_the_unknown_hold_is_retained(self):
        original=copy.deepcopy(self.reg["ledger"])
        checked=subject.verify_accounting(self.reg,self.proof)
        self.assertEqual(checked["known_client_cost_usd"],"5.25")
        self.assertEqual(checked["unresolved_reserve_usd"],"4")
        self.assertEqual(checked["native_receipts"],1)
        self.assertEqual(self.reg["ledger"],original)
    def test_headroom_allocation_is_admitted_without_erasing_old_hold(self):
        self.reconciled["proposed_new_allocation_usd"] = "78"
        self.reconciled["commitment_if_new_allocation_usd"] = "87.25"
        self.seal()
        checked = None
        try:
            checked = subject.verify_accounting(self.reg, self.proof)
        except ValueError:
            pass
        self.assertIsNotNone(checked, "headroom allocation must be independently admitted")
        self.assertEqual(checked["commitment_if_new_allocation_usd"], "87.25")
        self.assertEqual(checked["unresolved_reserve_usd"], "4")
        self.reconciled["proposed_new_allocation_usd"] = "38"
        self.reconciled["commitment_if_new_allocation_usd"] = "47.25"
        self.seal()
        with self.assertRaises(ValueError):
            subject.verify_accounting(self.reg, self.proof)
    def test_proposed_allocation_alone_crosses_otherwise_valid_ceiling(self):
        self.reg["ledger"]["ceiling_usd"] = "87.25"
        self.reconciled["ledger"] = copy.deepcopy(self.reg["ledger"])
        self.seal()
        checked = subject.verify_accounting(self.reg, self.proof)
        self.assertEqual(checked["commitment_if_new_allocation_usd"], "87.25")
        self.assertEqual(checked["unresolved_reserve_usd"], "4")
        self.reg["ledger"]["ceiling_usd"] = "87.24"
        self.reconciled["ledger"] = copy.deepcopy(self.reg["ledger"])
        self.seal()
        self.assertEqual(subject.accounting_totals(self.reg["ledger"])["committed_usd"], "9.25")
        with self.assertRaisesRegex(ValueError, "proposed commitment changed"):
            subject.verify_accounting(self.reg, self.proof)

    def test_only_declared_allocation_can_disagree_with_matching_commitment(self):
        self.reconciled["proposed_new_allocation_usd"] = "77"
        self.seal()
        self.assertEqual(self.reconciled["commitment_if_new_allocation_usd"], "87.25")
        with self.assertRaisesRegex(ValueError, "proposed commitment changed"):
            subject.verify_accounting(self.reg, self.proof)

    def test_omitted_charge_changed_receipt_unbound_opening_and_false_sum_refuse(self):
        original=copy.deepcopy(self.reg)
        original_report=copy.deepcopy(self.reconciled)
        raw=self.known.read_bytes()
        for case in ("omitted","changed","unbound-opening","sum","count","carry","commitment","receipt-coverage"):
            with self.subTest(case=case):
                self.reg=copy.deepcopy(original)
                self.reconciled=copy.deepcopy(original_report)
                self.known.write_bytes(raw)
                if case=="omitted": self.reg["ledger"]["charges"].pop()
                elif case=="changed": self.known.write_bytes(raw+b" ")
                elif case=="unbound-opening": self.reg["bindings"].pop(str(self.opening))
                elif case=="sum": self.reconciled["known_client_cost_usd"]="0"
                elif case=="count": self.reconciled["native_receipts"]=0
                elif case=="carry": self.reg.pop("carried_holds")
                elif case=="commitment": self.reconciled["commitment_if_new_allocation_usd"]="0"
                else: self.reconciled["receipt_bindings"].pop(str(self.known))
                self.seal()
                with self.assertRaises(ValueError):
                    subject.verify_accounting(self.reg,self.proof)

    def test_unknown_or_scripted_receipt_cannot_become_a_known_historical_charge(self):
        original=copy.deepcopy(self.reg)
        for case in ("unknown","scripted","wrong-session","wrong-cost"):
            with self.subTest(case=case):
                self.reg=copy.deepcopy(original)
                raw={"session_id":"known","scripted":False,"unknown_provider_cost":False,"cost_usd":"0.25"}
                if case=="unknown": raw.update(unknown_provider_cost=True,cost_usd=None)
                elif case=="scripted": raw["scripted"]=True
                elif case=="wrong-session": raw["session_id"]="other"
                else: raw["cost_usd"]="0.26"
                self.known.write_text(json.dumps(raw))
                digest=hashlib.sha256(self.known.read_bytes()).hexdigest()
                self.reg["bindings"][str(self.known)]=digest
                self.reg["ledger"]["charges"][1]["receipt_sha256"]=digest
                self.reconciled["ledger"]=copy.deepcopy(self.reg["ledger"])
                self.reconciled["receipt_bindings"][str(self.known)]=digest
                self.seal()
                with self.assertRaises(ValueError):
                    subject.verify_accounting(self.reg,self.proof)
class NativeInvocationAdmissionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.native=self.root/"native";self.native.mkdir()
        (self.native/"readiness").mkdir()
        self.source=self.root/"input";self.source.mkdir()
        (self.source/"program.rs").write_text("fn main() {}")
        self.reg={"bindings":{}}
        self.intent={"invocation_id":"q::0::repair","arm":"L","source":str(self.source),
                     "cli_cap_usd":"2.75","max_continuations":2}
        self.public={"image":"sha256:"+"a"*64,"capture_base_commit":"b"*40,
            "knowledge_sha256":"f"*64,"runtime":{"files":{"cli":{"path":"/frozen/cli"}},
            "plugin":{"path":"/frozen/plugin"}}}
        argv=["/frozen/cli","--effort","low","--model","claude-sonnet-5-5",
              "--setting-sources","user,project,local","--plugin-dir","/frozen/plugin",
              "--max-budget-usd","2.75"]
        self.raw={
            "invocation.json":{"invocation_id":self.intent["invocation_id"],"native_path":str(self.native),
                "measurement_invalid":False,"context_valid":True,"capture_complete":True,
                "cleanup_complete":True,"cost_is_final":True,"cost_usd":"0",
                "candidate":str(self.source),"source_digest":input_digest(self.source)},
            "native/launch.json":{"argv":argv,"scripted":True,"real_credentials_read":False,
                "source_image":self.public["image"],"mcp_protocol_negotiation":"legacy","session_id":"q"},
            "native/receipt.json":{"scripted":True,"context_valid":True,"session_id":"q",
                "unknown_provider_cost":False,"forwarded":0,"requests":1,"transport_errors":[],
                "cleanup_error":None,"supervision_error":None,"cost_usd":"0"},
            "native/native-executor.json":{"context_evidence":{"recon_delivered":True,"system_delivered":True},
                "context_valid":True,"capture_complete":True,"cleanup_complete":True,"cost_is_final":True,
                "scripted_provider":True,"provider_forwarded":0},
            "native/prepared.json":{"cli":"/frozen/cli","max_continuations":2,"baseline_commit":"b"*40},
            "native/public-preparation.json":{"source_sha256":input_digest(self.source),
                "onboarding_reused":True,"onboarding_author_calls":0,"knowledge_sha256":"f"*64},
            "native/supervision-final.json":{"complete":True,"resource_ok":True,"errors":[],
                "cgroup_probes":2,"oom_kill":0},
            "native/candidate-capture.json":{"complete":True,"image":self.public["image"],
                "baseline_commit":"b"*40,"bytes":5,"sha256":hashlib.sha256(b"patch").hexdigest()},
            "native/cleanup.json":[{"name":"worker","absent":True}],
            "native/mcp-launch-one.json":{"name":"worker"},
            "native/readiness/readiness.json":{"expected":{},"wire":{},"result":{"ready":True}},
            "native/request-0.json":{"output_config":{"effort":"low"},"messages":[{"role":"assistant",
                "content":[{"type":"tool_use","name":"Skill","input":{"skill":"codescout-companion:reconnaissance"}}]}]}}
        patch_path=self.native/"candidate.patch";patch_path.write_bytes(b"patch")
        self.reg["bindings"][str(patch_path)]=hashlib.sha256(b"patch").hexdigest()
        from context_inputs import prepare_context
        actor=self.native/"actor"
        (actor/".codescout").mkdir(parents=True)
        (actor/".codescout/system-prompt.md").write_text("FROZEN ONBOARDING")
        plugin=self.root/"plugin"
        skill=plugin/"skills/reconnaissance"
        skill.mkdir(parents=True)
        (skill/"SKILL.md").write_text("FROZEN RECON")
        context=prepare_context(self.native,actor,plugin)
        self.public["runtime"]["plugin"]["path"]=str(plugin)
        argv[argv.index("--plugin-dir")+1]=str(plugin)
        argv+=["--append-system-prompt",Path(context["path"]).read_text()]
        self.raw["native/launch.json"]["context_preload_sha256"]=context["files"][context["path"]]
        self.raw["native/prepared.json"].update(actor=str(actor),plugin=str(plugin),context_preload=context,
                                              files=context["files"])
        self.reg["bindings"].update(context["files"])
        self.raw["native/expected.json"]={"effort":"low","clause":"AUTHORITY","declaration":False,
            "global_visible":["GLOBAL"],"project_visible":["PROJECT"],
            "preload_visible":["<prepared-context>","FROZEN ONBOARDING","FROZEN RECON","</prepared-context>"]}
        self.raw["native/expected.json"]["preload_visible"]=Path(context["path"]).read_text().splitlines()
        self.raw["native/expected.json"]["preload_visible"]=[v for v in self.raw["native/expected.json"]["preload_visible"] if v.strip()]
        self.raw["native/request-0.json"].update(model="claude-sonnet-5-5",
            system=[{"type":"text","text":"GLOBAL\nPROJECT\n"+Path(context["path"]).read_text()}])
        self.seal()

    def test_preloaded_context_is_verified_without_model_selected_skill_calls(self):
        self.raw["native/request-0.json"]["messages"]=[]
        self.seal()
        self.assertEqual(self.invoke()["context_preloaded"],True)
        for case in ("missing","user-only","argument","hash"):
            original=copy.deepcopy(self.raw)
            request=self.raw["native/request-0.json"]
            if case=="missing":
                request["system"][0]["text"]=request["system"][0]["text"].replace("FROZEN RECON","")
            elif case=="user-only":
                request["messages"]=[{"role":"user","content":request["system"]}]
                request["system"]=[]
            elif case=="argument":
                argv=self.raw["native/launch.json"]["argv"]
                argv[argv.index("--append-system-prompt")+1]="unrelated"
            else:
                self.raw["native/launch.json"]["context_preload_sha256"]="0"*64
            self.seal()
            with self.subTest(case=case),self.assertRaises(ValueError):
                self.invoke()
            self.raw=original
            self.seal()

    def test_native_admission_reopens_build_seed_helper_mounts_and_closed_outputs(self):
        import public_build_inputs as build
        actor=Path(self.raw["native/prepared.json"]["actor"])
        for root in (actor,self.source):
            (root/"frontend/node_modules").mkdir(parents=True)
        seed=self.root/"public-seed"
        (seed/"cache").mkdir(parents=True)
        (seed/"cache/metadata").write_text("public package data")
        descriptor={"schema":"public-build-inputs-v1","image":self.public["image"],
            "seed":{"path":str(seed),"sha256":build.generated_digest(seed)},
            "dependency_dirs":["frontend/node_modules"],
            "cache_mounts":[{"seed_relative":"cache","destination":"/bench/public-dependencies/cache"}]}
        stage=build.stage_inputs(descriptor,actor,self.public["image"],self.native/"public-build-state")
        canonical=Path(build.__file__).resolve()
        helper=self.native/"public-build-inputs-helper.py"
        helper.write_bytes(canonical.read_bytes())
        def bind(path):
            digest=hashlib.sha256(path.read_bytes()).hexdigest()
            self.reg["bindings"][str(path)]=digest
            return digest
        helper_hash=bind(helper);bind(canonical);bind(Path(stage["output"])/"manifest.json")
        prepared=self.raw["native/prepared.json"]
        prepared.update(image=self.public["image"],execution_profile="cargo-v3",
            public_build_inputs=descriptor,public_build_stage=stage,public_build_inputs_helper=str(helper))
        prepared["files"]=dict(prepared["files"])
        prepared["files"][str(helper)]=helper_hash
        self.public.update(execution_profile="cargo-v3",public_build_inputs=descriptor)
        mounts=[{"Type":"bind","Source":str(actor),"Destination":"/testbed","RW":True}]
        mounts += [{"Type":"bind","Source":r["source"],"Destination":r["destination"],"RW":True}
                   for r in stage["mounts"]]
        self.raw["native/mcp-native-argv.json"]=["docker","run"]+[
            part for r in mounts for part in ("--mount","type=bind,src="+r["Source"]+",dst="+r["Destination"])
            ]+[self.public["image"],"start","--project","/testbed"]
        self.raw["native/readiness/public-build-runtime-raw.json"]={"Image":self.public["image"],"Mounts":mounts}
        runtime=build.validate_native_runtime(self.raw["native/readiness/public-build-runtime-raw.json"],
                                             descriptor,stage,actor,self.public["image"])
        self.raw["native/readiness/public-build-runtime.json"]={"binding":runtime,
            "scope":"Live mount/seed contract only; generated outputs inventory requires closed writers."}
        self.raw["native/readiness/readiness.json"]["expected"]={
            "binding":{"public_build_inputs_sha256":stage["fingerprint"]},"public_build_inputs":descriptor}
        self.raw["native/native-executor.json"].update(public_build_inputs=stage["fingerprint"],
            public_build_stage=stage,public_build_generated_after=build.verify_staged(
                stage,actor,self.public["image"])["generated_sha256"])
        digest=input_digest(self.source)
        self.raw["invocation.json"].update(source_digest=digest)
        self.raw["native/public-preparation.json"]["source_sha256"]=digest
        self.seal()
        def invoke():
            with patch.object(subject,"validate_readiness",return_value={"ready":True}):
                return subject.verify_native_invocation(self.reg,self.root,self.intent,self.public)
        proof=invoke()
        self.assertEqual(proof["public_build_inputs_sha256"],stage["fingerprint"])
        baseline=copy.deepcopy(self.raw)
        public=copy.deepcopy(self.public)
        for case in ("descriptor","profile","cross-task","helper","runtime-mount","live-output",
                     "ready-binding","ready-descriptor","backend-stage","backend-fingerprint","backend-output"):
            self.raw=copy.deepcopy(baseline);self.public=copy.deepcopy(public)
            with self.subTest(case=case):
                if case=="descriptor":self.raw["native/prepared.json"].pop("public_build_inputs")
                elif case=="profile":self.public["execution_profile"]="cargo-v2"
                elif case=="cross-task":self.public["public_build_inputs"]["image"]="sha256:"+"c"*64
                elif case=="helper":
                    helper.write_bytes(canonical.read_bytes()+b"\n# rebound foreign helper\n")
                    self.raw["native/prepared.json"]["files"][str(helper)]=bind(helper)
                elif case=="runtime-mount":self.raw["native/readiness/public-build-runtime-raw.json"]["Mounts"].pop()
                elif case=="live-output":self.raw["native/readiness/public-build-runtime.json"]["binding"]["generated_sha256"]="0"*64
                elif case=="ready-binding":self.raw["native/readiness/readiness.json"]["expected"]["binding"].clear()
                elif case=="ready-descriptor":self.raw["native/readiness/readiness.json"]["expected"].pop("public_build_inputs")
                elif case=="backend-stage":self.raw["native/native-executor.json"]["public_build_stage"]["image"]="sha256:"+"c"*64
                elif case=="backend-fingerprint":self.raw["native/native-executor.json"]["public_build_inputs"]="0"*64
                else:self.raw["native/native-executor.json"]["public_build_generated_after"]="0"*64
                self.seal()
                with self.assertRaises(ValueError):invoke()
                helper.write_bytes(canonical.read_bytes());bind(helper)
        self.raw=copy.deepcopy(baseline);self.public=public;self.seal()
        cache=Path(stage["mounts"][-1]["source"])/"metadata"
        cache.write_text("late generated change")
        with self.assertRaises(ValueError):invoke()
        cache.write_text("public package data")
        (seed/"cache/metadata").write_text("seed changed")
        with self.assertRaises(ValueError):invoke()

    def seal(self):
        for name,value in self.raw.items():
            path=self.root/name
            path.write_text(json.dumps(value))
            self.reg["bindings"][str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()

    def invoke(self):
        with patch.object(subject,"validate_readiness",return_value={"ready":True}) as validator:
            result=subject.verify_native_invocation(self.reg,self.root,self.intent,self.public)
        validator.assert_called_once_with({}, {}, source=self.source)
        return result

    def test_complete_native_contract_and_duplicate_cli_argument(self):
        checked=self.invoke()
        self.assertEqual(checked["effort"],"low")
        self.assertEqual(checked["cli_cap_usd"],"2.75")
        self.assertEqual(checked["cgroup_probes"],2)
        self.raw["native/launch.json"]["argv"]+=["--effort","xhigh"]
        self.seal()
        with self.assertRaisesRegex(ValueError,"repeated CLI"):
            self.invoke()

    def test_rebound_metadata_cannot_fake_semantic_native_guards(self):
        original=copy.deepcopy(self.raw)
        cases={
            "context":("invocation.json","context_valid",False),
            "unknown":("native/receipt.json","unknown_provider_cost",True),
            "forwarded":("native/receipt.json","forwarded",1),
            "recon":("native/native-executor.json","context_evidence",{"recon_delivered":False,"system_delivered":True}),
            "probes":("native/supervision-final.json","cgroup_probes",1),
            "oom":("native/supervision-final.json","oom_kill",1),
            "source":("native/public-preparation.json","source_sha256","0"*64),
            "memory":("native/public-preparation.json","knowledge_sha256","0"*64),
            "patch":("native/candidate-capture.json","sha256","0"*64),
            "continuations":("native/prepared.json","max_continuations",3)}
        for case,(name,key,value) in cases.items():
            with self.subTest(case=case):
                self.raw=copy.deepcopy(original)
                self.raw[name][key]=value
                self.seal()
                with self.assertRaises(ValueError): self.invoke()

    def test_wrong_effort_cap_context_skill_and_absence_refuse(self):
        original=copy.deepcopy(self.raw)
        for case in ("effort","cap","model","settings","plugin","request-effort","skill","absence","worker"):
            with self.subTest(case=case):
                self.raw=copy.deepcopy(original)
                argv=self.raw["native/launch.json"]["argv"]
                if case in ("effort","cap","model","settings","plugin"):
                    option={"effort":"--effort","cap":"--max-budget-usd","model":"--model",
                            "settings":"--setting-sources","plugin":"--plugin-dir"}[case]
                    argv[argv.index(option)+1]={"effort":"xhigh","cap":"3","model":"other",
                                              "settings":"local","plugin":"/other"}[case]
                elif case=="request-effort":
                    self.raw["native/request-0.json"]["output_config"]["effort"]="xhigh"
                elif case=="skill": self.raw["native/request-0.json"]["system"]=[]
                elif case=="absence": self.raw["native/cleanup.json"][0]["absent"]=False
                else: self.raw["native/cleanup.json"][0]["name"]="other"
                self.seal()
                with self.assertRaises(ValueError): self.invoke()
class RuntimeAdmissionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix="ep-runtime-unit-",dir="/var/tmp")
        self.addCleanup(self.temp.cleanup)
        self.base=Path(self.temp.name)
        self.root=self.base/"qualified";self.root.mkdir()
        self.reg={"output_root":str(self.base/"future-paid"),"tasks":{},"bindings":{}}
        metadata=[{"id":"task"+str(i),"repo":"org/repo"+str(i),"base_commit":"a"*40,
            "image":"frozen-image","language":"rust","public_issue_sha256":str(i+1)*64,
            "eligible":True,"reason":"qualified"} for i in range(2)]
        self.reg["selected"]=metadata
        self.reg["schedule"]=attempt_schedule(metadata)
        self.frozen=self.base/"runtime.py";self.frozen.write_text("reviewed runtime")
        self.producer=self.base/"producer.py";self.producer.write_text("actual controller driver")
        for row in metadata:
            source=self.base/row["id"];source.mkdir()
            (source/"code.rs").write_text("pub fn f() {}")
            self.reg["tasks"][row["id"]]={"source":str(source),"source_sha256":input_digest(source),
                "public_packet":{"issue":"public issue"},"backend":{"public":{},
                "private":{"config":"/private/config","config_sha256":"c"*64,"entry_sha256":"e"*64}}}
        self.reg["bindings"][str(self.frozen)]=hashlib.sha256(self.frozen.read_bytes()).hexdigest()
        self.proof={"root":str(self.root),"producer":self.bind(self.producer)}
        qualified={"mode":"scripted","campaign_id":"qualification","selected":metadata,
            "schedule":self.reg["schedule"],"tasks":copy.deepcopy(self.reg["tasks"]),
            "bindings":{str(self.frozen):self.reg["bindings"][str(self.frozen)]},
            "qualification_driver":self.proof["producer"]}
        closed={"attempts":[]}
        attempts=[]
        for index,attempt in enumerate(self.reg["schedule"]):
            directory=self.root/"attempts"/(str(index).zfill(2)+"-"+attempt["arm"])
            directory.mkdir(parents=True)
            candidate=directory/"candidate";candidate.mkdir()
            (candidate/"code.rs").write_text("pub fn f() {}")
            invocations=[]
            phases=("investigate","repair","challenge") if attempt["arm"] in ("P","R") else ("repair",)
            for phase_index,phase in enumerate(phases):
                phase_root=directory/phase;phase_root.mkdir()
                identity="qualification::"+str(index)+"::"+phase
                cap=attempt["phase_cli_caps_usd"][phase_index] if len(phases)==3 else attempt["cli_cap_usd"]
                allowance=attempt["phase_reservations_usd"][phase_index] if len(phases)==3 else attempt["reserved_usd"]
                intent={"invocation_id":identity,"task_id":attempt["task_id"],"arm":attempt["arm"],
                    "phase":phase,"cli_cap_usd":cap,"allowance_usd":allowance}
                record={"native_path":str(phase_root/"native")}
                self.write(phase_root/"intent.json",intent)
                self.write(phase_root/"invocation.json",record)
                invocations.append({"record":record,"measurement_invalid":False,
                                    "cost":{"known_usd":"0","unknown":False}})
            row={"attempt_index":index,"arm":attempt["arm"],"task_id":attempt["task_id"],
                 "attempt_receipt":str(directory/"attempt.json"),"workflow_state":"closed",
                 "measurement_invalid":False,"reason":None,"candidate":str(candidate),
                 "source_digest":input_digest(candidate),"invocations":invocations,"grade":None}
            self.write(directory/"attempt.json",row)
            closed["attempts"].append({"attempt_receipt":row["attempt_receipt"],
                "receipt_sha256":self.reg["bindings"][row["attempt_receipt"]],
                "candidate":str(candidate),"source_digest":row["source_digest"]})
            grade_root=self.root/"grades"/str(index).zfill(2);grade_root.mkdir(parents=True)
            packet={"source":str(candidate),"source_digest":row["source_digest"],
                    "config":"/private/config","config_sha256":"c"*64}
            self.write(grade_root/"private-request.json",packet)
            self.write(grade_root/"private-entry-started.json",{"entry_sha256":"e"*64,
                "request_sha256":self.reg["bindings"][str(grade_root/"private-request.json")]})
            row["grade"]={"valid":True,"pass":False}
            self.write(grade_root/"verdict.json",row["grade"])
            attempts.append(row)
        self.write(self.root/"ledger-final.json",{"charges":[]})
        closed["ledger_sha256"]=self.reg["bindings"][str(self.root/"ledger-final.json")]
        documents={"registration":("registration.json",qualified),
            "result":("result.json",{"status":"completed","unexecuted":[],"attempts":attempts}),
            "qualification":("runtime-qualification.json",{"attempts":8,"native_invocations":16,
                "private_evaluator_processes":8,"provider_forwarded":0,"all_protocol_workflows_closed":True,
                "efficacy_claim":None,"model_cost_usd":"0"}),
            "closure":("actor-batch-closed.json",closed)}
        for role,(name,value) in documents.items():
            self.write(self.root/name,value)
            self.proof[role]=self.bind(self.root/name)
        self.proof["ledger"]=self.bind(self.root/"ledger-final.json")

    def bind(self,path):
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        self.reg["bindings"][str(path)]=digest
        return {"path":str(path),"sha256":digest}

    def write(self,path,value):
        path.write_text(json.dumps(value))
        return self.bind(path)

    def invoke(self):
        with patch.object(subject,"_runtime_sources",return_value=[self.frozen]), \
             patch.object(subject,"verify_native_invocation",return_value={}) as native:
            result=subject.verify_runtime(self.reg,self.proof)
        return result,native.call_count

    def test_sixteen_native_invocations_and_eight_independent_grade_inputs_are_reopened(self):
        checked,calls=self.invoke()
        self.assertEqual(calls,16)
        self.assertEqual(checked["native_invocations"],16)
        self.assertEqual(checked["private_evaluator_processes"],8)

    def test_changed_qualified_runtime_source_is_not_covered_by_a_positive_summary(self):
        self.frozen.write_text("changed after qualification")
        with self.assertRaisesRegex(ValueError,"evidence bytes changed"):
            self.invoke()

    def test_rebound_summary_incomplete_attempt_or_wrong_phase_cap_refuse(self):
        for case in ("summary","attempt","cap","private"):
            with self.subTest(case=case):
                target={"summary":self.root/"runtime-qualification.json",
                    "attempt":self.root/"result.json",
                    "cap":self.root/"attempts/00-L/repair/intent.json",
                    "private":self.root/"grades/00/private-entry-started.json"}[case]
                raw=target.read_bytes()
                value=json.loads(raw)
                if case=="summary": value["native_invocations"]=15
                elif case=="attempt": value["attempts"][0]["workflow_state"]="incomplete"
                elif case=="cap": value["cli_cap_usd"]="3"
                else: value["entry_sha256"]="0"*64
                self.write(target,value)
                role={"summary":"qualification","attempt":"result"}.get(case)
                if role: self.proof[role]=self.bind(target)
                with self.assertRaises(ValueError): self.invoke()
                target.write_bytes(raw)
                self.bind(target)
                if role: self.proof[role]=self.bind(target)

    def test_different_paid_schedule_or_unbound_producer_cannot_reuse_qualification(self):
        self.reg["schedule"].reverse()
        with self.assertRaises(ValueError): self.invoke()
        self.reg["schedule"].reverse()
        self.reg["bindings"].pop(str(self.producer))
        with self.assertRaises(ValueError): self.invoke()
class VerificationAdmissionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir="/var/tmp")
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.source=self.root/"source.py";self.source.write_text("reviewed source")
        self.reg={"bindings":{}}
        self.commands={role:{"cwd":str(self.root),"argv":["command",role]} for role in
                       ("protocol","lifecycle","evaluator","gate")}
        self.sources=[self.source]
        digest=hashlib.sha256(self.source.read_bytes()).hexdigest()
        self.reg["bindings"][str(self.source)]=digest
        self.value={"schema":"effort-verification-v1","source_before":{str(self.source):digest},
                    "source_after":{str(self.source):digest},"executions":{}}
        for role,command in self.commands.items():
            log=self.root/(role+".log");log.write_text("observed complete test output")
            self.value["executions"][role]={**command,"exit_code":0,"timed_out":False,
                "environment":{"TMPDIR":"/var/tmp","PYTHONDONTWRITEBYTECODE":"1",
                    "CODESCOUT_WIP_ATTRIBUTION_TIMEOUT_MS":"120000","NEXTEST_TEST_THREADS":"4","RUST_TEST_THREADS":"4",
                    "EFFORT_PROTOCOL_TEST_IMAGE":"sha256:"+"a"*64,"EFFORT_FIXTURE_TEST_IMAGE":"sha256:"+"a"*64},
                "log":self.bind(log)}
        producer=self.root/"producer.py";producer.write_text("observed verification driver")
        self.value["producer"]=self.bind(producer)
        self.seal()

    def bind(self,path):
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        self.reg["bindings"][str(path)]=digest
        return {"path":str(path),"sha256":digest}

    def seal(self):
        path=self.root/"verification.json";path.write_text(json.dumps(self.value))
        self.descriptor=self.bind(path)

    def invoke(self):
        with patch.object(subject,"verification_contract",return_value=(self.sources,self.commands)):
            return subject.verify_verification(self.reg,self.descriptor)

    def test_complete_current_sources_and_exact_commands_are_required(self):
        self.assertEqual(set(self.invoke()["executions"]),set(self.commands))
        original=copy.deepcopy(self.value)
        for case in ("exit","bool","timeout","command","cwd","environment","sources","after","missing","empty-log"):
            self.value=copy.deepcopy(original)
            row=self.value["executions"]["gate"]
            if case=="exit":row["exit_code"]=1
            elif case=="bool":row["exit_code"]=False
            elif case=="timeout":row["timed_out"]=True
            elif case=="command":row["argv"]=["true"]
            elif case=="cwd":row["cwd"]="/elsewhere"
            elif case=="environment":row["environment"]["NEXTEST_TEST_THREADS"]="99"
            elif case=="sources":self.value["source_before"]={}
            elif case=="after":self.value["source_after"]={}
            elif case=="missing":self.value["executions"].pop("evaluator")
            else:
                path=self.root/"empty.log";path.write_text("")
                row["log"]=self.bind(path)
            self.seal()
            with self.subTest(case=case),self.assertRaises(ValueError):
                self.invoke()
        self.value=original;self.seal()
        self.source.write_text("unverified later source")
        with self.assertRaises(ValueError):self.invoke()
class ReviewAdmissionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir="/var/tmp")
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.source=self.root/"source.py";self.source.write_text("load-bearing guard")
        digest=hashlib.sha256(self.source.read_bytes()).hexdigest()
        self.reg={"bindings":{str(self.source):digest},"admission":{"verification":{},"review":{}},
                  "campaign_id":"fixed-campaign","schedule":[{"arm":"L"}]}
        self.source_map={str(self.source):digest}
        self.value={"schema":"effort-whole-admission-review-v1","scope":"whole-admission",
                    "reviewer":{"id":"independent-review","model":"strongest-available"},
                    "verdict":"approve","source_before":self.source_map,"findings":[],"mutations":[]}
        self.value["target_sha256"]=subject.review_target(self.reg)
        baseline=self.root/"baseline.log";baseline.write_text("baseline tests passed")
        self.value["baseline"]={"exit_code":0,"timed_out":False,"log":self.bind(baseline)}
        original=self.root/"original.py";original.write_bytes(self.source.read_bytes())
        for index in range(8):
            mutant=self.root/("mutant-"+str(index)+".py");mutant.write_text("removed guard "+str(index))
            log=self.root/("mutant-"+str(index)+".log");log.write_text("tests failed on the applied mutant")
            self.value["mutations"].append({"id":"M"+str(index),"source":str(self.source),
                "original":self.bind(original),"mutated":self.bind(mutant),"syntax_exit_code":0,
                "test_exit_code":1,"timed_out":False,"syntax_timed_out":False,"log":self.bind(log),"equivalent":False})
        self.seal()

    def bind(self,path):
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        self.reg["bindings"][str(path)]=digest
        return {"path":str(path),"sha256":digest}

    def seal(self,resolution=None):
        path=self.root/"review.json";path.write_text(json.dumps(self.value))
        self.descriptor={"report":self.bind(path),"resolution":resolution}

    def invoke(self):
        with patch.object(subject,"verification_contract",return_value=([self.source],{})):
            return subject.verify_review(self.reg,self.descriptor)

    def test_observed_mutation_results_and_full_scope_are_required(self):
        self.assertEqual(self.invoke()["valid_applied_mutants"],8)
        original=copy.deepcopy(self.value)
        for case in ("seven","reasoning","survivor","syntax","bool","scope","target","finding","baseline","timeout","syntax-timeout","encoded-signal","missing-timeout","missing-syntax-timeout","baseline-timeout","baseline-missing-timeout"):
            self.value=copy.deepcopy(original)
            if case=="seven":self.value["mutations"].pop()
            elif case=="reasoning":self.value["mutations"]=[]
            elif case=="survivor":self.value["mutations"][0]["test_exit_code"]=0
            elif case=="syntax":self.value["mutations"][0]["syntax_exit_code"]=1
            elif case=="bool":self.value["mutations"][0]["test_exit_code"]=True
            elif case=="scope":self.value["scope"]="slice"
            elif case=="target":self.value["target_sha256"]="0"*64
            elif case=="finding":self.value["findings"]=[{"id":"F1","severity":"high"}]
            elif case=="baseline":self.value["baseline"]["exit_code"]=1
            elif case=="timeout":self.value["mutations"][0].update(test_exit_code=124,timed_out=True)
            elif case=="syntax-timeout":self.value["mutations"][0]["syntax_timed_out"]=True
            elif case=="encoded-signal":self.value["mutations"][0]["test_exit_code"]=137
            elif case=="missing-timeout":self.value["mutations"][0].pop("timed_out")
            elif case=="missing-syntax-timeout":self.value["mutations"][0].pop("syntax_timed_out")
            elif case=="baseline-timeout":self.value["baseline"]["timed_out"]=True
            else:self.value["baseline"].pop("timed_out")
            self.seal()
            with self.subTest(case=case),self.assertRaises(ValueError):
                self.invoke()
        self.value=original;self.seal()
        self.reg["schedule"][0]["arm"]="X"
        with self.assertRaises(ValueError):self.invoke()

    def test_one_bounded_correction_requires_exact_survivor_replay_and_current_sources(self):
        regression=self.root/"regression.py";regression.write_text("original regression")
        self.source_map[str(regression)]=self.bind(regression)["sha256"]
        self.value["verdict"]="changes_required"
        self.value["findings"]=[{"id":"F1","severity":"high"}]
        self.value["mutations"][0]["test_exit_code"]=0
        self.seal()
        report_sha=self.descriptor["report"]["sha256"]
        regression.write_text("corrected regression")
        after={**self.source_map,str(regression):self.bind(regression)["sha256"]}
        replay=copy.deepcopy(self.value["mutations"][0])
        replay["test_exit_code"]=1
        resolution={"schema":"effort-bounded-review-correction-v1","correction_rounds":1,
            "review_sha256":report_sha,"target_sha256":self.value["target_sha256"],
            "source_before":self.value["source_before"],"source_after":after,
            "findings_closed":["F1"],"outstanding":[],"replays":[replay]}
        path=self.root/"resolution.json";path.write_text(json.dumps(resolution))
        self.descriptor["resolution"]=self.bind(path)
        with patch.object(subject,"verification_contract",return_value=([self.source,regression],{})):
            self.assertEqual(subject.verify_review(self.reg,self.descriptor)["bounded_correction_rounds"],1)
            resolution["replays"]=[]
            path.write_text(json.dumps(resolution));self.descriptor["resolution"]=self.bind(path)
            with self.assertRaises(ValueError):subject.verify_review(self.reg,self.descriptor)
    def test_unrelated_killed_mutant_cannot_replace_original_survivor(self):
        self.value["verdict"]="changes_required"
        self.value["findings"]=[{"id":"F1","severity":"high"}]
        self.value["mutations"][0]["test_exit_code"]=0
        self.seal()
        original=copy.deepcopy(self.value["mutations"][0])
        other=self.root/"other.py";other.write_bytes(self.source.read_bytes())
        source_map={**self.source_map,str(other):self.bind(other)["sha256"]}
        self.value["source_before"]=source_map
        self.seal()
        for case in ("same-file","cross-file"):
            with self.subTest(case=case):
                replay=copy.deepcopy(self.value["mutations"][1])
                replay["id"]=original["id"]
                if case=="cross-file":
                    replay["source"]=str(other)
                resolution={"schema":"effort-bounded-review-correction-v1","correction_rounds":1,
                    "review_sha256":self.descriptor["report"]["sha256"],
                    "target_sha256":self.value["target_sha256"],
                    "source_before":source_map,"source_after":source_map,
                    "findings_closed":["F1"],"outstanding":[],"replays":[replay]}
                path=self.root/"substituted-resolution.json";path.write_text(json.dumps(resolution))
                self.descriptor["resolution"]=self.bind(path)
                with patch.object(subject,"verification_contract",return_value=([self.source,other],{})):
                    with self.assertRaisesRegex(ValueError,"original survivor mutation"):
                        subject.verify_review(self.reg,self.descriptor)

class TrustedPrivateAdmissionTests(unittest.TestCase):
    def setUp(self):
        import trusted_test_inputs as core
        self.temp=tempfile.TemporaryDirectory(dir="/var/tmp")
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.reg={"bindings":{}}
        source=self.root/"canonical";(source/"tests").mkdir(parents=True)
        (source/"tests/original.snap").write_text("original assertion")
        self.trusted=core.seal_test_inputs(source,["tests"],self.root/"sealed")
        self.grade=self.root/"grade";self.grade.mkdir()
        self.config={"trusted_test_inputs":self.trusted,"bindings":{}}
        for name in ("evaluator_entry.py","trusted_test_inputs.py","feedback_trusted_inputs.py"):
            p=Path(subject.__file__).parent/name
            self.config["bindings"][str(p)]=self.bind(p)["sha256"]
        for role in ("manifest","archive"):
            self.bind(Path(self.trusted[role]))
        self.config_path=self.root/"config.json"
        self.private={"config":str(self.config_path)}
        self.seal_config()
        roots,entries,_=core._validated(self.trusted)
        expected={"complete":True,"roots":roots,"entries_verified":len(entries),
                  "manifest_sha256":self.trusted["manifest_sha256"],
                  "coverage":"Registered standalone inputs; no inline assertion claim"}
        remote=dict(self.trusted)
        for role in ("manifest","archive"):remote[role]="/tmp/effort-trusted-12345678/"+Path(remote[role]).name
        self.installation={"container":"a"*64,"helper":"/tmp/effort-trusted-12345678/trusted_test_inputs.py",
            "helper_sha256":hashlib.sha256(Path(core.__file__).read_bytes()).hexdigest(),
            "descriptor":remote,"restoration":copy.deepcopy(expected)}
        self.observations=[{"stage":"before-remove","name":"owned","inspect":{"Id":"a"*64},
                            "trusted_test_inputs":expected}]
        self.seal_grade()

    def bind(self,path):
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        self.reg["bindings"][str(path)]=digest
        return {"path":str(path),"sha256":digest}

    def seal_config(self):
        self.config_path.write_text(json.dumps(self.config))
        self.private["config_sha256"]=self.bind(self.config_path)["sha256"]

    def seal_grade(self):
        p=self.grade/"trusted-input-installation.json";p.write_text(json.dumps(self.installation));self.bind(p)
        p=self.grade/"runtime-observations.jsonl"
        p.write_text("".join(json.dumps(v)+"\n" for v in self.observations));self.bind(p)

    def test_original_input_protection_requires_bound_restore_and_postgrade_verification(self):
        result=subject.verify_private_test_inputs(self.reg,self.private,self.grade)
        self.assertEqual(result["entries_verified"],2)
        original_config=copy.deepcopy(self.config)
        original_install=copy.deepcopy(self.installation)
        original_observations=copy.deepcopy(self.observations)
        for case in ("absent","version","helper","restoration","postgrade","container","duplicate","artifact-binding"):
            with self.subTest(case=case):
                self.config=copy.deepcopy(original_config)
                self.installation=copy.deepcopy(original_install)
                self.observations=copy.deepcopy(original_observations)
                if case=="absent":self.config.pop("trusted_test_inputs")
                elif case=="version":self.config["trusted_test_inputs"]["schema"]="legacy"
                elif case=="helper":self.installation["helper_sha256"]="0"*64
                elif case=="restoration":self.installation["restoration"]["entries_verified"]=1
                elif case=="postgrade":self.observations[0].pop("trusted_test_inputs")
                elif case=="container":self.observations[0]["inspect"]["Id"]="b"*64
                elif case=="duplicate":self.observations.append(copy.deepcopy(self.observations[0]))
                else:self.reg["bindings"].pop(self.trusted["archive"])
                self.seal_config();self.seal_grade()
                with self.assertRaises(ValueError):
                    subject.verify_private_test_inputs(self.reg,self.private,self.grade)
                self.bind(Path(self.trusted["archive"]))


class SharedPreparationAdmissionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir="/var/tmp")
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.reg={"bindings":{},"tasks":{}}
        self.value={"schema":"effort-shared-reuse-v1","client_author_calls":0,"new_client_model_cost_usd":"0",
                    "excluded_costs":{name:{"status":"unmeasured","usd":None} for name in
                                      ("root","review","embedding_compute")},"tasks":{}}
        producer=self.root/"producer.py";producer.write_text("local reuse-only preparation")
        self.value["producer"]=self.bind(producer)
        for identity in ("a","b"):
            template=self.root/identity
            (template/".codescout").mkdir(parents=True)
            (template/"code.rs").write_text("source")
            system=template/".codescout/system-prompt.md";system.write_text("frozen onboarding")
            public={"template":str(template),"template_sha256":input_digest(template),
                    "knowledge_paths":["system-prompt.md"],
                    "knowledge_sha256":input_digest(template/".codescout",["system-prompt.md"])}
            self.reg["tasks"][identity]={"backend":{"public":public}}
            self.value["tasks"][identity]={key:public[key] for key in
                                          ("template","template_sha256","knowledge_sha256")}
            self.bind(system)
        self.seal()

    def bind(self,path):
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        self.reg["bindings"][str(path)]=digest
        return {"path":str(path),"sha256":digest}

    def seal(self):
        path=self.root/"shared.json";path.write_text(json.dumps(self.value))
        self.descriptor=self.bind(path)
        self.reg["shared_preparation"]={"cost_usd":"0","receipt_sha256":self.descriptor["sha256"]}

    def test_shared_build_preparation_reopens_provenance_manifests_versions_and_helper(self):
        import public_build_inputs as build
        public=self.reg["tasks"]["a"]["backend"]["public"]
        template=Path(public["template"])
        manifest=template/"Cargo.toml";manifest.write_text("[workspace]\n")
        public.update(image="sha256:"+"a"*64,execution_profile="cargo-v3",
            public_build_inputs={"schema":"public-build-inputs-v1","image":"sha256:"+"a"*64,
                                 "seed":None,"dependency_dirs":[],"cache_mounts":[]})
        public["template_sha256"]=input_digest(template)
        row=self.value["tasks"]["a"]
        row["template_sha256"]=public["template_sha256"]
        row["public_build_inputs"]=copy.deepcopy(public["public_build_inputs"])
        canonical=Path(build.__file__).resolve()
        version=self.root/"version.json"
        version.write_text(json.dumps({"image":public["image"],"argv":["cargo","--version"],
            "returncode":0,"stdout":"cargo 1.96.0\n","stderr":""}))
        producer=self.root/"build-producer.py";producer.write_text("# public preparation")
        proof={"schema":"public-build-preparation-v1","image":public["image"],
            "descriptor_sha256":build.validate_descriptor(public["public_build_inputs"],template,public["image"])["fingerprint"],
            "helper":self.bind(canonical),"producer":self.bind(producer),
            "source_manifests":[{"relative":"Cargo.toml",**self.bind(manifest)}],
            "version_probes":[self.bind(version)],"seed":None}
        proof_path=self.root/"build-preparation.json"
        def seal_proof():
            proof_path.write_text(json.dumps(proof))
            row["public_build_preparation"]=self.bind(proof_path)
            self.seal()
        seal_proof()
        result=subject.verify_shared_preparation(self.reg,self.descriptor)
        self.assertEqual(result["public_build_inputs"]["a"],proof["descriptor_sha256"])
        original=copy.deepcopy(proof)
        for case in ("fingerprint","image","helper","manifest-coverage","manifest-relative","version","seed"):
            proof=copy.deepcopy(original)
            with self.subTest(case=case):
                if case=="fingerprint":proof["descriptor_sha256"]="0"*64
                elif case=="image":proof["image"]="sha256:"+"b"*64
                elif case=="helper":
                    fake=self.root/"fake-helper.py";fake.write_text("# validly rebound wrong helper")
                    proof["helper"]=self.bind(fake)
                elif case=="manifest-coverage":proof["source_manifests"]=[]
                elif case=="manifest-relative":proof["source_manifests"][0]["relative"]="../Cargo.toml"
                elif case=="version":
                    version.write_text(json.dumps({"image":"sha256:"+"b"*64,"argv":["cargo","--version"],
                        "returncode":0,"stdout":"cargo 1.96.0","stderr":""}))
                    proof["version_probes"]=[self.bind(version)]
                else:proof["seed"]={"path":"/foreign","sha256":"0"*64}
                seal_proof()
                with self.assertRaises(ValueError):subject.verify_shared_preparation(self.reg,self.descriptor)
                version.write_text(json.dumps({"image":public["image"],"argv":["cargo","--version"],
                    "returncode":0,"stdout":"cargo 1.96.0\n","stderr":""}));self.bind(version)
        proof=copy.deepcopy(original);seal_proof()
        row.pop("public_build_inputs");self.seal()
        with self.assertRaises(ValueError):subject.verify_shared_preparation(self.reg,self.descriptor)

    def test_zero_author_reuse_retains_unmeasured_costs_and_exact_templates(self):
        self.assertEqual(subject.verify_shared_preparation(self.reg,self.descriptor)["client_author_calls"],0)
        original=copy.deepcopy(self.value)
        for case in ("calls","cost","coverage","knowledge","excluded"):
            self.value=copy.deepcopy(original)
            if case=="calls":self.value["client_author_calls"]=1
            elif case=="cost":self.value["new_client_model_cost_usd"]="0.5"
            elif case=="coverage":self.value["tasks"].pop("a")
            elif case=="knowledge":self.value["tasks"]["a"]["knowledge_sha256"]="0"*64
            else:self.value["excluded_costs"]["review"]={"status":"unmeasured","usd":"0"}
            self.seal()
            with self.subTest(case=case),self.assertRaises(ValueError):
                subject.verify_shared_preparation(self.reg,self.descriptor)
        self.value=original;self.seal()
        (self.root/"a/.codescout/system-prompt.md").write_text("reauthored onboarding")
        with self.assertRaises(ValueError):subject.verify_shared_preparation(self.reg,self.descriptor)

class PaidEvidenceBoundaryTests(unittest.TestCase):
    def test_every_concrete_proof_is_required_and_no_ready_flag_can_replace_it(self):
        roles={"population":"verify_population","public_commands":"verify_public_commands",
               "accounting":"verify_accounting","runtime":"verify_runtime",
               "verification":"verify_verification","review":"verify_review",
               "shared_preparation":"verify_shared_preparation"}
        reg={"schema":"evidence-campaign-v1","mode":"paid","tasks":{"a":{"backend":{"scripted_plans":{}}}},
             "admission":{name:{"proof":name} for name in roles}}
        reg["admission"]["credential_path"]="/registered/token"
        from contextlib import ExitStack
        with ExitStack() as stack:
            mocks={name:stack.enter_context(patch.object(subject,function,return_value={"checked":name}))
                   for name,function in roles.items()}
            result=subject.verify_paid(reg)
            self.assertTrue(result["ready"])
            self.assertEqual(set(result["proofs"]),set(roles))
            for name,checker in mocks.items():
                checker.assert_called_once_with(reg,reg["admission"][name])
            mocks["runtime"].side_effect=ValueError("runtime incomplete")
            with self.assertRaisesRegex(ValueError,"runtime incomplete"):subject.verify_paid(reg)
        reg["admission"]={"ready":True}
        with self.assertRaises(ValueError):subject.verify_paid(reg)
class PaidAuthorizationTests(unittest.TestCase):
    """Authorization-only fixtures mock the separate concrete evidence verifier."""
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir="/var/tmp")
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.token=self.root/"token";self.token.write_text("unit placeholder");self.token.chmod(0o600)
        self.reg={"campaign_id":"paid","output_root":str(self.root/"outputs"),"tasks":{},"bindings":{},
                  "admission":{"credential_path":str(self.token)}}
        selected=[{"id":"task"+str(i),"repo":"org/repo"+str(i),"base_commit":"a"*40,
                   "image":"frozen-image","language":"rust","public_issue_sha256":str(i+1)*64,
                   "eligible":True,"reason":"qualified"} for i in range(2)]
        self.reg["schedule"]=attempt_schedule(selected)
        for row in selected:
            source=self.root/row["id"];source.mkdir()
            (source/"source.rs").write_text("baseline")
            self.reg["tasks"][row["id"]]={"source":str(source),"source_sha256":input_digest(source),
                "public_packet":{"issue":"public issue"},"backend":{"public":{"runtime":"frozen"}}}
        bound=self.root/"bound";bound.write_text("fixed")
        self.reg["bindings"][str(bound)]=hashlib.sha256(bound.read_bytes()).hexdigest()
        with patch.object(subject,"verify_paid",return_value={"ready":True}):
            self.admission=subject.PaidAdmission(self.reg,self.token)

    def request(self,index=0,phase="repair"):
        attempt=self.reg["schedule"][index]
        task=self.reg["tasks"][attempt["task_id"]]
        phases=("investigate","repair","challenge") if attempt["arm"] in ("P","R") else ("repair",)
        pos=phases.index(phase)
        request={"attempt_index":index,"task_id":attempt["task_id"],"arm":attempt["arm"],"phase":phase,
                 "invocation_id":"paid::"+str(index)+"::"+phase,"source":task["source"],
                 "state":{"run_id":"paid-"+str(index),"turns_used":0,"baseline_digest":task["source_sha256"]},
                 "allowance_usd":attempt["phase_reservations_usd"][pos] if len(phases)==3 else attempt["reserved_usd"],
                 "cli_cap_usd":attempt["phase_cli_caps_usd"][pos] if len(phases)==3 else attempt["cli_cap_usd"],
                 "effort":"xhigh" if attempt["arm"]=="X" else "low","max_continuations":2,
                 "public_packet":{"issue":"public issue","prior_public_artifacts":[]}}
        out=Path(self.reg["output_root"])/"attempts"/(str(index).zfill(2)+"-"+attempt["arm"])/phase
        out.mkdir(parents=True,exist_ok=True)
        return request,out,task["backend"]["public"]

    def test_exact_authorization_is_single_use_and_cannot_mutate_its_registration(self):
        request,out,public=self.request()
        self.assertEqual(self.admission.authorize(request,out,public,self.token),
                         {"authorized_invocation":"paid::0::repair"})
        with self.assertRaises(ValueError):self.admission.authorize(request,out,public,self.token)
        self.admission.registration["campaign_id"]="changed"
        with self.assertRaises(ValueError):self.admission.authorize(request,out,public,self.token)

    def test_rebound_budget_source_context_effort_and_prior_phase_are_refused(self):
        original,out,public=self.request()
        for key,value in (("attempt_index",True),("cli_cap_usd","99"),("allowance_usd","99"),
                          ("effort","xhigh"),("max_continuations",8),("invocation_id","another")):
            request=copy.deepcopy(original);request[key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):
                self.admission.authorize(request,out,public,self.token)
        request=copy.deepcopy(original);request["public_packet"]["issue"]="private leakage"
        with self.assertRaises(ValueError):self.admission.authorize(request,out,public,self.token)
        request=copy.deepcopy(original);request["state"]["turns_used"]=1
        with self.assertRaises(ValueError):self.admission.authorize(request,out,public,self.token)
        request,out,public=self.request(1,"repair")
        with self.assertRaises(ValueError):self.admission.authorize(request,out,public,self.token)
        Path(next(iter(self.reg["bindings"]))).write_text("drift")
        request,out,public=self.request()
        with self.assertRaises(ValueError):self.admission.authorize(request,out,public,self.token)

    def test_later_phase_uses_exact_settled_candidate_and_public_artifact(self):
        request,out,public=self.request(1,"investigate")
        self.admission.authorize(request,out,public,self.token)
        candidate=self.root/"candidate";candidate.mkdir()
        (candidate/"source.rs").write_text("intermediate repair")
        artifact={"receipt":"public investigation"}
        record={"measurement_invalid":False,"cost_is_final":True,
                "state":{"phase":"repair","turns_used":2},"candidate":str(candidate),
                "source_digest":input_digest(candidate),"public_artifact":artifact}
        (out/"invocation.json").write_text(json.dumps(record))
        request,out,public=self.request(1,"repair")
        request["source"]=str(candidate)
        request["state"]["turns_used"]=2
        request["public_packet"]["prior_public_artifacts"]=[artifact]
        for case in ("source","artifact","unknown"):
            bad=copy.deepcopy(request)
            if case=="source":bad["source"]=self.reg["tasks"][bad["task_id"]]["source"]
            elif case=="artifact":bad["public_packet"]["prior_public_artifacts"]=[]
            else:
                previous=out.parent/"investigate/invocation.json"
                changed=copy.deepcopy(record);changed["cost_is_final"]=False
                previous.write_text(json.dumps(changed))
            with self.subTest(case=case),self.assertRaises(ValueError):
                self.admission.authorize(bad,out,public,self.token)
            (out.parent/"investigate/invocation.json").write_text(json.dumps(record))
        self.assertEqual(self.admission.authorize(request,out,public,self.token)["authorized_invocation"],
                         "paid::1::repair")

    def test_credential_permission_or_path_change_is_rejected_before_use(self):
        self.token.chmod(0o644)
        with patch.object(subject,"verify_paid",return_value={"ready":True}),self.assertRaises(ValueError):
            subject.PaidAdmission(self.reg,self.token)
        request,out,public=self.request()
        with self.assertRaises(ValueError):
            self.admission.authorize(request,out,public,self.root/"other-token")


if __name__=="__main__":
    unittest.main()
