"""Frozen public static HTTP fixture, shared by native and command runtimes.

All routes are controller-owned public data. No filesystem dispatch or outbound
network is provided by the service. Runtime admission must check the descriptor
and actual read-only mount before allowing the wrapped process to count.
"""
import hashlib
import http.client
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import os
from pathlib import Path, PurePosixPath
import re
import select
import stat
import subprocess
import sys

VERSION = "public-fixture-bundle-v1"
DESTINATION = "/bench/public-fixture"
DATA_FILES = {"public_fixture.py", "launch-native", "launch-command", "spec.json"}
MAX_BODY = 1_048_576
MAX_SPEC = 4_194_304


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n").encode()


def validate_spec(spec):
    if not isinstance(spec, dict) or set(spec) != {"version", "hostname", "port", "routes"}:
        raise ValueError("fixture spec keys")
    if spec["version"] != "public-http-fixture-v1":
        raise ValueError("fixture spec version")
    host = spec["hostname"]
    if (not isinstance(host, str) or len(host) > 253
            or not re.fullmatch(r"fixture\.(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)*"
                                r"(?:test|invalid|example|example\.com|example\.org|example\.net)", host)):
        raise ValueError("fixture hostname must be an explicit reserved fixture namespace")
    if type(spec["port"]) is not int or not 1024 <= spec["port"] <= 65535:
        raise ValueError("fixture port")
    routes = spec["routes"]
    if not isinstance(routes, dict) or not 1 <= len(routes) <= 64 or "/" not in routes:
        raise ValueError("fixture routes")
    for route, response in routes.items():
        if (not isinstance(route, str) or not route.startswith("/") or len(route) > 2048
                or any(ord(ch) < 32 for ch in route) or "#" in route):
            raise ValueError("fixture route path")
        if not isinstance(response, dict) or set(response) != {"status", "content_type", "body"}:
            raise ValueError("fixture response keys")
        if type(response["status"]) is not int or not 200 <= response["status"] <= 599:
            raise ValueError("fixture response status")
        content_type = response["content_type"]
        if (not isinstance(content_type, str) or not 1 <= len(content_type) <= 128
                or not content_type.isascii() or any(ord(ch) < 32 for ch in content_type)):
            raise ValueError("fixture content type")
        if not isinstance(response["body"], str) or len(response["body"].encode()) > MAX_BODY:
            raise ValueError("fixture response body")
    if len(canonical(spec)) > MAX_SPEC:
        raise ValueError("fixture spec size")
    return spec


def plain_path(value, must_exist=True):
    if not isinstance(value, (str, Path)):
        raise ValueError("fixture path type")
    path = Path(os.path.abspath(value))
    if any(ch in str(path) for ch in (",", "\n", "\r", "\0")):
        raise ValueError("fixture mount path")
    for part in (path, *path.parents):
        if part.is_symlink():
            raise ValueError("fixture symlink path")
    if must_exist and not path.is_dir():
        raise ValueError("fixture root is not a directory")
    return path


def file_identity(path):
    mode = path.lstat().st_mode
    if not stat.S_ISREG(mode) or stat.S_IMODE(mode) & 0o022:
        raise ValueError("fixture must contain only non-shared-writable regular files")
    return {"sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "mode": stat.S_IMODE(mode)}


def create_fixture_bundle(out, spec):
    validate_spec(spec)
    root = plain_path(out, must_exist=False)
    if root.exists():
        raise ValueError("fixture output already exists")
    wrapper = (
        "#!/usr/bin/env -S python3 -I -B\n"
        "from pathlib import Path\nimport runpy\n"
        "runpy.run_path(str(Path(__file__).with_name('public_fixture.py')), "
        "init_globals={'FIXTURE_LAUNCH_MODE': %r}, run_name='__main__')\n"
    )
    content = {
        "public_fixture.py": Path(__file__).read_bytes(),
        "launch-native": (wrapper % "native").encode(),
        "launch-command": (wrapper % "command").encode(),
        "spec.json": canonical(spec),
    }
    # Validate everything before the first output effect.
    root.mkdir(parents=True)
    for name, data in content.items():
        path = root / name
        path.write_bytes(data)
        path.chmod(0o755 if name.startswith("launch-") else 0o644)
    files = {name: file_identity(root / name) for name in sorted(DATA_FILES)}
    identity = {"version": VERSION, "files": files}
    identity["fingerprint"] = hashlib.sha256(canonical(identity)).hexdigest()
    manifest = root / "manifest.json"
    manifest.write_bytes(canonical(identity))
    manifest.chmod(0o644)
    return dict(identity, root=str(root))


def read_fixture_bundle(descriptor):
    if not isinstance(descriptor, dict) or set(descriptor) != {"version", "root", "files", "fingerprint"}:
        raise ValueError("fixture descriptor keys")
    root = plain_path(descriptor["root"])
    if descriptor["version"] != VERSION or set(p.name for p in root.iterdir()) != DATA_FILES | {"manifest.json"}:
        raise ValueError("fixture version or file population")
    if not isinstance(descriptor["files"], dict) or set(descriptor["files"]) != DATA_FILES:
        raise ValueError("fixture file identity population")
    identity = {"version": VERSION, "files": descriptor["files"]}
    fingerprint = hashlib.sha256(canonical(identity)).hexdigest()
    if descriptor["fingerprint"] != fingerprint:
        raise ValueError("fixture fingerprint")
    for name in DATA_FILES:
        expected = descriptor["files"][name]
        actual = file_identity(root / name)
        if actual != expected or actual["mode"] != (0o755 if name.startswith("launch-") else 0o644):
            raise ValueError("fixture file identity mismatch: " + name)
    file_identity(root / "manifest.json")
    if (root / "manifest.json").read_bytes() != canonical(dict(identity, fingerprint=fingerprint)):
        raise ValueError("fixture manifest identity")
    if (root / "spec.json").stat().st_size > MAX_SPEC:
        raise ValueError("fixture spec size")
    try:
        return validate_spec(json.loads((root / "spec.json").read_bytes()))
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError("fixture spec encoding") from exc


def fixture_docker_options(descriptor, mode):
    spec = read_fixture_bundle(descriptor)
    if mode not in ("native", "command"):
        raise ValueError("fixture launch mode")
    return ["--mount", f"type=bind,src={descriptor['root']},dst={DESTINATION},readonly",
            "--add-host", f"{spec['hostname']}:127.0.0.1",
            "--entrypoint", f"{DESTINATION}/launch-{mode}"]

def verify_fixture_startup(stderr, descriptor):
    read_fixture_bundle(descriptor)
    ready = ("public-fixture-ready " + descriptor["fingerprint"] + "\n").encode()
    if not stderr.startswith(ready) or b"\npublic-fixture-failed:" in stderr:
        raise ValueError("public fixture startup or exec failed")
    return {"fingerprint": descriptor["fingerprint"], "ready": True}


def validate_fixture_runtime(row, descriptor, mode):
    spec = read_fixture_bundle(descriptor)
    if mode not in ("native", "command"):
        raise ValueError("fixture launch mode")
    try:
        if row["HostConfig"].get("ExtraHosts") != [f"{spec['hostname']}:127.0.0.1"]:
            raise ValueError("fixture host alias")
        if row["Config"]["Entrypoint"] != [f"{DESTINATION}/launch-{mode}"]:
            raise ValueError("fixture launcher entrypoint")
        matches = []
        fixture_path = PurePosixPath(DESTINATION)
        for mount in row["Mounts"]:
            destination = PurePosixPath(mount["Destination"])
            if destination == fixture_path:
                matches.append(mount)
            elif destination in fixture_path.parents or fixture_path in destination.parents:
                raise ValueError("fixture overlapping mount")
        if len(matches) != 1:
            raise ValueError("fixture unique mount")
        mount = matches[0]
        if mount["Type"] != "bind" or mount["Source"] != descriptor["root"] or mount["RW"] is not False:
            raise ValueError("fixture readonly mount identity")
    except (KeyError, TypeError) as exc:
        raise ValueError("fixture runtime evidence incomplete") from exc
    return {"version": VERSION, "fingerprint": descriptor["fingerprint"],
            "hostname": spec["hostname"], "port": spec["port"], "mode": mode}

def validate_fixture_options(options, descriptor, mode, *, actor=None):
    """Check declaration before credentials, process creation or container effects."""
    read_fixture_bundle(descriptor)
    root = Path(descriptor["root"])
    if actor is not None and (root.is_relative_to(Path(actor).resolve())
                              or Path(actor).resolve().is_relative_to(root)):
        raise ValueError("fixture bundle overlaps mutable actor source")
    mounts = []
    for value in options.get("--mount", []):
        parts = value.split(",")
        parsed = {}
        for part in parts:
            key, separator, item = part.partition("=")
            if key in parsed:
                raise ValueError("duplicate fixture mount option")
            parsed[key] = item if separator else True
        mounts.append({"Type": parsed.get("type"), "Source": parsed.get("src"),
                       "Destination": parsed.get("dst", ""), "RW": parsed.get("readonly") is not True})
    return validate_fixture_runtime(
        {"HostConfig": {"ExtraHosts": options.get("--add-host")},
         "Config": {"Entrypoint": options.get("--entrypoint")}, "Mounts": mounts}, descriptor, mode)


def serve(spec_path, owner_pid):
    spec = validate_spec(json.loads(Path(spec_path).read_bytes()))

    class StaticHandler(BaseHTTPRequestHandler):
        def setup(self):
            super().setup()
            self.connection.settimeout(2)

        def do_GET(self):
            response = spec["routes"].get(self.path)
            if response is None:
                self.send_error(404)
                return
            body = response["body"].encode()
            self.send_response(response["status"])
            self.send_header("Content-Type", response["content_type"])
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *args):
            pass

    try:
        server = HTTPServer(("127.0.0.1", spec["port"]), StaticHandler)
    except OSError as exc:
        print(json.dumps({"error": str(exc)}), flush=True)
        return 78
    server.timeout = .2
    print(json.dumps({"ready": True}), flush=True)
    sys.stdout.close()
    try:
        while os.getppid() == owner_pid:
            server.handle_request()
    finally:
        server.server_close()
    return 0


def launch(mode):
    child = None
    try:
        root = Path(__file__).absolute().parent
        manifest = json.loads((root / "manifest.json").read_bytes())
        descriptor = dict(manifest, root=str(root))
        spec = read_fixture_bundle(descriptor)
        if mode == "native":
            argv = ["/bench/bin/codescout", *sys.argv[1:]]
        elif mode == "command" and sys.argv[1:]:
            argv = sys.argv[1:]
        else:
            raise ValueError("fixture command required")
        child = subprocess.Popen(
            [sys.executable, "-I", "-B", str(root / "public_fixture.py"),
             "serve", str(root / "spec.json"), str(os.getpid())],
            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=sys.stderr)
        ready, _, _ = select.select([child.stdout], [], [], 5)
        if not ready or child.stdout.readline(4096) != b'{"ready": true}\n':
            raise ValueError("fixture child did not start")
        child.stdout.close()
        # Probe the service itself before exec; bypass proxy environment and DNS.
        connection = http.client.HTTPConnection("127.0.0.1", spec["port"], timeout=2)
        try:
            connection.request("GET", "/")
            response = connection.getresponse()
            if (response.status != spec["routes"]["/"]["status"]
                    or response.read(MAX_BODY + 1) != spec["routes"]["/"]["body"].encode()
                    or child.poll() is not None):
                raise ValueError("fixture readiness bytes mismatch")
        finally:
            connection.close()
        print("public-fixture-ready " + descriptor["fingerprint"], file=sys.stderr, flush=True)
        os.execvp(argv[0], argv)
    except (OSError, ValueError, KeyError, TypeError, http.client.HTTPException) as exc:
        if child is not None:
            if child.poll() is None:
                child.terminate()
            child.wait(timeout=3)
        print("public-fixture-failed: " + str(exc), file=sys.stderr, flush=True)
        raise SystemExit(78) from exc


def main():
    if "FIXTURE_LAUNCH_MODE" in globals():
        launch(FIXTURE_LAUNCH_MODE)
    if len(sys.argv) == 4 and sys.argv[1] == "bundle":
        spec = json.loads(Path(sys.argv[3]).read_bytes())
        print(json.dumps(create_fixture_bundle(Path(sys.argv[2]), spec)))
        return 0
    if len(sys.argv) == 4 and sys.argv[1] == "serve":
        return serve(sys.argv[2], int(sys.argv[3]))
    raise ValueError("expected bundle OUT SPEC or serve SPEC OWNER")


if __name__ == "__main__":
    raise SystemExit(main())
