"""Project-independent phase admission over HOST-VERIFIED execution facts.

This module checks protocol structure, not semantic coverage or receipt authenticity.
The adapter MUST obtain receipts from the trusted executor through receipts.py;
passing model-authored dictionaries here would violate that boundary.
"""
import copy
import re

_DIGEST = re.compile(r"[0-9a-f]{64}")
_NEXT = {"investigate": "repair", "repair": "challenge", "challenge": "closed"}

class ProtocolViolation(ValueError):
    """A submitted phase cannot satisfy the registered protocol."""

def _require(condition, message):
    if not condition:
        raise ProtocolViolation(message)

def _digest(value):
    return isinstance(value, str) and _DIGEST.fullmatch(value) is not None

def validate_transition(state: dict, phase_result: dict, receipts: list[dict]) -> dict:
    """Return new state only when the next registered phase can be admitted."""
    _require(isinstance(state, dict) and isinstance(phase_result, dict), "invalid phase objects")
    phase = state.get("phase")
    _require(isinstance(phase, str) and phase in _NEXT, "workflow is not in an active phase")
    run_id = state.get("run_id")
    _require(isinstance(run_id, str) and bool(run_id), "missing run identity")
    _require(phase_result.get("run_id") == run_id and phase_result.get("phase") == phase,
             "phase or run identity mismatch")
    turns = phase_result.get("turns")
    previous_turns = state.get("turns_used", 0)
    _require(type(turns) is int and 1 <= turns <= 3, "phase turn limit")
    _require(type(previous_turns) is int and 0 <= previous_turns <= 9
             and previous_turns + turns <= 9, "workflow turn limit")
    status = phase_result.get("status")
    _require(status in ("submitted", "incomplete", "budget_exhausted"),
             "actor status cannot declare measurement validity")
    out = copy.deepcopy(state)
    out["turns_used"] = previous_turns + turns
    if status != "submitted":
        out["phase"] = status
        return out

    _require(_digest(state.get("baseline_digest")) and _digest(phase_result.get("source_digest")),
             "missing source digest")
    _require(isinstance(receipts, list) and bool(receipts), "no verified execution receipts")
    used = state.get("used_receipts", [])
    _require(isinstance(used, list) and all(isinstance(x, str) for x in used),
             "invalid prior receipt index")
    by_id = {}
    for receipt in receipts:
        _require(isinstance(receipt, dict), "invalid verified receipt")
        rid = receipt.get("id")
        _require(isinstance(rid, str) and bool(rid) and rid not in by_id and rid not in used,
                 "duplicate, missing or replayed receipt")
        _require(receipt.get("run_id") == run_id and receipt.get("phase") == phase,
                 "receipt belongs to another run or phase")
        _require(receipt.get("complete") is True and receipt.get("resource_valid") is True,
                 "receipt is truncated or infrastructure-invalid")
        _require(type(receipt.get("exit_code")) is int, "missing raw execution exit")
        _require(all(_digest(receipt.get(k)) for k in
                     ("source_digest", "production_digest", "test_digest")), "missing input digest")
        if phase == "investigate":
            _require(receipt["production_digest"] == state["baseline_digest"],
                     "production changed during investigation")
        by_id[rid] = receipt

    clauses = phase_result.get("clauses")
    _require(isinstance(clauses, list) and bool(clauses), "missing public clauses")
    clause_ids = set()
    roles = set()
    for clause in clauses:
        _require(isinstance(clause, dict), "invalid clause")
        cid = clause.get("id")
        _require(isinstance(cid, str) and bool(cid) and cid not in clause_ids,
                 "duplicate or missing clause identity")
        clause_ids.add(cid)
        _require(clause.get("kind") in ("requirement", "preservation", "uncertainty"),
                 "unsupported clause kind")
        references = clause.get("receipts")
        _require(isinstance(references, list) and bool(references)
                 and all(isinstance(r, str) and r in by_id for r in references),
                 "clause has no actual observation or references unknown evidence")
        role = clause.get("role")
        _require(isinstance(role, str), "missing investigation role")
        roles.add(role)
        unresolved = clause.get("unresolved", False)
        _require(type(unresolved) is bool, "invalid uncertainty declaration")
        if phase == "challenge":
            _require(not unresolved, "final uncertainty cannot be marked complete")
    if phase == "investigate":
        _require({"reproduction", "legitimate"} <= roles,
                 "missing reproduction or legitimate-behavior investigation")
    if phase == "challenge":
        final_ids = phase_result.get("final_receipts")
        _require(isinstance(final_ids, list) and bool(final_ids), "missing final verification")
        for rid in final_ids:
            _require(isinstance(rid, str) and rid in by_id, "unknown final verification")
            final = by_id[rid]
            _require(final["source_digest"] == phase_result["source_digest"],
                     "final verification uses a different source")
            _require(final["exit_code"] == 0, "final public verification did not pass")
    out["used_receipts"] = used + list(by_id)
    out["phase"] = _NEXT[phase]
    out["source_digest"] = phase_result["source_digest"]
    return out
