"""Actual CLI + native Codescout + scripted zero-provider phase qualification."""
import importlib
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
try:
    native = importlib.import_module("qualify_native")
except ModuleNotFoundError as exc:
    if exc.name != "qualify_native":
        raise
    native = None

ENABLED = all(os.environ.get(k) for k in (
    "EFFORT_PROTOCOL_CLI", "EFFORT_PROTOCOL_NATIVE_IMAGE",
    "EFFORT_PROTOCOL_PLUGIN", "EFFORT_PROTOCOL_GLOBAL_RULES",
    "EFFORT_PROTOCOL_TEST_IMAGE", "EFFORT_PROTOCOL_RUNTIME_MANIFEST",
    "EFFORT_PROTOCOL_KNOWLEDGE"))

@unittest.skipUnless(ENABLED, "actual CLI qualification requires explicit frozen runtime paths")
class NativeQualificationTests(unittest.TestCase):
    def test_three_native_phases_zero_provider_and_context_bound(self):
        self.assertIsNotNone(native, "native phase qualification is not implemented")
        # Keep even a failed native control; automatic rmtree must not mask its error.
        tmp = Path(tempfile.mkdtemp(prefix="ep-native-qualification-", dir="/tmp"))
        result = native.qualify(tmp / "qualification", {
            "cli": os.environ["EFFORT_PROTOCOL_CLI"],
            "native_image": os.environ["EFFORT_PROTOCOL_NATIVE_IMAGE"],
            "plugin": os.environ["EFFORT_PROTOCOL_PLUGIN"],
            "global_rules": os.environ["EFFORT_PROTOCOL_GLOBAL_RULES"],
            "evidence_image": os.environ["EFFORT_PROTOCOL_TEST_IMAGE"],
            "runtime_manifest": os.environ["EFFORT_PROTOCOL_RUNTIME_MANIFEST"],
            "knowledge": os.environ["EFFORT_PROTOCOL_KNOWLEDGE"]})
        self.assertEqual(result["state"]["phase"], "closed")
        self.assertEqual(result["native_invocations"], 3)
        self.assertEqual(result["provider_forwarded"], 0)
        self.assertEqual(result["model_cost_usd"], "0")
        self.assertTrue(result["all_context_valid"])
        self.assertTrue(result["all_cleanup_complete"])
        self.assertEqual((Path(result["final_source"]) / "fixed.txt").read_text(), "1\n")
        import json
        for phase, count, prior_exit in (("repair", 1, 1), ("challenge", 2, 0)):
            cfg = json.loads((tmp / "qualification" / (phase + "-native") / "prepared.json").read_text())
            actual = json.loads((tmp / "qualification" / (phase + "-native") / "request-0.json").read_text())
            user_texts = []
            for message in actual["messages"]:
                if message.get("role") != "user":
                    continue
                blocks = message.get("content", [])
                if isinstance(blocks, str):
                    user_texts.append(blocks)
                elif isinstance(blocks, list):
                    user_texts.extend(b.get("text", "") for b in blocks if b.get("type") == "text")
            self.assertTrue(any(cfg["prompt"] in text for text in user_texts),
                            "prepared public artifact was absent from the actual model request")
            packet_text = cfg["prompt"].split("Frozen public packet:\n", 1)[1]
            packet = json.JSONDecoder().raw_decode(packet_text)[0]
            artifacts = packet["prior_public_artifacts"]
            self.assertEqual(len(artifacts), count)
            self.assertIn("observations", artifacts[-1])
            observed = artifacts[-1]["observations"][0]
            self.assertEqual(observed["exit_code"], prior_exit)
            self.assertIn("actual fixed value", observed["stdout"]["content"])
            self.assertTrue(artifacts[-1]["submission"]["clauses"])
            self.assertNotIn("cost_usd", json.dumps(artifacts))

    def test_native_continuation_control_has_no_protocol_submission(self):
        self.assertIsNotNone(native, "native qualification is not implemented")
        tmp = Path(tempfile.mkdtemp(prefix="ep-native-control-", dir="/tmp"))
        result = native.qualify(tmp / "qualification", {
            "arm": "R", "cli": os.environ["EFFORT_PROTOCOL_CLI"],
            "native_image": os.environ["EFFORT_PROTOCOL_NATIVE_IMAGE"],
            "plugin": os.environ["EFFORT_PROTOCOL_PLUGIN"],
            "global_rules": os.environ["EFFORT_PROTOCOL_GLOBAL_RULES"],
            "evidence_image": os.environ["EFFORT_PROTOCOL_TEST_IMAGE"],
            "runtime_manifest": os.environ["EFFORT_PROTOCOL_RUNTIME_MANIFEST"],
            "knowledge": os.environ["EFFORT_PROTOCOL_KNOWLEDGE"]})
        self.assertEqual(result.get("arm"), "R")
        self.assertEqual(result["state"]["phase"], "closed")
        self.assertEqual(result["native_invocations"], 3)
        self.assertEqual(result["provider_forwarded"], 0)
        self.assertEqual(result["model_cost_usd"], "0")
        self.assertTrue(result["all_context_valid"])
        self.assertTrue(result["all_cleanup_complete"])
        self.assertEqual((Path(result["final_source"]) / "fixed.txt").read_text(), "1\n")
        for phase in ("investigate", "repair", "challenge"):
            prepared = tmp / "qualification" / (phase + "-native")
            self.assertFalse((prepared / "actor/submission.json").exists())
            cfg = __import__("json").loads((prepared / "prepared.json").read_text())
            self.assertNotIn("submission.json", cfg["prompt"])

if __name__ == "__main__":
    unittest.main()
