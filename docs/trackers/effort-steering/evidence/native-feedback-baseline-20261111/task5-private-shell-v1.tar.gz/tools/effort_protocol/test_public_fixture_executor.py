"""Trusted fixture identity must survive command execution and receipt readback."""
import copy
import hashlib
import json
import os
from pathlib import Path
import socket
import tempfile
import unittest

import execution_profiles as profiles
import executor
import public_fixture as fixture
import receipts

IMAGE = os.environ.get("EFFORT_FIXTURE_TEST_IMAGE")


class FixtureExecutorTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="fixture-executor-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / "source"
        self.source.mkdir()
        (self.source / "source.txt").write_text("public production")
        (self.source / "probe.py").write_text("print('public probe')")
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        self.spec = {"version": "public-http-fixture-v1", "hostname": "fixture.sample.test",
                     "port": port, "routes": {"/": {
                         "status": 200, "content_type": "text/plain", "body": "public response"}}}
        self.desc = fixture.create_fixture_bundle(self.root / "fixture", self.spec)
        self.out = self.root / "commands"
        self.request = {
            "id": "one", "run_id": "run", "phase": "repair", "kind": "observation",
            "argv": ["python3", "-I", "/work/probe.py"], "cwd": ".",
            "test_files": ["probe.py"], "production_files": ["source.txt"],
            "image": IMAGE or "sha256:" + "a" * 64,
            "timeout_s": 15, "max_log_bytes": 1024 * 1024,
            "execution_profile": "fixture-public-v1", "public_fixture": self.desc}

    def test_frozen_old_profile_digests_and_new_explicit_profiles(self):
        for name, digest in {
            "fixture-v1": "bdb14292da261a564d7081dd10504524832e346e79026160c91b517878cc12ab",
            "cargo-v1": "847ebb408fd0debfc249345cd9a84d146fa53c6eecf8a4e5add1201a3259abb8",
            "cargo-v2": "65cd10638041fb90a31fac66b89d85e66aa30de08c64f8d7047d834fceab1a65",
        }.items():
            with self.subTest(name=name):
                self.assertEqual(profiles.profile_digest(name), digest)
        for name, base in (("fixture-public-v1", "fixture-v1"), ("cargo-public-v1", "cargo-v2")):
            profile = profiles.get_profile(name)
            self.assertEqual(profile.pop("public_fixture"), fixture.VERSION)
            self.assertEqual(profile, profiles.get_profile(base))

    def test_fixture_admission_rejects_missing_bad_and_old_profile_injection_before_effect(self):
        cases = []
        bad = copy.deepcopy(self.request); bad.pop("public_fixture"); cases.append(bad)
        bad = copy.deepcopy(self.request); bad["public_fixture"]["fingerprint"] = "0" * 64; cases.append(bad)
        bad = copy.deepcopy(self.request); bad["execution_profile"] = "fixture-v1"; cases.append(bad)
        for bad in cases:
            with self.subTest(bad=bad), self.assertRaises(executor.ExecutionInvalid):
                executor.execute_observation(bad, self.source, self.out)
            self.assertFalse(self.out.exists())

    @unittest.skipUnless(IMAGE, "set pinned Docker image for executor qualification")
    def test_actual_receipt_binds_expected_fixture_and_preserves_command_exit_78(self):
        self.request["argv"] = [
            "python3", "-I", "-c", "import urllib.request,sys;"
            f"print(urllib.request.urlopen('http://fixture.sample.test:{self.spec['port']}/').read().decode());"
            "sys.exit(78)"]
        facts = executor.execute_observation(self.request, self.source, self.out)
        self.assertEqual(facts["exit_code"], 78)
        self.assertEqual(facts["public_fixture"]["fingerprint"], self.desc["fingerprint"])
        directory = self.out / "one"
        self.assertEqual((directory / "stdout").read_bytes(), b"public response\n")
        record = json.loads((directory / "receipt.json").read_bytes())
        row = json.loads((directory / "container-before.json").read_bytes())
        self.assertEqual(row["Config"]["Cmd"], self.request["argv"])
        self.assertEqual(record["argv"], self.request["argv"])
        self.assertTrue(record["cleanup_complete"])
        self.assertEqual(receipts.verify_receipt(
            {"id": "one"}, self.out, directory / "input",
            expected_profile="fixture-public-v1", expected_fixture=self.desc), facts)
        with self.assertRaises(receipts.ReceiptViolation):
            receipts.verify_receipt({"id": "one"}, self.out, directory / "input")
        altered = copy.deepcopy(self.desc)
        altered["fingerprint"] = "0" * 64
        with self.assertRaises(receipts.ReceiptViolation):
            receipts.verify_receipt({"id": "one"}, self.out, directory / "input",
                                    expected_fixture=altered)
        # A substituted actual command must fail even with a refreshed raw hash.
        original_row = copy.deepcopy(row)
        row["Config"]["Cmd"] = ["python3", "-c", "print('different command')"]
        raw = (json.dumps(row) + "\n").encode()
        (directory / "container-before.json").write_bytes(raw)
        record["runtime_before_sha256"] = hashlib.sha256(raw).hexdigest()
        (directory / "receipt.json").write_text(json.dumps(record))
        with self.assertRaises(receipts.ReceiptViolation):
            receipts.verify_receipt({"id": "one"}, self.out, directory / "input",
                                    expected_fixture=self.desc)
        row = original_row
        # An updated raw-byte hash must not authenticate a wrong host alias.
        row["HostConfig"]["ExtraHosts"] = ["example.com:127.0.0.1"]
        raw = (json.dumps(row) + "\n").encode()
        (directory / "container-before.json").write_bytes(raw)
        record["runtime_before_sha256"] = hashlib.sha256(raw).hexdigest()
        (directory / "receipt.json").write_text(json.dumps(record))
        with self.assertRaises(receipts.ReceiptViolation):
            receipts.verify_receipt({"id": "one"}, self.out, directory / "input",
                                    expected_fixture=self.desc)

    @unittest.skipUnless(IMAGE, "set pinned Docker image for executor qualification")
    def test_launcher_failure_is_invalid_instead_of_a_functional_exit_78(self):
        self.request["argv"] = ["/missing-public-command"]
        with self.assertRaises(executor.ExecutionInvalid) as error:
            executor.execute_observation(self.request, self.source, self.out)
        self.assertEqual(error.exception.reason, "public_fixture_startup_failed")
        failure = json.loads((self.out / "one" / "failure.json").read_bytes())
        self.assertTrue(failure["cleanup_complete"])
        self.assertFalse((self.out / "one" / "receipt.json").exists())

    def original_exit_receipt(self):
        self.request["argv"] = ["python3", "-I", "-c",
                                "import os,sys;print(os.getcwd());sys.exit(78)"]
        facts = executor.execute_observation(self.request, self.source, self.out)
        self.assertEqual(facts["exit_code"], 78)
        self.assertEqual((self.out / "one/stdout").read_text(), "/work\n")
        directory = self.out / "one"
        return directory, json.loads((directory / "receipt.json").read_bytes())

    @unittest.skipUnless(IMAGE, "set pinned Docker image for executor qualification")
    def test_readback_rejects_changed_actual_workdir_with_refreshed_raw_hashes(self):
        directory, original = self.original_exit_receipt()
        raw_originals = {stage: (directory / ("container-" + stage + ".json")).read_bytes()
                         for stage in ("before", "after")}
        for stages in (("before",), ("after",), ("before", "after")):
            record = copy.deepcopy(original)
            for stage, raw in raw_originals.items():
                row = json.loads(raw)
                if stage in stages:
                    row["Config"]["WorkingDir"] = "/tmp"
                encoded = (json.dumps(row) + "\n").encode()
                (directory / ("container-" + stage + ".json")).write_bytes(encoded)
                record["runtime_" + stage + "_sha256"] = hashlib.sha256(encoded).hexdigest()
            (directory / "receipt.json").write_text(json.dumps(record))
            with self.subTest(stages=stages), self.assertRaises(receipts.ReceiptViolation):
                receipts.verify_receipt({"id": "one"}, self.out, directory / "input",
                                        expected_fixture=self.desc)

    @unittest.skipUnless(IMAGE, "set pinned Docker image for executor qualification")
    def test_readback_rejects_claimed_success_against_actual_exit_78(self):
        directory, record = self.original_exit_receipt()
        record["exit_code"] = 0
        (directory / "receipt.json").write_text(json.dumps(record))
        with self.assertRaises(receipts.ReceiptViolation):
            receipts.verify_receipt({"id": "one"}, self.out, directory / "input",
                                    expected_fixture=self.desc)

    @unittest.skipUnless(IMAGE, "set pinned Docker image for executor qualification")
    def test_readback_rejects_coherently_rehashed_unclosed_or_invalid_final_state(self):
        directory, original = self.original_exit_receipt()
        row = json.loads((directory / "container-after.json").read_bytes())
        original_state = copy.deepcopy(row["State"])
        for patch in ({"Status": "running", "Running": True}, {"OOMKilled": True},
                      {"Error": "runtime failed"}, {"ExitCode": 0}):
            row["State"] = dict(original_state, **patch)
            encoded = (json.dumps(row) + "\n").encode()
            (directory / "container-after.json").write_bytes(encoded)
            record = copy.deepcopy(original)
            record["runtime_after_sha256"] = hashlib.sha256(encoded).hexdigest()
            record["final_container_state"] = copy.deepcopy(row["State"])
            (directory / "receipt.json").write_text(json.dumps(record))
            with self.subTest(patch=patch), self.assertRaises(receipts.ReceiptViolation):
                receipts.verify_receipt({"id": "one"}, self.out, directory / "input",
                                        expected_fixture=self.desc)
        (directory / "container-after.json").write_text(json.dumps(dict(row, State=original_state)))
        restored_raw = (directory / "container-after.json").read_bytes()
        for attach in (1, True, None):
            record = copy.deepcopy(original)
            record["runtime_after_sha256"] = hashlib.sha256(restored_raw).hexdigest()
            record["docker_attach_exit"] = attach
            (directory / "receipt.json").write_text(json.dumps(record))
            with self.subTest(attach=attach), self.assertRaises(receipts.ReceiptViolation):
                receipts.verify_receipt({"id": "one"}, self.out, directory / "input",
                                        expected_fixture=self.desc)


if __name__ == "__main__":
    unittest.main()
