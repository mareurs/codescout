"""Behavioral contract for project-independent phase admission."""
import copy
import importlib
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
try:
    policy = importlib.import_module("policy")
except ModuleNotFoundError as exc:
    if exc.name != "policy":
        raise
    policy = None

A = "a" * 64
B = "b" * 64

class TransitionTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(policy, "generic phase policy is not implemented")
        self.state = {"run_id": "run", "phase": "investigate", "baseline_digest": A,
                      "used_receipts": [], "turns_used": 0}
        self.result = {"run_id": "run", "phase": "investigate", "source_digest": A,
                       "turns": 1, "status": "submitted", "clauses": [
                           {"id": "bug", "kind": "requirement", "role": "reproduction", "receipts": ["one"]},
                           {"id": "keep", "kind": "preservation", "role": "legitimate", "receipts": ["two"]}]}
        self.receipts = [{"id": name, "run_id": "run", "phase": "investigate",
                          "source_digest": A, "production_digest": A, "test_digest": B,
                          "complete": True, "resource_valid": True, "exit_code": code}
                         for name, code in [("one", 1), ("two", 0)]]

    def apply(self):
        return policy.validate_transition(self.state, self.result, self.receipts)

    def reject(self):
        with self.assertRaises(policy.ProtocolViolation):
            self.apply()

    def challenge(self):
        self.state["phase"] = self.result["phase"] = "challenge"
        self.state["turns_used"] = 6
        for r in self.receipts:
            r["phase"] = "challenge"
        self.result["final_receipts"] = ["two"]

    def test_valid_investigation_advances_without_mutating_inputs(self):
        before = copy.deepcopy((self.state, self.result, self.receipts))
        out = self.apply()
        self.assertEqual(out["phase"], "repair")
        self.assertEqual(out["turns_used"], 1)
        self.assertEqual(set(out["used_receipts"]), {"one", "two"})
        self.assertEqual((self.state, self.result, self.receipts), before)

    def test_wrong_phase_is_rejected(self):
        self.result["phase"] = "repair"
        self.reject()

    def test_receipts_cannot_come_from_another_run(self):
        self.receipts[0]["run_id"] = "other"
        self.reject()

    def test_receipts_cannot_come_from_another_phase(self):
        self.receipts[0]["phase"] = "repair"
        self.reject()

    def test_duplicate_receipt_ids_rejected(self):
        self.receipts[1]["id"] = "one"
        self.reject()

    def test_unknown_clause_receipt_rejected(self):
        self.result["clauses"][0]["receipts"] = ["absent"]
        self.reject()

    def test_replayed_receipt_rejected(self):
        self.state["used_receipts"] = ["one"]
        self.reject()

    def test_truncated_receipt_rejected(self):
        self.receipts[0]["complete"] = False
        self.reject()

    def test_infrastructure_fault_is_not_admitted(self):
        self.receipts[0]["resource_valid"] = False
        self.reject()

    def test_nonzero_functional_observation_is_permitted(self):
        self.assertEqual(self.apply()["phase"], "repair")

    def test_source_changes_during_investigation_rejected(self):
        self.receipts[0]["production_digest"] = B
        self.reject()

    def test_missing_legitimate_investigation_rejected(self):
        self.result["clauses"] = self.result["clauses"][:1]
        self.reject()

    def test_uncertainty_requires_an_observation(self):
        self.result["clauses"].append({"id": "unknown", "kind": "uncertainty",
                                       "role": "boundary", "receipts": []})
        self.reject()

    def test_duplicate_clause_ids_rejected(self):
        self.result["clauses"][1]["id"] = "bug"
        self.reject()

    def test_receipt_without_test_digest_rejected(self):
        del self.receipts[0]["test_digest"]
        self.reject()

    def test_missing_or_malformed_exit_is_not_an_observation(self):
        for value in (None, True, "0"):
            with self.subTest(value=value):
                self.receipts[0]["exit_code"] = value
                self.reject()

    def test_more_than_two_continuations_rejected(self):
        self.result["turns"] = 4
        self.reject()

    def test_boolean_turn_count_rejected(self):
        self.result["turns"] = True
        self.reject()

    def test_terminal_workflow_cannot_restart(self):
        self.state["phase"] = self.result["phase"] = "closed"
        self.reject()

    def test_final_verification_must_match_final_source(self):
        self.challenge()
        self.receipts[1]["source_digest"] = B
        self.reject()

    def test_final_verification_must_pass(self):
        self.challenge()
        self.receipts[1]["exit_code"] = 1
        self.reject()

    def test_missing_final_verification_rejected(self):
        self.challenge()
        self.result["final_receipts"] = []
        self.reject()

    def test_final_uncertainty_cannot_be_reported_complete(self):
        self.challenge()
        self.result["clauses"][0]["unresolved"] = True
        self.reject()

    def test_valid_finalization_closes(self):
        self.challenge()
        self.assertEqual(self.apply()["phase"], "closed")

    def test_budget_and_incomplete_remain_distinct_terminal_states(self):
        for status in ("incomplete", "budget_exhausted"):
            with self.subTest(status=status):
                self.result["status"] = status
                self.assertEqual(self.apply()["phase"], status)

    def test_actor_cannot_self_declare_infrastructure_invalidity(self):
        self.result["status"] = "measurement_invalid"
        self.reject()

    def test_opaque_project_identifier_does_not_change_policy(self):
        self.result["project_id"] = "arbitrary-public-project"
        self.assertEqual(self.apply()["phase"], "repair")

if __name__ == "__main__":
    unittest.main()
