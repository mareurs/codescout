"""Versioned preparation for the measured literal Cargo-test/report runner grammar.

This changes scheduling and makes test compilation observable before test payloads.
Expected names, assertions, selectors, reports and source patches are untouched.
"""
import copy
import re
import shlex
from pathlib import PurePosixPath

def prepare_record(original):
    if (not isinstance(original, dict) or not isinstance(original.get("test_cmds"), list)
            or not original["test_cmds"]):
        raise ValueError("literal Cargo test command inventory required")
    rebuild = original.get("rebuild_cmds")
    if rebuild is not None and (not isinstance(rebuild, list) or any(not isinstance(x, str) for x in rebuild)):
        raise ValueError("invalid original rebuild inventory")
    result = copy.deepcopy(original)
    result["rebuild_cmds"] = list(rebuild or [])
    prepared_tests = []
    for command in original["test_cmds"]:
        if not isinstance(command, str):
            raise ValueError("invalid test command")
        report = re.fullmatch(r"(?P<prefix>.+?)\s+2>&1\s*\|\s*tee\s+[A-Za-z0-9_./-]+\s*", command)
        if report is None:
            raise ValueError("unregistered test/report shell grammar")
        prefix = report["prefix"]
        if any(char in prefix for char in "|;&<>$\x60*?~\n\r"):
            raise ValueError("shell expansion or operators require a separate runner registration")
        try:
            words = shlex.split(prefix)
        except ValueError as exc:
            raise ValueError("invalid literal Cargo arguments") from exc
        if words[:2] != ["cargo", "test"]:
            raise ValueError("unregistered test runner")
        compile_words = words[:words.index("--")] if "--" in words else words
        if any(word in ("--no-run", "--doc") or word.startswith("--message-format") for word in compile_words[2:]):
            raise ValueError("test-only or structured diagnostic mode needs its own contract")
        result["rebuild_cmds"].append(shlex.join([*compile_words, "--no-run"]))
        if "--no-fail-fast" in compile_words[2:]:
            prepared_tests.append(command)
        else:
            marker = re.match(r"^\s*cargo\s+test(?=\s|$)", command)
            if marker is None:
                raise ValueError("literal Cargo prefix differs")
            prepared_tests.append(command[:marker.end()] + " --no-fail-fast" + command[marker.end():])
    result["test_cmds"] = prepared_tests
    return result
def _literal_shell_groups(command):
    if not isinstance(command,str) or not command.strip() or any(c in command for c in "$\x60*?~\n\r#"):
        raise ValueError("literal source shell command required")
    try:
        lexer=shlex.shlex(command,posix=True,punctuation_chars=";&")
        lexer.whitespace_split=True
        lexer.commenters=""
        tokens=list(lexer)
    except ValueError as exc:
        raise ValueError("invalid source shell quoting") from exc
    groups=[];current=[]
    for token in tokens:
        if token in (";","&&"):
            if not current:raise ValueError("empty source shell command")
            groups.append(current);current=[]
        elif any(c in token for c in ";&|<>"):
            raise ValueError("unsupported source shell operator")
        else:current.append(token)
    if not current:raise ValueError("empty source shell suffix")
    groups.append(current)
    return groups


def _literal_cargo(words,verbs):
    words=list(words)
    if words and words[0]=="env":words=words[1:]
    environment=[];names=set()
    while words and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*=.*",words[0]):
        assignment=words.pop(0);name=assignment.split("=",1)[0]
        if name in names:raise ValueError("repeated source environment")
        names.add(name);environment.append(assignment)
    if len(words)<2 or words[0]!="cargo" or words[1] not in verbs:
        raise ValueError("unsupported source Cargo command")
    return environment,words


def _cargo_shell(environment,words):
    return shlex.join((["env",*environment] if environment else [])+words)


def prepare_shell_record(original,*,image,bootstrap=None):
    """Preserve literal source selection/env while making offline test compilation observable."""
    if (not isinstance(original,dict) or not isinstance(original.get("test_cmds"),list)
            or not original["test_cmds"] or not isinstance(image,str)
            or re.fullmatch(r"sha256:[0-9a-f]{64}",image) is None):
        raise ValueError("source shell record and immutable image required")
    rebuild=original.get("rebuild_cmds")
    if rebuild is not None and not isinstance(rebuild,list):
        raise ValueError("literal rebuild inventory required")
    prepared=copy.deepcopy(original)
    rebuilt=[];setup=[];packages=set()
    for command in rebuild or []:
        seen_cargo=False
        for group in _literal_shell_groups(command):
            if seen_cargo:raise ValueError("rebuild commands after Cargo require a separate contract")
            if group==["cd","/testbed"]:continue
            if group==["apt-get","update","-qq"]:
                setup.append(shlex.join(group));continue
            if group[:2]==["apt-get","install"]:
                flags=[];index=2
                while index<len(group) and group[index].startswith("-"):
                    flags.append(group[index]);index+=1
                names=group[index:]
                if (set(flags)!={"-y","-qq"} or len(flags)!=2 or not names
                        or any(re.fullmatch(r"[a-z0-9][a-z0-9+.-]*",name) is None for name in names)):
                    raise ValueError("unsupported declared package bootstrap")
                packages.update(names);setup.append(shlex.join(group));continue
            environment,words=_literal_cargo(group,{"build","check"})
            rebuilt.append(_cargo_shell(environment,words));seen_cargo=True
    if setup:
        if (not isinstance(bootstrap,dict) or set(bootstrap)!={"image","apt_packages"}
                or bootstrap["image"]!=image or not isinstance(bootstrap["apt_packages"],dict)
                or any(not isinstance(k,str) or not isinstance(v,str) or not v.strip()
                       for k,v in bootstrap["apt_packages"].items())
                or not packages<=set(bootstrap["apt_packages"])):
            raise ValueError("declared package setup needs matching installed-image version evidence")
    elif bootstrap is not None:
        raise ValueError("unexpected package bootstrap evidence")
    tests=[];prefixes=[];environments=[]
    for command in original["test_cmds"]:
        if not isinstance(command,str):raise ValueError("literal test command required")
        report=re.fullmatch(r"(?P<prefix>.+?)(?:\s+2>&1\s*\|\s*tee\s+(?P<tee>[A-Za-z0-9_./-]+)|\s*>\s*(?P<redirect>[A-Za-z0-9_./-]+)\s+2>&1)\s*",command)
        if report is None:raise ValueError("unsupported merged source report transport")
        name=report["tee"] or report["redirect"]
        relative=PurePosixPath(name)
        if relative.is_absolute() or not relative.parts or ".." in relative.parts or relative.as_posix()!=name or name==".":
            raise ValueError("source report must be a canonical relative path")
        groups=_literal_shell_groups(report["prefix"])
        if any(group not in (["cd","/testbed"],["mkdir","-p","reports"]) for group in groups[:-1]):
            raise ValueError("unsupported test setup prefix")
        environment,words=_literal_cargo(groups[-1],{"test"})
        compilation=words[:words.index("--")] if "--" in words else words
        if any(word in ("--doc","--no-run") or word.startswith("--message-format") for word in compilation[2:]):
            raise ValueError("separate test runner contract required")
        if compilation.count("--no-fail-fast")>1:
            raise ValueError("repeated test scheduling flag")
        prefixes.append(_cargo_shell(environment,[*compilation,"--no-run"]))
        scheduled=words if "--no-fail-fast" in compilation else [*words[:2],"--no-fail-fast",*words[2:]]
        transport=(" 2>&1 | tee "+name) if report["tee"] else (" > "+name+" 2>&1")
        tests.append(_cargo_shell(environment,scheduled)+transport)
        environments.append(list(environment))
    prepared["test_cmds"]=tests
    prepared["rebuild_cmds"]=[*rebuilt,*prefixes]
    return {"schema":"source-shell-command-preparation-v1","record":prepared,
            "image":image,"bootstrap":copy.deepcopy(bootstrap),
            "declared_apt_packages":sorted(packages),"removed_setup_commands":setup,
            "compiler_prefixes":prefixes,"test_environments":environments}
