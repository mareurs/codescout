"""Prospective bounded CodeRank relay profile; validation makes no model call.

This verifies a registered live embedding boundary, not source admission,
transitive-runtime custody, model context delivery, or repair quality.
"""
import hashlib
import ipaddress
import json
import pathlib
import re
import subprocess

RELAY_SHA256 = "16ceb890a5c341f8698251c35d486ab09dc70946ece621f316feddc2850e1839"
PROFILE_KEYS = {"version", "owner", "network_id", "relay_id", "service_id", "service_image",
                "service_started_at", "upstream_network", "upstream_network_id", "service_ip", "relay_script", "relay_sha256"}


def _require(condition, message):
    if not condition:
        raise ValueError("embedding runtime profile: " + message)


def _inspect(kind, identity):
    run = subprocess.run(["docker", kind, "inspect", identity], capture_output=True, text=True, timeout=20)
    _require(run.returncode == 0, "registered live object unavailable")
    rows = json.loads(run.stdout)
    _require(isinstance(rows, list) and len(rows) == 1, "ambiguous live object")
    return rows[0]


def validate_embedding_profile(profile, options, image, *, inspect=None):
    """Fail before launch when the registered embedding-only topology has drifted."""
    try:
        return _validate(profile, options, image, inspect or _inspect)
    except (KeyError, TypeError, AttributeError, OSError, subprocess.TimeoutExpired) as exc:
        raise ValueError("embedding runtime profile: incomplete or unavailable evidence") from exc


def _validate(profile, options, image, inspect):
    _require(isinstance(profile, dict) and set(profile) == PROFILE_KEYS, "unknown or incomplete declaration")
    _require(profile["version"] == "embedding-relay-v1", "unsupported version")
    _require(isinstance(profile["owner"], str) and re.fullmatch(r"ep-relay-[0-9a-f]{32}", profile["owner"]), "unregistered owner")
    for key in ("network_id", "relay_id", "service_id", "upstream_network_id"):
        _require(isinstance(profile[key], str) and re.fullmatch(r"[0-9a-f]{64}", profile[key]), "immutable object id missing")
    _require(isinstance(profile["service_image"], str) and re.fullmatch(r"sha256:[0-9a-f]{64}", profile["service_image"]), "immutable service image missing")
    _require(isinstance(profile["service_started_at"], str) and profile["service_started_at"], "service incarnation missing")
    _require(profile["upstream_network"] == "codescout-retrieval_retrieval_net", "unregistered embedding upstream")
    address = ipaddress.IPv4Address(profile["service_ip"])
    _require(str(address) == profile["service_ip"] and not address.is_loopback and not address.is_unspecified, "invalid service address")
    script = pathlib.Path(profile["relay_script"])
    _require(script.is_absolute() and not script.is_symlink() and script.is_file(), "relay must be a regular absolute file")
    _require(profile["relay_sha256"] == RELAY_SHA256 and hashlib.sha256(script.read_bytes()).hexdigest() == RELAY_SHA256, "relay source changed")
    net_id, relay_id, service_id = (profile[key] for key in ("network_id", "relay_id", "service_id"))
    for key, value in {
        "--network": [net_id], "--tmpfs": ["/tmp:rw,exec,size=16g,uid=1000,gid=1000"],
        "--read-only": [True], "--cap-drop": ["ALL"], "--security-opt": ["no-new-privileges"],
    }.items():
        _require(options.get(key) == value, "actor boundary changed: " + key)
    network = inspect("network", net_id)
    _require(network["Id"] == net_id and network["Internal"] is True, "network is not the registered internal network")
    _require(network["Labels"].get("codescout.hfa") == profile["owner"], "network ownership changed")
    _require(set(network["Containers"]) == {relay_id}, "private network contains unexpected members")
    relay = inspect("container", relay_id)
    _require(relay["Id"] == relay_id and relay["Image"] == image and relay["State"]["Running"] is True, "relay identity or process changed")
    config, host = relay["Config"], relay["HostConfig"]
    _require(config["Labels"].get("codescout.hfa") == profile["owner"], "relay ownership changed")
    _require(config["User"] == "1000:1000" and config["Entrypoint"] == ["python3"], "relay execution identity changed")
    _require(config["Cmd"] == ["-I", "-B", "/relay.py", "--upstream",
        f"http://{address}:8080/v1/embeddings", "--model", "CodeRankEmbed", "--dimensions", "768"], "relay endpoint or executable changed")
    _require(host["ReadonlyRootfs"] is True and host["Privileged"] is False, "relay root permissions changed")
    _require(host["CapDrop"] == ["ALL"] and not host.get("CapAdd") and host["SecurityOpt"] == ["no-new-privileges"], "relay capabilities changed")
    for key, value in {"Memory": 536870912, "MemorySwap": 536870912, "NanoCpus": 1000000000, "PidsLimit": 64}.items():
        _require(host[key] == value, "relay resource boundary changed: " + key)
    _require(not host.get("PortBindings") and not host.get("Devices"), "relay exposes host resources")
    _require(host.get("Tmpfs") == {"/mnt_tmp": "ro,noexec,nosuid,nodev,size=1m"}, "relay temporary mount boundary changed")
    _require(all(not host.get(key) for key in ("ExtraHosts", "Dns", "DnsSearch", "DnsOptions")), "relay resolution override prohibited")
    mounts = relay["Mounts"]
    _require(len(mounts) == 1 and mounts[0]["Type"] == "bind" and mounts[0]["Source"] == str(script)
        and mounts[0]["Destination"] == "/relay.py" and mounts[0]["RW"] is False, "relay mount boundary changed")
    networks = relay["NetworkSettings"]["Networks"]
    private = [row for row in networks.values() if row["NetworkID"] == net_id]
    upstream = profile["upstream_network"]
    _require(len(networks) == 2 and len(private) == 1 and upstream in networks
        and "source-embeddings" in (private[0].get("Aliases") or []), "relay network boundary changed")
    _require(all(not value for value in relay["NetworkSettings"]["Ports"].values()), "relay host port published")
    service = inspect("container", service_id)
    _require(service["Id"] == service_id and service["Image"] == profile["service_image"]
        and service["State"]["Running"] is True and service["State"]["StartedAt"] == profile["service_started_at"], "embedding service identity or incarnation changed")
    service_network = service["NetworkSettings"]["Networks"][upstream]
    _require(service_network["NetworkID"] == profile["upstream_network_id"]
        and networks[upstream]["NetworkID"] == profile["upstream_network_id"]
        and service_network["IPAddress"] == str(address), "embedding upstream network or address changed")
    return {"network_id": net_id, "profile_version": "embedding-relay-v1"}
