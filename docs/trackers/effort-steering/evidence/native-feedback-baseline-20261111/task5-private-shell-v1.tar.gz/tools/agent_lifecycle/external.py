"""Prepared external task entry; admission and shared-knowledge assembly stay controller-owned."""
import hashlib
import importlib.util
import json
import pathlib
import re
import stat
import os
import tempfile
import uuid
from decimal import Decimal
from types import SimpleNamespace

from qualify import worker
import transport
import workflow
from artifacts import capture_patch
from core import amount
from embedding_profile import validate_embedding_profile

# Load the standalone shared contract without changing global module search order.
_fixture_spec = importlib.util.spec_from_file_location(
    "lifecycle_public_fixture", pathlib.Path(__file__).resolve().parents[1] / "effort_protocol/public_fixture.py")
public_fixture = importlib.util.module_from_spec(_fixture_spec)
_fixture_spec.loader.exec_module(public_fixture)


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def validate_context_path(path):
    """Admit only physical scratch paths without inherited project or user context."""
    raw = pathlib.Path(path).absolute()
    resolved = raw.resolve(strict=True)
    bases = (pathlib.Path("/tmp"), pathlib.Path("/var/tmp"))
    base = next((value for value in bases if resolved != value and value in resolved.parents), None)
    if base is None or resolved != raw:
        raise ValueError("external CLI context must have isolated physical scratch ancestry")
    for parent in resolved.parents:
        if any((parent / name).exists() or (parent / name).is_symlink()
               for name in ("CLAUDE.md", "AGENTS.md", ".git", ".claude", "Cargo.toml")):
            raise ValueError("external CLI context has inherited rules or workspace ancestry")
        if parent == base:
            break
    if resolved.stat().st_uid != os.getuid():
        raise ValueError("external CLI context is not owned scratch")
    return resolved

def context_preload(cfg, actor):
    """Reconstruct the bound append-only system input before any credential read."""
    if "context_preload" not in cfg:
        return None
    descriptor=cfg["context_preload"]
    if not isinstance(descriptor,dict) or set(descriptor)!={"path","system_path","skill_path","files"}:
        raise ValueError("invalid prepared context descriptor")
    body_path=pathlib.Path(descriptor["path"])
    system=pathlib.Path(descriptor["system_path"])
    skill=pathlib.Path(descriptor["skill_path"])
    target=actor/".codescout/prepared-context/reconnaissance"
    if system!=actor/".codescout/system-prompt.md" or skill!=target/"SKILL.md":
        raise ValueError("prepared context must name the actor's frozen onboarding and skill")
    paths=[body_path,system,*target.rglob("*")]
    if any(p.is_symlink() or not(p.is_file() or p.is_dir()) for p in paths):
        raise ValueError("physical prepared context required")
    files={str(p) for p in paths if p.is_file()}
    if files!=set(descriptor["files"]):
        raise ValueError("prepared context file coverage differs")
    for name,digest in descriptor["files"].items():
        p=pathlib.Path(name)
        if (any(parent.is_symlink() for parent in p.parents) or cfg["files"].get(name)!=digest
                or hashlib.sha256(p.read_bytes()).hexdigest()!=digest):
            raise ValueError("prepared context hash coverage differs")
    if not system.read_text().strip() or not skill.read_text().strip():
        raise ValueError("nonempty prepared context required")
    expected=("<prepared-context>\n<codescout-onboarding>\n"+system.read_text()+
              "\n</codescout-onboarding>\n<reconnaissance-instructions>\n"
              "Supporting files: .codescout/prepared-context/reconnaissance\n"+
              skill.read_text()+"\n</reconnaissance-instructions>\n</prepared-context>\n")
    body=body_path.read_text()
    if body!=expected:
        raise ValueError("prepared context body differs from frozen inputs")
    return body

def _public_build_helper(cfg):
    """Load the hash-bound standalone helper only for the registered new profile."""
    fields = {"public_build_inputs", "public_build_stage", "public_build_inputs_helper"}
    selected = fields.intersection(cfg)
    if not selected and cfg.get("execution_profile") != "cargo-v3":
        return None
    if selected != fields or cfg.get("execution_profile") != "cargo-v3":
        raise ValueError("external public build contract incomplete or profile differs")
    name = cfg["public_build_inputs_helper"]
    if not isinstance(name, str):
        raise ValueError("external public build helper path missing")
    path = pathlib.Path(name)
    if (not path.is_absolute() or path.resolve(strict=True) != path
            or path.is_symlink() or not path.is_file()):
        raise ValueError("external public build helper must be a physical frozen file")
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if cfg.get("files", {}).get(str(path)) != digest:
        raise ValueError("external public build helper hash missing or changed")
    spec = importlib.util.spec_from_file_location("lifecycle_public_build_inputs_" + digest, path)
    helper = importlib.util.module_from_spec(spec)
    # Execute the exact bytes just checked, without adding their directory to sys.path.
    exec(compile(data, str(path), "exec"), helper.__dict__)
    return helper

def public_build_contract(cfg, options, actor):
    helper = _public_build_helper(cfg)
    if helper is None:
        return None
    return helper.validate_native_options(options, cfg["public_build_inputs"], cfg["public_build_stage"],
                                          actor, cfg["image"])


def public_build_runtime(cfg, row, actor):
    helper = _public_build_helper(cfg)
    if helper is None:
        return None
    return helper.validate_native_runtime(row, cfg["public_build_inputs"], cfg["public_build_stage"],
                                          actor, cfg["image"])


def validate_prepared(out, effort, allowance, cli_cap):
    out = pathlib.Path(out)
    cfg = json.loads((out / "prepared.json").read_text())
    balance, cap = amount(allowance), amount(cli_cap if cli_cap is not None else allowance)
    if effort not in ("low", "high", "xhigh") or not 0 < cap <= balance:
        raise ValueError("invalid external effort or budget")
    if not re.fullmatch(r"sha256:[0-9a-f]{64}", cfg["image"]):
        raise ValueError("external image must be immutable")
    if not re.fullmatch(r"[0-9a-f]{40}", cfg["baseline_commit"]):
        raise ValueError("external source baseline must be immutable")
    actor = validate_context_path(cfg["actor"])
    context_preload(cfg, actor)
    required = {str(out / "mcp-native-argv.json"), cfg["global_rules"], cfg["cli"],
                str(actor / "CLAUDE.md")}
    if "public_fixture" in cfg:
        public_fixture.read_fixture_bundle(cfg["public_fixture"])
        required |= {str(path) for path in pathlib.Path(cfg["public_fixture"]["root"]).iterdir()}
    if not required <= cfg["files"].keys():
        raise ValueError("external required input hashes missing")
    for name, expected in cfg["files"].items():
        path = pathlib.Path(name)
        if path.is_symlink() or not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError("external input drift: " + name)
    native = json.loads((out / "mcp-native-argv.json").read_text())
    if native[:2] != ["docker", "run"] or native[-4:] != [cfg["image"], "start", "--project", "/testbed"]:
        raise ValueError("unexpected external native boundary")
    options = {}
    valued = {"--pull", "--network", "--user", "--cpus", "--memory", "--memory-swap",
              "--pids-limit", "--name", "--label", "--tmpfs", "--mount", "--workdir",
              "--entrypoint", "-e", "--env"}
    if "public_fixture" in cfg:
        valued.add("--add-host")
    repeated = {"--mount", "-e", "--env"}
    flags = {"--init", "-i"}
    if "embedding_profile" in cfg:
        valued |= {"--cap-drop", "--security-opt"}
        flags.add("--read-only")
    args = native[2:-4]
    index = 0
    while index < len(args):
        raw = args[index]
        option, equals, value = raw.partition("=")
        if option in flags and not equals:
            value = True
        elif option in valued:
            if not equals:
                index += 1
                if index >= len(args) or args[index].startswith("-"):
                    raise ValueError("missing external native option value " + option)
                value = args[index]
            if not value:
                raise ValueError("empty external native option " + option)
        else:
            raise ValueError("unsupported external native option " + raw)
        if option in options and option not in repeated:
            raise ValueError("duplicate external native option " + option)
        options.setdefault(option, []).append(value)
        index += 1
    public_build_contract(cfg, options, actor)
    if "public_fixture" in cfg:
        public_fixture.validate_fixture_options(options, cfg["public_fixture"], "native", actor=actor)
    if "embedding_profile" in cfg:
        validate_embedding_profile(cfg["embedding_profile"], options, cfg["image"])
    else:
        if options.get("--network") != ["none"]:
            raise ValueError("unexpected external native option --network")
        if options.get("--tmpfs") != ["/tmp:rw,exec,size=4g,uid=1000,gid=1000"]:
            raise ValueError("unexpected external native temporary storage")
    for option, expected in [("--user", "1000:1000"),
                             ("--cpus", "4"), ("--memory", "32g"), ("--pids-limit", "4096")]:
        if options.get(option) != [expected]:
            raise ValueError("unexpected external native option " + option)
    if options.get("--memory-swap", ["32g"]) != ["32g"]:
        raise ValueError("unexpected external native swap limit")
    if options.get("--pull", ["never"]) != ["never"]:
        raise ValueError("external native image pull prohibited")
    if options.get("--init") != [True] or "--name" not in options or "--label" not in options:
        raise ValueError("external native identity/init missing")
    config = workflow.validate_config({"checks": cfg["checks"], "timeout_s": cfg.get("timeout_s", 3600),
        "check_timeout_s": cfg.get("check_timeout_s", 1800), "max_continuations": cfg.get("max_continuations", 8)})
    if not isinstance(cfg["prompt"], str) or not cfg["prompt"].strip():
        raise ValueError("external public prompt missing")
    return cfg, config, actor, balance, cap


def launch(out, *, effort, allowance, cli_cap=None, scripted_plan=None,
           token_path=pathlib.Path("/home/marius/.config/s5/token-claude-stef"), supervisor=None):
    out = pathlib.Path(out).resolve()
    cfg, config, actor, balance, cap = validate_prepared(out, effort, allowance, cli_cap)
    temporary_base = "/var/tmp" if actor.is_relative_to("/var/tmp") else "/tmp"
    client_temporary = pathlib.Path(tempfile.mkdtemp(prefix="ep-cli-", dir=temporary_base))
    scripted = scripted_plan is not None
    with (out / "started.json").open("x") as marker:
        json.dump({"prepared_sha256": hashlib.sha256((out / "prepared.json").read_bytes()).hexdigest(),
                   "scripted": scripted, "effort": effort, "allowance_usd": str(balance)}, marker)
    home = out / "client-home"; client_config = home / ".claude"; client_config.mkdir(parents=True)
    global_md = pathlib.Path(cfg["global_rules"]).read_text()
    project_md = (actor / "CLAUDE.md").read_text()
    (client_config / "CLAUDE.md").write_text(global_md)
    expected = {"effort": effort, "clause": worker.CLAUSE,
        "declaration": worker.CLAUSE in global_md + "\n" + project_md,
        "global_visible": worker.visible(global_md), "project_visible": worker.visible(project_md)}
    preload = context_preload(cfg, actor)
    if preload is not None:
        expected["preload_visible"] = worker.visible(preload)
    save(out / "expected.json", expected)
    stdio = pathlib.Path(__file__).with_name("native_stdio.py")
    save(out / "mcp.json", {"mcpServers": {"codescout": {"command": "/usr/bin/python3",
        "args": ["-B", str(stdio), str(out)]}}})
    allowed = ["Skill", "ToolSearch", "mcp__codescout__*"]
    save(out / "settings.json", {"permissions": {"allow": allowed}})
    hook = out / "hook"; hook.mkdir()
    sid = str(uuid.uuid4())
    argv = [cfg["cli"], "-p", "--model", "claude-sonnet-5-5", "--effort", effort, "--session-id", sid,
        "--setting-sources", "user,project,local", "--settings", str(out / "settings.json"),
        "--strict-mcp-config", "--mcp-config", str(out / "mcp.json"), "--permission-mode", "acceptEdits",
        "--tools", "Skill,ToolSearch", "--allowedTools", ",".join(allowed), "--output-format", "json",
        "--max-budget-usd", str(cap), "--plugin-dir", cfg["plugin"], "--", cfg["prompt"]]
    if preload is not None:
        argv[-2:-2] = ["--append-system-prompt", preload]
    env = {"HOME": str(home), "USER": "marius", "LANG": "C.UTF-8", "PATH": "/usr/local/bin:/usr/bin:/bin",
        "CLAUDE_CONFIG_DIR": str(client_config), "DISABLE_AUTOUPDATER": "1",
        "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC": "1", "CLAUDE_CODE_MAX_OUTPUT_TOKENS": "8192",
        "PYTHONDONTWRITEBYTECODE": "1", "MCP_PROTOCOL_NEGOTIATION": "legacy",
        "TMPDIR": str(client_temporary)}
    if scripted:
        env["ANTHROPIC_API_KEY"] = "scripted-no-real-credential"
    else:
        info = token_path.stat()
        if not stat.S_ISREG(info.st_mode) or info.st_mode & 0o077:
            raise ValueError("credential permissions invalid")
        env["CLAUDE_CODE_OAUTH_TOKEN"] = token_path.read_text().strip()
    server = transport.server(out, expected, scripted, scripted_plan or [], campaign_remaining=balance)
    env["ANTHROPIC_BASE_URL"] = "http://127.0.0.1:" + str(server.server_port)
    save(out / "launch.json", {"argv": argv, "session_id": sid, "scripted": scripted,
        "real_credentials_read": not scripted, "source_image": cfg["image"],
        "mcp_protocol_negotiation": env["MCP_PROTOCOL_NEGOTIATION"],
        "client_temporary": str(client_temporary),
        **({"context_preload_sha256": hashlib.sha256(preload.encode()).hexdigest()} if preload is not None else {}),
        "native_stdio_sha256": hashlib.sha256(stdio.read_bytes()).hexdigest(),
        "hook_set": "Pinned companion skills plus lifecycle observer; no task-specific hint hook"})
    runtime = SimpleNamespace(IMAGE=cfg["image"], save=save,
        extract_result=worker.extract_result, audit_hooks=worker.audit_hooks)
    try:
        receipt = workflow.execute(runtime, config, out, actor, argv, env, server, sid, hook, balance,
            capture_artifacts=lambda: capture_patch(out, cfg["image"], cfg["baseline_commit"]),
            supervisor=supervisor)
    finally:
        server.shutdown(); server.server_close()
    receipt["context_valid"] = bool(server.requests) and not server.errors
    receipt["workflow_completed"] = receipt["workflow_completed"] and receipt["context_valid"]
    save(out / "receipt.json", receipt)
    return receipt
