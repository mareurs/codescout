"""Native Docker boundary tests; replace only the external Docker invocation."""
import json
import pathlib
import subprocess
import tempfile
import unittest
from unittest.mock import patch
import qualify


class OwnerTests(unittest.TestCase):
    def test_probe_connection_is_not_assumed_to_own_the_job(self):
        with tempfile.TemporaryDirectory() as temp:
            out=pathlib.Path(temp)
            for name in ("probe","owner"):
                (out/("mcp-launch-"+name+".json")).write_text(json.dumps({"name":name}))
            path="/tmp/codescout-bg/1-abcd-bg_00000001.json"
            record={"schema":1,"handle":"@bg_00000001","state":"running","exit_code":None}
            def docker(argv,**kwargs):
                name=argv[2]
                if argv[1]=="inspect":
                    return subprocess.CompletedProcess(argv,0,json.dumps([{"Id":name+"-id","Image":qualify.worker.IMAGE,
                        "Config":{"Labels":{"codescout.hfa":name}}}]),"")
                if name=="owner-id":
                    return subprocess.CompletedProcess(argv,0,json.dumps(record),"")
                return subprocess.CompletedProcess(argv,1,"","not found")
            with patch.object(qualify.subprocess,"run",side_effect=docker):
                self.assertEqual(qualify.native_record(out,path),record)
                self.assertEqual(json.loads((out/"record-owner.json").read_text()),
                    {"name":"owner","container_id":"owner-id"})
                record["state"]="exited";record["exit_code"]=0
                self.assertEqual(qualify.native_record(out,path)["exit_code"],0)
            rows=[json.loads(line) for line in (out/"record-observations.jsonl").read_text().splitlines()]
            self.assertEqual([r["container"] for r in rows],["owner","owner"])
            self.assertEqual([r["container_id"] for r in rows],["owner-id","owner-id"])

    def test_replacement_with_same_name_image_label_is_rejected_before_read(self):
        with tempfile.TemporaryDirectory() as temp:
            out=pathlib.Path(temp)
            (out/"record-owner.json").write_text(json.dumps({"name":"owner","container_id":"original-id"}))
            calls=[]
            def docker(argv,**kwargs):
                calls.append(argv)
                if argv[1]=="inspect":
                    return subprocess.CompletedProcess(argv,0,json.dumps([{"Id":"replacement-id","Image":qualify.worker.IMAGE,
                        "Config":{"Labels":{"codescout.hfa":"owner"}}}]),"")
                return subprocess.CompletedProcess(argv,0,json.dumps({"state":"exited","exit_code":0}),"")
            with patch.object(qualify.subprocess,"run",side_effect=docker):
                with self.assertRaises(ValueError):
                    qualify.native_record(out,"/tmp/codescout-bg/1-abcd-bg_00000001.json")
            self.assertFalse(any(argv[1]=="exec" for argv in calls))

    def test_name_only_existing_pin_cannot_be_silently_upgraded(self):
        with tempfile.TemporaryDirectory() as temp:
            out=pathlib.Path(temp)
            (out/"record-owner.json").write_text(json.dumps({"name":"owner"}))
            with patch.object(qualify.subprocess,"run",side_effect=AssertionError("must reject before Docker")):
                with self.assertRaises(ValueError):
                    qualify.native_record(out,"/tmp/codescout-bg/1-abcd-bg_00000001.json")
class CleanupTests(unittest.TestCase):
    def test_failed_remove_is_ok_only_when_exact_owned_container_is_absent(self):
        with tempfile.TemporaryDirectory() as temp:
            out=pathlib.Path(temp)
            (out/"mcp-launch-owned.json").write_text(json.dumps({"name":"owned"}))
            for absent in (True,False):
                calls=0
                def docker(argv,**kwargs):
                    nonlocal calls
                    if argv[1]=="rm":
                        return subprocess.CompletedProcess(argv,1,"","already removing")
                    calls+=1
                    if calls>1 and absent:
                        return subprocess.CompletedProcess(argv,1,"","Error: No such object: owned")
                    return subprocess.CompletedProcess(argv,0,json.dumps([{
                        "Id":"exact-id","Image":qualify.worker.IMAGE,"Config":{"Labels":{"codescout.hfa":"owned"}}}]),"")
                with self.subTest(absent=absent),patch.object(qualify.subprocess,"run",side_effect=docker):
                    if absent:
                        self.assertEqual(qualify.cleanup_owned(out,timeout_s=.02),[{"name":"owned","absent":True,"remove_exit_code":1}])
                    else:
                        with self.assertRaisesRegex(ValueError,"container remains"):
                            qualify.cleanup_owned(out,timeout_s=.02)


class CleanupPinTests(unittest.TestCase):
    def test_replacement_of_pinned_background_owner_is_never_removed(self):
        with tempfile.TemporaryDirectory() as temp:
            out=pathlib.Path(temp)
            (out/"mcp-launch-owner.json").write_text(json.dumps({"name":"owner"}))
            (out/"record-owner.json").write_text(json.dumps({"name":"owner","container_id":"original-id"}))
            calls=[]
            def docker(argv,**kwargs):
                calls.append(argv)
                if argv[1]=="rm":
                    return subprocess.CompletedProcess(argv,0,"","")
                return subprocess.CompletedProcess(argv,0,json.dumps([{"Id":"replacement-id",
                    "Image":qualify.worker.IMAGE,"Config":{"Labels":{"codescout.hfa":"owner"}}}]),"")
            with patch.object(qualify.subprocess,"run",side_effect=docker):
                with self.assertRaises(ValueError):
                    qualify.cleanup_owned(out,timeout_s=0)
            self.assertFalse(any(argv[1]=="rm" for argv in calls))


if __name__=="__main__":unittest.main()
