"""Actual JSON envelopes must preserve record failures across text decoding."""
import json
import pathlib
import subprocess
import sys
import tempfile
import unittest
from session import background_launches


class ObserverTests(unittest.TestCase):
    def test_native_text_record_failure_is_not_swallowed(self):
        value={"content":[{"type":"text","text":json.dumps({
            "output_id":"@bg_00000001","record_error":"disk full"})}]}
        with self.assertRaisesRegex(ValueError,"completion record unavailable"):
            list(background_launches(value))

    def test_observer_captures_atomic_native_hook_receipt(self):
        with tempfile.TemporaryDirectory() as temp:
            root=pathlib.Path(temp)
            data={"tool_name":"mcp__codescout__run_command","tool_response":{
                "content":[{"type":"text","text":json.dumps({
                    "output_id":"@bg_00000001","record":"/tmp/codescout-bg/1-a-bg_00000001.json"})}]}}
            result=subprocess.run([sys.executable,str(pathlib.Path(__file__).with_name("observer.py"))],
                input=json.dumps(data),text=True,capture_output=True,
                env={"AGENT_LIFECYCLE_OBSERVATIONS":str(root)},check=True)
            self.assertEqual(json.loads(result.stdout),{})
            files=list(root.iterdir())
            self.assertEqual(len(files),1)
            self.assertEqual(files[0].suffix,".json")
            self.assertEqual(json.loads(files[0].read_text()),data)
            self.assertEqual(list(background_launches(data["tool_response"])),
                [("@bg_00000001","/tmp/codescout-bg/1-a-bg_00000001.json")])
class RecordGuardTests(unittest.TestCase):
    def test_schema_is_required_before_interpreting_terminal_status(self):
        from session import validate_record
        with self.assertRaises(ValueError):
            validate_record({"schema":99,"handle":"@bg_00000001","state":"exited","exit_code":0},"@bg_00000001")

    def test_handle_reuse_cannot_substitute_a_different_servers_record(self):
        from session import observe_jobs
        with tempfile.TemporaryDirectory() as temp:
            root=pathlib.Path(temp);(root/"observations").mkdir()
            jobs={"@bg_00000001":{"handle":"@bg_00000001","record":"/tmp/first.json","delivered":True}}
            (root/"observations/new.json").write_text(json.dumps({"tool_name":"mcp__codescout__run_command",
                "tool_response":{"output_id":"@bg_00000001","record":"/tmp/second.json"}}))
            with self.assertRaisesRegex(ValueError,"handle reused"):
                observe_jobs(root,jobs)

    def test_other_tool_payloads_do_not_register_background_jobs(self):
        from session import observe_jobs
        with tempfile.TemporaryDirectory() as temp:
            root=pathlib.Path(temp);(root/"observations").mkdir()
            (root/"observations/not-launch.json").write_text(json.dumps({"tool_name":"mcp__codescout__read_file",
                "tool_response":{"output_id":"@bg_00000001","record":"/tmp/quoted.json"}}))
            jobs={}
            observe_jobs(root,jobs)
            self.assertEqual(jobs,{})


if __name__=="__main__":unittest.main()
