"""Behavioral hook contracts: actual local clients, no Docker/provider."""
import json
import pathlib
import sys
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch
from decimal import Decimal
import session
import workflow

import time

PROGRAM = r"""
import json,sys
sid="guard-test"
for line in sys.stdin:
    print(json.dumps({"type":"result","session_id":sid,"subtype":"success","is_error":False,
                      "total_cost_usd":0,"result":"candidate"}),flush=True)
"""

class SessionGuardTests(unittest.TestCase):
    def exercise(self,root,**options):
        client=root/"client.py";client.write_text(PROGRAM)
        return session.run_session([sys.executable,str(client)],cwd=root,env={},
            prompt="task",session_id="guard-test",out=root,read_record=lambda p:None,
            timeout_s=2,**options)

    def test_fault_before_spawn_prevents_client_contact(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp)
            def guard():raise ValueError("host floor failed")
            result=self.exercise(root,guard=guard)
            self.assertIsNone(result["client_pid"])
            self.assertIn("host floor failed",result["error"])
            self.assertEqual(result["turns"],0)

    def test_observer_gets_actual_owned_process_before_first_prompt(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp);seen=[]
            def observer(proc):
                self.assertIsNone(proc.poll())
                seen.append(proc.pid)
            result=self.exercise(root,client_observer=observer)
            self.assertEqual(result["status"],"settled")
            self.assertEqual(seen,[result["client_pid"]])

    def test_fault_while_client_idle_reaps_owned_process_without_deadline_wait(self):
        import time
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp);client=root/"idle.py"
            client.write_text("import time;time.sleep(30)")
            started=time.monotonic()
            def guard():
                if time.monotonic()-started>.1:raise ValueError("runtime probe lost")
            result=session.run_session([sys.executable,str(client)],cwd=root,env={},prompt="task",
                session_id="guard-test",out=root,read_record=lambda p:None,timeout_s=2,guard=guard)
            self.assertIn("runtime probe lost",result["error"])
            self.assertLess(time.monotonic()-started,1.5)
            self.assertIsNotNone(result["exit_code"])

class Supervisor:
    def __init__(self,events,*,invalid=False):
        self.events=events;self.invalid=invalid
    def bind(self,out,image,server):
        self.events.append("bind")
        server.request_guard=self.check
    def check(self):pass
    def client_started(self,proc):self.events.append("client")
    def before_public(self):self.events.append("before-public")
    def after_public(self,command,log,code):
        self.events.append("after-public")
        if self.invalid:raise ValueError("public infrastructure invalid")
    def finish(self):self.events.append("finish")

class WorkflowSupervisorTests(unittest.TestCase):
    def exercise(self,root,*,invalid=False,public_code=0,program=PROGRAM,supervisor_factory=Supervisor):
        events=[];supervisor=supervisor_factory(events,invalid=invalid)
        actor=root/"actor";actor.mkdir()
        script=root/"client.py";script.write_text(program)
        (root/"settings.json").write_text("{}");(root/"launch.json").write_text("{}")
        config={"checks":[{"id":"public","command":"check"}],"timeout_s":2,
                "check_timeout_s":1,"max_continuations":1}
        class Server:
            budget=SimpleNamespace(pending=None,spent=Decimal("0"))
            errors=[];budget_stop=None;forwarded=0;requests=[];scripted=True;stage=0
            def shutdown(self):pass
            def server_close(self):pass
        runtime=SimpleNamespace(IMAGE="image",save=lambda p,o:p.write_text(json.dumps(o)),
            extract_result=lambda rows,sid:{"cost":Decimal("0"),"is_error":False,"subtype":"success"},
            audit_hooks=lambda events:[])
        def native(out,image,command,log,timeout_s):
            events.append("native");log.write_text("functional output");return public_code
        def cleanup(*a,**kw):events.append("cleanup")
        def preserve(*a,**kw):
            events.append("preserve");return {"complete":True,"errors":[],"logs":[]}
        argv=[sys.executable,str(script),"--output-format","json","--","task"]
        with patch.object(workflow,"native_check",side_effect=native),\
             patch.object(workflow,"cleanup_native",side_effect=cleanup),\
             patch.object(workflow,"preserve_background_logs",side_effect=preserve):
            result=workflow.execute(runtime,config,root,actor,argv,{},Server(),"guard-test",
                                    root/"hook",Decimal("1"),supervisor=supervisor)
        return result,events

    def test_supervisor_observes_public_result_and_finishes_before_cleanup(self):
        with tempfile.TemporaryDirectory() as tmp:
            result,events=self.exercise(pathlib.Path(tmp))
            self.assertTrue(result["workflow_completed"])
            self.assertEqual(events,["bind","client","before-public","native","after-public","preserve","finish","cleanup"])

    def test_invalid_public_result_never_sends_continuation_and_still_finishes(self):
        with tempfile.TemporaryDirectory() as tmp:
            result,events=self.exercise(pathlib.Path(tmp),invalid=True,public_code=1)
            self.assertFalse(result["workflow_completed"])
            self.assertEqual(result["lifecycle"]["continuations"],0)
            self.assertEqual(result["lifecycle"]["turns"],1)
            self.assertIn("public infrastructure invalid",result["lifecycle"]["error"])
            self.assertLess(events.index("finish"),events.index("cleanup"))

    def test_functional_failure_still_continues_same_client_then_exhausts(self):
        with tempfile.TemporaryDirectory() as tmp:
            result,events=self.exercise(pathlib.Path(tmp),public_code=1)
            self.assertEqual(result["lifecycle"]["continuations"],1)
            self.assertEqual(result["lifecycle"]["turns"],2)
            self.assertEqual(events.count("native"),2)
            self.assertEqual(events.count("finish"),1)
            self.assertFalse(result["workflow_completed"])
    def test_workflow_guard_fault_interrupts_idle_owned_client(self):
        class Fault(Supervisor):
            started=None
            def client_started(self,proc):
                super().client_started(proc)
                self.started=time.monotonic()
            def check(self):
                if self.started is not None and time.monotonic()-self.started>.05:
                    raise ValueError("runtime guard fault")
        with tempfile.TemporaryDirectory() as tmp:
            result,events=self.exercise(pathlib.Path(tmp),program="import time;time.sleep(30)",
                                        supervisor_factory=Fault)
            self.assertIn("runtime guard fault",result["lifecycle"]["error"])
            self.assertEqual(result["lifecycle"]["continuations"],0)
            self.assertNotIn("native",events)
            self.assertEqual(events.count("finish"),1)
            self.assertLess(events.index("finish"),events.index("cleanup"))
            self.assertFalse(result["workflow_completed"])

    def test_finish_only_failure_invalidates_successful_public_result_and_keeps_error(self):
        class Fault(Supervisor):
            def finish(self):
                super().finish()
                raise ValueError("final native probe failed")
        with tempfile.TemporaryDirectory() as tmp:
            result,events=self.exercise(pathlib.Path(tmp),supervisor_factory=Fault)
            self.assertTrue(result["public_verification"]["passed"])
            self.assertTrue(result["background_evidence"]["complete"])
            self.assertFalse(result["workflow_completed"])
            self.assertIn("final native probe failed",result["supervision_error"])
            self.assertIn("final native probe failed",result["lifecycle"]["error"])
            self.assertEqual(events.count("finish"),1)
            self.assertLess(events.index("preserve"),events.index("finish"))
            self.assertLess(events.index("finish"),events.index("cleanup"))
