"""Final candidate export uses actual Git, mocking only the Docker boundary."""
import hashlib
import json
import pathlib
import subprocess
import tempfile
import unittest
from unittest.mock import patch

try:
    import artifacts
except ModuleNotFoundError:
    artifacts = None


class PatchCaptureTests(unittest.TestCase):
    def require_module(self):
        self.assertIsNotNone(artifacts, "candidate capture contract is not implemented")
        return artifacts

    def make_repo(self, root):
        root.mkdir()
        self.git(root, "init", "-q")
        (root / "old.rs").write_text("fn old() {}\n")
        (root / "remove.rs").write_text("delete me\n")
        self.git(root, "add", ".")
        self.git(root, "-c", "user.name=fixture", "-c", "user.email=fixture@invalid",
                 "commit", "-qm", "baseline")
        return self.git(root, "rev-parse", "HEAD").decode().strip()

    def git(self, root, *args):
        return subprocess.check_output(["git", "-C", str(root), *args], stderr=subprocess.PIPE)

    def test_capture_keeps_new_deleted_binary_files_against_frozen_base_after_head_moves(self):
        mod = self.require_module()
        with tempfile.TemporaryDirectory() as temp:
            parent = pathlib.Path(temp)
            repo = parent / "repo"
            baseline = self.make_repo(repo)
            (repo / "old.rs").write_text("fn changed() {}\n")
            (repo / "remove.rs").unlink()
            (repo / "new.rs").write_text("pub fn new() {}\n")
            (repo / "bytes.bin").write_bytes(bytes(range(256)))
            for name in (".codescout", ".buddy", ".superpowers", ".claude", "target", "node_modules"):
                (repo / name).mkdir()
                (repo / name / "private-state.txt").write_text("MUST_NOT_ENTER_CANDIDATE")
            self.git(repo, "add", "old.rs")
            self.git(repo, "-c", "user.name=fixture", "-c", "user.email=fixture@invalid",
                     "commit", "-qm", "actor moved HEAD")
            out = parent / "out"; out.mkdir()
            (out / "record-owner.json").write_text(json.dumps({"name": "owner", "container_id": "immutable"}))
            original = subprocess.run
            commands = []
            def docker(argv, **kwargs):
                commands.append(argv)
                if argv[:2] == ["docker", "inspect"]:
                    return subprocess.CompletedProcess(argv, 0, json.dumps([{
                        "Id": "immutable", "Image": "sha256:external", "State": {"Running": True},
                        "Config": {"Labels": {"codescout.hfa": "owner"}}}]), "")
                self.assertEqual(argv[:5], ["docker", "exec", "-w", "/testbed", "immutable"])
                return original(["git", "-C", str(repo), *argv[6:]], **kwargs)
            with patch.object(mod.subprocess, "run", side_effect=docker):
                proof = mod.capture_patch(out, "sha256:external", baseline)
            self.assertTrue(proof["complete"], proof)
            self.assertEqual(set(proof["edited"]), {"old.rs", "remove.rs", "new.rs", "bytes.bin"})
            data = (out / "candidate.patch").read_bytes()
            self.assertNotIn(b"MUST_NOT_ENTER_CANDIDATE", data)
            self.assertIn(b"GIT binary patch", data)
            self.assertEqual(hashlib.sha256(data).hexdigest(), proof["sha256"])
            self.assertEqual(proof["container_id"], "immutable")
            self.assertEqual(proof["baseline_commit"], baseline)
            check = parent / "check"
            self.make_repo(check)
            # Copy exact baseline history so context matches the pinned commit.
            self.git(check, "fetch", "-q", str(repo), baseline)
            self.git(check, "reset", "--hard", baseline)
            original(["git", "-C", str(check), "apply", str(out / "candidate.patch")], check=True,
                     capture_output=True)
            self.assertEqual((check / "old.rs").read_text(), "fn changed() {}\n")
            self.assertEqual((check / "new.rs").read_text(), "pub fn new() {}\n")
            self.assertFalse((check / "remove.rs").exists())
            self.assertEqual((check / "bytes.bin").read_bytes(), bytes(range(256)))

    def test_replaced_or_wrong_image_container_is_never_executed(self):
        mod = self.require_module()
        for image, ident, label in [
            ("sha256:wrong", "immutable", "owner"),
            ("sha256:expected", "replacement", "owner"),
            ("sha256:expected", "immutable", "foreign")]:
            with self.subTest(image=image, ident=ident, label=label), tempfile.TemporaryDirectory() as temp:
                out = pathlib.Path(temp)
                (out / "record-owner.json").write_text(json.dumps({"name": "owner", "container_id": "immutable"}))
                calls = []
                def docker(argv, **kwargs):
                    calls.append(argv)
                    return subprocess.CompletedProcess(argv, 0, json.dumps([{
                        "Id": ident, "Image": image, "State": {"Running": True},
                        "Config": {"Labels": {"codescout.hfa": label}}}]), "")
                with patch.object(mod.subprocess, "run", side_effect=docker):
                    with self.assertRaisesRegex(ValueError, "identity"):
                        mod.capture_patch(out, "sha256:expected", "a" * 40)
                self.assertFalse(any(a[1] == "exec" for a in calls))
                self.assertFalse((out / "candidate.patch").exists())

    def test_unpinned_owner_or_invalid_baseline_never_contacts_docker(self):
        mod = self.require_module()
        with tempfile.TemporaryDirectory() as temp:
            out = pathlib.Path(temp)
            for owner in (None, {"name": "owner"}):
                if owner is not None:
                    (out / "record-owner.json").write_text(json.dumps(owner))
                with patch.object(mod.subprocess, "run", side_effect=AssertionError("Docker forbidden")):
                    with self.assertRaises(ValueError):
                        mod.capture_patch(out, "sha256:expected", "a" * 40)
            with patch.object(mod.subprocess, "run", side_effect=AssertionError("Docker forbidden")):
                with self.assertRaises(ValueError):
                    mod.capture_patch(out, "sha256:expected", "HEAD; exit 0")
