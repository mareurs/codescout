"""Capture final source changes while the exact owned native worker is alive."""
import hashlib
import json
import pathlib
import re
import subprocess
import tempfile
import time

EXCLUDED = (".codescout", ".buddy", ".superpowers", ".claude", "target", "node_modules")
PATHSPEC = (".", *(f":(exclude,glob)**/{name}/**" for name in EXCLUDED))


def capture_patch(out, image, baseline_commit, *, timeout_s=60, max_bytes=32*1024*1024):
    out = pathlib.Path(out)
    if not isinstance(baseline_commit, str) or not re.fullmatch(r"[0-9a-f]{40}", baseline_commit):
        raise ValueError("capture requires a frozen baseline commit")
    owner_path = out / "record-owner.json"
    if not owner_path.is_file():
        raise ValueError("capture requires a pinned native owner identity")
    owner = json.loads(owner_path.read_text())
    if not owner.get("name") or not owner.get("container_id"):
        raise ValueError("capture owner identity is incomplete")
    deadline = time.monotonic() + timeout_s
    inspected = subprocess.run(["docker", "inspect", owner["name"]], capture_output=True,
                               text=True, timeout=min(5, timeout_s))
    if inspected.returncode:
        raise ValueError("capture owner identity is unavailable")
    rows = json.loads(inspected.stdout)
    if len(rows) != 1:
        raise ValueError("capture owner identity is ambiguous")
    identity = rows[0]
    if (identity["Id"] != owner["container_id"] or identity["Image"] != image
            or identity["Config"]["Labels"].get("codescout.hfa") != owner["name"]
            or not identity["State"]["Running"]):
        raise ValueError("capture owner identity mismatch")
    container_id = identity["Id"]

    def git(*args):
        left = deadline - time.monotonic()
        if left <= 0:
            raise TimeoutError("candidate capture deadline exceeded")
        # File stdout prevents a large candidate diff filling host memory.
        with tempfile.TemporaryFile() as stream:
            result = subprocess.run(["docker", "exec", "-w", "/testbed", container_id, "git", *args],
                stdout=stream, stderr=subprocess.PIPE, timeout=min(30, left))
            if result.returncode:
                raise ValueError("candidate Git capture failed: " + result.stderr.decode("utf-8", "replace")[-500:])
            stream.seek(0)
            data = stream.read(max_bytes + 1)
        if len(data) > max_bytes:
            raise ValueError("candidate capture exceeds byte limit")
        return data

    # This matches the existing setup-ab extraction contract, including new files.
    # The controller-supplied baseline is independent of any agent-moved HEAD.
    git("add", "-A", "--", *PATHSPEC)
    names = git("diff", "--cached", "--name-only", "-z", baseline_commit, "--", *PATHSPEC)
    edited = [name.decode("utf-8", "surrogateescape") for name in names.split(b"\0") if name]
    if any(any(part in EXCLUDED for part in pathlib.PurePosixPath(name).parts) for name in edited):
        raise ValueError("tool state entered the candidate path set")
    candidate = git("diff", "--cached", "--binary", baseline_commit, "--", *PATHSPEC)
    target = out / "candidate.patch"
    with target.open("xb") as stream:
        stream.write(candidate)
    proof = {"complete": True, "container_id": container_id, "image": image,
             "baseline_commit": baseline_commit, "edited": edited, "bytes": len(candidate),
             "sha256": hashlib.sha256(candidate).hexdigest(), "path": str(target)}
    with (out / "candidate-capture.json").open("x") as stream:
        json.dump(proof, stream, indent=2)
        stream.write("\n")
    return proof
