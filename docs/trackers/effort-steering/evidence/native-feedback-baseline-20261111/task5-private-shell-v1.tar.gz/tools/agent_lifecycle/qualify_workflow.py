"""Actual CLI/native workflow qualification. No credential or upstream access."""
import hashlib
import json
import pathlib
import shutil
import sys
from unittest.mock import patch

HERE=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/"hint_authority_pilot"))
import run as worker
import transport
from qualify import NoCredential, no_upstream
from session import background_launches


def cell(root,frozen,mode):
    worker.L=root
    checks=[{"id":"format","command":"printf FORMAT"},
        {"id":"compile","command":"test -f workflow-repaired.txt" if mode=="repair" else "printf COMPILE"},
        {"id":"lean","command":"printf LEAN"},{"id":"default","command":"printf DEFAULT"}]
    if mode=="unknown":
        checks[1]["command"]="sleep 10"
    config={"checks":checks,"timeout_s":180,"check_timeout_s":.2 if mode=="unknown" else 30}
    original=transport.Proxy.scripted
    base_length=8
    state={"background":False,"tail":False,"repair":False}
    def scripted(self,body):
        if not state["background"]:
            self.server.plan.append(("mcp__codescout__run_command",{
                "command":"sleep 2; printf WORKFLOW_BACKGROUND_FINISHED","run_in_background":True}))
            state["background"]=True
        text=json.dumps(body)
        if self.server.stage==base_length+1 and "[harness background completion]" in text and not state["tail"]:
            observations=self.server.out/"observations"
            launches=[pair for p in observations.glob("*.json")
                for pair in background_launches(json.loads(p.read_text()).get("tool_response"))]
            if len(launches)!=1:raise ValueError("background launch not captured")
            self.server.plan.append(("mcp__codescout__run_command",{"command":"tail -50 "+launches[0][0]}))
            state["tail"]=True
        if mode=="repair" and "[harness public verification]" in text and not state["repair"]:
            self.server.plan.append(("mcp__codescout__create_file",{
                "path":"workflow-repaired.txt","content":"scripted repair after public failure\n"}))
            state["repair"]=True
        return original(self,body)
    with patch.object(transport.Proxy,"scripted",scripted):
        receipt=worker.one(mode,"low",False,True,workflow=config)
    out=root/mode
    rounds=[json.loads(p.read_text()) for p in sorted(out.glob("verification-*/receipt.json"))]
    assert receipt["forwarded"]==0 and receipt["cost_usd"]=="0" and not receipt["transport_errors"]
    assert receipt["hint_then_edit"] and receipt["cleanup_error"] is None
    assert all(j["delivered"] for j in receipt["lifecycle"]["jobs"])
    assert (out/"record-owner.json").exists()
    if mode=="unknown":
        assert not receipt["workflow_completed"]
        assert rounds[-1]["status"]=="incomplete" and rounds[-1]["error"]
        assert receipt["lifecycle"]["status"]=="incomplete"
    else:
        assert receipt["workflow_completed"]
        assert receipt["public_verification"]["passed"] and len(receipt["public_verification"]["checks"])==4
        assert receipt["lifecycle"]["continuations"]==(2 if mode=="repair" else 1)
        if mode=="repair":
            assert len(rounds)==2 and [r["exit_code"] for r in rounds[0]["checks"]]==[0,1,0,0]
            assert [r["exit_code"] for r in rounds[1]["checks"]]==[0,0,0,0]
    return {"mode":mode,"receipt":receipt,"rounds":rounds}


def main():
    root=pathlib.Path(sys.argv[1]).resolve();root.mkdir()
    frozen=worker.P/"launch-budget-requalification-20261104"
    shutil.copytree(frozen/"source",root/"source")
    shutil.copytree(frozen/"skill-only-plugin",root/"skill-only-plugin")
    worker.TOKEN=NoCredential();transport.Proxy.upstream=no_upstream
    sources=[HERE/"session.py",HERE/"workflow.py",HERE/"verification.py",HERE/"qualify_workflow.py",worker.HERE/"run.py"]
    worker.save(root/"inputs.json",{"frozen":str(frozen),"source_hashes":{
        str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}})
    results=[]
    for mode in ("success","repair","unknown"):
        results.append(cell(root,frozen,mode))
        worker.save(root/"results.json",results)
    print(json.dumps({"qualified":True,"cells":len(results),"cost_usd":"0","root":str(root)}))


if __name__=="__main__":main()
