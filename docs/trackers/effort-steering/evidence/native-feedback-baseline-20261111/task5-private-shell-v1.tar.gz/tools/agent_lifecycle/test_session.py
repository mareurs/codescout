"""Behavior tests: real subprocess and delayed record, no provider or Docker dependency."""
import json
import pathlib
import sys
import tempfile
import unittest
from decimal import Decimal

try:
    from session import run_session
except ImportError:
    run_session = None

FIXTURE = r'''
import json, os, pathlib, subprocess, sys
root=pathlib.Path(os.environ["FIXTURE_ROOT"])
mode=os.environ["FIXTURE_MODE"]
sid=os.environ["FIXTURE_SID"]
observations=root/"observations";observations.mkdir(exist_ok=True)
messages=[]
for line in sys.stdin:
    msg=json.loads(line);messages.append(msg)
    (root/"messages.json").write_text(json.dumps(messages))
    if len(messages)==1:
        if mode!="no-job":
            record=root/"job.json"
            observation={"tool_name":"mcp__codescout__run_command","tool_use_id":"start",
              "tool_response":{"output_id":"@bg_00000001","record":str(record)}}
            (observations/"start.json").write_text(json.dumps(observation))
            state={"schema":1,"handle":"@bg_00000001","state":"running","exit_code":None}
            record.write_text(json.dumps(state))
            if mode not in ("timeout", "missing"):
                code=7 if mode=="failed" else 0
                if mode=="malformed": code="bad"
                end=dict(state,state="exited",exit_code=code)
                if mode=="mismatch":end["handle"]="@bg_wrong"
                program="import pathlib,time;time.sleep(.15);pathlib.Path("+repr(str(record))+").write_text("+repr(json.dumps(end))+")"
                subprocess.Popen([sys.executable,"-c",program],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            if mode=="missing":record.unlink()
        result={"type":"result","subtype":"success","is_error":False,
          "session_id":sid,"total_cost_usd":0.2,"result":"Waiting for background completion"}
    else:
        if mode=="wrong-session":sid="foreign"
        result={"type":"result","subtype":"success","is_error":False,
          "session_id":sid,"total_cost_usd":0.3,"result":"Read completed; continued in same process"}
        if mode=="regressing-cost":result["total_cost_usd"]=0.1
    print(json.dumps(result),flush=True)
'''

class LifecycleTests(unittest.TestCase):
    def exercise(self, mode="success", **kwargs):
        self.assertIsNotNone(run_session, "stream lifecycle controller is missing")
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = pathlib.Path(temp.name)
        script = root/"client.py"; script.write_text(kwargs.pop("program",FIXTURE))
        env = {"FIXTURE_ROOT":str(root), "FIXTURE_MODE":mode, "FIXTURE_SID":"same-session"}
        receipt = run_session([sys.executable,str(script)], cwd=root, env=env,
            prompt="original task", session_id="same-session", out=root,
            read_record=lambda p:json.loads(pathlib.Path(p).read_text()),
            timeout_s=kwargs.pop("timeout_s", 3), max_continuations=kwargs.pop("max_continuations",2), **kwargs)
        return receipt, root

    def test_yield_waits_and_continues_same_session_with_terminal_status(self):
        receipt, root = self.exercise()
        messages=json.loads((root/"messages.json").read_text())
        self.assertEqual(receipt["status"],"settled")
        self.assertEqual(receipt["continuations"],1)
        self.assertEqual(len(messages),2)
        self.assertEqual(messages[0]["message"]["content"],"original task")
        self.assertEqual(messages[1]["session_id"],"same-session")
        self.assertIn("@bg_00000001",messages[1]["message"]["content"])
        self.assertIn('"exit_code": 0',messages[1]["message"]["content"])
        self.assertEqual(receipt["cost_usd"],"0.3")  # terminal totals are cumulative, not .5
        self.assertEqual(receipt["exit_code"],0)

    def test_failed_job_is_delivered_without_becoming_success(self):
        receipt,root=self.exercise("failed")
        self.assertEqual(receipt["status"],"settled")
        self.assertFalse(receipt["all_jobs_succeeded"])
        self.assertIn('"exit_code": 7',json.loads((root/"messages.json").read_text())[1]["message"]["content"])

    def test_no_job_finishes_without_spurious_continuation(self):
        receipt,_=self.exercise("no-job")
        self.assertEqual(receipt["continuations"],0)
        self.assertEqual(receipt["status"],"settled")
        self.assertEqual(receipt["cost_usd"],"0.2")

    def test_missing_malformed_and_mismatched_records_fail_closed(self):
        for mode in ("missing","malformed","mismatch","wrong-session","regressing-cost"):
            with self.subTest(mode=mode):
                receipt,_=self.exercise(mode)
                self.assertEqual(receipt["status"],"incomplete")
                self.assertTrue(receipt["error"])

    def test_deadline_kills_client_and_never_reports_settled(self):
        receipt,_=self.exercise("timeout",timeout_s=.4)
        self.assertEqual(receipt["status"],"incomplete")
        self.assertIn("deadline",receipt["error"])
        self.assertIsNotNone(receipt["exit_code"])

    def test_continuation_limit_never_silently_drops_result(self):
        receipt,root=self.exercise(max_continuations=0)
        self.assertEqual(receipt["status"],"incomplete")
        self.assertIn("continuation limit",receipt["error"])
        self.assertEqual(len(json.loads((root/"messages.json").read_text())),1)
    def test_failed_cli_turn_does_not_count_as_settled(self):
        program=FIXTURE.replace('"is_error":False','"is_error":True')
        receipt,_=self.exercise("no-job",program=program)
        self.assertEqual(receipt["status"],"incomplete")
        self.assertIn("CLI turn did not succeed",receipt["error"])

    def test_nonzero_client_exit_does_not_count_as_settled(self):
        receipt,_=self.exercise("no-job",program=FIXTURE+"\nsys.exit(9)\n")
        self.assertEqual(receipt["status"],"incomplete")
        self.assertEqual(receipt["exit_code"],9)

    def test_every_pending_job_is_delivered_with_its_own_outcome(self):
        extra = """
            other=root/"job2.json"
            second={"schema":1,"handle":"@bg_00000002","state":"running","exit_code":None}
            other.write_text(json.dumps(second))
            (observations/"second.json").write_text(json.dumps({"tool_name":"mcp__codescout__run_command",
                "tool_response":{"output_id":"@bg_00000002","record":str(other)}}))
            end2=dict(second,state="exited",exit_code=9)
            prog2="import pathlib,time;time.sleep(.3);pathlib.Path("+repr(str(other))+").write_text("+repr(json.dumps(end2))+")"
            subprocess.Popen([sys.executable,"-c",prog2],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
"""
        program=FIXTURE.replace("            if mode not in",extra+"            if mode not in")
        receipt,root=self.exercise(program=program)
        self.assertEqual(receipt["status"],"settled")
        messages=json.loads((root/"messages.json").read_text())
        notification=messages[1]["message"]["content"]
        self.assertIn("@bg_00000001",notification)
        self.assertIn("@bg_00000002",notification)
        self.assertIn('"exit_code": 9',notification)
        self.assertEqual(len(receipt["jobs"]),2)
        self.assertFalse(receipt["all_jobs_succeeded"])
class VerificationContinuationTests(unittest.TestCase):
    exercise = LifecycleTests.exercise
    def test_failed_public_check_reuses_live_session_and_latest_cost(self):
        calls=[]
        def verify(remaining_s):
            calls.append(remaining_s)
            return "compile failed; fix and retry" if len(calls)==1 else None
        receipt,root=self.exercise("no-job",completion_check=verify)
        self.assertEqual(receipt["status"],"settled")
        self.assertEqual(receipt["continuations"],1)
        self.assertEqual(receipt["cost_usd"],"0.3")
        messages=json.loads((root/"messages.json").read_text())
        self.assertIn("compile failed",messages[1]["message"]["content"])
        self.assertEqual(len(calls),2)
        self.assertGreater(calls[0],calls[1])

    def test_unknown_public_check_stops_without_sending_more_messages(self):
        def verify(remaining_s):
            raise ValueError("unknown check result")
        receipt,root=self.exercise("no-job",completion_check=verify)
        self.assertEqual(receipt["status"],"incomplete")
        self.assertIn("unknown check result",receipt["error"])
        self.assertEqual(len(json.loads((root/"messages.json").read_text())),1)

    def test_public_check_feedback_respects_shared_continuation_bound(self):
        receipt,_=self.exercise("no-job",completion_check=lambda left:"still failed",max_continuations=1)
        self.assertEqual(receipt["status"],"incomplete")
        self.assertEqual(receipt["continuations"],1)

class DeadlineTests(unittest.TestCase):
    def run_blocked_client(self, program, prompt):
        import time
        with tempfile.TemporaryDirectory() as temp:
            root=pathlib.Path(temp)
            started=time.monotonic()
            receipt=run_session([sys.executable,"-c",program],cwd=root,env={},
                prompt=prompt,session_id="deadline",out=root,read_record=lambda p:None,
                timeout_s=.15,max_continuations=1)
            elapsed=time.monotonic()-started
            self.assertEqual(receipt["status"],"incomplete")
            self.assertLess(elapsed,.8,"blocked pipe outlived lifecycle deadline")

    def test_dead_leader_with_descendant_stdout_does_not_block_cleanup(self):
        self.run_blocked_client("import subprocess,sys,os; subprocess.Popen([sys.executable,'-c','import time;time.sleep(2)']);os._exit(0)","task")

    def test_nonreading_stdin_does_not_block_prompt_deadline(self):
        self.run_blocked_client("import time;time.sleep(2)","x"*1000000)

class PreCleanupTests(unittest.TestCase):
    def test_snapshot_runs_once_while_client_is_alive_before_stdin_close_or_kill(self):
        import os
        import session
        from unittest.mock import patch
        for mode in ("no-job","timeout"):
            with self.subTest(mode=mode),tempfile.TemporaryDirectory() as temp:
                root=pathlib.Path(temp)
                program=FIXTURE.replace("messages=[]","(root/'client.pid').write_text(str(os.getpid()))\nmessages=[]")
                program+="\n(root/'stdin-closed').write_text('closed')\n"
                script=root/"client.py";script.write_text(program)
                snapshots=[];closed=[];signals=[]
                original_popen=session.subprocess.Popen
                original_killpg=session.os.killpg
                class InputWitness:
                    def __init__(self,pipe):self.pipe=pipe
                    def __getattr__(self,name):return getattr(self.pipe,name)
                    def close(self):
                        closed.append("stdin.close")
                        return self.pipe.close()
                def start(*args,**kwargs):
                    process=original_popen(*args,**kwargs)
                    process.stdin=InputWitness(process.stdin)
                    return process
                def killpg(*args):
                    signals.append("killpg")
                    return original_killpg(*args)
                def snapshot():
                    self.assertEqual(closed,[],"snapshot must precede the actual stdin.close call")
                    self.assertEqual(signals,[],"snapshot must precede the first killpg call")
                    os.kill(int((root/"client.pid").read_text()),0)
                    self.assertFalse((root/"stdin-closed").exists())
                    snapshots.append("live")
                with patch.object(session.subprocess,"Popen",side_effect=start),patch.object(session.os,"killpg",side_effect=killpg):
                    receipt=run_session([sys.executable,str(script)],cwd=root,
                        env={"FIXTURE_ROOT":str(root),"FIXTURE_MODE":mode,"FIXTURE_SID":"sid"},
                        prompt="task",session_id="sid",out=root,
                        read_record=lambda p:json.loads(pathlib.Path(p).read_text()),
                        timeout_s=.4,max_continuations=2,before_client_cleanup=snapshot)
                self.assertEqual(snapshots,["live"])
                self.assertEqual(receipt["status"],"settled" if mode=="no-job" else "incomplete")
                if mode=="no-job":self.assertTrue((root/"stdin-closed").exists())
                with self.assertRaises(ProcessLookupError):
                    os.kill(int((root/"client.pid").read_text()),0)

if __name__=="__main__":unittest.main()
