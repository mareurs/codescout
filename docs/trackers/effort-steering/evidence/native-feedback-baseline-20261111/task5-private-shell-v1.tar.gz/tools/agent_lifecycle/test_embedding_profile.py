"""Reject unregistered egress and changed live relay graphs before actor launch."""
import copy
import hashlib
import importlib
import pathlib
import shutil
import sys
import tempfile
import unittest

sys.path.insert(0, str(pathlib.Path(__file__).parent))
try:
    profile_module = importlib.import_module("embedding_profile")
except ModuleNotFoundError as exc:
    if exc.name != "embedding_profile":
        raise
    profile_module = None


class EmbeddingProfileTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(profile_module, "bounded embedding runtime profile missing")
        self.temp = tempfile.TemporaryDirectory(prefix="ep-relay-profile-")
        self.addCleanup(self.temp.cleanup)
        script = pathlib.Path(self.temp.name) / "embedding_relay.py"
        shutil.copyfile(pathlib.Path(__file__).parent.parent / "effort_protocol/embedding_relay.py", script)
        self.image = "sha256:" + "a" * 64
        self.owner = "ep-relay-" + "b" * 32
        self.net, self.relay, self.service = "c" * 64, "d" * 64, "e" * 64
        self.upstream = "codescout-retrieval_retrieval_net"
        self.profile = {
            "version": "embedding-relay-v1", "owner": self.owner, "network_id": self.net,
            "relay_id": self.relay, "service_id": self.service, "service_image": "sha256:" + "f" * 64,
            "service_started_at": "2026-11-10T03:00:00Z", "upstream_network": self.upstream,
            "upstream_network_id": "9" * 64, "service_ip": "172.30.0.2",
            "relay_script": str(script), "relay_sha256": hashlib.sha256(script.read_bytes()).hexdigest(),
        }
        self.options = {
            "--network": [self.net], "--tmpfs": ["/tmp:rw,exec,size=16g,uid=1000,gid=1000"],
            "--read-only": [True], "--cap-drop": ["ALL"], "--security-opt": ["no-new-privileges"],
        }
        self.rows = {
            self.net: {"Id": self.net, "Internal": True, "Labels": {"codescout.hfa": self.owner}, "Containers": {self.relay: {}}},
            self.relay: {
                "Id": self.relay, "Image": self.image, "State": {"Running": True},
                "Config": {"User": "1000:1000", "Entrypoint": ["python3"],
                    "Cmd": ["-I", "-B", "/relay.py", "--upstream", "http://172.30.0.2:8080/v1/embeddings", "--model", "CodeRankEmbed", "--dimensions", "768"],
                    "Labels": {"codescout.hfa": self.owner}},
                "HostConfig": {"ReadonlyRootfs": True, "Privileged": False, "CapDrop": ["ALL"],
                    "CapAdd": None, "SecurityOpt": ["no-new-privileges"], "Memory": 536870912,
                    "MemorySwap": 536870912, "NanoCpus": 1000000000, "PidsLimit": 64, "PortBindings": {}, "Devices": [],
                    "Tmpfs": {"/mnt_tmp": "ro,noexec,nosuid,nodev,size=1m"}},
                "Mounts": [{"Type": "bind", "Source": str(script), "Destination": "/relay.py", "RW": False}],
                "NetworkSettings": {"Networks": {
                    "private": {"NetworkID": self.net, "Aliases": ["source-embeddings"]},
                    self.upstream: {"NetworkID": "9" * 64}}, "Ports": {}},
            },
            self.service: {"Id": self.service, "Image": self.profile["service_image"],
                "State": {"Running": True, "StartedAt": self.profile["service_started_at"]},
                "NetworkSettings": {"Networks": {self.upstream: {"NetworkID": "9" * 64, "IPAddress": "172.30.0.2"}}},
            },
        }

    def validate(self):
        return profile_module.validate_embedding_profile(self.profile, self.options, self.image, inspect=lambda kind, identity: copy.deepcopy(self.rows[identity]))

    def test_only_registered_owned_internal_relay_graph_is_admitted(self):
        self.assertEqual(self.validate(), {"network_id": self.net, "profile_version": "embedding-relay-v1"})

    def test_unknown_profile_and_unregistered_actor_options_are_rejected(self):
        changes = [
            ("version", "arbitrary-network"),
            ("network_id", "bridge"), ("relay_id", "short"),
            ("owner", "another-session"), ("service_image", "latest"),
            ("service_started_at", ""), ("relay_sha256", "0" * 64),
        ]
        for key, value in changes:
            with self.subTest(key=key):
                prior = self.profile[key]
                self.profile[key] = value
                with self.assertRaises(ValueError):
                    self.validate()
                self.profile[key] = prior
        self.profile["unexpected"] = True
        with self.assertRaises(ValueError):
            self.validate()

    def test_actor_requires_private_network_hardening_and_usable_temporary_storage(self):
        for key, value in [
            ("--network", ["none"]), ("--tmpfs", ["/tmp:rw,noexec,size=16g"]),
            ("--read-only", []), ("--cap-drop", []), ("--security-opt", []),
        ]:
            with self.subTest(key=key):
                prior = self.options[key]
                self.options[key] = value
                with self.assertRaises(ValueError):
                    self.validate()
                self.options[key] = prior

    def test_mutated_live_network_identity_or_foreign_member_is_rejected(self):
        row = self.rows[self.net]
        for key, value in [
            ("Id", "0" * 64), ("Internal", False), ("Labels", {}),
            ("Containers", {}), ("Containers", {self.relay: {}, "foreign": {}}),
        ]:
            with self.subTest(key=key, value=value):
                prior = row[key]
                row[key] = value
                with self.assertRaises(ValueError):
                    self.validate()
                row[key] = prior

    def test_relay_process_resource_mount_and_network_drift_is_rejected(self):
        row = self.rows[self.relay]
        changes = [
            (row, "Id", "0" * 64), (row, "Image", "sha256:" + "0" * 64),
            (row["State"], "Running", False),
            (row["Config"], "User", "0:0"), (row["Config"], "Entrypoint", ["sh"]),
            (row["Config"], "Cmd", ["-m", "http.server"]), (row["Config"], "Labels", {}),
            (row["HostConfig"], "ReadonlyRootfs", False), (row["HostConfig"], "Privileged", True),
            (row["HostConfig"], "CapDrop", []), (row["HostConfig"], "CapAdd", ["NET_ADMIN"]),
            (row["HostConfig"], "SecurityOpt", []), (row["HostConfig"], "Memory", 0),
            (row["HostConfig"], "MemorySwap", -1), (row["HostConfig"], "NanoCpus", 0),
            (row["HostConfig"], "PidsLimit", 0), (row["HostConfig"], "PortBindings", {"8000/tcp": [{"HostPort": "8000"}]}),
            (row["HostConfig"], "Devices", [{"PathOnHost": "/dev/sda"}]),
            (row, "Mounts", []),
            (row["Mounts"][0], "RW", True), (row["Mounts"][0], "Destination", "/different.py"),
            (row["NetworkSettings"], "Networks", {"private": {"NetworkID": self.net}}),
            (row["NetworkSettings"], "Ports", {"8000/tcp": [{"HostPort": "8000"}]}),
        ]
        for target, key, value in changes:
            with self.subTest(key=key):
                prior = target[key]
                target[key] = value
                with self.assertRaises(ValueError):
                    self.validate()
                target[key] = prior

    def test_service_restart_image_or_upstream_drift_is_rejected(self):
        row = self.rows[self.service]
        for target, key, value in [
            (row, "Id", "0" * 64), (row, "Image", self.image),
            (row["State"], "Running", False), (row["State"], "StartedAt", "new"),
            (row["NetworkSettings"], "Networks", {self.upstream: {"NetworkID": "0" * 64}}),
        ]:
            with self.subTest(key=key):
                prior = target[key]
                target[key] = value
                with self.assertRaises(ValueError):
                    self.validate()
                target[key] = prior

    def test_relay_bytes_and_symlink_substitution_are_rejected(self):
        path = pathlib.Path(self.profile["relay_script"])
        original = path.read_bytes()
        path.write_bytes(original + b"\n# changed\n")
        with self.assertRaises(ValueError):
            self.validate()
        path.write_bytes(original)
        link = path.with_name("link.py")
        link.symlink_to(path)
        self.profile["relay_script"] = str(link)
        self.rows[self.relay]["Mounts"][0]["Source"] = str(link)
        with self.assertRaises(ValueError):
            self.validate()

    def test_resolution_overrides_and_coordinated_upstream_drift_are_rejected(self):
        host = self.rows[self.relay]["HostConfig"]
        for key, value in [
            ("ExtraHosts", ["codescout-dense-amd:203.0.113.5"]),
            ("Dns", ["203.0.113.6"]), ("DnsSearch", ["different.invalid"]),
            ("DnsOptions", ["ndots:5"]),
        ]:
            with self.subTest(key=key):
                host[key] = value
                with self.assertRaises(ValueError):
                    self.validate()
                del host[key]
        self.rows[self.relay]["NetworkSettings"]["Networks"][self.upstream]["NetworkID"] = "0" * 64
        self.rows[self.service]["NetworkSettings"]["Networks"][self.upstream]["NetworkID"] = "0" * 64
        with self.assertRaises(ValueError):
            self.validate()

    def test_exact_readonly_inherited_volume_mask_rejects_unknown_tmpfs(self):
        host = self.rows[self.relay]["HostConfig"]
        for value in [
            None, {}, {"/mnt_tmp": "rw,exec,size=8g"},
            {"/unexpected": "rw,exec,size=8g"},
            {"/mnt_tmp": "ro,noexec,nosuid,nodev,size=1m", "/extra": "ro,size=1m"},
        ]:
            with self.subTest(value=value):
                host["Tmpfs"] = value
                with self.assertRaises(ValueError):
                    self.validate()

    def test_registered_service_address_must_match_the_live_service_and_relay_url(self):
        for value in ["", "latest", "172.30.0.3", "127.0.0.1", "172.030.0.2"]:
            with self.subTest(value=value):
                self.profile["service_ip"] = value
                with self.assertRaises(ValueError):
                    self.validate()
        self.profile["service_ip"] = "172.30.0.2"
        self.rows[self.service]["NetworkSettings"]["Networks"][self.upstream]["IPAddress"] = "172.30.0.3"
        with self.assertRaises(ValueError):
            self.validate()

    def test_independent_network_alias_and_mount_guards_reject_the_review_survivors(self):
        self.profile["upstream_network"] = "unregistered"
        relay_nets = self.rows[self.relay]["NetworkSettings"]["Networks"]
        service_nets = self.rows[self.service]["NetworkSettings"]["Networks"]
        relay_nets["unregistered"] = relay_nets.pop(self.upstream)
        service_nets["unregistered"] = service_nets.pop(self.upstream)
        with self.assertRaises(ValueError):
            self.validate()
        relay_nets[self.upstream] = relay_nets.pop("unregistered")
        service_nets[self.upstream] = service_nets.pop("unregistered")
        self.profile["upstream_network"] = self.upstream
        private = relay_nets["private"]
        private["Aliases"] = []
        with self.assertRaises(ValueError):
            self.validate()
        private["Aliases"] = ["source-embeddings"]
        mount = self.rows[self.relay]["Mounts"][0]
        mount["Type"] = "volume"
        with self.assertRaises(ValueError):
            self.validate()
        mount["Type"] = "bind"
        mount["Source"] = "/unregistered/file.py"
        with self.assertRaises(ValueError):
            self.validate()


if __name__ == "__main__":
    unittest.main()
