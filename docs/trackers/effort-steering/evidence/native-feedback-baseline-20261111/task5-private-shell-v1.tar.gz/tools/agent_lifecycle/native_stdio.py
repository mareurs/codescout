"""One retained Docker stdio connection; the workflow owns final container cleanup."""
import json
import os
from pathlib import Path
import subprocess
import sys
import uuid


def main(root):
    root = Path(root).resolve(strict=True)
    args = json.loads((root / "mcp-native-argv.json").read_bytes())
    if (not isinstance(args, list) or not all(isinstance(value, str) for value in args)
            or args[:2] != ["docker", "run"] or args.count("--name") != 1
            or args.count("--label") != 1 or any(value.split("=", 1)[0] == "--rm" for value in args)):
        raise ValueError("unregistered native stdio boundary or auto-removal")
    if any(args.index(option) + 1 >= len(args) for option in ("--name", "--label")):
        raise ValueError("native stdio identity field missing")
    name = "hfa-native-" + uuid.uuid4().hex
    args[args.index("--name") + 1] = name
    args[args.index("--label") + 1] = "codescout.hfa=" + name
    stderr_path = root / ("native-stderr-" + name + ".log")
    descriptor = os.open(stderr_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "wb") as stderr:
        with (root / ("mcp-launch-" + name + ".json")).open("x") as launch:
            json.dump({"argv": args, "name": name, "stderr_path": str(stderr_path)}, launch)
            launch.write("\n")
        # The Docker client needs no provider authentication inherited from the CLI.
        env = {key: value for key, value in os.environ.items()
               if key in ("PATH", "HOME", "USER", "LANG")}
        code, error = None, None
        try:
            code = subprocess.run(args, stderr=stderr, env=env).returncode
        except BaseException as exc:
            error = type(exc).__name__
            raise
        finally:
            with (root / ("mcp-exit-" + name + ".json")).open("x") as terminal:
                json.dump({"exit_code": code, "error": error, "stderr_path": str(stderr_path)}, terminal)
                terminal.write("\n")
    return code


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
