"""Keep a stream-json CLI and its MCP processes alive until observed jobs settle.

This measures lifecycle settlement only, never task correctness or required-check coverage.
The caller owns its provider budget/proxy and worker cleanup after this function returns.
"""
import json
import os
import pathlib
import select
import signal
import subprocess
from collections import deque
import time
from decimal import Decimal


def background_launches(value):
    """Decode structured MCP payloads; prose mentioning a handle is not a launch."""
    if isinstance(value, str):
        try:
            decoded = json.loads(value)
        except (ValueError, TypeError):
            return
        yield from background_launches(decoded)
    elif isinstance(value, list):
        for item in value:
            yield from background_launches(item)
    elif isinstance(value, dict):
        if str(value.get("output_id", "")).startswith("@bg_"):
            if not isinstance(value.get("record"), str):
                # Later tail responses can carry output_id without launching a job.
                if value.get("record_error"):
                    raise ValueError("background completion record unavailable")
            else:
                yield value["output_id"], value["record"]
        for item in value.values():
            if isinstance(item, (dict, list)):
                yield from background_launches(item)
        if value.get("type") == "text":
            yield from background_launches(value.get("text", ""))


def observe_jobs(out, jobs):
    for path in sorted((out/"observations").glob("*.json")):
        data = json.loads(path.read_text())
        if data.get("tool_name") != "mcp__codescout__run_command":
            continue
        for handle, record in background_launches(data.get("tool_response")):
            if handle in jobs and jobs[handle]["record"] != record:
                raise ValueError("background handle reused by another server")
            jobs.setdefault(handle, {"handle":handle, "record":record, "delivered":False})


def validate_record(record, handle):
    if not isinstance(record, dict) or record.get("schema") != 1 or record.get("handle") != handle:
        raise ValueError("missing or mismatched job record")
    state = record.get("state")
    code = record.get("exit_code")
    if state not in ("running", "exited", "failed"):
        raise ValueError("unknown job state")
    if code is not None and (type(code) is not int or state != "exited"):
        raise ValueError("malformed job exit code")
    return {k:record.get(k) for k in ("handle","state","exit_code","error","command")}


def run_session(argv, *, cwd, env, prompt, session_id, out, read_record,
                timeout_s=900, max_continuations=4, completion_check=None, terminal_observer=None, before_client_cleanup=None, guard=None, client_observer=None):
    """Run stream-json; read_record must be bounded and scoped to the worker."""
    out = pathlib.Path(out)
    if timeout_s <= 0 or max_continuations < 0:
        raise ValueError("invalid lifecycle bounds")
    deadline = time.monotonic()+timeout_s
    events = deque()
    pending_bytes = b""
    jobs = {}
    turns = []
    cost = Decimal("0")
    error = None
    continuations = 0
    proc = None
    snapshot_started = False

    def snapshot():
        nonlocal snapshot_started
        if not snapshot_started and before_client_cleanup is not None:
            snapshot_started = True
            before_client_cleanup()

    def remaining():
        if guard is not None:
            guard()
        left = deadline-time.monotonic()
        if left <= 0:
            raise TimeoutError("lifecycle deadline exceeded")
        return left

    def send(content):
        data = (json.dumps({"type":"user","session_id":session_id,
            "message":{"role":"user","content":content}})+"\n").encode()
        fd = proc.stdin.fileno()
        while data:
            _, writable, _ = select.select([], [fd], [], min(.05,remaining()))
            if writable:
                try:
                    written = os.write(fd,data)
                except BlockingIOError:
                    continue
                data = data[written:]

    try:
        with (out/"stream.jsonl").open("x") as stream, (out/"stream-stderr.log").open("x") as stderr:
            if guard is not None:
                guard()
            proc = subprocess.Popen(argv, cwd=cwd, env=env,
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr,
                start_new_session=True, bufsize=0)
            if client_observer is not None:
                client_observer(proc)
            os.set_blocking(proc.stdin.fileno(),False)
            os.set_blocking(proc.stdout.fileno(),False)
            send(prompt)
            while True:
                left = remaining()
                if not events:
                    readable, _, _ = select.select([proc.stdout.fileno()],[],[],min(.05,left))
                    if not readable:
                        continue
                    try:
                        chunk = os.read(proc.stdout.fileno(),65536)
                    except BlockingIOError:
                        continue
                    if not chunk:
                        raise ValueError("client exited before lifecycle settlement")
                    pending_bytes += chunk
                    while b"\n" in pending_bytes:
                        line, pending_bytes = pending_bytes.split(b"\n",1)
                        events.append(json.loads(line))
                    continue
                event = events.popleft()
                stream.write(json.dumps(event)+"\n");stream.flush()
                if not isinstance(event,dict):
                    raise ValueError("malformed client stream")
                if event.get("type") != "result":
                    continue
                if event.get("session_id") != session_id:
                    raise ValueError("client session identity changed")
                total = Decimal(str(event["total_cost_usd"]))
                if not total.is_finite() or total < cost:
                    raise ValueError("invalid or regressing cumulative cost")
                cost = total
                turns.append(event)
                if terminal_observer is not None:
                    terminal_observer(event)
                if event.get("is_error") is not False or event.get("subtype") != "success":
                    raise ValueError("CLI turn did not succeed")
                observe_jobs(out, jobs)
                pending = [j for j in jobs.values() if not j["delivered"]]
                if not pending:
                    feedback = completion_check(remaining()) if completion_check is not None else None
                    remaining()
                    if feedback is None:
                        break
                    if not isinstance(feedback,str) or not feedback.strip():
                        raise ValueError("invalid public verification feedback")
                    if continuations >= max_continuations:
                        raise ValueError("continuation limit reached with failed public verification")
                    send("[harness public verification]\n"+feedback)
                    continuations += 1
                    continue
                if continuations >= max_continuations:
                    raise ValueError("continuation limit reached with undelivered jobs")
                while True:
                    remaining()
                    for job in pending:
                        job["outcome"] = validate_record(read_record(job["record"]), job["handle"])
                        remaining()
                    if all(j["outcome"]["state"] != "running" for j in pending):
                        break
                    if proc.poll() is not None:
                        raise ValueError("client exited with pending jobs")
                    time.sleep(min(.05,remaining()))
                outcomes = [j["outcome"] for j in pending]
                send("[harness background completion]\n"+json.dumps(outcomes)+
                     "\nRead each original handle with run_command(\"tail -50 @bg_HANDLE\"). "
                     "Continue the original task and remaining checks; report failures truthfully.")
                continuations += 1
                for job in pending:
                    job["delivered"] = True
            snapshot()
            proc.stdin.close()
            proc.wait(timeout=remaining())
            if proc.returncode != 0:
                raise ValueError("client process exit was nonzero")
    except Exception as exc:
        error = type(exc).__name__+": "+str(exc)
    finally:
        try:
            snapshot()
        except Exception as exc:
            if error is None:
                error = type(exc).__name__+": "+str(exc)
        if proc is not None:
            # A dead leader may still have descendants holding pipes or running jobs.
            # Reap only this launch's isolated process group, never process-name matches.
            try:
                os.killpg(proc.pid,signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                proc.wait(timeout=.2)
            except subprocess.TimeoutExpired:
                pass
            try:
                os.killpg(proc.pid,signal.SIGKILL)
            except ProcessLookupError:
                pass
            proc.wait()
            if proc.stdin and not proc.stdin.closed:
                proc.stdin.close()
            if proc.stdout:
                proc.stdout.close()
    receipt = {"status":"incomplete" if error else "settled", "error":error,
        "session_id":session_id, "client_pid":proc.pid if proc else None,
        "exit_code":proc.returncode if proc else None, "continuations":continuations,
        "cost_usd":str(cost), "cost_is_final":error is None,
        "turns":len(turns), "jobs":list(jobs.values()),
        "all_jobs_succeeded":not error and all(j.get("outcome",{}).get("state")=="exited"
            and j["outcome"]["exit_code"]==0 for j in jobs.values())}
    (out/"lifecycle-receipt.json").write_text(json.dumps(receipt, indent=2)+"\n")
    return receipt
