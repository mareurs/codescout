"""PostToolUse receipt capture. No model call, hint, or job execution."""
import json
import os
import pathlib
import sys
import uuid


def main():
    data = json.load(sys.stdin)
    if data.get("tool_name") == "mcp__codescout__run_command":
        root = pathlib.Path(os.environ["AGENT_LIFECYCLE_OBSERVATIONS"])
        root.mkdir(parents=True, exist_ok=True)
        name = uuid.uuid4().hex
        tmp = root/(name+".tmp")
        tmp.write_text(json.dumps(data))
        tmp.replace(root/(name+".json"))
    print("{}")


if __name__ == "__main__":
    main()
