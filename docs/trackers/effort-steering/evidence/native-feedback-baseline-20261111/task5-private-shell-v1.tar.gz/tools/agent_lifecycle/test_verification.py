"""Verification is command execution, never a model's success claim."""
import json
import pathlib
import subprocess
import sys
import tempfile
import unittest

try:
    from verification import PublicVerifier, validate_checks
except ImportError:
    PublicVerifier = validate_checks = None

class VerificationTests(unittest.TestCase):
    def test_manifest_rejects_empty_duplicate_and_missing_commands(self):
        self.assertIsNotNone(validate_checks,"manifest verifier missing")
        for checks in ([],[{"id":"x","command":""}],[{"id":"x","command":"true"},{"id":"x","command":"false"}]):
            with self.subTest(checks=checks),self.assertRaises(ValueError):
                validate_checks(checks)

    def test_every_command_runs_and_final_round_is_observed_after_repair(self):
        self.assertIsNotNone(PublicVerifier,"public verifier missing")
        with tempfile.TemporaryDirectory() as temp:
            root=pathlib.Path(temp)
            checks=[{"id":"format","command":"printf FORMAT"},
                    {"id":"compile","command":"test -f repaired"},
                    {"id":"lean","command":"printf LEAN"},
                    {"id":"default","command":"printf DEFAULT"}]
            def execute(command,log,timeout_s):
                with log.open("wb") as output:
                    return subprocess.run(["/bin/sh","-c",command],cwd=root,
                        stdout=output,stderr=subprocess.STDOUT,timeout=timeout_s).returncode
            verifier=PublicVerifier(root,checks,execute)
            feedback=verifier(10)
            self.assertIn("compile",feedback)
            first=json.loads((root/"public-verification.json").read_text())
            self.assertFalse(first["passed"])
            self.assertEqual([r["exit_code"] for r in first["checks"]],[0,1,0,0])
            (root/"repaired").touch()
            self.assertIsNone(verifier(10))
            final=json.loads((root/"public-verification.json").read_text())
            self.assertTrue(final["passed"])
            self.assertEqual(final["round"],1)
            self.assertTrue((root/"verification-0/receipt.json").exists())
            self.assertEqual([r["exit_code"] for r in final["checks"]],[0,0,0,0])
            self.assertEqual((root/"verification-1/3.log").read_text(),"DEFAULT")

    def test_unknown_result_persists_partial_round_and_never_passes(self):
        self.assertIsNotNone(PublicVerifier,"public verifier missing")
        with tempfile.TemporaryDirectory() as temp:
            root=pathlib.Path(temp)
            def unknown(command,log,timeout_s):
                log.write_text("no terminal result")
                return None
            verifier=PublicVerifier(root,[{"id":"compile","command":"check"}],unknown)
            with self.assertRaises(ValueError):
                verifier(10)
            receipt=json.loads((root/"public-verification.json").read_text())
            self.assertFalse(receipt["passed"])
            self.assertEqual(receipt["status"],"incomplete")
            self.assertTrue(receipt["error"])
class DeadlineVerificationTests(unittest.TestCase):
    def test_backend_return_after_deadline_is_incomplete(self):
        import time
        with tempfile.TemporaryDirectory() as temp:
            root=pathlib.Path(temp)
            def slow(command,log,timeout_s):
                log.write_text("late success")
                time.sleep(.03)
                return 0
            verifier=PublicVerifier(root,[{"id":"compile","command":"slow"}],slow)
            with self.assertRaises(TimeoutError):
                verifier(.005)
            receipt=json.loads((root/"public-verification.json").read_text())
            self.assertFalse(receipt["passed"])
            self.assertEqual(receipt["status"],"incomplete")

if __name__=="__main__":unittest.main()
