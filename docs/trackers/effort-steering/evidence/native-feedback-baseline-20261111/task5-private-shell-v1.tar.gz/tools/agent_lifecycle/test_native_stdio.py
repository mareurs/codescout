"""Per-connection native transport preserves stderr and leaves cleanup to the owner."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

WRAPPER = Path(__file__).with_name("native_stdio.py")


class NativeStdioTests(unittest.TestCase):
    def setUp(self):
        self.assertTrue(WRAPPER.is_file(), "owned native stdio is not implemented")
        self.temp = tempfile.TemporaryDirectory(prefix="native-stdio-test-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        binary = self.root / "bin"
        binary.mkdir()
        docker = binary / "docker"
        docker.write_text("#!/usr/bin/python3\nimport json,os,sys\n"
            "print('mcp-stdout',flush=True)\n"
            "print('native-stderr',file=sys.stderr,flush=True)\n"
            "print(json.dumps({'argv':sys.argv[1:],'auth':os.environ.get('CLAUDE_CODE_OAUTH_TOKEN')}),"
            "file=open(" + repr(str(self.root / "docker-called.json")) + ",'w'))\n"
            "raise SystemExit(7)\n")
        docker.chmod(0o700)
        self.env = dict(os.environ, PATH=str(binary)+os.pathsep+os.defpath,
                        CLAUDE_CODE_OAUTH_TOKEN="synthetic-secret-must-not-forward")
        self.argv = ["docker","run","--name","placeholder","--label","codescout.hfa=placeholder",
                     "sha256:"+"a"*64,"start","--project","/testbed"]
        (self.root/"mcp-native-argv.json").write_text(json.dumps(self.argv))

    def invoke(self):
        return subprocess.run([sys.executable,"-I","-B",str(WRAPPER),str(self.root)],
                              capture_output=True,text=True,env=self.env,timeout=15)

    def test_retains_unique_native_stderr_and_exit_without_auto_removal(self):
        result = self.invoke()
        self.assertEqual(result.returncode, 7, result.stderr)
        self.assertEqual(result.stdout, "mcp-stdout\n")
        launches = list(self.root.glob("mcp-launch-*.json"))
        self.assertEqual(len(launches), 1)
        launch = json.loads(launches[0].read_bytes())
        self.assertNotIn("--rm", launch["argv"])
        self.assertRegex(launch["name"], r"^hfa-native-[0-9a-f]{32}$")
        self.assertIn("codescout.hfa="+launch["name"], launch["argv"])
        stderr = self.root/("native-stderr-"+launch["name"]+".log")
        self.assertEqual(stderr.read_text(), "native-stderr\n")
        self.assertEqual(stderr.stat().st_mode & 0o777, 0o600)
        self.assertEqual(json.loads((self.root/("mcp-exit-"+launch["name"]+".json")).read_bytes())["exit_code"], 7)
        self.assertIsNone(json.loads((self.root/"docker-called.json").read_bytes())["auth"])

    def test_second_connection_cannot_overwrite_first_stderr(self):
        self.invoke()
        first = {path.name:path.read_bytes() for path in self.root.glob("native-stderr-*.log")}
        self.assertEqual(len(first), 1)
        self.invoke()
        self.assertEqual(len(list(self.root.glob("native-stderr-*.log"))), 2)
        for name, raw in first.items():
            self.assertEqual((self.root/name).read_bytes(), raw)

    def test_auto_remove_input_is_refused_before_docker(self):
        self.argv.insert(2, "--rm")
        (self.root/"mcp-native-argv.json").write_text(json.dumps(self.argv))
        result = self.invoke()
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse((self.root/"docker-called.json").exists())
        self.assertEqual(list(self.root.glob("mcp-launch-*.json")), [])

    def test_invalid_boundary_is_refused_before_docker(self):
        self.argv[0] = "unregistered-docker"
        (self.root/"mcp-native-argv.json").write_text(json.dumps(self.argv))
        result = self.invoke()
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse((self.root/"docker-called.json").exists())


if __name__=="__main__":
    unittest.main()
