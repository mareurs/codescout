"""Zero-provider actual-client lifecycle controls. No paid entry point."""
import hashlib
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import uuid

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent/"hint_authority_pilot"))
import run as worker
import transport
from session import run_session, background_launches


class NoCredential:
    def __getattr__(self, name):
        raise AssertionError("credential access forbidden in lifecycle qualification")


def no_upstream(*args, **kwargs):
    raise AssertionError("provider forwarding forbidden in lifecycle qualification")


def native_record(out, path, *, image=None):
    if not re.fullmatch(r"/tmp/codescout-bg/[0-9]+-[0-9a-f]+-bg_[0-9a-f]+\.json",path):
        raise ValueError("unexpected native job record path")
    owner_file = out/"record-owner.json"
    pinned = json.loads(owner_file.read_text()) if owner_file.exists() else None
    if pinned is not None and (not isinstance(pinned.get("container_id"),str) or not pinned["container_id"]):
        raise ValueError("native job owner lacks immutable ID")
    names = [pinned["name"]] if pinned else [
        json.loads(p.read_text())["name"] for p in out.glob("mcp-launch-*.json")]
    matches = []
    for name in names:
        inspected = subprocess.run(["docker","inspect",name],capture_output=True,text=True,timeout=5)
        if inspected.returncode:
            continue
        identity = json.loads(inspected.stdout)[0]
        container_id = identity.get("Id")
        if (identity["Image"] != (worker.IMAGE if image is None else image) or identity["Config"]["Labels"].get("codescout.hfa") != name
                or not isinstance(container_id,str) or not container_id
                or (pinned is not None and pinned["container_id"] != container_id)):
            raise ValueError("native job owner identity mismatch")
        result = subprocess.run(["docker","exec",container_id,"cat",path],text=True,
                                capture_output=True,timeout=5)
        if result.returncode == 0:
            matches.append((name,container_id,json.loads(result.stdout)))
    if len(matches) != 1:
        raise ValueError("native job record has no unique live owner")
    name,container_id,record = matches[0]
    if not pinned:
        owner_file.write_text(json.dumps({"name":name,"container_id":container_id}))
    with (out/"record-observations.jsonl").open("a") as f:
        f.write(json.dumps({"container":name,"container_id":container_id,"path":path,"record":record})+"\n")
    return record


def preserve_background_logs(out, *, max_bytes=64*1024*1024, timeout_s=15, image=None):
    """Copy bounded log snapshots before teardown; partial capture stays explicit."""
    import hashlib
    import time
    proof={"complete":True,"logs":[],"errors":[]}
    deadline=time.monotonic()+timeout_s
    try:
        observations=out/"record-observations.jsonl"
        if observations.exists():
            rows=[json.loads(line) for line in observations.read_text().splitlines() if line.strip()]
        else:
            rows=[]
        if rows:
            pinned=json.loads((out/"record-owner.json").read_text())
            container_id=pinned.get("container_id")
            if not isinstance(container_id,str) or not container_id:
                raise ValueError("background evidence owner lacks immutable ID")
            inspected=subprocess.run(["docker","inspect",pinned["name"]],
                capture_output=True,text=True,timeout=min(5,max(.001,deadline-time.monotonic())))
            if inspected.returncode:
                raise ValueError("background evidence owner unavailable")
            identity=json.loads(inspected.stdout)[0]
            if (identity["Id"]!=container_id or identity["Image"]!= (worker.IMAGE if image is None else image)
                    or identity["Config"]["Labels"].get("codescout.hfa")!=pinned["name"]):
                raise ValueError("background evidence owner identity mismatch")
            latest={}
            for row in rows:
                if row.get("container_id")!=container_id or row["container"]!=pinned["name"]:
                    raise ValueError("background observation owner mismatch")
                log_path=row["record"].get("log_path")
                if not isinstance(log_path,str) or not re.fullmatch(r"/tmp/codescout-bg-[A-Za-z0-9]+\.log",log_path):
                    raise ValueError("unexpected native background log path")
                latest[log_path]=row["record"]
            destination=out/"background-logs";destination.mkdir(exist_ok=True)
            for index,(log_path,record) in enumerate(sorted(latest.items())):
                try:
                    left=deadline-time.monotonic()
                    if left<=0:
                        raise TimeoutError("background evidence deadline exceeded")
                    copied=subprocess.run(["docker","exec",container_id,"head","-c",str(max_bytes+1),log_path],
                        capture_output=True,timeout=min(5,left))
                    if copied.returncode:
                        raise ValueError("native background log copy failed")
                    content=copied.stdout[:max_bytes]
                    path=destination/(str(index)+".log")
                    path.write_bytes(content)
                    truncated=len(copied.stdout)>max_bytes
                    proof["logs"].append(dict(native_path=log_path,saved_path=str(path),container_id=container_id,
                        bytes_saved=len(content),sha256=hashlib.sha256(content).hexdigest(),truncated=truncated,
                        observed_job_state=record.get("state")))
                    if truncated:
                        proof["errors"].append("native log exceeds capture byte limit: "+log_path)
                except Exception as exc:
                    proof["errors"].append(type(exc).__name__+": "+str(exc)[:500])
    except Exception as exc:
        proof["errors"].append(type(exc).__name__+": "+str(exc)[:500])
    proof["complete"]=not proof["errors"]
    worker.save(out/"background-evidence.json",proof)
    return proof

def cleanup_owned(out, timeout_s=30, *, image=None):
    import time
    pin=out/"record-owner.json"
    pinned=json.loads(pin.read_text()) if pin.exists() else None
    if pinned is not None and not pinned.get("container_id"):
        raise ValueError("container cleanup owner lacks immutable ID")
    records = []
    for launch in out.glob("mcp-launch-*.json"):
        name = json.loads(launch.read_text())["name"]
        inspected = subprocess.run(["docker","inspect",name],capture_output=True,text=True,timeout=5)
        removed = None
        if inspected.returncode == 0:
            row = json.loads(inspected.stdout)[0]
            if (row["Image"] != (worker.IMAGE if image is None else image) or row["Config"]["Labels"].get("codescout.hfa") != name
                    or (pinned is not None and pinned["name"]==name and pinned["container_id"]!=row["Id"])):
                raise ValueError("container cleanup identity mismatch")
            removed = subprocess.run(["docker","rm","-f",row["Id"]],capture_output=True,text=True,timeout=10)
        deadline = time.monotonic()+timeout_s
        while True:
            result = subprocess.run(["docker","inspect",name],capture_output=True,text=True,timeout=5)
            with (out/"cleanup-observations.jsonl").open("a") as trace:
                trace.write(json.dumps({"name":name,"inspect_exit_code":result.returncode,
                    "stderr":result.stderr,"remaining_s":deadline-time.monotonic()})+"\n")
            absent = result.returncode != 0 and "no such" in result.stderr.lower()
            if absent or time.monotonic()>=deadline:
                break
            time.sleep(min(.05,max(0,deadline-time.monotonic())))
        records.append({"name":name,"absent":absent,"remove_exit_code":removed.returncode if removed else None})
        worker.save(out/"cleanup.json",records)
        if not absent:
            raise ValueError("owned container remains after cleanup")
    return records


def cell(root, frozen, mode):
    out = root/mode; out.mkdir()
    actor = out/"project"
    shutil.copytree(frozen/"source",actor)
    nativehome = out/"native-home"; nativehome.mkdir()
    home = out/"client-home"; config = home/".claude"; config.mkdir(parents=True)
    global_md = (worker.P/"inputs/global-CLAUDE.md").read_text()
    (config/"CLAUDE.md").write_text(global_md)
    expected = {"effort":"low", "declaration":False, "clause":worker.CLAUSE,
                "global_visible":worker.visible(global_md),
                "project_visible":worker.visible((actor/"CLAUDE.md").read_text())}
    worker.save(out/"mcp-native-argv.json",worker.native_argv(actor,nativehome))
    worker.save(out/"mcp.json",{"mcpServers":{"codescout":{"command":"/usr/bin/python3",
        "args":["-B",str(worker.HERE/"stdio.py"),str(out)]}}})
    observations = out/"observations"; observations.mkdir()
    hook = "AGENT_LIFECYCLE_OBSERVATIONS="+str(observations)+" /usr/bin/python3 -B "+str(HERE/"observer.py")
    allowed = ["ToolSearch","mcp__codescout__run_command","mcp__codescout__create_file"]
    worker.save(out/"settings.json",{"permissions":{"allow":allowed},"hooks":{
        "PostToolUse":[{"matcher":"mcp__codescout__run_command","hooks":[{"type":"command","command":hook,"timeout":10}]}]}})
    sid = str(uuid.uuid4())
    marker = "LIFECYCLE_NATIVE_"+uuid.uuid4().hex
    exit_code = 7 if mode=="failed" else 0
    plan = [("mcp__codescout__run_command",{"command":"sleep 8; printf '"+marker+
        "\\n'; touch lifecycle-job-finished.txt; exit "+str(exit_code),"run_in_background":True})]
    original = transport.Proxy.scripted

    def scripted(self, body):
        if self.server.stage==1 and "[harness background completion]" in json.dumps(body):
            launches = []
            for p in observations.glob("*.json"):
                launches.extend(background_launches(json.loads(p.read_text()).get("tool_response")))
            if len(launches)!=1:
                raise ValueError("native launch not captured")
            handle = launches[0][0]
            self.server.plan = plan+[
                ("mcp__codescout__run_command",{"command":"tail -50 "+handle}),
                ("mcp__codescout__create_file",{"path":"lifecycle-agent-continued.txt",
                 "content":"same session retained task nonce "+sid+"\n"})]
        return original(self,body)

    transport.Proxy.scripted = scripted
    worker.TOKEN = NoCredential()
    transport.Proxy.upstream = no_upstream
    s = transport.server(out,expected,True,plan,campaign_remaining=0)
    argv = [str(worker.CLI),"-p","--model","claude-sonnet-5-5","--effort","low",
        "--session-id",sid,"--setting-sources","user,project,local","--settings",str(out/"settings.json"),
        "--strict-mcp-config","--mcp-config",str(out/"mcp.json"),"--permission-mode","acceptEdits",
        "--tools","ToolSearch","--allowedTools",",".join(allowed),"--input-format","stream-json",
        "--output-format","stream-json","--verbose","--max-turns","32","--max-budget-usd","0.65",
        "--plugin-dir",str(frozen/"skill-only-plugin")]
    env = {"HOME":str(home),"USER":"marius","LANG":"C.UTF-8","PATH":"/usr/local/bin:/usr/bin:/bin",
        "CLAUDE_CONFIG_DIR":str(config),"ANTHROPIC_BASE_URL":"http://127.0.0.1:"+str(s.server_port),
        "ANTHROPIC_API_KEY":"scripted-no-real-credential","DISABLE_AUTOUPDATER":"1",
        "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC":"1","CLAUDE_CODE_MAX_OUTPUT_TOKENS":"8192",
        "PYTHONDONTWRITEBYTECODE":"1"}
    worker.save(out/"launch.json",{"argv":argv,"session_id":sid,"real_credentials_read":False})
    try:
        receipt = run_session(argv,cwd=actor,env=env,prompt="Offline lifecycle probe; retain task nonce "+sid+
            ". Follow the scripted tool sequence; do not change source or onboard.",session_id=sid,
            out=out,read_record=lambda path:native_record(out,path),timeout_s=120,
            max_continuations=0 if mode=="negative" else 2)
    finally:
        s.shutdown();s.server_close();transport.Proxy.scripted = original
        cleanup_owned(out)
    launches = list(out.glob("mcp-launch-*.json"))
    results = [json.loads(p.read_text()) for p in out.glob("request-*.json")]
    tool_results = [b for request in results for msg in request.get("messages",[])
                    if msg.get("role")=="user" for b in msg.get("content",[])
                    if isinstance(b,dict) and b.get("type")=="tool_result"]
    original_handle_read = any(marker in json.dumps(b.get("content")) for b in tool_results)
    summary = {"mode":mode,"lifecycle":receipt,"forwarded":s.forwarded,"transport_errors":s.errors,
        "native_connections":len(launches),"native_original_handle_read":original_handle_read,
        "job_owner":json.loads((out/"record-owner.json").read_text()) if (out/"record-owner.json").exists() else None,
        "job_marker_exists":(actor/"lifecycle-job-finished.txt").exists(),
        "agent_continuation_marker_exists":(actor/"lifecycle-agent-continued.txt").exists(),
        "cleanup":json.loads((out/"cleanup.json").read_text())}
    worker.save(out/"summary.json",summary)
    if s.forwarded or s.errors or not launches or not all(r["absent"] for r in summary["cleanup"]):
        raise ValueError("transport or cleanup qualification failed")
    if mode=="negative":
        if receipt["status"]!="incomplete" or summary["job_marker_exists"] or summary["agent_continuation_marker_exists"]:
            raise ValueError("negative lifecycle control failed")
    elif receipt["status"]!="settled" or receipt["continuations"]!=1 or not original_handle_read or not summary["job_marker_exists"] or not summary["agent_continuation_marker_exists"] or receipt["all_jobs_succeeded"]!=(exit_code==0):
        raise ValueError("positive lifecycle control failed")
    return summary


def main():
    root = pathlib.Path(sys.argv[1]).resolve();root.mkdir()
    frozen = worker.P/"launch-budget-requalification-20261104"
    worker.save(root/"inputs.json",{"frozen":str(frozen),"provider_forwarding":"forbidden",
        "source_hashes":{p.name:hashlib.sha256(p.read_bytes()).hexdigest()
          for p in [HERE/"session.py",HERE/"observer.py",HERE/"qualify.py"]}})
    summaries = []
    for mode in ("negative","success","failed"):
        summaries.append(cell(root,frozen,mode))
        worker.save(root/"results.json",summaries)
    print(json.dumps({"qualified":True,"cells":len(summaries),"cost_usd":"0","root":str(root)}))


if __name__=="__main__":
    main()
