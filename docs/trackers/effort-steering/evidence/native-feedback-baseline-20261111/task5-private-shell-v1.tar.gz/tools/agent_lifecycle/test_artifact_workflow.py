"""Required final artifacts participate in settlement without losing billed cost."""
import json
import pathlib
import sys
import tempfile
import unittest
from decimal import Decimal
from types import SimpleNamespace
from unittest.mock import patch

import qualify
import workflow


class ArtifactWorkflowTests(unittest.TestCase):
    def exercise(self, capture):
        with tempfile.TemporaryDirectory() as temp:
            out = pathlib.Path(temp)
            (out / "hook").mkdir()
            (out / "settings.json").write_text("{}")
            (out / "launch.json").write_text("{}")
            client = out / "client.py"
            client.write_text("import json,sys\nfor line in sys.stdin:\n"
                " print(json.dumps(dict(type='result',subtype='success',is_error=False,"
                "session_id='sid',total_cost_usd=0.25)),flush=True)\n")
            order = []
            def check(root, image, command, log, timeout):
                log.write_text("public check passed")
                order.append("check")
                return 0
            def callback():
                order.append("capture")
                return capture(out)
            def cleanup(root, **kwargs):
                order.append("cleanup")
                self.assertIn("capture", order)
                self.assertTrue((out / "artifact-evidence.json").is_file())
                return []
            runtime = SimpleNamespace(IMAGE="sha256:fixture", save=qualify.worker.save,
                extract_result=qualify.worker.extract_result, audit_hooks=qualify.worker.audit_hooks)
            server = SimpleNamespace(budget=SimpleNamespace(pending=None, spent=Decimal(".25")),
                errors=[], budget_stop=None, forwarded=1, requests=[{}], scripted=False, stage=0,
                shutdown=lambda: None, server_close=lambda: None)
            argv = [sys.executable, str(client), "--session-id", "sid", "--output-format",
                    "json", "--", "task"]
            try:
                with patch.object(workflow, "native_check", side_effect=check), \
                     patch.object(workflow, "cleanup_native", side_effect=cleanup):
                    receipt = workflow.execute(runtime,
                        {"checks": [{"id": "check", "command": "check"}], "timeout_s": 3},
                        out, out, argv, {}, server, "sid", out / "hook", Decimal(4),
                        capture_artifacts=callback)
            except TypeError as exc:
                self.fail("required artifact callback contract missing: " + str(exc))
            self.assertEqual(order, ["check", "capture", "cleanup"])
            self.assertEqual(receipt["cost_usd"], "0.25")  # local fixture, not a paid charge
            self.assertFalse(receipt["unknown_provider_cost"])
            self.assertIsNone(receipt["cleanup_error"])
            self.assertEqual(json.loads((out / "artifact-evidence.json").read_text()),
                             receipt["artifact_evidence"])
            return receipt

    def test_candidate_is_saved_before_native_cleanup(self):
        def capture(out):
            (out / "candidate.patch").write_bytes(b"preserved diff")
            return {"complete": True, "path": str(out / "candidate.patch")}
        receipt = self.exercise(capture)
        self.assertTrue(receipt["workflow_completed"])
        self.assertTrue(receipt["artifact_evidence"]["complete"])

    def test_capture_exception_blocks_success_without_discarding_terminal_cost(self):
        def capture(out):
            raise ValueError("candidate export failed")
        receipt = self.exercise(capture)
        self.assertFalse(receipt["workflow_completed"])
        self.assertFalse(receipt["artifact_evidence"]["complete"])
        self.assertIn("candidate export failed", str(receipt["artifact_evidence"]["errors"]))

    def test_missing_false_and_non_boolean_completion_witness_cannot_pass(self):
        for value in (None, {"complete": False}, {"complete": 1}):
            with self.subTest(value=value):
                receipt = self.exercise(lambda out: value)
                self.assertFalse(receipt["workflow_completed"])
                self.assertFalse(receipt["artifact_evidence"]["complete"])
