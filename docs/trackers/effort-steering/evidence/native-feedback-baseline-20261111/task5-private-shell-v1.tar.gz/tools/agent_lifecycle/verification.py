"""Observe every configured public command against the idle worker's current candidate."""
import hashlib
import json
import pathlib
import time


def validate_checks(checks):
    if not isinstance(checks,list) or not checks:
        raise ValueError("nonempty public verification manifest required")
    ids=set()
    for check in checks:
        if not isinstance(check,dict) or not isinstance(check.get("id"),str) or not check["id"].strip():
            raise ValueError("check identity required")
        if check["id"] in ids:
            raise ValueError("duplicate check identity")
        if not isinstance(check.get("command"),str) or not check["command"].strip():
            raise ValueError("public check command required")
        ids.add(check["id"])
    return [{"id":c["id"],"command":c["command"]} for c in checks]


class PublicVerifier:
    def __init__(self,out,checks,execute):
        self.out=pathlib.Path(out)
        self.checks=validate_checks(checks)
        self.execute=execute
        self.round=0
        self.manifest_sha256=hashlib.sha256(json.dumps(self.checks,sort_keys=True).encode()).hexdigest()

    def __call__(self,remaining_s):
        deadline=time.monotonic()+remaining_s
        directory=self.out/("verification-"+str(self.round));directory.mkdir()
        receipt={"round":self.round,"manifest_sha256":self.manifest_sha256,
                 "status":"incomplete","passed":False,"checks":[],"error":None}
        self.round+=1
        try:
            for i,check in enumerate(self.checks):
                left=deadline-time.monotonic()
                if left<=0:
                    raise TimeoutError("public verification deadline")
                log=directory/(str(i)+".log")
                code=self.execute(check["command"],log,left)
                if type(code) is not int:
                    raise ValueError("public command has no known terminal exit code")
                receipt["checks"].append(dict(check,exit_code=code,log=str(log)))
                if time.monotonic()>deadline:
                    raise TimeoutError("public verification deadline")
            receipt["status"]="completed"
            receipt["passed"]=all(c["exit_code"]==0 for c in receipt["checks"])
        except Exception as exc:
            receipt["error"]=type(exc).__name__+": "+str(exc)
            raise
        finally:
            data=json.dumps(receipt,indent=2)+"\n"
            (directory/"receipt.json").write_text(data)
            (self.out/"public-verification.json").write_text(data)
        if receipt["passed"]:
            return None
        failed=[]
        for check in receipt["checks"]:
            if check["exit_code"]!=0:
                raw=pathlib.Path(check["log"]).read_bytes()
                failed.append({"id":check["id"],"command":check["command"],
                    "exit_code":check["exit_code"],"output_tail":raw[-8192:].decode("utf-8","replace")})
        return json.dumps({"public_verification_failed":failed,"instruction":
            "Repair the original task using this public feedback, then end your turn for a fresh full verification round."})
