"""Exercise both actual campaign loops with local terminal/grade fixtures."""
import contextlib,hashlib,io,json,pathlib,sys,tempfile,unittest
from decimal import Decimal
from unittest.mock import patch
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent.parent/'hint_authority_resume'))
import driver as resume
import run

def preflight(root):
    (root/'functional-controls-v2.json').write_text(json.dumps({'oracle_version':2,'fingerprint':'current','results':[{'exit_code':101},{'exit_code':0}]}))
    q={'fingerprint':'current','transport_errors':[],'hint_then_edit':True,'scripted_steps':8,'unknown_provider_cost':False,'exit_code':0,'terminal':{'is_error':False},'boundary_denied':True,'hint_visible_on_wire':True}
    for i in range(4):
        p=root/f'qualify-{i}';p.mkdir();(p/'receipt.json').write_text(json.dumps(q))
    (root/'review-accepted.json').write_text(json.dumps({'accepted':True,'fingerprint':'current'}))

class BudgetWiringTests(unittest.TestCase):
    def launcher(self,root,seen):
        actor=root/'actor';actor.mkdir()
        def one(label,effort,declaration,scripted,**kwargs):
            seen.append(kwargs.get('campaign_remaining'))
            out=root/label;out.mkdir()
            terminal={'type':'result','session_id':label,'total_cost_usd':'.2','is_error':False,'subtype':'success'}
            (out/'stdout.json').write_text(json.dumps(terminal))
            return {'session_id':label,'scripted':False,'cost_usd':'.2','exit_code':0,
              'terminal':{'is_error':False,'subtype':'success'},'wall_s':0,'requests':1,'forwarded':1,
              'transport_errors':[],'upper_usage_cost':'.22','unknown_provider_cost':False,
              'hint_then_edit':True,'scripted_steps':0,'actor':str(actor)}
        return one

    def test_regular_loop_passes_remaining_total_after_every_actual_cost(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);preflight(root);seen=[]
            with patch.object(run,'L',root),patch('audit.fingerprint',return_value='current'),patch.object(run,'prior_spend',return_value=Decimal('.5')),patch.object(run,'one',side_effect=self.launcher(root,seen)),patch.object(run,'grade',return_value={'exit_code':0}),patch('sys.argv',['run.py','paid']),contextlib.redirect_stdout(io.StringIO()):
                run.main()
            self.assertEqual(seen,[Decimal('3.5'),Decimal('3.3'),Decimal('3.1'),Decimal('2.9')])
            self.assertEqual(json.loads((root/'paid-results.json').read_text())['cost_usd'],'1.3')

    def test_resume_loop_uses_the_same_remaining_balance_policy(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);preflight(root);seen=[]
            (root/'paid-v2-results.json').write_text('{"cost_usd":".5","results":[]}')
            h=hashlib.sha256(pathlib.Path(resume.__file__).read_bytes()).hexdigest()
            (root/'resume-review.json').write_text(json.dumps({'accepted':True,'driver_sha256':h,'worker_fingerprint':'current'}))
            with patch.object(resume,'L',root),patch.object(resume,'fingerprint',return_value='current'),patch.object(resume,'prior_spend',return_value=Decimal('.5')),patch.object(resume,'one',side_effect=self.launcher(root,seen)),patch.object(resume,'grade',return_value={'exit_code':0}),contextlib.redirect_stdout(io.StringIO()):
                resume.main()
            self.assertEqual(seen,[Decimal('3.5'),Decimal('3.3'),Decimal('3.1'),Decimal('2.9')])
            self.assertEqual(json.loads((root/'paid-v2-results.json').read_text())['cost_usd'],'1.3')

    def test_paid_launch_rejects_missing_balance_before_any_credential_access(self):
        with tempfile.TemporaryDirectory() as d:
            with patch.object(run,'L',pathlib.Path(d)),patch.object(run,'TOKEN') as token:
                with self.assertRaises(ValueError):run.one('missing','low',False,False,campaign_remaining=None)
                token.stat.assert_not_called()
