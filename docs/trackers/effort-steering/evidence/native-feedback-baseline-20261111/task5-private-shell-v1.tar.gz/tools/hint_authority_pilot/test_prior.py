import json,pathlib,tempfile,unittest
from decimal import Decimal
from unittest.mock import patch
import run

class PriorTests(unittest.TestCase):
    def test_prior_abort_cost_is_counted_and_unknown_cost_stops(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d)
            out=root/'stdout.json';out.write_text(json.dumps({'type':'result','session_id':'s','total_cost_usd':'.16765020000000003'}))
            receipt=root/'receipt.json';receipt.write_text(json.dumps({'session_id':'s','cost_usd':'.16765020000000003','unknown_provider_cost':False}))
            (root/'prior-attempts.json').write_text(json.dumps({'attempts':[{'session_id':'s','receipt_path':str(receipt),'stdout_path':str(out)}]}))
            with patch.object(run,'L',root):
                self.assertEqual(run.prior_spend(),Decimal('.16765020000000003'))
                receipt.write_text(json.dumps({'session_id':'s','unknown_provider_cost':True}))
                with self.assertRaisesRegex(ValueError,'Unknown prior cost'):run.prior_spend()
    def test_paid_entrypoint_reserves_after_prior_spend(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d)
            (root/'functional-controls-v2.json').write_text(json.dumps({'oracle_version':2,'fingerprint':'current','results':[{'exit_code':101},{'exit_code':0}]}))
            q={'fingerprint':'current','transport_errors':[],'hint_then_edit':True,'scripted_steps':8,'unknown_provider_cost':False,'exit_code':0,'terminal':{'is_error':False},'boundary_denied':True,'hint_visible_on_wire':True}
            for i in range(4):
                p=root/f'qualify-{i}';p.mkdir();(p/'receipt.json').write_text(json.dumps(q))
            (root/'review-accepted.json').write_text(json.dumps({'accepted':True,'fingerprint':'current'}))
            with patch.object(run,'L',root),patch('audit.fingerprint',return_value='current'),patch.object(run,'prior_spend',return_value=Decimal('3.1')),patch.object(run,'one',side_effect=RuntimeError('ATTEMPTED MODEL')) as launch,patch('sys.argv',['run.py','paid']):
                run.main()
                launch.assert_not_called()
