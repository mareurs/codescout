"""Pure gates shared by offline qualification and paid launches."""
import json
from decimal import Decimal, InvalidOperation

def amount(value):
    try:
        n=Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise ValueError('Unknown cost') from None
    if not n.is_finite() or n<0: raise ValueError('Invalid cost')
    return n

def admit(spent, reserve, cap):
    return amount(spent)+amount(reserve)<=amount(cap)

def _ordered(text, lines):
    pos=0
    for line in lines:
        at=text.find(line,pos)
        if at<0: raise ValueError('Missing visible instruction: '+line[:80])
        pos=at+len(line)

def audit_request(request, expected):
    if request.get('model')!='claude-sonnet-5-5': raise ValueError('Unexpected model')
    if request.get('output_config',{}).get('effort')!=expected['effort']: raise ValueError('Effort mismatch')
    def flatten(x):
        if isinstance(x,str): return x
        if isinstance(x,list): return '\n'.join(flatten(v) for v in x)
        if isinstance(x,dict): return '\n'.join(flatten(v) for v in x.values())
        return ''
    system=flatten(request.get('system',[]))
    text=system+'\n'+flatten(request.get('messages',[]))
    if (expected['clause'] in text)!=expected['declaration']: raise ValueError('Authority clause mismatch')
    _ordered(text,expected['global_visible']); _ordered(text,expected['project_visible'])
    if 'preload_visible' in expected:
        lines=expected['preload_visible']
        if not isinstance(lines,list) or not lines or any(not isinstance(v,str) or not v.strip() for v in lines):
            raise ValueError('Nonempty prepared context expectation required')
        _ordered(system,lines)
    return True

def audit_hooks(events):
    triggered=False
    for event in events:
        if event.get('event')=='trigger' and event.get('carrier')=='context': triggered=True
        if event.get('event')=='edit' and triggered:return True
    return False

def extract_result(records,session_id):
    matches=[r for r in records if r.get('type')=='result']
    if len(matches)!=1: raise ValueError('Exactly one terminal result required')
    r=matches[0]
    if r.get('session_id')!=session_id: raise ValueError('Wrong session result')
    return dict(cost=amount(r.get('total_cost_usd')),is_error=r.get('is_error'),subtype=r.get('subtype'))
