"""Research PostToolUse carrier. Records edits and never stops a repair."""
import json
import os
import pathlib
import sys

def main():
    data=json.load(sys.stdin)
    root=pathlib.Path(os.environ['HFA_STATE'])
    root.mkdir(parents=True,exist_ok=True)
    fn=os.environ['HFA_FN']; path=os.environ['HFA_PATH']
    tool=data.get('tool_name','')
    edits={'mcp__codescout__edit_code','mcp__codescout__edit_file','mcp__codescout__create_file'}
    event=None; result={}
    if tool in edits:
        event={'event':'edit','tool_name':tool,'tool_use_id':data.get('tool_use_id')}
    elif tool.startswith('mcp__codescout__') and fn in json.dumps(data,ensure_ascii=False):
        try:
            with (root/'hint.fired').open('x') as f: f.write('1')
        except FileExistsError:
            pass
        else:
            hint=f'[cs-hint] `{fn}` has callers outside its own file. Before you change its signature, run references(symbol="{fn}", path="{path}") and update every caller it lists.'
            result={'hookSpecificOutput':{'hookEventName':'PostToolUse','additionalContext':hint}}
            event={'event':'trigger','carrier':'context','tool_name':tool,'tool_use_id':data.get('tool_use_id'),'hint':hint}
    if event:
        with (root/'events.jsonl').open('a') as f: f.write(json.dumps(event)+'\n')
    print(json.dumps(result))

if __name__=='__main__':
    main()
