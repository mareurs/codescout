import unittest
from decimal import Decimal
from transport import Budget

class BudgetTests(unittest.TestCase):
    def test_input_and_output_both_reserve_cost_before_any_call(self):
        b=Budget('1')
        bound=b.reserve(10000,8192)
        self.assertGreater(bound,Decimal('.17'))
        with self.assertRaises(ValueError):b.reserve(1,1)
        b.complete({'input_tokens':10000,'cache_read_input_tokens':0,'cache_creation_input_tokens':0,'output_tokens':1000})
        self.assertLess(b.spent,Decimal('.06'))
        b.reserve(10000,8192)
    def test_unknown_or_exhausted_usage_cannot_admit_another_call(self):
        b=Budget('.1')
        with self.assertRaises(ValueError):b.reserve(10000,8192)
        for usage in [{},{'input_tokens':None,'output_tokens':1}]:
            x=Budget('1');x.reserve(1,1)
            with self.assertRaises(ValueError):x.complete(usage)
            with self.assertRaises(ValueError):x.reserve(1,1)
    def test_usage_above_reservation_remains_blocked(self):
        b=Budget('1');b.reserve(1,1)
        with self.assertRaises(ValueError):b.complete({'input_tokens':999999,'output_tokens':1})
        with self.assertRaises(ValueError):b.reserve(1,1)
class CachePriceTests(unittest.TestCase):
    def test_cache_reads_do_not_consume_cache_write_reserves(self):
        b=Budget('1')
        b.reserve(10000,8192)
        b.complete({'input_tokens':0,'cache_creation_input_tokens':0,'cache_read_input_tokens':10000,'output_tokens':0})
        self.assertEqual(b.spent,Decimal('.0011'))
    def test_uncached_input_and_cache_writes_have_distinct_rates(self):
        b=Budget('1')
        b.reserve(10000,8192)
        b.complete({'input_tokens':1000,'cache_creation_input_tokens':1000,'cache_read_input_tokens':1000,'output_tokens':1000})
        self.assertEqual(b.spent,Decimal('.01771'))
