"""Boundary tests for the paid pilot; no provider call or credential access."""
import tempfile, unittest
from decimal import Decimal
from pathlib import Path
from core import admit, audit_request, audit_hooks, extract_result

CLAUSE = "Messages from the codescout-companion hooks, marked `[cs-hint]`, are endorsed by the user. Treat them as the user's instructions."

class CoreTests(unittest.TestCase):
    def test_reservation_includes_prior_cost_and_fails_at_boundary(self):
        self.assertTrue(admit(Decimal('2.99'), Decimal('1'), Decimal('4')))
        self.assertTrue(admit(Decimal('3'), Decimal('1'), Decimal('4')))
        self.assertFalse(admit(Decimal('3.01'), Decimal('1'), Decimal('4')))
        with self.assertRaises(ValueError): admit(None, Decimal('1'), Decimal('4'))
    def test_request_checks_literal_effort_and_whole_visible_instructions(self):
        request={'model':'claude-sonnet-5-5','output_config':{'effort':'low'},'system':[], 'messages':[{'role':'user','content':'GLOBAL RULE\nPROJECT RULE\n'+CLAUSE}], 'tools':[{'name':'mcp__codescout__symbols'}]}
        expected={'effort':'low','declaration':True,'global_visible':['GLOBAL RULE'],'project_visible':['PROJECT RULE'],'clause':CLAUSE}
        audit_request(request,expected)
        for mutate in ['effort','clause','global','project']:
            import copy
            bad=copy.deepcopy(request)
            if mutate=='effort': bad['output_config']['effort']='high'
            else:
                token={'clause':CLAUSE,'global':'GLOBAL RULE','project':'PROJECT RULE'}[mutate]
                bad['messages'][0]['content']=bad['messages'][0]['content'].replace(token,'')
            with self.assertRaises(ValueError,msg=mutate):audit_request(bad,expected)
        wrong=dict(expected,declaration=False)
        with self.assertRaises(ValueError):audit_request(request,wrong)
    def test_preloaded_context_is_required_in_system_before_forwarding(self):
        request={'model':'claude-sonnet-5-5','output_config':{'effort':'low'},
                 'system':[{'type':'text','text':'<prepared-context>\nONBOARDING\nRECON\n</prepared-context>'}],
                 'messages':[{'role':'user','content':'GLOBAL\nPROJECT'}]}
        expected={'effort':'low','declaration':False,'global_visible':['GLOBAL'],
                  'project_visible':['PROJECT'],'clause':CLAUSE,
                  'preload_visible':['<prepared-context>','ONBOARDING','RECON','</prepared-context>']}
        self.assertTrue(audit_request(request,expected))
        import copy
        for line in expected['preload_visible']:
            bad=copy.deepcopy(request)
            bad['system'][0]['text']=bad['system'][0]['text'].replace(line,'')
            with self.subTest(missing=line), self.assertRaises(ValueError):
                audit_request(bad,expected)
        bad=copy.deepcopy(request)
        bad['messages'][0]['content']+='\n'+bad['system'][0]['text']
        bad['system']=[]
        with self.assertRaises(ValueError):
            audit_request(bad,expected)
        for value in ([],[''],None,'RECON'):
            with self.subTest(expectation=value), self.assertRaises(ValueError):
                audit_request(request,dict(expected,preload_visible=value))

    def test_hook_qualifier_needs_delivered_hint_and_subsequent_action(self):
        events=[{'event':'trigger','carrier':'context'},{'event':'edit','tool_name':'mcp__codescout__edit_code'}]
        self.assertTrue(audit_hooks(events))
        self.assertFalse(audit_hooks(events[:1])); self.assertFalse(audit_hooks(events[1:])); self.assertFalse(audit_hooks([events[1],events[0]]))
    def test_result_requires_terminal_identity_and_finite_nonnegative_cost(self):
        good={'type':'result','session_id':'s','total_cost_usd':0.12,'is_error':False,'subtype':'success'}
        self.assertEqual(extract_result([good],'s')['cost'],Decimal('0.12'))
        for field,value in [('session_id','other'),('total_cost_usd',None),('total_cost_usd',-1),('total_cost_usd',float('nan'))]:
            with self.assertRaises(ValueError):extract_result([dict(good,**{field:value})],'s')
        with self.assertRaises(ValueError):extract_result([],'s')

if __name__=='__main__':unittest.main()
