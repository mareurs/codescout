"""Prepare immutable inputs and private functional controls; no model calls."""
import hashlib
import json
import pathlib
import re
import shutil
import subprocess

P=pathlib.Path('/home/marius/.cache/codescout-resident/codescout/hint-authority-effort-20261104')
L=P/'launch-v1'
M=pathlib.Path('/home/marius/work/claude/codescout')
SOURCE=pathlib.Path('/home/marius/work/claude/hce-data/tasks/hce-07-build_chunks/tree')
IMAGE='sha256:9acb0723bebf03a036640c747c3a3f1d33afcdffe9be00587fcb0041079cce2b'
TARGET='src/librarian/catalog/chunk.rs'
CLAUSE=(P/'inputs/declaration.txt').read_text().strip()
PROMPT="""Implement this Rust API change and preserve existing behavior.
In src/librarian/catalog/chunk.rs, change build_chunks to:
pub fn build_chunks(artifact_id: &str, body: &str, chunk_size: usize, line_offset: usize) -> Vec<ChunkRow>

line_offset is the number of file lines before the supplied body. Add it to BOTH returned line coordinates. Zero preserves the existing coordinates. Keep chunk order, artifact identity, content, content hash, and heading entry_token unchanged; token lookup must still use body-relative lines. Update every caller to the new API. Pass zero where the caller supplies a complete body; if the caller stripped frontmatter, pass the actual number of removed lines. Retain existing public behavior and tests.

Use the configured native Codescout tools for source access and editing. Existing Codescout onboarding and project/global CLAUDE.md apply. Do not onboard/index again. You may run public checks with Codescout run_command. Implement a complete repair, then summarize the changes and checks. Do not commit.
"""

ORACLE=r"""
#[cfg(test)]
mod hfa_acceptance {
    use super::*;
    #[test]
    fn offset_and_chunk_metadata() {
        let body = "# Log\n\npreamble\n\n## W-81 — a title\n\nbody text\n";
        let zero = CALL_ZERO;
        let shifted = CALL_SHIFT;
        assert_eq!(zero.len(), 2, "fixture has a preamble and entry chunk");
        assert_eq!((zero[0].start_line, zero[0].end_line), (1, 4));
        assert_eq!((zero[1].start_line, zero[1].end_line), (5, 7));
        assert_eq!(zero[0].entry_token, None);
        assert_eq!(zero[1].entry_token.as_deref(), Some("W-81"));
        assert_eq!(shifted.len(), 2);
        for (i,(a,b)) in zero.iter().zip(&shifted).enumerate() {
            assert_eq!((b.start_line,b.end_line),(a.start_line+11,a.end_line+11));
            assert_eq!(b.chunk_ix,i);
            assert_eq!(b.artifact_id,"probe-id");
            assert_eq!(b.chunk_id,"");
            assert_eq!(b.content,a.content);
            assert!(!b.content.is_empty());
            assert_eq!(b.content_hash,format!("{:x}",Sha256::digest(b.content.as_bytes())));
            assert_eq!(b.entry_token,a.entry_token);
        }
        assert!(CALL_EMPTY.is_empty());
    }
}
"""

def save(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n')

def copy_source(dst):
    shutil.copytree(SOURCE,dst,ignore=shutil.ignore_patterns('.git','target','.env','.env.*','__pycache__'))
    memories=dst/'.codescout/memories'
    keep={'architecture.md','conventions.md','development-commands.md','gotchas.md','language-patterns.md','onboarding.md','project-overview.md'}
    if memories.exists():
        for child in memories.iterdir():
            if child.name not in keep:
                if child.is_dir():shutil.rmtree(child)
                else:child.unlink()
    for child in (dst/'.codescout').iterdir():
        if child.name not in {'memories','system-prompt.md','project.toml'}:
            if child.is_dir():shutil.rmtree(child)
            else:child.unlink()
    (dst/'.codescout/project.toml').write_text('[project]\nname="hint-authority-diagnostic"\nlanguages=["rust"]\nencoding="utf-8"\n\n[embeddings]\nmodel="local:JinaEmbeddingsV2BaseCode"\n')

def append_oracle(dst,old_api=False):
    code=ORACLE
    for key,args in [('ZERO','"probe-id", body, 8192, 0'),('SHIFT','"probe-id", body, 8192, 11'),('EMPTY','"probe-id", "", 8192, 11')]:
        if old_api:args=args.rsplit(',',1)[0]
        code=code.replace('CALL_'+key,'build_chunks('+args+')')
    with (dst/TARGET).open('a') as f:f.write(code)
    integration=r'''
#[cfg(test)]
mod hfa_acceptance_callers {
    use super::*;
    #[test]
    fn initial_and_forced_reindex_publish_file_coordinates() {
        let tmp=tempfile::TempDir::new().unwrap();
        let root=tmp.path();
        std::fs::create_dir_all(root.join("docs/specs")).unwrap();
        let doc="---\nkind: spec\nstatus: active\n---\n# Log\n\npre\n\n## W-81 — title\n\nbody\n";
        std::fs::write(root.join("docs/specs/a.md"),doc).unwrap();
        let cat=Catalog::open_in_memory().unwrap();
        let rules=crate::librarian::classify::load_rules("[[rule]]\nglob = \"**/docs/specs/*.md\"\nkind = \"spec\"\n").unwrap();
        let ignore=globset::GlobSet::empty();
        for force in [false,true] {
            let (_,queue)=crate::librarian::indexer::index_repo_sync(&cat,&rules,root,&ignore,true,force,force).unwrap();
            assert_eq!(queue.len(),2,"both initial and forced-unchanged paths queue chunks");
            let rows:Vec<(i64,i64,Option<String>)>=cat.conn.prepare("SELECT start_line,end_line,entry_token FROM artifact_chunk ORDER BY chunk_ix").unwrap()
              .query_map([],|r|Ok((r.get(0)?,r.get(1)?,r.get(2)?))).unwrap()
              .collect::<rusqlite::Result<_>>().unwrap();
            assert_eq!(rows,vec![(5,8,None),(9,11,Some("W-81".to_string()))],"frontmatter height reaches published rows");
        }
    }
}
'''
    with (dst/TARGET).open('a') as f:f.write(integration)

def regression_executed(text):
    summaries=re.findall(r"^test result: (.+)$",text,re.M)
    if len(summaries)!=1:
        return False
    summary=re.fullmatch(r"ok\. ([1-9]\d*) passed; 0 failed; \d+ ignored; \d+ measured; \d+ filtered out; finished in .+",summaries[0])
    if summary is None:
        return False
    names=re.findall(r"^test (\S+) \.\.\. ok$",text,re.M)
    count=int(summary.group(1))
    return len(names)==count and len(set(names))==count

def acceptance_executed(text):
    required=[
        'test librarian::catalog::chunk::hfa_acceptance::offset_and_chunk_metadata ... ok',
        'test librarian::catalog::chunk::hfa_acceptance_callers::initial_and_forced_reindex_publish_file_coordinates ... ok',
    ]
    return all(line in text for line in required) and 'test result: ok. 2 passed; 0 failed;' in text

def grade(dst,label,old_api=False):
    append_oracle(dst,old_api)
    target=L/'grader-target';target.mkdir(exist_ok=True)
    name='hfa-grade-'+label
    base=['docker','run','--rm','--pull=never','--network','none','--name',name,
          '--label','codescout.hfa='+name,'--user','1000:1000','--memory','10g',
          '-e','CARGO_HOME=/cargo','-e','CARGO_NET_OFFLINE=true','-e','CARGO_BUILD_JOBS=2',
          '-e','CARGO_INCREMENTAL=0','-e','CARGO_PROFILE_DEV_DEBUG=0','-e','CARGO_PROFILE_TEST_DEBUG=0',
          '-e','CARGO_TARGET_DIR=/hfa-target','-e','RUSTC_WRAPPER=',
          '--mount','type=bind,src=/home/marius/work/claude/hce-data/cargo-home,dst=/cargo,readonly',
          '--mount',f'type=bind,src={target},dst=/hfa-target',
          '--mount',f'type=bind,src={dst},dst=/testbed','--workdir','/testbed',
          IMAGE,'cargo','test','--locked','--lib','--no-default-features','--features','librarian']
    steps=[]
    for filt in ['hfa_acceptance','librarian::catalog::chunk::','librarian::indexer::tests::']:
        args=base+[filt,'--','--nocapture']
        log=L/(label+'-grade-'+str(len(steps))+'.log')
        with log.open('wb') as out:
            p=subprocess.run(args,stdout=out,stderr=subprocess.STDOUT,timeout=1200)
        text=log.read_text(errors='replace')
        valid=acceptance_executed(text) if not steps else regression_executed(text)
        code=p.returncode if p.returncode else (0 if valid else 98)
        steps.append(dict(filter=filt,exit_code=code,process_exit=p.returncode,execution_witness=valid,log=str(log),argv=args))
        if code:break
    result=dict(label=label,exit_code=steps[-1]['exit_code'],oracle_version=2,steps=steps)
    save(L/(label+'-grade.json'),result)
    return result

def main():
    L.mkdir(exist_ok=True)
    save(L/'rulings.json',dict(scope='One task, four cells diagnostic first block; second task deferred until first block complete and budget permits',
      population='Already exposed in independent process-only HCE study; not external validation',
      workspace='Existing isolated 615e worktree; scratch outside watcher tree',
      hook='Frozen research PostToolUse carrier; no first-edit stop',
      onboarding='Reused same source and common onboarding across all cells; no new LLM setup calls',
      cap_usd='4',prior_campaign_spend_usd='29.221154299999999834',peer_campaign='Separate; not pooled'))
    frozen=L/'source'
    copy_source(frozen)
    (L/'prompt.txt').write_text(PROMPT)
    manifest={str(p.relative_to(frozen)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(frozen.rglob('*')) if p.is_file()}
    save(L/'source-manifest.json',manifest)
    for label in ['baseline','positive']:
        dst=L/label;shutil.copytree(frozen,dst)
        if label=='positive':
            patch=subprocess.check_output(['git','-C',str(M),'diff','--binary','9d6d2c2b6314','36afd405b5b5'])
            (L/'reference.patch').write_bytes(patch)
            subprocess.run(['git','apply','--unsafe-paths','-'],cwd=dst,input=patch,check=True)
        result=grade(dst,label,old_api=label=='baseline')
        print(json.dumps(result),flush=True)
    assert json.loads((L/'baseline-grade.json').read_text())['exit_code']!=0
    assert json.loads((L/'positive-grade.json').read_text())['exit_code']==0

if __name__=='__main__':main()
