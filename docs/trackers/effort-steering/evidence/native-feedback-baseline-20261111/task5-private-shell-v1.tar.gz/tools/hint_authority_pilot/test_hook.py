import importlib.util,json,os,pathlib,subprocess,sys,tempfile,unittest
HERE=pathlib.Path(__file__).resolve().parent

class HookTests(unittest.TestCase):
 def test_hint_is_delivered_and_edits_do_not_stop_the_worker(self):
  with tempfile.TemporaryDirectory() as d:
   env={**os.environ,'HFA_STATE':d,'HFA_FN':'build_chunks','HFA_PATH':'src/librarian/catalog/chunk.rs'}
   event={'tool_name':'mcp__codescout__symbols','tool_use_id':'read1','tool_input':{'name':'build_chunks'},'tool_response':{'content':[{'type':'text','text':'build_chunks body'}]}}
   p=subprocess.run([sys.executable,str(HERE/'pilot_hook.py')],input=json.dumps(event),env=env,capture_output=True,text=True)
   self.assertEqual(p.returncode,0,p.stderr)
   self.assertIn('[cs-hint]',json.loads(p.stdout)['hookSpecificOutput']['additionalContext'])
   event.update(tool_name='mcp__codescout__edit_code',tool_use_id='edit1')
   p=subprocess.run([sys.executable,str(HERE/'pilot_hook.py')],input=json.dumps(event),env=env,capture_output=True,text=True)
   self.assertEqual(json.loads(p.stdout),{})
   events=[json.loads(l) for l in (pathlib.Path(d)/'events.jsonl').read_text().splitlines()]
   self.assertEqual([e['event'] for e in events],['trigger','edit'])
   self.assertFalse(any(e.get('continue') is False for e in events))
if __name__=='__main__':unittest.main()
