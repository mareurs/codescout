"""Request guards must stop even unmetered counting and the last upstream hop."""
import http.client
import json
import pathlib
import tempfile
import types
import unittest
from unittest.mock import patch

import transport


class RequestGuardTests(unittest.TestCase):
    def test_unhealthy_runtime_blocks_count_endpoint_before_scripted_response(self):
        with tempfile.TemporaryDirectory() as d:
            server = transport.server(pathlib.Path(d), {}, True, [])
            def fail():
                raise ValueError("runtime unavailable")
            server.request_guard = fail
            try:
                conn = http.client.HTTPConnection("127.0.0.1", server.server_port, timeout=3)
                conn.request("POST", "/v1/messages/count_tokens", body=b"{}",
                             headers={"Content-Type": "application/json"})
                response = conn.getresponse()
                body = json.loads(response.read())
                conn.close()
                self.assertEqual(response.status, 400)
                self.assertIn("runtime unavailable", body["error"]["message"])
                self.assertEqual(server.stage, 0)
                self.assertEqual(server.forwarded, 0)
            finally:
                server.shutdown()
                server.server_close()

    def test_guard_rechecks_immediately_before_upstream_contact(self):
        handler = object.__new__(transport.Proxy)
        def fail():
            raise ValueError("fault after entry")
        handler.server = types.SimpleNamespace(request_guard=fail)
        handler.headers = {}
        with patch.object(http.client, "HTTPSConnection",
                          side_effect=AssertionError("provider must never be contacted")):
            with self.assertRaisesRegex(ValueError, "fault after entry"):
                handler.upstream("/v1/messages", {})


if __name__ == "__main__":
    unittest.main()
