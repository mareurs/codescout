import copy
import unittest
from audit import validate_preflight
class PreflightTests(unittest.TestCase):
    def test_stale_review_and_old_oracle_and_missing_delivery_block_spend(self):
        controls={'oracle_version':2,'fingerprint':'current','results':[{'exit_code':101},{'exit_code':0}]}
        q={'fingerprint':'current','transport_errors':[],'hint_then_edit':True,'scripted_steps':8,'unknown_provider_cost':False,'exit_code':0,'terminal':{'is_error':False},'boundary_denied':True,'hint_visible_on_wire':True}
        review={'accepted':True,'fingerprint':'current'}
        validate_preflight(controls,[q]*4,review,'current')
        with self.assertRaises(ValueError):validate_preflight(controls,[q]*4,review,'changed')
        with self.assertRaises(ValueError):validate_preflight(dict(controls,oracle_version=1),[q]*4,review,'current')
        with self.assertRaisesRegex(ValueError,'Stale functional'):validate_preflight(dict(controls,fingerprint='stale'),[q]*4,review,'current')
        for field,value in [('fingerprint','old'),('boundary_denied',False),('hint_visible_on_wire',False),('unknown_provider_cost',True),('exit_code',1),('terminal',{'is_error':True})]:
            bad=dict(q,**{field:value})
            with self.assertRaises(ValueError,msg=field):validate_preflight(controls,[bad]*4,review,'current')
