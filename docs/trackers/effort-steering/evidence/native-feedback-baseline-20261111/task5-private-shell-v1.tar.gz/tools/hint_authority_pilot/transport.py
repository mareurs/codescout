"""Capture actual requests, fail closed on identity/context/cost, forward without logging headers."""
import http.client
import http.server
import json
import threading
from decimal import Decimal
from core import amount, audit_request

class BudgetExhausted(ValueError):
    """Known campaign-envelope exhaustion, distinct from transport/unknown cost."""
    pass

class Budget:
    # Conservative rates: highest cache write + US multiplier, with 2x counted input.
    # Input count is an API estimate, not an invoice; actual terminal CLI cost is separate.
    def __init__(self,cap):
        self.cap=amount(cap);self.spent=Decimal('0');self.pending=None
    def reserve(self,input_tokens,max_tokens):
        if self.pending is not None:raise ValueError('Pending/unknown provider cost')
        n=amount(input_tokens);out=amount(max_tokens)
        bound=(2*n+1024)*Decimal('.0000044')+out*Decimal('.000011')
        if self.spent+bound>self.cap:raise BudgetExhausted('Campaign budget cannot reserve the next request')
        self.pending=bound
        return bound
    def complete(self,usage):
        if self.pending is None:raise ValueError('No reservation')
        if usage.get('speed','standard')!='standard':raise ValueError('Unpriced provider speed')
        actual=(amount(usage.get('input_tokens'))*Decimal('.0000022')
          +amount(usage.get('cache_creation_input_tokens',0))*Decimal('.0000044')
          +amount(usage.get('cache_read_input_tokens',0))*Decimal('.00000011')
          +amount(usage.get('output_tokens'))*Decimal('.000011'))
        if actual>self.pending:raise ValueError('Observed usage exceeded reservation')
        self.spent+=actual;self.pending=None

class Proxy(http.server.BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def reject(self,reason,*,budget=False):
        if budget:
            self.server.budget_stop={'reason':reason,'campaign_available_usd':str(self.server.budget.cap),'upper_usage_cost':str(self.server.budget.spent)}
            (self.server.out/'budget-stop.json').write_text(json.dumps(self.server.budget_stop))
        else:self.server.errors.append(reason)
        self.send_response(400);self.send_header('Content-Type','application/json');self.end_headers()
        self.wfile.write(json.dumps({'type':'error','error':{'type':'invalid_request_error','message':reason}}).encode())
    def upstream(self,path,body):
        guard = getattr(self.server, 'request_guard', None)
        if guard is not None: guard()
        headers={k:v for k,v in self.headers.items() if k.lower() not in {'host','content-length','connection','accept-encoding'}}
        headers['Content-Type']='application/json'
        conn=http.client.HTTPSConnection('api.anthropic.com',timeout=180)
        conn.request('POST',path,body=json.dumps(body).encode(),headers=headers)
        return conn,conn.getresponse()
    def do_POST(self):
        with self.server.lock:
            try:self.handle_request()
            except BudgetExhausted as e:self.reject(str(e),budget=True)
            except Exception as e:
                # Never include upstream auth headers or raw network exception repr.
                self.reject(type(e).__name__+': '+str(e)[:300])
    def handle_request(self):
        guard = getattr(self.server, 'request_guard', None)
        if guard is not None: guard()
        size=int(self.headers.get('content-length','0'))
        if not 0<size<=2000000:raise ValueError('Invalid request size')
        body=json.loads(self.rfile.read(size))
        if 'count_tokens' in self.path:
            if self.server.scripted:
                self.send_response(200);self.end_headers();self.wfile.write(b'{"input_tokens":0}');return
            conn,res=self.upstream(self.path,body)
            raw=res.read();self.send_response(res.status);self.end_headers();self.wfile.write(raw);conn.close();return
        if self.path.split('?')[0]!='/v1/messages':raise ValueError('Unexpected endpoint')
        if self.server.errors:raise ValueError('Earlier transport failure')
        audit_request(body,self.server.expected)
        n=len(self.server.requests)
        self.server.requests.append(body)
        (self.server.out/f'request-{n}.json').write_text(json.dumps(body,ensure_ascii=False))
        if self.server.scripted:
            self.scripted(body);return
        if body.get('max_tokens',0)>8192:raise ValueError('Unexpected output bound')
        if body.get('speed')=='fast':raise ValueError('Fast mode not budgeted')
        count_body={k:v for k,v in body.items() if k in {'model','messages','system','tools','thinking','output_config','cache_control'}}
        conn,countres=self.upstream('/v1/messages/count_tokens',count_body)
        raw=countres.read();conn.close()
        (self.server.out/f'count-{n}.json').write_bytes(raw)
        if countres.status!=200:raise ValueError('Token count not accepted: '+str(countres.status))
        count=json.loads(raw)['input_tokens']
        bound=self.server.budget.reserve(count,body['max_tokens'])
        (self.server.out/f'reserve-{n}.json').write_text(json.dumps({'input_tokens_estimate':count,'upper_cost_estimate':str(bound)}))
        # Reserve is recorded before provider contact. Unknown response leaves pending set.
        conn,res=self.upstream(self.path,body)
        self.server.forwarded+=1
        self.send_response(res.status)
        self.send_header('Content-Type',res.getheader('Content-Type','application/json'));self.end_headers()
        chunks=[]
        with (self.server.out/f'response-{n}.bin').open('wb') as f:
            while True:
                chunk=res.read1(65536)
                if not chunk:break
                f.write(chunk);chunks.append(chunk)
                self.wfile.write(chunk);self.wfile.flush()
        conn.close()
        raw=b''.join(chunks)
        if res.status!=200:raise ValueError('Provider status '+str(res.status))
        if body.get('stream'):
            usage={}
            for line in raw.splitlines():
                if not line.startswith(b'data: '):continue
                event=json.loads(line[6:])
                if event.get('type')=='message_start':usage.update(event['message'].get('usage',{}))
                if event.get('type')=='message_delta':usage.update(event.get('usage',{}))
            if b'"message_stop"' not in raw:raise ValueError('No terminal provider event')
        else:usage=json.loads(raw)['usage']
        self.server.budget.complete(usage)
        (self.server.out/f'usage-{n}.json').write_text(json.dumps(usage))
    def scripted(self,body):
        available={t.get('name') for t in body.get('tools',[]) if isinstance(t,dict)}
        block={'type':'text','text':'FUNCTIONAL_TRANSPORT_DONE'}
        if self.server.stage<len(self.server.plan):
            name,args=self.server.plan[self.server.stage]
            if name not in available and 'ToolSearch' in available:
                block={'type':'tool_use','id':'tool_'+__import__('uuid').uuid4().hex,'name':'ToolSearch','input':{'query':'select:'+name,'max_results':1}}
            elif name in available:
                block={'type':'tool_use','id':'tool_'+__import__('uuid').uuid4().hex,'name':name,'input':args}
                self.server.stage+=1
            else:raise ValueError('Scripted tool unavailable: '+name)
        stop='tool_use' if block['type']=='tool_use' else 'end_turn'
        message={'id':'msg_fixture','type':'message','role':'assistant','model':body['model'],'content':[],'stop_reason':None,'stop_sequence':None,'usage':{'input_tokens':0,'output_tokens':0}}
        initial=dict(block)
        if block['type']=='tool_use':
            initial['input']={};delta={'type':'input_json_delta','partial_json':json.dumps(block['input'])}
        else:initial['text']='';delta={'type':'text_delta','text':block['text']}
        events=[('message_start',{'type':'message_start','message':message}),
         ('content_block_start',{'type':'content_block_start','index':0,'content_block':initial}),
         ('content_block_delta',{'type':'content_block_delta','index':0,'delta':delta}),
         ('content_block_stop',{'type':'content_block_stop','index':0}),
         ('message_delta',{'type':'message_delta','delta':{'stop_reason':stop,'stop_sequence':None},'usage':{'output_tokens':0}}),
         ('message_stop',{'type':'message_stop'})]
        self.send_response(200);self.send_header('Content-Type','text/event-stream');self.end_headers()
        for name,event in events:
            self.wfile.write(('event: '+name+'\ndata: '+json.dumps(event)+'\n\n').encode());self.wfile.flush()

def server(out,expected,scripted,plan,*,campaign_remaining=None):
    cap=Decimal('0') if scripted else amount(campaign_remaining)
    s=http.server.ThreadingHTTPServer(('127.0.0.1',0),Proxy)
    s.out=out;s.expected=expected;s.scripted=scripted;s.plan=plan;s.stage=0
    s.lock=threading.Lock();s.budget=Budget(cap);s.budget_stop=None
    s.requests=[];s.errors=[];s.forwarded=0
    threading.Thread(target=s.serve_forever,daemon=True).start()
    return s
