"""Real loopback proxy tests; provider boundary is a local deterministic double."""
import http.client
import io
import json
import pathlib
import tempfile
import unittest
from decimal import Decimal
from unittest.mock import patch
from transport import Proxy,server

EXPECTED={'effort':'low','declaration':False,'clause':'AUTHORITY','global_visible':['GLOBAL'],'project_visible':['PROJECT']}
BODY={'model':'claude-sonnet-5-5','output_config':{'effort':'low'},'messages':[{'role':'user','content':'GLOBAL\nPROJECT'}],'max_tokens':8192,'stream':True}

class CampaignBudgetTests(unittest.TestCase):
    def request(self,s):
        c=http.client.HTTPConnection('127.0.0.1',s.server_port,timeout=5)
        try:
            c.request('POST','/v1/messages',json.dumps(BODY),{'Content-Type':'application/json'})
            r=c.getresponse();raw=r.read()
            return r.status,raw
        finally:c.close()

    def provider(self,calls):
        class Reply(io.BytesIO):
            status=200
            def getheader(self,*args):return 'application/json'
        class Conn:
            def close(self):pass
        def upstream(proxy,path,body):
            calls.append(path)
            if 'count_tokens' in path:return Conn(),Reply(b'{"input_tokens":59666}')
            raw=b'data: {"type":"message_start","message":{"usage":{"input_tokens":2,"cache_creation_input_tokens":100,"cache_read_input_tokens":59000,"output_tokens":0}}}\n\ndata: {"type":"message_delta","usage":{"output_tokens":32}}\n\ndata: {"type":"message_stop"}\n\n'
            return Conn(),Reply(raw)
        return upstream

    def test_actual_first_cutoff_is_admitted_against_remaining_campaign_money(self):
        with tempfile.TemporaryDirectory() as d:
            calls=[]
            with patch.object(Proxy,'upstream',self.provider(calls)):
                s=server(pathlib.Path(d),EXPECTED,False,[],campaign_remaining=Decimal('3.83234979999999997'))
                try:
                    s.budget.spent=Decimal('.40071361')
                    status,raw=self.request(s)
                    self.assertEqual(status,200)
                    self.assertIn(b'"message_stop"',raw)
                    self.assertEqual(s.forwarded,1)
                    self.assertEqual(s.errors,[])
                    self.assertIsNone(s.budget.pending)
                    self.assertIsNone(s.budget_stop)
                finally:s.shutdown();s.server_close()
    def test_thirty_cached_responses_can_finish_without_a_synthetic_run_ceiling(self):
        with tempfile.TemporaryDirectory() as d:
            calls=[]
            with patch.object(Proxy,'upstream',self.provider(calls)):
                s=server(pathlib.Path(d),EXPECTED,False,[],campaign_remaining=Decimal('2.39344410000000003'))
                try:
                    s.budget.spent=Decimal('.40071361')
                    for _ in range(30):
                        status,raw=self.request(s)
                        self.assertEqual(status,200)
                        self.assertIn(b'"message_stop"',raw)
                    self.assertEqual(s.forwarded,30)
                    self.assertEqual(s.errors,[])
                    self.assertIsNone(s.budget_stop)
                    self.assertIsNone(s.budget.pending)
                    self.assertLess(s.budget.spent,s.budget.cap)
                finally:s.shutdown();s.server_close()

    def test_real_campaign_exhaustion_never_reaches_generation_or_becomes_transport_error(self):
        with tempfile.TemporaryDirectory() as d:
            calls=[]
            with patch.object(Proxy,'upstream',self.provider(calls)):
                s=server(pathlib.Path(d),EXPECTED,False,[],campaign_remaining=Decimal('.9'))
                try:
                    s.budget.spent=Decimal('.40071361')
                    status,_=self.request(s)
                    self.assertEqual(status,400)
                    self.assertEqual(s.forwarded,0)
                    self.assertEqual(calls,['/v1/messages/count_tokens'])
                    self.assertEqual(s.errors,[])
                    self.assertIsNotNone(s.budget_stop)
                    self.assertIsNone(s.budget.pending)
                    self.assertTrue((pathlib.Path(d)/'budget-stop.json').exists())
                finally:s.shutdown();s.server_close()

    def test_unknown_pending_cost_remains_fatal(self):
        with tempfile.TemporaryDirectory() as d:
            calls=[]
            with patch.object(Proxy,'upstream',self.provider(calls)):
                s=server(pathlib.Path(d),EXPECTED,False,[],campaign_remaining=Decimal('4'))
                try:
                    s.budget.pending=Decimal('.1')
                    status,_=self.request(s)
                    self.assertEqual(status,400)
                    self.assertEqual(s.forwarded,0)
                    self.assertTrue(s.errors)
                    self.assertIsNone(s.budget_stop)
                    self.assertEqual(s.budget.pending,Decimal('.1'))
                finally:s.shutdown();s.server_close()

    def test_paid_proxy_cannot_default_to_an_implicit_budget(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError):server(pathlib.Path(d),EXPECTED,False,[])
class RecordedCutoffReplayTests(unittest.TestCase):
    def test_all_four_recorded_denials_fit_the_actual_campaign_balance(self):
        from transport import Budget,BudgetExhausted
        # Rows from launch-v1/paid-v2-{0,1,2,3}: actual count at denial,
        # completed-usage debit and terminal-verified campaign balance at start.
        cases=[
          (59666,'.40071361','3.83234979999999997'),
          (58094,'.40363147','3.46806469999999994'),
          (61490,'.38717327','3.10112700000000004'),
          (59209,'.39127792','2.74915130000000009'),
        ]
        for count,debit,remaining in cases:
            with self.subTest(count=count):
                old=Budget('1');old.spent=Decimal(debit)
                with self.assertRaises(BudgetExhausted):old.reserve(count,8192)
                fixed=Budget(remaining);fixed.spent=Decimal(debit)
                fixed.reserve(count,8192)
                self.assertIsNotNone(fixed.pending)
                self.assertLessEqual(fixed.spent+fixed.pending,Decimal(remaining))
