"""One unique Docker stdio process per Claude MCP connection; no credential forwarding."""
import json
import pathlib
import subprocess
import sys
import uuid
root=pathlib.Path(sys.argv[1])
args=json.loads((root/'mcp-native-argv.json').read_text())
name='hfa-native-'+uuid.uuid4().hex
args[args.index('--name')+1]=name
args[args.index('--label')+1]='codescout.hfa='+name
args[2:2]=['--rm']
(root/('mcp-launch-'+name+'.json')).write_text(json.dumps({'argv':args,'name':name}))
p=subprocess.run(args)
(root/('mcp-exit-'+name+'.json')).write_text(json.dumps({'exit_code':p.returncode}))
sys.exit(p.returncode)
