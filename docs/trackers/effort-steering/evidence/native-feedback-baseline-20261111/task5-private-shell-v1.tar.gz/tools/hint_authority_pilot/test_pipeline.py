import http.client
import json
import pathlib
import tempfile
import time
import unittest
from unittest.mock import patch
import run
from transport import Proxy,server

class PipelineTests(unittest.TestCase):
    def test_paid_entrypoint_rejects_stale_review_before_attempt(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d)
            (root/'functional-controls-v2.json').write_text(json.dumps({'oracle_version':2,'fingerprint':'current','results':[{'exit_code':101},{'exit_code':0}]}))
            q={'fingerprint':'current','transport_errors':[],'hint_then_edit':True,'scripted_steps':8,'unknown_provider_cost':False,'exit_code':0,'terminal':{'is_error':False},'boundary_denied':True,'hint_visible_on_wire':True}
            for i in range(4):
                p=root/f'qualify-{i}';p.mkdir();(p/'receipt.json').write_text(json.dumps(q))
            (root/'review-accepted.json').write_text(json.dumps({'accepted':True,'fingerprint':'stale'}))
            with patch.object(run,'L',root),patch('audit.fingerprint',return_value='current'),patch.object(run,'one',side_effect=RuntimeError('ATTEMPTED MODEL')) as launch,patch('sys.argv',['run.py','paid']):
                with self.assertRaisesRegex(ValueError,'Review not bound'):run.main()
                launch.assert_not_called()
    def test_cleanup_rejects_foreign_image_or_label_before_removal(self):
        from types import SimpleNamespace
        for field in ['Image','Labels']:
            row={'Id':'private','Image':run.IMAGE,'Config':{'Labels':{'codescout.hfa':'owned'}}}
            if field=='Image':row['Image']='foreign'
            else:row['Config']['Labels']={}
            with tempfile.TemporaryDirectory() as d:
                out=pathlib.Path(d);(out/'mcp-launch-owned.json').write_text('{"name":"owned"}')
                with patch.object(run.subprocess,'run',return_value=SimpleNamespace(returncode=0,stdout=json.dumps([row]))) as command:
                    with self.assertRaisesRegex(ValueError,'identity mismatch'):run.cleanup(out)
                    self.assertEqual(command.call_count,1)
    def test_truncated_provider_stream_keeps_unknown_cost_and_blocks(self):
        import io
        class Reply(io.BytesIO):
            status=200
            def getheader(self,*args):return 'text/event-stream'
        class Conn:
            def close(self):pass
        raw=b'data: {"type":"message_start","message":{"usage":{"input_tokens":1,"output_tokens":0}}}\n\ndata: {"type":"message_delta","usage":{"output_tokens":1}}\n\n'
        def upstream(self,path,body):
            return Conn(),Reply(b'{"input_tokens":1}' if 'count_tokens' in path else raw)
        with tempfile.TemporaryDirectory() as d:
            expected={'effort':'low','declaration':False,'clause':'AUTHORITY','global_visible':['GLOBAL'],'project_visible':['PROJECT']}
            with patch.object(Proxy,'upstream',upstream):
                s=server(pathlib.Path(d),expected,False,[],campaign_remaining='1')
                try:
                    c=http.client.HTTPConnection('127.0.0.1',s.server_port,timeout=5)
                    c.request('POST','/v1/messages',json.dumps({'model':'claude-sonnet-5-5','output_config':{'effort':'low'},'messages':[{'role':'user','content':'GLOBAL\nPROJECT'}],'max_tokens':10,'stream':True}),{'Content-Type':'application/json'})
                    c.getresponse().read();c.close()
                    self.assertTrue(any('No terminal provider event' in e for e in s.errors))
                    self.assertIsNotNone(s.budget.pending)
                finally:s.shutdown();s.server_close()
