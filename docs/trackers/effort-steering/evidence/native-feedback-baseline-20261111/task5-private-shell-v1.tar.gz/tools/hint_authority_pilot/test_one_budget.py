"""Launcher budget integration: real one(), proxy, wire response and saved receipt."""
import http.client
import io
import json
import pathlib
import shutil
import tempfile
import unittest
from decimal import Decimal
from types import SimpleNamespace
from unittest.mock import patch

import run
from transport import Proxy


class Reply(io.BytesIO):
    status = 200

    def getheader(self, *args):
        return 'text/event-stream'


class Connection:
    def close(self):
        pass


class OneBudgetTests(unittest.TestCase):
    def exercise(self, balance, exhausted):
        with tempfile.TemporaryDirectory(prefix='hfa-one-budget-') as directory:
            root = pathlib.Path(directory)
            (root / 'source').mkdir()
            (root / 'source' / 'CLAUDE.md').write_text('PROJECT')
            (root / 'inputs').mkdir()
            (root / 'inputs' / 'global-CLAUDE.md').write_text('GLOBAL')
            calls, servers = [], []

            def provider(proxy, path, body):
                calls.append(path)
                if 'count_tokens' in path:
                    servers.append(proxy.server)
                    proxy.server.budget.spent = Decimal('.40071361')
                    return Connection(), Reply(b'{"input_tokens":59666}')
                raw = (
                    b'data: {"type":"message_start","message":{"usage":{"input_tokens":2,"cache_creation_input_tokens":100,"cache_read_input_tokens":59000,"output_tokens":0}}}\n\n'
                    b'data: {"type":"message_delta","usage":{"output_tokens":32}}\n\n'
                    b'data: {"type":"message_stop"}\n\n'
                )
                return Connection(), Reply(raw)

            test = self

            class LocalCLI:
                def __init__(self, argv, **kwargs):
                    test.assertEqual(argv[argv.index('--max-budget-usd') + 1], '0.65')
                    env = kwargs['env']
                    test.assertEqual(env['CLAUDE_CODE_MAX_OUTPUT_TOKENS'], '8192')
                    test.assertEqual(env['CLAUDE_CODE_OAUTH_TOKEN'], 'LOCAL-NONCREDENTIAL')
                    connection = http.client.HTTPConnection(
                        env['ANTHROPIC_BASE_URL'].removeprefix('http://'), timeout=10)
                    body = {
                        'model': 'claude-sonnet-5-5',
                        'output_config': {'effort': 'low'},
                        'messages': [{'role': 'user', 'content': 'GLOBAL\nPROJECT'}],
                        'max_tokens': 8192, 'stream': True,
                    }
                    connection.request('POST', '/v1/messages', json.dumps(body),
                                       {'Content-Type': 'application/json'})
                    response = connection.getresponse()
                    response.read()
                    connection.close()
                    self.returncode = 0 if response.status == 200 else 1
                    sid = argv[argv.index('--session-id') + 1]
                    kwargs['stdout'].write(json.dumps({
                        'type': 'result', 'session_id': sid, 'total_cost_usd': '.4',
                        'is_error': response.status != 200,
                        'subtype': 'success' if response.status == 200 else 'error',
                    }).encode())

                def wait(self, **kwargs):
                    return self.returncode

            token = SimpleNamespace(
                stat=lambda: SimpleNamespace(st_mode=0o600), is_file=lambda: True,
                read_text=lambda: 'LOCAL-NONCREDENTIAL')
            actors = []
            copytree = shutil.copytree

            def copy_actor(source, actor):
                actors.append(actor)
                return copytree(source, actor)

            try:
                with patch.object(run, 'L', root), patch.object(run, 'P', root), \
                     patch.object(run, 'TOKEN', token), \
                     patch.object(run, 'native_argv', return_value=[]), \
                     patch.object(run, 'plugin_copy', return_value=root), \
                     patch.object(run, 'cleanup'), \
                     patch.object(run.shutil, 'copytree', side_effect=copy_actor), \
                     patch.object(run.subprocess, 'run'), \
                     patch.object(run.subprocess, 'Popen', LocalCLI), \
                     patch.object(Proxy, 'upstream', provider):
                    receipt = run.one('cell', 'low', False, False,
                                      campaign_remaining=Decimal(balance))
                self.assertEqual(servers[0].budget.cap, Decimal(balance))
                self.assertEqual(Decimal(receipt['campaign_available_usd']), Decimal(balance))
                self.assertEqual(bool(receipt['budget_stop']), exhausted)
                self.assertEqual(receipt['workflow_completed'], not exhausted)
                self.assertEqual(receipt['transport_errors'], [])
                self.assertFalse(receipt['unknown_provider_cost'])
                self.assertEqual(receipt['forwarded'], 0 if exhausted else 1)
                self.assertEqual(calls, ['/v1/messages/count_tokens'] +
                                 ([] if exhausted else ['/v1/messages']))
                self.assertEqual(json.loads((root / 'cell' / 'receipt.json').read_text()),
                                 receipt)
                self.assertEqual((root / 'cell' / 'budget-stop.json').exists(), exhausted)
            finally:
                for actor in actors:
                    shutil.rmtree(actor.parent)

    def test_actual_launcher_admits_recorded_cutoff_with_campaign_balance(self):
        self.exercise('3.5', False)

    def test_actual_launcher_persists_campaign_stop_and_incomplete_workflow(self):
        self.exercise('.9', True)


if __name__ == '__main__':
    unittest.main()
