"""Bind qualification/review to bytes and inspect actual post-tool request contents."""
import hashlib
import json
from prepare import L,P,save

def flatten(value):
    if isinstance(value,str):return value
    if isinstance(value,list):return '\n'.join(map(flatten,value))
    if isinstance(value,dict):return '\n'.join(map(flatten,value.values()))
    return ''

def extra_inputs():
    paths=[L/'reference.patch']
    prior=L/'prior-attempts.json'
    if prior.exists():paths.append(prior)
    return paths

def fingerprint():
    here=__import__('pathlib').Path(__file__).resolve().parent
    root=P.parent
    roots=[L/'source',L/'skill-only-plugin',P/'inputs',
      root/'native-build-provenance-20261104/bin',
      root/'native-env-admission-20261104/qualification-20261104/runtime-v2',
      root/'native-env-admission-20261104/qualification-20261104/patched-lsp',
      root/'native-env-admission-20261104/qualification-20261104/jina-cache']
    files=list(here.glob('*.py'))+[root/'behavior-transfer-20261029/claude-2.1.309']+extra_inputs()
    for directory in roots:
        if not directory.is_dir():raise ValueError('Missing frozen runtime/input '+str(directory))
        files.extend(directory.rglob('*'))
    result={}
    for p in sorted(files):
        if p.is_symlink():result[str(p)+'#link']=str(p.readlink())
        if p.is_file():
            h=hashlib.sha256()
            with p.open('rb') as f:
                while data:=f.read(1024*1024):h.update(data)
            result[str(p)]=h.hexdigest()
    return hashlib.sha256(json.dumps(result,sort_keys=True).encode()).hexdigest()

def validate_preflight(controls,qualifications,review,current):
    if controls.get('oracle_version')!=2:raise ValueError('Wrong functional oracle')
    if controls.get('fingerprint')!=current:raise ValueError('Stale functional controls')
    c=controls.get('results',[])
    if len(c)!=2 or c[0].get('exit_code')!=101 or c[1].get('exit_code')!=0:raise ValueError('Controls not discriminating')
    if review.get('accepted') is not True or review.get('fingerprint')!=current:raise ValueError('Review not bound to current bytes')
    if len(qualifications)!=4:raise ValueError('All four scripted cells required')
    for q in qualifications:
        if q.get('fingerprint')!=current:raise ValueError('Stale qualification')
        if q.get('transport_errors') or not q.get('hint_then_edit') or q.get('scripted_steps')!=8:raise ValueError('Incomplete transport qualification')
        if q.get('unknown_provider_cost') or q.get('exit_code')!=0 or q.get('terminal',{}).get('is_error') is not False:raise ValueError('Unsuccessful qualification')
        if q.get('boundary_denied') is not True or q.get('hint_visible_on_wire') is not True:raise ValueError('Delivery/boundary not qualified')

def inspect_cell(out):
    requests=[json.loads(p.read_text()) for p in sorted(out.glob('request-*.json'),key=lambda p:int(p.stem.split('-')[-1]))]
    calls={};results={}
    for req in requests:
        for message in req.get('messages',[]):
            content=message.get('content',[])
            if not isinstance(content,list):continue
            for block in content:
                if block.get('type')=='tool_use':calls[block['id']]=block
                if block.get('type')=='tool_result':results[block['tool_use_id']]=block
    denied=[]
    for callid,call in calls.items():
        if call.get('name')=='mcp__codescout__read_file' and call.get('input',{}).get('path','').endswith('outside-host-canary.txt'):
            result=flatten(results.get(callid,{}))
            denied.append(result)
    text=flatten(requests[-1]) if requests else ''
    hint='[cs-hint] `build_chunks` has callers outside its own file.'
    # An emitted local hook event is insufficient: context must reach next request.
    visible=hint in text
    boundary=len(denied)==1 and '"ok": false' in denied[0] and any(x in denied[0].lower() for x in ['outside','denied','not allowed','scope'])
    return {'hint_visible_on_wire':visible,'boundary_denied':boundary,'boundary_result':denied}

def main():
    current=fingerprint()
    for i in range(4):
        out=L/f'qualify-{i}'
        inspected=inspect_cell(out)
        q=json.loads((out/'receipt.json').read_text())
        if q.get('fingerprint')!=current:raise ValueError('Cannot rebind stale scripted evidence')
        q.update(inspected)
        save(out/'receipt.json',q)
        print(json.dumps({'cell':i,**inspected}),flush=True)
    save(L/'qualified-fingerprint.json',{'fingerprint':current})

if __name__=='__main__':main()
