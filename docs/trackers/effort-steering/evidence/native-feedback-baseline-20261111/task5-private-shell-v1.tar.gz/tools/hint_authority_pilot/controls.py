"""Qualify the full functional oracle against independent known broken/repaired copies."""
import json
import shutil
import subprocess
from prepare import L,grade,save
def main():
    from audit import fingerprint
    current=fingerprint()
    results=[]
    for label in ['baseline','positive']:
        name='control-'+current[:8]+'-'+label
        dst=L/name
        shutil.copytree(L/'source',dst)
        if label=='positive':
            subprocess.run(['git','apply','--unsafe-paths','-'],cwd=dst,input=(L/'reference.patch').read_bytes(),check=True)
        result=grade(dst,name,old_api=label=='baseline')
        results.append(result);print(json.dumps(result),flush=True)
    assert results[0]['exit_code']==101 and results[1]['exit_code']==0
    assert fingerprint()==current
    save(L/'functional-controls-v2.json',{'oracle_version':2,'fingerprint':current,'results':results})
if __name__=='__main__':main()
