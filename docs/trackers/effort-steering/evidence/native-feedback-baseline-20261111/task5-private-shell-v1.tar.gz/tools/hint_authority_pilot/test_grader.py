import pathlib
import tempfile
import types
import unittest
from unittest.mock import patch
import prepare
from prepare import acceptance_executed
class GraderTests(unittest.TestCase):
    def test_zero_tests_and_one_missing_assertion_are_rejected(self):
        good='test librarian::catalog::chunk::hfa_acceptance::offset_and_chunk_metadata ... ok\ntest librarian::catalog::chunk::hfa_acceptance_callers::initial_and_forced_reindex_publish_file_coordinates ... ok\ntest result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 4995 filtered out; finished in 0.00s'
        self.assertTrue(acceptance_executed(good))
        self.assertFalse(acceptance_executed('test result: ok. 0 passed; 0 failed'))
        self.assertFalse(acceptance_executed(good.replace('hfa_acceptance_callers::','other::')))
        self.assertFalse(acceptance_executed(good.replace('2 passed; 0 failed','1 passed; 1 failed')))
class RegressionWitnessTests(unittest.TestCase):
    def output(self,count):
        return "".join(f"test suite::case_{i} ... ok\n" for i in range(count))+f"test result: ok. {count} passed; 0 failed; 0 ignored; 0 measured; 4995 filtered out; finished in 0.01s\n"

    def exercise(self,text):
        acceptance="test librarian::catalog::chunk::hfa_acceptance::offset_and_chunk_metadata ... ok\ntest librarian::catalog::chunk::hfa_acceptance_callers::initial_and_forced_reindex_publish_file_coordinates ... ok\ntest result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 4995 filtered out; finished in 0.00s\n"
        def run(argv,**kwargs):
            output=acceptance if argv[-3]=="hfa_acceptance" else text
            kwargs["stdout"].write(output.encode())
            return types.SimpleNamespace(returncode=0)
        with tempfile.TemporaryDirectory() as tmp:
            with patch.object(prepare,"L",pathlib.Path(tmp)),patch.object(prepare,"append_oracle"),patch.object(prepare.subprocess,"run",run):
                return prepare.grade(pathlib.Path(tmp),"witness")

    def test_positive_counts_ending_in_zero_are_real_execution(self):
        for count in (1,9,10,20,40,100):
            with self.subTest(count=count):
                result=self.exercise(self.output(count))
                self.assertEqual(result["exit_code"],0)
                self.assertEqual(len(result["steps"]),3)
                self.assertTrue(all(s["execution_witness"] for s in result["steps"]))

    def test_zero_missing_failed_or_inconsistent_evidence_is_rejected(self):
        one=self.output(1)
        cases=(self.output(0),"",one.split("test result:")[0],
            one.replace("ok. 1 passed; 0 failed;","FAILED. 0 passed; 1 failed;"),
            one.replace("1 passed;","2 passed;"),
            one+one,one+self.output(0),
            self.output(2).replace("case_1","case_0"),
            one.replace("test result:","noise test result:"),
            "test result: ok. 40 passed; 0 failed; 0 ignored; 0 measured; 4995 filtered out; finished in 0.01s\n")
        for text in cases:
            with self.subTest(text=text):
                result=self.exercise(text)
                self.assertEqual(result["exit_code"],98)
                self.assertFalse(result["steps"][-1]["execution_witness"])
