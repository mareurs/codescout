"""Single-use paid launcher: requires fresh concrete admission; never retries old roots."""
import hashlib
import json
from pathlib import Path
import sys
import time

WORK=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from native_campaign import NativeCampaignBackend
import runner

def save(path,value):
    with path.open("x") as stream:
        json.dump(value,stream,indent=2,sort_keys=True)

def main():
    root=Path("/var/tmp/ep11-01a15")
    inputs=root/"headroom-paid-final-v1"
    path=inputs/"registration.json"
    reg=json.loads(path.read_bytes())
    checked=json.loads((inputs/"preflight.json").read_bytes())
    assert checked["ready"] is True and checked["paid_ready"] is True
    assert reg["mode"]=="paid" and len(reg["schedule"])==8
    assert reg["campaign_id"]=="generic-evidence-pilot-20261111-headroom-v3"
    assert reg["transport_headroom_policy"]=="stage1-headroom-v2"
    assert not Path(reg["output_root"]).exists()
    launch=root/"headroom-paid-launch-v1"
    launch.mkdir()
    save(launch/"intent.json",{"schema":"effort-paid-launch-v1","started_at":time.time(),
        "registration":{"path":str(path),"sha256":hashlib.sha256(path.read_bytes()).hexdigest()},
        "scope":"Fresh eight-attempt diagnostic after versioned transport-headroom correction. Actor CLI targets, prompts and evaluator stay frozen. Historical stopped-pilot charges remain in the series ledger. No automatic retry."})
    token=Path(reg["admission"]["credential_path"])
    backend=NativeCampaignBackend(mode="paid",token_path=token)
    assert isinstance(backend.token_path,Path)
    print(json.dumps({"starting_reviewed_pilot":reg["campaign_id"],"attempts":8,
                      "credential_argument_type":type(token).__name__}),flush=True)
    try:
        result=runner.run_campaign(reg,backend)
    except BaseException as error:
        save(launch/"controller-exception.json",{"type":type(error).__name__,"reason":str(error),
            "completed":False,"cost_inference":"Missing cost remains unknown. Inspect all actual receipts/reservations."})
        raise
    summary={"status":result["status"],"reason":result.get("reason"),
             "attempts":len(result["attempts"]),"unexecuted":len(result["unexecuted"]),
             "analysis":result["analysis"],"result_path":str(Path(reg["output_root"])/"result.json")}
    save(launch/"summary.json",summary)
    print(json.dumps(summary),flush=True)

if __name__=="__main__":
    main()
