"""Fresh exact-source checks after the explicit legacy-hold expectation correction."""
import hashlib
import json
import sys
from pathlib import Path

WORK = Path(__file__).resolve().parents[3]
ROOT = Path("/var/tmp/ep11-01a15")
OLD_DRIVER = WORK / ".superpowers/sdd/2026-11-10-campaign-integration"

def main():
    previous = json.loads((ROOT/"final-verification-v3/verification.json").read_text())["source_after"]
    current = {path: hashlib.sha256(Path(path).read_bytes()).hexdigest() for path in previous}
    changed = sorted(path for path in previous if current[path] != previous[path])
    expected = sorted(str(WORK/"tools/effort_protocol"/name) for name in (
        "campaign.py", "paid_admission.py", "test_campaign.py", "test_paid_admission.py", "test_runner.py"))
    assert changed == expected, changed
    parent = ROOT/"headroom-source-delta-v2"
    parent.mkdir(exist_ok=False)
    (parent/"delta.json").write_text(json.dumps({
        "source_before": previous, "source_after": current, "changed": changed,
        "scope": "Two financial policy functions plus three regression test files.",
        "previous_qualification_reused_as_new_qualification": False,
        "limits": "The old qualified registration supplies unchanged evaluator package bindings only.",
        "driver": {"path": str(Path(__file__).resolve()), "sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    }, indent=2)+"\n")
    sys.path.insert(0, str(OLD_DRIVER))
    import verify_final_admission_sources as job
    job.OUT = ROOT/"headroom-verification-v2"
    job.main()

if __name__ == "__main__":
    main()
