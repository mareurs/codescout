"""Bind an actually approved fresh target and run all seven concrete no-provider checks."""
import copy
import hashlib
import json
import os
from pathlib import Path
import sys

WORK=Path(__file__).resolve().parents[3]
ROOT=Path("/var/tmp/ep11-01a15")
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
import paid_admission
from native_campaign import NativeCampaignBackend
import runner

def read(path):
    return json.loads(Path(path).read_bytes())

def save(path,value):
    with path.open("x") as stream:
        json.dump(value,stream,indent=2,sort_keys=True)

def main():
    path=ROOT/"headroom-paid-registration-v1/registration-for-review.json"
    reg=copy.deepcopy(read(path))
    report=ROOT/"headroom-admission-review-v1/report.json"
    reviewed=read(report)
    verification=Path(reg["admission"]["verification"]["path"])
    final=read(verification)
    pending_path=ROOT/"headroom-bounded-correction-v1/pending-resolution.json"
    resolved=copy.deepcopy(read(pending_path))
    assert final["source_before"]==final["source_after"]==resolved["source_after"]
    assert resolved["source_before"]==reviewed["source_before"]
    changed=[name for name in resolved["source_after"] if resolved["source_after"][name]!=reviewed["source_before"][name]]
    assert changed==[str(WORK/"tools/effort_protocol/test_paid_admission.py")]
    assert resolved["correction_rounds"]==1 and resolved["outstanding"]==[]
    assert {row["id"] for row in resolved["replays"]}=={"H09","H10"}
    important={row["id"] for row in reviewed["findings"] if row["severity"] in ("high","medium")}
    assert important<=set(resolved["findings_closed"]), "Unresolved final review finding."
    def bind(path):
        path=Path(path)
        assert path.is_file() and path.resolve(strict=True)==path
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        reg["bindings"][str(path)]=digest
        return {"path":str(path),"sha256":digest}
    for name,digest in final["source_after"].items():
        assert bind(name)["sha256"]==digest
    bind(final["producer"]["path"])
    for row in final["executions"].values():
        assert bind(row["log"]["path"])["sha256"]==row["log"]["sha256"]
    ssl_descriptor=final["gate_environment_qualification"]
    assert bind(ssl_descriptor["path"])["sha256"]==ssl_descriptor["sha256"]
    ssl=read(ssl_descriptor["path"])
    for name,item in ssl["manifest"].items():
        if item["type"]=="file":
            assert bind(name)["sha256"]==item["sha256"]
        else:
            assert Path(name).is_symlink() and os.readlink(name)==item["target"]
    assert bind(ssl["archive"]["path"])["sha256"]==ssl["archive"]["sha256"]
    report_descriptor=bind(report)
    resolved.update(review_sha256=report_descriptor["sha256"],
                    target_sha256=paid_admission.review_target(reg),ready_for_target_binding=True,
                    bound_from=bind(pending_path))
    correction=ROOT/"headroom-bounded-correction-v1/resolution.json"
    save(correction,resolved)
    reg["admission"]["review"]={"report":report_descriptor,"resolution":bind(correction)}
    bind(reviewed["baseline"]["log"]["path"])
    for mutation in reviewed["mutations"]+resolved["replays"]:
        for role in ("original","mutated","log"):
            assert bind(mutation[role]["path"])["sha256"]==mutation[role]["sha256"]
    bind(resolved["baseline"]["log"]["path"])
    bind(resolved["producer"]["path"])
    bind(Path(__file__).resolve())
    assert paid_admission.review_target(reg)==reviewed["target_sha256"]
    proof=paid_admission.verify_paid(reg)
    destination=ROOT/"headroom-paid-final-v1"
    destination.mkdir(exist_ok=False)
    save(destination/"registration.json",reg)
    save(destination/"proof.json",{"is_actor_run":False,"paid_admission":proof,
        "target_sha256":paid_admission.review_target(reg),"finalizer":bind(Path(__file__).resolve()),
        "bounded_correction_rounds":1,"exact_survivors_replayed":["H09","H10"],
        "evidence_limit":"No model run or provider invoice inference."})
    token=Path(reg["admission"]["credential_path"])
    backend=NativeCampaignBackend(mode="paid",token_path=token)
    assert isinstance(backend.token_path,Path)
    checked=runner.preflight(reg,backend)
    save(destination/"preflight.json",checked)
    assert checked["ready"] is True and checked["paid_ready"] is True,checked
    print(json.dumps({"no_provider_preflight_complete":True,"paid_ready":True,
                      "credential_argument_type":type(token).__name__,
                      "target_sha256":paid_admission.review_target(reg)}),flush=True)

if __name__=="__main__":
    main()
