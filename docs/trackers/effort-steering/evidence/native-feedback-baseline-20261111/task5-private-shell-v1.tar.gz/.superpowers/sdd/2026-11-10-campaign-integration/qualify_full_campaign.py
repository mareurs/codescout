"""Zero-forward controller qualification. Synthetic probes do not repair either task."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch

WORK=Path("/home/marius/.codex/worktrees/cf66/codescout")
COMMON=Path("/tmp/effort-native-composition-v2-20261111-01a15ca9")
PRIVATE=Path("/tmp/effort-private-entry-qualification-v3-20261111-01a15ca9")
OUT=Path("/tmp/effort-native-campaign-qualification-v1-20261111-01a15ca9")
REGISTERED=OUT.with_name(OUT.name+"-registration")
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from native_campaign import NativeCampaignBackend
from native_executor import external
from campaign import select_tasks,attempt_schedule
from runner import run_campaign,preflight
from receipts import input_digest

RECON="codescout-companion:reconnaissance"
PROBE="probes/runtime_diagnostic.py"

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):
    with Path(path).open("x") as stream: json.dump(value,stream,indent=2,sort_keys=True)

def plan(arm,phase):
    result=[["Skill",{"skill":RECON}],
        ["mcp__codescout__read_file",{"path":".codescout/system-prompt.md","force":True,"start_line":1,"end_line":100}],
        ["mcp__codescout__workspace",{"action":"status"}]]
    if arm in ("L","X"):
        return result+[["mcp__codescout__create_file",{"path":"runtime-ordinary-marker.txt",
            "content":"Scripted runtime qualification only; no task repair.\n"}]]
    probe="import sys\nprint('scripted runtime witness',sys.argv[-1])\nraise SystemExit("+(
        "1 if sys.argv[-1]=='bug' else 0" if phase=="investigate" else "0")+")\n"
    result += [["mcp__codescout__create_file",{"path":PROBE,"content":probe,"overwrite":True}]]
    if phase!="investigate":
        result += [["mcp__codescout__create_file",{"path":"runtime-"+phase+"-marker.txt",
            "content":"Scripted "+phase+" source change; no task repair.\n"}]]
    if arm=="P":
        commands=[{"id":role+"-probe","argv":["python3","-I","/testbed/"+PROBE,arg],
            "cwd":".","test_files":[PROBE]} for role,arg in (("bug","bug"),("keep","keep"))]
        clauses=[{"id":"runtime-"+role,"kind":kind,"role":role,
            "receipts":[command["id"]],"unresolved":False,
            "statement":"Synthetic runtime witness, not a claim about the repair task."}
            for role,kind,command in (("reproduction","requirement",commands[0]),
                                      ("legitimate","preservation",commands[1]))]
        result += [["mcp__codescout__create_file",{"path":"submission.json","overwrite":True,
            "content":json.dumps({"status":"submitted","clauses":clauses,"commands":commands})}]]
    return result

def build():
    REGISTERED.mkdir()
    reg={"schema":"evidence-campaign-v1","campaign_id":"native-runtime-qualification-v1",
        "mode":"scripted","output_root":str(OUT),"metadata":[],"exposure":[],
        "seed":"frozen-two-development-projects-20261110","tasks":{},"bindings":{},
        "ledger":{"ceiling_usd":"200","charges":[],"holds":[],"reservations":[]},
        "shared_preparation":{"cost_usd":"0","receipt_sha256":"0"*64},
        "qualification_scope":"Synthetic zero-forward accounting fixture only. Actual historical spend/unknown4USDhold unchanged; no paid admission or repair efficacy."}
    evidence={"qualification_scope":reg["qualification_scope"],"provider_calls":0,"paid_ready":False,
        "known_historical_client_usd":"64.401093499999998654","unresolved_real_hold_usd":"4",
        "probe_policy":"same synthetic probe/markers on both repositories and all P/R phases; no gold repair or task-specific policy"}
    save(REGISTERED/"scope.json",evidence)
    reg["shared_preparation"]["receipt_sha256"]=sha(REGISTERED/"scope.json")
    for role,stem in (("obscura","obscura-421"),("lean","lean-ctx-1168")):
        prior=json.loads((COMMON/stem/"registration.json").read_bytes())
        public=copy.deepcopy(prior["public"])
        public["capture_base_commit"]=subprocess.check_output(
            ["git","--git-dir="+str(Path(public["template"])/".git"),"rev-parse","HEAD"],text=True).strip()
        public["public_checks"]=[{"argv":["python3","-I","/testbed/"+PROBE,"keep"],
            "cwd":".","test_files":[PROBE]}]
        source=Path(prior["request"]["source"])
        config=PRIVATE/role/"config.json"
        private=json.loads(config.read_bytes())
        record=json.loads(Path(private["record"]).read_bytes())
        issue=record["problem_statement"]
        identity=record["instance_id"]
        reg["metadata"].append({"id":identity,"repo":record["repo"],"base_commit":record["base_commit"],
            "image":public["image"],"created_at":"2026-11-10","language":"rust",
            "public_issue_sha256":hashlib.sha256(issue.encode()).hexdigest(),"eligible":True,
            "reason":"frozen development pair; synthetic runtime qualification, not held-out selection"})
        plans={arm+":"+phase:plan(arm,phase) for arm in ("L","R","P","X")
            for phase in (("investigate","repair","challenge") if arm in ("P","R") else ("repair",))}
        entry=WORK/"tools/effort_protocol/evaluator_entry.py"
        reg["tasks"][identity]={"source":str(source),"source_sha256":input_digest(source),
            "public_packet":{"issue":issue},"backend":{"public":public,
                "private":{"entry":str(entry),"entry_sha256":sha(entry),
                    "config":str(config),"config_sha256":sha(config)},"scripted_plans":plans}}
        reg["bindings"].update(private["bindings"])
        reg["bindings"][str(config)]=sha(config)
    reg["selected"]=select_tasks(reg["metadata"],set(),reg["seed"])
    reg["schedule"]=attempt_schedule(reg["selected"])
    files=[Path(__file__),REGISTERED/"scope.json",*sorted((WORK/"tools/effort_protocol").glob("*.py")),
        *sorted((WORK/"tools/agent_lifecycle").glob("*.py")),
        *sorted((WORK/"tools/hint_authority_pilot").glob("*.py")),WORK/"tools/effort_protocol/prompts.json"]
    for path in files: reg["bindings"][str(path)]=sha(path)
    save(REGISTERED/"registration.json",reg)
    return reg

def no_upstream(*args,**kwargs):
    raise AssertionError("scripted native campaign attempted provider forwarding")

def main():
    prior=json.loads((PRIVATE/"result.json").read_bytes())
    assert len(prior["rows"])==2 and all(row["valid"] is True and row["pass"] is False for row in prior["rows"])
    reg=build()
    backend=NativeCampaignBackend(mode="scripted")
    checked=preflight(reg,backend)
    save(REGISTERED/"preflight.json",checked)
    assert checked["ready"] and checked["paid_ready"] is False,checked
    print(json.dumps({"starting":True,"schedule":reg["schedule"],"paid_ready":False}),flush=True)
    with patch.object(external.transport.Proxy,"upstream",no_upstream):
        result=run_campaign(reg,backend)
    save(REGISTERED/"terminal-summary.json",{"status":result["status"],"reason":result.get("reason"),
        "attempts":len(result["attempts"]),"provider_calls":0,"paid_ready":False})
    assert result["status"]=="completed",result.get("reason")
    count=0
    for row in result["attempts"]:
        assert row["workflow_state"]=="closed" and row["grade"]["valid"] is True and row["grade"]["pass"] is False
        for decision in row["invocations"]:
            native=Path(decision["record"]["native_path"])
            launch=json.loads((native/"launch.json").read_bytes())
            receipt=json.loads((native/"receipt.json").read_bytes())
            assert launch["real_credentials_read"] is False and launch["mcp_protocol_negotiation"]=="legacy"
            assert receipt["forwarded"]==0 and decision["cost"]=={"known_usd":"0","unknown":False}
            assert len(list(native.glob("mcp-launch-*.json")))==1
            expected="xhigh" if row["arm"]=="X" else "low"
            bodies=[json.loads(path.read_bytes()) for path in sorted(native.glob("request-*.json"))]
            efforts=[body["output_config"]["effort"] for body in bodies if "effort" in body.get("output_config",{})]
            assert efforts and all(value==expected for value in efforts)
            count+=1
        if row["arm"] in ("P","R"):
            native=Path(row["invocations"][-1]["record"]["native_path"])
            data=(native/"candidate.patch").read_bytes()
            assert b"runtime-repair-marker.txt" in data and b"runtime-challenge-marker.txt" in data
            assert PROBE.encode() in data
    assert count==16
    save(OUT/"runtime-qualification.json",{"attempts":8,"native_invocations":16,
        "private_evaluator_processes":8,"provider_forwarded":0,"model_cost_usd":"0","paid_ready":False,
        "all_protocol_workflows_closed":True,"synthetic_candidates_acceptance":0,
        "efficacy_claim":None,"cumulative_repair_and_challenge_markers_bound":True})
    print(json.dumps({"completed":True,"attempts":8,"native_invocations":16,"provider_forwarded":0,
        "paid_ready":False}),flush=True)
if __name__=="__main__": main()
