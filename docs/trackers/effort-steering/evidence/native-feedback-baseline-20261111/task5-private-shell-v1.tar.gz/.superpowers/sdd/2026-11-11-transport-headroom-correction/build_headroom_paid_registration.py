"""Assemble a new review target only after exact-source checks and fresh qualification."""
import copy
import hashlib
import json
from pathlib import Path
import sys

WORK=Path(__file__).resolve().parents[3]
MAIN=Path("/home/marius/work/claude/codescout")
ROOT=Path("/var/tmp/ep11-01a15")
QUALIFIED=ROOT/"headroom-native-qualification-v1"
OUT=ROOT/"headroom-paid-registration-v1"
VERIFY=ROOT/"headroom-verification-v4/verification.json"
ACCOUNT=MAIN/"docs/trackers/effort-steering/evidence/headroom-accounting-20261111/reconciliation.json"
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
import paid_admission as admission

def read(path):
    return json.loads(Path(path).read_bytes())

def save(path,value):
    with Path(path).open("x") as stream:
        json.dump(value,stream,indent=2,sort_keys=True)

def main():
    qualified=read(QUALIFIED/"registration.json")
    summary=read(QUALIFIED/"runtime-qualification.json")
    assert summary["native_invocations"]==16 and summary["all_protocol_workflows_closed"]
    verification=read(VERIFY)
    assert verification["source_before"]==verification["source_after"]
    assert all(row["exit_code"]==0 and row["timed_out"] is False for row in verification["executions"].values())
    account=read(ACCOUNT)
    OUT.mkdir()
    reg=copy.deepcopy(qualified)
    for key in ("qualification_scope","qualification_driver","qualification_driver_dependencies"):
        reg.pop(key,None)
    reg.update(mode="paid",campaign_id="generic-evidence-pilot-20261111-headroom-v3",
               output_root=str(ROOT/"paid-campaign-headroom-v3"),ledger=copy.deepcopy(account["ledger"]))
    reg["carried_holds"]=[{key:row[key] for key in ("id","source","receipt_sha256","reserved_usd")}
                          for row in account["ledger"]["holds"] if not row["settled"]]
    for task in reg["tasks"].values():
        task["backend"]["scripted_plans"]={}
    bindings=reg["bindings"]
    def bind(path):
        path=Path(path)
        assert path.is_file() and path.resolve(strict=True)==path
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        bindings[str(path)]=digest
        return {"path":str(path),"sha256":digest}
    for path,digest in account["receipt_bindings"].items():
        assert bind(path)["sha256"]==digest
    assert bind(account["opening_balance_source"])["sha256"]==account["opening_balance_sha256"]
    runtime={"root":str(QUALIFIED),"producer":qualified["qualification_driver"]}
    for role,name in {"registration":"registration.json","result":"result.json",
        "qualification":"runtime-qualification.json","closure":"actor-batch-closed.json",
        "ledger":"ledger-final.json"}.items():
        runtime[role]=bind(QUALIFIED/name)
    bind(qualified["qualification_driver"]["path"])
    for dependency in qualified["qualification_driver_dependencies"]:
        bind(dependency["path"])
    result=read(QUALIFIED/"result.json")
    for index,row in enumerate(result["attempts"]):
        directory=QUALIFIED/"attempts"/(str(index).zfill(2)+"-"+row["arm"])
        bind(directory/"attempt.json")
        for decision in row["invocations"]:
            native=Path(decision["record"]["native_path"])
            phase=native.parent
            for path in (phase/"intent.json",phase/"invocation.json",native/"launch.json",native/"receipt.json",
                native/"native-executor.json",native/"prepared.json",native/"public-preparation.json",
                native/"supervision-final.json",native/"candidate-capture.json",native/"cleanup.json",
                native/"readiness/readiness.json",native/"candidate.patch",native/"expected.json",
                *native.glob("mcp-launch-*.json"),*native.glob("request-*.json")):
                bind(path)
            for name in read(native/"prepared.json")["context_preload"]["files"]:
                bind(name)
        for name in ("private-request.json","private-entry-started.json","verdict.json"):
            bind(QUALIFIED/"grades"/str(index).zfill(2)/name)
    shared={"schema":"effort-shared-reuse-v1","client_author_calls":0,"new_client_model_cost_usd":"0",
            "excluded_costs":{name:{"status":"unmeasured","usd":None} for name in
                              ("root","review","embedding_compute")},"producer":bind(Path(__file__).resolve()),
            "tasks":{},"scope":"Reuse the same frozen source-only onboarding; no new model author call. Old stopped-pilot charges remain in current series accounting."}
    for identity,task in reg["tasks"].items():
        public=task["backend"]["public"]
        shared["tasks"][identity]={key:public[key] for key in
                                  ("template","template_sha256","knowledge_sha256")}
        for name in public["knowledge_paths"]:
            bind(Path(public["template"])/".codescout"/name)
    shared_path=OUT/"shared-reuse.json"
    save(shared_path,shared)
    shared_descriptor=bind(shared_path)
    reg["shared_preparation"]={"cost_usd":"0","receipt_sha256":shared_descriptor["sha256"]}
    for path in verification["source_after"]:
        bind(path)
    bind(verification["producer"]["path"])
    for row in verification["executions"].values():
        bind(row["log"]["path"])
    for name in ("qualify_headroom_campaign.py","verify_current_headroom_v2.py",
                 "reconcile_headroom_costs.py","launch_headroom_campaign.py",
                 "build_headroom_paid_registration.py","finalize_headroom_admission.py"):
        bind(Path(__file__).parent/name)
    reg["technical_predecessor"]={
        "stopped_pilot":bind(ROOT/"paid-campaign-path-v2/result.json"),
        "cost_reconciliation":bind(ACCOUNT),
        "budget_stop_replay":bind(ROOT/"budget-stop-audit-v1/result.json"),
        "headroom_replay":bind(ROOT/"transport-headroom-replay-v1/result.json"),
        "closed_outputs":bind(MAIN/"docs/trackers/effort-steering/evidence/paid-budget-stop-20261111/closure.json"),
        "policy_change":"Only conservative transport envelopes/allocation change; actor CLI targets/prompts/evaluator remain frozen. Fresh8attempt pilot, no carried candidate or revealed private grade."}
    reg["admission"]={
        "population":read(ROOT/"population-admission-v2/population-proof.json"),
        "public_commands":read(ROOT/"public-command-admission/public-command-proof.json"),
        "accounting":bind(ACCOUNT),"runtime":runtime,"verification":bind(VERIFY),
        "review":{"report":None,"resolution":None},"shared_preparation":shared_descriptor,
        "credential_path":"/home/marius/.config/s5/token-claude-stef"}
    checks={}
    for role,function in (("population",admission.verify_population),("public_commands",admission.verify_public_commands),
        ("accounting",admission.verify_accounting),("runtime",admission.verify_runtime),
        ("verification",admission.verify_verification),("shared_preparation",admission.verify_shared_preparation)):
        checks[role]=function(reg,reg["admission"][role])
    save(OUT/"registration-for-review.json",reg)
    save(OUT/"non-review-preflight.json",{"checked":checks,"review_target_sha256":admission.review_target(reg),
         "paid_ready":False,"reason":"Exact new financial policy/source requires one truthful new independent review."})
    print(json.dumps({"assembled_for_review":True,"paid_ready":False,"proofs":list(checks),
                      "target":admission.review_target(reg)}),flush=True)

if __name__=="__main__":
    main()
