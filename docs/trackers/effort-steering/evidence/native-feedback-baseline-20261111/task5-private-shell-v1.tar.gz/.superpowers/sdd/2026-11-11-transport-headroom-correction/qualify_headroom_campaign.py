"""Fresh exact financial-schedule qualification: real native CLI, scripted responses."""
import copy
import json
from pathlib import Path
import shlex
import subprocess
import sys

WORK=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(WORK/".superpowers/sdd/2026-11-10-campaign-integration"))
import qualify_full_campaign as original

ROOT=Path("/var/tmp/ep11-01a15")
OUT=ROOT/"headroom-native-qualification-v1"
REGISTERED=ROOT/"headroom-native-qualification-v1-registration"

def read(path):
    return json.loads(Path(path).read_bytes())

def build():
    REGISTERED.mkdir()
    reg=read(ROOT/"population-admission-v2/registration-inputs.json")
    publics=read(ROOT/"public-command-admission/registration-inputs.json")
    account=read(ROOT/"accounting-admission/registration-inputs.json")
    reg["bindings"].update(publics["bindings"])
    reg["bindings"].update(account["bindings"])
    reg.update(schema="evidence-campaign-v1",campaign_id="headroom-native-qualification-v1",
               mode="scripted",output_root=str(OUT),tasks=copy.deepcopy(publics["tasks"]),
               ledger=copy.deepcopy(account["ledger"]),carried_holds=copy.deepcopy(account["carried_holds"]))
    reg["schedule"]=original.attempt_schedule(reg["selected"])
    reg["transport_headroom_policy"]="stage1-headroom-v2"
    reg["qualification_scope"]="Fresh exact headroom schedule/source, scripted actual CLI and private evaluator only; not model efficacy. Historical unknown4USDhold stays reserved."
    scope=REGISTERED/"scope.json"
    original.save(scope,{"scope":reg["qualification_scope"],"client_author_calls":0,"model_cost_usd":"0",
                         "compute_cost_measured":False,"paid_ready":False})
    reg["shared_preparation"]={"cost_usd":"0","receipt_sha256":original.sha(scope)}
    reg["qualification_driver"]={"path":str(Path(__file__).resolve()),"sha256":original.sha(__file__)}
    reg["qualification_driver_dependencies"]=[{"path":str(Path(original.__file__).resolve()),
                                             "sha256":original.sha(original.__file__)}]
    for identity,task in reg["tasks"].items():
        role="lean" if identity=="yvgude__lean-ctx-1168" else "obscura"
        config=ROOT/"private-controls"/role/"config.json"
        private=read(config)
        record=read(private["record"])
        assert record["instance_id"]==identity
        task["public_packet"]={"issue":record["problem_statement"]}
        public=task["backend"]["public"]
        public["source_baseline"]={"path":task["source"],"sha256":task["source_sha256"]}
        public["capture_base_commit"]=subprocess.check_output(
            ["git","--git-dir="+str(Path(public["template"])/".git"),"rev-parse","HEAD"],text=True).strip()
        public.update(timeout_s=3600,check_timeout_s=900,command_timeout_s=900)
        public["cli_checks"]=[]
        for index,command in enumerate(public["public_checks"]):
            cwd=command.get("cwd",".")
            shell=shlex.join(command["argv"])
            if cwd!=".":
                shell="cd -- "+shlex.quote(cwd)+" && "+shell
            public["cli_checks"].append({"id":"common-public-"+str(index),"command":shell})
        assert public["cli_checks"]
        entry=WORK/"tools/effort_protocol/evaluator_entry.py"
        task["backend"]["private"]={"entry":str(entry),"entry_sha256":original.sha(entry),
                                   "config":str(config),"config_sha256":original.sha(config)}
        task["backend"]["scripted_plans"]={arm+":"+phase:original.plan(arm,phase)
            for arm in ("L","R","P","X")
            for phase in (("investigate","repair","challenge") if arm in ("P","R") else ("repair",))}
        reg["bindings"].update(private["bindings"])
        reg["bindings"][str(config)]=original.sha(config)
    files=[Path(__file__),Path(original.__file__),scope,
           *[p for folder in ("effort_protocol","agent_lifecycle","hint_authority_pilot")
             for p in (WORK/"tools"/folder).glob("*.py")
             if not p.name.startswith("test_") and p.name!="paid_admission.py"],
           WORK/"tools/effort_protocol/prompts.json"]
    for path in files:
        reg["bindings"][str(path.resolve())]=original.sha(path)
    original.save(REGISTERED/"registration.json",reg)
    return reg

def main():
    evidence=read(ROOT/"preloaded-context-v1/result.json")
    assert len(evidence["controls"])==2 and all(row["context_in_first_system"] for row in evidence["controls"])
    original.OUT=OUT
    original.PRIVATE=ROOT/"private-controls"
    original.REGISTERED=REGISTERED
    original.build=build
    original.main()

if __name__=="__main__":
    main()
