"""Fresh final checks after the one test-only review correction."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

WORK=Path(__file__).resolve().parents[3]
ROOT=Path("/var/tmp/ep11-01a15")
OUT=ROOT/"headroom-verification-v4"
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from paid_admission import verification_contract

def read(path):
    return json.loads(Path(path).read_bytes())

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(path,value):
    with path.open("x") as stream:
        json.dump(value,stream,indent=2,sort_keys=True)

def main():
    old=read(ROOT/"headroom-verification-v3/verification.json")
    before={path:sha(path) for path in old["source_after"]}
    changed=[path for path in before if before[path]!=old["source_after"][path]]
    assert changed==[str(WORK/"tools/effort_protocol/test_paid_admission.py")],changed
    ssl_path=ROOT/"gate-openssl35-v1/result.json"
    ssl=read(ssl_path)
    for name,item in ssl["manifest"].items():
        if item["type"]=="file":
            assert sha(name)==item["sha256"]
        else:
            assert Path(name).is_symlink() and os.readlink(name)==item["target"]
    # A registration locates exact private package inputs; qualification completion is checked separately.
    reg=read(ROOT/"headroom-native-qualification-v1/registration.json")
    sources,commands=verification_contract(reg)
    assert set(before)=={str(path) for path in sources}
    environment={**old["executions"]["protocol"]["environment"],**ssl["environment"]}
    OUT.mkdir(exist_ok=False)
    producer={"path":str(Path(__file__).resolve()),"sha256":sha(__file__)}
    save(OUT/"registration.json",{"sources":before,"commands":commands,"environment":environment,
                                "producer":producer,"changed_after_review_stageA":changed})
    executions={}
    for role,command in commands.items():
        print(json.dumps({"starting":role}),flush=True)
        log=OUT/(role+".log")
        start=time.time()
        timed_out=False
        with log.open("xb") as stream:
            try:
                done=subprocess.run(command["argv"],cwd=command["cwd"],env={**os.environ,**environment},
                                    stdout=stream,stderr=subprocess.STDOUT,timeout=3600 if role=="gate" else 1200)
                code=done.returncode
            except subprocess.TimeoutExpired:
                code=None
                timed_out=True
        row={**command,"exit_code":code,"timed_out":timed_out,"environment":environment,
             "started_at":start,"finished_at":time.time(),"log":{"path":str(log),"sha256":sha(log)}}
        executions[role]=row
        save(OUT/(role+".json"),row)
        print(json.dumps({"role":role,"exit_code":code,"timed_out":timed_out}),flush=True)
        assert code==0 and not timed_out,role
    after={path:sha(path) for path in before}
    assert before==after
    save(OUT/"verification.json",{"schema":"effort-verification-v1","source_before":before,"source_after":after,
        "executions":executions,"producer":producer,
        "gate_environment_qualification":{"path":str(ssl_path),"sha256":sha(ssl_path)},
        "limits":["All four roles ran freshly after the one test-only bounded correction.",
                  "Supported isolated OpenSSL3.5.1 changes gate environment only; host remains4.1.0.",
                  "Gate heavy-Python/server-stack/librarian-lean/local ONNX exclusions remain.",
                  "Three optional protocol skips must be read from the actual log."]})
    print(json.dumps({"final_checks_complete":True,"source_files":len(before),"paid_ready":False}),flush=True)

if __name__=="__main__":
    main()
