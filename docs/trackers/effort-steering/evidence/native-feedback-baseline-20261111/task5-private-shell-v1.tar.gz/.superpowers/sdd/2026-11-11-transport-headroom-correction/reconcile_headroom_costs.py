"""Append two closed client receipts; retain unknown hold and old raw ledgers."""
import copy
import hashlib
import json
import sys
from decimal import Decimal, localcontext
from pathlib import Path

WORK=Path(__file__).resolve().parents[3]
MAIN=Path("/home/marius/work/claude/codescout")
ROOT=Path("/var/tmp/ep11-01a15")
DEST=MAIN/"docs/trackers/effort-steering/evidence/headroom-accounting-20261111"
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from campaign import accounting_totals, admit_history
from paid_admission import verify_accounting

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(path):
    return json.loads(Path(path).read_bytes())

def main():
    old_path=MAIN/"docs/trackers/effort-steering/evidence/campaign-accounting-20261111/reconciliation.json"
    assert sha(old_path)=="f422a24515278bdfbb5853bfc1e34fb799dbed05c1077a6e70b0134a4beaa858"
    old=read(old_path)
    ledger=copy.deepcopy(old["ledger"])
    assert ledger["reservations"]==[]
    bindings=dict(old["receipt_bindings"])
    opening=Path(old["opening_balance_source"])
    assert sha(opening)==old["opening_balance_sha256"]
    for row in ledger["charges"]:
        assert sha(row["source"])==row["receipt_sha256"]
        if row["source"]!=str(opening):
            receipt=read(row["source"])
            assert receipt["scripted"] is False and receipt["unknown_provider_cost"] is False
            assert row["id"]=="native-client:"+receipt["session_id"]
            assert Decimal(receipt["cost_usd"])==Decimal(row["cost_usd"])
    assert len(ledger["holds"])==1
    hold=ledger["holds"][0]
    assert not hold["settled"] and hold["cost_usd"] is None and hold["reserved_usd"]=="4"
    assert sha(hold["source"])==hold["receipt_sha256"]
    predecessor=ROOT/"paid-campaign-path-v2"
    result=read(predecessor/"result.json")
    assert result["status"]=="stopped" and len(result["attempts"])==2 and len(result["unexecuted"])==6
    assert all(row["grade"] is None and row["cost"]["unknown"] is False for row in result["attempts"])
    final_ledger=read(predecessor/"ledger-final.json")
    append=[]
    for path in (predecessor/"attempts/00-L/repair/native/receipt.json",
                 predecessor/"attempts/01-R/investigate/native/receipt.json"):
        receipt=read(path)
        assert receipt["scripted"] is False and receipt["unknown_provider_cost"] is False
        assert receipt["cost_coverage"]["forwarded_at_terminal"]==receipt["cost_coverage"]["forwarded_total"]
        identity="native-client:"+receipt["session_id"]
        assert identity not in {row["id"] for row in ledger["charges"]}
        record={"id":identity,"source":str(path),"receipt_sha256":sha(path),
                "cost_usd":receipt["cost_usd"],"basis":"Final closed native client charge, independent of workflow/capture validity."}
        ledger["charges"].append(record)
        bindings[str(path)]=sha(path)
        append.append(record)
    audit=ROOT/"path-recovery-registration-v1/pretransport-audit.json"
    report=ROOT/"review-target-rebind-v1/report.json"
    readback=ROOT/"review-target-rebind-v1/readback.json"
    assert sha(audit)=="ec20d6ede5cec7bad9c56231c8466520c8591851d23bf08e2d31d4d51a65dce9"
    assert sha(report)=="ca713580877eab1047e65417c4f489678de0d8955c8f6562e685374300b1cbaa"
    assert sha(readback)=="fc3707aba209cca64db624c3648c9047fe9e3213848371476225e6de9485ac2f"
    assert read(report)["administrative_rebind"]["decision"]=="supported"
    assert read(readback)["causal_settlement"]["native_client_cost_usd"]=="0"
    assert read(readback)["causal_settlement"]["old_4usd_hold_released"] is False
    for item in read(audit)["evidence"]:
        assert sha(item["path"])==item["sha256"]
    with localcontext() as context:
        context.prec=128
        known=sum((Decimal(row["cost_usd"]) for row in ledger["charges"]),Decimal(0))
        native=sum((Decimal(row["cost_usd"]) for row in ledger["charges"] if row["source"]!=str(opening)),Decimal(0))
        allocated=known+Decimal("4")+Decimal("78")
        assert known==Decimal("64.768895999999998654")
        assert allocated==Decimal("146.768895999999998654") and allocated<=Decimal("200")
    carried=[{key:hold[key] for key in ("id","source","receipt_sha256","reserved_usd")}]
    reg={"ledger":ledger,"carried_holds":carried,"bindings":{**bindings,str(opening):sha(opening)}}
    admit_history(ledger,carried_holds=carried,bindings=reg["bindings"])
    assert Decimal(accounting_totals(ledger)["committed_usd"])==known+Decimal("4")
    reconciled={**copy.deepcopy(old),"ledger":ledger,"known_client_cost_usd":str(known),
        "native_receipts":len(ledger["charges"])-1,"native_client_cost_usd":str(native),
        "receipt_bindings":bindings,"proposed_new_allocation_usd":"78",
        "commitment_if_new_allocation_usd":str(allocated),
        "previous_reconciliation":{"path":str(old_path),"sha256":sha(old_path)},
        "new_terminal_receipts":append,"paid_ready":False,
        "closed_predecessor":{"result":{"path":str(predecessor/"result.json"),"sha256":sha(predecessor/"result.json")},
            "ledger":{"path":str(predecessor/"ledger-final.json"),"sha256":sha(predecessor/"ledger-final.json")},
            "status":"stopped, no active actor workflow; no further launch under this immutable existing output root",
            "unexecuted_attempts":6,
            "retired_unspent_reservations":final_ledger["reservations"],
            "basis":"Controller terminal state and all observed charges settled; no unknown client charge in this predecessor. Raw final ledger is unchanged."},
        "separate_pretransport_causal_settlement":{"audit":{"path":str(audit),"sha256":sha(audit)},
            "independent_report":{"path":str(report),"sha256":sha(report)},
            "readback":{"path":str(readback),"sha256":sha(readback)},
            "cost_is_direct_provider_receipt":False,"raw_unknown_receipt_unchanged":True},
        "limits":old["limits"]+[
            "Retired reservations are unspent future allocations of a closed predecessor, not erased costs.",
            "The two real stopped-pilot charges remain fully counted; new pilot does not inherit its candidate/quality results.",
            "No new provider/model call; root/review/embedding/compute cost remains unmeasured."]}
    DEST.mkdir(exist_ok=False)
    path=DEST/"reconciliation.json"
    path.write_text(json.dumps(reconciled,indent=2,sort_keys=True)+"\n")
    reg["bindings"][str(path)]=sha(path)
    checked=verify_accounting(reg,{"path":str(path),"sha256":sha(path)})
    (DEST/"consuming-check.json").write_text(json.dumps(checked,indent=2)+"\n")
    print(json.dumps(checked))
if __name__=="__main__":
    main()
