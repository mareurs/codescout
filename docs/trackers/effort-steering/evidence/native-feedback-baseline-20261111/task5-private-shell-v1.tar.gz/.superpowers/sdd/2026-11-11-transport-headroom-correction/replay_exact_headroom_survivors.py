"""One bounded test-only correction; replay the exact observed survivor bytes."""
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time

WORK=Path(__file__).resolve().parents[3]
ROOT=Path("/var/tmp/ep11-01a15")
REVIEW=ROOT/"headroom-admission-review-v1"
OUT=ROOT/"headroom-bounded-correction-v1"

def read(path):
    return json.loads(Path(path).read_bytes())

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(path,value):
    with Path(path).open("x") as stream:
        json.dump(value,stream,indent=2,sort_keys=True)

def run(argv,cwd,log):
    start=time.monotonic()
    with log.open("xb") as stream:
        try:
            done=subprocess.run(argv,cwd=cwd,env={**os.environ,"PYTHONDONTWRITEBYTECODE":"1"},
                                stdout=stream,stderr=subprocess.STDOUT,timeout=120)
            code=done.returncode
            timeout=False
        except subprocess.TimeoutExpired:
            code=None
            timeout=True
    return {"exit_code":code,"timed_out":timeout,"elapsed_seconds":time.monotonic()-start,
            "log":{"path":str(log),"sha256":sha(log)}}

def main():
    staged=read(REVIEW/"stage-a-results.json")
    before=staged["source_before"]
    after={path:sha(path) for path in before}
    changed=[path for path in before if before[path]!=after[path]]
    assert changed==[str(WORK/"tools/effort_protocol/test_paid_admission.py")],changed
    assert staged["counts"]=={"killed":10,"survived":2,"invalid":0,"equivalent":0}
    OUT.mkdir(exist_ok=False)
    originals={row["id"]:row for row in staged["mutations"] if row["id"] in ("H09","H10")}
    assert set(originals)=={"H09","H10"}
    test_path=Path("tools/effort_protocol/test_paid_admission.py")
    command=["python3","-B","-m","unittest","-v","test_campaign","test_paid_admission","test_runner"]
    def tree(name):
        target=OUT/name/"tree"
        target.parent.mkdir()
        shutil.copytree(REVIEW/"baseline",target,symlinks=True)
        for source,digest in before.items():
            relative=Path(source).relative_to(WORK) if Path(source).is_relative_to(WORK) else None
            if relative is not None and (target/relative).is_file():
                assert sha(target/relative)==digest,source
        shutil.copy2(WORK/test_path,target/test_path)
        return target
    baseline_tree=tree("baseline")
    baseline=run(command,baseline_tree/"tools/effort_protocol",OUT/"baseline.log")
    assert baseline["exit_code"]==0 and not baseline["timed_out"]
    text=Path(baseline["log"]["path"]).read_text()
    measured=re.search(r"Ran (\d+) tests",text)
    assert measured and int(measured.group(1))==81,text[-2000:]
    replays=[]
    for identity in ("H09","H10"):
        original=originals[identity]
        assert original["test_exit_code"]==0 and original["syntax_exit_code"]==0
        assert not original["timed_out"] and not original["syntax_timed_out"]
        assert sha(original["original"]["path"])==original["original"]["sha256"]==sha(original["source"])
        assert sha(original["mutated"]["path"])==original["mutated"]["sha256"]
        target=tree(identity)
        applied=target/"tools/effort_protocol/paid_admission.py"
        applied.write_bytes(Path(original["mutated"]["path"]).read_bytes())
        assert sha(applied)==original["mutated"]["sha256"]
        syntax=run(["python3","-B","-c","import ast,pathlib,sys; ast.parse(pathlib.Path(sys.argv[1]).read_bytes())",str(applied)],
                   target,OUT/identity/"syntax.log")
        tested=run(command,target/"tools/effort_protocol",OUT/identity/"test.log")
        assert syntax["exit_code"]==0 and not syntax["timed_out"]
        assert tested["exit_code"]==1 and not tested["timed_out"]
        failure=Path(tested["log"]["path"]).read_text()
        expected=("test_proposed_allocation_alone_crosses_otherwise_valid_ceiling" if identity=="H09"
                  else "test_only_declared_allocation_can_disagree_with_matching_commitment")
        assert "FAIL: "+expected in failure and "AssertionError: ValueError not raised" in failure,failure[-4000:]
        assert sha(applied)==original["mutated"]["sha256"]
        replays.append({"id":identity,"source":original["source"],"original":original["original"],
                        "mutated":{"path":str(applied),"sha256":sha(applied)},
                        "syntax_exit_code":syntax["exit_code"],"syntax_timed_out":syntax["timed_out"],
                        "test_exit_code":tested["exit_code"],"timed_out":tested["timed_out"],
                        "log":tested["log"],"syntax_log":syntax["log"],"observed_outcome":"killed",
                        "original_survivor_log":original["log"]})
    assert after=={path:sha(path) for path in before}
    pending={"schema":"effort-bounded-review-correction-v1","correction_rounds":1,
             "review_sha256":None,"target_sha256":None,"source_before":before,"source_after":after,
             "outstanding":[],"findings_closed":["HA-F01","HA-F02"],"replays":replays,
             "baseline":baseline,"baseline_tests":81,"changed":changed,
             "ready_for_target_binding":False,"producer":{"path":str(Path(__file__).resolve()),"sha256":sha(__file__)},
             "limits":["Exact original H09/H10 mutation bytes killed by assertion failures, not syntax/import failures.",
                       "Final review SHA/target deliberately missing until actual candidate/report exists.",
                       "Production source unchanged; only two tests added to the existing parent file."]}
    save(OUT/"pending-resolution.json",pending)
    print(json.dumps({"baseline_tests":81,"baseline_pass":True,"exact_survivors_killed":[r["id"] for r in replays],
                      "parent_sources_unchanged_during_replay":True,"paid_ready":False}),flush=True)

if __name__=="__main__":
    main()
