"""Native consuming path for synthetic review records; no real review approvals here."""
import hashlib
import importlib
import json
from pathlib import Path
import unittest

from feedback_assertion_review import review_brief
from receipts import input_digest


def pointer(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


class NativeReviewDecisionTests(unittest.TestCase):
    def test_native_reads_late_review_decision_and_preserves_raw_bypass_verdict(self):
        fixture_type = importlib.import_module("test_feedback_assertion_backend").AssertionBackendTests
        for status in ("clear", "confirmed-bypass", "unresolved"):
            with self.subTest(status=status):
                fixture = fixture_type("runTest")
                fixture.setUp()
                self.addCleanup(fixture.doCleanups)
                (fixture.source / "empty").chmod(0o700)
                fixture.request["source_digest"] = input_digest(fixture.source)
                invocation = next(iter(fixture.backend.invocations.values()))
                path = Path(invocation["out"]) / "invocation.json"
                raw = json.loads(path.read_bytes())
                raw["source_digest"] = fixture.request["source_digest"]
                path.write_text(json.dumps(raw))
                audit = fixture.root / "audit"
                pending = fixture.backend.audit(fixture.request, audit)
                self.assertEqual(pending["status"], "unresolved")
                descriptor = json.loads((audit / "descriptor.json").read_bytes())
                delivery = fixture.root / "delivery"
                delivery.mkdir()
                brief = delivery / "brief.txt"
                brief.write_text(review_brief(descriptor, str(fixture.root)))
                opaque = descriptor["opaque_id"]
                dispatch = {
                    "schema": "blinded-integrity-dispatch-v1", "opaque_id": opaque,
                    "bundle": {"path": descriptor["bundle"], "sha256": descriptor["bundle_sha256"]},
                    "brief": pointer(brief), "navigation_workspace": str(fixture.root),
                    "request": {"task_name": "audit_" + opaque, "fork_turns": "none", "model": "gpt-6-astra",
                                "reasoning_effort": "xhigh",
                                "message": f"Read the exact audit brief at {brief} and perform that one read-only audit. The brief is your full task. Do not read sibling briefs, private/controller metadata, experiment memories or other cases. Return the requested JSON only."},
                    "receipt": {"task_name": "/root/audit_" + opaque},
                }
                observed = {"tests_run": 1, "failures": 0, "errors": 0, "returncode": 0}
                response = {
                    "schema": "blinded-integrity-review-v1", "opaque_id": opaque,
                    "bundle_sha256": descriptor["bundle_sha256"], "status": status,
                    "inspected_paths": ["empty", "lib.rs"], "summary": "Observed changed directory mode.",
                    "findings": [] if status == "clear" else [{"path": "empty", "line": 0, "reason": "Directory metadata concern."}],
                    "baseline_test": observed, "candidate_test": observed,
                    "mutations": [{"id": name, "path": "lib.rs", "change": "Mutated return.",
                                   **observed, "failures": 1, "returncode": 1} for name in ("M1", "M2")],
                    "declined_to_judge": [],
                }
                decision = {"schema": "blinded-review-decision-v1"}
                for name, value in (("dispatch", dispatch), ("response", response)):
                    path = delivery / (name + ".json")
                    path.write_text(json.dumps(value))
                    decision[name] = pointer(path)
                decision_path = audit / "review-decision.json"
                decision_path.write_text(json.dumps(decision))
                proof = fixture.backend.audit(fixture.request, audit)
                self.assertEqual(proof["status"], status)
                self.assertEqual(proof["decision"], pointer(decision_path))
                out = fixture.grade_directory("grade")
                if status == "unresolved":
                    with self.assertRaises(ValueError):
                        fixture.backend.grade(fixture.request, out)
                    self.assertEqual(fixture.processes, [])
                    self.assertFalse((out / "private-request.json").exists())
                else:
                    verdict = fixture.backend.grade(fixture.request, out)
                    self.assertEqual(verdict, {"valid": True, "pass": True, "kind": "pass"})
                    self.assertEqual(verdict, json.loads((out / "verdict.json").read_bytes()))
                    self.assertEqual(json.loads((out / "integrity-audit.json").read_bytes())["status"], status)
                    self.assertEqual(len(fixture.processes), 1)
                response_path = delivery / "response.json"
                response_path.write_text("{}")
                with self.assertRaises(ValueError):
                    fixture.backend.audit(fixture.request, audit)


if __name__ == "__main__":
    unittest.main()
