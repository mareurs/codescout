"""Prospective paid authority must consume full reference closure and distinct actor roles."""
import copy
import importlib
from pathlib import Path
import unittest
from unittest.mock import patch

import feedback_admission as subject
from receipts import input_digest


class ReferenceAdmissionTests(unittest.TestCase):
    def setUp(self):
        fixture = importlib.import_module("test_feedback_public_controls").FeedbackPublicControlTests()
        fixture.setUp()
        self.addCleanup(fixture.doCleanups)
        self.fixture = fixture

    def test_generic_reader_reopens_full_reference_and_both_exact_commands(self):
        self.assertTrue(callable(getattr(subject, "verify_reference_controls", None)),
                        "mandatory full-reference admission reader is missing")
        with patch.object(subject.legacy, "verify_receipt", return_value=self.fixture.facts):
            proof = subject.verify_reference_controls(self.fixture.reg, self.fixture.proof)
        self.assertEqual(proof["task"]["reference"]["verified_commands"], 2)
        self.assertEqual(proof["task"]["closure"]["role"], "private-reference-only")

    def test_wrong_actor_role_missing_full_patch_and_broader_failure_cannot_construct_authority(self):
        for case in ("actor-is-private-reference", "omitted-full-patch", "broader-exit101"):
            with self.subTest(case=case):
                f = self.fixture
                reg, proof = copy.deepcopy(f.reg), copy.deepcopy(f.proof)
                if case == "actor-is-private-reference":
                    reg["tasks"]["task"]["source"] = str(f.reference)
                    reg["tasks"]["task"]["source_sha256"] = input_digest(f.reference)
                elif case == "omitted-full-patch":
                    del proof["task"]["reference"]["inputs"]
                else:
                    proof["task"]["reference"]["commands"][1]["result"] = f.bound(
                        "failed-" + case + ".json", {**f.facts, "exit_code": 101, "receipt": f.facts})
                    reg["bindings"] = dict(f.reg["bindings"])
                reg.update(mode="paid", admission={key: {} for key in subject._ROLES})
                reg["admission"].update(credential_path="/nonexistent/credential", public_commands=proof)
                with patch.object(subject, "validate_registration"), \
                     patch.object(subject, "verify_population", return_value={}), \
                     patch.object(subject.legacy, "verify_receipt", return_value=f.facts), \
                     patch.object(subject, "_credential", side_effect=AssertionError("credential path reached")):
                    with self.assertRaises(ValueError):
                        subject.FeedbackAdmission(reg, "/nonexistent/credential")
