"""Portable blinded integrity inputs, separate from hidden tests and model outcomes."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import tarfile
import tempfile
import uuid

from evaluator_entry import _entries, verify_candidate
from receipts import input_digest

SCHEMA = "blinded-candidate-audit-v1"
CAPTURE_KEYS = {"source", "source_digest", "public_baseline", "public_baseline_sha256",
                "patch", "patch_sha256", "capture_proof", "capture_proof_sha256"}


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _file(path):
    path = Path(path)
    _require(path.is_absolute() and path.resolve() == path and path.is_file()
             and not path.is_symlink(), "audit artifact is not a physical regular file")
    return path


def _context(issue, protected_roots):
    _require(isinstance(issue, str) and bool(issue.strip()), "audit original issue is missing")
    _require(isinstance(protected_roots, list) and protected_roots
             and len(protected_roots) == len(set(protected_roots)), "audit protected roots differ")
    for name in protected_roots:
        _require(isinstance(name, str) and name and "\x00" not in name,
                 "audit protected root is missing")
        path = PurePosixPath(name)
        _require(not path.is_absolute() and str(path) == name and name != "."
                 and ".." not in path.parts, "audit protected root is unsafe")
    return {"issue_sha256": _sha(issue.encode()), "protected_roots": list(protected_roots)}


def _capture(request):
    _require(isinstance(request, dict) and set(request) == CAPTURE_KEYS,
             "audit receives exact capture bindings only")
    for key, digest_key in (("source", "source_digest"), ("public_baseline", "public_baseline_sha256")):
        path = Path(request[key])
        _require(path.is_absolute() and path.resolve() == path and path.is_dir()
                 and not path.is_symlink(), "audit source is not physical")
        _require(input_digest(path) == request[digest_key], "audit captured source changed")
    source, baseline = Path(request["source"]), Path(request["public_baseline"])
    _require(not source.is_relative_to(baseline) and not baseline.is_relative_to(source),
             "audit source roles overlap")
    for key in ("patch", "capture_proof"):
        _require(_sha(_file(request[key]).read_bytes()) == request[key + "_sha256"],
                 "audit capture artifact changed")
    return json.loads(json.dumps(request))


def _json(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, separators=(",", ":"), allow_nan=False)
        stream.write("\n")


def _archive(path, root, entries):
    with tarfile.open(path, "x:") as archive:
        for name, entry in entries.items():
            info = tarfile.TarInfo(name)
            info.mtime, info.uid, info.gid = 0, 0, 0
            info.mode = entry.get("mode", 0o777)
            if entry["kind"] == "directory":
                info.type = tarfile.DIRTYPE
                archive.addfile(info)
            elif entry["kind"] == "link":
                info.type, info.linkname = tarfile.SYMTYPE, entry["target"]
                archive.addfile(info)
            else:
                info.size = (root / name).stat().st_size
                with (root / name).open("rb") as stream:
                    archive.addfile(info, stream)


def _archive_entries(path):
    result = {}
    with tarfile.open(path, "r:") as archive:
        for member in archive:
            name = member.name
            relative = PurePosixPath(name)
            _require(name and str(relative) == name and not relative.is_absolute()
                     and ".." not in relative.parts and name not in result,
                     "audit archive member is unsafe or repeated")
            _require(member.uid == member.gid == member.mtime == 0
                     and member.uname == member.gname == "", "audit archive leaks host metadata")
            _require(set(member.pax_headers) <= {"path", "linkpath", "size"},
                     "audit archive extension leaks controller metadata")
            if member.isdir():
                entry = {"kind": "directory", "mode": member.mode}
            elif member.issym():
                _require(not PurePosixPath(member.linkname).is_absolute(), "audit archive link is not portable")
                entry = {"kind": "link", "target": member.linkname}
            elif member.isfile():
                with archive.extractfile(member) as stream:
                    entry = {"kind": "file", "mode": member.mode,
                             "sha256": hashlib.file_digest(stream, "sha256").hexdigest()}
            else:
                raise ValueError("unsupported audit archive member")
            result[name] = entry
    return result


def prepare_audit(request: dict, issue: str, protected_roots: list[str], output: Path) -> dict:
    """Export full public capture, never invocation metadata or private canonical bytes."""
    capture, context = _capture(request), _context(issue, protected_roots)
    output = Path(output).absolute()
    _require(output.parent.is_dir() and output.parent.resolve() == output.parent
             and not output.exists() and not output.is_symlink()
             and all(not output.is_relative_to(Path(capture[key]))
                     and not Path(capture[key]).is_relative_to(output)
                     for key in ("source", "public_baseline")), "audit output exists or overlaps source")
    output.mkdir(mode=0o700)
    opaque = uuid.uuid4().hex
    # Private equivalence artifacts stay outside the exported review input.
    with tempfile.TemporaryDirectory(prefix="audit-equivalence-") as temporary:
        verify_candidate(capture, Path(temporary) / "source")
    tree = output / "review"
    tree.mkdir(mode=0o700)
    for role, key in (("baseline", "public_baseline"), ("candidate", "source")):
        shutil.copytree(capture[key], tree / role, symlinks=True)
        _require(input_digest(tree / role) == capture["public_baseline_sha256" if role == "baseline"
                                                    else "source_digest"], "audit source copy differs")
    (tree / "issue.txt").write_text(issue)
    (tree / "candidate.patch").write_bytes(_file(capture["patch"]).read_bytes())
    metadata = {"schema": "blind-review-inputs-v1", "opaque_id": opaque, **context,
                "baseline_sha256": capture["public_baseline_sha256"],
                "candidate_sha256": capture["source_digest"], "patch_sha256": capture["patch_sha256"]}
    _json(tree / "review.json", metadata)
    for name in ("issue.txt", "candidate.patch", "review.json"):
        (tree / name).chmod(0o644)
    entries = _entries(tree)
    manifest = output / "manifest.json"
    _json(manifest, {"schema": SCHEMA, "opaque_id": opaque, "entries": entries, "metadata": metadata})
    archive = output / "review.tar"
    _archive(archive, tree, entries)
    descriptor = {"schema": SCHEMA, "opaque_id": opaque, "capture": capture, **context,
                  "manifest": str(manifest), "manifest_sha256": _sha(manifest.read_bytes()),
                  "bundle": str(archive), "bundle_sha256": _sha(archive.read_bytes())}
    _require(_entries(tree) == entries and _capture(request) == capture, "audit inputs changed during export")
    return descriptor


def verify_audit(descriptor: dict, request: dict, decision: dict | None,
                 *, issue: str, protected_roots: list[str]) -> dict:
    """Require original task/capture plus identical bytes or a bound independent ruling."""
    capture, context = _capture(request), _context(issue, protected_roots)
    _require(isinstance(descriptor, dict) and set(descriptor) == {
        "schema", "opaque_id", "capture", "issue_sha256", "protected_roots",
        "manifest", "manifest_sha256", "bundle", "bundle_sha256"}, "audit descriptor is incomplete")
    _require(descriptor["schema"] == SCHEMA and isinstance(descriptor["opaque_id"], str)
             and re.fullmatch("[0-9a-f]{32}", descriptor["opaque_id"])
             and descriptor["capture"] == capture
             and all(descriptor[key] == value for key, value in context.items()), "audit original binding differs")
    paths = {}
    for key in ("manifest", "bundle"):
        paths[key] = _file(descriptor[key])
        _require(_sha(paths[key].read_bytes()) == descriptor[key + "_sha256"], "audit review bytes changed")
    manifest = json.loads(paths["manifest"].read_bytes())
    expected_metadata = {"schema": "blind-review-inputs-v1", "opaque_id": descriptor["opaque_id"], **context,
                         "baseline_sha256": capture["public_baseline_sha256"],
                         "candidate_sha256": capture["source_digest"], "patch_sha256": capture["patch_sha256"]}
    _require(set(manifest) == {"schema", "opaque_id", "entries", "metadata"}
             and manifest["schema"] == SCHEMA and manifest["opaque_id"] == descriptor["opaque_id"]
             and manifest["metadata"] == expected_metadata, "audit review context differs")
    entries = _archive_entries(paths["bundle"])
    _require(entries == manifest["entries"], "audit archive contradicts its manifest")
    for prefix, key in (("baseline", "public_baseline"), ("candidate", "source")):
        actual = {name[len(prefix) + 1:]: value for name, value in entries.items()
                  if name.startswith(prefix + "/")}
        _require(actual == _entries(capture[key]), "audit archive source inventory differs")
    expected_top = {"baseline", "candidate", "issue.txt", "candidate.patch", "review.json"}
    _require({PurePosixPath(name).parts[0] for name in entries} == expected_top,
             "audit review member population differs")
    _require(entries["issue.txt"] == {"kind": "file", "mode": 0o644, "sha256": context["issue_sha256"]}
             and entries["candidate.patch"] == {"kind": "file", "mode": 0o644, "sha256": capture["patch_sha256"]},
             "audit issue or patch export differs")
    expected_review = (json.dumps(expected_metadata, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n").encode()
    _require(entries["review.json"] == {"kind": "file", "mode": 0o644, "sha256": _sha(expected_review)},
             "audit exported review metadata differs")
    if decision is not None:
        from feedback_assertion_review import verify_review
        return verify_review(descriptor, decision)
    unchanged = (not _file(capture["patch"]).read_bytes()
                 and capture["source_digest"] == capture["public_baseline_sha256"])
    return {"schema": SCHEMA, "opaque_id": descriptor["opaque_id"],
            "bundle_sha256": descriptor["bundle_sha256"], "terminal": unchanged,
            "status": "clear" if unchanged else "unresolved",
            "method": "identical-source" if unchanged else "blinded-review-required"}
