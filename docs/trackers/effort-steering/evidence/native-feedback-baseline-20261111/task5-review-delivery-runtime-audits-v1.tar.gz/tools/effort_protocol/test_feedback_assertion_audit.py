"""Audit input closure, blinding metadata and unchanged-source integrity proof."""
import copy
import hashlib
import importlib
import json
import os
from pathlib import Path
import shutil
import tarfile
import tempfile
import unittest

from receipts import input_digest

try:
    subject = importlib.import_module("feedback_assertion_audit")
except ModuleNotFoundError:
    subject = None


def sha(data):
    return hashlib.sha256(data).hexdigest()


class AssertionAuditTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(subject, "blinded candidate integrity boundary is missing")
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.baseline = self.root / "original"
        (self.baseline / "src").mkdir(parents=True)
        (self.baseline / "empty").mkdir(mode=0o750)
        (self.baseline / ".claude").mkdir()
        (self.baseline / ".claude/rules.md").write_text("original project rule\n")
        (self.baseline / "src/lib.rs").write_text("pub fn value() -> u8 { 1 }\n")
        self.candidate = self.root / "captured"
        shutil.copytree(self.baseline, self.candidate)
        self.patch = self.root / "capture.patch"
        self.patch.write_bytes(b"")
        self.capture = self.root / "capture.json"
        self.capture.write_text(json.dumps({"complete": True, "sha256": sha(b""), "bytes": 0}))
        self.request = {
            "source": str(self.candidate), "source_digest": input_digest(self.candidate),
            "public_baseline": str(self.baseline), "public_baseline_sha256": input_digest(self.baseline),
            "patch": str(self.patch), "patch_sha256": sha(self.patch.read_bytes()),
            "capture_proof": str(self.capture), "capture_proof_sha256": sha(self.capture.read_bytes()),
        }

    def test_unchanged_requires_empty_patch_and_full_digest_equality(self):
        original = copy.deepcopy(self.request)
        baseline_before, candidate_before = input_digest(self.baseline), input_digest(self.candidate)
        descriptor = subject.prepare_audit(self.request, "Return the requested value.", ["tests"], self.root / "audit")
        proof = subject.verify_audit(descriptor, self.request, None,
                                     issue="Return the requested value.", protected_roots=["tests"])
        self.assertEqual(proof["status"], "clear")
        self.assertEqual(proof["method"], "identical-source")
        self.assertIs(proof["terminal"], True)
        self.assertEqual(self.request, original)
        self.assertEqual(input_digest(self.baseline), baseline_before)
        self.assertEqual(input_digest(self.candidate), candidate_before)
        # Git's file-only patch equivalence cannot license a changed directory mode.
        (self.candidate / "empty").chmod(0o700)
        self.request["source_digest"] = input_digest(self.candidate)
        changed = subject.prepare_audit(self.request, "Return the requested value.", ["tests"], self.root / "changed")
        changed_proof = subject.verify_audit(changed, self.request, None,
                                             issue="Return the requested value.", protected_roots=["tests"])
        self.assertEqual(changed_proof["status"], "unresolved")
        self.assertIs(changed_proof["terminal"], False)

    def rearchive(self, descriptor, mutate, *, rebind_manifest=False):
        tree = Path(descriptor["bundle"]).parent / "review"
        mutate(tree)
        archive = Path(descriptor["bundle"])
        archive.unlink()
        entries = subject._entries(tree)
        subject._archive(archive, tree, entries)
        descriptor["bundle_sha256"] = sha(archive.read_bytes())
        if rebind_manifest:
            manifest = Path(descriptor["manifest"])
            data = json.loads(manifest.read_bytes())
            data["entries"] = entries
            manifest.write_text(json.dumps(data))
            descriptor["manifest_sha256"] = sha(manifest.read_bytes())

    def test_archive_and_manifest_must_agree_even_when_outer_hash_is_updated(self):
        descriptor = subject.prepare_audit(self.request, "Original task", ["tests"], self.root / "audit")
        self.rearchive(descriptor, lambda tree: (tree / "review.json").write_text('{"injected":"ARM_SENTINEL"}'))
        with self.assertRaises(ValueError):
            subject.verify_audit(descriptor, self.request, None, issue="Original task", protected_roots=["tests"])

    def test_review_json_cannot_disagree_with_original_task_despite_rehashed_inventory(self):
        descriptor = subject.prepare_audit(self.request, "Original task", ["tests"], self.root / "audit")
        self.rearchive(descriptor, lambda tree: (tree / "review.json").write_text('{"injected":"ARM_SENTINEL"}'),
                       rebind_manifest=True)
        with self.assertRaises(ValueError):
            subject.verify_audit(descriptor, self.request, None, issue="Original task", protected_roots=["tests"])

    def test_export_retains_full_source_but_contains_no_controller_metadata(self):
        descriptor = subject.prepare_audit(self.request, "Original task", ["tests"], self.root / "audit")
        with tarfile.open(descriptor["bundle"], "r:") as archive:
            members = archive.getmembers()
            names = [member.name for member in members]
            self.assertEqual(len(names), len(set(names)))
            self.assertIn("baseline/.claude/rules.md", names)
            self.assertIn("candidate/.claude/rules.md", names)
            self.assertIn("candidate/empty", names)
            metadata = json.loads(archive.extractfile("review.json").read())
            self.assertEqual(set(metadata), {"schema", "opaque_id", "issue_sha256", "protected_roots",
                                             "baseline_sha256", "candidate_sha256", "patch_sha256"})
            for member in members:
                self.assertEqual((member.uid, member.gid, member.mtime, member.uname, member.gname),
                                 (0, 0, 0, "", ""))
                self.assertFalse(member.name.startswith("/"))
            self.assertNotIn(str(self.root), json.dumps(metadata))
        # Exact request interface prevents passing model/arm/cost/private metadata through.
        for key in ("arm", "cost", "model_narrative", "gold", "private_outcome"):
            with self.subTest(key=key), self.assertRaises(ValueError):
                subject.prepare_audit(dict(self.request, **{key: "CONTROLLER_SENTINEL"}),
                                      "Original task", ["tests"], self.root / ("forbidden-" + key))

    def test_original_issue_protected_scope_source_patch_and_artifact_drift_are_refused(self):
        descriptor = subject.prepare_audit(self.request, "Original task", ["tests"], self.root / "audit")
        for issue, roots in (("Altered task", ["tests"]), ("Original task", ["other"])):
            with self.subTest(issue=issue, roots=roots), self.assertRaises(ValueError):
                subject.verify_audit(descriptor, self.request, None, issue=issue, protected_roots=roots)
        for key in ("manifest", "bundle"):
            artifact = Path(descriptor[key])
            before = artifact.read_bytes()
            artifact.write_bytes(before + b"changed")
            with self.subTest(key=key), self.assertRaises(ValueError):
                subject.verify_audit(descriptor, self.request, None, issue="Original task", protected_roots=["tests"])
            artifact.write_bytes(before)
        (self.candidate / "src/lib.rs").write_text("mutated after capture\n")
        with self.assertRaises(ValueError):
            subject.verify_audit(descriptor, self.request, None, issue="Original task", protected_roots=["tests"])

    def test_export_is_independent_of_private_controller_umask(self):
        old = os.umask(0o077)
        try:
            descriptor = subject.prepare_audit(self.request, "Original task", ["tests"], self.root / "audit")
            proof = subject.verify_audit(descriptor, self.request, None,
                                         issue="Original task", protected_roots=["tests"])
        finally:
            os.umask(old)
        self.assertEqual(proof["status"], "clear")

    def test_archive_extension_metadata_cannot_smuggle_controller_labels(self):
        import io
        path = self.root / "tainted.tar"
        with tarfile.open(path, "w", format=tarfile.PAX_FORMAT) as archive:
            member = tarfile.TarInfo("issue.txt")
            member.size = 1
            member.pax_headers = {"comment": "PRIVATE_ARM_SENTINEL"}
            archive.addfile(member, io.BytesIO(b"x"))
        with self.assertRaises(ValueError):
            subject._archive_entries(path)

    def test_manifest_inventory_cannot_lie_about_an_unchanged_export(self):
        descriptor = subject.prepare_audit(self.request, "Original task", ["tests"], self.root / "audit")
        path = Path(descriptor["manifest"])
        manifest = json.loads(path.read_bytes())
        manifest["entries"]["issue.txt"]["sha256"] = "0" * 64
        path.write_text(json.dumps(manifest))
        descriptor["manifest_sha256"] = sha(path.read_bytes())
        with self.assertRaises(ValueError):
            subject.verify_audit(descriptor, self.request, None, issue="Original task", protected_roots=["tests"])
