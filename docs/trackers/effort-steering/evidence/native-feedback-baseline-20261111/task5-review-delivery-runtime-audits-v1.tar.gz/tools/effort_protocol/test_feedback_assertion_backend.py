"""New-policy private evaluator cannot run without its exact terminal integrity audit."""
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import types
import unittest
from unittest.mock import patch

import feedback_policy
import native_campaign as subject
from receipts import input_digest
from trusted_test_inputs import seal_test_inputs


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class AssertionBackendTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.baseline = self.root / "baseline"
        (self.baseline / "tests").mkdir(parents=True)
        (self.baseline / "empty").mkdir(mode=0o750)
        (self.baseline / "lib.rs").write_text("public source\n")
        (self.baseline / "tests/assertion.txt").write_text("original expectation\n")
        self.source = self.root / "captured"
        shutil.copytree(self.baseline, self.source)
        sealed = seal_test_inputs(self.baseline, ["tests"], self.root / "sealed")
        self.config = self.root / "config.json"
        self.config.write_text(json.dumps({"trusted_test_inputs": sealed}))
        invocation = self.root / "invocation"
        native = invocation / "native"
        native.mkdir(parents=True)
        (native / "candidate.patch").write_bytes(b"")
        (native / "candidate-capture.json").write_text(json.dumps({
            "complete": True, "baseline_commit": "base", "sha256": sha(native / "candidate.patch"), "bytes": 0}))
        (invocation / "invocation.json").write_text(json.dumps({
            "candidate": str(self.source), "source_digest": input_digest(self.source)}))
        self.backend = subject.NativeCampaignBackend(mode="scripted")
        self.backend.registration = {"schema": feedback_policy.SCHEMA, "tasks": {"task": {
            "source": str(self.baseline), "source_sha256": input_digest(self.baseline),
            "public_packet": {"issue": "Fix the original behavior."}, "backend": {
                "public": {"capture_base_commit": "base"}, "private": {
                    "config": str(self.config), "config_sha256": sha(self.config), "entry": "/unreachable/private.py"}}}},
            "bindings": {}}
        self.backend.invocations = {"id": {"out": str(invocation), "task_id": "task", "arm": "L"}}
        self.request = {"task_id": "task", "arm": "L", "source": str(self.source),
                        "source_digest": input_digest(self.source)}
        self.stack = self.enterContext(__import__("contextlib").ExitStack())
        self.stack.enter_context(patch.object(self.backend, "_closed"))
        self.stack.enter_context(patch.object(subject, "_verify_private"))
        self.processes = []
        self.real_run = subject.subprocess.run
        self.stack.enter_context(patch.object(subject.subprocess, "run", side_effect=self.private_process))

    def private_process(self, argv, **kwargs):
        if argv[0] == "git":
            return self.real_run(argv, **kwargs)
        self.processes.append(argv)
        out = Path(argv[-1])
        (out / "verdict.json").write_text(json.dumps({"valid": True, "pass": True, "kind": "pass"}))
        return types.SimpleNamespace(returncode=0)

    def grade_directory(self, name):
        out = self.root / name
        out.mkdir()
        return out

    def test_missing_integrity_audit_refuses_before_any_private_artifact_or_process(self):
        out = self.grade_directory("grade")
        with self.assertRaisesRegex(ValueError, "integrity audit"):
            self.backend.grade(self.request, out)
        self.assertFalse((out / "private-request.json").exists())
        self.assertEqual(self.processes, [])

    def test_exact_unchanged_audit_reaches_raw_grader_and_keeps_verdict(self):
        self.assertTrue(callable(getattr(self.backend, "audit", None)), "native integrity audit dispatch missing")
        proof = self.backend.audit(self.request, self.root / "audit")
        self.assertEqual(proof["status"], "clear")
        out = self.grade_directory("grade")
        result = self.backend.grade(self.request, out)
        self.assertEqual(result, json.loads((out / "verdict.json").read_bytes()))
        self.assertEqual(result, {"valid": True, "pass": True, "kind": "pass"})
        self.assertEqual(len(self.processes), 1)

    def test_unresolved_mode_only_capture_refuses_before_private_publication(self):
        self.assertTrue(callable(getattr(self.backend, "audit", None)), "native integrity audit dispatch missing")
        (self.source / "empty").chmod(0o700)
        self.request["source_digest"] = input_digest(self.source)
        invocation = next(iter(self.backend.invocations.values()))
        path = Path(invocation["out"]) / "invocation.json"
        record = json.loads(path.read_bytes())
        record["source_digest"] = self.request["source_digest"]
        path.write_text(json.dumps(record))
        proof = self.backend.audit(self.request, self.root / "audit")
        self.assertEqual(proof["status"], "unresolved")
        out = self.grade_directory("grade")
        with self.assertRaisesRegex(ValueError, "integrity audit"):
            self.backend.grade(self.request, out)
        self.assertFalse((out / "private-request.json").exists())
        self.assertEqual(self.processes, [])

    def test_changed_audit_descriptor_cannot_be_used_before_private_publication(self):
        proof = self.backend.audit(self.request, self.root / "audit")
        path = Path(proof["descriptor"]["path"])
        path.write_bytes(path.read_bytes() + b"changed")
        out = self.grade_directory("grade")
        with self.assertRaisesRegex(ValueError, "integrity audit descriptor changed"):
            self.backend.grade(self.request, out)
        self.assertFalse((out / "private-request.json").exists())
        self.assertEqual(self.processes, [])

    def test_original_task_context_is_reopened_when_consuming_a_clear_audit(self):
        self.backend.audit(self.request, self.root / "audit")
        self.backend.registration["tasks"]["task"]["public_packet"]["issue"] = "altered acceptance"
        out = self.grade_directory("grade")
        with self.assertRaises(ValueError):
            self.backend.grade(self.request, out)
        self.assertFalse((out / "private-request.json").exists())
        self.assertEqual(self.processes, [])
