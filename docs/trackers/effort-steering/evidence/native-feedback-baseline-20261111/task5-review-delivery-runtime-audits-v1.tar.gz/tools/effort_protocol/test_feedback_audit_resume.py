"""Batch integrity barrier and primary-outcome preservation; resume cases follow."""
import copy
import importlib
import json
from pathlib import Path
import unittest
import uuid

import feedback_runner as subject


class AuditBatchTests(unittest.TestCase):
    def setUp(self):
        fixture = importlib.import_module("test_feedback_runner").FeedbackRunnerTests()
        fixture.setUp()
        self.addCleanup(fixture.doCleanups)
        self.fixture = fixture
        self.audited = []
        self.pending_at = None
        fixture.backend.audit = self.audit

    def audit(self, request, out):
        f = self.fixture
        self.assertTrue((f.out / "actor-batch-closed.json").is_file())
        self.assertTrue((f.out / "ledger-final.json").is_file())
        self.assertEqual(len(f.backend.calls), 16)
        index = len(self.audited)
        self.audited.append(copy.deepcopy(request))
        return {"schema": "blinded-candidate-audit-v1", "opaque_id": uuid.uuid4().hex,
                "terminal": index != self.pending_at,
                "status": "unresolved" if index == self.pending_at else "clear"}

    def test_later_unresolved_blocks_every_private_grade_and_retains_all_costs(self):
        self.pending_at = 15
        result = subject.run_campaign(self.fixture.reg, self.fixture.backend)
        self.assertEqual(self.fixture.backend.grades, [])
        self.assertEqual(len(self.audited), 16)
        self.assertEqual(result["status"], "audit_pending")
        self.assertEqual(len(result["attempts"]), 16)
        self.assertTrue(all(row["grade"] is None for row in result["attempts"]))
        self.assertFalse(result["analysis"]["interpretable"])
        self.assertEqual(result["analysis"]["setup_client_usd"], "0")
        self.assertTrue(all(row["cost"]["known_usd"] == "0.10" for row in result["attempts"]))
        self.assertTrue((self.fixture.out / "ledger-final.json").is_file())
        self.assertFalse((self.fixture.out / "grades").exists())

    def test_all_sixteen_audits_precede_the_first_private_grade(self):
        def before_grade(packet, out):
            self.assertEqual(len(self.audited), 16)
        self.fixture.backend.grade_hook = before_grade
        result = subject.run_campaign(self.fixture.reg, self.fixture.backend)
        self.assertEqual(result["status"], "completed")
        self.assertEqual(len(self.audited), 16)
        self.assertEqual(len(self.fixture.backend.grades), 16)
        self.assertTrue(result["integrity_audit"]["complete"])

    def test_confirmed_bypass_retains_raw_pass_but_primary_fails_without_dropping_cost_or_denominator(self):
        result = subject.run_campaign(self.fixture.reg, self.fixture.backend)
        for row in result["attempts"]:
            row["integrity_audit"] = {"status": "clear", "terminal": True}
        victim = result["attempts"][0]
        arm = victim["arm"]
        victim["integrity_audit"] = {"status": "confirmed-bypass", "terminal": True}
        before_cost = result["analysis"]["totals"][arm]["client_cost_usd"]
        report = subject.analyze_result(result)
        self.assertIs(victim["grade"]["pass"], True)
        self.assertEqual(report["totals"][arm]["accepted"], 3)
        self.assertEqual(report["totals"][arm]["valid_observed"], 4)
        self.assertEqual(report["totals"][arm]["client_cost_usd"], before_cost)

    def test_replayed_analysis_reopens_audit_index_instead_of_trusting_result_copy(self):
        result = subject.run_campaign(self.fixture.reg, self.fixture.backend)
        self.assertEqual(subject.analyze(self.fixture.reg, str(self.fixture.out))["totals"]["L"]["accepted"], 4)
        result["attempts"][0]["integrity_audit"]["status"] = "confirmed-bypass"
        (self.fixture.out / "result.json").write_text(json.dumps(result))
        with self.assertRaises(ValueError):
            subject.analyze(self.fixture.reg, str(self.fixture.out))

    def test_resume_uses_closed_captures_without_any_actor_authorization_or_ledger_write(self):
        import hashlib
        from unittest.mock import patch
        self.pending_at = 15
        initial = subject.run_campaign(self.fixture.reg, self.fixture.backend)
        self.assertEqual(initial["status"], "audit_pending")
        self.assertTrue(callable(getattr(subject, "resume_grading", None)), "actor-free grading resume missing")
        frozen = {p: p.read_bytes() for p in self.fixture.out.rglob("*")
                  if p.is_file() and ("attempts" in p.relative_to(self.fixture.out).parts
                                      or p.name in ("registration.json", "actor-batch-closed.json",
                                                    "ledger-final.json", "ledger-reserved.json", "result.json"))}
        self.pending_at = None
        restored = []
        def restore(reg, root):
            self.assertEqual(reg, self.fixture.reg)
            self.assertEqual(root, self.fixture.out)
            restored.append(root)
        self.fixture.backend.restore_closed = restore
        with patch.object(self.fixture.backend, "invoke", side_effect=AssertionError("actor invoked")), \
             patch.object(self.fixture.backend, "verify", side_effect=AssertionError("authorization restarted")):
            result = subject.resume_grading(self.fixture.reg, self.fixture.backend)
            with self.assertRaises(ValueError):
                subject.resume_grading(self.fixture.reg, self.fixture.backend)
        self.assertEqual(restored, [self.fixture.out])
        self.assertEqual(result["status"], "completed")
        self.assertEqual(len(self.fixture.backend.calls), 16)
        self.assertEqual(len(self.fixture.backend.grades), 16)
        self.assertEqual(result["resumed_from"]["sha256"], hashlib.sha256(frozen[self.fixture.out / "result.json"]).hexdigest())
        self.assertEqual([row["candidate"] for row in result["attempts"]],
                         [row["candidate"] for row in initial["attempts"]])
        self.assertTrue((self.fixture.out / "result-final.json").is_file())
        for path, original in frozen.items():
            self.assertEqual(path.read_bytes(), original, str(path))
        self.assertEqual(subject.analyze(self.fixture.reg, str(self.fixture.out))["totals"]["L"]["accepted"], 4)

    def test_unresolved_resume_does_not_publish_final_grade_or_change_original_checkpoint(self):
        from unittest.mock import patch
        self.pending_at = 15
        subject.run_campaign(self.fixture.reg, self.fixture.backend)
        self.assertTrue(callable(getattr(subject, "resume_grading", None)), "actor-free grading resume missing")
        before = (self.fixture.out / "result.json").read_bytes()
        self.pending_at = 31
        self.fixture.backend.restore_closed = lambda reg, root: None
        with patch.object(self.fixture.backend, "invoke", side_effect=AssertionError("actor invoked")):
            with self.assertRaises(ValueError):
                subject.resume_grading(self.fixture.reg, self.fixture.backend)
        self.assertEqual(self.fixture.backend.grades, [])
        self.assertFalse((self.fixture.out / "result-final.json").exists())
        self.assertEqual((self.fixture.out / "result.json").read_bytes(), before)

    def test_changed_closed_ledger_refuses_resume_before_restore_or_private_grade(self):
        from unittest.mock import patch
        self.pending_at = 15
        subject.run_campaign(self.fixture.reg, self.fixture.backend)
        self.assertTrue(callable(getattr(subject, "resume_grading", None)), "actor-free grading resume missing")
        (self.fixture.out / "ledger-final.json").write_bytes(b"altered")
        restored = []
        self.fixture.backend.restore_closed = lambda reg, root: restored.append(root)
        with patch.object(self.fixture.backend, "invoke", side_effect=AssertionError("actor invoked")):
            with self.assertRaises(ValueError):
                subject.resume_grading(self.fixture.reg, self.fixture.backend)
        self.assertEqual(restored, [])
        self.assertEqual(self.fixture.backend.grades, [])

    def test_native_restore_rehydrates_receipts_and_permanently_refuses_actor_dispatch(self):
        from unittest.mock import patch
        from native_campaign import NativeCampaignBackend
        self.pending_at = 15
        subject.run_campaign(self.fixture.reg, self.fixture.backend)
        backend = NativeCampaignBackend(mode="scripted")
        self.assertTrue(callable(getattr(backend, "restore_closed", None)), "native closed-capture restore missing")
        backend.restore_closed(self.fixture.reg, self.fixture.out)
        self.assertEqual(len(backend.invocations), 16)
        self.assertIsNone(backend.authorization)
        self.assertTrue(backend.closed_only)
        with patch("native_campaign.invoke_native", side_effect=AssertionError("actor started")):
            with self.assertRaises(ValueError):
                backend.invoke({}, self.fixture.out / "unregistered")
        for identity, invocation in backend.invocations.items():
            record = json.loads((Path(invocation["out"]) / "invocation.json").read_bytes())
            self.assertEqual(record["invocation_id"], identity)

    def test_resume_cannot_change_the_common_preparation_cost(self):
        from unittest.mock import patch
        self.pending_at = 15
        subject.run_campaign(self.fixture.reg, self.fixture.backend)
        self.pending_at = None
        checkpoint = self.fixture.out / "result.json"
        data = json.loads(checkpoint.read_bytes())
        data["setup_cost_usd"] = "999"
        checkpoint.write_text(json.dumps(data))
        restored = []
        self.fixture.backend.restore_closed = lambda reg, root: restored.append(root)
        with patch.object(self.fixture.backend, "invoke", side_effect=AssertionError("actor invoked")):
            with self.assertRaises(ValueError):
                subject.resume_grading(self.fixture.reg, self.fixture.backend)
        self.assertEqual(restored, [])
        self.assertEqual(self.fixture.backend.grades, [])
