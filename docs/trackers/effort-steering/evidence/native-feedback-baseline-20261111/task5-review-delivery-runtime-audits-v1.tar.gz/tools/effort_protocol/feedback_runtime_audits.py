"""Mandatory paid-admission readback of all closed repair-only integrity audits."""
import json
from pathlib import Path

from feedback_assertion_audit import CAPTURE_KEYS, verify_audit
from feedback_runner import verify_audit_index
from paid_admission import _bound_json, _bound_path, _require
from trusted_test_inputs import _validated


def verify_runtime_audits(registration, root, closed, result):
    """Recompute every audit from bound original inputs; a declared count is insufficient."""
    root = Path(root)
    index_pointer = result.get("integrity_audit", {}).get("index")
    _require(isinstance(index_pointer, dict), "runtime integrity audit index missing")
    _bound_json(registration, index_pointer)
    rows = result["attempts"]
    audits = verify_audit_index(root, closed, rows, result)
    _require(len(rows) == 16 and len(audits) == 16, "runtime integrity audit population is incomplete")
    opaque_ids = set()
    for index, row in enumerate(rows):
        grade = root / "grades" / str(index).zfill(2)
        _require((grade / "integrity-audit.json").is_file(), "runtime persisted integrity proof missing")
        proof = _bound_json(registration, {"path": str(grade / "integrity-audit.json"),
                                         "sha256": registration["bindings"].get(str(grade / "integrity-audit.json"))})
        _require(proof == row.get("integrity_audit") == audits[index],
                 "runtime persisted integrity proof differs")
        descriptor_pointer = proof.get("descriptor")
        _require(isinstance(descriptor_pointer, dict), "runtime audit descriptor missing")
        descriptor_path = Path(descriptor_pointer["path"])
        _require(descriptor_path.is_relative_to(root / "audits"), "runtime audit descriptor outside audit root")
        descriptor = _bound_json(registration, descriptor_pointer)
        for role in ("bundle", "manifest"):
            _bound_path(registration, {"path": descriptor[role], "sha256": descriptor[role + "_sha256"]})
        packet_path = grade / "private-request.json"
        packet = _bound_json(registration, {"path": str(packet_path),
                                           "sha256": registration["bindings"].get(str(packet_path))})
        task = registration["tasks"][row["task_id"]]
        _require(packet.get("public_baseline") == task["source"]
                 and packet.get("public_baseline_sha256") == task["source_sha256"]
                 and packet.get("source") == row["candidate"] and packet.get("source_digest") == row["source_digest"],
                 "runtime audit original baseline or candidate differs")
        _require(CAPTURE_KEYS <= set(packet), "runtime audit capture packet is incomplete")
        for role in ("patch", "capture_proof"):
            _bound_path(registration, {"path": packet[role], "sha256": packet[role + "_sha256"]})
        private = task["backend"]["private"]
        config = _bound_json(registration, {"path": private["config"], "sha256": private["config_sha256"]})
        roots, _, _ = _validated(config["trusted_test_inputs"])
        decision, outer = None, {}
        if "decision" in proof:
            _require(Path(proof["decision"]["path"]) == descriptor_path.parent / "review-decision.json",
                     "runtime decision is outside its audit directory")
            decision = _bound_json(registration, proof["decision"])
            dispatch = _bound_json(registration, decision["dispatch"])
            _bound_path(registration, dispatch["brief"])
            _bound_path(registration, decision["response"])
            outer = {"decision": proof["decision"]}
        expected = verify_audit(descriptor, {key: packet[key] for key in CAPTURE_KEYS}, decision,
                                issue=task["public_packet"]["issue"], protected_roots=roots)
        _require(proof == {**expected, "descriptor": descriptor_pointer, **outer}
                 and expected["terminal"] is True and expected["status"] in ("clear", "confirmed-bypass"),
                 "runtime audit has no exact terminal independent proof")
        _require(expected["opaque_id"] not in opaque_ids, "runtime duplicated opaque audit identity")
        opaque_ids.add(expected["opaque_id"])
    return len(opaque_ids)
