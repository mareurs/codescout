"""Concrete host campaign backend. Private evaluation runs only in a child process."""
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import feedback_policy
from execution_profiles import validate_profile_build_inputs

from campaign_native import invoke_native
from campaign_resources import measure_host
from preparation import _runtime, _runtime_inputs
from public_clone import _git, verify_source_baseline
from receipts import input_digest, publish_exclusive

_PUBLIC = frozenset(("image", "template", "template_sha256", "knowledge_paths",
    "knowledge_sha256", "runtime_manifest", "runtime", "global_rules",
    "global_rules_sha256", "embedding", "registered_readiness", "execution_profile",
    "cli_checks", "timeout_s", "check_timeout_s", "command_timeout_s", "max_log_bytes",
    "allowed_probe_prefixes", "public_checks", "lsp_warmup_retries", "resource_root",
    "resource_floors", "public_fixture", "capture_base_commit", "source_baseline", "public_build_inputs"))


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _identity(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",",":")).encode()).hexdigest()


def _verify_public(public):
    verify_source_baseline(public)
    template = Path(public["template"]).resolve(strict=True)
    if (input_digest(template) != public["template_sha256"] or
            input_digest(template/".codescout",public["knowledge_paths"]) != public["knowledge_sha256"] or
            _runtime(_runtime_inputs(public["runtime"])) != public["runtime"] or
            _sha(public["global_rules"]) != public["global_rules_sha256"]):
        raise ValueError("frozen public preparation changed")
    base = public.get("capture_base_commit")
    if (not isinstance(base,str) or not re.fullmatch("[0-9a-f]{40}",base) or
            _git(template,"rev-parse","HEAD").stdout.strip() != base):
        raise ValueError("task capture baseline differs from frozen public template")
    if not re.fullmatch("sha256:[0-9a-f]{64}",public["image"]):
        raise ValueError("native image identity is not immutable")
    validate_profile_build_inputs(public.get("execution_profile", "fixture-v1"), public.get("public_build_inputs"),
                                  template, public["image"])
    host = measure_host(public["resource_root"], os.environ.get("TMPDIR","/tmp"))
    floors = public["resource_floors"]
    if (set(floors) != {"root_free","tmp_free","mem_available"} or
            any(type(v) is not int or v <= 0 for v in floors.values()) or
            any(type(host.get(k)) is not int or host[k] < v for k,v in floors.items()) or
            host.get("tmp_exec") is not True):
        raise ValueError("current host resource admission failed")
    return {"ready":True,"host":host,"capture_base_commit":base}


def _verify_private(private, bindings):
    if set(private) != {"entry","entry_sha256","config","config_sha256"}:
        raise ValueError("private evaluator descriptor invalid")
    entry = Path(private["entry"]).resolve(strict=True)
    if entry != Path(__file__).with_name("evaluator_entry.py").resolve():
        raise ValueError("unregistered private evaluator executable")
    for name in ("entry","config"):
        path = Path(private[name])
        expected = private[name+"_sha256"]
        if path.is_symlink() or _sha(path) != expected or bindings.get(str(path)) != expected:
            raise ValueError("private evaluator entry/config binding changed")
    return {"ready":True,"entry_sha256":private["entry_sha256"]}


class NativeCampaignBackend:
    def __init__(self, *, mode, token_path=None):
        if mode not in ("scripted","paid") or (mode == "scripted" and token_path is not None):
            raise ValueError("invalid native campaign mode/credentials")
        self.mode, self.token_path = mode, token_path
        self.registration = None
        self.registration_sha256 = None
        self.invocations = {}
        self.audit_inputs = {}

    def verify(self, registration):
        if self.mode != registration.get("mode"):
            raise ValueError("native campaign mode changed")
        repair_only = registration.get("schema") == feedback_policy.SCHEMA
        if repair_only:
            from feedback_admission import validate_registration
            validate_registration(registration)
        authorization = None
        if self.mode == "paid":
            if repair_only:
                from feedback_admission import FeedbackAdmission
                authorization = FeedbackAdmission(registration, self.token_path)
            else:
                from paid_admission import PaidAdmission
                authorization = PaidAdmission(registration, self.token_path)
        identity = _identity(registration)
        if self.registration_sha256 not in (None, identity):
            raise ValueError("native campaign registration changed after verification")
        descriptors = []
        allowed_public = _PUBLIC | ({"feedback_policy"} if repair_only else set())
        for task in registration["tasks"].values():
            descriptor = task["backend"]
            if (set(descriptor) != {"public", "private", "scripted_plans"} or
                    not isinstance(descriptor["public"], dict) or
                    set(descriptor["public"]) - allowed_public or
                    not isinstance(descriptor["scripted_plans"], dict)):
                raise ValueError("unregistered public/private backend descriptor")
            baseline = descriptor["public"].get("source_baseline")
            if baseline is not None and baseline != {"path": task["source"], "sha256": task["source_sha256"]}:
                raise ValueError("source baseline differs from the registered initial task")
            if self.mode == "paid" and descriptor["scripted_plans"]:
                raise ValueError("paid campaign cannot carry scripted provider plans")
            if repair_only and self.mode == "scripted":
                plans = descriptor["scripted_plans"]
                if set(plans) != {arm + ":repair" for arm in "LRPX"} or not all(isinstance(p, list) for p in plans.values()):
                    raise ValueError("repair-only qualification requires exactly four ordinary repair plans")
            descriptors.append(descriptor)
        proofs = []
        for descriptor in descriptors:
            proofs.append({"public": _verify_public(descriptor["public"]),
                           "private": _verify_private(descriptor["private"], registration["bindings"])})
        self.authorization = authorization
        self.registration = copy.deepcopy(registration)
        self.registration_sha256 = identity
        return {"ready": True, "mode": self.mode, "tasks": proofs, "paid_ready": self.mode == "paid"}

    def invoke(self, request, out):
        if getattr(self, "closed_only", False):
            raise ValueError("closed native backend cannot start another actor")
        if self.registration is None:
            raise ValueError("native campaign has not been verified")
        if _identity(self.registration) != self.registration_sha256:
            raise ValueError("native campaign registration changed after verification")
        repair_only = self.registration.get("schema") == feedback_policy.SCHEMA
        if repair_only:
            root=Path(self.registration["output_root"])
            if any((root/name).exists() or (root/name).is_symlink()
                   for name in ("ledger-final.json","actor-batch-closed.json","result.json")):
                raise ValueError("terminal campaign cannot start another actor")
        index = request["attempt_index"]
        schedule = self.registration["schedule"]
        if type(index) is not int or not 0 <= index < len(schedule):
            raise ValueError("attempt index invalid")
        attempt = schedule[index]
        task_id, arm, phase = request["task_id"], request["arm"], request["phase"]
        phases = ("repair",) if repair_only else (("investigate", "repair", "challenge") if arm in ("P", "R") else ("repair",))
        identity = self.registration["campaign_id"] + "::" + str(index) + "::" + phase
        expected = Path(self.registration["output_root"]) / "attempts" / (str(index).zfill(2) + "-" + arm) / phase
        if (attempt["task_id"] != task_id or attempt["arm"] != arm or phase not in phases
                or request["invocation_id"] != identity or identity in self.invocations
                or Path(out).resolve() != expected.resolve()):
            raise ValueError("unregistered native invocation identity or output")
        descriptor = self.registration["tasks"][task_id]["backend"]
        if repair_only:
            from feedback_admission import validate_invocation
            validate_invocation(self.registration, request, out, descriptor["public"])
        _verify_public(descriptor["public"])
        if self.mode == "scripted":
            plan = descriptor["scripted_plans"].get(arm + ":" + phase)
            if not isinstance(plan, list):
                raise ValueError("scripted phase plan is absent")
            kwargs = {"scripted_plan": copy.deepcopy(plan)}
        else:
            authorization = getattr(self, "authorization", None)
            if authorization is None or descriptor["scripted_plans"]:
                raise ValueError("verified paid authorization is unavailable")
            kwargs = {"admission": authorization, "token_path": self.token_path}
        self.invocations[identity] = {"out": str(out), "task_id": task_id, "arm": arm}
        return invoke_native(request, out, copy.deepcopy(descriptor["public"]), mode=self.mode, **kwargs)


    def restore_closed(self, registration, root):
        """Recover only immutable capture identities; never recreate actor authority."""
        from feedback_admission import validate_registration
        from feedback_runner import verify_closed
        from feedback_assertion_audit import CAPTURE_KEYS
        validate_registration(registration)
        root = Path(root)
        if (registration.get("schema") != feedback_policy.SCHEMA or self.mode != registration["mode"]
                or root != Path(registration["output_root"]) or not root.is_dir()
                or root.is_symlink() or root.resolve() != root):
            raise ValueError("closed native restore policy or root differs")
        if self.registration is not None and _identity(self.registration) != _identity(registration):
            raise ValueError("closed native restore changed registration")
        for name in ("registration.json", "actor-batch-closed.json", "integrity-audits.json"):
            path = root / name
            if not path.is_file() or path.is_symlink() or path.resolve() != path:
                raise ValueError("closed native restore artifact is not physical")
        if json.loads((root / "registration.json").read_bytes()) != registration:
            raise ValueError("closed native restore lost original registration")
        closed = json.loads((root / "actor-batch-closed.json").read_bytes())
        rows = verify_closed(registration, root, closed)
        invocations = {}
        for row in rows:
            identity = registration["campaign_id"] + "::" + str(row["attempt_index"]) + "::repair"
            directory = root / "attempts" / (str(row["attempt_index"]).zfill(2) + "-" + row["arm"]) / "repair"
            path = directory / "invocation.json"
            decision = row["invocations"][0]
            if (not path.is_file() or path.is_symlink() or path.resolve() != path
                    or _sha(path) != decision["receipt_sha256"]
                    or json.loads(path.read_bytes()) != decision["record"]
                    or decision["record"].get("invocation_id") != identity):
                raise ValueError("closed native invocation receipt changed")
            invocations[identity] = {"out":str(directory), "task_id":row["task_id"], "arm":row["arm"]}
        self.registration = copy.deepcopy(registration)
        self.registration_sha256 = _identity(registration)
        self.invocations, self.audit_inputs = invocations, {}
        self.authorization, self.closed_only = None, True
        index = json.loads((root / "integrity-audits.json").read_bytes())
        if index.get("closure_sha256") != _sha(root / "actor-batch-closed.json"):
            raise ValueError("closed native audit index closure changed")
        eligible = {row["attempt_index"]: row for row in rows if row["candidate"] is not None
                    and row["invocations"][0]["record"].get("capture_complete") is True}
        if [item.get("attempt_index") for item in index.get("audits", [])] != list(eligible):
            raise ValueError("closed native audit population differs")
        for item in index["audits"]:
            binding = item["audit"].get("descriptor")
            if binding is None:
                if self.mode == "paid":
                    raise ValueError("closed native audit descriptor is missing")
                continue
            row = eligible[item["attempt_index"]]
            if item["candidate"] != row["candidate"] or item["source_digest"] != row["source_digest"]:
                raise ValueError("closed native audit candidate changed")
            path = Path(binding["path"])
            if (not path.is_relative_to(root / "audits") or not path.is_file() or path.is_symlink()
                    or path.resolve() != path or _sha(path) != binding["sha256"]):
                raise ValueError("closed native audit descriptor changed")
            packet = self._candidate_packet({key:row[key] for key in ("task_id","arm","source_digest")}
                                            | {"source":row["candidate"]})
            capture = {key:packet[key] for key in CAPTURE_KEYS}
            descriptor = json.loads(path.read_bytes())
            if descriptor.get("capture") != capture:
                raise ValueError("closed native audit capture differs")
            identity = _identity(capture)
            if identity in self.audit_inputs:
                raise ValueError("closed native audit capture repeats")
            self.audit_inputs[identity] = dict(binding)
            self._integrity_audit(packet)
        self._closed()

    def _closed(self):
        if self.registration is None:
            raise ValueError("campaign not verified")
        root = Path(self.registration["output_root"])
        path = root/"actor-batch-closed.json"
        if path.is_symlink() or not path.is_file():
            raise ValueError("private grading requires full actor batch closure")
        closed = json.loads(path.read_bytes())
        if self.registration.get("schema")==feedback_policy.SCHEMA:
            if _identity(self.registration)!=self.registration_sha256:
                raise ValueError("native campaign registration changed after verification")
            from feedback_runner import verify_closed
            verify_closed(self.registration,root,closed)
            return closed
        if (len(closed["attempts"]) != 8 or
                _sha(root/"ledger-final.json") != closed["ledger_sha256"]):
            raise ValueError("actor batch or ledger closure changed")
        for row in closed["attempts"]:
            if (_sha(row["attempt_receipt"]) != row["receipt_sha256"] or
                    input_digest(row["candidate"]) != row["source_digest"]):
                raise ValueError("closed actor result changed")
        return closed


    def _candidate_packet(self, request):
        self._closed()
        source = Path(request["source"]).resolve(strict=True)
        matches = []
        for invocation in self.invocations.values():
            receipt = json.loads((Path(invocation["out"])/"invocation.json").read_bytes())
            if (Path(receipt["candidate"]).resolve() == source and invocation["task_id"] == request["task_id"]
                    and invocation["arm"] == request["arm"]):
                matches.append((invocation,receipt))
        if len(matches) != 1 or input_digest(source) != request["source_digest"]:
            raise ValueError("grade source has no unique bound native capture")
        invocation,receipt = matches[0]
        native = Path(invocation["out"])/"native"
        proof_path, patch_path = native/"candidate-capture.json",native/"candidate.patch"
        proof = json.loads(proof_path.read_bytes())
        public = self.registration["tasks"][request["task_id"]]["backend"]["public"]
        if (proof.get("complete") is not True or proof.get("baseline_commit") != public["capture_base_commit"] or
                proof.get("sha256") != _sha(patch_path) or
                type(proof.get("bytes")) is not int or proof["bytes"] != patch_path.stat().st_size or
                receipt["source_digest"] != request["source_digest"]):
            raise ValueError("complete cumulative candidate patch binding failed")
        descriptor = self.registration["tasks"][request["task_id"]]["backend"]["private"]
        _verify_private(descriptor,self.registration["bindings"])
        return {**copy.deepcopy(request), "patch":str(patch_path),"patch_sha256":_sha(patch_path),
            "capture_proof":str(proof_path),"capture_proof_sha256":_sha(proof_path),
            "public_baseline":self.registration["tasks"][request["task_id"]]["source"],
            "public_baseline_sha256":self.registration["tasks"][request["task_id"]]["source_sha256"],
            "config":descriptor["config"],"config_sha256":descriptor["config_sha256"]}

    def _audit_context(self, packet):
        from trusted_test_inputs import _validated
        config = json.loads(Path(packet["config"]).read_bytes())
        roots, _, _ = _validated(config["trusted_test_inputs"])
        issue = self.registration["tasks"][packet["task_id"]]["public_packet"]["issue"]
        return issue, roots

    def _integrity_audit(self, packet):
        from feedback_assertion_audit import CAPTURE_KEYS, verify_audit
        capture = {key: packet[key] for key in CAPTURE_KEYS}
        identity = _identity(capture)
        binding = self.audit_inputs.get(identity)
        if not isinstance(binding, dict):
            raise ValueError("integrity audit is missing for captured candidate")
        path = Path(binding["path"])
        if path.is_symlink() or not path.is_file() or _sha(path) != binding["sha256"]:
            raise ValueError("integrity audit descriptor changed")
        descriptor = json.loads(path.read_bytes())
        issue, roots = self._audit_context(packet)
        proof = verify_audit(descriptor, capture, None, issue=issue, protected_roots=roots)
        return {**proof, "descriptor": dict(binding)}

    def audit(self, request, out):
        from feedback_assertion_audit import CAPTURE_KEYS, prepare_audit
        if self.registration is None or self.registration.get("schema") != feedback_policy.SCHEMA:
            raise ValueError("integrity audit dispatch requires repair-only campaign")
        packet = self._candidate_packet(request)
        capture = {key: packet[key] for key in CAPTURE_KEYS}
        identity = _identity(capture)
        if identity not in self.audit_inputs:
            issue, roots = self._audit_context(packet)
            descriptor = prepare_audit(capture, issue, roots, Path(out))
            path = Path(out)/"descriptor.json"
            publish_exclusive(path, descriptor)
            self.audit_inputs[identity] = {"path": str(path), "sha256": _sha(path)}
        return self._integrity_audit(packet)

    def grade(self, request, out):
        packet = self._candidate_packet(request)
        descriptor = self.registration["tasks"][request["task_id"]]["backend"]["private"]
        out = Path(out)
        if self.registration.get("schema") == feedback_policy.SCHEMA:
            audit = self._integrity_audit(packet)
            if audit.get("terminal") is not True or audit.get("status") != "clear":
                raise ValueError("integrity audit unresolved; private grading is withheld")
            publish_exclusive(out/"integrity-audit.json", audit)
        publish_exclusive(out/"private-request.json",packet)
        env = {key:value for key,value in os.environ.items() if key in ("PATH","HOME","USER","LANG","TMPDIR")}
        with (out/"private-process.stdout").open("xb") as stdout, (out/"private-process.stderr").open("xb") as stderr:
            process = subprocess.run([sys.executable,"-I","-B",descriptor["entry"],
                str(out/"private-request.json"),str(out)],stdout=stdout,stderr=stderr,env=env,timeout=7200)
        path = out/"verdict.json"
        if process.returncode != 0 or not path.is_file() or path.is_symlink():
            verdict = {"valid":False,"pass":None,"reason":"private evaluator process failed",
                       "returncode":process.returncode}
            if not path.exists():
                publish_exclusive(path,verdict)
            return verdict
        self._closed()
        return json.loads(path.read_bytes())
