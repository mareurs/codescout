"""Filesystem controls for generated build evidence; no Docker/model claim."""
import hashlib
import importlib
import json
import os
from pathlib import Path
import stat
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).parent))
import receipts
try:
    build_inputs = importlib.import_module("public_build_inputs")
except ModuleNotFoundError as exc:
    if exc.name != "public_build_inputs":
        raise
    build_inputs = None


class GeneratedInventoryTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(build_inputs, "generated build inventory is not implemented")
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.base = Path(temporary.name)
        self.root = self.base / "generated"
        self.root.mkdir()

    def test_literal_file_and_empty_directory_inventory(self):
        (self.root / "empty").mkdir(mode=0o750)
        (self.root / "a.txt").write_bytes(b"abc")
        (self.root / "a.txt").chmod(0o640)
        expected = {"a.txt": {"kind": "file", "mode": 0o640,
                    "sha256": "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"},
                    "empty": {"kind": "directory", "mode": 0o750}}
        self.assertEqual(build_inputs.generated_inventory(self.root), expected)
        literal = json.dumps(expected, sort_keys=True, separators=(",", ":")).encode()
        self.assertEqual(build_inputs.generated_digest(self.root), hashlib.sha256(literal).hexdigest())
        self.assertEqual(build_inputs.generated_digest(self.root), receipts.input_digest(self.root))

    def test_external_file_and_directory_links_are_leaves(self):
        outside = self.base / "outside"
        outside.mkdir()
        (outside / "secret").write_bytes(b"unread external")
        (self.root / "project").symlink_to(outside, target_is_directory=True)
        (self.root / "file").symlink_to(outside / "secret")
        inventory = build_inputs.generated_inventory(self.root)
        self.assertEqual(set(inventory), {"project", "file"})
        self.assertEqual(inventory["project"]["target"], str(outside))
        self.assertEqual(inventory["project"]["mode"], stat.S_IMODE((self.root / "project").lstat().st_mode))
        original = build_inputs.generated_digest(self.root)
        (outside / "secret").write_bytes(b"different external bytes")
        (outside / "another").mkdir()
        self.assertEqual(build_inputs.generated_digest(self.root), original)
        with self.assertRaisesRegex(receipts.ReceiptViolation, "escapes"):
            receipts.input_digest(self.root)

    def test_dangling_and_cyclic_links_remain_inventory_entries(self):
        (self.root / "missing").symlink_to("/testbed/frontend")
        (self.root / "cycle").symlink_to("cycle")
        inventory = build_inputs.generated_inventory(self.root)
        self.assertEqual(set(inventory), {"missing", "cycle"})
        self.assertEqual(inventory["missing"]["target"], "/testbed/frontend")
        self.assertEqual(inventory["cycle"]["target"], "cycle")
        self.assertEqual(inventory["cycle"]["kind"], "link")

    def test_link_target_string_changes_digest(self):
        link = self.root / "project"
        link.symlink_to("/testbed/a")
        before = build_inputs.generated_digest(self.root)
        link.unlink()
        link.symlink_to("/testbed/b")
        self.assertNotEqual(build_inputs.generated_digest(self.root), before)

    def test_file_bytes_modes_and_empty_directories_are_bound(self):
        file = self.root / "data"
        file.write_bytes(b"first")
        seen = {build_inputs.generated_digest(self.root)}
        file.write_bytes(b"other")
        seen.add(build_inputs.generated_digest(self.root))
        file.chmod(0o400)
        seen.add(build_inputs.generated_digest(self.root))
        empty = self.root / "empty"
        empty.mkdir(mode=0o750)
        seen.add(build_inputs.generated_digest(self.root))
        empty.chmod(0o700)
        seen.add(build_inputs.generated_digest(self.root))
        empty.rename(self.root / "renamed")
        seen.add(build_inputs.generated_digest(self.root))
        self.assertEqual(len(seen), 6)

    def test_fifo_is_rejected_without_opening_it(self):
        os.mkfifo(self.root / "pipe")
        with self.assertRaisesRegex(ValueError, "unsupported"):
            build_inputs.generated_inventory(self.root)

    def test_root_link_and_link_ancestor_are_rejected(self):
        link = self.base / "alias"
        link.symlink_to(self.root, target_is_directory=True)
        nested = self.root / "nested"
        nested.mkdir()
        for root in (link, link / "nested"):
            with self.subTest(root=str(root)), self.assertRaises(ValueError):
                build_inputs.generated_inventory(root)

    def test_missing_or_file_root_is_rejected(self):
        file = self.base / "file"
        file.write_bytes(b"x")
        for root in (file, self.base / "missing"):
            with self.subTest(root=str(root)), self.assertRaises(ValueError):
                build_inputs.generated_inventory(root)

    def test_unicode_names_and_nested_link_free_overlap(self):
        (self.root / "λ").mkdir(mode=0o750)
        (self.root / "λ" / "é.txt").write_bytes(b"payload\x00")
        (self.root / "λ" / "é.txt").chmod(0o640)
        self.assertEqual(set(build_inputs.generated_inventory(self.root)), {"λ", "λ/é.txt"})
        self.assertEqual(build_inputs.generated_digest(self.root), receipts.input_digest(self.root))

    def test_empty_tree_has_literal_empty_inventory_digest(self):
        self.assertEqual(build_inputs.generated_inventory(self.root), {})
        self.assertEqual(build_inputs.generated_digest(self.root),
                         "44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a")


class BuildInputContractTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.base = Path(temporary.name)
        self.source = self.base / "source"
        self.source.mkdir()
        (self.source / "frontend").mkdir()
        (self.source / "frontend/node_modules").mkdir()
        (self.source / "main.rs").write_bytes(b"original")
        self.seed = self.base / "seed"
        (self.seed / "store").mkdir(parents=True)
        (self.seed / "store/payload").write_bytes(b"locked dependency")
        self.image = "sha256:" + "a" * 64
        self.raw = {"schema": "public-build-inputs-v1", "image": self.image,
                    "seed": {"path": str(self.seed), "sha256": build_inputs.generated_digest(self.seed)},
                    "dependency_dirs": ["frontend/node_modules"],
                    "cache_mounts": [{"seed_relative": "store", "destination": "/bench/public-dependencies/store"}]}

    def test_descriptor_fingerprint_binds_literal_contract(self):
        result = build_inputs.validate_descriptor(self.raw, self.source, self.image)
        literal = json.dumps(self.raw, sort_keys=True, separators=(",", ":")).encode()
        self.assertEqual(result["fingerprint"], hashlib.sha256(literal).hexdigest())

    def test_invalid_contract_fields_and_image_fail_closed(self):
        variants = [{**self.raw, "extra": True}, {**self.raw, "schema": True},
                    {**self.raw, "image": "latest"}, {**self.raw, "image": "sha256:" + "b" * 64},
                    {**self.raw, "dependency_dirs": "frontend/node_modules"},
                    {**self.raw, "cache_mounts": True}, {**self.raw, "seed": {"path": str(self.seed)}}]
        for raw in variants:
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                build_inputs.validate_descriptor(raw, self.source, self.image)

    def test_dependency_traversal_duplicates_and_overlaps_rejected(self):
        for dirs in (["../escape"], ["/tmp"], ["frontend/./node_modules"],
                     ["frontend/node_modules", "frontend/node_modules"],
                     ["frontend", "frontend/node_modules"], ["frontend/node_modules,ro"]):
            with self.subTest(dirs=dirs), self.assertRaises(ValueError):
                build_inputs.validate_descriptor({**self.raw, "dependency_dirs": dirs}, self.source, self.image)

    def test_nonempty_or_symlink_dependency_targets_rejected(self):
        target = self.source / "frontend/node_modules"
        (target / "unexpected").write_text("source content")
        with self.assertRaises(ValueError):
            build_inputs.validate_descriptor(self.raw, self.source, self.image)
        (target / "unexpected").unlink()
        target.rmdir()
        target.symlink_to(self.seed, target_is_directory=True)
        with self.assertRaises(ValueError):
            build_inputs.validate_descriptor(self.raw, self.source, self.image)

    def test_seed_must_be_physical_unchanged_and_disjoint_from_source(self):
        (self.seed / "store/payload").write_bytes(b"mutated dependency")
        with self.assertRaises(ValueError):
            build_inputs.validate_descriptor(self.raw, self.source, self.image)
        local_seed = {"path": str(self.source), "sha256": build_inputs.generated_digest(self.source)}
        with self.assertRaises(ValueError):
            build_inputs.validate_descriptor({**self.raw, "seed": local_seed}, self.source, self.image)

    def test_cache_paths_cannot_escape_shadow_or_overlap(self):
        for mount in ({"seed_relative": "../outside", "destination": "/bench/public-dependencies/store"},
                      {"seed_relative": "/tmp", "destination": "/bench/public-dependencies/store"},
                      {"seed_relative": "store", "destination": "/testbed/frontend"},
                      {"seed_relative": "store", "destination": "/build/cache"},
                      {"seed_relative": "store", "destination": "/bench/public-dependencies"},
                      {"seed_relative": "store", "destination": "/bench/public-dependencies/../runtime"}):
            with self.subTest(mount=mount), self.assertRaises(ValueError):
                build_inputs.validate_descriptor({**self.raw, "cache_mounts": [mount]}, self.source, self.image)
        first = self.raw["cache_mounts"][0]
        for mounts in ([first, first], [first, {**first, "destination": first["destination"] + "/child"}]):
            with self.subTest(mounts=mounts), self.assertRaises(ValueError):
                build_inputs.validate_descriptor({**self.raw, "cache_mounts": mounts}, self.source, self.image)

    def test_two_stages_are_independent_and_preserve_source_seed(self):
        source_before = receipts.input_digest(self.source)
        seed_before = build_inputs.generated_digest(self.seed)
        first = build_inputs.stage_inputs(self.raw, self.source, self.image, self.base / "one")
        second = build_inputs.stage_inputs(self.raw, self.source, self.image, self.base / "two")
        self.assertEqual(first["fingerprint"], second["fingerprint"])
        self.assertNotEqual(first["mounts"][0]["source"], second["mounts"][0]["source"])
        cache = next(Path(row["source"]) for row in first["mounts"] if row["role"] == "cache")
        other = next(Path(row["source"]) for row in second["mounts"] if row["role"] == "cache")
        self.assertEqual((cache / "payload").read_bytes(), b"locked dependency")
        (cache / "payload").write_bytes(b"first attempt mutation")
        self.assertEqual((other / "payload").read_bytes(), b"locked dependency")
        self.assertEqual((self.seed / "store/payload").read_bytes(), b"locked dependency")
        self.assertEqual(build_inputs.generated_digest(self.seed), seed_before)
        self.assertEqual(receipts.input_digest(self.source), source_before)
        after = build_inputs.verify_staged(first, self.source, self.image)
        self.assertNotEqual(after["generated_sha256"], first["initial_generated_sha256"])

    def test_copy_preserves_opaque_symlinks(self):
        (self.seed / "store/project").symlink_to("/testbed/frontend")
        self.raw["seed"]["sha256"] = build_inputs.generated_digest(self.seed)
        stage = build_inputs.stage_inputs(self.raw, self.source, self.image, self.base / "one")
        cache = next(Path(row["source"]) for row in stage["mounts"] if row["role"] == "cache")
        self.assertTrue((cache / "project").is_symlink())
        self.assertEqual(os.readlink(cache / "project"), "/testbed/frontend")
        self.assertEqual(build_inputs.verify_staged(stage, self.source, self.image)["fingerprint"], stage["fingerprint"])

    def test_staged_contract_rejects_tampered_mount_and_changed_seed(self):
        stage = build_inputs.stage_inputs(self.raw, self.source, self.image, self.base / "one")
        changed = json.loads(json.dumps(stage))
        changed["mounts"][0]["source"] = str(self.seed)
        with self.assertRaises(ValueError):
            build_inputs.verify_staged(changed, self.source, self.image)
        (self.seed / "store/payload").write_bytes(b"seed changed after staging")
        with self.assertRaises(ValueError):
            build_inputs.verify_staged(stage, self.source, self.image)

    def test_staging_cannot_reuse_or_overlap_source_seed(self):
        for output in (self.source / "generated", self.seed / "generated", self.base):
            with self.subTest(output=str(output)), self.assertRaises(ValueError):
                build_inputs.stage_inputs(self.raw, self.source, self.image, output)
        build_inputs.stage_inputs(self.raw, self.source, self.image, self.base / "one")
        with self.assertRaises(ValueError):
            build_inputs.stage_inputs(self.raw, self.source, self.image, self.base / "one")

    def test_explicit_empty_descriptor_is_image_bound(self):
        raw = {"schema": "public-build-inputs-v1", "image": self.image, "seed": None,
               "dependency_dirs": [], "cache_mounts": []}
        stage = build_inputs.stage_inputs(raw, self.source, self.image, self.base / "empty")
        self.assertEqual(stage["mounts"], [])
        self.assertEqual(build_inputs.verify_staged(stage, self.source, self.image)["fingerprint"], stage["fingerprint"])
        with self.assertRaises(ValueError):
            build_inputs.validate_descriptor(raw, self.source, "sha256:" + "b" * 64)


if __name__ == "__main__":
    unittest.main()
