"""Consumer checks for the native CLI phase boundary, with real file capture."""
import importlib
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import public_fixture

sys.path.insert(0, str(Path(__file__).parent))
try:
    native = importlib.import_module("native_executor")
except ModuleNotFoundError as exc:
    if exc.name != "native_executor":
        raise
    native = None


class NativeExecutorTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(native, "native CLI executor is not implemented")
        self.temp = tempfile.TemporaryDirectory(prefix="ep-native-unit-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.actor = self.root / "actor"
        self.actor.mkdir()
        (self.actor / "program.txt").write_text("original\n")
        (self.actor / ".codescout").mkdir()
        (self.actor / ".codescout/system-prompt.md").write_text("Shared source-only guidance.\n")
        self.prepared = self.root / "prepared"
        self.prepared.mkdir()
        cfg = {"actor": str(self.actor), "prompt": "unused public task", "max_continuations": 2}
        (self.prepared / "prepared.json").write_text(json.dumps(cfg))
        self.packet = {"run_id": "r", "phase": "repair", "prompt": "Repair from public evidence.",
                       "public_packet": {"issue": "Public request"}, "allowance_usd": "0.50",
                       "max_continuations": 2}
        self.receipt = {"context_valid": True, "cost_usd": "0.07", "unknown_provider_cost": False,
            "cleanup_error": None, "supervision_error": None,
            "background_evidence": {"complete": True}, "artifact_evidence": {"complete": True},
            "lifecycle": {"continuations": 1}, "forwarded": 0, "transport_errors": []}
        self.executor = native.NativeExecutor(self.prepared, self.root / "captured",
            system_lines=["Shared source-only guidance."], recon_marker="RECON_LOADED", scripted_plan=[])
        request = {"system": [{"type": "text", "text": "CLI system"}], "messages": [
            {"role": "assistant", "content": [
                {"type": "tool_use", "id": "s", "name": "mcp__codescout__read_file",
                 "input": {"path": ".codescout/system-prompt.md"}},
                {"type": "tool_use", "id": "k", "name": "Skill",
                 "input": {"skill": "codescout-companion:reconnaissance"}}]},
            {"role": "user", "content": [
                {"type": "tool_result", "tool_use_id": "s", "content": "Shared source-only guidance."},
                {"type": "tool_result", "tool_use_id": "k", "content": "Launching skill: codescout-companion:reconnaissance"}]},
        {"role": "user", "content": [{"type": "text", "text": "Base directory for this skill: /frozen/plugin/skills/reconnaissance\\n\\nRECON_LOADED"}]}]}
        (self.prepared / "request-0.json").write_text(json.dumps(request))
        self.image = "sha256:" + "a" * 64
        binary_dir = self.root / "runtime-bin"
        binary_dir.mkdir()
        (binary_dir / "codescout").write_bytes(b"frozen native executable")
        (self.actor / ".codescout/project.toml").write_text('[project]\nlanguages=["text"]\n')
        cfg = json.loads((self.prepared / "prepared.json").read_text())
        cfg.update(image=self.image, knowledge_paths=["project.toml", "system-prompt.md"])
        (self.prepared / "prepared.json").write_text(json.dumps(cfg))
        (self.prepared / "mcp-native-argv.json").write_text(json.dumps(
            ["docker", "run", "--entrypoint", "/bench/bin/codescout", "--mount",
             "type=bind,src=" + str(binary_dir) + ",dst=/bench/bin,readonly",
             self.image, "start", "--project", "/testbed"]))
        baseline = self.root / "public-baseline"
        baseline.mkdir()
        (baseline / "program.txt").write_text("original\n")
        import hashlib
        from receipts import input_digest
        self.binding = {"image": self.image,
            "executable_sha256": hashlib.sha256(b"frozen native executable").hexdigest(),
            "source_snapshot_sha256": input_digest(baseline),
            "knowledge_sha256": input_digest(self.actor / ".codescout",
                ["project.toml", "system-prompt.md"])}
        (self.actor / ".git").mkdir()
        (self.actor / ".git/metadata").write_text("tool role, never source")
        self.executor.bind_readiness(self.binding)
    def test_preloaded_first_system_request_needs_no_tool_calls(self):
        expected={'effort':'low','declaration':False,'clause':'AUTHORITY',
                  'global_visible':['GLOBAL'],'project_visible':['PROJECT'],
                  'preload_visible':['<prepared-context>','Shared source-only guidance.','RECON_LOADED','</prepared-context>']}
        (self.prepared/'expected.json').write_text(json.dumps(expected))
        request={'model':'claude-sonnet-5-5','output_config':{'effort':'low'},
                 'system':[{'type':'text','text':'GLOBAL\nPROJECT\n'+'\n'.join(expected['preload_visible'])}],
                 'messages':[{'role':'user','content':'Repair the public task.'}]}
        path=self.prepared/'request-0.json'; path.write_text(json.dumps(request))
        self.assertEqual(native._context(self.prepared,['Shared source-only guidance.'],'RECON_LOADED'),
                         {'system_delivered':True,'recon_delivered':True})
        for target in ('later','user','tool','onboarding'):
            bad=json.loads(json.dumps(request))
            if target=='later':
                (self.prepared/'request-1.json').write_text(json.dumps(request))
                bad['system']=[]
            elif target in ('user','tool'):
                text=bad['system'][0]['text'];bad['system']=[]
                bad['messages']=[{'role':'user','content':text if target=='user' else
                                 [{'type':'tool_result','tool_use_id':'x','content':text}]}]
            else:
                bad['system'][0]['text']=bad['system'][0]['text'].replace('Shared source-only guidance.','')
            path.write_text(json.dumps(bad))
            with self.subTest(location=target):
                self.assertEqual(native._context(self.prepared,['Shared source-only guidance.'],'RECON_LOADED'),
                                 {'system_delivered':False,'recon_delivered':False})

    def add_fixture(self, root=None):
        descriptor = public_fixture.create_fixture_bundle(
            root or self.root / "public-fixture",
            {"version": "public-http-fixture-v1", "hostname": "fixture.sample.test",
             "port": 18081, "routes": {"/": {
                 "status": 200, "content_type": "text/plain", "body": "public"}}})
        path = self.prepared / "prepared.json"
        cfg = json.loads(path.read_text())
        cfg["public_fixture"] = descriptor
        path.write_text(json.dumps(cfg))
        argv_path = self.prepared / "mcp-native-argv.json"
        argv = json.loads(argv_path.read_text())
        entry = argv.index("--entrypoint")
        del argv[entry:entry + 2]
        argv[-4:-4] = public_fixture.fixture_docker_options(descriptor, "native")
        argv_path.write_text(json.dumps(argv))
        return descriptor

    def test_native_fixture_binding_preserves_binary_and_adds_exact_bundle(self):
        descriptor = self.add_fixture()
        expected = dict(self.binding, public_fixture_sha256=descriptor["fingerprint"])
        self.assertEqual(native._runtime_binding(self.prepared)[0], expected)
        self.assertEqual(self.executor.bind_readiness(expected), expected)
        cfg = json.loads((self.prepared / "prepared.json").read_text())
        for path in Path(descriptor["root"]).iterdir():
            self.assertIn(str(path), cfg["files"])
        binary = self.root / "runtime-bin/codescout"
        binary.write_bytes(b"different native executable")
        with self.assertRaises(ValueError):
            self.executor.bind_readiness(expected)

    def test_native_and_command_fixture_must_have_equal_presence_and_identity_before_launch(self):
        import shutil
        from adapter import run_phase, PhaseInvalid, _admit_backend
        from test_readiness import fixture
        original_cfg = (self.prepared / "prepared.json").read_text()
        original_argv = (self.prepared / "mcp-native-argv.json").read_text()
        declared = self.add_fixture()
        fixture_cfg = (self.prepared / "prepared.json").read_text()
        fixture_argv = (self.prepared / "mcp-native-argv.json").read_text()
        alternate = public_fixture.create_fixture_bundle(
            self.root / "other-fixture",
            {"version": "public-http-fixture-v1", "hostname": "fixture.sample.test",
             "port": 18081, "routes": {"/": {
                 "status": 200, "content_type": "text/plain", "body": "different public body"}}})
        for index, (native_has_fixture, command_fixture) in enumerate(
                ((True, alternate), (True, None), (False, alternate))):
            prepared = self.root / ("prepared-case-" + str(index))
            shutil.copytree(self.prepared, prepared)
            (prepared / "prepared.json").write_text(fixture_cfg if native_has_fixture else original_cfg)
            (prepared / "mcp-native-argv.json").write_text(fixture_argv if native_has_fixture else original_argv)
            backend = native.NativeExecutor(prepared, self.root / ("capture-" + str(index)),
                system_lines=["Shared source-only guidance."], recon_marker="RECON_LOADED", scripted_plan=[])
            expected, wire = fixture()
            binding = dict(self.binding)
            if native_has_fixture:
                binding["public_fixture_sha256"] = declared["fingerprint"]
            expected["binding"] = binding
            wire["binding"] = dict(binding)
            request = {"state": {"run_id": "r", "phase": "investigate",
                                "baseline_paths": ["program.txt"],
                                "baseline_digest": self.binding["source_snapshot_sha256"]},
                "arm": "R", "execution_mode": "native",
                "native_preflight": {"expected": expected, "wire": wire},
                "phase_budget_usd": "0.50", "public_packet": {"issue": "Public request"},
                "out": str(self.root / ("phase-case-" + str(index))),
                "execution_profile": "fixture-public-v1" if command_fixture else "fixture-v1",
                **({"public_fixture": command_fixture} if command_fixture else {})}
            with self.subTest(index=index):
                with patch.object(native.external, "launch", side_effect=RuntimeError("unexpected launch")) as launch:
                    with self.assertRaises(PhaseInvalid):
                        run_phase(request, backend)
                    launch.assert_not_called()
                self.assertFalse(Path(request["out"]).exists())
        # The guard also admits the matched new profile, without launching a client.
        expected, wire = fixture()
        binding = dict(self.binding, public_fixture_sha256=declared["fingerprint"])
        expected["binding"], wire["binding"] = binding, dict(binding)
        admitted = _admit_backend(
            {"execution_mode": "native", "native_preflight": {"expected": expected, "wire": wire},
             "execution_profile": "fixture-public-v1", "public_fixture": declared}, self.executor)
        self.assertEqual(admitted["binding"], binding)

    def empty_omission_proof(self):
        from test_readiness import fixture, reply
        (self.actor / "empty.rs").write_bytes(b"")
        expected, wire = fixture()
        binding = native._runtime_binding(self.prepared)[0]
        expected["binding"], wire["binding"] = binding, dict(binding)
        value = {"verdict": "incomplete", "expected_files": 2, "stored_files": 1,
                 "missing_count": 1, "missing_sample": ["empty.rs"], "orphan_count": 0,
                 "chunks_without_vectors": 0, "memories": {"missing_count": 0, "orphan_count": 0}}
        wire["index_verification"] = reply(json.dumps(value))
        return {"execution_mode": "native", "native_preflight": {"expected": expected, "wire": wire}}

    def test_consuming_native_admission_checks_actual_empty_omission_without_rewriting_verdict(self):
        import copy
        from adapter import _admit_backend
        request = self.empty_omission_proof()
        before = copy.deepcopy(request)
        result = _admit_backend(request, self.executor)
        self.assertEqual(result["index_coverage"]["native_verdict"], "incomplete")
        self.assertEqual(result["index_coverage"]["coverage"], "all_nonempty_eligible_files")
        self.assertEqual(result["index_coverage"]["empty_missing_files"][0]["path"], "empty.rs")
        self.assertEqual(request, before)

    def test_consuming_native_admission_refuses_nonempty_missing_file_on_bound_source(self):
        from adapter import _admit_backend, PhaseInvalid
        request = self.empty_omission_proof()
        (self.actor / "empty.rs").write_text("pub fn omitted() {}")
        binding = native._runtime_binding(self.prepared)[0]
        request["native_preflight"]["expected"]["binding"] = binding
        request["native_preflight"]["wire"]["binding"] = dict(binding)
        with self.assertRaisesRegex(PhaseInvalid, "missing file is not empty regular source"):
            _admit_backend(request, self.executor)

    def test_consuming_native_admission_refuses_changed_source_before_coverage(self):
        from adapter import _admit_backend, PhaseInvalid
        request = self.empty_omission_proof()
        (self.actor / "program.txt").write_text("changed after preparation")
        with self.assertRaisesRegex(PhaseInvalid, "actual public source mismatch"):
            _admit_backend(request, self.executor)

    def test_native_fixture_alias_mount_and_entrypoint_cannot_drift(self):
        descriptor = self.add_fixture()
        path = self.prepared / "mcp-native-argv.json"
        original = path.read_text()
        argv = json.loads(original)
        for before, after in (
                ("fixture.sample.test:127.0.0.1", "example.com:127.0.0.1"),
                ("/bench/public-fixture/launch-native", "/bench/public-fixture/launch-command"),
                (f"type=bind,src={descriptor['root']},dst=/bench/public-fixture,readonly",
                 f"type=bind,src={descriptor['root']},dst=/bench/public-fixture")):
            bad = [after if value == before else value for value in argv]
            path.write_text(json.dumps(bad))
            with self.subTest(before=before), self.assertRaises(ValueError):
                native._runtime_binding(self.prepared)
        path.write_text(original)

    def test_native_fixture_under_actor_source_is_rejected(self):
        self.add_fixture(self.actor / "mutable-fixture")
        with self.assertRaises(ValueError):
            native._runtime_binding(self.prepared)

    def launch(self, *args, **kwargs):
        self.launched = kwargs
        (self.actor / "program.txt").write_text("repaired\n")
        (self.actor / "submission.json").write_text(json.dumps({"status": "submitted", "clauses": [], "commands": []}))
        return self.receipt

    def test_real_capture_excludes_tool_state_and_submission_and_preserves_cost(self):
        with patch.object(native.external, "launch", side_effect=self.launch):
            result = self.executor.execute(self.packet)
        captured = Path(result["source"])
        self.assertEqual((captured / "program.txt").read_text(), "repaired\n")
        self.assertFalse((captured / ".codescout").exists())
        self.assertFalse((captured / ".git").exists())
        self.assertFalse((captured / "submission.json").exists())
        self.assertEqual(result["cost_usd"], "0.07")
        self.assertEqual(result["turns"], 2)
        self.assertTrue(result["context_valid"])
        self.assertEqual(result["submission"]["status"], "submitted")
        cfg = json.loads((self.prepared / "prepared.json").read_text())
        self.assertEqual(cfg["max_continuations"], 2)
        self.assertIn("Public request", cfg["prompt"])
        self.assertIn("Repair from public evidence.", cfg["prompt"])
        self.assertEqual(self.launched["allowance"], "0.50")
        self.assertEqual(self.launched["scripted_plan"], [])

    def test_absent_native_context_is_not_replaced_by_receipt_boolean(self):
        (self.prepared / "request-0.json").unlink()
        with patch.object(native.external, "launch", side_effect=self.launch):
            result = self.executor.execute(self.packet)
        self.assertFalse(result["context_valid"])
        self.assertEqual(result["cost_usd"], "0.07")

    def test_echoing_context_in_an_unrelated_command_does_not_prove_delivery(self):
        p = self.prepared / "request-0.json"
        raw = json.loads(p.read_text())
        for block in raw["messages"][0]["content"]:
            block["name"] = "mcp__codescout__run_command"
            block["input"] = {"command": "echo pretend"}
        p.write_text(json.dumps(raw))
        with patch.object(native.external, "launch", side_effect=self.launch):
            result = self.executor.execute(self.packet)
        self.assertFalse(result["context_valid"])

    def test_real_cli_injects_skill_body_separately_from_its_acknowledgement(self):
        self.executor.recon_marker = "# /codescout-companion:reconnaissance"
        p = self.prepared / "request-0.json"
        raw = json.loads(p.read_text())
        raw["messages"][1]["content"][1]["content"] = "Launching skill: codescout-companion:reconnaissance"
        raw["messages"].append({"role": "user", "content": [{"type": "text", "text":
            "Base directory for this skill: /frozen/plugin/skills/reconnaissance\n\n"
            "# /codescout-companion:reconnaissance\n\nActual loaded skill body."}]})
        p.write_text(json.dumps(raw))
        with patch.object(native.external, "launch", side_effect=self.launch):
            result = self.executor.execute(self.packet)
        self.assertTrue(result["context_valid"])

    def test_skill_acknowledgement_without_its_body_is_not_delivery(self):
        self.executor.recon_marker = "# /codescout-companion:reconnaissance"
        p = self.prepared / "request-0.json"
        raw = json.loads(p.read_text())
        raw["messages"][1]["content"][1]["content"] = "Launching skill: codescout-companion:reconnaissance"
        p.write_text(json.dumps(raw))
        with patch.object(native.external, "launch", side_effect=self.launch):
            result = self.executor.execute(self.packet)
        self.assertFalse(result["context_valid"])

    def test_error_tool_result_does_not_prove_system_or_skill_delivery(self):
        p = self.prepared / "request-0.json"
        raw = json.loads(p.read_text())
        for block in raw["messages"][1]["content"]:
            block["is_error"] = True
        p.write_text(json.dumps(raw))
        with patch.object(native.external, "launch", side_effect=self.launch):
            result = self.executor.execute(self.packet)
        self.assertFalse(result["context_valid"])

    def test_missing_submission_is_returned_for_protocol_incomplete_without_retry(self):
        def launch(*args, **kwargs):
            return self.receipt
        with patch.object(native.external, "launch", side_effect=launch) as call:
            result = self.executor.execute(self.packet)
        self.assertIsNone(result["submission"])
        self.assertEqual(call.call_count, 1)
        self.assertTrue(result["capture_complete"])

    def test_cleanup_failure_and_unsettled_cost_are_not_silently_success(self):
        self.receipt["cleanup_error"] = "owned container removal not confirmed"
        self.receipt["unknown_provider_cost"] = True
        with patch.object(native.external, "launch", side_effect=self.launch):
            result = self.executor.execute(self.packet)
        self.assertFalse(result["cleanup_complete"])
        self.assertFalse(result["cost_is_final"])

    def test_source_symlink_escape_is_rejected_after_cost_is_preserved(self):
        outside = self.root / "outside"
        outside.write_text("host-private")
        def launch(*args, **kwargs):
            result = self.launch(*args, **kwargs)
            (self.actor / "escape").symlink_to(outside)
            return result
        with patch.object(native.external, "launch", side_effect=launch):
            result = self.executor.execute(self.packet)
        self.assertFalse(result["capture_complete"])
        self.assertEqual(result["cost_usd"], "0.07")

    def test_default_executor_cannot_start_a_paid_call(self):
        executor = native.NativeExecutor(self.prepared, self.root / "captured",
            system_lines=["Shared source-only guidance."], recon_marker="RECON_LOADED")
        with patch.object(native.external, "launch") as call:
            with self.assertRaisesRegex(ValueError, "paid"):
                executor.execute(self.packet)
        call.assert_not_called()

    def test_malformed_context_preserves_settled_cost_and_safe_capture(self):
        (self.prepared / "request-0.json").write_text("{broken")
        with patch.object(native.external, "launch", side_effect=self.launch):
            result = self.executor.execute(self.packet)
        self.assertEqual(result["cost_usd"], "0.07")
        self.assertTrue(result["cost_is_final"])
        self.assertTrue(result["capture_complete"])
        self.assertFalse(result["context_valid"])

    def test_each_incomplete_native_lifecycle_dimension_is_reflected(self):
        for label, change, field in [
            ("supervision", {"supervision_error": "failed"}, "cleanup_complete"),
            ("background", {"background_evidence": {"complete": False}}, "cleanup_complete"),
            ("capture", {"artifact_evidence": {"complete": False}}, "capture_complete"),
            ("too_many_turns", {"lifecycle": {"continuations": 3}}, "context_valid"),
            ("negative_turns", {"lifecycle": {"continuations": -1}}, "context_valid")]:
            with self.subTest(label=label):
                (self.actor / "program.txt").write_text("original\n")
                original = dict(self.receipt)
                self.receipt.update(change)
                self.executor.capture = self.root / ("capture-" + label)
                with patch.object(native.external, "launch", side_effect=self.launch):
                    result = self.executor.execute(self.packet)
                self.assertFalse(result[field])
                self.assertEqual(result["cost_usd"], "0.07")
                self.receipt = original
                (self.prepared / "native-executor.json").unlink()

    def test_preflight_rejects_each_concrete_runtime_binding_mismatch(self):
        import copy
        for key in self.binding:
            with self.subTest(key=key):
                binding = copy.deepcopy(self.binding)
                binding[key] = ("sha256:" if key == "image" else "") + "f" * 64
                self.assertTrue(callable(getattr(self.executor, "bind_readiness", None)),
                                "native executor cannot bind readiness yet")
                with self.assertRaisesRegex(ValueError, "binding"):
                    self.executor.bind_readiness(binding)

    def test_consuming_adapter_refuses_wrong_executor_before_launch(self):
        from adapter import run_phase, PhaseInvalid
        from test_readiness import fixture
        expected, wire = fixture()
        binding = dict(self.binding)
        binding["image"] = "sha256:" + "f" * 64
        expected["binding"] = dict(binding)
        wire["binding"] = dict(binding)
        request = {"state": {"run_id": "r", "phase": "investigate", "baseline_paths": ["program.txt"],
                            "baseline_digest": self.binding["source_snapshot_sha256"]},
            "execution_mode": "native", "native_preflight": {"expected": expected, "wire": wire},
            "phase_budget_usd": "0.50", "public_packet": {"issue": "Public request"},
            "out": str(self.root / "phase")}
        with patch.object(native.external, "launch", side_effect=AssertionError("must not launch")) as call:
            with self.assertRaises(PhaseInvalid):
                run_phase(request, self.executor)
        call.assert_not_called()

    def test_source_drift_after_binding_is_refused_before_launch(self):
        (self.actor / "program.txt").write_text("changed after admission\n")
        with patch.object(native.external, "launch") as call:
            with self.assertRaisesRegex(ValueError, "binding"):
                self.executor.execute(self.packet)
        call.assert_not_called()

    def test_executable_drift_after_binding_is_refused_before_launch(self):
        (self.root / "runtime-bin/codescout").write_bytes(b"changed after admission")
        with patch.object(native.external, "launch") as call:
            with self.assertRaisesRegex(ValueError, "binding"):
                self.executor.execute(self.packet)
        call.assert_not_called()

    def test_continuation_control_does_not_require_a_protocol_submission(self):
        self.packet.update(cli_cap_usd="0.45", arm="R", prompt="Continue the public repair.")
        with patch.object(native.external, "launch", return_value=self.receipt) as launched:
            result = self.executor.execute(self.packet)
        cfg = json.loads((self.prepared / "prepared.json").read_text())
        self.assertNotIn("submission.json", cfg["prompt"])
        self.assertIsNone(result["submission"])
        self.assertEqual(launched.call_args.kwargs["cli_cap"], "0.45")

    def test_fixed_xhigh_baseline_reaches_the_native_launch_at_xhigh(self):
        self.packet.update(cli_cap_usd="0.45", arm="X", phase="ordinary", prompt="Repair the public task.")
        with patch.object(native.external, "launch", return_value=self.receipt) as launched:
            result = self.executor.execute(self.packet)
        self.assertEqual(launched.call_args.kwargs["effort"], "xhigh")
        self.assertNotIn("submission.json", json.loads(
            (self.prepared / "prepared.json").read_text())["prompt"])
        self.assertIsNone(result["submission"])
        self.assertEqual(launched.call_args.kwargs["cli_cap"], "0.45")

    def test_ordinary_low_baseline_retains_the_same_native_boundary(self):
        self.packet.update(cli_cap_usd="0.45", arm="L", phase="ordinary", prompt="Repair the public task.")
        with patch.object(native.external, "launch", return_value=self.receipt) as launched:
            result = self.executor.execute(self.packet)
        self.assertEqual(launched.call_args.kwargs["effort"], "low")
        self.assertEqual(launched.call_args.kwargs["allowance"], "0.50")
        self.assertEqual(result["cost_usd"], "0.07")
        self.assertTrue(result["context_valid"])
        self.assertNotIn("submission.json", json.loads(
            (self.prepared / "prepared.json").read_text())["prompt"])
        self.assertEqual(launched.call_args.kwargs["cli_cap"], "0.45")

    def test_unknown_arm_is_rejected_before_launch_or_prepared_prompt_change(self):
        self.packet["arm"] = "unregistered"
        original = (self.prepared / "prepared.json").read_bytes()
        with patch.object(native.external, "launch", return_value=self.receipt) as launched:
            with self.assertRaisesRegex(ValueError, "unsupported native arm"):
                self.executor.execute(self.packet)
        launched.assert_not_called()
        self.assertEqual((self.prepared / "prepared.json").read_bytes(), original)
        self.assertFalse(self.executor.capture.exists())

    def test_phase_adapter_forwards_control_identity_to_the_actor_boundary(self):
        from adapter import run_phase
        from types import SimpleNamespace
        packets = []
        def execute(packet):
            packets.append(packet)
            return {"cost_usd": "0.01", "cost_is_final": True, "context_valid": True,
                    "cleanup_complete": True, "capture_complete": True, "turns": 1,
                    "source": str(self.root / "public-baseline"), "submission": None}
        request = {"state": {"run_id": "r", "phase": "investigate",
                            "baseline_digest": self.binding["source_snapshot_sha256"],
                            "baseline_paths": ["program.txt"]},
                   "arm": "R", "execution_mode": "scripted", "phase_budget_usd": "0.50", "cli_cap_usd": "0.45",
                   "public_packet": {"issue": "Public request"}, "out": str(self.root / "control-phase")}
        result = run_phase(request, SimpleNamespace(mode="scripted", execute=execute))
        self.assertEqual(result["state"]["phase"], "repair")
        self.assertEqual(packets[0].get("arm"), "R")
        self.assertEqual(packets[0].get("cli_cap_usd"), "0.45")

    def test_explicit_cli_cap_and_trusted_supervisor_reach_the_launch(self):
        marker = object()
        self.executor = native.NativeExecutor(self.prepared, self.root / "capped-capture",
            system_lines=["Shared source-only guidance."], recon_marker="RECON_LOADED",
            scripted_plan=[], supervisor=marker)
        self.executor.bind_readiness(self.binding)
        self.packet.update(cli_cap_usd="0.45", supervisor="actor cannot supply this")
        with patch.object(native.external, "launch", side_effect=self.launch):
            self.executor.execute(self.packet)
        self.assertEqual(self.launched["cli_cap"], "0.45")
        self.assertEqual(self.launched["allowance"], "0.50")
        self.assertIs(self.launched["supervisor"], marker)

    def test_invalid_cli_caps_cannot_launch_or_mutate_prepared_prompt(self):
        for index, cap in enumerate((None, "0", "-1", "0.50", "0.51", "NaN", "Infinity", True)):
            with self.subTest(cap=cap):
                prepared = self.root / ("cap-case-" + str(index))
                shutil.copytree(self.prepared, prepared)
                engine = native.NativeExecutor(prepared, self.root / ("cap-capture-" + str(index)),
                    system_lines=["Shared source-only guidance."], recon_marker="RECON_LOADED",
                    scripted_plan=[])
                engine.bind_readiness(self.binding)
                before = (prepared / "prepared.json").read_bytes()
                packet = dict(self.packet, cli_cap_usd=cap)
                with patch.object(native.external, "launch", return_value=self.receipt) as launched:
                    with self.assertRaisesRegex(ValueError, "CLI cap"):
                        engine.execute(packet)
                launched.assert_not_called()
                self.assertEqual((prepared / "prepared.json").read_bytes(), before)

    def test_phase_adapter_refuses_invalid_caps_before_actor_or_output(self):
        from adapter import PhaseInvalid, run_phase
        from types import SimpleNamespace
        calls = []
        def execute(packet):
            calls.append(packet)
            raise AssertionError("invalid CLI cap reached actor")
        for index, cap in enumerate((None, "0", "-1", "0.50", "0.51", "NaN", True)):
            with self.subTest(cap=cap):
                out = self.root / ("invalid-adapter-cap-" + str(index))
                request = {"state":{"run_id":"r","phase":"investigate"},
                    "arm":"R","execution_mode":"scripted","phase_budget_usd":"0.50","cli_cap_usd":cap,
                    "public_packet":{"issue":"Public request"},"out":str(out)}
                with self.assertRaisesRegex(PhaseInvalid,"CLI cap"):
                    run_phase(request,SimpleNamespace(mode="scripted",execute=execute))
                self.assertFalse(out.exists())
        self.assertEqual(calls, [])


    def add_build_inputs(self):
        import hashlib
        (self.actor / "node_modules").mkdir()
        raw = {"schema":"public-build-inputs-v1", "image":self.image, "seed":None,
               "dependency_dirs":["node_modules"], "cache_mounts":[]}
        stage = native.public_build_inputs.stage_inputs(raw, self.actor, self.image, self.prepared / "build-state")
        helper = self.prepared / "public-build-inputs-helper.py"
        helper.write_bytes(Path(native.public_build_inputs.__file__).read_bytes())
        cfg_path = self.prepared / "prepared.json"
        cfg = json.loads(cfg_path.read_bytes())
        cfg.update(public_build_inputs=raw, public_build_stage=stage,
                   public_build_inputs_helper=str(helper), execution_profile="cargo-v3")
        cfg.setdefault("files", {})[str(helper)] = hashlib.sha256(helper.read_bytes()).hexdigest()
        cfg_path.write_text(json.dumps(cfg))
        argv_path = self.prepared / "mcp-native-argv.json"
        argv = json.loads(argv_path.read_bytes())
        mounts = ["--mount", "type=bind,src=" + str(self.actor) + ",dst=/testbed"]
        for row in stage["mounts"]:
            mounts += ["--mount", "type=bind,src=" + row["source"] + ",dst=" + row["destination"]]
        argv[-4:-4] = mounts
        argv_path.write_text(json.dumps(argv))
        self.binding.update(source_snapshot_sha256=native._public_digest(self.actor, dependency_dirs=["node_modules"]),
                            public_build_inputs_sha256=stage["fingerprint"])
        return raw, stage

    def test_declared_native_dependencies_bind_capture_and_readback(self):
        raw, stage = self.add_build_inputs()
        self.executor.bind_readiness(self.binding)
        with patch.object(native.external, "launch", side_effect=self.launch):
            result = self.executor.execute(self.packet)
        self.assertTrue(result["capture_complete"])
        self.assertEqual(result["public_build_inputs"], stage["fingerprint"])
        self.assertTrue((self.root / "captured/node_modules").is_dir())
        self.assertEqual((self.root / "captured/program.txt").read_text(), "repaired\n")
        self.assertEqual(result["public_build_generated_after"],
                         native.public_build_inputs.generated_digest(Path(stage["output"]) / "generated"))

    def test_valid_but_different_command_descriptor_is_refused_before_binding(self):
        from adapter import _admit_backend, PhaseInvalid
        from test_readiness import fixture
        raw, stage = self.add_build_inputs()
        expected, wire = fixture()
        expected["binding"] = dict(self.binding)
        wire["binding"] = dict(self.binding)
        expected["public_build_inputs"] = raw
        common = {"execution_mode":"native", "native_preflight":{"expected":expected,"wire":wire},
                  "execution_profile":"cargo-v3", "public_build_inputs":raw}
        self.assertEqual(_admit_backend(common, self.executor)["binding"], self.binding)
        different = {**raw, "dependency_dirs":[]}
        with self.assertRaises(PhaseInvalid):
            _admit_backend({**common, "public_build_inputs":different}, self.executor)
