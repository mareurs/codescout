from pathlib import Path
import hashlib, json, stat, tarfile, re, gzip

HOME = Path('/home/marius/work/claude/codescout')
OWN = Path('/home/marius/.codex/worktrees/cf66/codescout')
REAL = Path('/var/tmp/ep9-01a15/real-source-probe-4e959f3765')
REVIEW = Path('/tmp/execution-profile-review-20261109')
DEST = HOME / 'docs/trackers/effort-steering/evidence/execution-profiles-20261109'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def members():
    paths = {}
    for prefix, root in [('source', OWN / 'tools/effort_protocol'),
                         ('real-source', REAL), ('review', REVIEW)]:
        for path in sorted([root] + list(root.rglob('*'))):
            relative = path.relative_to(root)
            if any(part in {'__pycache__', '.git'} for part in relative.parts):
                continue
            paths[(Path(prefix) / relative).as_posix()] = path
    for path in sorted(REAL.parent.glob('execution-*.log')):
        paths['tests/' + path.name] = path
    for n in range(0x30, 0x40):
        path = Path('/tmp/codescout-bg') / ('337215-288e487c-bg_' + format(n, '08x') + '.json')
        if path.exists():
            row = json.loads(path.read_text())
            if any(token in row.get('command', '') for token in ['ep9-01a15', 'tools/effort_protocol']):
                paths['jobs/' + path.name] = path
    return paths

def describe(path):
    mode = path.lstat().st_mode
    row = {'mode': stat.S_IMODE(mode)}
    if stat.S_ISREG(mode):
        data = path.read_bytes()
        row.update(kind='file', bytes=len(data), sha256=digest(data))
    elif stat.S_ISLNK(mode):
        row.update(kind='symlink', target=path.readlink().as_posix())
    elif stat.S_ISDIR(mode):
        row.update(kind='directory')
    else:
        raise ValueError('unsupported evidence object: ' + str(path))
    return row

def main():
    assert (REVIEW / 'final').is_dir()
    DEST.mkdir(parents=True, exist_ok=True)
    archive = DEST / 'execution-profiles.tar.gz'
    manifest_path = DEST / 'manifest.json'
    assert not archive.exists() and not manifest_path.exists()
    paths = members()
    manifest = {name: describe(path) for name, path in sorted(paths.items())}
    with archive.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w') as bundle:
                for name, path in sorted(paths.items()):
                    assert describe(path) == manifest[name], 'source changed before capture: ' + name
                    bundle.add(path, arcname=name, recursive=False)
    verified = set()
    with tarfile.open(archive, 'r:gz') as bundle:
        for item in bundle:
            assert item.name in manifest and item.name not in verified
            row = manifest[item.name]
            assert item.mode == row['mode']
            if row['kind'] == 'file':
                assert item.isfile()
                data = bundle.extractfile(item).read()
                assert len(data) == row['bytes'] and digest(data) == row['sha256']
            elif row['kind'] == 'symlink':
                assert item.issym() and item.linkname == row['target']
            else:
                assert item.isdir()
            verified.add(item.name)
    assert verified == set(manifest)
    for name, path in paths.items():
        assert describe(path) == manifest[name], 'source changed after capture: ' + name
    result = {
        'schema': 1, 'scope': 'uncommitted execution profile source, all retained real-source attempts, tests and applied mutation review',
        'session_id': 'codex:01a15ca9-f939-7603-acb5-01c6b02f68e2',
        'source_branch': 'research/evidence-protocol-20261109',
        'source_base': 'fe8bb4b34f5e7912f9b16c4c0bf1ff73a3a10a23',
        'archive': archive.name, 'archive_bytes': archive.stat().st_size,
        'archive_sha256': digest(archive.read_bytes()), 'archive_readback_verified': True,
        'logical_entries': len(manifest),
        'regular_files': sum(row['kind'] == 'file' for row in manifest.values()),
        'directories': sum(row['kind'] == 'directory' for row in manifest.values()),
        'symlinks': sum(row['kind'] == 'symlink' for row in manifest.values()),
        'source_files': {name: row for name, row in manifest.items() if name.startswith('source/') and row['kind'] == 'file'},
        'members': manifest,
        'limits': [
            'Excludes __pycache__ and review .git directories.',
            'No dependency image export; exact existing image ID remains required.',
            'Receipts contain original absolute host mount paths; preserved bytes do not assert replay at another path without explicit reconstruction.',
            'Earlier public-handoff archive is a separate source version.',
            'No paid cohort admission or generic efficacy claim.',
            'No peer resource cleanup or unidentified orphan volume deletion.'
        ]}
    manifest_path.write_text(json.dumps(result, indent=2) + '\n')
    check = json.loads(manifest_path.read_text())
    assert check == result
    print(json.dumps({k: v for k, v in result.items() if k not in {'source_files', 'members'}}, indent=2))

if __name__ == '__main__':
    main()
