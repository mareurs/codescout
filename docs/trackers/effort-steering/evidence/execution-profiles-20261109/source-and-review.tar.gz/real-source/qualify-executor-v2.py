from pathlib import Path
import json,shutil,time,re
from executor import execute_observation
from receipts import input_digest,verify_receipt
root=Path('/var/tmp/ep9-01a15/real-source-probe-4e959f3765'); source=root/'source'; out=root/'execution-v2'; original=input_digest(source); image='sha256:a7108935ae3cb9c6573af9f0e371dbaaffb4c9a88a92038e334184bf8672cc32'
paths=sorted(p.relative_to(source).as_posix() for p in source.rglob('*'))
commands=[('metadata',['cargo','metadata','--offline','--locked','--no-deps','--format-version','1'],['Cargo.toml','Cargo.lock']),('stdx-public',['cargo','test','--offline','--locked','-p','stdx','--lib'],['Cargo.toml','Cargo.lock','crates/stdx']),('source-readonly',['python3','-I','-c',"from pathlib import Path; import errno; p=Path('/testbed/Cargo.toml');\ntry: p.open('a').write('forbidden')\nexcept OSError as e: print('source write rejected', e.errno); assert e.errno == errno.EROFS\nelse: raise SystemExit('source was writable')"],['Cargo.toml'])]
rows=[]
for rid,argv,tests in commands:
 request={'id':rid,'run_id':'real-source-profile-20261109','phase':'investigate','execution_profile':'cargo-v1','argv':argv,'cwd':'.','test_files':tests,'production_files':paths,'image':image,'kind':'observation','timeout_s':180,'max_log_bytes':4*1024*1024}
 start=time.monotonic(); facts=execute_observation(request,source,out); assert facts['exit_code']==0; assert input_digest(source)==original
 if rid=='metadata':
  metadata=json.loads((out/rid/'stdout').read_text()); assert metadata['workspace_root']=='/testbed' and metadata['target_directory']=='/build/target'
 rows.append({'id':rid,'facts':facts,'wall_s':time.monotonic()-start})
negative=root/'negative-source'; shutil.copytree(source,negative,symlinks=True); tests=negative/'crates/stdx/tests'; tests.mkdir(exist_ok=True); (tests/'effort_runtime_negative.rs').write_text('#[test]\nfn deliberately_failing_public_runtime_control() { assert!(false, "intentional runtime control"); }\n')
request={'id':'stdx-negative','run_id':'real-source-profile-20261109','phase':'challenge','execution_profile':'cargo-v1','argv':['cargo','test','--offline','--locked','-p','stdx','--test','effort_runtime_negative'],'cwd':'.','test_files':['Cargo.toml','Cargo.lock','crates/stdx'],'production_files':paths,'image':image,'kind':'observation','timeout_s':180,'max_log_bytes':4*1024*1024}
facts=execute_observation(request,negative,out); assert facts['exit_code']==101 and facts['resource_valid'] and facts['complete']; assert input_digest(source)==original
rows.append({'id':'stdx-negative','facts':facts})
for row in rows:
 candidate=negative if row['id']=='stdx-negative' else source
 assert verify_receipt({'id':row['id']},out,candidate,expected_profile='cargo-v1')==row['facts']
result={'scope':'public real-workspace leaf-crate runtime controls, no actor or provider, no private grades; not whole-project repair qualification','image':image,'source_head':'3678da48aebe17797d2f792bde07a46f5bf4a827','source_digest':original,'source_unchanged':input_digest(source)==original,'execution_profile':'cargo-v1','controls':rows,'paid_ready':False}
(root/'executor-qualification.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result))
