from pathlib import Path
import json, shutil, time
from executor import execute_observation
from receipts import input_digest, verify_receipt

root = Path('/var/tmp/ep9-01a15/real-source-probe-4e959f3765')
source = root / 'source'
out = root / 'execution-v3'
original = input_digest(source)
image = 'sha256:a7108935ae3cb9c6573af9f0e371dbaaffb4c9a88a92038e334184bf8672cc32'

def selected_tests(tree, names):
    selected = set()
    for name in names:
        path = tree / name
        candidates = path.rglob('*') if path.is_dir() else [path]
        for item in candidates:
            if item.is_symlink():
                raise ValueError('test inventory cannot name a symbolic alias')
            if item.is_file():
                selected.add(item.relative_to(tree).as_posix())
    assert selected
    return sorted(selected)

def execute(rid, argv, names, tree, phase='investigate'):
    tests = selected_tests(tree, names)
    production = sorted(p.relative_to(tree).as_posix() for p in tree.rglob('*'))
    request = {'id': rid, 'run_id': 'real-source-profile-v3-20261109',
               'phase': phase, 'execution_profile': 'cargo-v1', 'argv': argv,
               'cwd': '.', 'test_files': tests, 'production_files': production,
               'image': image, 'kind': 'observation', 'timeout_s': 180,
               'max_log_bytes': 4 * 1024 * 1024}
    start = time.monotonic()
    facts = execute_observation(request, tree, out)
    assert verify_receipt({'id': rid}, out, tree, expected_profile='cargo-v1') == facts
    assert input_digest(source) == original
    return {'id': rid, 'facts': facts, 'test_file_count': len(tests),
            'test_files': tests, 'wall_s': time.monotonic() - start}

def main():
    rows = []
    rows.append(execute('metadata', ['cargo', 'metadata', '--offline', '--locked', '--no-deps', '--format-version', '1'], ['Cargo.toml', 'Cargo.lock'], source))
    assert rows[-1]['facts']['exit_code'] == 0
    metadata = json.loads((out / 'metadata/stdout').read_text())
    assert metadata['workspace_root'] == '/testbed'
    assert metadata['target_directory'] == '/build/target'
    rows.append(execute('stdx-public', ['cargo', 'test', '--offline', '--locked', '-p', 'stdx', '--lib'], ['Cargo.toml', 'Cargo.lock', 'crates/stdx'], source))
    assert rows[-1]['facts']['exit_code'] == 0
    probe = "from pathlib import Path; import errno; p=Path('/testbed/Cargo.toml');\ntry: p.open('a').write('forbidden')\nexcept OSError as e: print('source write rejected', e.errno); assert e.errno == errno.EROFS\nelse: raise SystemExit('source was writable')"
    rows.append(execute('source-readonly', ['python3', '-I', '-c', probe], ['Cargo.toml'], source))
    assert rows[-1]['facts']['exit_code'] == 0
    negative = root / 'negative-source-v3'
    shutil.copytree(source, negative, symlinks=True)
    tests = negative / 'crates/stdx/tests'
    tests.mkdir(exist_ok=True)
    (tests / 'effort_runtime_negative.rs').write_text('#[test]\nfn deliberately_failing_public_runtime_control() { assert!(false, "intentional runtime control"); }\n')
    rows.append(execute('stdx-negative', ['cargo', 'test', '--offline', '--locked', '-p', 'stdx', '--test', 'effort_runtime_negative'], ['Cargo.toml', 'Cargo.lock', 'crates/stdx'], negative, 'challenge'))
    assert rows[-1]['facts']['exit_code'] == 101
    assert rows[-1]['facts']['resource_valid'] and rows[-1]['facts']['complete']
    assert rows[1]['facts']['test_digest'] != rows[-1]['facts']['test_digest']
    assert rows[1]['facts']['source_digest'] != rows[-1]['facts']['source_digest']
    result = {'scope': 'public real-workspace leaf-crate runtime controls; no actor, provider or private grades; not whole-project repair qualification',
              'image': image, 'source_head': '3678da48aebe17797d2f792bde07a46f5bf4a827',
              'source_digest': original, 'source_unchanged': input_digest(source) == original,
              'execution_profile': 'cargo-v1', 'controls': rows, 'paid_ready': False}
    (root / 'executor-qualification-v3.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))

if __name__ == '__main__':
    main()
