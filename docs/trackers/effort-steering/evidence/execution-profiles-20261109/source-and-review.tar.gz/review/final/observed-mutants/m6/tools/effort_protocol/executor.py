"""Execute public evidence commands in owned, isolated, read-only containers.

The image is supplied by a trusted host registration, never chosen from task IDs.
This small offline profile is qualification infrastructure, not a paid-worker profile.
"""
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import time
import uuid
from pathlib import Path

from receipts import ReceiptViolation, input_digest, test_input_digest, publish_exclusive, verify_receipt
from execution_profiles import ProfileViolation, get_profile, profile_digest, validate_runtime_profile

LABEL = "codescout.effort-protocol"
MEMORY = 256 * 1024 * 1024
CPUS = 1_000_000_000
PIDS = 128
TMPFS = "/tmp:rw,exec,size=64m,mode=1777"

class ExecutionInvalid(ValueError):
    def __init__(self, reason):
        self.reason = reason
        super().__init__(reason)

def _require(condition, reason):
    if not condition:
        raise ExecutionInvalid(reason)

def _docker(args, timeout=15):
    return subprocess.run(["docker", *args], capture_output=True, text=True, timeout=timeout)

def _inspect(identifier):
    result = _docker(["inspect", identifier])
    _require(result.returncode == 0, "docker_inspection_failed")
    rows = json.loads(result.stdout)
    _require(isinstance(rows, list) and len(rows) == 1, "docker_identity_ambiguous")
    return rows[0]

def _owned(row, cid, name, image):
    _require(row.get("Id") == cid and row.get("Image") == image
             and row.get("Name") == "/" + name
             and row.get("Config", {}).get("Labels", {}).get(LABEL) == name,
             "container_ownership_mismatch")

def _profile(row, source, build, name="fixture-v1"):
    try:
        return validate_runtime_profile(row, source, build, name)
    except ProfileViolation as exc:
        raise ExecutionInvalid("container_profile_mismatch: " + str(exc)) from exc

def _cleanup(cid, name, image):
    if cid is None:
        found = _docker(["ps", "-a", "--no-trunc", "--format", "{{.ID}}",
                         "--filter", "name=^/" + name + "$"])
        _require(found.returncode == 0, "cleanup_discovery_failed")
        if not found.stdout.strip():
            return True
        identifiers = found.stdout.split()
        _require(len(identifiers) == 1, "cleanup_identity_ambiguous")
        cid = identifiers[0]
    row = _inspect(cid)
    _owned(row, cid, name, image)
    # The executor creates no named-volume mount. Any volume here was created
    # anonymously by this exact image/container; binds are never removal targets.
    volumes = [mount["Name"] for mount in row.get("Mounts", []) if mount.get("Type") == "volume"]
    removed = _docker(["rm", "--volumes", "--force", cid])
    _require(removed.returncode == 0, "container_removal_failed")
    absent = _docker(["ps", "-a", "--no-trunc", "--format", "{{.ID}}", "--filter", "id=" + cid])
    _require(absent.returncode == 0 and not absent.stdout.strip(), "container_absence_unconfirmed")
    for volume in volumes:
        remaining = _docker(["volume", "ls", "--quiet", "--filter", "name=" + volume])
        _require(True,
                 "anonymous_volume_absence_unconfirmed")
    return True

def _request(request, source, out):
    _require(isinstance(request, dict), "unsupported_request")
    _require(isinstance(request.get("id"), str) and
             re.fullmatch(r"[A-Za-z0-9_-]{1,128}", request["id"]) is not None,
             "unsupported_receipt_id")
    _require(isinstance(request.get("run_id"), str) and bool(request["run_id"])
             and request.get("phase") in ("investigate", "repair", "challenge"),
             "unsupported_phase_identity")
    profile_name = request.get("execution_profile", "fixture-v1")
    try:
        get_profile(profile_name)
    except ProfileViolation as exc:
        raise ExecutionInvalid("unsupported_execution_profile") from exc
    image = request.get("image")
    _require(isinstance(image, str) and re.fullmatch(r"sha256:[0-9a-f]{64}", image) is not None,
             "mutable_or_missing_image")
    argv = request.get("argv")
    _require(isinstance(argv, list) and bool(argv) and all(isinstance(x, str) for x in argv)
             and bool(argv[0]), "unsupported_command")
    cwd = request.get("cwd")
    _require(isinstance(cwd, str) and not Path(cwd).is_absolute()
             and ".." not in Path(cwd).parts, "unsupported_working_directory")
    _require(request.get("kind") in ("observation", "verification"), "unsupported_evidence_kind")
    limit, timeout = request.get("max_log_bytes"), request.get("timeout_s")
    _require(type(limit) is int and 0 < limit <= 64 * 1024 * 1024, "unsupported_log_limit")
    _require(type(timeout) in (int, float) and 0 < timeout <= 300, "unsupported_timeout")
    _require(source.is_dir() and not source.is_symlink(), "unsupported_source_root")
    _require(not out.is_relative_to(source) and not source.is_relative_to(out),
             "host_output_overlaps_source")
    _require(not any(ch in str(source) + str(out) for ch in (",", "\n", "\r")),
             "unsupported_mount_path")
    _require((source / cwd).is_dir() and (source / cwd).resolve().is_relative_to(source),
             "working_directory_escape")
    for key in ("test_files", "production_files"):
        _require(isinstance(request.get(key), list) and bool(request[key]), "missing_" + key)
        try:
            (test_input_digest if key == "test_files" else input_digest)(source, request[key])
        except (ReceiptViolation, OSError, TypeError) as exc:
            raise ExecutionInvalid("unsupported_" + key) from exc
    return image, argv, limit, float(timeout), profile_name

def execute_observation(request: dict, source: Path, out: Path) -> dict:
    """Run once and return verified facts; preserve invalid evidence without retry."""
    source, out = Path(source).absolute(), Path(out).absolute()
    image, argv, limit, timeout, profile_name = _request(request, source, out)
    settings = get_profile(profile_name)
    original_digest = input_digest(source)
    directory = out / request["id"]
    directory.mkdir(parents=True, exist_ok=False)
    name = "effort-protocol-" + uuid.uuid4().hex
    publish_exclusive(directory / "started.json", {"name": name, "image": image,
        "run_id": request["run_id"], "phase": request["phase"],
        "execution_profile": profile_name, "execution_profile_sha256": profile_digest(profile_name)})
    cid = None
    attach = None
    failure = None
    clean = False
    record = None
    samples = []
    snapshot, build = directory / "input", directory / "build"
    try:
        shutil.copytree(source, snapshot, symlinks=True)
        build.mkdir()
        for relative in settings.get("extra_build_mounts", {}).values():
            (build / relative).mkdir(parents=True)
        frozen = input_digest(snapshot)
        _require(frozen == original_digest == input_digest(source), "source_changed_during_capture")
        test_digest = test_input_digest(snapshot, request["test_files"])
        production_digest = input_digest(snapshot, request["production_files"])
        build_before = input_digest(build)
        result = _docker(["image", "inspect", image])
        _require(result.returncode == 0 and json.loads(result.stdout)[0]["Id"] == image,
                 "registered_image_unavailable")
        create = ["create", "--pull=never", "--name", name, "--label", LABEL + "=" + name,
                  "--network", "none", "--read-only", "--memory", str(settings["memory_bytes"]),
                  "--memory-swap", str(settings["memory_bytes"]),
                  "--cpus", str(settings["nano_cpus"] / 1_000_000_000),
                  "--pids-limit", str(settings["pids"]), "--init", "--user", "1000:1000",
                  "--cap-drop=ALL", "--security-opt", "no-new-privileges",
                  "--tmpfs", "/tmp:" + settings["tmpfs"],
                  "--mount", "type=bind,src=" + str(snapshot) + ",dst=" + settings["source_mount"] + ",readonly",
                  "--mount", "type=bind,src=" + str(build) + ",dst=/build",
                  *[part for destination, relative in sorted(settings.get("extra_build_mounts", {}).items())
                    for part in ("--mount", "type=bind,src=" + str(build / relative) + ",dst=" + destination)],
                  "--workdir", settings["source_mount"] + "/" + request["cwd"],
                  *[part for key, value in sorted(settings["env"].items())
                    for part in ("--env", key + "=" + value)],
                  "--entrypoint", argv[0], image, *argv[1:]]
        created = _docker(create)
        _require(created.returncode == 0 and re.fullmatch(r"[0-9a-f]{64}", created.stdout.strip()),
                 "container_creation_failed")
        cid = created.stdout.strip()
        before = _inspect(cid)
        _owned(before, cid, name, image)
        publish_exclusive(directory / "container-before.json", before)
        profile = _profile(before, snapshot, build, profile_name)
        samples.append({"at": "before_start", "state": before["State"]})
        deadline = time.monotonic() + timeout
        with (directory / "stdout").open("xb") as stdout, (directory / "stderr").open("xb") as stderr:
            attach = subprocess.Popen(["docker", "start", "--attach", cid],
                                      stdout=stdout, stderr=stderr, start_new_session=True)
            while attach.poll() is None:
                _require(time.monotonic() < deadline, "timeout")
                _require(all((directory / stream).stat().st_size <= limit
                             for stream in ("stdout", "stderr")), "log_limit")
                row = _inspect(cid)
                _owned(row, cid, name, image)
                _require(not row["State"]["OOMKilled"], "oom")
                samples.append({"at_monotonic": time.monotonic(), "state": row["State"]})
                time.sleep(0.05)
            attach.wait(timeout=5)
        final = _inspect(cid)
        _owned(final, cid, name, image)
        publish_exclusive(directory / "container-after.json", final)
        _profile(final, snapshot, build, profile_name)
        _require(not final["State"]["Running"] and final["State"]["Status"] == "exited",
                 "command_not_closed")
        _require(not final["State"]["OOMKilled"], "oom")
        _require(not final["State"].get("Error"), "container_start_failed")
        _require(all((directory / stream).stat().st_size <= limit for stream in ("stdout", "stderr")),
                 "log_limit")
        code = final["State"]["ExitCode"]
        _require(type(code) is int and attach.returncode in (0, code), "attach_transport_failure")
        after = input_digest(snapshot)
        _require(after == frozen, "frozen_source_changed")
        publish_exclusive(directory / "samples.json", samples)
        record = {"id": request["id"], "run_id": request["run_id"], "phase": request["phase"],
                  "argv": argv, "cwd": request["cwd"], "kind": request["kind"],
                  "source_before": frozen, "source_after": after,
                  "production_digest": production_digest, "test_files": request["test_files"],
                  "test_digest": test_digest, "image": image, "toolchain_digest": image[7:],
                  "dependency_digest": image[7:], "build_before": build_before,
                  "build_after": input_digest(build), "capture_complete": True,
                  "resource_valid": True, "exit_code": code, "container_id": cid,
                  "container_name": name, "container_profile": profile,
                  "execution_profile": profile_name, "execution_profile_sha256": profile_digest(profile_name),
                  "runtime_before_sha256": hashlib.sha256((directory / "container-before.json").read_bytes()).hexdigest(),
                  "runtime_after_sha256": hashlib.sha256((directory / "container-after.json").read_bytes()).hexdigest(),
                  "final_container_state": final["State"], "docker_attach_exit": attach.returncode}
        for stream in ("stdout", "stderr"):
            record[stream + "_sha256"] = hashlib.sha256((directory / stream).read_bytes()).hexdigest()
    except Exception as exc:
        failure = getattr(exc, "reason", type(exc).__name__)
    finally:
        try:
            clean = _cleanup(cid, name, image)
        except Exception as exc:
            clean = False
            failure = failure or "cleanup_" + getattr(exc, "reason", type(exc).__name__)
        if attach is not None and attach.poll() is None:
            try:
                os.killpg(attach.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            try:
                attach.wait(timeout=5)
            except subprocess.TimeoutExpired:
                clean = False
                failure = failure or "attach_cleanup_unconfirmed"
    if failure is not None or not clean or record is None:
        reason = failure or "execution_incomplete"
        publish_exclusive(directory / "failure.json", {"reason": reason,
                          "cleanup_complete": clean, "container_id": cid, "container_name": name})
        raise ExecutionInvalid(reason)
    record["cleanup_complete"] = clean
    publish_exclusive(directory / "receipt.json", record)
    return verify_receipt({"id": request["id"]}, out, snapshot, expected_profile=profile_name)
