"""Phase integration fixtures: scripted actor boundary, REAL evidence execution."""
import copy
import importlib
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
try:
    adapter = importlib.import_module("adapter")
except ModuleNotFoundError as exc:
    if exc.name != "adapter":
        raise
    adapter = None
import receipts

IMAGE = os.environ.get("EFFORT_PROTOCOL_TEST_IMAGE")

class ClosedActor:
    def __init__(self, source, submission):
        self.source, self.submission = source, submission
        self.mode = "scripted"
        self.calls = []
        self.cost = "0.12"
        self.final = True
        self.context = True
        self.cleanup = True
        self.turns = 1

    def bind_readiness(self, binding):
        self.readiness_binding = dict(binding)

    def execute(self, request):
        self.calls.append(copy.deepcopy(request))
        return {"cost_usd": self.cost, "cost_is_final": self.final,
                "context_valid": self.context, "cleanup_complete": self.cleanup,
                "capture_complete": True, "turns": self.turns,
                "source": str(self.source), "submission": copy.deepcopy(self.submission)}

@unittest.skipUnless(IMAGE, "phase integration requires an existing pinned Docker image")
class AdapterTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(adapter, "phase adapter is not implemented")
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / "closed-public-source"
        self.source.mkdir()
        (self.source / "program.txt").write_text("baseline production")
        (self.source / "probe.py").write_text(
            "import sys\nprint('observed', sys.argv[-1]); raise SystemExit(1 if sys.argv[-1]=='bug' else 0)\n")
        baseline_paths = ["program.txt", "probe.py"]
        self.state = {"run_id": "run", "phase": "investigate", "baseline_paths": baseline_paths,
                      "baseline_digest": receipts.input_digest(self.source, baseline_paths),
                      "used_receipts": [], "turns_used": 0}
        self.submission = {"status": "submitted", "clauses": [
            {"id": "bug", "kind": "requirement", "role": "reproduction", "receipts": ["bug-probe"]},
            {"id": "keep", "kind": "preservation", "role": "legitimate", "receipts": ["keep-probe"]}],
            "commands": [{"id": "bug-probe", "argv": ["python3","-I","/work/probe.py","bug"],
                          "cwd": ".", "test_files": ["probe.py"]},
                         {"id": "keep-probe", "argv": ["python3","-I","/work/probe.py","keep"],
                          "cwd": ".", "test_files": ["probe.py"]}]}
        self.actor = ClosedActor(self.source, self.submission)
        self.request = {"state": self.state, "out": str(self.root / "phase"),
                        "phase_budget_usd": "0.60", "image": IMAGE, "execution_mode": "scripted",
                        "public_packet": {"issue": "Repair the public behavior described by the user."},
                        "allowed_probe_prefixes": ["probes/"],
                        "public_checks": [{"argv": ["python3","-I","/work/probe.py","keep"],
                                           "cwd": ".", "test_files": ["probe.py"]}],
                        "command_timeout_s": 10, "max_log_bytes": 1048576}

    def run_phase(self):
        return adapter.run_phase(self.request, self.actor)

    def cost(self):
        return json.loads((self.root / "phase" / "cost.json").read_text())

    def challenge(self):
        self.state["phase"] = "challenge"
        self.state["turns_used"] = 6

    def test_real_receipts_gate_the_transition(self):
        result = self.run_phase()
        self.assertEqual(result["state"]["phase"], "repair")
        self.assertEqual(len(result["receipts"]), 2)
        self.assertEqual(len(self.actor.calls), 1)
        self.assertEqual(self.cost()["known_usd"], "0.12")
        self.assertFalse(self.cost()["unknown"])
        self.assertIn("Investigate", self.actor.calls[0]["prompt"])
    def test_frozen_public_handoff_contains_observations_not_lifecycle_metadata(self):
        result = self.run_phase()
        artifact = result["public_artifact"]
        stored = json.loads((self.root / "phase/public-artifact.json").read_text())
        self.assertEqual(stored, artifact)
        self.assertEqual(artifact["submission"]["clauses"], self.submission["clauses"])
        self.assertEqual([x["exit_code"] for x in artifact["observations"]], [1, 0])
        self.assertIn("observed bug", artifact["observations"][0]["stdout"]["content"])
        self.assertNotIn("cost", artifact)
        # This is exactly the actor packet consumed by the next invocation.
        self.state = result["state"]
        self.request.update(state=self.state, out=str(self.root / "next-phase"),
                            public_packet={"issue": "Public repair", "prior_public_artifacts": [artifact]})
        second = self.run_phase()
        consumed = self.actor.calls[-1]["public_packet"]["prior_public_artifacts"][0]
        self.assertEqual(consumed, stored)
        self.assertEqual(consumed["observations"][0]["stdout"]["content"],
                         artifact["observations"][0]["stdout"]["content"])
    def test_challenge_verifications_are_present_in_public_artifact(self):
        self.challenge()
        result = self.run_phase()
        self.assertEqual(result["state"]["phase"], "closed")
        observed = {row["id"]: row for row in result["public_artifact"]["observations"]}
        self.assertTrue(result["final_receipts"])
        self.assertEqual(set(observed), set(result["receipts"]))
        for rid in result["final_receipts"]:
            self.assertEqual(observed[rid]["kind"], "verification")
            self.assertEqual(observed[rid]["exit_code"], 0)
            self.assertEqual(observed[rid]["stdout"]["content"], "observed keep\n")
    def test_unknown_host_execution_profile_stops_before_actor_spend(self):
        self.request["execution_profile"] = "unregistered"
        with self.assertRaisesRegex(adapter.PhaseInvalid, "profile"):
            self.run_phase()
        self.assertEqual(self.actor.calls, [])

    def test_actor_cannot_override_host_execution_profile(self):
        self.request["execution_profile"] = "fixture-v1"
        for command in self.submission["commands"]:
            command["execution_profile"] = "cargo-v1"
        result = self.run_phase()
        self.assertEqual(result["state"]["phase"], "repair")
        started = json.loads((self.root / "phase/started.json").read_text())
        self.assertEqual(started["execution_profile"], "fixture-v1")
        for rid in result["receipts"]:
            record = json.loads((self.root / "phase/commands" / rid / "receipt.json").read_text())
            self.assertEqual(record["execution_profile"], "fixture-v1")

    def test_host_cargo_profile_is_forwarded_to_actual_evidence_commands(self):
        self.request["execution_profile"] = "cargo-v1"
        for command in self.submission["commands"]:
            command["argv"][2] = "/testbed/probe.py"
        result = self.run_phase()
        self.assertEqual(result["state"]["phase"], "repair")
        for rid in result["receipts"]:
            record = json.loads((self.root / "phase/commands" / rid / "receipt.json").read_text())
            self.assertEqual(record["execution_profile"], "cargo-v1")
            actual = json.loads((self.root / "phase/commands" / rid / "container-before.json").read_text())
            self.assertEqual(actual["HostConfig"]["Memory"], 8 * 1024**3)

    def test_phase_zero_production_drift_keeps_cost_and_is_incomplete(self):
        (self.source / "program.txt").write_text("unauthorized phase-zero repair")
        result = self.run_phase()
        self.assertEqual(result["state"]["phase"], "incomplete")
        self.assertEqual(self.cost()["known_usd"], "0.12")
        self.assertFalse((self.root / "phase" / "commands").exists())

    def test_new_production_file_cannot_masquerade_as_a_probe(self):
        (self.source / "new-production.py").write_text("print('new source')")
        result = self.run_phase()
        self.assertEqual(result["state"]["phase"], "incomplete")
        self.assertFalse((self.root / "phase" / "commands").exists())

    def test_context_failure_cannot_start_a_command(self):
        self.actor.context = False
        with self.assertRaises(adapter.PhaseInvalid):
            self.run_phase()
        self.assertEqual(self.cost()["known_usd"], "0.12")
        self.assertFalse((self.root / "phase" / "commands").exists())

    def test_unsettled_cost_keeps_known_amount_and_stops(self):
        self.actor.final = False
        with self.assertRaises(adapter.PhaseInvalid):
            self.run_phase()
        self.assertEqual(self.cost()["known_usd"], "0.12")
        self.assertTrue(self.cost()["unknown"])

    def test_missing_cost_is_unknown_not_zero(self):
        self.actor.cost = None
        with self.assertRaises(adapter.PhaseInvalid):
            self.run_phase()
        self.assertIsNone(self.cost()["known_usd"])
        self.assertTrue(self.cost()["unknown"])

    def test_cleanup_uncertainty_stops_before_commands(self):
        self.actor.cleanup = False
        with self.assertRaises(adapter.PhaseInvalid):
            self.run_phase()
        self.assertFalse((self.root / "phase" / "commands").exists())

    def test_missing_observation_is_incomplete_without_another_actor_call(self):
        self.actor.submission["clauses"][0]["receipts"] = ["not-executed"]
        result = self.run_phase()
        self.assertEqual(result["state"]["phase"], "incomplete")
        self.assertEqual(len(self.actor.calls), 1)

    def test_malformed_submission_is_not_a_paid_retry(self):
        self.actor.submission = "not-an-object"
        result = self.run_phase()
        self.assertEqual(result["state"]["phase"], "incomplete")
        self.assertEqual(len(self.actor.calls), 1)
        self.assertEqual(self.cost()["known_usd"], "0.12")

    def test_duplicate_attempt_is_refused_before_actor_call(self):
        self.run_phase()
        with self.assertRaises(FileExistsError):
            self.run_phase()
        self.assertEqual(len(self.actor.calls), 1)

    def test_fourth_phase_is_refused_before_actor_call(self):
        self.state["phase"] = "closed"
        with self.assertRaises(adapter.PhaseInvalid):
            self.run_phase()
        self.assertEqual(self.actor.calls, [])

    def test_final_public_checks_are_host_selected_and_source_bound(self):
        self.challenge()
        self.actor.submission["final_receipts"] = ["bug-probe"]
        result = self.run_phase()
        self.assertEqual(result["state"]["phase"], "closed")
        self.assertTrue(result["final_receipts"])
        self.assertNotIn("bug-probe", result["final_receipts"])
        for rid in result["final_receipts"]:
            self.assertEqual(result["receipts"][rid]["source_digest"], result["state"]["source_digest"])
            self.assertEqual(result["receipts"][rid]["kind"], "verification")

    def test_failed_final_public_check_is_functional_incompleteness(self):
        self.challenge()
        self.request["public_checks"][0]["argv"][-1] = "bug"
        result = self.run_phase()
        self.assertEqual(result["state"]["phase"], "incomplete")
        self.assertFalse(result["measurement_invalid"])

    def test_continuation_control_has_equal_opportunities_without_protocol_gates(self):
        self.request['arm'] = 'R'
        self.actor.submission = None
        result = self.run_phase()
        self.assertEqual(result['state']['phase'], 'repair')
        self.assertEqual(result['receipts'], {})
        self.assertEqual(self.actor.calls[0]['max_continuations'], 2)
        self.assertEqual(self.actor.calls[0]['allowance_usd'], '0.60')
        self.assertIn('Continue', self.actor.calls[0]['prompt'])


    def test_private_packet_key_is_refused_before_actor_call(self):
        self.request['public_packet']['private_tests'] = 'not public'
        with self.assertRaises(adapter.PhaseInvalid):
            self.run_phase()
        self.assertEqual(self.actor.calls, [])


    def test_three_phase_chain_has_no_receipt_id_collision(self):
        for number, phase in enumerate(('investigate', 'repair', 'challenge')):
            self.request['state'] = self.state
            self.request['out'] = str(self.root / ('phase-' + str(number)))
            result = self.run_phase()
            self.state = result['state']
            self.assertNotEqual(self.state['phase'], 'incomplete')
        self.assertEqual(self.state['phase'], 'closed')
        self.assertEqual(self.state['turns_used'], 3)
        self.assertEqual(len(self.actor.calls), 3)
        self.assertEqual(len(self.state['used_receipts']), len(set(self.state['used_receipts'])))


    def test_public_packet_and_prompt_are_bound_before_actor_execution(self):
        self.run_phase()
        start = json.loads((self.root / 'phase' / 'started.json').read_text())
        saved = json.loads((self.root / 'phase' / 'actor-packet.json').read_text())
        self.assertEqual(saved, self.actor.calls[0])
        self.assertEqual(start['prompt_sha256'], adapter.packet_digest(saved['prompt']))
        self.assertEqual(start['public_packet_sha256'], adapter.packet_digest(saved['public_packet']))

    def test_excess_turns_cannot_pass_the_gate(self):
        self.actor.turns = 4
        result = self.run_phase()
        self.assertEqual(result["state"]["phase"], "incomplete")

    def test_unclassified_backend_cannot_start_an_actor(self):
        self.request.pop("execution_mode", None)
        with self.assertRaises(adapter.PhaseInvalid):
            self.run_phase()
        self.assertEqual(self.actor.calls, [])

    def test_native_backend_needs_real_preparation_before_actor_call(self):
        from test_readiness import fixture
        expected, wire = fixture()
        wire["status"]["result"]["content"][0]["text"] = json.dumps({"project_root": "/testbed", "languages": []})
        self.request.update(execution_mode="native", native_preflight={"expected": expected, "wire": wire})
        self.actor.mode = "native"
        with self.assertRaises(adapter.PhaseInvalid):
            self.run_phase()
        self.assertEqual(self.actor.calls, [])

    def test_native_preflight_is_consumed_and_bound_before_actor_execution(self):
        from test_readiness import fixture
        expected, wire = fixture()
        self.request.update(execution_mode="native", native_preflight={"expected": expected, "wire": wire})
        self.actor.mode = "native"
        result = self.run_phase()
        self.assertEqual(result["state"]["phase"], "repair")
        started = json.loads((Path(self.request["out"]) / "started.json").read_text())
        self.assertEqual(started["native_readiness_sha256"], adapter.packet_digest(
            adapter.validate_readiness(expected, wire)))

if __name__ == "__main__":
    unittest.main()
