"""Actual isolated-command tests. Enable only with an existing pinned image."""
import importlib
import json
import os
import sys
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
try:
    executor = importlib.import_module("executor")
except ModuleNotFoundError as exc:
    if exc.name != "executor":
        raise
    executor = None
import receipts

IMAGE = os.environ.get("EFFORT_PROTOCOL_TEST_IMAGE")
@unittest.skipUnless(IMAGE, "actual Docker tests require EFFORT_PROTOCOL_TEST_IMAGE")
class ExecutorTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(executor, "isolated command executor is not implemented")
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / "public-source"
        self.source.mkdir()
        (self.source / "program.txt").write_text("original production")
        (self.source / "probe.py").write_text("print('observed-value')\n")
        self.out = self.root / "host-only"
        self.request = {"id": "one", "run_id": "run", "phase": "investigate",
                        "argv": ["python3", "-I", "/work/probe.py"], "cwd": ".",
                        "test_files": ["probe.py"], "production_files": ["program.txt"],
                        "image": IMAGE, "kind": "observation",
                        "timeout_s": 10, "max_log_bytes": 1024 * 1024}

    def run_command(self):
        return executor.execute_observation(self.request, self.source, self.out)

    def record(self):
        return json.loads((self.out / "one" / "receipt.json").read_text())

    def test_actual_execution_is_source_bound_and_removed(self):
        result = self.run_command()
        self.assertEqual(result["exit_code"], 0)
        self.assertIn(b"observed-value", (self.out / "one" / "stdout").read_bytes())
        data = self.record()
        self.assertTrue(data["cleanup_complete"])
        self.assertEqual(data["source_before"], data["source_after"])
        self.assertEqual(data["source_before"], receipts.input_digest(self.out / "one" / "input"))
        self.assertEqual(data["image"], IMAGE)
        self.assertFalse(data["final_container_state"]["Running"])
        self.assertFalse(data["final_container_state"]["OOMKilled"])
        self.assertEqual(data["production_digest"], receipts.input_digest(self.source, ["program.txt"]))

    def test_production_snapshot_is_kernel_read_only(self):
        (self.source / "probe.py").write_text(
            "from pathlib import Path\n"
            "try:\n Path('/work/program.txt').write_text('altered')\n"
            "except OSError as e:\n print('read-only', e.errno)\n"
            "else:\n raise RuntimeError('source was writable')\n")
        self.assertEqual(self.run_command()["exit_code"], 0)
        self.assertEqual((self.source / "program.txt").read_text(), "original production")
        self.assertIn(b"read-only", (self.out / "one" / "stdout").read_bytes())

    def test_actor_cannot_read_host_receipt_namespace(self):
        hidden = self.out / "host-canary"
        hidden.parent.mkdir()
        hidden.write_text("controller-only")
        (self.source / "probe.py").write_text(
            "from pathlib import Path\n"
            f"assert not Path({str(hidden)!r}).exists()\n"
            "assert not Path('/home/marius').exists()\nprint('isolated')\n")
        self.assertEqual(self.run_command()["exit_code"], 0)

    def test_build_and_temporary_directories_are_writable(self):
        (self.source / "probe.py").write_text(
            "from pathlib import Path\n"
            "Path('/build/generated.txt').write_text('generated')\n"
            "Path('/tmp/probe.txt').write_text('temporary')\nprint('build-ok')\n")
        self.assertEqual(self.run_command()["exit_code"], 0)
        self.assertEqual((self.out / "one" / "build/generated.txt").read_text(), "generated")
        self.assertNotEqual(self.record()["build_before"], self.record()["build_after"])

    def test_functional_failure_retains_nonzero_observation(self):
        (self.source / "probe.py").write_text("print('assertion-failure'); raise SystemExit(7)\n")
        self.assertEqual(self.run_command()["exit_code"], 7)
        self.assertTrue(self.record()["resource_valid"])

    def test_same_policy_executes_a_shell_probe(self):
        (self.source / "probe.sh").write_text("printf 'shell-observation\\n'\n")
        self.request["argv"] = ["/bin/sh", "/work/probe.sh"]
        self.request["test_files"] = ["probe.sh"]
        self.assertEqual(self.run_command()["exit_code"], 0)
        self.assertIn(b"shell-observation", (self.out / "one" / "stdout").read_bytes())

    def test_container_cannot_use_host_network(self):
        (self.source / "probe.py").write_text(
            "import socket\ns=socket.socket(); s.settimeout(0.3)\n"
            "try:\n s.connect(('192.0.2.1',80))\n"
            "except OSError:\n print('network-disabled')\n"
            "else:\n raise RuntimeError('unexpected network connection')\n")
        self.assertEqual(self.run_command()["exit_code"], 0)
        self.assertEqual(self.record()["container_profile"]["NetworkMode"], "none")

    def test_timeout_is_invalid_and_container_is_removed(self):
        (self.source / "probe.py").write_text("import time\nprint('started', flush=True)\ntime.sleep(30)\n")
        self.request["timeout_s"] = 0.5
        with self.assertRaises(executor.ExecutionInvalid):
            self.run_command()
        failure = json.loads((self.out / "one" / "failure.json").read_text())
        self.assertTrue(failure["cleanup_complete"])
        self.assertEqual(failure["reason"], "timeout")
        self.assertFalse((self.out / "one" / "receipt.json").exists())

    def test_log_limit_is_not_a_complete_observation(self):
        (self.source / "probe.py").write_text("print('x'*50000)\n")
        self.request["max_log_bytes"] = 1000
        with self.assertRaises(executor.ExecutionInvalid):
            self.run_command()
        failure = json.loads((self.out / "one" / "failure.json").read_text())
        self.assertTrue(failure["cleanup_complete"])
        self.assertEqual(failure["reason"], "log_limit")

    def test_cgroup_oom_is_invalid_and_removed(self):
        (self.source / 'probe.py').write_text("print('allocating', flush=True)\nblock = bytearray(512 * 1024 * 1024)\nprint(len(block))\n")
        with self.assertRaises(executor.ExecutionInvalid):
            self.run_command()
        failure = json.loads((self.out / 'one' / 'failure.json').read_text())
        self.assertEqual(failure['reason'], 'oom')
        self.assertTrue(failure['cleanup_complete'])


    def test_generated_executable_inputs_are_bound(self):
        (self.source / 'probe.py').write_text("from pathlib import Path\nimport subprocess\nPath('/build/generated.py').write_text(\"print('generated-observation')\\n\")\nsubprocess.run(['python3','-I','/build/generated.py'], check=True)\n")
        self.assertEqual(self.run_command()['exit_code'], 0)
        self.assertEqual(self.record()['build_after'], receipts.input_digest(self.out / 'one' / 'build'))
        self.assertIn(b'generated-observation', (self.out / 'one' / 'stdout').read_bytes())

    def test_actor_cannot_overwrite_or_replay_a_receipt(self):
        self.run_command()
        before = (self.out / "one" / "receipt.json").read_bytes()
        with self.assertRaises(FileExistsError):
            self.run_command()
        self.assertEqual((self.out / "one" / "receipt.json").read_bytes(), before)

    def test_mutable_image_is_rejected_before_effect(self):
        self.request["image"] = "python:3.12-slim"
        with self.assertRaises(executor.ExecutionInvalid):
            self.run_command()
        self.assertFalse(self.out.exists())

    def test_test_path_escape_is_rejected_before_effect(self):
        self.request["test_files"] = ["../secret"]
        with self.assertRaises(executor.ExecutionInvalid):
            self.run_command()
        self.assertFalse(self.out.exists())

    def test_host_outputs_cannot_overlap_source(self):
        self.out = self.source / "host-only"
        with self.assertRaises(executor.ExecutionInvalid):
            self.run_command()
        self.assertFalse(self.out.exists())

    def test_generated_input_tampering_is_rejected_on_readback(self):
        (self.source / 'probe.py').write_text("from pathlib import Path\nPath('/build/generated.py').write_text(\"print('original')\\n\")\nprint('generated')\n")
        self.run_command()
        (self.out / 'one' / 'build' / 'generated.py').write_text("print('changed')\n")
        with self.assertRaises(receipts.ReceiptViolation):
            receipts.verify_receipt({'id': 'one'}, self.out, self.out / 'one' / 'input')

    def test_receipt_readback_uses_actual_frozen_copy(self):
        self.run_command()
        (self.source / "program.txt").write_text("later actor edits")
        result = receipts.verify_receipt({"id": "one"}, self.out, self.out / "one" / "input")
        self.assertEqual(result["exit_code"], 0)
        (self.out / "one" / "input" / "program.txt").write_text("frozen copy tampered")
        with self.assertRaises(receipts.ReceiptViolation):
            receipts.verify_receipt({"id": "one"}, self.out, self.out / "one" / "input")
    def test_cargo_profile_controls_real_resources_source_path_and_environment(self):
        self.request.update(execution_profile="cargo-v1",
                            argv=["python3", "-I", "-c",
                                  "import os,json; from pathlib import Path; "
                                  "Path('/build/generated').write_text('actual build'); "
                          "Path('/mnt_tmp/generated').write_text('scratch input'); "
                                  "print(json.dumps([os.getcwd(),os.environ['CARGO_TARGET_DIR'],"
                                  "os.environ['CARGO_NET_OFFLINE'],os.environ['TMPDIR']]))"])
        result = self.run_command()
        self.assertEqual(result["exit_code"], 0, (self.out / "one/stderr").read_text())
        record = self.record()
        self.assertEqual(record["execution_profile"], "cargo-v1")
        self.assertEqual(len(record["execution_profile_sha256"]), 64)
        self.assertEqual(json.loads((self.out / "one/stdout").read_text()),
                         ["/testbed", "/build/target", "true", "/mnt_tmp"])
        for label in ("before", "after"):
            actual = json.loads((self.out / "one" / ("container-" + label + ".json")).read_text())
            self.assertEqual(actual["HostConfig"]["Memory"], 8 * 1024**3)
            self.assertEqual(actual["HostConfig"]["MemorySwap"], 8 * 1024**3)
            self.assertEqual(actual["HostConfig"]["NanoCpus"], 4_000_000_000)
            self.assertEqual(actual["HostConfig"]["PidsLimit"], 512)
            mounts = {m["Destination"]: m for m in actual["Mounts"]}
            self.assertFalse(mounts["/testbed"]["RW"])
            self.assertTrue(mounts["/build"]["RW"])
            self.assertTrue(mounts["/mnt_tmp"]["RW"])
            self.assertEqual(mounts["/mnt_tmp"]["Source"], str(self.out / "one/build/scratch"))
        self.assertEqual((self.source / "program.txt").read_text(), "original production")

    def test_unknown_execution_profile_stops_before_container_or_evidence(self):
        self.request["execution_profile"] = "unregistered"
        with self.assertRaisesRegex(executor.ExecutionInvalid, "unsupported_execution_profile"):
            self.run_command()
        self.assertFalse(self.out.exists())

    def test_fresh_profile_receipt_cannot_drop_or_change_its_binding(self):
        self.run_command()
        original = self.record()
        for key in ("execution_profile", "execution_profile_sha256"):
            with self.subTest(key=key):
                altered = dict(original)
                altered.pop(key, None)
                (self.out / "one/receipt.json").write_text(json.dumps(altered))
                with self.assertRaisesRegex(ValueError, "profile"):
                    receipts.verify_receipt({"id": "one"}, self.out, self.out / "one/input")
        (self.out / "one/receipt.json").write_text(json.dumps(original))
        with self.assertRaisesRegex(ValueError, "profile"):
            receipts.verify_receipt({"id": "one"}, self.out, self.out / "one/input",
                                    expected_profile="cargo-v1")

    def test_raw_runtime_profile_tampering_cannot_be_relabelled_valid(self):
        self.run_command()
        path = self.out / "one/container-after.json"
        actual = json.loads(path.read_text())
        actual["HostConfig"]["Memory"] = 0
        path.write_text(json.dumps(actual))
        record = self.record()
        import hashlib
        record["runtime_after_sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
        (self.out / "one/receipt.json").write_text(json.dumps(record))
        with self.assertRaisesRegex(ValueError, "profile"):
            receipts.verify_receipt({"id": "one"}, self.out, self.out / "one/input")
    def test_rejected_profile_keeps_raw_before_and_after_inspections(self):
        original = executor._profile
        for reject_at, stage in ((1, "before"), (2, "after")):
            with self.subTest(stage=stage):
                self.request["id"] = stage
                calls = 0
                def reject(row, *args):
                    nonlocal calls
                    calls += 1
                    if calls == reject_at:
                        raise executor.ExecutionInvalid("container_profile_mismatch: test rejection")
                    return original(row, *args)
                with patch.object(executor, "_profile", side_effect=reject):
                    with self.assertRaisesRegex(executor.ExecutionInvalid, "profile"):
                        self.run_command()
                directory = self.out / stage
                raw = directory / ("container-" + stage + ".json")
                self.assertTrue(raw.is_file(), "rejected runtime input must survive cleanup")
                self.assertTrue(json.loads((directory / "failure.json").read_text())["cleanup_complete"])

    @unittest.skipUnless(os.environ.get("EFFORT_PROTOCOL_VOLUME_TEST_IMAGE"),
                         "anonymous-volume cleanup requires an explicit existing volume image")
    def test_owned_anonymous_image_volume_is_removed_with_its_container(self):
        image = os.environ["EFFORT_PROTOCOL_VOLUME_TEST_IMAGE"]
        import uuid
        name = "effort-volume-control-" + uuid.uuid4().hex
        made = executor._docker(["create", "--pull=never", "--name", name, "--label",
                                 executor.LABEL + "=" + name, "--entrypoint", "python3",
                                 image, "-c", "print('not started')"])
        self.assertEqual(made.returncode, 0, made.stderr)
        cid = made.stdout.strip()
        before = executor._inspect(cid)
        executor._owned(before, cid, name, image)
        volumes = [m["Name"] for m in before["Mounts"] if m["Type"] == "volume"]
        self.assertTrue(volumes, "control image must declare an anonymous volume")
        try:
            self.assertTrue(executor._cleanup(cid, name, image))
            for volume in volumes:
                self.assertNotEqual(executor._docker(["volume", "inspect", volume]).returncode, 0,
                                    "container removal must not leave its anonymous volume")
        finally:
            # Exact volumes observed on this test-created container only.
            executor._docker(["rm", "--volumes", "-f", cid])
            for volume in volumes:
                if executor._docker(["volume", "inspect", volume]).returncode == 0:
                    executor._docker(["volume", "rm", volume])

if __name__ == "__main__":
    unittest.main()
