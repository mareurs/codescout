import json,sys,unittest,os,time
copy,tag=sys.argv[1:]
sys.path.insert(0,os.path.abspath(copy))
names=['tools.effort_protocol.test_execution_profiles',
'tools.effort_protocol.test_executor.ExecutorTests.test_cargo_profile_controls_real_resources_source_path_and_environment',
'tools.effort_protocol.test_executor.ExecutorTests.test_unknown_execution_profile_stops_before_container_or_evidence',
'tools.effort_protocol.test_executor.ExecutorTests.test_fresh_profile_receipt_cannot_drop_or_change_its_binding',
'tools.effort_protocol.test_executor.ExecutorTests.test_raw_runtime_profile_tampering_cannot_be_relabelled_valid',
'tools.effort_protocol.test_executor.ExecutorTests.test_rejected_profile_keeps_raw_before_and_after_inspections',
'tools.effort_protocol.test_executor.ExecutorTests.test_owned_anonymous_image_volume_is_removed_with_its_container',
'tools.effort_protocol.test_adapter.AdapterTests.test_unknown_host_execution_profile_stops_before_actor_spend',
'tools.effort_protocol.test_adapter.AdapterTests.test_actor_cannot_override_host_execution_profile',
'tools.effort_protocol.test_adapter.AdapterTests.test_host_cargo_profile_is_forwarded_to_actual_evidence_commands']
from final_extra import profile_extra, inventory_extra
extra = inventory_extra if 'inventory' in tag else profile_extra
names = ([] if 'inventory' in tag else names) + ['tools.effort_protocol.test_executor.ExecutorTests.' + n for n in extra]
suite=unittest.defaultTestLoader.loadTestsFromNames(names)
discovered=suite.countTestCases()
start=time.monotonic()
with open(tag+'.log','w') as stream:
 result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
data=dict(tag=tag,discovered=discovered,executed=result.testsRun-len(result.skipped),skips=len(result.skipped),failures=len(result.failures),errors=len(result.errors),success=result.wasSuccessful(),elapsed=time.monotonic()-start)
open(tag+'.json','w').write(json.dumps(data,indent=2))
print(json.dumps(data),flush=True)
