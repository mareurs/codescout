import os,sys,json,hashlib,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
copy,tag=sys.argv[1:]
sys.path.insert(0,str(Path(copy).resolve()/'tools/effort_protocol'))
import executor,receipts,test_executor
class EdgeTests(unittest.TestCase):
    def setUp(self):
        self.case=test_executor.ExecutorTests()
        self.case.setUp()
        self.addCleanup(self.case.doCleanups)
    def receipt(self):
        self.case.run_command()
        directory=self.case.out/'one'
        return directory,json.loads((directory/'receipt.json').read_text())
    def check(self,directory,record):
        (directory/'receipt.json').write_text(json.dumps(record))
        with self.assertRaises(ValueError):
            receipts.verify_receipt({'id':'one'},self.case.out,directory/'input')
    def test_environment_guard(self):
        directory,record=self.receipt()
        path=directory/'container-after.json'
        row=json.loads(path.read_text())
        row['Config']['Env']=[x for x in row['Config']['Env'] if not x.startswith('HOME=')]+['HOME=/wrong']
        path.write_text(json.dumps(row))
        record['runtime_after_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
        self.check(directory,record)
    def test_raw_worker_identity_guard(self):
        directory,record=self.receipt()
        path=directory/'container-before.json'
        row=json.loads(path.read_text())
        row['Id']='f'*64
        path.write_text(json.dumps(row))
        record['runtime_before_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
        self.check(directory,record)
    def test_raw_hash_guard(self):
        directory,record=self.receipt()
        path=directory/'container-after.json'
        path.write_text(path.read_text()+'\n ')
        self.check(directory,record)
    def test_cleanup_ownership_guard(self):
        row={'Id':'foreign','Image':'image','Name':'/worker','Config':{'Labels':{executor.LABEL:'worker'}},'Mounts':[]}
        with patch.object(executor,'_inspect',return_value=row),patch.object(executor,'_docker',return_value=SimpleNamespace(returncode=0,stdout='')) as docker:
            with self.assertRaisesRegex(executor.ExecutionInvalid,'ownership'):
                executor._cleanup('owned','worker','image')
            docker.assert_not_called()
    def test_cleanup_volume_absence_guard(self):
        row={'Id':'owned','Image':'image','Name':'/worker','Config':{'Labels':{executor.LABEL:'worker'}},'Mounts':[{'Type':'volume','Name':'owned-volume'}]}
        def docker(args):
            return SimpleNamespace(returncode=0,stdout='owned-volume\n' if args[:2]==['volume','ls'] else '')
        with patch.object(executor,'_inspect',return_value=row),patch.object(executor,'_docker',side_effect=docker):
            with self.assertRaisesRegex(executor.ExecutionInvalid,'anonymous_volume_absence'):
                executor._cleanup('owned','worker','image')
suite=unittest.defaultTestLoader.loadTestsFromTestCase(EdgeTests)
with open(tag+'.log','w') as stream:
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
data=dict(tag=tag,executed=result.testsRun-len(result.skipped),skips=len(result.skipped),failures=len(result.failures),errors=len(result.errors),success=result.wasSuccessful())
open(tag+'.json','w').write(json.dumps(data,indent=2))
print(json.dumps(data))
