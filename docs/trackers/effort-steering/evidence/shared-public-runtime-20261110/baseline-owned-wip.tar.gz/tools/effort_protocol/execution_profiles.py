"""Versioned host-selected command contracts; no task or repair-specific policy."""
import copy
import hashlib
import json
from pathlib import Path

_PROFILES = {
    "fixture-v1": {
        "memory_bytes": 256 * 1024 * 1024, "nano_cpus": 1_000_000_000, "pids": 128,
        "source_mount": "/work", "tmpfs": "rw,exec,size=64m,mode=1777",
        "env": {"HOME": "/tmp", "PYTHONDONTWRITEBYTECODE": "1"}},
    "cargo-v1": {
        "memory_bytes": 8 * 1024**3, "nano_cpus": 4_000_000_000, "pids": 512,
        "source_mount": "/testbed", "tmpfs": "rw,exec,size=1073741824,mode=1777",
        "extra_build_mounts": {"/mnt_tmp": "scratch"},
        "env": {"HOME": "/tmp", "PYTHONDONTWRITEBYTECODE": "1", "TMPDIR": "/mnt_tmp",
                "CARGO_TARGET_DIR": "/build/target", "CARGO_NET_OFFLINE": "true"}}}


# A new identity binds the cold-command budget; old dictionaries stay frozen.
_PROFILES["cargo-v2"] = {**copy.deepcopy(_PROFILES["cargo-v1"]), "max_command_timeout_s": 900}


class ProfileViolation(ValueError):
    """Registered execution contract is absent or not observed at runtime."""


def _require(condition, message):
    if not condition:
        raise ProfileViolation(message)


def get_profile(name):
    _require(isinstance(name, str) and name in _PROFILES, "unsupported execution profile")
    return copy.deepcopy(_PROFILES[name])

def validate_command_budget(name, timeout_s, max_log_bytes):
    """Validate host command bounds before any actor or container effect."""
    maximum = get_profile(name).get("max_command_timeout_s", 300)
    _require(type(max_log_bytes) is int and 0 < max_log_bytes <= 64 * 1024 * 1024,
             "unsupported_log_limit")
    _require(type(timeout_s) in (int, float) and 0 < timeout_s <= maximum,
             "unsupported_timeout")


def profile_digest(name):
    return hashlib.sha256(json.dumps(get_profile(name), sort_keys=True,
                                     separators=(",", ":")).encode()).hexdigest()


def runtime_contract(name):
    profile = get_profile(name)
    extra = profile.get("extra_build_mounts", {})
    return {"ReadonlyRootfs": True, "NetworkMode": "none",
            "Memory": profile["memory_bytes"], "MemorySwap": profile["memory_bytes"],
            "NanoCpus": profile["nano_cpus"], "PidsLimit": profile["pids"], "Init": True,
            "CapDrop": ["ALL"], "SecurityOpt": ["no-new-privileges"],
            "SourceMount": profile["source_mount"], "Tmpfs": {"/tmp": profile["tmpfs"]},
            "Environment": profile["env"], **({"BuildMounts": extra} if extra else {})}


def validate_runtime_profile(row, source, build, name):
    contract = runtime_contract(name)
    host = row.get("HostConfig", {})
    config = row.get("Config", {})
    _require(all(host.get(k) == contract[k] for k in
                 ("ReadonlyRootfs", "NetworkMode", "Memory", "MemorySwap",
                  "NanoCpus", "PidsLimit", "Init", "CapDrop", "SecurityOpt")),
             "container profile mismatch")
    _require(config.get("User") == "1000:1000", "container profile user mismatch")
    _require(host.get("Tmpfs") == contract["Tmpfs"], "container profile temporary storage mismatch")
    mounts = row.get("Mounts", [])
    binds = {m["Destination"]: m for m in mounts if m.get("Type") == "bind"}
    source_mount = contract["SourceMount"]
    extra = contract.get("BuildMounts", {})
    _require(set(binds) == {source_mount, "/build", *extra}, "container profile unexpected host mount")
    _require(binds[source_mount].get("Source") == str(Path(source))
             and binds[source_mount].get("RW") is False
             and binds["/build"].get("Source") == str(Path(build))
             and binds["/build"].get("RW") is True, "container profile source is not read only")
    _require(all(binds[destination].get("Source") == str(Path(build) / relative)
                 and binds[destination].get("RW") is True
                 for destination, relative in extra.items()), "container profile scratch mount mismatch")
    _require(all(m.get("Type") == "bind" or
                 (m.get("Type") == "tmpfs" and m.get("Destination") == "/tmp")
                 for m in mounts), "container profile unexpected runtime mount")
    environment = dict(item.split("=", 1) for item in config.get("Env", []))
    _require(all(environment.get(key) == value for key, value in contract["Environment"].items()),
             "container profile environment mismatch")
    return contract
