"""Archive closed final checks, the pre-transport failure and administrative recovery."""
import hashlib
import io
import json
import os
from pathlib import Path
import tarfile

ROOT=Path("/var/tmp/ep11-01a15")
WORK=Path("/home/marius/.codex/worktrees/cf66/codescout")
PLAN=WORK/".superpowers/sdd/2026-11-10-campaign-integration"
DEST=Path("/home/marius/work/claude/codescout/docs/trackers/effort-steering/evidence/path-recovery-20261111")

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    DEST.mkdir()
    roots=("final-verification-v3","paid-registration-final-v1","paid-campaign-v1",
           "reviewed-campaign-continuation-v1","paid-launch-v1","paid-argument-seam-v1",
           "paid-argument-seam-v2","path-recovery-registration-v1","review-target-rebind-v1",
           "path-recovery-final-v1")
    entries={}
    skipped=[]
    for role in roots:
        source=ROOT/role
        assert source.resolve(strict=True)==source
        for path in [source,*sorted(source.rglob("*"))]:
            relative=path.relative_to(source)
            if role=="paid-campaign-v1" and any(part in ("actor","preparation-source") for part in relative.parts):
                skipped.append(str(path))
                continue
            name=role if path==source else role+"/"+relative.as_posix()
            entries[name]=path
    for name in ("control_paid_argument_seam.py","prepare_path_recovery.py",
                 "launch_reviewed_paid_campaign.py","finalize_paid_admission.py",
                 "launch_path_recovered_campaign.py","finalize_path_recovery.py",
                 "continue_reviewed_campaign.py","verify_after_bounded_review.py","seal_path_recovery.py"):
        entries["helpers/"+name]=PLAN/name
    manifest={}
    for name,path in entries.items():
        manifest[name]=({"type":"symlink","target":os.readlink(path)} if path.is_symlink()
          else {"type":"directory"} if path.is_dir()
          else {"type":"file","bytes":path.stat().st_size,"sha256":sha(path)})
    provenance={"schema":"effort-path-recovery-custody-v1",
        "scope":"Closed verification, first pre-transport failure/control/audit and independently rebound replacement registration. Active replacement model outputs are excluded.",
        "omitted_duplicate_trees":["paid-campaign-v1 actor","paid-campaign-v1 preparation-source"],
        "omission_basis":"No model workflow reached in first failure. Frozen original public source/index are already preserved in earlier persistent capsule; raw trees remain on disk.",
        "skipped_duplicate_tree_entries":len(skipped),
        "settlement":"Causal native-client zero, not provider invoice proof; original unknown record preserved, old4USDhold remains reserved.",
        "active_replacement_included":False}
    archive=DEST/"evidence.tar.gz"
    with tarfile.open(archive,"x:gz",format=tarfile.PAX_FORMAT,compresslevel=6) as stream:
        for name,path in entries.items():
            record=manifest[name];info=tarfile.TarInfo(name);info.mode=0o600
            if record["type"]=="directory":
                info.type=tarfile.DIRTYPE;info.mode=0o700;stream.addfile(info)
            elif record["type"]=="symlink":
                info.type=tarfile.SYMTYPE;info.linkname=record["target"];stream.addfile(info)
            else:
                info.size=record["bytes"]
                with path.open("rb") as file:stream.addfile(info,file)
        for name,value in (("manifest.json",manifest),("provenance.json",provenance)):
            raw=json.dumps(value,indent=2,sort_keys=True).encode()
            info=tarfile.TarInfo(name);info.mode=0o600;info.size=len(raw);stream.addfile(info,io.BytesIO(raw))
    seen=set()
    with tarfile.open(archive,"r:gz") as stream:
        for member in stream:
            if member.name in ("manifest.json","provenance.json"):continue
            assert member.name not in seen;seen.add(member.name);record=manifest[member.name]
            if record["type"]=="file":
                raw=stream.extractfile(member).read()
                assert len(raw)==record["bytes"] and hashlib.sha256(raw).hexdigest()==record["sha256"]
            elif record["type"]=="symlink":
                assert member.issym() and member.linkname==record["target"]
            else:assert member.isdir()
    assert seen==set(manifest)
    assert all(sha(path)==manifest[name]["sha256"] for name,path in entries.items() if manifest[name]["type"]=="file")
    closure={"schema":"effort-path-recovery-closure-v1","archive":str(archive),
             "archive_bytes":archive.stat().st_size,"archive_sha256":sha(archive),
             "payload_entries":len(manifest),"all_selected_payloads_reopened":True,
             "all_selected_originals_unchanged":True,"active_replacement_included":False}
    (DEST/"closure.json").write_text(json.dumps(closure,indent=2)+"\n")
    print(json.dumps(closure),flush=True)

if __name__=="__main__":
    main()
