"""Finish the previous frozen evaluator child, then verify corrected sources freshly."""
import os
from pathlib import Path
import select
import sys

def main():
    previous=Path("/proc/3851874")
    if previous.exists():
        try:
            command=(previous/"cmdline").read_bytes()
            cwd=(previous/"cwd").resolve(strict=True)
            assert b"unittest" in command and str(cwd)=="/var/tmp/ep11-01a15/private-package/evaluator/source/tools/setup-ab-eval"
            descriptor=os.pidfd_open(3851874)
        except (FileNotFoundError,ProcessLookupError):
            descriptor=None
        if descriptor is not None:
            try:
                readable,_,_=select.select([descriptor],[],[],1200)
                assert readable,"previous owned evaluator child did not finish"
            finally:
                os.close(descriptor)
    sys.path.insert(0,str(Path(__file__).resolve().parent))
    import verify_final_admission_sources as job
    job.OUT=Path("/var/tmp/ep11-01a15/final-verification-v3")
    job.main()

if __name__=="__main__":
    main()
