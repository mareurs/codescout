"""Retain the failed pre-transport attempt and prepare an otherwise identical registration."""
import copy
import hashlib
import json
from pathlib import Path
import sys

WORK=Path("/home/marius/.codex/worktrees/cf66/codescout")
ROOT=Path("/var/tmp/ep11-01a15")
PLAN=WORK/".superpowers/sdd/2026-11-10-campaign-integration"
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
from paid_admission import review_target

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(path):
    return json.loads(Path(path).read_bytes())

def save(path,value):
    with path.open("x") as stream:
        json.dump(value,stream,indent=2,sort_keys=True)

def main():
    out=ROOT/"path-recovery-registration-v1";out.mkdir()
    original=ROOT/"paid-registration-final-v1/registration.json"
    reg=copy.deepcopy(read(original))
    failed=ROOT/"paid-campaign-v1"
    invocation=failed/"attempts/00-L/repair/invocation.json"
    started=failed/"attempts/00-L/repair/native/started.json"
    result=read(failed/"result.json")
    raw=read(invocation)
    control=ROOT/"paid-argument-seam-v2/result.json"
    observed=read(control)
    assert result["status"]=="stopped" and len(result["attempts"])==1 and len(result["unexecuted"])==7
    assert raw["reason"]=="AttributeError: 'str' object has no attribute 'stat'"
    assert read(started)["scripted"] is False
    assert observed["cases"][0]["transport_factory_calls"]==0
    assert observed["cases"][0]["provider_workflow_calls"]==0
    assert observed["cases"][1]["exception_type"]=="StopBeforeProvider"
    assert observed["cases"][1]["provider_workflow_calls"]==0
    correction=read(ROOT/"bounded-correction-v1/final/resolution.json")
    assert all(sha(path)==digest for path,digest in correction["source_after"].items())
    assert sha(observed["source"]["path"])==observed["source"]["sha256"]
    def bind(path):
        path=Path(path)
        digest=sha(path)
        reg["bindings"][str(path)]=digest
        return {"path":str(path),"sha256":digest}
    evidence=[original,invocation,started,failed/"result.json",failed/"ledger-final.json",control,
              failed/"attempts/00-L/repair/native/prepared.json",
              ROOT/"reviewed-campaign-continuation-v1/paid-pilot.log",
              PLAN/"launch_reviewed_paid_campaign.py",PLAN/"finalize_paid_admission.py",
              WORK/"tools/agent_lifecycle/external.py",WORK/"tools/effort_protocol/native_executor.py",
              WORK/"tools/effort_protocol/campaign_native.py",WORK/"tools/effort_protocol/native_campaign.py",
              PLAN/"control_paid_argument_seam.py"]
    audit={"schema":"effort-pretransport-failure-audit-v1","status":"proposed-for-independent-binding-check",
           "failure":"Credential path string reaches external.launch token_path.stat before token read, transport server creation or workflow.execute.",
           "cost_usd":"0","cost_basis":"Causal pre-transport localization from unchanged executed source, actual raw argument/started marker/reason, calibrated by offline string-vs-Path entry control. Not inferred from missing logs.",
           "cost_is_direct_provider_receipt":False,"provider_invoice_reconciliation":False,
           "historical_original_receipt_unchanged":True,
           "original_unknown_preserved":"Raw invocation cost remains null/false; this is an append-only causal settlement, not an edited native receipt.",
           "scientific_outcome":"Infrastructure stop before model execution; no quality result or private grades.",
           "standalone_control_limit":observed["historical_limit"],
           "evidence":[bind(path) for path in evidence],
           "original_controller_terminal":result["status"],
           "release_previous_reservations":[row["id"] for row in read(failed/"ledger-final.json")["reservations"]],
           "historical_4usd_hold":"Remains unresolved and fully reserved.",
           "new_native_client_receipt_count":0,
           "excluded_local_costs":{"root":"unmeasured","review":"unmeasured","embedding_compute":"unmeasured"}}
    audit_path=out/"pretransport-audit.json";save(audit_path,audit)
    reg["campaign_id"]="generic-evidence-pilot-20261111-path-v2"
    reg["output_root"]=str(ROOT/"paid-campaign-path-v2")
    reg["technical_predecessor"]=bind(audit_path)
    reg["admission"]["review"]={"report":None,"resolution":None}
    assert not Path(reg["output_root"]).exists()
    original_reg=read(original)
    semantic_old=copy.deepcopy(original_reg)
    semantic_new=copy.deepcopy(reg)
    for value in (semantic_old,semantic_new):
        value.pop("bindings",None)
        value.pop("campaign_id",None)
        value.pop("output_root",None)
        value.pop("technical_predecessor",None)
        value["admission"].pop("review",None)
    assert semantic_old==semantic_new
    save(out/"registration-for-binding.json",reg)
    save(out/"difference.json",{"original":bind(original),
          "candidate":{"path":str(out/"registration-for-binding.json"),"sha256":sha(out/"registration-for-binding.json")},
          "old_review_target":review_target(original_reg),"new_review_target":review_target(reg),
          "changed_administrative_fields":["campaign_id","output_root","technical_predecessor"],
          "review_placeholder_changed":True,"all_other_protected_fields_equal":True,
          "contract_sources_unchanged":len(correction["source_after"]),"paid_ready":False})
    print(json.dumps({"prepared_new_binding":True,"paid_ready":False,"new_target":review_target(reg)}))

if __name__=="__main__":
    main()
