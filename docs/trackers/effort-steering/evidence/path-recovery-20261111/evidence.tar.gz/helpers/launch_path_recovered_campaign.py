"""Launch the freshly bound replacement for the pre-transport caller failure, once."""
import hashlib
import json
from pathlib import Path
import sys
import time
sys.path.insert(0,"/home/marius/.codex/worktrees/cf66/codescout/tools/effort_protocol")
import runner
from native_campaign import NativeCampaignBackend

def save(path,value):
    with path.open("x") as stream:
        json.dump(value,stream,indent=2,sort_keys=True)

def main():
    root=Path("/var/tmp/ep11-01a15")
    inputs=root/"path-recovery-final-v1"
    path=inputs/"registration.json"
    reg=json.loads(path.read_bytes())
    checked=json.loads((inputs/"preflight.json").read_bytes())
    assert checked["ready"] is True and checked["paid_ready"] is True
    assert reg["mode"]=="paid" and len(reg["schedule"])==8
    assert reg["campaign_id"]=="generic-evidence-pilot-20261111-path-v2"
    assert not Path(reg["output_root"]).exists()
    launch=root/"path-recovery-launch-v1"
    launch.mkdir()
    save(launch/"intent.json",{"schema":"effort-paid-launch-v1","started_at":time.time(),
        "registration":{"path":str(path),"sha256":hashlib.sha256(path.read_bytes()).hexdigest()},
        "scope":"Replacement only for proved pre-transport caller failure. Same frozen eight-attempt protocol; runner revalidates all seven proofs. No automatic retry or policy revision."})
    token=Path(reg["admission"]["credential_path"])
    backend=NativeCampaignBackend(mode="paid",token_path=token)
    assert isinstance(backend.token_path,Path)
    print(json.dumps({"starting_reviewed_pilot":reg["campaign_id"],"attempts":8,"credential_argument_type":type(token).__name__}),flush=True)
    try:
        result=runner.run_campaign(reg,backend)
    except BaseException as error:
        save(launch/"controller-exception.json",{"type":type(error).__name__,"reason":str(error),
            "completed":False,"cost_inference":"No missing cost inferred zero. Inspect preserved receipts/reservations."})
        raise
    summary={"status":result["status"],"reason":result.get("reason"),
             "attempts":len(result["attempts"]),"unexecuted":len(result["unexecuted"]),
             "analysis":result["analysis"],"result_path":str(Path(reg["output_root"])/"result.json")}
    save(launch/"summary.json",summary)
    print(json.dumps(summary),flush=True)

if __name__=="__main__":
    main()
