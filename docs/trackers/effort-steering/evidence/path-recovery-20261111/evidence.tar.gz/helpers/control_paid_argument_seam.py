"""Exercise the actual paid entry before transport using a non-secret placeholder."""
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import sys
from unittest.mock import patch

WORK=Path("/home/marius/.codex/worktrees/cf66/codescout")
ROOT=Path("/var/tmp/ep11-01a15")
sys.path.insert(0,str(WORK/"tools/agent_lifecycle"))
import external

class StopBeforeProvider(Exception):
    pass

def main():
    failed=ROOT/"paid-campaign-v1/attempts/00-L/repair/native"
    out=ROOT/"paid-argument-seam-v2";out.mkdir()
    cfg=json.loads((failed/"prepared.json").read_bytes())
    actor=external.validate_context_path(cfg["actor"])
    external.context_preload(cfg,actor)
    for name,digest in cfg["files"].items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest
    config=external.workflow.validate_config({key:cfg[key] for key in
        ("checks","timeout_s","check_timeout_s","max_continuations")})
    balance,cap=Decimal("3"),Decimal("2.75")
    fake=out/"non-secret-placeholder";fake.write_text("OFFLINE-PLACEHOLDER-NOT-A-REAL-CREDENTIAL")
    fake.chmod(0o600)
    source=Path(external.__file__).resolve()
    rows=[]
    for label,token in (("string",str(fake)),("path",fake)):
        case=out/label;case.mkdir()
        (case/"prepared.json").write_bytes((failed/"prepared.json").read_bytes())
        with patch.object(external,"validate_prepared",return_value=(cfg,config,actor,balance,cap)), \
                patch.object(external.transport,"server",side_effect=StopBeforeProvider("paid entry reached transport; network intentionally blocked")) as transport, \
                patch.object(external.workflow,"execute",side_effect=AssertionError("provider workflow must not run")) as workflow:
            try:
                external.launch(case,effort="low",allowance="3",cli_cap="2.75",token_path=token)
            except (AttributeError,StopBeforeProvider) as error:
                row={"argument_type":type(token).__name__,"exception_type":type(error).__name__,
                     "reason":str(error),"transport_factory_calls":transport.call_count,
                     "provider_workflow_calls":workflow.call_count,
                     "started_marker_exists":(case/"started.json").is_file(),
                     "real_credential_used":False}
            else:
                raise AssertionError("entry unexpectedly completed")
        rows.append(row)
    assert rows[0]["exception_type"]=="AttributeError"
    assert rows[0]["reason"]=="'str' object has no attribute 'stat'"
    assert rows[0]["transport_factory_calls"]==0 and rows[0]["provider_workflow_calls"]==0
    assert rows[1]["exception_type"]=="StopBeforeProvider"
    assert rows[1]["transport_factory_calls"]==1 and rows[1]["provider_workflow_calls"]==0
    receipt={"schema":"effort-paid-argument-seam-v1","source":{"path":str(source),
        "sha256":hashlib.sha256(source.read_bytes()).hexdigest()},
        "control_scope":"Actual external.launch body; retained preparation/context/input hashes rechecked, live embedding network intentionally not revalidated after its recorded cleanup. validate_prepared result reconstructed from those frozen fields, transport blocked before network, non-secret placeholder only.",
        "cases":rows,"historical_limit":"This control is not a provider billing receipt. Historical failure localization additionally rests on the exact source/argument and its recorded reason."}
    (out/"result.json").write_text(json.dumps(receipt,indent=2)+"\n")
    print(json.dumps(receipt),flush=True)

if __name__=="__main__":
    main()
