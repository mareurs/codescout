"""Assemble reviewed paid inputs and run the real, no-provider preflight."""
import copy
import hashlib
import json
from pathlib import Path
import sys

WORK=Path("/home/marius/.codex/worktrees/cf66/codescout")
ROOT=Path("/var/tmp/ep11-01a15")
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
import paid_admission
import runner
from native_campaign import NativeCampaignBackend

def read(path):
    return json.loads(Path(path).read_bytes())

def save(path,value):
    with Path(path).open("x") as stream:
        json.dump(value,stream,indent=2,sort_keys=True)

def main():
    old=ROOT/"paid-registration-v1/registration-for-review.json"
    reg=copy.deepcopy(read(old))
    verification=ROOT/"final-verification-v3/verification.json"
    correction=ROOT/"bounded-correction-v1/final/resolution.json"
    report=ROOT/"whole-admission-review-v1/report.json"
    final=read(verification)
    resolved=read(correction)
    reviewed=read(report)
    assert final["source_after"]==resolved["source_after"]
    assert final["source_before"]==final["source_after"]
    changed=[name for name in final["source_after"] if final["source_after"][name]!=reviewed["source_before"][name]]
    assert {Path(name).name for name in changed}=={
        "test_runner.py","test_native_campaign.py","test_paid_admission.py","paid_admission.py"}
    assert resolved["correction_rounds"]==1 and resolved["outstanding"]==[]
    def bind(path):
        path=Path(path)
        assert path.is_file() and path.resolve(strict=True)==path
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        reg["bindings"][str(path)]=digest
        return {"path":str(path),"sha256":digest}
    for name in final["source_after"]:
        bind(name)
    bind(final["producer"]["path"])
    for execution in final["executions"].values():
        bind(execution["log"]["path"])
    reg["admission"]["verification"]=bind(verification)
    reg["admission"]["review"]={"report":bind(report),"resolution":bind(correction)}
    bind(reviewed["baseline"]["log"]["path"])
    for mutation in reviewed["mutations"]+resolved["replays"]:
        for role in ("original","mutated","log"):
            assert bind(mutation[role]["path"])["sha256"]==mutation[role]["sha256"]
    bind(resolved["baseline"]["log"]["path"])
    bind(resolved["producer"]["path"])
    bind(Path(__file__).resolve())
    assert paid_admission.review_target(reg)==reviewed["target_sha256"]
    proof=paid_admission.verify_paid(reg)
    destination=ROOT/"paid-registration-final-v1"
    destination.mkdir()
    save(destination/"registration.json",reg)
    save(destination/"proof.json",{"is_actor_run":False,"paid_admission":proof,
         "target_sha256":paid_admission.review_target(reg),"changed_sources":changed,
         "finalizer":bind(Path(__file__).resolve())})
    backend=NativeCampaignBackend(mode="paid",token_path=reg["admission"]["credential_path"])
    checked=runner.preflight(reg,backend)
    save(destination/"preflight.json",checked)
    assert checked["ready"] is True and checked["paid_ready"] is True,checked
    print(json.dumps({"no_provider_preflight_complete":True,"paid_ready":True,
                      "original_survivors_killed":len(resolved["replays"]),
                      "output_root":reg["output_root"],"target_sha256":paid_admission.review_target(reg)}),flush=True)

if __name__=="__main__":
    main()
