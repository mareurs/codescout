"""Finish the frozen gate, consume all admission proofs, then run the authorized pilot once."""
import json
import os
from pathlib import Path
import select
import subprocess
import sys
import time

WORK=Path("/home/marius/.codex/worktrees/cf66/codescout")
ROOT=Path("/var/tmp/ep11-01a15")
PLAN=WORK/".superpowers/sdd/2026-11-10-campaign-integration"

def save(path,value):
    with path.open("x") as stream:
        json.dump(value,stream,indent=2,sort_keys=True)

def main():
    out=ROOT/"reviewed-campaign-continuation-v1"
    out.mkdir()
    save(out/"intent.json",{"schema":"reviewed-campaign-continuation-v1","started_at":time.time(),
         "scope":"Existing authorized fixed pilot only, conditional on completed final verification and real seven-proof preflight; no retry or policy change."})
    verification=ROOT/"final-verification-v3/verification.json"
    if not verification.exists():
        process=Path("/proc/3930369")
        try:
            command=(process/"cmdline").read_bytes()
            assert b"verify_after_bounded_review.py" in command
            descriptor=os.pidfd_open(3930369)
        except (FileNotFoundError,ProcessLookupError):
            descriptor=None
        if descriptor is not None:
            try:
                ready,_,_=select.select([descriptor],[],[],7200)
                assert ready,"owned final verification did not finish"
            finally:
                os.close(descriptor)
    assert verification.is_file(),"final verification did not produce a closed receipt"
    closed=json.loads(verification.read_bytes())
    assert closed["source_before"]==closed["source_after"]
    assert all(row["exit_code"]==0 and row["timed_out"] is False for row in closed["executions"].values())
    environment={**os.environ,"TMPDIR":"/var/tmp/ep9-01a15","PYTHONDONTWRITEBYTECODE":"1"}
    for role,script in (("preflight","finalize_paid_admission.py"),("paid-pilot","launch_reviewed_paid_campaign.py")):
        print(json.dumps({"starting":role,"time":time.time()}),flush=True)
        with (out/(role+".log")).open("xb") as stream:
            completed=subprocess.run([sys.executable,"-B",str(PLAN/script)],cwd=WORK,
                                      env=environment,stdout=stream,stderr=subprocess.STDOUT)
        save(out/(role+".json"),{"script":str(PLAN/script),"exit_code":completed.returncode})
        assert completed.returncode==0,role
        if role=="preflight":
            check=json.loads((ROOT/"paid-registration-final-v1/preflight.json").read_bytes())
            assert check["ready"] is True and check["paid_ready"] is True
        print(json.dumps({"completed":role,"exit_code":completed.returncode}),flush=True)
    save(out/"completed.json",{"completed":True,"finished_at":time.time(),
         "scope":"Controller exited; inspect the actual paid result and analysis. This does not assert efficacy or goal completion."})

if __name__=="__main__":
    main()
