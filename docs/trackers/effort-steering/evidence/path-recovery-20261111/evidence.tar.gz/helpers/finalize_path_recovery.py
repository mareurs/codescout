"""Bind an independently attested administrative recovery to the unchanged reviewed protocol."""
import copy
import hashlib
import json
from pathlib import Path
import sys
WORK=Path("/home/marius/.codex/worktrees/cf66/codescout")
ROOT=Path("/var/tmp/ep11-01a15")
PLAN=WORK/".superpowers/sdd/2026-11-10-campaign-integration"
sys.path.insert(0,str(WORK/"tools/effort_protocol"))
import paid_admission
import runner
from native_campaign import NativeCampaignBackend

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(path):
    return json.loads(Path(path).read_bytes())

def save(path,value):
    with path.open("x") as stream:
        json.dump(value,stream,indent=2,sort_keys=True)

def main():
    reg=read(ROOT/"path-recovery-registration-v1/registration-for-binding.json")
    original_report=ROOT/"whole-admission-review-v1/report.json"
    report_path=ROOT/"review-target-rebind-v1/report.json"
    assert sha(report_path)=="ca713580877eab1047e65417c4f489678de0d8955c8f6562e685374300b1cbaa"
    old_report,new_report=read(original_report),read(report_path)
    for key in ("schema","scope","source_before","baseline","mutations","findings","verdict"):
        assert new_report[key]==old_report[key],key
    assert new_report["target_sha256"]==paid_admission.review_target(reg)
    old_resolution=ROOT/"bounded-correction-v1/final/resolution.json"
    resolution=copy.deepcopy(read(old_resolution))
    assert all(sha(path)==digest for path,digest in resolution["source_after"].items())
    destination=ROOT/"path-recovery-final-v1";destination.mkdir()
    def bind(path):
        path=Path(path)
        assert path.resolve(strict=True)==path and path.is_file()
        digest=sha(path)
        reg["bindings"][str(path)]=digest
        return {"path":str(path),"sha256":digest}
    resolution["review_sha256"]=sha(report_path)
    resolution["target_sha256"]=paid_admission.review_target(reg)
    resolution["administrative_rebind"]={"original_report":bind(original_report),
         "original_correction":bind(old_resolution),
         "readback":bind(ROOT/"review-target-rebind-v1/readback.json"),
         "scope":"Same one code correction and exact observed replays; fresh administrative registration only."}
    resolution_path=destination/"resolution.json";save(resolution_path,resolution)
    reg["admission"]["review"]={"report":bind(report_path),"resolution":bind(resolution_path)}
    for name in resolution["source_after"]:
        assert bind(name)["sha256"]==resolution["source_after"][name]
    for mutation in new_report["mutations"]+resolution["replays"]:
        for role in ("original","mutated","log"):
            assert bind(mutation[role]["path"])["sha256"]==mutation[role]["sha256"]
    bind(new_report["baseline"]["log"]["path"])
    bind(PLAN/"launch_path_recovered_campaign.py")
    bind(Path(__file__).resolve())
    proof=paid_admission.verify_paid(reg)
    backend=NativeCampaignBackend(mode="paid",token_path=Path(reg["admission"]["credential_path"]))
    assert isinstance(backend.token_path,Path)
    checked=runner.preflight(reg,backend)
    save(destination/"registration.json",reg)
    save(destination/"proof.json",proof)
    save(destination/"preflight.json",checked)
    assert checked["ready"] is True and checked["paid_ready"] is True,checked
    print(json.dumps({"ready":True,"paid_ready":True,"credential_argument_type":type(backend.token_path).__name__,
                      "target_sha256":paid_admission.review_target(reg),"scope":"No-provider preflight only"}),flush=True)

if __name__=="__main__":
    main()
