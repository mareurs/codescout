from pathlib import Path
import subprocess,time,concurrent.futures
ROOT=Path(__file__).resolve().parent
def run(name):
    with (ROOT/(name+'-driver.log')).open('w') as log:
        subprocess.run(['python3',str(ROOT/'run_review.py'),name],stdout=log,stderr=subprocess.STDOUT,timeout=1200,check=True)
while not (ROOT/'evidence/alternative_error_bypass/result.json').exists():time.sleep(5)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(run,['warm_200_repeat','warm_500_repeat']))
