# Private specification-oracle review

Scoped verdict: PASS for the frozen filtered behavioral oracle/control. No new blocking or important defect found in this slice. This is not full-population, pilot, controller, cost, or paid admission; paid_ready remains false.

Reviewed snapshot: `/tmp/effort-spec-oracle-review-xk8283ov`. Manifest SHA256 `8ad578f9059c7bfc0df2d454fe094ef282e9d6e7afc9b0625454a6cd0c14dbe8`; all 90 manifest-listed file hashes and sizes verified before review and again after execution. No Git range was substituted for the private snapshot.

Evidence: `summary.json`, `runtime-audit.json`, `snapshot-control-verification.json`, and `evidence/<variant>/`. Every variant retains its source copy, exact base-relative candidate.patch and SHA256, production-source SHA256 map, full native grade.log/grade.json with captured streams/stderr, Docker/cgroup observations, and result.json. `finalize.py` exited 0 and generated summary.json.

## Actual observations

| Implementation | Native pass | Native fail | Observation |
|---|---:|---:|---|
| Base | 1 | 3 | Each error fails on repeated request 1, actual 200 |
| Reference | 4 | 0 | Positive control passes |
| Cached status always 200 | 1 | 3 | Killed on warm error statuses |
| Cached status always 500 | 1 | 3 | Killed on warm 200/400/429 |
| Only cached 429 changed to 400 | 3 | 1 | Killed on warm 429 |
| Cached body replaced with corrupt bytes | 0 | 4 | Killed on warm bodies |
| Cached body omitted | 0 | 4 | Killed on warm bodies |
| All cache hits bypassed | 3 | 1 | Killed by the 200 upstream counter |
| Cold status forced to 200 | 1 | 3 | Killed on cold request 0 for all errors |
| Cold body omitted | 0 | 4 | Killed on cold request 0 for all cases |
| Alternative: cache successful responses only | 4 | 0 | Accepted without gold's status-carrying types |

Distinct semantic mutation count: **8 killed, 0 survived, 0 invalid, 0 timeouts**. Every row has 0 missing statuses. Mutants compiled and failed native runtime assertions with test return code 101; no source-hash refusal or compile failure was counted as a kill. Base completed in 123.1s; reference in 120.8s; valid alternative in 120.2s. Two first mutants were repeated unchanged to add final evaluator-side source hashing; the repeats are not extra distinct mutations. Their original runs and identical patch hashes are preserved.

The alternative's entire patch is a success-status guard at public `rust/src/proxy/forward/transport.rs:169`; it starts from base and modifies no cache response types. Patch SHA256: `6e74f03c2816a7824829ec6811829869213915bac9999a2b3d9a2510d87e56e5`.

## Review findings and boundaries

- No new severity finding. The oracle uses actual local HTTP upstream traffic and real forward_request/cache construction (`subject/effort_status_oracle.rs:29`, `:45`, `:69`). Literal fixture status and body are independently checked for both requests (`:64`, `:76`, `:78`). The 200 counter assertion (`:81`) is actually discriminating: global cache bypass passes the three errors but fails that assertion.
- No gold-strategy overconstraint was observed: the independently constructed error-cache-bypass implementation passes. Broader valid implementations, streaming, headers, arbitrary statuses, TTL/eviction and cache-key separation are outside these four fixtures and were not claimed covered.
- Supplement paths are asserted disjoint from gold production paths (`subject/qualify_spec_oracle.py:35`–`:37`). Native grading really restores and reapplies tests after candidate application (`grader-source/multilang_tasks.py:450`–`:455`). The final matrix verifies all four applied production files plus oracle bytes inside the evaluators, so restoration did not erase the reference or mutants. For base/reference these hashes were observed during the run; mutants/alternative were observed before removal.
- Private oracle installation occurs only in fresh evaluator containers. There were no actor-project writes, actor memories, model/provider requests, host bind mounts, commits, pushes, or global changes. Full original expected tests remain an explicit requirement of the proposed superset (`plan.md:24`, `:30`–`:38`; `subject/qualify_spec_oracle.py:47`–`:63`). The filtered record deliberately executes only the new four checks; this review does not establish a functioning/full executed admission path or independently reconstruct the original expected arrays from their registered digest.
- Success-path server abort is explicit (`subject/effort_status_oracle.rs:85`); tests use separate current-thread Tokio test runtimes (`:88` onward), the environment restoration guard runs on unwind, and the native external command timeout is 900s. All observed containers were removed with no OOM. No deliberate timeout/hung-upstream fault injection was performed; timeout recovery is not newly qualified by these passing/failing runs.
- Fresh native runs used the pinned image, UID0, 4 CPUs, 8GiB memory and total memory+swap, init reaper, network none, dropped capabilities, pids limit 4096, and independent writable container layers. Complete-stream qualification was rerun against both supplied controls and every fresh run. Runtime audit confirms 13 native executions, a maximum of two overlapping run intervals, and no host bind mounts. The image supplies an anonymous Docker volume at /mnt_tmp; its volume identity was distinct for every run. Volume reclamation is not claimed.

## Preserved review deviation

The initial reviewer harness imported Python grader dependencies directly from the snapshot and generated 17 `grader-source/__pycache__/*.pyc` files at baseline startup. This violated the intent that the snapshot directory remain untouched. All 90 registered files stayed byte-identical; no source/oracle bytes changed. Bytecode writes were then disabled. The generated files remain preserved rather than deleted under the cleanup constraints. This is review hygiene debt, not a finding against the submitted oracle. The wrapper also gained final evaluator-side source-hash capture after the first two mutants; those mutants were repeated with identical source/patches to complete uniform final evidence.

## Declined scopes

The earlier grader capture/stream WIP was used as a checked dependency, not re-reviewed in full. No new root product gate was run for this private-only review; prior product-gate evidence is not evidence that the full Lean suite passed. Original full selected Lean population, Obscura service/runtime, host resource floor, F6, all arms/context/controller/accounting, cost and paid/model efficacy remain open or outside scope. No mutation evidence here changes the old failed admission or the original F2P label.

Ledger checked: 165e8f13fd7f368c, 99ed755151585a9b, 8a6abb155fdd2c4c, 5f61da17fabfaa11. Phase 0 performed; no new bug filed.
