"""Check native outcomes, exact bindings, runtime constraints, and cleanup."""
from pathlib import Path
import hashlib,json,re,subprocess
ROOT=Path(__file__).resolve().parent
SNAP=Path('/tmp/effort-spec-oracle-review-xk8283ov')
NAMES=['base','reference','warm_200_repeat','warm_500_repeat','warm_429_as_400','warm_body_corrupt','warm_body_empty','cache_bypass','cold_200','cold_body_empty','alternative_error_bypass']
MUTANTS=NAMES[2:-1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((SNAP/'manifest.json').read_text())
assert sha(SNAP/'manifest.json')=='8ad578f9059c7bfc0df2d454fe094ef282e9d6e7afc9b0625454a6cd0c14dbe8'
assert all(sha(SNAP/p)==v['sha256'] and (SNAP/p).stat().st_size==v['bytes'] for p,v in manifest['files'].items())
rows=[]
for name in NAMES:
    d=ROOT/'evidence'/name
    x=json.loads((d/'result.json').read_text());raw=x['raw']
    bind=json.loads((d/'binding.json').read_text())
    assert sha(d/'candidate.patch')==bind['patch_sha256']
    assert all(sha(ROOT/name/p)==h for p,h in bind['source_sha256'].items())
    assert x['source_unchanged'] and x['fresh_container_absent']
    assert raw['container_removed'] and not raw['oom_killed']
    assert x['complete_stream_contract']
    runtime=json.loads((d/'runtime.json').read_text())
    assert [i['stage'] for i in runtime]==['after-start','before-remove']
    for item in runtime:
        assert item['inspect_rc']==0 and item['cgroup_rc']==0 and 'error' not in item
        info=item['inspect'];cfg=info['HostConfig']
        assert info['Image']==manifest['actual_image']
        assert info['Config']['User']=='0:0'
        assert cfg['Init'] and cfg['NetworkMode']=='none'
        assert cfg['NanoCpus']==4_000_000_000 and cfg['Memory']==8*1024**3 and cfg['MemorySwap']==8*1024**3
        assert cfg['CapDrop']==['ALL'] and cfg['PidsLimit']==4096
        assert re.search(r'(?m)^oom_kill 0$',item['cgroup'])
    if name in ('base','reference'):
        observed=json.loads((d/'container-source-sha256.json').read_text());assert observed['returncode']==0
        text=observed['stdout']
    else:
        assert runtime[-1]['source_sha256_rc']==0
        text=runtime[-1]['source_sha256_output']
    actual={line.split()[1].removeprefix('/testbed/'):line.split()[0] for line in text.splitlines()}
    want=dict(bind['source_sha256']);want['rust/src/proxy/forward/effort_status_oracle.rs']=bind['oracle_sha256']
    assert actual==want,(name,actual,want)
    log=Path(raw['log']).read_text()
    native=re.search(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',log)
    statuses=x['statuses'];passed=sum(s=='pass' for s in statuses.values());failed=sum(s=='fail' for s in statuses.values());missing=sum(s is None for s in statuses.values())
    if raw.get('error') or not native or missing or passed+failed!=4:
        classification='invalid'
    else:
        assert [int(native[1]),int(native[2])]==[passed,failed]
        classification=('killed' if failed else 'survived') if name in MUTANTS else 'control'
    p=subprocess.run(['docker','container','inspect',raw['container']],capture_output=True,text=True,timeout=30)
    assert p.returncode!=0 and 'No such container' in p.stderr
    rows.append({'name':name,'classification':classification,'passed':passed,'failed':failed,'missing':missing,'test_returncode':raw['steps'][0]['returncode'],'wall_seconds':raw['wall_seconds'],'patch_sha256':bind['patch_sha256'],'log':raw['log'],'failure_messages':re.findall(r'assertion `left == right` failed: ([^\n]+)',log)})
counts={state:sum(row['classification']==state for row in rows if row['name'] in MUTANTS) for state in ['killed','survived','invalid']}
counts['timeouts']=sum('timeout' in str(json.loads((ROOT/'evidence'/name/'result.json').read_text())['raw'].get('error','')).lower() for name in MUTANTS)
result={'rows':rows,'mutation_counts':counts,'snapshot_verified_files':len(manifest['files']),'runtime_source_cleanup_verified':True,'paid_ready':False,'experimental_model_calls':0,'full_original_population_executed':False}
(ROOT/'summary.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,indent=2))
