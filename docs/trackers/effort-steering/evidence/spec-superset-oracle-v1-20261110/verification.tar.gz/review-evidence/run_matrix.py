from pathlib import Path
import subprocess,concurrent.futures,time,json
ROOT=Path(__file__).resolve().parent
NAMES=['warm_200','warm_500','warm_429_as_400','warm_body_corrupt','warm_body_empty','cache_bypass','cold_200','cold_body_empty','alternative_error_bypass']

def run(name):
    with (ROOT/(name+'-driver.log')).open('w') as log:
        result=subprocess.run(['python3',str(ROOT/'run_review.py'),name],stdout=log,stderr=subprocess.STDOUT,timeout=1200)
    print(json.dumps({'variant':name,'driver_returncode':result.returncode}),flush=True)

while not all((ROOT/'evidence'/name/'result.json').exists() for name in ('base','reference')):
    time.sleep(5)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(run,NAMES))
