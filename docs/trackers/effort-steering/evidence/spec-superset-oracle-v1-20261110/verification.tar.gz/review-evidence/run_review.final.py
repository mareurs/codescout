"""Isolated reviewer harness; source snapshot immutable; each grade uses fresh image layers."""
from pathlib import Path
import sys,json,hashlib,difflib,subprocess,time,uuid

ROOT=Path(__file__).resolve().parent
SNAP=Path('/tmp/effort-spec-oracle-review-xk8283ov')
sys.path.insert(0,str(SNAP/'grader-source'))
import multilang_tasks as tasks
import multilang_grade as grade
import stream_evidence as streams

def sha(data):
    return hashlib.sha256(data).hexdigest()

def put(path,value):
    path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')

def main(name):
    source=ROOT/name
    out=ROOT/'evidence'/name
    out.mkdir(parents=True,exist_ok=False)
    record=json.loads((SNAP/'subject/filtered-record.json').read_text())
    reg=json.loads((SNAP/'subject/registration.json').read_text())
    patch=''
    hashes={}
    for rel in reg['gold_production_paths']:
        before=(SNAP/'public-source'/rel).read_text()
        after=(source/rel).read_text()
        hashes[rel]=sha(after.encode())
        if before!=after:
            patch+='diff --git a/'+rel+' b/'+rel+'\n'
            patch+=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
    (out/'candidate.patch').write_text(patch)
    put(out/'binding.json',{'source_sha256':hashes,'patch_sha256':sha(patch.encode()),'oracle_sha256':sha((SNAP/'subject/effort_status_oracle.rs').read_bytes()),'snapshot_manifest_sha256':sha((SNAP/'manifest.json').read_bytes()),'name':name,'paid_ready':False})
    observations=[]
    docker=tasks.pilot.docker
    def observe(container,stage):
        x={'container':container,'stage':stage,'at':time.time()}
        try:
            p=docker('inspect',container,check=False,timeout=60)
            x['inspect_rc']=p.returncode
            if p.returncode==0:x['inspect']=json.loads(p.stdout)[0]
            p=docker('exec',container,'sh','-c','for f in /sys/fs/cgroup/memory.events /sys/fs/cgroup/memory.max /sys/fs/cgroup/memory.swap.max /sys/fs/cgroup/cpu.max; do printf "%s\\n" "$f"; cat "$f"; done',check=False,timeout=60)
            x.update(cgroup=p.stdout,cgroup_stderr=p.stderr,cgroup_rc=p.returncode)
            if stage=='before-remove':
                p=docker('exec',container,'sha256sum',*[f'/testbed/{rel}' for rel in reg['gold_production_paths']],'/testbed/rust/src/proxy/forward/effort_status_oracle.rs',check=False,timeout=60)
                x.update(source_sha256_output=p.stdout,source_sha256_rc=p.returncode,source_sha256_stderr=p.stderr)
        except Exception as exc:x['error']=repr(exc)
        observations.append(x);put(out/'runtime.json',observations)
    def tracked(*args,**kwargs):
        if args and args[0]=='run':args=('run','--user','0:0','--memory-swap','8g','--init',*args[1:])
        if args and args[0]=='rm':
            for arg in args[1:]:
                if isinstance(arg,str) and arg.startswith(tasks.GRADE_PREFIX):observe(arg,'before-remove')
        result=docker(*args,**kwargs)
        if args and args[0]=='run' and result.returncode==0:observe(args[args.index('--name')+1],'after-start')
        return result
    tasks.pilot.docker=tracked
    tasks.GRADE_PREFIX='sab-grade-oracle-review-'
    tasks.GRADE_STEP_TIMEOUT=900
    bundle={'workdir':'/testbed','expected':{'fail_to_pass':3,'pass_to_pass_kept':1,'dropped':[],'fail_to_pass_dropped':[]}}
    grader=tasks.live_grader(record,bundle,reg['image'],out,capture_streams=True,diagnostic_artifacts={0:['rust/effort-oracle.stderr']})
    raw=grader(patch,name)
    result={'name':name,'raw':raw,'paid_ready':False,'experimental_model_calls':0,'full_population_executed':False}
    logpath=Path(raw.get('log',''))
    if logpath.is_file():
        log=logpath.read_text();full=json.loads(logpath.with_name('grade.json').read_text())
        statuses=grade.run_parser(record['log_parser'],log)
        result['statuses']={key:statuses.get(key) for key in record['FAIL_TO_PASS']+record['PASS_TO_PASS']}
        try:
            result['stream_diagnostics']=streams.qualify(full,record,log,reg['stream_registration'])
            result['complete_stream_contract']=True
        except streams.EvidenceError as exc:
            result['complete_stream_contract']=False;result['stream_error']=str(exc)
    p=subprocess.run(['docker','container','inspect',raw['container']],capture_output=True,text=True,timeout=30)
    result['fresh_container_absent']=p.returncode!=0 and 'No such container' in p.stderr
    result['source_unchanged']=all(sha((source/rel).read_bytes())==h for rel,h in hashes.items())
    put(out/'result.json',result)
    print(json.dumps(result),flush=True)

if __name__=='__main__':main(sys.argv[1])
