from pathlib import Path
import json,hashlib,tempfile,sys,shutil
W=Path("/home/marius/work/claude/codescout/.worktrees/grader-stream-provenance-01a15ca9")
L=W/".superpowers/sdd/2026-11-10-spec-superset-oracle"
P=Path("/home/marius/.cache/codescout-resident/codescout/evidence-cohort-20261110/common-lean-ctx-1168-v1/project")
R=Path(tempfile.mkdtemp(prefix="effort-spec-oracle-review-"))
files={}
def add(name,p):
    p=Path(p);assert not p.is_symlink()
    data=p.read_bytes();dst=R/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)
    files[name]={"sha256":hashlib.sha256(data).hexdigest(),"bytes":len(data)}
for name in ["effort_status_oracle.rs","qualify_spec_oracle.py","verify_task1.py","registration.json","filtered-record.json","supplement.patch","progress.md","task1-verification.json","task-1-brief.md","task-2-brief.md"]:
    add("subject/"+name,L/name)
for role in ["base","reference"]:
    for p in (L/role).rglob("*"):
        if p.is_file():add("controls/"+role+"/"+str(p.relative_to(L/role)),p)
for p in (W/"tools/setup-ab-eval").iterdir():
    if p.is_file() and p.suffix in [".py",".sh"]:add("grader-source/"+p.name,p)
sys.path.insert(0,str(W/"tools/setup-ab-eval"))
import tasks
record=json.loads((L/"filtered-record.json").read_text())
for rel in sorted(set(tasks.patch_files(record["patch"]))|{"rust/src/proxy/forward/tests.rs"}):
    add("public-source/"+rel,P/rel)
add("plan.md","/home/marius/work/claude/codescout/docs/trackers/effort-steering/plans/2026-11-10-spec-superset-oracle.md")
package={"scope":"new private functional oracle/control only; original14graderWIP unchanged dependency, no Git-range claim",
         "base_head":"f586d35f4b0d41768931648dd1a9a33f1cdd450f","files":files,
         "image":record["docker_image"],"actual_image":"sha256:b72f902d24c0a54516e4ef242d8218805f0ea3dc1d26ac809140979ba1f51d56",
         "review_root":str(R),"paid_ready":False}
(R/"manifest.json").write_text(json.dumps(package,indent=2,sort_keys=True)+"\n")
(L/"review-input.json").write_text(json.dumps({"root":str(R),"manifest_sha256":hashlib.sha256((R/"manifest.json").read_bytes()).hexdigest()},indent=2)+"\n")
print(json.dumps({"root":str(R),"members":len(files),"manifest_sha256":hashlib.sha256((R/"manifest.json").read_bytes()).hexdigest()},indent=2))
