"""Verify real persisted controls and their source/runtime binding; no paid readiness."""
from pathlib import Path
import json,hashlib,re,subprocess
L=Path(__file__).resolve().parent
W=L.parents[2]
reg=json.loads((L/"registration.json").read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(W/p)==h for p,h in reg["source_sha256"].items())
assert sha(L/"effort_status_oracle.rs")==reg["oracle_sha256"]
assert sha(L/"qualify_spec_oracle.py")==reg["helper_sha256"]
assert not set(reg["supplement_paths"])&set(reg["gold_production_paths"])
prefix="proxy::forward::tests::effort_status_oracle::"
want={prefix+"status_200_preserves_body_and_cache":"pass",
      prefix+"status_400_survives_repeated_request":"fail",
      prefix+"status_429_survives_repeated_request":"fail",
      prefix+"status_500_survives_repeated_request":"fail"}
verified={}
for role in ("base","reference"):
    r=json.loads((L/role/"result.json").read_text());raw=r["raw"]
    expected=want if role=="base" else {k:"pass" for k in want}
    assert r["statuses"]==expected
    assert r["complete_stream_contract"] is True and r["source_unchanged"] is True
    assert r["fresh_container_absent"] is True
    assert raw.get("error") is None and raw.get("infra") is None
    assert raw["expected"]==4 and raw["missing"]==0
    assert raw["not_passing"]==(3 if role=="base" else 0)
    assert raw["pass"] is (role=="reference")
    assert raw["oom_killed"] is False and raw["container_removed"] is True
    runtime=json.loads((L/role/"runtime.json").read_text())
    assert [x["stage"] for x in runtime]==["after-start","before-remove"]
    for x in runtime:
        assert x["inspect_rc"]==0 and x["cgroup_rc"]==0 and "error" not in x
        inspect=x["inspect"];host=inspect["HostConfig"]
        assert inspect["Config"]["Image"]==reg["image"]
        assert inspect["Config"]["User"]=="0:0"
        assert host["Init"] is True and host["NetworkMode"]=="none"
        assert host["NanoCpus"]==4_000_000_000
        assert host["Memory"]==8*1024**3 and host["MemorySwap"]==8*1024**3
        assert host["PidsLimit"]==4096 and host["CapDrop"]==["ALL"]
        assert re.search(r"(?m)^oom_kill 0$",x["cgroup"])
    assert runtime[-1]["inspect"]["State"]["OOMKilled"] is False
    if role=="base":
        log=Path(raw["log"]).read_text()
        for status in (400,429,500):
            assert f"status must survive request 1 for status {status}" in log
            assert f"right: {status}" in log
    p=subprocess.run(["docker","container","inspect",raw["container"]],capture_output=True,text=True,timeout=30)
    assert p.returncode!=0 and "No such container" in p.stderr
    verified[role]={"statuses":r["statuses"],"wall_seconds":raw["wall_seconds"],
                    "runtime_limits_init_and_cleanup_verified":True,"complete_stream_contract":True}
result={"task1_verified":True,"controls":verified,"source_unchanged":True,
        "original_full_expected_population_executed":False,"host_resource_floor_qualified":False,
        "experimental_model_calls":0,"paid_ready":False}
(L/"task1-verification.json").write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
print(json.dumps(result,indent=2))
