"""Filtered behavioral oracle controls only; full old population remains prerequisite."""
from pathlib import Path
import sys,json,hashlib,difflib,time,subprocess
W=Path("/home/marius/work/claude/codescout/.worktrees/grader-stream-provenance-01a15ca9")
L=W/".superpowers/sdd/2026-11-10-spec-superset-oracle"
M=Path("/home/marius/work/claude/codescout")
D=M/"docs/trackers/effort-steering/evidence/spec-superset-oracle-v1-20261110"
P=Path("/home/marius/.cache/codescout-resident/codescout/evidence-cohort-20261110/common-lean-ctx-1168-v1/project")
DATA=Path("/home/marius/work/claude/setup-ab-data/live/multilang-rust.jsonl")
IMAGE="sha256:b72f902d24c0a54516e4ef242d8218805f0ea3dc1d26ac809140979ba1f51d56"
sys.path.insert(0,str(W/"tools/setup-ab-eval"))
import multilang_tasks as tasks,multilang_grade as grade
import stream_evidence as streams
TID="yvgude__lean-ctx-1168"
PREFIX="proxy::forward::tests::effort_status_oracle::"
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,value):p.write_text(json.dumps(value,indent=2,sort_keys=True)+"\n")
def source_hashes():return {str(p.relative_to(W)):sha(p.read_bytes()) for p in (W/"tools/setup-ab-eval").glob("*.py")}
def record():
    assert sha(DATA.read_bytes())=="bf2dd8252a07d0f275663ef8f6ab87571dd9bc4ce386abf9ec98d3cd6bb51a81"
    return next(r for line in DATA.open() if (r:=json.loads(line)).get("instance_id")==TID)
def register():
    assert not D.exists();D.mkdir()
    original=record()
    path="rust/src/proxy/forward/tests.rs"
    newpath="rust/src/proxy/forward/effort_status_oracle.rs"
    before=(P/path).read_text()
    oracle=(L/"effort_status_oracle.rs").read_text()
    appended=before+"\ninclude!(\"effort_status_oracle.rs\");\n"
    supplement=("diff --git a/"+path+" b/"+path+"\n"+
                "".join(difflib.unified_diff(before.splitlines(True),appended.splitlines(True),
                                            fromfile="a/"+path,tofile="b/"+path))+
                "diff --git a/"+newpath+" b/"+newpath+"\nnew file mode 100644\n"+
                "".join(difflib.unified_diff([],oracle.splitlines(True),fromfile="/dev/null",tofile="b/"+newpath)))
    extra=tasks.tasks.patch_files(supplement)
    assert set(extra)=={path,newpath}
    assert not set(extra)&set(tasks.tasks.patch_files(original["patch"]))
    (L/"supplement.patch").write_text(supplement)
    derived=dict(original)
    derived["test_patch"]=original["test_patch"]+"\n"+supplement
    derived["rebuild_cmds"]=[]
    derived["test_cmds"]=["cd /testbed/rust && LEAN_CTX_EMBEDDINGS_AUTO_DOWNLOAD=0 cargo test --offline --locked --lib effort_status_oracle -- --test-threads=1 > effort-oracle.log 2> effort-oracle.stderr"]
    derived["print_cmds"]=["cat /testbed/rust/effort-oracle.log"]
    derived["FAIL_TO_PASS"]=[PREFIX+"status_"+str(s)+"_survives_repeated_request" for s in (400,429,500)]
    derived["PASS_TO_PASS"]=[PREFIX+"status_200_preserves_body_and_cache"]
    put(L/"filtered-record.json",derived)
    reg={"schema":1,"task":TID,"scope":"filtered new behavioral checks only, not full prospective admission",
         "acceptance_version_proposed":"original-selected-population AND specification-oracle",
         "old_admission_unchanged":True,"original_dataset_sha256":sha(DATA.read_bytes()),
         "original_record_canonical_sha256":sha(json.dumps(original,sort_keys=True).encode()),
         "original_expected_sha256":sha(json.dumps([original["FAIL_TO_PASS"],original["PASS_TO_PASS"]],sort_keys=True).encode()),
         "filtered_record_sha256":sha((L/"filtered-record.json").read_bytes()),
         "source_sha256":source_hashes(),"oracle_sha256":sha(oracle.encode()),
         "helper_sha256":sha(Path(__file__).read_bytes()),"supplement_sha256":sha(supplement.encode()),
         "supplement_paths":extra,"gold_production_paths":tasks.tasks.patch_files(original["patch"]),
         "controls":["base","reference"],"image":IMAGE,"step_timeout_s":900,
         "runtime":{"user":"0:0","network":"none","cpus":4,"memory":"8g","memory_swap":"8g","init":True},
         "expected_new_f2p":derived["FAIL_TO_PASS"],"expected_new_p2p":derived["PASS_TO_PASS"],
         "stream_registration":{"version":streams.VERSION,"commands_sha256":streams.commands_digest(derived),
                                "tests":[{"profile":streams.LIB,"reports":[0],"stderr_files":["rust/effort-oracle.stderr"]}]},
         "experimental_model_calls":0,"original_full_expected_population_executed":False,
         "paid_ready":False,"error_cache_bypass_allowed":True,
         "decision":"base must fail runtime status assertions, reference all4pass; setup/compile failure invalid; no filtered result grants full population or model admission"}
    put(D/"registration.json",reg);put(L/"registration.json",reg)
    print(json.dumps({"registration":str(D/"registration.json"),"extra_paths":extra,"paid_ready":False}))
def run(role):
    reg=json.loads((D/"registration.json").read_text());assert role in reg["controls"]
    assert source_hashes()==reg["source_sha256"]
    assert sha(Path(__file__).read_bytes())==reg["helper_sha256"]
    assert sha((L/"effort_status_oracle.rs").read_bytes())==reg["oracle_sha256"]
    assert sha((L/"filtered-record.json").read_bytes())==reg["filtered_record_sha256"]
    r=json.loads((L/"filtered-record.json").read_text())
    out=L/role;out.mkdir(exist_ok=False)
    observations=[]
    docker=tasks.pilot.docker
    def observe(name,stage):
        item={"container":name,"stage":stage,"at":time.time()}
        try:
            p=docker("inspect",name,check=False,timeout=120)
            item["inspect_rc"]=p.returncode
            if p.returncode==0:item["inspect"]=json.loads(p.stdout)[0]
            p=docker("exec",name,"sh","-c","for f in /sys/fs/cgroup/memory.events /sys/fs/cgroup/memory.max /sys/fs/cgroup/memory.swap.max /sys/fs/cgroup/cpu.max; do printf '%s\\n' \"$f\"; cat \"$f\"; done",check=False,timeout=120)
            item["cgroup_rc"]=p.returncode;item["cgroup"]=p.stdout;item["cgroup_stderr"]=p.stderr
        except Exception as e:item["error"]=repr(e)
        observations.append(item);put(out/"runtime.json",observations)
    def tracked(*args,**kwargs):
        if args and args[0]=="run":
            args=("run","--user","0:0","--memory-swap","8g","--init",*args[1:])
        if args and args[0]=="rm":
            for a in args[1:]:
                if isinstance(a,str) and a.startswith(tasks.GRADE_PREFIX):observe(a,"before-remove")
        result=docker(*args,**kwargs)
        if args and args[0]=="run" and result.returncode==0:observe(args[args.index("--name")+1],"after-start")
        return result
    tasks.pilot.docker=tracked
    tasks.GRADE_STEP_TIMEOUT=reg["step_timeout_s"]
    bundle={"workdir":"/testbed","expected":{"fail_to_pass":3,"pass_to_pass_kept":1,"dropped":[],"fail_to_pass_dropped":[]}}
    grader=tasks.live_grader(r,bundle,IMAGE,out,capture_streams=True,diagnostic_artifacts={0:["rust/effort-oracle.stderr"]})
    raw=grader("" if role=="base" else r["patch"],role)
    result={"role":role,"raw":raw,"paid_ready":False,"original_full_expected_population_executed":False}
    p=Path(raw.get("log",""))
    if p.is_file():
        log=p.read_text();full=json.loads(p.with_name("grade.json").read_text())
        statuses=grade.run_parser(r["log_parser"],log)
        result["statuses"]={k:statuses.get(k) for k in r["FAIL_TO_PASS"]+r["PASS_TO_PASS"]}
        try:
            diagnostics=streams.qualify(full,r,log,reg["stream_registration"])
            result["complete_stream_contract"]=True
            result["diagnostics"]=diagnostics
        except streams.EvidenceError as e:
            result["complete_stream_contract"]=False;result["stream_error"]=str(e)
    p=subprocess.run(["docker","container","inspect",raw["container"]],capture_output=True,text=True,timeout=30)
    result["fresh_container_absent"]=p.returncode!=0 and "No such container" in p.stderr
    result["source_unchanged"]=source_hashes()==reg["source_sha256"]
    put(out/"result.json",result)
    print(json.dumps(result,indent=2))
if __name__=="__main__":
    if sys.argv[1]=="register":register()
    else:run(sys.argv[1])
