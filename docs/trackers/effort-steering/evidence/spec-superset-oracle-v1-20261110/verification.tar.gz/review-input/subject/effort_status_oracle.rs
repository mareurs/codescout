// Evaluation-only public-specification oracle; never installed in actor source.
// Breaks pinned: warm errors forced to200, other wrong status, corrupted body,
// and removing caching globally. Error responses may remain uncached.
mod effort_status_oracle {
    use axum::{body::{Body, to_bytes}, extract::State, http::{Request, StatusCode}, routing::post, Router};
    use std::{ffi::OsString, sync::{Arc, atomic::{AtomicUsize, Ordering}}, time::Duration};
    use crate::{core::ocla::response_cache::ResponseCache, proxy::{ProxyState, Upstreams, ProxyStats}};

    struct RestoreDataDir(Option<OsString>);
    impl Drop for RestoreDataDir {
        fn drop(&mut self) {
            match self.0.take() {
                Some(value) => crate::test_env::set_var("LEAN_CTX_DATA_DIR", value),
                None => crate::test_env::remove_var("LEAN_CTX_DATA_DIR"),
            }
        }
    }

    async fn run_case(expected: u16) {
        let _lock = crate::core::data_dir::test_env_lock();
        let dir = tempfile::tempdir().unwrap();
        let _restore = RestoreDataDir(std::env::var_os("LEAN_CTX_DATA_DIR"));
        crate::test_env::set_var("LEAN_CTX_DATA_DIR", dir.path());

        let calls = Arc::new(AtomicUsize::new(0));
        let counter = calls.clone();
        let literal_body = format!("{{\"oracle_marker\":\"upstream-status-{expected}\"}}");
        let reply = literal_body.clone();
        let status = StatusCode::from_u16(expected).unwrap();
        let app = Router::new().route("/v1/chat/completions", post(move || {
            let counter = counter.clone();
            let reply = reply.clone();
            async move {
                counter.fetch_add(1, Ordering::SeqCst);
                (status, [(axum::http::header::CONTENT_TYPE, "application/json")], reply)
            }
        }));
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let upstream = format!("http://{}", listener.local_addr().unwrap());
        let server = tokio::spawn(async move { axum::serve(listener, app).await.unwrap(); });
        let (_sender, upstreams) = tokio::sync::watch::channel(Arc::new(Upstreams {
            anthropic: upstream.clone(),
            openai: upstream.clone(),
            chatgpt: upstream.clone(),
            gemini: upstream.clone(),
            providers: Vec::new(),
        }));
        let state = ProxyState {
            client: reqwest::Client::builder().no_proxy().timeout(Duration::from_secs(2)).build().unwrap(),
            port: 0,
            stats: Arc::new(ProxyStats::default()),
            introspect: Arc::new(crate::proxy::introspect::IntrospectState::default()),
            ocla_cache: Some(Arc::new(crate::proxy::ocla_cache_bridge::OclaCacheBridge::new(
                Arc::new(ResponseCache::new(8, Duration::from_secs(60)))
            ))),
            upstreams,
            chatgpt_cookies: crate::proxy::chatgpt_cookies::shared_chatgpt_cloudflare_cookie_store(),
            mcp_servers: Arc::new(Vec::new()),
        };
        let payload = serde_json::to_vec(&serde_json::json!({
            "model": format!("spec-oracle-{expected}"),
            "messages": [{"role":"user", "content":"status-preservation sentinel"}],
            "stream": false,
        })).unwrap();
        for request_index in 0..2 {
            let req = Request::builder().method("POST").uri("/v1/chat/completions")
                .header(axum::http::header::CONTENT_TYPE, "application/json")
                .body(Body::from(payload.clone())).unwrap();
            let response = crate::proxy::forward::forward_request(
                State(state.clone()), req, &upstream, "/v1/chat/completions",
                |value, original| (serde_json::to_vec(&value).unwrap(), original, original),
                "OpenAI", &[],
            ).await.expect("local upstream request must produce a response");
            let got_status = response.status().as_u16();
            let body = to_bytes(response.into_body(), 1024 * 1024).await.unwrap();
            assert_eq!(body.as_ref(), literal_body.as_bytes(),
                       "body must survive request {request_index} for status {expected}");
            assert_eq!(got_status, expected,
                       "status must survive request {request_index} for status {expected}");
        }
        if expected == 200 {
            assert_eq!(calls.load(Ordering::SeqCst), 1,
                       "two identical successful requests must retain cache behavior");
        }
        server.abort();
    }

    #[tokio::test(flavor = "current_thread")]
    async fn status_200_preserves_body_and_cache() { run_case(200).await; }

    #[tokio::test(flavor = "current_thread")]
    async fn status_400_survives_repeated_request() { run_case(400).await; }

    #[tokio::test(flavor = "current_thread")]
    async fn status_429_survives_repeated_request() { run_case(429).await; }

    #[tokio::test(flavor = "current_thread")]
    async fn status_500_survives_repeated_request() { run_case(500).await; }
}
