### Task 1: Real private behavioral RED/GREEN

**Files:** plan-owned ledger and effort_status_oracle.rs; host qualify_spec_oracle.py helper; private generated test patch, no edits to actor source or production grader.
**Interfaces:** Oracle run_case(expected:u16) performs2actual forward_request calls and returns after literal assertions; host register/run modes freeze oracle/helper/source/image hashes before controls.

- [ ] Record isolated grader HEAD and existing source hashes; initialize plan ledger and brief.
- [ ] Write200positive cache and400/429/500 status/body tests first; static fake-upstream interface, fresh data directory and environment restoration.
- [ ] Generate supplemental test-only patch and assert no overlap with the original gold production paths.
- [ ] Preregister filtered base/reference controls; run same oracle on fresh base, then fresh reference with complete capture, real inspections/cgroups and cleanup.
- [ ] Observe baseline runtime status assertion failures and reference4/4pass; any compile/setup error is invalid setup and must be fixed without task-production changes. Preserve every attempt.

