### Task 2: Integrity and semantic review

**Files:** immutable reviewed oracle/control source snapshot, applied mutation copies, final report/checkpoint.
**Interfaces:** review input contains public issue, oracle/control/registration and observed RED/GREEN, no model results.

- [ ] One fresh strongest reviewer applies at least8 meaningful cache/status/body/control mutations and runs the actual relevant tests, reporting observed killed/survived/invalid counts.
- [ ] Read surviving actual diffs and logs before one bounded correction pass; replay exact mutants after any correction. Record declined scopes and minors.
- [ ] Preserve checked source/patch/complete controls and mutation evidence. No new root gate needed for unchanged product source; disclose prior gate scope and perform native oracle verification required here.
- [ ] Bind a new diagnostic checkpoint with paid_readyfalse. Full old-population reference/repeat, unresolved Obscura service/runtime, F6, all-arm/context/controller/accounting remain admission prerequisites.

## Self-review and rulings

Current public forward_request signature and ProxyState/cache constructors were read. The gold production paths include forward/mod.rs, so appending its module declaration there would be erased by RESTORE_SH; test-only forward/tests.rs avoids that seam. Config/data environment restoration and actual upstream observations are part of Task1. The superset is a controller choice under standing delegation, not user-specified oracle details. If wrong, cost is a rejected/new diagnostic contract, never a relabelled original score or paid launch.
