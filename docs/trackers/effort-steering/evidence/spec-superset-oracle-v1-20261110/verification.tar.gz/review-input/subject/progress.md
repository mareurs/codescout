# SDD ledger — plan: /home/marius/work/claude/codescout/docs/trackers/effort-steering/plans/2026-11-10-spec-superset-oracle.md

Task 1 active. BASE f586d35f4b0d41768931648dd1a9a33f1cdd450f. Existing14-file grader WIP preserved; source SHA map is the closed fixed-oracle-diagnostic-v2 registration. No production edit or commit.

Pre-flight: Task1 produces oracle/registration/real RED-GREEN; Task2 consumes exact frozen bytes. No interface conflict. Ruling: standing autonomous delegation covers the private validation superset; original expected arrays/dataset and failed admission remain immutable. Additional spec checks are a new prospective contract, never an old score rewrite. If wrong, no paid launch; retain diagnostic failure.

Ruling: supplemental source paths are test-only forward/tests.rs and new effort_status_oracle.rs, disjoint from gold production paths. Editing forward/mod.rs would be erased by live_grader's restore ordering. New oracle cannot be copied into actor source/memories/prompts.

Ruling: error caching is not mandated; correct fixes may bypass error cache. The200positive probe demands continued cache behavior. No global cache disable can pass allprobes. Literal status/body expectations come from the public issue and fixed fixtures.

## Task 1 genuine runtime RED — 2026-11-10

Base completed133.1s, compile2m00s, no setup/compile error,0missing. New200body/cachepositive passes;400/429/500 each fail on request_index1 because gotstatus200 rather than literal expected. Same test-only supplement applies without gold-source overlap. Complete stream contract passes; no actor/modelcalls. Alloriginalgrader production hashes unchanged. Reference control now launched against the same pinned oracle/helper/image/runtime; do not edit those bytes while running. No full-old-population or paid admission from filtered4tests.
Task 1: complete (commits f586d35..f586d35, tests: python3 .superpowers/sdd/2026-11-10-spec-superset-oracle/verify_task1.py → })
