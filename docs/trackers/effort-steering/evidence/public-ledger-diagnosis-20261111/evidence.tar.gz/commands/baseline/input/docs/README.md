# Repository docs

This folder contains **developer-facing** docs for the `lean-ctx` repository.

End-user documentation lives at **https://leanctx.com/docs/getting-started**.

## Start here

- Project overview: [`README.md`](../README.md)
- Contributing: [`CONTRIBUTING.md`](../CONTRIBUTING.md)
- Security: [`SECURITY.md`](../SECURITY.md)
- Architecture: [`ARCHITECTURE.md`](../ARCHITECTURE.md)
- Benchmarks: [`BENCHMARKS.md`](../BENCHMARKS.md)

## Codebase entry points

- Core binary + MCP server: [`rust/`](../rust/)
- Cookbook (real examples + `lean-ctx-client`): [`cookbook/`](../cookbook/)
- Editor integrations: [`packages/`](../packages/)

## Reference & journeys

- Full function-by-function reference (organized as user journeys): [`reference/README.md`](reference/README.md)
- **User journeys (website narrative)** — the governed, scalable context runtime wave (MCP Gateway, Context Firewall, Sensitivity Floor, Reproducible Scorecard): [`user-journeys.md`](user-journeys.md)
- Always-current, generated appendices: [MCP tools](reference/generated/mcp-tools.md) · [config keys](reference/generated/config-keys.md)

## Guides

- Monorepo usage: [`guides/monorepo.md`](guides/monorepo.md)
- Publishing context packages to ctxpkg.com (sign, publish, install,
  lockfile): [`guides/publishing-packages.md`](guides/publishing-packages.md)

## Compliance

- Context Governance Benchmark (CGB) self-assessment — honest grading incl.
  declared gaps: [`compliance/cgb-self-assessment.md`](compliance/cgb-self-assessment.md)

## Design notes / tickets

- Cache correctness + heatmap plan: [`premium-cache-heatmap.md`](premium-cache-heatmap.md)
