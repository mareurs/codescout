"""Bounded public-suite processes; logs live outside the read-only source."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time


def main():
    order = sys.argv[1].split(',')
    assert order.count('default') == 3 and order.count('serial') == 2
    out = Path('/build/ledger-diagnostic-results')
    out.mkdir(exist_ok=False)
    base = ['cargo', 'test', '--offline', '--manifest-path', 'rust/Cargo.toml', '--lib', 'ocla']
    results = []
    for index, mode in enumerate(order):
        argv = base + (['--', '--test-threads=1'] if mode == 'serial' else [])
        stdout, stderr = out / f'{index}-{mode}.stdout', out / f'{index}-{mode}.stderr'
        start = time.monotonic()
        with stdout.open('xb') as so, stderr.open('xb') as se:
            process = subprocess.run(argv, stdout=so, stderr=se, timeout=600)
        text = stdout.read_text()
        summaries = re.findall(r'^test result: (.+)$', text, re.MULTILINE)
        statuses = re.findall(r'^test (.+?) \.\.\. (ok|FAILED|ignored)$', text, re.MULTILINE)
        assert len(summaries) == 1 and len(statuses) == len(dict(statuses))
        count = re.fullmatch(r'(?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; '
            r'(\d+) measured; (\d+) filtered out; finished in .+', summaries[0])
        assert count is not None
        passed, failed, ignored, measured, filtered = map(int, count.groups())
        assert measured == 0
        assert passed == sum(s == 'ok' for _, s in statuses)
        assert failed == sum(s == 'FAILED' for _, s in statuses)
        assert ignored == sum(s == 'ignored' for _, s in statuses)
        assert process.returncode in (0, 101)
        assert (process.returncode == 0) == (failed == 0)
        row = {'index': index, 'mode': mode, 'argv': argv, 'returncode': process.returncode,
            'wall_s': time.monotonic() - start, 'summary': summaries[0],
            'parsed_status_count': len(statuses), 'passed': passed, 'failed': failed,
            'ignored': ignored, 'filtered': filtered,
            'failed_tests': [name for name, status in statuses if status == 'FAILED'],
            'stdout_sha256': hashlib.sha256(stdout.read_bytes()).hexdigest(),
            'stderr_sha256': hashlib.sha256(stderr.read_bytes()).hexdigest()}
        results.append(row)
        print(json.dumps(row), flush=True)
    (out / 'results.json').write_text(json.dumps({'processes': results}, indent=2) + '\n')


if __name__ == '__main__':
    main()
