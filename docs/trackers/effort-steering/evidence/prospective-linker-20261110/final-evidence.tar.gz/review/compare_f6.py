from pathlib import Path
import sys,json,importlib.util,ast,hashlib
r=Path(__file__).resolve().parent
sys.path.insert(0,str(r/'tools/setup-ab-eval'))
import test_stream_policy as t
import grade_policy as current
spec=importlib.util.spec_from_file_location("pref6",r/'pre-f6/tools/setup-ab-eval/grade_policy.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
legacy={}
for name in ["scoped_lines","compiler_diagnostic","adjudicate_private"]:
    bodies=[]
    for folder in ["pre-f6/",""]:
        text=(r/(folder+"tools/setup-ab-eval/grade_policy.py")).read_text()
        node=next(x for x in ast.parse(text).body if isinstance(x,ast.FunctionDef) and x.name==name)
        bodies.append(ast.get_source_segment(text,node))
    legacy[name]=bodies[0]==bodies[1]
changed=[]
for p in (r/'pre-f6/tools/setup-ab-eval').rglob('*'):
    if p.is_file():
        rel=p.relative_to(r/'pre-f6')
        if p.read_bytes()!=(r/rel).read_bytes():changed.append(str(rel))
outputs=[]
for mode in ["test","rebuild"]:
    for sep in ["\x0b","\x0c","\x85","\u2028","\u2029"]:
        text="7 | example"+sep+"error: linking with `cc` failed: exit status: 1\n"
        record=dict(t.RECORD,log_parser=t.JSON_PARSER,FAIL_TO_PASS=[t.SELECTED],PASS_TO_PASS=[],rebuild_cmds=["cargo build"] if mode=="rebuild" else [])
        steps=([t.step("grade:rebuild",err=text,code=101),t.step("grade:test[0]")] if mode=="rebuild" else [t.step("grade:test[0]",err=text,code=101)])+[t.step("grade:print[0]")]
        raw,full=t.prepared(record,"",{"steps":steps})
        entry={"mode":mode,"separator":repr(sep),"text":text,"utf8_hex":text.encode().hex()}
        for name,policy in [("pre_f6",old),("current",current)]:
            entry[name]=policy.adjudicate_streams(raw,full,record,t.BUNDLE,log="",runtime=t.OK,registered=t.contract(record))
        outputs.append(entry)
result={"changed_source_files":changed,"legacy_ast_source_equal":legacy,"cases":outputs}
(r/'baseline-comparison.json').write_text(json.dumps(result,indent=2))
print(json.dumps({"changed_source_files":changed,"legacy_ast_source_equal":legacy,"cases":[{"mode":v["mode"],"separator":v["separator"],"pre_f6":v["pre_f6"]["kind"],"current":v["current"]["kind"]} for v in outputs]},indent=2))
