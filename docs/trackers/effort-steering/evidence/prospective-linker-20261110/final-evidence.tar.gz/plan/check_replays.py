"""Check exact replay deltas and observed targeted failures, not generic nonzero exits."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import tarfile
root = Path.cwd()
out = root / ".superpowers/sdd/2026-11-10-prospective-linker-classification"
rows = []
for identity, old, new, method, job in (
    ("M06-status-127", "int(match.group(2)) < 128", "int(match.group(2)) < 127",
     "test_f6_linker_exit_boundary_accepts_127_and_refuses_128", "bg_00000122"),
    ("M07-command-blank", "and match.group(1).strip() ", "",
     "test_f6_whitespace_only_linker_command_is_not_affirmative_evidence", "bg_00000123")):
    case = out / "mutation-replays" / identity
    before = json.loads((case / "before.json").read_text())
    original = (root / "tools/setup-ab-eval/grade_policy.py").read_text()
    assert original.count(old) == 1
    expected = original.replace(old, new)
    actual = (case / "tools/setup-ab-eval/grade_policy.py").read_text()
    assert actual == expected
    for name, digest in before.items():
        if name != "tools/setup-ab-eval/grade_policy.py":
            assert hashlib.sha256((case / name).read_bytes()).hexdigest() == digest
    (case / "mutation.diff").write_text("".join(difflib.unified_diff(
        original.splitlines(True), actual.splitlines(True),fromfile="final/grade_policy.py",tofile=identity+"/grade_policy.py")))
    record_path = Path("/tmp/codescout-bg/532382-bfc3fc33-" + job + ".json")
    record = json.loads(record_path.read_text())
    assert record["state"] == "exited" and record["exit_code"] == 1, record
    text = (case / "replay-tests.log").read_text()
    failures = re.findall(r"^FAIL: (\w+)", text, re.M)
    assert failures and set(failures) == {method}, failures
    assert "Ran 73 tests" in text and not re.search(r"^ERROR:", text, re.M)
    row = {"id":identity,"exact_mutation_verified":True,"test_count":73,"targeted_failures":len(failures),
           "exit_code":1,"verdict":"killed","targeted_method":method}
    (case / "job-record.json").write_text(json.dumps(record,indent=2))
    (case / "replay-result.json").write_text(json.dumps(row,indent=2))
    rows.append(row)
with (out / "survivor-replays.json").open("x") as stream:
    json.dump({"counts":{"killed":2,"survived":0,"invalid":0,"timeout":0},"results":rows},stream,indent=2)
print(json.dumps(rows,indent=2))
