"""Preserve final F6 source, controls, review and observed corrections without publishing."""
from pathlib import Path
import ast
import difflib
import hashlib
import io
import json
import stat
import subprocess
import sys
import tarfile

ROOT = Path.cwd()
WORK = ROOT / ".superpowers/sdd/2026-11-10-prospective-linker-classification"
DEST = Path("/home/marius/work/claude/codescout/docs/trackers/effort-steering/evidence/prospective-linker-20261110")

def sha(data):
    return hashlib.sha256(data).hexdigest()

def segment(source, name):
    node = next(n for n in ast.parse(source).body
                if isinstance(n, ast.FunctionDef) and n.name == name)
    return ast.get_source_segment(source, node)

def main():
    report = Path(sys.argv[1]).resolve(strict=True)
    review = report.parent
    assert str(review).startswith("/tmp/prospective-linker-review-20261110-")
    assert report.is_file()
    with tarfile.open(WORK / "baseline.tar.gz", "r:gz") as old:
        baseline = json.load(old.extractfile("manifest.json"))
        names = sorted(baseline["files"])
        assert len(names) == 99
        current = {name: (ROOT / name).read_bytes() for name in names}
        changed = [name for name in names if sha(current[name]) != baseline["files"][name]["sha256"]]
        assert changed == ["tools/setup-ab-eval/grade_policy.py", "tools/setup-ab-eval/test_stream_policy.py"]
        original = old.extractfile("tools/setup-ab-eval/grade_policy.py").read().decode()
        final = current["tools/setup-ab-eval/grade_policy.py"].decode()
        legacy = {name: segment(original, name) == segment(final, name)
                  for name in ("compiler_diagnostic", "adjudicate_private", "scoped_lines")}
        assert all(legacy.values())
        delta = "".join(line for name in changed for line in difflib.unified_diff(
            old.extractfile(name).read().decode().splitlines(True),
            current[name].decode().splitlines(True),
            fromfile="baseline/" + name, tofile="final/" + name)).encode()
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    assert head == baseline["head"]
    with (WORK / "final-f6.diff").open("xb") as stream:
        stream.write(delta)
    files = {"source/" + name: ROOT / name for name in names}
    for prefix, root in (("plan", WORK), ("review", review)):
        for path in sorted(root.rglob("*")):
            if "__pycache__" in path.parts or path.suffix == ".pyc":
                continue
            assert not path.is_symlink(), str(path)
            if path.is_file():
                files[prefix + "/" + path.relative_to(root).as_posix()] = path
    inventory = {name: {"sha256": sha(path.read_bytes()), "size": path.stat().st_size,
                        "mode": stat.S_IMODE(path.stat().st_mode)}
                 for name, path in sorted(files.items())}
    manifest = {"version": 1, "head": head, "source_files": names, "changed_paths": changed,
                "legacy_functions_source_byte_equal": legacy, "files": inventory,
                "review_report": "review/" + report.name, "paid_ready": False,
                "scope": "model-free prospective linker qualification; no efficacy or paid admission"}
    DEST.mkdir(parents=True, exist_ok=False)
    archive = DEST / "final-evidence.tar.gz"
    with tarfile.open(archive, "x:gz") as package:
        for name, path in sorted(files.items()):
            content = path.read_bytes()
            assert sha(content) == inventory[name]["sha256"]
            info = tarfile.TarInfo(name)
            info.size = len(content)
            info.mode = inventory[name]["mode"]
            package.addfile(info, io.BytesIO(content))
        content = json.dumps(manifest, indent=2, sort_keys=True).encode()
        info = tarfile.TarInfo("manifest.json")
        info.size = len(content)
        package.addfile(info, io.BytesIO(content))
    with tarfile.open(archive, "r:gz") as package:
        members = package.getmembers()
        assert len(members) == len(files) + 1
        assert len({m.name for m in members}) == len(members)
        assert all(m.isfile() for m in members)
        assert json.load(package.extractfile("manifest.json")) == manifest
        for name, path in sorted(files.items()):
            content = package.extractfile(name).read()
            assert sha(content) == inventory[name]["sha256"]
            assert len(content) == inventory[name]["size"]
            assert sha(path.read_bytes()) == inventory[name]["sha256"]
    receipt = {"archive": str(archive), "sha256": sha(archive.read_bytes()),
               "archive_bytes": archive.stat().st_size, "regular_payloads": len(files),
               "all_members_reopened": True, "all_current_payloads_byte_equal": True,
               "source_files": len(names), "changed_paths": changed,
               "legacy_functions_source_byte_equal": legacy, "paid_ready": False}
    with (DEST / "closure.json").open("x") as stream:
        json.dump(receipt, stream, indent=2)
    print(json.dumps(receipt, indent=2))

if __name__ == "__main__":
    main()
