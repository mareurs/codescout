"""Preserve terminal producer records for direct, already retained logs."""
from pathlib import Path
import json
import shutil
root = Path.cwd() / ".superpowers/sdd/2026-11-10-prospective-linker-classification"
destination = root / "job-records"
destination.mkdir(exist_ok=False)
for suffix in ("115","116","117","118","119","11a","11b","120","121","122","123"):
    name = "bg_" + suffix.zfill(8)
    source = Path("/tmp/codescout-bg/532382-bfc3fc33-" + name + ".json")
    record = json.loads(source.read_text())
    assert record["state"] == "exited", record
    assert record["exit_code"] == (1 if suffix in ("122","123") else 0), record
    shutil.copy2(source,destination / (name + ".json"))
print(json.dumps({"terminal_records_preserved":11,"mutation_exit1_expected":2}))
