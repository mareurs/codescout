"""Stage exact current source copies for the two previously observed survivors."""
from pathlib import Path
import hashlib
import json
import shutil
import tarfile
root = Path.cwd()
out = root / ".superpowers/sdd/2026-11-10-prospective-linker-classification"
with tarfile.open(out / "baseline.tar.gz", "r:gz") as package:
    names = sorted(json.load(package.extractfile("manifest.json"))["files"])
destination = out / "mutation-replays"
destination.mkdir(exist_ok=False)
for identity in ("M06-status-127", "M07-command-blank"):
    for name in names:
        target = destination / identity / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(root / name, target)
    rows = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in names}
    assert all(hashlib.sha256((destination / identity / name).read_bytes()).hexdigest() == rows[name]
               for name in names)
    (destination / identity / "before.json").write_text(json.dumps(rows, indent=2))
print(json.dumps({"staged":2, "source_files_each":len(names)}))
