"""Actual cgroup observations and policy adjudication only after fresh worker absence."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time
import uuid
import native_controls as b

def events(cid):
    result = b.docker(["exec", cid, "python3", "-I", "-c",
                      "from pathlib import Path;print(Path('/sys/fs/cgroup/memory.events').read_text(),end='')"])
    assert result.returncode == 0, result.stderr
    values = dict((key, int(value)) for key, value in (line.split() for line in result.stdout.splitlines()))
    assert "oom_kill" in values and all(type(value) is int and value >= 0 for value in values.values())
    return {"raw": result.stdout, "values": values}

def main(stem):
    image = b.IMAGES[stem]
    out = b.HERE / ("native-" + stem + "-v2")
    out.mkdir(exist_ok=False)
    nextest = stem == "obscura-421"
    parser = b.JSON_PARSER if nextest else b.LIB_PARSER
    command = ("cargo nextest run --offline --no-fail-fast --message-format libtest-json-plus"
               if nextest else "cargo test --lib --offline") + " > /probe/report"
    record = {"log_parser": parser, "FAIL_TO_PASS": [b.SELECTORS[stem]], "PASS_TO_PASS": [],
              "rebuild_cmds": [], "test_cmds": [command], "print_cmds": ["cat /probe/report"]}
    registered = {"version": b.stream_evidence.VERSION, "commands_sha256": b.stream_evidence.commands_digest(record),
                  "tests": [{"profile": b.stream_evidence.NEXT if nextest else b.stream_evidence.LIB,
                             "reports": [0], "stderr_files": []}]}
    name = "f6-native-" + uuid.uuid4().hex
    args = ["create", "--pull=never", "--name", name, "--label", "codescout.f6-control=" + name,
            "--network", "none", "--read-only", "--user", "1000:1000", "--cpus", "4",
            "--memory", "8g", "--memory-swap", "8g", "--pids-limit", "4096", "--init",
            "--cap-drop=ALL", "--security-opt", "no-new-privileges",
            "--tmpfs", "/probe:rw,exec,size=256m,uid=1000,gid=1000",
            "--tmpfs", "/tmp:rw,exec,size=128m,uid=1000,gid=1000",
            "--tmpfs", "/mnt_tmp:ro,noexec,nosuid,nodev,size=1m",
            "--env", "TMPDIR=/probe", "--env", "CARGO_TARGET_DIR=/probe/target",
            "--env", "CARGO_NET_OFFLINE=true", "--env", "NEXTEST_EXPERIMENTAL_LIBTEST_JSON=1",
            "--workdir", "/probe", "--entrypoint", "/bin/sleep", image, "infinity"]
    b.save(out / "registration.json", {"image": image, "create_argv": ["docker", *args],
        "helper_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "helper_dependency_sha256": hashlib.sha256(Path(b.__file__).read_bytes()).hexdigest(),
        "record": record, "runner_contract": registered,
        "source": {"Cargo.toml": b.TOML, "good": b.GOOD, "bad": b.BAD},
        "policy_version": "semantic-stream-contract-v2",
        "module_hashes": {n: hashlib.sha256((b.MODULES/n).read_bytes()).hexdigest()
            for n in ("grade_policy.py","command_capture.py","stream_evidence.py","multilang_control.py")},
        "scope": "generated compiler/runner controls; actual measured cgroups and closure, no benchmark candidate or model",
        "provider_calls": 0, "paid_ready": False})
    cid = None
    pending = []
    closed = None
    cleanup = None
    try:
        created = b.docker(args)
        assert created.returncode == 0, created.stderr
        cid = created.stdout.strip()
        before = b.inspect(cid)
        b.owned(before, cid, name, image)
        b.save(out / "container-before.json", before)
        host = before["HostConfig"]
        assert (host["Memory"],host["MemorySwap"],host["NanoCpus"],host["PidsLimit"]) == (8*1024**3,8*1024**3,4*10**9,4096)
        assert host["Init"] and host["ReadonlyRootfs"] and host["CapDrop"] == ["ALL"] and not before["Mounts"]
        assert before["Config"]["User"] == "1000:1000" and host["NetworkMode"] == "none"
        assert b.docker(["start", cid]).returncode == 0
        for program in (["rustc","--version"],["cargo","--version"],
                        *( [["cargo","nextest","--version"]] if nextest else [] )):
            version = b.docker(["exec",cid,*program])
            b.save(out / ("version-"+"-".join(program[:-1])+".json"),
                   {"argv":program,"returncode":version.returncode,"stdout":version.stdout,"stderr":version.stderr})
            assert version.returncode == 0, version.stderr
            if program[:2] == ["cargo","nextest"]:
                assert version.stdout.startswith("cargo-nextest 0.9.128 ")
            if not nextest and program[0] == "rustc":
                assert version.stdout.startswith("rustc 1.97.1 "), version.stdout
        for variant, source in (("good",b.GOOD),("bad",b.BAD)):
            case = out / variant
            case.mkdir()
            writer = ("from pathlib import Path;Path('/probe/src').mkdir(exist_ok=True);"
                      "Path('/probe/Cargo.toml').write_text("+repr(b.TOML)+");"
                      "Path('/probe/src/lib.rs').write_text("+repr(source)+");"
                      "Path('/probe/report').unlink(missing_ok=True)")
            made = b.docker(["exec",cid,"python3","-I","-c",writer])
            assert made.returncode == 0, made.stderr
            probes = [events(cid)]
            start = time.monotonic()
            test = b.control._step(cid,"/probe","grade:test[0]",command,120,capture_streams=True)
            printed = b.control._step(cid,"/probe","grade:print[0]","(\ncat /probe/report\n) 2>&1",30,capture_streams=True)
            probes.append(events(cid))
            b.save(case / "memory-events.json", probes)
            assert probes[-1]["values"]["oom_kill"] == probes[0]["values"]["oom_kill"]
            stdout, stderr = b.command_capture.read_streams(test["capture"])
            report, outer = b.command_capture.read_streams(printed["capture"])
            assert not outer and printed["returncode"] == 0
            for filename, raw in (("command.stdout",stdout),("command.stderr",stderr),("report.log",report)):
                (case/filename).write_bytes(raw)
            observed = b.grade.run_parser(parser,report.decode())
            state = b.inspect(cid)
            b.owned(state,cid,name,image)
            assert state["State"]["Running"] and not state["State"]["OOMKilled"]
            b.save(case/"state.json",state)
            if variant == "good":
                assert test["returncode"] == 0 and observed == {b.SELECTORS[stem]:"pass"}, (test,observed)
                assert b.grade_policy.linker_diagnostic(stderr.decode()) is None
            else:
                assert test["returncode"] != 0 and not observed and b"undefined" in stderr, (test,observed)
            pending.append({"variant":variant,"test":test,"printed":printed,"observed":observed,
                            "log":report.decode(),"probes":probes,"wall_s":time.monotonic()-start})
    except Exception as exc:
        b.save(out/"failure.json",{"type":type(exc).__name__,"message":str(exc)[:2000]})
        raise
    finally:
        if cid is not None:
            after = b.inspect(cid)
            b.owned(after,cid,name,image)
            b.save(out/"container-after.json",after)
            stopped = b.docker(["stop","-t","5",cid])
            assert stopped.returncode == 0, stopped.stderr
            closed = b.inspect(cid)
            b.owned(closed,cid,name,image)
            b.save(out/"container-closed.json",closed)
            assert closed["State"]["Status"] == "exited" and not closed["State"]["Running"] and not closed["State"]["OOMKilled"]
            assert b.docker(["rm","-v",cid]).returncode == 0
            absent = b.docker(["inspect",cid])
            assert absent.returncode != 0 and "no such" in absent.stderr.lower()
            cleanup = {"complete":True,"cid":cid,"name":name,"fresh_absence":True}
            b.save(out/"cleanup.json",cleanup)
    rows = []
    for item in pending:
        probes = item["probes"]
        runtime = {"complete":cleanup["complete"],"resource_ok":True,"cgroup_probes":len(probes),
                   "oom_kill":probes[-1]["values"]["oom_kill"]-probes[0]["values"]["oom_kill"],"errors":[]}
        raw = dict(b.grade.verdict(item["observed"],record["FAIL_TO_PASS"],[]),
                   oom_killed=closed["State"]["OOMKilled"],container_removed=cleanup["fresh_absence"],error=None,infra=None)
        full = dict(raw,steps=[item["test"],item["printed"]])
        outcome = b.grade_policy.adjudicate_streams(raw,full,record,
            {"expected":{"fail_to_pass":1,"pass_to_pass_kept":0,"dropped":[]}},
            log=item["log"],runtime=runtime,registered=registered)
        case = out/item["variant"]
        b.save(case/"runtime.json",runtime)
        b.save(case/"full-evidence.json",full)
        b.save(case/"policy-result.json",outcome)
        assert outcome["valid"],outcome
        assert outcome["pass"] == (item["variant"] == "good"),outcome
        assert outcome["kind"] == ("pass" if item["variant"] == "good" else "compile_failure"),outcome
        rows.append({"variant":item["variant"],"native_returncode":item["test"]["returncode"],
                     "parsed_statuses":item["observed"],"policy":outcome,"runtime":runtime,"wall_s":item["wall_s"]})
    b.save(out/"result.json",{"cases":rows,"cleanup_complete":True,"provider_calls":0,"paid_ready":False,
           "scope":"actual generated compiler/runner/complete-capture controls; no benchmark repair or efficacy outcome"})
    print(json.dumps({"stem":stem,"complete":True,"cases":len(rows),"paid_ready":False}))

if __name__ == "__main__":
    main(sys.argv[1])
