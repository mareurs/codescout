# SDD ledger — plan: /home/marius/work/claude/codescout/docs/trackers/effort-steering/plans/2026-11-10-prospective-linker-classification.md

Pre-flight: Task1 produces prospective compiler classification/version consumed by Task2 actual native output replay; legacy path untouched. Interfaces match scouted current _adjudicate diagnostics and complete capture helpers.

Ruling: reuse isolated fix/grader-stream-provenance-20261110 worktree with distinct Gitdir and no superproject; preserve complete current WIP before edits — keeps prior complete-stream implementation and no shared-main source writes — cost if wrong: qualification refuses or new local test fails; no payment admitted.

Ruling: standing operator autonomy opts out of recurring design/plan signoffs; implement the chosen prospective-only design inline — avoids repeating settled process questions — cost if wrong: local unpublished source must be revised, no merge/push/provider effect.

Ruling: prospective policy version becomes semantic-stream-contract-v2; historical compiler_diagnostic/adjudicate_private stay unchanged — prevents old recorded semantics changing silently — cost if wrong: new admission fails version binding, no historical regrade.

Ruling: no commit/delete-workspace while publication hold applies; retain source/capsule and explicit path WIP — overriding skill default commit/deletion steps within standing user constraints — cost if wrong: integration remains local and requires later operator action.
Task 1: complete (commits f586d35..f586d35, tests: python3 -B -m unittest discover -s tools/setup-ab-eval -p test_*policy.py -v → OK)

## Task 1 and native-control checkpoint

Baseline 99 source files sealed/reopened unchanged, SHA256866e2e08b44623976d84f901ae9887bf2c685ca4b80fb86d71a351134f0493a8. Focused baseline13tests OK. RED new prospective suite21tests reported8failures,including stale selected pass surviving actual failed-link test diagnostic. No errors. GREEN prospective21 and legacy49; task-done task1 runs both70tests OK, with HEAD unchanged under publication hold. Only grade_policy.py and test_stream_policy.py changed from this plan baseline.

Ruling: recognize only canonical ordinary linker exit statuses1..127; encoded137/139 remain outside this new affirmative recognition — preserves distinction from fatal signals rather than silently deciding F7 — cost if wrong: unsupported ordinary text remains invalid rather than receiving a favorable pass.

Task2 initial native v1 generated valid/undefined-symbol controls both succeeded on both actual frozen images. They explicitly mark policy runtime fields as replay flags; do not present cgroup_probes2 or container_removedtrue there as actual timing measurements. New v2 adds actual before/after memory.events and adjudicates only AFTER fresh worker absence. Prior v1 evidence retained, no benchmark/model rerun. Native v2 jobs bg11a/bg11b running.

Whole tools/setup-ab-eval suite bg116:1389reported tests,OK. Final product gate bg117 still running; logs are retained directly inside this plan workspace, not only ephemeral background paths.

Ruling: this task’s fresh review covers the new prospective F6 delta against the preserved full source WIP. Prior complete-stream review/capsule stays authoritative for its earlier slice. HEAD..HEAD is empty under publication hold, so final review must use sealed source plus exact baseline delta, not pretend an empty commit range was reviewed — cost if wrong: unreviewed delta stays unadmitted, no payment.

No F3 decision, historical verdict rewrite, new onboarding/provider repair or source commit. Parent admission and research goal remain open.

## Native v2 and final gate checkpoint — 2026-11-10

Supersedes the pending job wording above. Both native v2 controls complete: exact Obscura nextest0.9.128 and Lean rustc1.97.1 images each produce good return0/pass with one selected status; undefined-symbol variant return101/compile_failure with zero statuses. Before/after actual memory.events:2probes each command,oom_kill delta0. Fresh owned-container absence confirmed before policy adjudication. No benchmark/private repair or provider call.

Direct tools/setup-ab-eval suite1389reported tests,OK. Gate bg117 terminal exit0,total447s; Python1765passed,1skipped,554subtests; lean6318passed/48skipped,default9215passed/62skipped. FMT/CLIPPY/LEAN/DEFAULT and PYTHON_LIGHT all0. Printed heavy-Python,server-stack,lean-librarian,local-ONNX exclusions retained in gate.log. This gate does not substitute for the direct tools suite.

ONE fresh final reviewer is running against sealed99file fullWIP+exact2fileF6delta; source unchanged since sealing. No payment admitted. Final review/custody remains pending.

## Final review disposition — one bounded correction

ONE review complete,with fixes. Parent read full review,exact M06/M07differences and their70test-greenlogs,consuming probes and both pre-F6/current Unicode comparisons; independently reproduced U+2028 in test and rebuild and filed MAIN bf0d019daf7cc5ef before any fix.

Ruling F6-R1 Important: accept; prevent non-LF separators inside one physical line creating a prospective linker header. Preserve named historical helpers byte-identical. Add consuming RED first,then minimal new-helper normalization.

Ruling F6-R2 Important test gap: accept; pin whitespace-only command refusal in both consuming paths,then replay exact observed M07mutant. Current production guard itself is correct.

Ruling F6-R3 Minor test gap: accept within this bounded pass; pin accepted127/rejected128 and replay exact M06mutant. Current production endpoint itself is correct.

Declined scopes retained: F3missing-status and F7generic encoded-signal attribution,earlier complete-stream architecture/other historical recognizers/outer registration,exhaustive compiler/terminal encodings,independent reexecution of parent's native/cgroup/gate,repair efficacy/payment/publication. No implicit ruling or scope expansion. No second reviewer/re-review. Native controls are unchanged inputs; after minimal linker fix replay their complete captured evidence instead of spending another compiler/model run.

## Final correction verification — 2026-11-10

Final: fixed F6-R1 — consuming test_f6_non_lf_separators_cannot_create_physical_linker_header observed RED before production; prospective helper now preserves CRLF and prevents non-LF splitlines separators inventing headers. Historical helper bytes remain unchanged and will be rechecked in final custody. Initial RED24tests/66failures included two incorrect bare-CR selected-pass expectations; existing complete-stream normalization already rejects bare CR. That test-instrument error was corrected without weakening production. Failed first green73tests/2failures and final green73tests/OK retained.

Final: fixed F6-R2 test gap — observed M07survivor before closing tests; exact replay with new consuming whitespace cases now exits1 on10targeted subtests,73tests total,noerrors. No current production blank-guard change.

Ruling: pin the Minor F6-R3 endpoint while completing this plan's explicit1..127 boundary contract — no production behavior change and no new review; costs one small existing-mutant replay rather than leaving a measured gap in the promised input range. Exact M06replay now exits1 on2targeted subtests,73tests total,noerrors. Original survivor and current replay retained separately, never rewrite original10killed/2survived result.

Corrected final policy replay on the four retained actual native captures is byte-equivalent to all prior verdicts; no container/compiler rerun. Final direct tools suite bg121:1392tests,OK,256.711s. Final gate bg120:exit0,total125s; Python1765passed/1skip/554subtests,lean6318passed48skipped,default9215passed62skipped; all lanes0. Printed exclusions retained. Eleven terminal producer records preserved in plan workspace, including expected exit1mutant replays.

No second review,source commit,push,merge,provider call or historical verdict rewrite. Publication hold and parent admission remain closed. Final capsule/reopen and task completion line follow; immutable archive will retain this pre-completion ledger snapshot.
