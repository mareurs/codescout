### Task 1: Prospective linker classifier and consuming tests

**Files:** modify tools/setup-ab-eval/grade_policy.py and test_stream_policy.py; add narrowly scoped fixtures/tests only if required.
**Interfaces:** linker_diagnostic(text:str)->str|None recognizes exact top-level ordinary linker evidence using existing scoped_lines; compiler(step) in _adjudicate calls it only with qualified diagnostics. adjudicate_streams emits policy_version semantic-stream-contract-v2. Existing call signatures and legacy recognizer unchanged.

- [ ] Preserve baseline source/diff/hashes; verify current affected suites and isolated branch identity.
  Run python3 -B -m unittest discover -s tools/setup-ab-eval -p test_stream_policy.py -v. Expected: current suite green; this is baseline, not proof F6 works.
- [ ] Add consuming tests for failed rebuild/test ordinary link, retained selected status/missing status, successful-step refusal, captured linker words, fatal/storage precedence, malformed headers/ambiguous framing, legacy invalid behavior and v2 identity. Reuse real complete captures and existing public parser fixtures.
  Run same focused command. Expected RED on ordinary-link classification/version before production edits; retain exact output.
- [ ] Implement prospective-only recognition and identity bump. No historical helper widening.
  Run same focused command and python3 -B -m unittest discover -s tools/setup-ab-eval -p test_grade_policy.py -v. Expected: all green, historic test unchanged.

