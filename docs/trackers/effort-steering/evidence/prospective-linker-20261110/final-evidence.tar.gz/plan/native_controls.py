"""Generated public compiler controls on frozen images; no benchmark candidate/model."""
from pathlib import Path
import hashlib
import json
import shlex
import subprocess
import sys
import time
import uuid

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
MODULES = REPO / "tools/setup-ab-eval"
sys.path.insert(0, str(MODULES))
import command_capture
import grade_policy
import multilang_control as control
import multilang_grade as grade
import stream_evidence

IMAGES = {
    "obscura-421": "sha256:b22988cd6022dd7a428a750799114b9c6f09bcaecc4fd9d8b86a0ef8502772d1",
    "lean-ctx-1168": "sha256:b72f902d24c0a54516e4ef242d8218805f0ea3dc1d26ac809140979ba1f51d56",
}
SELECTORS = {"obscura-421": "f6_link_probe::f6_link_probe$smoke", "lean-ctx-1168": "smoke"}
TOML = '[package]\nname="f6_link_probe"\nversion="0.1.0"\nedition="2021"\n'
GOOD = '#[test]\nfn smoke() { assert_eq!(1 + 1, 2); }\n'
BAD = 'extern "C" { fn f6_missing_link_symbol(); }\n#[test]\nfn smoke() { unsafe { f6_missing_link_symbol(); } }\n'
JSON_PARSER = """def parser(log):
    import json
    result={}
    for line in log.splitlines():
        event=json.loads(line)
        if event.get('type')=='test' and event.get('event') in ('ok','failed','ignored'):
            result[event['name']]={'ok':'pass','failed':'fail','ignored':'skip'}[event['event']]
    return result
"""
LIB_PARSER = """def parser(log):
    import re
    result={}
    for line in log.splitlines():
        m=re.fullmatch(r'test (.+) \\.\\.\\. (ok|FAILED|ignored)',line)
        if m:
            result[m[1]]={'ok':'pass','FAILED':'fail','ignored':'skip'}[m[2]]
    return result
"""

def save(path, value):
    with path.open("x") as f:
        json.dump(value, f, indent=2)

def docker(args, *, timeout=60):
    return subprocess.run(["docker", *args], capture_output=True, text=True, timeout=timeout)

def inspect(cid):
    result = docker(["inspect", cid])
    assert result.returncode == 0, result.stderr
    return json.loads(result.stdout)[0]

def owned(row, cid, name, image):
    assert row["Id"] == cid and row["Image"] == image
    assert row["Config"]["Labels"]["codescout.f6-control"] == name

def main(stem):
    image = IMAGES[stem]
    out = HERE / ("native-" + stem + "-v1")
    out.mkdir(exist_ok=False)
    nextest = stem == "obscura-421"
    parser = JSON_PARSER if nextest else LIB_PARSER
    command = ("cargo nextest run --offline --no-fail-fast --message-format libtest-json-plus"
               if nextest else "cargo test --lib --offline") + " > /probe/report"
    record = {"log_parser": parser, "FAIL_TO_PASS": [SELECTORS[stem]], "PASS_TO_PASS": [],
              "rebuild_cmds": [], "test_cmds": [command], "print_cmds": ["cat /probe/report"]}
    registered = {"version": stream_evidence.VERSION,
                  "commands_sha256": stream_evidence.commands_digest(record),
                  "tests": [{"profile": stream_evidence.NEXT if nextest else stream_evidence.LIB,
                             "reports": [0], "stderr_files": []}]}
    name = "f6-native-" + uuid.uuid4().hex
    args = ["create", "--pull=never", "--name", name, "--label", "codescout.f6-control=" + name,
            "--network", "none", "--read-only", "--user", "1000:1000", "--cpus", "4",
            "--memory", "8g", "--memory-swap", "8g", "--pids-limit", "4096", "--init",
            "--cap-drop=ALL", "--security-opt", "no-new-privileges",
            "--tmpfs", "/probe:rw,exec,size=256m,uid=1000,gid=1000",
            "--tmpfs", "/tmp:rw,exec,size=128m,uid=1000,gid=1000",
            "--tmpfs", "/mnt_tmp:ro,noexec,nosuid,nodev,size=1m",
            "--env", "TMPDIR=/probe", "--env", "CARGO_TARGET_DIR=/probe/target",
            "--env", "CARGO_NET_OFFLINE=true", "--env", "NEXTEST_EXPERIMENTAL_LIBTEST_JSON=1",
            "--workdir", "/probe", "--entrypoint", "/bin/sleep", image, "infinity"]
    save(out / "registration.json", {"image": image, "create_argv": ["docker", *args],
         "helper_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         "source": {"Cargo.toml": TOML, "good": GOOD, "bad": BAD},
         "record": record, "runner_contract": registered, "policy_version": "semantic-stream-contract-v2",
         "module_hashes": {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
             for p in [MODULES / n for n in ("grade_policy.py", "command_capture.py", "stream_evidence.py", "multilang_control.py")]},
         "paid_ready": False, "provider_calls": 0,
         "scope": "generated source only; actual runner/complete command capture, no benchmark candidate or gold"})
    cid = None
    rows = []
    try:
        created = docker(args)
        assert created.returncode == 0, created.stderr
        cid = created.stdout.strip()
        before = inspect(cid)
        owned(before, cid, name, image)
        save(out / "container-before.json", before)
        host = before["HostConfig"]
        assert (host["Memory"],host["MemorySwap"],host["NanoCpus"],host["PidsLimit"]) == (8*1024**3,8*1024**3,4*10**9,4096)
        assert host["Init"] and host["ReadonlyRootfs"] and host["CapDrop"] == ["ALL"]
        assert not before["Mounts"]
        assert docker(["start", cid]).returncode == 0
        for program in (["rustc", "--version"], ["cargo", "--version"],
                        *( [["cargo", "nextest", "--version"]] if nextest else [] )):
            version = docker(["exec", cid, *program])
            save(out / ("version-" + "-".join(program[:-1]) + ".json"),
                 {"argv": program, "returncode": version.returncode, "stdout": version.stdout, "stderr": version.stderr})
            assert version.returncode == 0, version.stderr
            if program[:2] == ["cargo", "nextest"]:
                assert version.stdout.startswith("cargo-nextest 0.9.128 ")
            if not nextest and program[0] == "rustc":
                assert version.stdout.startswith("rustc 1.97.1 "), version.stdout
        for variant, source in (("good", GOOD), ("bad", BAD)):
            case = out / variant
            case.mkdir()
            writer = ("from pathlib import Path;"
                      "Path('/probe/src').mkdir(exist_ok=True);"
                      "Path('/probe/Cargo.toml').write_text(" + repr(TOML) + ");"
                      "Path('/probe/src/lib.rs').write_text(" + repr(source) + ");"
                      "Path('/probe/report').unlink(missing_ok=True)")
            made = docker(["exec", cid, "python3", "-I", "-c", writer])
            assert made.returncode == 0, made.stderr
            start = time.monotonic()
            test = control._step(cid, "/probe", "grade:test[0]", command, 120, capture_streams=True)
            printed = control._step(cid, "/probe", "grade:print[0]", "(\ncat /probe/report\n) 2>&1", 30, capture_streams=True)
            stdout, stderr = command_capture.read_streams(test["capture"])
            report_bytes, print_err = command_capture.read_streams(printed["capture"])
            assert not print_err and printed["returncode"] == 0
            log = report_bytes.decode()
            (case / "command.stdout").write_bytes(stdout)
            (case / "command.stderr").write_bytes(stderr)
            (case / "report.log").write_bytes(report_bytes)
            observed = grade.run_parser(parser, log)
            raw = dict(grade.verdict(observed, record["FAIL_TO_PASS"], []),
                       oom_killed=False, container_removed=True, error=None, infra=None)
            full = dict(raw, steps=[test, printed])
            runtime = {"complete": True, "resource_ok": True, "cgroup_probes": 2,
                       "oom_kill": 0, "errors": []}
            # Actual owner/resource state is checked separately; replay fields are marked explicitly below.
            outcome = grade_policy.adjudicate_streams(raw, full, record,
                {"expected": {"fail_to_pass": 1, "pass_to_pass_kept": 0, "dropped": []}},
                log=log, runtime=runtime, registered=registered)
            current = inspect(cid)
            owned(current, cid, name, image)
            assert current["State"]["Running"] and not current["State"]["OOMKilled"]
            save(case / "state.json", current)
            save(case / "full-evidence.json", full)
            save(case / "policy-result.json", outcome)
            if variant == "good":
                assert test["returncode"] == 0 and observed == {SELECTORS[stem]: "pass"}, (test, observed)
                assert outcome["valid"] and outcome["pass"], outcome
                assert grade_policy.linker_diagnostic(stderr.decode()) is None
            else:
                assert test["returncode"] != 0 and not observed, (test, observed)
                assert b"undefined" in stderr or b"undefined" in stdout
                assert outcome["valid"] and not outcome["pass"] and outcome["kind"] == "compile_failure", outcome
            rows.append({"variant": variant, "native_returncode": test["returncode"],
                         "parsed_statuses": observed, "policy": outcome,
                         "wall_seconds": time.monotonic() - start,
                         "actual_stream_capture_complete": test["capture"]["complete"],
                         "runtime_policy_fields": "replay boundary flags; actual native resource/owner/state/cleanup retained independently"})
        save(out / "result-before-cleanup.json", {"cases": rows, "provider_calls": 0, "paid_ready": False})
    except Exception as exc:
        save(out / "failure.json", {"type": type(exc).__name__, "message": str(exc)[:2000], "provider_calls": 0})
        raise
    finally:
        if cid is not None:
            final = inspect(cid)
            owned(final, cid, name, image)
            save(out / "container-after.json", final)
            assert not final["State"]["OOMKilled"]
            stopped = docker(["stop", "-t", "5", cid])
            assert stopped.returncode == 0, stopped.stderr
            closed = inspect(cid)
            owned(closed, cid, name, image)
            save(out / "container-closed.json", closed)
            assert not closed["State"]["Running"] and not closed["State"]["OOMKilled"]
            removed = docker(["rm", "-v", cid])
            assert removed.returncode == 0, removed.stderr
            absent = docker(["inspect", cid])
            assert absent.returncode != 0 and "no such" in absent.stderr.lower()
            save(out / "cleanup.json", {"complete": True, "cid": cid, "name": name, "fresh_absence": True})
    save(out / "result.json", {"cases": rows, "cleanup_complete": True, "provider_calls": 0,
                              "paid_ready": False, "scope": "generated compiler/runner controls, not benchmark repair"})
    print(json.dumps({"stem": stem, "complete": True, "cases": len(rows), "paid_ready": False}))

if __name__ == "__main__":
    main(sys.argv[1])
