"""Seal the entire current grader source and exact F6-only delta for one review."""
from pathlib import Path
import ast
import difflib
import hashlib
import io
import json
import subprocess
import tarfile

ROOT = Path.cwd()
OUT = ROOT / ".superpowers/sdd/2026-11-10-prospective-linker-classification"
with tarfile.open(OUT / "baseline.tar.gz", "r:gz") as old:
    baseline = json.load(old.extractfile("manifest.json"))
    names = sorted(baseline["files"])
    changed = [name for name in names if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
               != baseline["files"][name]["sha256"]]
    assert changed == ["tools/setup-ab-eval/grade_policy.py", "tools/setup-ab-eval/test_stream_policy.py"], changed
    diffs = []
    for name in changed:
        previous = old.extractfile(name).read().decode()
        current = (ROOT/name).read_text()
        diffs.extend(difflib.unified_diff(previous.splitlines(True), current.splitlines(True),
                                         fromfile="baseline/"+name,tofile="final/"+name))
    original = old.extractfile("tools/setup-ab-eval/grade_policy.py").read().decode()
    current = (ROOT/"tools/setup-ab-eval/grade_policy.py").read_text()
    def segment(source, name):
        node = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name == name)
        return ast.get_source_segment(source,node)
    assert all(segment(original,name)==segment(current,name)
               for name in ("compiler_diagnostic","adjudicate_private","scoped_lines"))
delta = "".join(diffs).encode()
with (OUT/"f6-only.diff").open("xb") as f:
    f.write(delta)
files = {name:ROOT/name for name in names}
for name in ("native_controls.py","native_controls_v2.py"):
    files["helpers/"+name] = OUT/name
for stem in ("obscura-421","lean-ctx-1168"):
    control = OUT/("native-"+stem+"-v2")
    assert json.loads((control/"result.json").read_text())["cleanup_complete"]
    for p in control.rglob("*"):
        if p.is_file():
            files["native/"+stem+"/"+str(p.relative_to(control))] = p
for name in ("progress.md","task-1-brief.md","task-2-brief.md","task1-red.log","task1-green.log","legacy-green.log","all-tools.log"):
    files["evidence/"+name] = OUT/name
manifest = {"head":baseline["head"],"changed_paths":changed,"legacy_functions_source_byte_equal":True,
            "files":{name:hashlib.sha256(p.read_bytes()).hexdigest() for name,p in sorted(files.items())},
            "scope":"99-file source package and exact prospective F6 delta; not empty HEAD..HEAD; no publication"}
raw = json.dumps(manifest,indent=2,sort_keys=True).encode()
archive = OUT/"review-source.tar.gz"
with tarfile.open(archive,"x:gz") as tar:
    for name,p in sorted(files.items()):
        tar.inodes.clear()
        tar.add(p,arcname=name,recursive=False)
    for name,content in (("manifest.json",raw),("f6-only.diff",delta)):
        info=tarfile.TarInfo(name)
        info.size=len(content)
        tar.addfile(info,io.BytesIO(content))
with tarfile.open(archive,"r:gz") as tar:
    assert json.load(tar.extractfile("manifest.json"))==manifest
    for name,p in files.items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==manifest["files"][name]
        assert hashlib.sha256(p.read_bytes()).hexdigest()==manifest["files"][name]
receipt={"archive":str(archive),"sha256":hashlib.sha256(archive.read_bytes()).hexdigest(),
         "changed_paths":changed,"source_files":len(names),"all_members_reopened":True,
         "legacy_functions_source_byte_equal":True,"paid_ready":False}
with (OUT/"review-source-receipt.json").open("x") as f:
    json.dump(receipt,f,indent=2)
print(json.dumps(receipt,indent=2))
