"""Replay four existing complete native captures through the corrected policy; no container call."""
from pathlib import Path
import hashlib
import json
import sys
root = Path.cwd()
out = root / ".superpowers/sdd/2026-11-10-prospective-linker-classification"
sys.path.insert(0, str(root / "tools/setup-ab-eval"))
import grade_policy as policy
rows = []
for stem in ("obscura-421", "lean-ctx-1168"):
    native = out / ("native-" + stem + "-v2")
    registration = json.loads((native / "registration.json").read_text())
    for variant in ("good", "bad"):
        case = native / variant
        full = json.loads((case / "full-evidence.json").read_text())
        raw = {key:value for key,value in full.items() if key != "steps"}
        result = policy.adjudicate_streams(raw, full, registration["record"],
            {"expected":{"fail_to_pass":1,"pass_to_pass_kept":0,"dropped":[]}},
            log=(case / "report.log").read_text(),
            runtime=json.loads((case / "runtime.json").read_text()),
            registered=registration["runner_contract"])
        assert result == json.loads((case / "policy-result.json").read_text()), result
        rows.append({"stem":stem,"variant":variant,"kind":result["kind"],
                     "valid":result["valid"],"pass":result["pass"]})
receipt = {"scope":"replay retained complete native evidence, no reexecution",
           "policy_sha256":hashlib.sha256((root / "tools/setup-ab-eval/grade_policy.py").read_bytes()).hexdigest(),
           "cases":rows,"native_invocations":0,"provider_calls":0,"paid_ready":False}
with (out / "native-final-replay.json").open("x") as stream:
    json.dump(receipt,stream,indent=2)
print(json.dumps(receipt,indent=2))
