### Task 2: Native compiler controls, review and checked custody

**Files:** owned model-free compiler helper and output/registration under this plan’s scratch; report and checked capsule under this tracker. Product code from Task1 only.
**Interfaces:** each control writes exact image/argv/rustc version/full stdout/stderr/state/cleanup evidence and feeds those bytes through the real prospective capture/policy entry point. No task/candidate execution or actual expected benchmark result changes.

- [ ] Generate dependency-free undefined-symbol and valid-link controls on BOTH exact task images; bind helper/source/runtime before execution. Feed failed compiler output into separate synthetic selection receipts through complete-stream contract. Expect native failed-link nonzero plus prospective valid compile_failure; valid link has no false compiler evidence. Preserve native fatal/storage negative controls without intentionally exhausting host resources.
- [ ] Run all tools/setup-ab-eval test_*.py suites and required ./scripts/gate.sh --check in the isolated worktree. Expected: green, every skip/exclusion/red disclosed; direct tools suite is required because gate does not include it.
- [ ] Seal final source WIP against the baseline, then ONE fresh strongest reviewer applies at least8load-bearing guard mutations on isolated copies, runs actual tests and reports observed killed/survived/invalid counts. Read survivor diffs/logs before fixes. Critical/Important get one RED/GREEN correction and affected whole-suite replay; Minor/declined scope get explicit rulings.
- [ ] Preserve source/diffs/native control inputs/streams/review/mutants/tests/gate with manifest and actual archive reopen. Update F6 issue/report/README/parent admission checkpoint; paid_readyfalse. No source commit or premature parent-goal completion.

## Self-review

Actual code scout: _adjudicate receives qualified diagnostic texts only from adjudicate_streams; legacy adjudicate_private calls the same helper without diagnostics. Infrastructure scan precedes compile classification. Existing rebuild records failed status without aborting subsequent tests/prints. Only one test pins the old prospective version; update its assertion as part of explicit v2 behavior. The new classifier must use existing scoping and resist inherited source-gutter text. Native tests characterize compiler bytes on actual images; they do not regrade benchmark candidates or establish efficacy.
