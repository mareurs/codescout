"""Real-shell controls for declared redirected diagnostic files, without model or Docker calls."""
import json
from pathlib import Path
import subprocess
import tempfile
import unittest

import diagnostic_artifacts as artifacts

class ArtifactTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        subprocess.run(["git","init","-q",str(self.root)], check=True)

    def run_script(self, source):
        return subprocess.run(["bash","-o","pipefail","-c",source], cwd=self.root,
                              capture_output=True, text=True, timeout=10)

    def prepare(self, paths):
        result = self.run_script(artifacts.prepare_script(paths))
        self.assertEqual(result.returncode,0,result.stderr)
        return artifacts.prepared(result.stdout,paths)

    def collect(self, paths, prepared, *, limit=1024):
        result = self.run_script(artifacts.read_script(paths,prepared,limit_bytes=limit))
        self.assertEqual(result.returncode,0,result.stderr)
        return artifacts.decode(result.stdout,prepared,paths,limit_bytes=limit)

    def test_stale_untracked_redirect_is_removed_then_fresh_binary_bytes_are_retained(self):
        (self.root/"rust").mkdir()
        path = self.root/"rust/1"
        path.write_text("stale compiler error")
        preparation = self.prepare(["rust/1"])
        self.assertFalse(path.exists())
        path.write_bytes(b"new stderr\x00\xff")
        result = self.collect(["rust/1"],preparation)
        self.assertTrue(result["complete"])
        self.assertEqual(artifacts.read_files(result,["rust/1"]), {"rust/1":b"new stderr\x00\xff"})

    def test_post_command_fifo_is_refused_without_waiting_for_a_writer(self):
        import os
        preparation = self.prepare(["1"])
        os.mkfifo(self.root/"1")
        result = self.run_script(artifacts.read_script(["1"], preparation, limit_bytes=1024))
        self.assertNotEqual(result.returncode, 0)

    def test_missing_after_preparation_never_becomes_empty_diagnostics(self):
        preparation = self.prepare(["1"])
        result = self.run_script(artifacts.read_script(["1"],preparation,limit_bytes=1024))
        self.assertNotEqual(result.returncode,0)

    def test_trackedsymlink_directory_and_parent_symlink_are_refused_before_deletion(self):
        (self.root/"tracked").write_text("must survive")
        subprocess.run(["git","add","--","tracked"],cwd=self.root,check=True)
        (self.root/"target").write_text("must survive")
        (self.root/"link").symlink_to("target")
        (self.root/"dir").mkdir()
        (self.root/"alias").symlink_to("dir",target_is_directory=True)
        for path in ("tracked","link","dir","alias/new"):
            with self.subTest(path=path):
                result = self.run_script(artifacts.prepare_script([path]))
                self.assertNotEqual(result.returncode,0)
                self.assertEqual((self.root/"tracked").read_text(),"must survive")
                self.assertEqual((self.root/"target").read_text(),"must survive")
                self.assertTrue((self.root/"link").is_symlink())

    def test_unsafe_duplicate_or_too_many_paths_are_refused(self):
        for paths in (["../escape"],["/tmp/x"],["a/../x"],[".git/x"],["a","a"],[],
                      ["a","b","c","d","e"],[True],["a\nb"]):
            with self.subTest(paths=paths):
                with self.assertRaises(artifacts.ArtifactError):
                    artifacts.prepare_script(paths)

    def test_cap_is_bytes_and_incomplete_evidence_is_retained(self):
        preparation = self.prepare(["1"])
        (self.root/"1").write_bytes(b"q"*80)
        result = self.collect(["1"],preparation,limit=16)
        self.assertFalse(result["complete"])
        self.assertEqual(result["files"][0]["total_bytes"],80)
        self.assertEqual(artifacts.read_files(result,["1"])["1"],b"q"*17)

    def test_review_different_well_formed_retained_nonce_is_refused(self):
        preparation = self.prepare(["1"])
        (self.root/"1").write_text("diagnostic")
        result = self.collect(["1"], preparation)
        result["nonce"] = "b"*32 if preparation["nonce"] != "b"*32 else "a"*32
        with self.assertRaisesRegex(artifacts.ArtifactError, "freshness receipt mismatch"):
            artifacts.read_files(result, ["1"])

    def test_review_post_command_hardlink_is_refused_even_after_valid_preparation(self):
        import os
        preparation = self.prepare(["1"])
        (self.root/"outside").write_text("shared")
        os.link(self.root/"outside", self.root/"1")
        result = self.run_script(artifacts.read_script(["1"], preparation))
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual((self.root/"outside").read_text(), "shared")

    def test_preparation_nonce_names_hashes_and_completeness_are_bound(self):
        preparation = self.prepare(["1"])
        (self.root/"1").write_text("diagnostic")
        result = self.collect(["1"],preparation)
        import copy
        for field in ("nonce","path","sha256","complete"):
            changed = copy.deepcopy(result)
            if field == "nonce":
                changed["preparation"]["nonce"] = "wrong"
            elif field == "path":
                changed["files"][0]["path"] = "different"
            elif field == "sha256":
                changed["files"][0]["sha256"] = "0"*64
            else:
                changed["complete"] = False
            with self.subTest(field=field):
                with self.assertRaises(artifacts.ArtifactError):
                    artifacts.read_files(changed,["1"])

if __name__ == "__main__":
    unittest.main()
