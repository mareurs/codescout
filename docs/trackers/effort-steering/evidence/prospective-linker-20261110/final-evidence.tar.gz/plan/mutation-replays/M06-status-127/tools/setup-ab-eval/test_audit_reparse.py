"""Audit-only tests use the dataset parser verbatim; no native/paid task runs."""
import json
import unittest
from pathlib import Path

import audit_reparse as audit

RECORD = json.loads((Path(__file__).parent / "fixtures/multilang/rust_concat_record.json").read_text())
SUITE = "target/debug/deps/tests-b7e6894743b0a1f5"
RUNNING = "Running tests/main.rs (" + SUITE + ")\n"
BARE = "last_result::bare_external_with_inherited_stdout_does_not_capture"
BAD = "last_result::mixed_str_length_result_does_replace_last"
GLUED = "should_not_overwrite_lasttest " + BARE + " ... ok\n"


class ReparseTests(unittest.TestCase):
    def test_split_retains_exact_stdout_prefix_and_line_identity(self):
        text, splits = audit.split_concatenated_status("header\n" + GLUED)
        self.assertEqual(text, "header\nshould_not_overwrite_last\ntest " + BARE + " ... ok\n")
        self.assertEqual(len(splits), 1)
        self.assertEqual(splits[0]["line"], 2)
        self.assertEqual(splits[0]["prefix"], "should_not_overwrite_last")
        self.assertEqual(splits[0]["status_line"], "test " + BARE + " ... ok")

    def test_recovers_expected_pass_without_hiding_real_failure(self):
        log = RUNNING + "test " + BAD + " ... FAILED\n" + GLUED
        result = audit.reparse(RECORD, log, [SUITE + "::" + BARE], [SUITE + "::" + BAD])
        self.assertEqual((result["original"]["missing"], result["adjusted"]["missing"]), (1, 0))
        self.assertEqual(result["adjusted"]["not_passing"], 1)
        self.assertIs(result["adjusted"]["pass"], False)
        self.assertEqual(result["adjusted"]["examples"], [SUITE + "::" + BAD])
        self.assertEqual(result["recovered"], [{"key": SUITE + "::" + BARE, "status": "pass",
                                              "line": 3, "raw": GLUED.rstrip("\n")}])

    def test_expected_identity_includes_binary_not_only_test_name(self):
        log = "Running tests/main.rs (other-binary)\n" + GLUED
        result = audit.reparse(RECORD, log, [SUITE + "::" + BARE], [])
        self.assertEqual(result["adjusted"]["missing"], 1)
        self.assertEqual(result["recovered"], [])

    def test_does_not_recover_an_unexpected_name(self):
        result = audit.reparse(RECORD, RUNNING + GLUED, [SUITE + "::" + BAD], [])
        self.assertEqual(result["recovered"], [])
        self.assertEqual(result["adjusted"], result["original"])

    def test_glued_failure_beats_an_earlier_ok(self):
        log = RUNNING + "test " + BARE + " ... ok\nprefixtest " + BARE + " ... FAILED\n"
        result = audit.reparse(RECORD, log, [SUITE + "::" + BARE], [])
        self.assertTrue(result["original"]["pass"])
        self.assertFalse(result["adjusted"]["pass"])
        self.assertEqual(result["recovered"][0]["status"], "fail")

    def test_glued_pass_never_overwrites_an_earlier_failure(self):
        log = RUNNING + "test " + BARE + " ... FAILED\n" + GLUED
        result = audit.reparse(RECORD, log, [SUITE + "::" + BARE], [])
        self.assertFalse(result["adjusted"]["pass"])
        self.assertEqual(result["recovered"], [])

    def test_ansi_and_carriage_return_statuses_already_parsed_are_not_recovered(self):
        # Each prefix has visible text or an escape, so the audit reports a split; the record
        # parser already reads the status, so nothing may count as recovered.
        for prefix in ("\x1b[32m", "progress 50%\r", "    "):
            with self.subTest(prefix=prefix):
                log = RUNNING + prefix + "test " + BARE + " ... ok\n"
                result = audit.reparse(RECORD, log, [SUITE + "::" + BARE], [])
                self.assertTrue(result["original"]["pass"])
                self.assertEqual(result["adjusted"], result["original"])
                self.assertEqual(result["recovered"], [])

    def test_split_line_numbers_count_newlines_only(self):
        text, splits = audit.split_concatenated_status("progress 1\rprogress 2\n" + GLUED)
        self.assertEqual([s["line"] for s in splits], [2])
        self.assertEqual(text, "progress 1\rprogress 2\nshould_not_overwrite_last\ntest " + BARE + " ... ok\n")

    def test_a_glued_status_on_an_unterminated_last_line_is_split_and_recovered(self):
        log = RUNNING + GLUED.rstrip("\n")
        text, splits = audit.split_concatenated_status(log)
        self.assertEqual(text, RUNNING + "should_not_overwrite_last\ntest " + BARE + " ... ok")
        self.assertEqual([(s["line"], s["prefix"]) for s in splits], [(2, "should_not_overwrite_last")])
        result = audit.reparse(RECORD, log, [SUITE + "::" + BARE], [])
        self.assertEqual((result["original"]["missing"], result["adjusted"]["missing"]), (1, 0))
        self.assertEqual([(r["key"], r["line"]) for r in result["recovered"]], [(SUITE + "::" + BARE, 2)])

    def test_split_reports_a_status_that_follows_visible_text_and_a_carriage_return(self):
        # The audit reports every glued status on a physical line, including a CR-redrawn one.
        # `reparse` then counts it as recovered only when the record parser had missed it.
        text, splits = audit.split_concatenated_status("progress 50%\rtest " + BARE + " ... ok\n")
        self.assertEqual([(s["line"], s["prefix"]) for s in splits], [(1, "progress 50%\r")])
        self.assertEqual(text, "progress 50%\r\ntest " + BARE + " ... ok\n")

    def test_recovered_line_counts_newlines_only(self):
        log = "progress 1\rprogress 2\n" + RUNNING + GLUED
        result = audit.reparse(RECORD, log, [SUITE + "::" + BARE], [])
        self.assertEqual([r["line"] for r in result["recovered"]], [3])

    def test_multiple_suites_do_not_misattribute_same_test_name(self):
        log = RUNNING + GLUED + "Running tests/main.rs (other-binary)\n" + GLUED
        result = audit.reparse(RECORD, log, [SUITE + "::" + BARE, "other-binary::" + BARE], [])
        self.assertTrue(result["adjusted"]["pass"])
        self.assertEqual([(r["key"], r["line"]) for r in result["recovered"]],
                         [(SUITE + "::" + BARE, 2), ("other-binary::" + BARE, 4)])


    def test_header_context_change_does_not_misattribute_ordinary_status(self):
        log = ("Running tests/main.rs (binary-b)test first ... ok\n"
               "test ordinary ... ok\noutputtest second ... ok\n")
        result = audit.reparse(RECORD, log,
                              ["binary-b::first", "binary-b::ordinary", "binary-b::second"], [])
        self.assertEqual(result["adjusted"]["missing"], 1)
        self.assertFalse(result["adjusted"]["pass"])
        self.assertEqual([(r["key"], r["line"], r["raw"]) for r in result["recovered"]],
                         [("binary-b::first", 1, log.splitlines()[0]),
                          ("binary-b::second", 3, log.splitlines()[2])])

    def test_expected_p2p_pass_is_recovered(self):
        result = audit.reparse(RECORD, RUNNING + GLUED, [], [SUITE + "::" + BARE])
        self.assertEqual(result["original"]["missing"], 1)
        self.assertTrue(result["adjusted"]["pass"])
        self.assertEqual(result["recovered"], [{"key": SUITE + "::" + BARE, "status": "pass",
                                              "line": 2, "raw": GLUED.rstrip("\n")}])

    def test_original_failure_guard_independent_of_record_parser_severity(self):
        # Alternate unchanged record parser intentionally uses last observation; removing
        # the audit's own failure guard must still be caught even when the dataset does not help.
        parser = RECORD["log_parser"]
        needle = "if previous is None or ranks[status] > ranks[previous]:"
        self.assertEqual(parser.count(needle), 1)
        alternate = dict(RECORD, log_parser=parser.replace(needle, "if True:"))
        result = audit.reparse(alternate, RUNNING + "test " + BARE + " ... FAILED\n" + GLUED,
                               [SUITE + "::" + BARE], [])
        self.assertFalse(result["adjusted"]["pass"])
        self.assertEqual(result["recovered"], [])

    def test_nonterminal_status_substring_is_not_split(self):
        log = "prefixtest " + BARE + " ... ok trailing noise\n"
        self.assertEqual(audit.split_concatenated_status(log), (log, []))

    def test_ansi_only_prefix_is_not_a_glued_stdout_prefix(self):
        for prefix in ("\x1b[32m", "\x1b[0m\x1b[31m"):
            with self.subTest(prefix=prefix):
                log = prefix + "test " + BARE + " ... ok\n"
                self.assertEqual(audit.split_concatenated_status(log), (log, []))
