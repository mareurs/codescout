"""Real-shell production wiring of fresh redirected diagnostics."""
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest import mock

import diagnostic_artifacts as artifacts
import multilang_control as control
import grade_policy as policy
import multilang_grade as grade
from test_stream_evidence import contract
from test_grade_policy import PARSER, OK

class ArtifactControlTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        subprocess.run(["git","init","-q",str(self.root)],check=True)
        self.steps = []

    def local_exec(self, container, workdir, *args, **kwargs):
        self.assertEqual(container,"owned")
        self.assertEqual(workdir,str(self.root))
        return subprocess.run(args,cwd=self.root,input=kwargs.get("data"),capture_output=True,
                              text=True,timeout=kwargs.get("timeout"),env=dict(os.environ,TMPDIR=str(self.root)))

    def run_record(self, command, *, paths=None):
        record = {"test_cmds":[command],"print_cmds":["printf 'test f ... ok\\n'"]}
        with mock.patch.object(control,"_exec",side_effect=self.local_exec):
            return control.run_tests("owned",str(self.root),record,10,steps=self.steps,state="grade",
                                     capture_streams=True,diagnostic_artifacts={0:["1"]} if paths is None else paths)

    def test_frozen_redirect_shape_retains_fresh_file_stderr_and_exit(self):
        (self.root/"1").write_text("stale")
        log = self.run_record("(printf 'compiler stderr\\n' >&2; exit 101) 2>1")
        self.assertEqual(log,"test f ... ok\n")
        self.assertEqual([s["name"] for s in self.steps],["grade:test[0]","grade:print[0]"])
        self.assertEqual(self.steps[0]["returncode"],101)
        proof = self.steps[0]["artifacts"]
        self.assertTrue(proof["complete"])
        self.assertEqual(artifacts.read_files(proof,["1"]),{"1":b"compiler stderr\n"})

    def test_preparation_failure_prevents_test_execution(self):
        (self.root/"1").write_text("tracked")
        subprocess.run(["git","add","--","1"],cwd=self.root,check=True)
        with self.assertRaisesRegex(control.ControlError,"artifact"):
            self.run_record("touch ran; printf new >1")
        self.assertFalse((self.root/"ran").exists())
        self.assertEqual((self.root/"1").read_text(),"tracked")
        self.assertEqual(self.steps,[])

    def test_missing_file_after_test_preserves_test_step_and_refuses_print(self):
        with self.assertRaisesRegex(control.ControlError,"artifact"):
            self.run_record("true")
        self.assertEqual([s["name"] for s in self.steps],["grade:test[0]"])

    def test_over_cap_snapshot_is_retained_before_control_refusal(self):
        with mock.patch.object(artifacts,"MAX_BYTES",16):
            with self.assertRaisesRegex(control.ControlError,"artifact"):
                self.run_record("python3 -c \"open('1','wb').write(b'q'*80)\"")
        self.assertFalse(self.steps[0]["artifacts"]["complete"])
        self.assertEqual(self.steps[0]["artifacts"]["files"][0]["total_bytes"],80)

    def test_collected_real_stderr_reaches_prospective_verdict_and_cannot_be_dropped(self):
        command = "(printf 'error[E0425]: missing y\\n --> src/lib.rs:3:5\\n' >&2; exit 101) 2>1"
        log = self.run_record(command)
        record = {"rebuild_cmds": [], "test_cmds": [command],
                  "print_cmds": ["printf 'test f ... ok\\n'"], "log_parser": PARSER,
                  "FAIL_TO_PASS": ["unknown::f"], "PASS_TO_PASS": []}
        bundle = {"expected": {"fail_to_pass": 1, "pass_to_pass_kept": 0, "dropped": []}}
        raw = dict(grade.verdict(grade.run_parser(PARSER, log), ["unknown::f"], []),
                   oom_killed=False, container_removed=True)
        full = dict(raw, steps=self.steps)
        registered = contract(record, profile="libtest-rustc-1.97.1-lib")
        registered["tests"][0]["stderr_files"] = ["1"]
        result = policy.adjudicate_streams(raw, full, record, bundle, log=log, runtime=OK,
                                         registered=registered)
        self.assertTrue(result["valid"], result)
        self.assertFalse(result["pass"])
        self.assertEqual(result["kind"], "compile_failure")
        del self.steps[0]["artifacts"]
        result = policy.adjudicate_streams(raw, full, record, bundle, log=log, runtime=OK,
                                         registered=registered)
        self.assertFalse(result["valid"], result)
        self.assertIn("artifact", result["error"])

    def test_merged_transport_preparation_error_keeps_the_actual_diagnostic(self):
        from types import SimpleNamespace
        (self.root/"1").write_text("tracked")
        subprocess.run(["git", "add", "--", "1"], cwd=self.root, check=True)
        original = self.local_exec
        def merged(*args, **kwargs):
            result = original(*args, **kwargs)
            return SimpleNamespace(returncode=result.returncode, stdout=result.stdout+result.stderr, stderr=None)
        with mock.patch.object(self, "local_exec", side_effect=merged):
            with self.assertRaisesRegex(control.ControlError, "tracked or git check failed"):
                self.run_record("true")

    def test_merged_transport_snapshot_error_keeps_the_actual_diagnostic(self):
        from types import SimpleNamespace
        original = self.local_exec
        def merged(*args, **kwargs):
            result = original(*args, **kwargs)
            return SimpleNamespace(returncode=result.returncode, stdout=result.stdout+result.stderr, stderr=None)
        with mock.patch.object(self, "local_exec", side_effect=merged):
            with self.assertRaisesRegex(control.ControlError, "No such file or directory"):
                self.run_record("true")

    def test_review_failed_preparation_with_a_valid_receipt_cannot_start_test(self):
        original = self.local_exec
        def failed_receipt(*args, **kwargs):
            result = original(*args, **kwargs)
            if '"prepared":true' in result.stdout.replace(" ", ""):
                result.returncode = 1
            return result
        with mock.patch.object(self, "local_exec", side_effect=failed_receipt):
            with self.assertRaisesRegex(control.ControlError, "preparation failed"):
                self.run_record("printf fresh >1; touch ran")
        self.assertFalse((self.root/"ran").exists())

    def test_wrong_or_unbound_mapping_is_refused_before_command_runs(self):
        for mapping in ({1:["1"]},{True:["1"]},{0:[]},{0:["../bad"]},[]):
            with self.subTest(mapping=mapping):
                with self.assertRaises(control.ControlError):
                    self.run_record("touch ran",paths=mapping)
                self.assertFalse((self.root/"ran").exists())

if __name__ == "__main__":
    unittest.main()
