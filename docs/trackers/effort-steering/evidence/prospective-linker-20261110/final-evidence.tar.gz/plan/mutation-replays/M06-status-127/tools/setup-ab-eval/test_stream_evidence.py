"""Prospective evidence qualification: complete streams, authenticated test payloads, exact commands."""
import base64
import copy
import json
from pathlib import Path
import unittest

import command_capture as capture
import stream_evidence as evidence

FIXTURES = Path(__file__).parent / "fixtures/stream-provenance"
NATIVE_LOG = (FIXTURES / "nextest-0.9.128.jsonl").read_text()
NATIVE_ERR = (FIXTURES / "nextest-0.9.128.stderr").read_text()
RECORD = {"rebuild_cmds": [], "test_cmds": ["cargo nextest run > reports/log"],
          "print_cmds": ["cat reports/log"]}

def stream(out="", err="", code=0, *, limit=capture.MAX_BYTES):
    out, err = out.encode(), err.encode()
    wire = {"version": capture.VERSION, "returncode": code, "process_returncode": code,
            "open_streams": 0, "stdout": base64.b64encode(out).decode(),
            "stderr": base64.b64encode(err).decode(), "stdout_bytes": len(out), "stderr_bytes": len(err)}
    return capture.decode(json.dumps(wire), code, limit)

def step(name, out="", err="", code=0):
    result = stream(out, err, code)
    return {"name": name, "returncode": code, "tail": result["tail"], "capture": result}

def contract(record=RECORD, *, profile="nextest-0.9.128-combined", reports=None):
    return {"version": evidence.VERSION, "commands_sha256": evidence.commands_digest(record),
            "tests": [{"profile": profile, "reports": [0] if reports is None else reports,
                       "stderr_files": []}]}

def fixture(log=NATIVE_LOG, err=NATIVE_ERR):
    return {"steps": [step("grade:test[0]", err=err, code=100),
                      step("grade:print[0]", out=log)]}

class EvidenceTests(unittest.TestCase):
    def qualify(self, full=None, *, log=NATIVE_LOG, record=RECORD, registered=None):
        return evidence.qualify(fixture() if full is None else full, record, log,
                                contract(record) if registered is None else registered)

    def test_actual_nextest_payload_is_removed_but_runner_summary_survives(self):
        result = self.qualify()
        text = result["grade:test[0]"]
        self.assertNotIn("planted compiler diagnostic", text)
        self.assertNotIn("No space left on device", text)
        self.assertNotIn("terminated with signal", text)
        self.assertNotIn("output ─", text)
        self.assertIn("Summary", text)
        self.assertIn("error: test run failed", text)
        self.assertEqual(result["grade:print[0]"], "")

    def test_top_level_fault_after_captured_payload_is_retained(self):
        for fault in ("error: No space left on device (os error 28)",
                      "error[E0425]: cannot find value y\n --> src/lib.rs:3:5",
                      "rustc: fatal error: terminated with signal 9",
                      "    warning: No space left on device"):
            with self.subTest(fault=fault):
                full = fixture(err=NATIVE_ERR + fault + "\n")
                self.assertIn(fault, self.qualify(full)["grade:test[0]"])

    def test_legacy_or_unclosed_or_unbound_capture_is_refused(self):
        for text in ("--- STDERR: p t ---\nboom\n------------\nSummary\n",
                     "---- f stdout ----\nboom\n",
                     "  output ───\n\n    unknown\nSummary\n",
                     "  stdout ───\n\n    unknown\nSummary\n",
                     "  stderr ───\n\n    unknown\nSummary\n"):
            with self.subTest(text=text):
                with self.assertRaises(evidence.EvidenceError):
                    self.qualify(fixture(err=text))

    def test_cut_tails_are_never_used_to_classify(self):
        full = fixture()
        self.assertGreater(len(full["steps"][0]["capture"]["stderr"]["base64"]), 4096)
        self.assertIn("terminated with signal", full["steps"][0]["tail"])
        self.assertNotIn("terminated with signal", self.qualify(full)["grade:test[0]"])
        # A different outside tail contradicts its complete capture and is refused.
        full["steps"][0]["tail"] = "error: injected tail"
        with self.assertRaises(evidence.EvidenceError):
            self.qualify(full)

    def test_missing_corrupt_incomplete_or_returncode_inconsistent_capture_is_refused(self):
        mutations = [
            lambda s: s.pop("capture"),
            lambda s: s["capture"]["stderr"].update(sha256="0"*64),
            lambda s: s["capture"].update(complete=False),
            lambda s: s.update(returncode=0),
            lambda s: s.update(truncated=True),
            lambda s: s["capture"].update(open_streams=1),
        ]
        for mutate in mutations:
            with self.subTest(mutate=mutate):
                full = fixture()
                mutate(full["steps"][0])
                with self.assertRaises(evidence.EvidenceError):
                    self.qualify(full)

    def test_print_outputs_and_order_must_reproduce_the_entire_log(self):
        record = dict(RECORD, print_cmds=["cat a", "cat b"])
        split = NATIVE_LOG.index("\n") + 1
        full = {"steps":[step("grade:test[0]", err=NATIVE_ERR, code=100),
                         step("grade:print[0]", out=NATIVE_LOG[:split]),
                         step("grade:print[1]", out=NATIVE_LOG[split:])]}
        registered = contract(record, reports=[0, 1])
        self.assertNotIn("planted compiler", self.qualify(full, record=record, registered=registered)["grade:test[0]"])
        for changed in (full["steps"][:-1], [full["steps"][0], full["steps"][2], full["steps"][1]]):
            with self.subTest(changed=changed):
                with self.assertRaises(evidence.EvidenceError):
                    self.qualify({"steps":changed}, record=record, registered=registered)
        with self.assertRaises(evidence.EvidenceError):
            self.qualify(full, log=NATIVE_LOG+"extra", record=record, registered=registered)
        bad = copy.deepcopy(full)
        bad["steps"][1] = step("grade:print[0]", out=NATIVE_LOG[:split], err="unexpected")
        with self.assertRaises(evidence.EvidenceError):
            self.qualify(bad, record=record, registered=registered)

    def test_each_test_gets_only_its_registered_report_and_diagnostics(self):
        record = dict(RECORD, test_cmds=["nextest one > a", "nextest two > b"],
                      print_cmds=["cat a", "cat b"])
        full = {"steps":[step("grade:test[0]", err=NATIVE_ERR, code=100),
                         step("grade:test[1]", err="error[E0425]: missing\n --> src/b.rs:1:1\n", code=101),
                         step("grade:print[0]", out=NATIVE_LOG), step("grade:print[1]")]}
        registered = contract(record)
        registered["tests"].append({"profile":"nextest-0.9.128-combined","reports":[1],"stderr_files":[]})
        result = self.qualify(full, record=record, registered=registered)
        self.assertNotIn("planted", result["grade:test[0]"])
        self.assertIn("src/b.rs", result["grade:test[1]"])
        for reports in ([0], [], [2], [True]):
            bad = copy.deepcopy(registered)
            bad["tests"][1]["reports"] = reports
            with self.subTest(reports=reports):
                with self.assertRaises(evidence.EvidenceError):
                    self.qualify(full, record=record, registered=bad)

    def test_exact_commands_version_and_profile_are_required(self):
        for key, value in (("version", "unknown"), ("commands_sha256", "0"*64),
                           ("tests", []), ("tests", None)):
            registered = contract()
            registered[key] = value
            with self.subTest(key=key):
                with self.assertRaises(evidence.EvidenceError):
                    self.qualify(registered=registered)
        for profile in ("nextest-0.9.127-combined", "unmeasured", None):
            with self.subTest(profile=profile):
                with self.assertRaises(evidence.EvidenceError):
                    self.qualify(registered=contract(profile=profile))
        changed = dict(RECORD, test_cmds=["different command"])
        with self.assertRaises(evidence.EvidenceError):
            self.qualify(record=changed, registered=contract())

    def test_both_profiles_refuse_undeclared_missing_diagnostic_artifact_support(self):
        registered = contract(profile="libtest-rustc-1.97.1-lib")
        registered["tests"][0]["stderr_files"] = ["rust/1"]
        with self.assertRaisesRegex(evidence.EvidenceError, "artifact"):
            self.qualify(registered=registered)

    def test_libtest_profile_keeps_stderr_and_does_not_scan_test_stdout(self):
        log = "test f ... ok\n---- other stdout ----\nNo space left on device\n"
        record = dict(RECORD, test_cmds=["cargo test --lib > reports/log"])
        full = {"steps":[step("grade:test[0]", out=log, err="compiler stderr", code=101),
                         step("grade:print[0]", out=log)]}
        registered = contract(record, profile="libtest-rustc-1.97.1-lib")
        result = self.qualify(full, log=log, record=record, registered=registered)
        self.assertEqual(result["grade:test[0]"], "compiler stderr")
        # Unframed stderr captures violate this declared --lib execution profile.
        full["steps"][0] = step("grade:test[0]", err="---- f stdout ----\nNo space left on device")
        with self.assertRaises(evidence.EvidenceError):
            self.qualify(full, log=log, record=record, registered=registered)

    def test_rebuild_stdout_is_host_evidence_and_cannot_borrow_test_payloads(self):
        record = dict(RECORD, rebuild_cmds=["cargo build"])
        full = fixture()
        full["steps"].insert(0, step("grade:rebuild", out="error: No space left on device", code=101))
        self.assertIn("No space left", self.qualify(full, record=record)["grade:rebuild"])

    def test_payload_or_header_contradiction_and_duplicate_display_are_refused(self):
        for err in (NATIVE_ERR.replace("planted compiler diagnostic", "different text"),
                    NATIVE_ERR+NATIVE_ERR):
            with self.subTest(err=err[-50:]):
                with self.assertRaises(evidence.EvidenceError):
                    self.qualify(fixture(err=err))

    def test_complete_ansi_and_crlf_normalization_preserves_payload_boundary(self):
        err = NATIVE_ERR.replace("error[E0425]", "\x1b[38;5;9merror[E0425]\x1b[0m")
        result = self.qualify(fixture(err=err.replace("\n","\r\n")))
        self.assertNotIn("planted", result["grade:test[0]"])
        self.assertIn("Summary", result["grade:test[0]"])

    def test_unexpected_nextest_stdout_is_not_silently_ignored(self):
        full = fixture()
        full["steps"][0] = step("grade:test[0]", out="error: No space left on device", err=NATIVE_ERR, code=100)
        with self.assertRaises(evidence.EvidenceError):
            self.qualify(full)

    def test_review_coherent_incomplete_command_capture_reaches_completeness_guard(self):
        import base64
        record = dict(RECORD, test_cmds=["cargo test --lib > report"])
        log = "test f ... ok\n"
        wire = {"version":capture.VERSION, "returncode":0, "process_returncode":0, "open_streams":0,
                "stdout":"", "stderr":base64.b64encode(b"x"*17).decode(),
                "stdout_bytes":0, "stderr_bytes":80}
        stored = capture.decode(json.dumps(wire), 0, 16)
        full = {"steps":[{"name":"grade:test[0]", "returncode":0, "tail":stored["tail"], "capture":stored},
                         step("grade:print[0]",out=log)]}
        with self.assertRaisesRegex(evidence.EvidenceError, "complete"):
            self.qualify(full, log=log, record=record,
                         registered=contract(record,profile="libtest-rustc-1.97.1-lib"))

    def test_review_unused_empty_print_is_not_a_complete_report_partition(self):
        record = dict(RECORD, test_cmds=["cargo test --lib > report"],
                      print_cmds=["cat report", "printf empty"])
        log = "test f ... ok\n"
        full = {"steps":[step("grade:test[0]"), step("grade:print[0]",out=log), step("grade:print[1]")]}
        with self.assertRaisesRegex(evidence.EvidenceError, "reports are missing"):
            self.qualify(full, log=log, record=record,
                         registered=contract(record,profile="libtest-rustc-1.97.1-lib"))

    def test_review_header_cannot_authorize_a_nonadjacent_payload(self):
        err = NATIVE_ERR.replace("    running 1 test\n", "    running 1 test\n\nHOST INSERTION\n", 1)
        with self.assertRaisesRegex(evidence.EvidenceError, "adjacent"):
            self.qualify(fixture(err=err))

    def test_review_unknown_frame_after_authentic_payload_is_not_ignored(self):
        for header in ("  output ───", "  stdout ───", "  stderr ───", "--- STDERR: p t ---"):
            with self.subTest(header=header):
                err = NATIVE_ERR+header+"\n\n    unknown payload\n"
                with self.assertRaisesRegex(evidence.EvidenceError, "unbound or legacy"):
                    self.qualify(fixture(err=err))

    def test_review_libtest_stdout_must_match_its_bound_report(self):
        record = dict(RECORD, test_cmds=["cargo test --lib > report"])
        log = "test f ... ok\n"
        full = {"steps":[step("grade:test[0]",out="different report"), step("grade:print[0]",out=log)]}
        with self.assertRaisesRegex(evidence.EvidenceError, "stdout contradicts"):
            self.qualify(full, log=log, record=record,
                         registered=contract(record,profile="libtest-rustc-1.97.1-lib"))

    def test_review_coherent_incomplete_artifact_is_refused_at_qualification(self):
        import base64
        import diagnostic_artifacts as artifacts
        record = dict(RECORD, test_cmds=["cargo test --lib > report"])
        log = "test f ... ok\n"
        preparation = {"version":artifacts.VERSION,"nonce":"a"*32,"paths":["1"],"prepared":True}
        raw = b"x"*17
        payload = {"version":artifacts.VERSION,"nonce":"a"*32,
                   "files":[{"path":"1","base64":base64.b64encode(raw).decode(),"bytes":17,
                             "total_bytes":80,"sha256":__import__("hashlib").sha256(raw).hexdigest()}]}
        proof = artifacts.decode(json.dumps(payload),preparation,["1"],limit_bytes=16)
        self.assertFalse(proof["complete"])
        full = {"steps":[dict(step("grade:test[0]"),artifacts=proof),step("grade:print[0]",out=log)]}
        registered = contract(record,profile="libtest-rustc-1.97.1-lib")
        registered["tests"][0]["stderr_files"] = ["1"]
        with self.assertRaisesRegex(evidence.EvidenceError, "artifact capture incomplete"):
            self.qualify(full, log=log, record=record, registered=registered)

    def test_json_duplicate_keys_and_unrecognized_stream_fields_are_refused(self):
        log = '{"type":"test","event":"failed","name":"f","stdout":"first","stdout":"second"}\n'
        with self.assertRaises(evidence.EvidenceError):
            self.qualify(fixture(log=log, err=""), log=log)
        full = fixture()
        full["steps"][0]["capture"]["extra"] = True
        with self.assertRaises(evidence.EvidenceError):
            self.qualify(full)

if __name__ == "__main__":
    unittest.main()
