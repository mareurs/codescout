"""Selected verdicts through complete production-shaped stream evidence; legacy F3 unchanged."""
import copy
import json
import unittest

import grade_policy as policy
import multilang_grade as grade
from test_stream_evidence import (NATIVE_ERR, NATIVE_LOG, RECORD, contract, fixture, step)
from test_grade_policy import OK, PARSER, PASS_LOG, FAIL_LOG

JSON_PARSER = """def parser(log):
    import json
    result = {}
    for line in log.splitlines():
        event = json.loads(line)
        if event.get('type') == 'test' and event.get('event') in ('ok', 'failed', 'ignored'):
            value = {'ok':'pass','failed':'fail','ignored':'skip'}[event['event']]
            key = event['name']
            if result.get(key) != 'fail':
                result[key] = value
    return result
"""
SELECTED = "stream_probe::stream_probe$selected_pass"
FAILED = "stream_probe::stream_probe$captured_failure"
BUNDLE = {"expected":{"fail_to_pass":1,"pass_to_pass_kept":0,"dropped":[]}}

def prepared(record, log, full):
    statuses = grade.run_parser(record["log_parser"], log)
    expected = record["FAIL_TO_PASS"]
    raw = dict(grade.verdict(statuses, expected, record["PASS_TO_PASS"]),
               oom_killed=False, container_removed=True)
    full = dict(full, **raw)
    return raw, full

class StreamPolicyTests(unittest.TestCase):
    def adjudicate(self, *, log=NATIVE_LOG, err=NATIVE_ERR, full=None, selected=SELECTED,
                   record=None, registered=None, runtime=OK):
        record = dict(RECORD, log_parser=JSON_PARSER, FAIL_TO_PASS=[selected], PASS_TO_PASS=[]) if record is None else record
        full = fixture(log, err) if full is None else full
        raw, full = prepared(record, log, full)
        return policy.adjudicate_streams(raw, full, record, BUNDLE, log=log, runtime=runtime,
                                         registered=contract(record) if registered is None else registered)

    def test_real_selected_pass_survives_unselected_failure_payload_and_cut_tail(self):
        result = self.adjudicate()
        self.assertTrue(result["valid"], result)
        self.assertTrue(result["pass"], result)
        self.assertEqual(result["kind"], "pass")
        self.assertEqual(result["statuses"], {SELECTED:"pass"})
        self.assertEqual(result["policy_version"], "semantic-stream-contract-v2")

    def test_real_selected_failure_stays_failure_despite_infra_words_in_payload(self):
        result = self.adjudicate(selected=FAILED)
        self.assertTrue(result["valid"], result)
        self.assertFalse(result["pass"])
        self.assertEqual(result["kind"], "test_failure")
        self.assertEqual(result["statuses"], {FAILED:"fail"})

    def test_top_level_storage_and_toolchain_fatal_after_payload_are_invalid(self):
        for fault in ("error: No space left on device (os error 28)",
                      "rustc: fatal error: terminated with signal 9",
                      "open /tmp/compiler.tmp: Permission denied",
                      "    warning: No space left on device"):
            with self.subTest(fault=fault):
                result = self.adjudicate(err=NATIVE_ERR+fault+"\n")
                self.assertFalse(result["valid"], result)
                self.assertEqual(result["kind"], "measurement_invalid")

    def test_top_level_compile_after_payload_overrides_stale_selected_pass(self):
        full = fixture(err=NATIVE_ERR+"error[E0425]: missing y\n --> src/lib.rs:3:5\n")
        full["steps"][0] = step("grade:test[0]", err=NATIVE_ERR+"error[E0425]: missing y\n --> src/lib.rs:3:5\n", code=101)
        result = self.adjudicate(full=full)
        self.assertTrue(result["valid"], result)
        self.assertFalse(result["pass"])
        self.assertEqual(result["kind"], "compile_failure")

    def test_real_compiler_error_without_any_report_status_is_compile_failure(self):
        full = fixture(log="", err="error[E0425]: missing y\n --> src/lib.rs:3:5\n")
        result = self.adjudicate(log="", full=full)
        self.assertTrue(result["valid"], result)
        self.assertFalse(result["pass"])
        self.assertEqual(result["kind"], "compile_failure")

    def test_missing_test_without_compiler_keeps_f3_invalid_policy(self):
        full = fixture(log="", err="candidate binary aborted")
        result = self.adjudicate(log="", full=full)
        self.assertFalse(result["valid"], result)
        self.assertIn("expected statuses missing", result["error"])

    def test_libtest_captured_error_text_never_revokes_selected_pass_or_failure(self):
        for log in (PASS_LOG, FAIL_LOG):
            for data in ("error[E0308]: mismatched types\n --> tests/ui/x.rs:3:5",
                         "write failed: No space left on device",
                         "rustc: fatal error: terminated with signal 9"):
                with self.subTest(log=log, data=data):
                    log = log+"---- other stdout ----\n"+data+"\ntest result: FAILED. 1 passed; 1 failed;\n"
                    record = dict(RECORD, test_cmds=["cargo test --lib > reports/log"], log_parser=PARSER,
                                  FAIL_TO_PASS=["bin::f"], PASS_TO_PASS=["bin::p"])
                    full = {"steps":[step("grade:test[0]", out=log, code=101),
                                     step("grade:print[0]", out=log)]}
                    result = self.adjudicate(log=log, full=full, record=record,
                        registered=contract(record, profile="libtest-rustc-1.97.1-lib"))
                    self.assertTrue(result["valid"], result)
                    self.assertEqual(result["pass"], "test f ... ok" in log, result)

    def test_capture_corruption_contract_mismatch_and_runtime_floor_cannot_pass(self):
        for index in range(4):
            full = fixture()
            registered = contract(dict(RECORD, log_parser=JSON_PARSER))
            runtime = copy.deepcopy(OK)
            if index == 0:
                full["steps"][0].pop("capture")
            elif index == 1:
                full["steps"][0]["capture"]["stderr"]["sha256"] = "0"*64
            elif index == 2:
                registered["commands_sha256"] = "0"*64
            else:
                runtime["cgroup_probes"] = 1
            with self.subTest(index=index):
                result = self.adjudicate(full=full, registered=registered, runtime=runtime)
                self.assertFalse(result["valid"], result)
                self.assertFalse(result["pass"])

    def test_multiple_print_commands_use_their_registered_complete_parts(self):
        record = dict(RECORD, log_parser=JSON_PARSER, FAIL_TO_PASS=[FAILED], PASS_TO_PASS=[],
                      print_cmds=["cat first","cat second"])
        cut = NATIVE_LOG.index("\n")+1
        full = {"steps":[step("grade:test[0]", err=NATIVE_ERR, code=100),
                         step("grade:print[0]", out=NATIVE_LOG[:cut]),
                         step("grade:print[1]", out=NATIVE_LOG[cut:])]}
        result = self.adjudicate(record=record, full=full, registered=contract(record,reports=[0,1]))
        self.assertTrue(result["valid"], result)
        self.assertEqual(result["kind"], "test_failure")

    def test_source_excerpt_does_not_turn_compiler_failure_into_infra(self):
        err = "error[E0425]: missing y\n --> src/lib.rs:3:5\n3 | write failed: No space left on device\n"
        result = self.adjudicate(log="", full=fixture(log="",err=err))
        self.assertTrue(result["valid"], result)
        self.assertEqual(result["kind"], "compile_failure")

    def test_raw_and_full_terminal_and_verdict_metadata_must_match_with_exact_types(self):
        record = dict(RECORD, log_parser=JSON_PARSER, FAIL_TO_PASS=[SELECTED], PASS_TO_PASS=[])
        cases = [("oom_killed", True), ("oom_killed", 0), ("container_removed", False),
                 ("container_removed", 1), ("error", "transport failed"), ("infra", "oom"),
                 ("pass", 1), ("expected", True), ("not_passing", False), ("missing", False)]
        for key, value in cases:
            raw, full = prepared(record, NATIVE_LOG, fixture())
            full[key] = value
            with self.subTest(key=key, value=value):
                result = policy.adjudicate_streams(raw, full, record, BUNDLE, log=NATIVE_LOG,
                                                   runtime=OK, registered=contract(record))
                self.assertFalse(result["valid"], result)
                self.assertFalse(result["pass"])

    def test_a_directly_signaled_command_cannot_pass_even_with_complete_selected_status(self):
        import command_capture
        from test_stream_evidence import stream
        record = dict(RECORD, log_parser=JSON_PARSER, FAIL_TO_PASS=[SELECTED], PASS_TO_PASS=[])
        raw, full = prepared(record, NATIVE_LOG, fixture())
        stored = stream(err=NATIVE_ERR, code=137)
        stored["process_returncode"] = -9
        full["steps"][0].update(returncode=137, tail=stored["tail"], capture=stored)
        result = policy.adjudicate_streams(raw, full, record, BUNDLE, log=NATIVE_LOG,
                                           runtime=OK, registered=contract(record))
        self.assertFalse(result["valid"], result)
        self.assertIn("signal", result["error"])

    def test_uncollected_lean_diagnostic_file_is_never_silently_admitted(self):
        registered = contract()
        registered["tests"][0]["stderr_files"] = ["rust/1"]
        result = self.adjudicate(registered=registered)
        self.assertFalse(result["valid"], result)
        self.assertIn("artifact", result["error"])

    def linker_case(self, text, *, mode="test", code=101, log=""):
        record = dict(RECORD, log_parser=JSON_PARSER, FAIL_TO_PASS=[SELECTED], PASS_TO_PASS=[])
        if mode == "rebuild":
            record["rebuild_cmds"] = ["cargo build"]
            steps = [step("grade:rebuild", err=text, code=code),
                     step("grade:test[0]", code=0), step("grade:print[0]", out=log)]
        else:
            record["rebuild_cmds"] = []
            steps = [step("grade:test[0]", err=text, code=code), step("grade:print[0]", out=log)]
        return self.adjudicate(record=record, log=log, full={"steps": steps})

    def test_f6_ordinary_linker_failed_steps_are_compile_failures(self):
        text = "error: linking with `cc` failed: exit status: 1\n  = note: undefined reference to missing_symbol\n"
        for mode in ("rebuild", "test"):
            for code in (1, 101):
                with self.subTest(mode=mode, code=code):
                    result = self.linker_case(text, mode=mode, code=code)
                    self.assertTrue(result["valid"], result)
                    self.assertFalse(result["pass"])
                    self.assertEqual(result["kind"], "compile_failure")
                    self.assertEqual(result["statuses"], {})
                    self.assertEqual(result["adjusted"]["missing"], 1)

    def test_f6_stale_selected_pass_is_not_a_link_success(self):
        log = json.dumps({"type": "test", "event": "ok", "name": SELECTED}) + "\n"
        for mode in ("rebuild", "test"):
            with self.subTest(mode=mode):
                result = self.linker_case("error: linking with `/usr/bin/clang` failed: exit status: 1\n",
                                          mode=mode, log=log)
                self.assertTrue(result["valid"], result)
                self.assertFalse(result["pass"])
                self.assertEqual(result["kind"], "compile_failure")
                self.assertEqual(result["statuses"], {SELECTED: "pass"})
                self.assertTrue(result["adjusted"]["pass"])

    def test_f6_successful_step_cannot_invent_compile_failure(self):
        log = json.dumps({"type": "test", "event": "ok", "name": SELECTED}) + "\n"
        result = self.linker_case("error: linking with `cc` failed: exit status: 1\n", code=0, log=log)
        self.assertTrue(result["valid"], result)
        self.assertTrue(result["pass"])
        self.assertEqual(result["kind"], "pass")

    def test_f6_captured_nextest_linker_payload_keeps_selected_verdict(self):
        payload = "error: linking with `cc` failed: exit status: 1\n"
        events = [{"type": "test", "event": "ok", "name": SELECTED},
                  {"type": "test", "event": "failed", "name": "unselected_fixture", "stdout": payload}]
        log = "".join(json.dumps(event) + "\n" for event in events)
        display = "output ───\n\n" + "\n".join("    " + line if line else "" for line in payload.split("\n"))
        result = self.linker_case(display, log=log)
        self.assertTrue(result["valid"], result)
        self.assertTrue(result["pass"])
        self.assertEqual(result["statuses"], {SELECTED: "pass"})

    def test_f6_fatal_or_storage_precedes_ordinary_linker_failure(self):
        header = "error: linking with `cc` failed: exit status: 1\n"
        for fault in ("rustc: fatal error: terminated with signal 9\n",
                      "error: No space left on device (os error 28)\n",
                      "open /tmp/object.o: Permission denied\n"):
            with self.subTest(fault=fault):
                result = self.linker_case(header + fault)
                self.assertFalse(result["valid"], result)
                self.assertEqual(result["kind"], "measurement_invalid")

    def test_f6_malformed_or_nonordinary_header_cannot_classify_missing_status(self):
        for text in ("prefix error: linking with `cc` failed: exit status: 1\n",
                     "error: linking with `cc` failed: exit status: 0\n",
                     "error: linking with `cc` failed: exit status: 137\n",
                     "error: linking with `cc` failed: exit status: 139\n",
                     "error: linking with `cc` failed: exit status: 1 trailing text\n",
                     "error: linking with `` failed: exit status: 1\n",
                     "3 | error: linking with `cc` failed: exit status: 1\n"):
            with self.subTest(text=text):
                result = self.linker_case(text)
                self.assertFalse(result["valid"], result)
                self.assertEqual(result["kind"], "measurement_invalid")

    def test_f6_legacy_replay_keeps_unclassified_linker_failure(self):
        record = dict(RECORD, log_parser=JSON_PARSER, FAIL_TO_PASS=[SELECTED], PASS_TO_PASS=[],
                      rebuild_cmds=["cargo build"])
        full = {"steps": [step("grade:rebuild", err="error: linking with `cc` failed: exit status: 1\n", code=1),
                          step("grade:test[0]"), step("grade:print[0]")]}
        raw, full = prepared(record, "", full)
        result = policy.adjudicate_private(raw, full, record, BUNDLE, log="", runtime=OK)
        self.assertFalse(result["valid"], result)
        self.assertIn("rebuild failed without a classified compiler diagnostic", result["error"])
        self.assertIsNone(policy.compiler_diagnostic("error: linking with `cc` failed: exit status: 1\n"))

    def test_f6_linker_scoping_rejects_data_and_ambiguous_post_capture(self):
        recognize = getattr(policy, "linker_diagnostic", None)
        self.assertIsNotNone(recognize, "prospective linker recognizer is absent")
        header = "error: linking with `cc` failed: exit status: 1"
        for text in ("---- fixture stdout ----\n" + header + "\n",
                     "--- STDERR: fixture ---\n" + header + "\n",
                     "output ───\n    " + header + "\n",
                     json.dumps({"type": "test", "stdout": header}) + "\n",
                     "7 | " + header + "\n"):
            with self.subTest(data=text):
                self.assertIsNone(recognize(text))
        for text in ("---- fixture stdout ----\ndata\ntest result: FAILED. 0 passed; 1 failed;\n" + header + "\n",
                     "output ───\n    data\n" + header + "\n"):
            with self.subTest(ambiguous=text), self.assertRaisesRegex(ValueError, "ambiguous provenance"):
                recognize(text)
        self.assertEqual(recognize("\x1b[31m" + header + "\x1b[0m\r\n"), header)

    def test_f6_non_lf_separators_cannot_create_physical_linker_header(self):
        header = "error: linking with `cc` failed: exit status: 1\n"
        passed = json.dumps({"type": "test", "event": "ok", "name": SELECTED}) + "\n"
        for mode in ("test", "rebuild"):
            for separator in "\r\v\f\x1c\x1d\x1e\x85\u2028\u2029":
                for prefix in ("7 | example", "ordinary prefix"):
                    for log in ("", passed):
                        with self.subTest(mode=mode, separator=repr(separator), prefix=prefix, log=log):
                            result = self.linker_case(prefix + separator + header, mode=mode, log=log)
                            # Bare CR is already refused by the complete-stream contract.
                            if mode == "test" and log and separator != "\r":
                                self.assertTrue(result["valid"], result)
                                self.assertTrue(result["pass"], result)
                                self.assertEqual(result["kind"], "pass")
                                self.assertEqual(result["statuses"], {SELECTED: "pass"})
                            else:
                                self.assertFalse(result["valid"], result)
                                self.assertEqual(result["kind"], "measurement_invalid")
        self.assertIsNone(policy.linker_diagnostic("7 | example\r" + header))
        self.assertEqual(policy.linker_diagnostic(header.replace("\n", "\r\n")), header.rstrip("\n"))

    def test_f6_whitespace_only_linker_command_is_not_affirmative_evidence(self):
        for mode in ("test", "rebuild"):
            for command in (" ", "   ", "\t", " \t ", "\u2003"):
                with self.subTest(mode=mode, command=repr(command)):
                    result = self.linker_case(
                        "error: linking with `" + command + "` failed: exit status: 1\n", mode=mode)
                    self.assertFalse(result["valid"], result)
                    self.assertEqual(result["kind"], "measurement_invalid")

    def test_f6_linker_exit_boundary_accepts_127_and_refuses_128(self):
        for mode in ("test", "rebuild"):
            for status in (126, 127, 128):
                with self.subTest(mode=mode, status=status):
                    result = self.linker_case(
                        "error: linking with `cc` failed: exit status: " + str(status) + "\n",
                        mode=mode, code=status)
                    self.assertEqual(result["valid"], status < 128, result)
                    self.assertFalse(result["pass"], result)
                    self.assertEqual(result["kind"], "compile_failure" if status < 128 else "measurement_invalid")

if __name__ == "__main__":
    unittest.main()
