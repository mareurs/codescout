"""Declared grader diagnostics: fresh untracked files only, bounded byte snapshots."""
import base64
import hashlib
import json
from pathlib import PurePosixPath
import re
import secrets
import shlex

VERSION = "diagnostic-artifacts-v1"
MAX_BYTES = 8 * 1024 * 1024

class ArtifactError(ValueError):
    pass

def _paths(paths):
    if (not isinstance(paths,list) or not 1 <= len(paths) <= 4
            or any(not isinstance(p,str) for p in paths) or len(set(paths)) != len(paths)):
        raise ArtifactError("one to four distinct diagnostic paths required")
    for path in paths:
        parsed = PurePosixPath(path)
        if (not path or parsed.is_absolute() or str(parsed) != path
                or any(x in (".","..",".git") for x in parsed.parts)
                or any(ord(x)<32 or ord(x)==127 for x in path)):
            raise ArtifactError("unsafe diagnostic path")
    return paths

def _limit(limit):
    if type(limit) is not int or not 0 < limit <= MAX_BYTES:
        raise ArtifactError("invalid artifact byte limit")
    return limit

_COMMON = r"""
import base64,hashlib,json,os,pathlib,stat,subprocess,sys
paths=json.loads(sys.argv[1])
nonce=sys.argv[2]
def safe(path):
    target=pathlib.Path(path)
    for parent in list(target.parents)[:-1]:
        if parent.is_symlink() or not parent.is_dir():
            raise ValueError("diagnostic parent not an ordinary directory")
    if target.is_symlink():
        raise ValueError("diagnostic target is a symlink")
    return target
"""
_PREPARE = _COMMON + r"""
targets=[]
for path in paths:
    target=safe(path)
    probe=subprocess.run(["git","ls-files","--error-unmatch","--",path],capture_output=True)
    if probe.returncode != 1:
        raise ValueError("diagnostic target is tracked or git check failed")
    if target.exists():
        st=target.lstat()
        if not stat.S_ISREG(st.st_mode) or st.st_nlink != 1:
            raise ValueError("diagnostic target is not an independent regular file")
    targets.append(target)
for target in targets:
    if target.exists():
        target.unlink()
print(json.dumps({"version":"diagnostic-artifacts-v1","nonce":nonce,"paths":paths,"prepared":True}))
"""
_READ = _COMMON + r"""
limit=int(sys.argv[3])
files=[]
for path in paths:
    target=safe(path)
    fd=os.open(target,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
    with os.fdopen(fd,"rb") as src:
        before=os.fstat(src.fileno())
        if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
            raise ValueError("diagnostic is not an independent regular file")
        raw=src.read(limit+1)
        after=os.fstat(src.fileno())
    if (before.st_ino,before.st_dev,before.st_size,before.st_mtime_ns,before.st_ctime_ns) != (
            after.st_ino,after.st_dev,after.st_size,after.st_mtime_ns,after.st_ctime_ns):
        raise ValueError("diagnostic changed during snapshot")
    files.append({"path":path,"base64":base64.b64encode(raw).decode(),"bytes":len(raw),
                  "total_bytes":before.st_size,"sha256":hashlib.sha256(raw).hexdigest()})
print(json.dumps({"version":"diagnostic-artifacts-v1","nonce":nonce,"files":files}))
"""

def prepare_script(paths):
    _paths(paths)
    nonce = secrets.token_hex(16)
    return "python3 -c "+shlex.quote(_PREPARE)+" "+shlex.quote(json.dumps(paths))+" "+nonce

def prepared(payload, paths):
    _paths(paths)
    try:
        result = json.loads(payload)
        if (not isinstance(result,dict) or set(result) != {"version","nonce","paths","prepared"}
                or result["version"] != VERSION or result["paths"] != paths
                or result["prepared"] is not True or not isinstance(result["nonce"],str)
                or not re.fullmatch("[0-9a-f]{32}",result["nonce"])):
            raise ArtifactError("artifact preparation receipt invalid")
        return result
    except (ValueError,TypeError) as exc:
        raise ArtifactError("artifact preparation refused: "+str(exc)) from exc

def read_script(paths, preparation, *, limit_bytes=MAX_BYTES):
    proof = prepared(json.dumps(preparation),paths)
    return ("python3 -c "+shlex.quote(_READ)+" "+shlex.quote(json.dumps(paths))+" "
            +proof["nonce"]+" "+str(_limit(limit_bytes)))

def decode(payload, preparation, paths, *, limit_bytes=MAX_BYTES):
    proof = prepared(json.dumps(preparation),paths)
    limit = _limit(limit_bytes)
    try:
        result = json.loads(payload)
        if (not isinstance(result,dict) or set(result) != {"version","nonce","files"}
                or result["version"] != VERSION or result["nonce"] != proof["nonce"]
                or not isinstance(result["files"],list)):
            raise ArtifactError("artifact snapshot receipt invalid")
        result.update(preparation=proof,limit_bytes=limit,
                      complete=all(type(x.get("total_bytes")) is int and x["total_bytes"]<=limit
                                   for x in result["files"] if isinstance(x,dict)))
        read_files(result,paths)
        return result
    except (KeyError,ValueError,TypeError) as exc:
        raise ArtifactError("artifact snapshot refused: "+str(exc)) from exc

def read_files(result, paths):
    """Validate all evidence, including intentionally retained over-cap snapshots."""
    try:
        _paths(paths)
        if (not isinstance(result,dict) or set(result) != {
                "version","nonce","files","preparation","limit_bytes","complete"}):
            raise ArtifactError("artifact evidence fields missing or unknown")
        proof = prepared(json.dumps(result["preparation"]),paths)
        limit = _limit(result["limit_bytes"])
        if (result["version"] != VERSION or result["nonce"] != proof["nonce"]
                or not isinstance(result["files"],list)
                or [x["path"] for x in result["files"]] != paths):
            raise ArtifactError("artifact identity or freshness receipt mismatch")
        decoded = {}
        complete = True
        for item in result["files"]:
            if set(item) != {"path","base64","bytes","total_bytes","sha256"}:
                raise ArtifactError("artifact snapshot fields invalid")
            raw = base64.b64decode(item["base64"],validate=True)
            total = item["total_bytes"]
            if (base64.b64encode(raw).decode()!=item["base64"] or type(total) is not int or total<0
                    or type(item["bytes"]) is not int or item["bytes"]!=len(raw)
                    or len(raw)!=min(total,limit+1) or item["sha256"]!=hashlib.sha256(raw).hexdigest()):
                raise ArtifactError("artifact byte count, hash or encoding mismatch")
            decoded[item["path"]] = raw
            complete = complete and total<=limit
        if type(result["complete"]) is not bool or result["complete"] != complete:
            raise ArtifactError("artifact completeness contradiction")
        return decoded
    except (KeyError,ValueError,TypeError,AttributeError) as exc:
        raise ArtifactError("artifact evidence refused: "+str(exc)) from exc
