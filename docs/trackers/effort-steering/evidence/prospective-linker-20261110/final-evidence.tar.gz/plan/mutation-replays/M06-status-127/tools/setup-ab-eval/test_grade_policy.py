"""Policy observations, with the dataset parser unchanged and no Docker/model boundary."""
import base64
import copy
import tempfile
import json
import unittest
from pathlib import Path

import grade_policy as policy
import multilang_control as control
import multilang_grade as grade

PARSER = json.loads((Path(__file__).parent / "fixtures/multilang/rust_concat_record.json").read_text())["log_parser"]
RECORD = {"log_parser": PARSER, "FAIL_TO_PASS": ["bin::f"], "PASS_TO_PASS": ["bin::p"],
          "test_cmds": ["cargo test"], "print_cmds": ["cat reports/log"], "rebuild_cmds": []}
BUNDLE = {"expected": {"fail_to_pass": 1, "pass_to_pass_kept": 1, "dropped": []}}
OK = {"complete": True, "resource_ok": True, "cgroup_probes": 2, "oom_kill": 0, "errors": []}
PASS_LOG = "Running tests/main.rs (bin)\ntest f ... ok\ntest p ... ok\n"
FAIL_LOG = "Running tests/main.rs (bin)\ntest f ... FAILED\ntest p ... ok\n"
SIGNAL = "collect2: fatal error: ld terminated with signal 7 [Bus error], core dumped"


def fixture(log):
    verdict = grade.verdict(grade.run_parser(PARSER, log), ["bin::f"], ["bin::p"])
    raw = dict(verdict, oom_killed=False, container_removed=True)
    full = dict(raw, steps=[{"name": "grade:test[0]", "returncode": 0, "tail": ""},
                            {"name": "grade:print[0]", "returncode": 0, "tail": ""}])
    return raw, full


class PolicyTests(unittest.TestCase):
    def private(self, log, *, runtime=None, raw=None, full=None, record=None):
        default_raw, default_full = fixture(log)
        return policy.adjudicate_private(default_raw if raw is None else raw,
                                          default_full if full is None else full,
                                          RECORD if record is None else record, BUNDLE,
                                          log=log, runtime=OK if runtime is None else runtime)

    def test_public_success_and_functional_failure(self):
        self.assertEqual(policy.classify_public("build complete", 0, runtime=OK)["kind"], "pass")
        result = policy.classify_public("assertion failed", 101, runtime=OK)
        self.assertIs(result["valid"], True)
        self.assertIs(result["pass"], False)
        self.assertEqual(result["kind"], "functional_failure")

    def test_public_unknown_or_bad_runtime_fails_closed(self):
        for runtime in ({}, dict(OK, complete=False), dict(OK, resource_ok=False),
                        dict(OK, oom_kill=1), dict(OK, cgroup_probes=0), dict(OK, errors=["probe failed"])):
            with self.subTest(runtime=runtime):
                result = policy.classify_public("success", 0, runtime=runtime)
                self.assertIs(result["valid"], False)
                self.assertIs(result["pass"], False)
                self.assertTrue(result["error"])

    def test_public_capture_signal_storage_and_process_failure_invalidate(self):
        for log, code, truncated in ((SIGNAL, 1, False),
                                     ("error: No space left on device (os error 28)", 1, False),
                                     ("bash: /tmp/test-exec: Permission denied", 126, False),
                                     ("", -9, False), ("", 0, True)):
            with self.subTest(log=log, code=code, truncated=truncated):
                self.assertFalse(policy.classify_public(log, code, runtime=OK, truncated=truncated)["valid"])

    def test_private_complete_pass_and_real_test_failure(self):
        passed, failed = self.private(PASS_LOG), self.private(FAIL_LOG)
        self.assertTrue(passed["valid"])
        self.assertTrue(passed["pass"])
        self.assertEqual(passed["statuses"], {"bin::f": "pass", "bin::p": "pass"})
        self.assertTrue(failed["valid"])
        self.assertFalse(failed["pass"])
        self.assertEqual(failed["kind"], "test_failure")
        self.assertEqual(failed["statuses"]["bin::f"], "fail")

    def test_private_recovers_expected_p2p_with_physical_provenance(self):
        log = "Running tests/main.rs (bin)\ntest f ... ok\noutputtest p ... ok\n"
        result = self.private(log)
        self.assertTrue(result["valid"])
        self.assertTrue(result["pass"])
        self.assertEqual((result["raw"]["missing"], result["adjusted"]["missing"]), (1, 0))
        self.assertEqual(result["statuses"], {"bin::f": "pass", "bin::p": "pass"})
        self.assertEqual(result["recovered"], [{"key": "bin::p", "status": "pass",
                                              "line": 3, "raw": "outputtest p ... ok"}])

    def test_private_recovery_does_not_replace_failure(self):
        result = self.private(FAIL_LOG + "outputtest f ... ok\n")
        self.assertTrue(result["valid"])
        self.assertFalse(result["pass"])
        self.assertEqual(result["statuses"]["bin::f"], "fail")

    def test_private_missing_status_is_not_fabricated_failure(self):
        result = self.private("Running tests/main.rs (bin)\ntest f ... ok\n")
        self.assertFalse(result["valid"])
        self.assertEqual(result["kind"], "measurement_invalid")
        self.assertTrue(result["error"])

    def test_private_compiler_failure_is_semantic_with_zero_statuses(self):
        log = "error[E0425]: cannot find value missing\nerror: could not compile candidate\n"
        raw, full = fixture(log)
        full["steps"][0]["returncode"] = 101
        result = self.private(log, raw=raw, full=full)
        self.assertTrue(result["valid"])
        self.assertFalse(result["pass"])
        self.assertEqual(result["kind"], "compile_failure")
        self.assertEqual(result["statuses"], {})

    def test_private_source_excerpt_is_not_infrastructure(self):
        log = "error: format argument must be a string literal\n2 | println!(Bus error);\n"
        raw, full = fixture(log)
        full["steps"][0]["returncode"] = 101
        result = self.private(log, raw=raw, full=full)
        self.assertTrue(result["valid"])
        self.assertEqual(result["kind"], "compile_failure")

    def test_private_partial_statuses_cannot_hide_toolchain_or_storage_fault(self):
        for suffix in (SIGNAL, "error: No space left on device (os error 28)"):
            with self.subTest(suffix=suffix):
                self.assertFalse(self.private(PASS_LOG + suffix + "\n")["valid"])

    def test_private_runtime_and_raw_faults_never_recover_to_pass(self):
        self.assertFalse(self.private(PASS_LOG, runtime=dict(OK, oom_kill=1))["valid"])
        for change in ({"error": "timeout"}, {"infra": "unknown"}, {"oom_killed": True},
                       {"container_removed": False}, {"pass": False}):
            with self.subTest(change=change):
                raw, full = fixture(PASS_LOG)
                raw.update(change)
                self.assertFalse(self.private(PASS_LOG, raw=raw, full=full)["valid"])

    def test_private_requires_exact_complete_capture_steps(self):
        raw, original = fixture(PASS_LOG)
        variants = [dict(original, steps=[]),
                    dict(original, steps=list(reversed(original["steps"])))]
        for change in ({"truncated": True}, {"returncode": 1}, {"returncode": True}):
            full = copy.deepcopy(original)
            full["steps"][1].update(change)
            variants.append(full)
        for full in variants:
            with self.subTest(full=full):
                self.assertFalse(self.private(PASS_LOG, raw=raw, full=full)["valid"])

    def test_private_failed_rebuild_cannot_pass_on_stale_complete_test_log(self):
        record = dict(RECORD, rebuild_cmds=["cargo build"])
        raw, full = fixture(PASS_LOG)
        full["steps"].insert(0, {"name": "grade:rebuild", "returncode": 101,
                                 "tail": "error[E0425]: cannot find value missing"})
        result = self.private(PASS_LOG, raw=raw, full=full, record=record)
        self.assertTrue(result["valid"])
        self.assertFalse(result["pass"])
        self.assertEqual(result["kind"], "compile_failure")

    def test_selected_expected_pass_can_survive_unselected_test_failures(self):
        # Existing NU gold controls exit101 for unselected tests; the selected oracle
        # is the registered expected set, not cargo's whole-project return code.
        log = PASS_LOG + "error: test failed, to rerun pass --lib\n"
        raw, full = fixture(log)
        full["steps"][0]["returncode"] = 101
        result = self.private(log, raw=raw, full=full)
        self.assertTrue(result["valid"])
        self.assertTrue(result["pass"])
    def test_selected_expected_pass_survives_unselected_doctest_compile_failure(self):
        diagnostic = (
            "---- crates/unselected.rs - unselected (line 1) stdout ----\n"
            "error[E0425]: cannot find value missing in this scope\n"
            " --> crates/unselected.rs:1:1\n"
            "  |\n1 | missing\n  | ^^^^^^^ not found in this scope\n"
        )
        log = PASS_LOG + "test crates/unselected.rs - unselected (line 1) ... FAILED\n" + diagnostic
        for tail in ("", diagnostic, diagnostic.split("\n", 1)[1]):
            with self.subTest(step_tail=tail):
                raw, full = fixture(log)
                full["steps"][0].update(returncode=101, tail=tail)
                result = self.private(log, raw=raw, full=full)
                self.assertTrue(result["valid"])
                self.assertTrue(result["adjusted"]["pass"])
                self.assertTrue(result["pass"])

    def test_stale_selected_pass_cannot_hide_real_test_step_compile_failure(self):
        raw, full = fixture(PASS_LOG)
        full["steps"][0].update(
            returncode=101,
            tail="error[E0425]: cannot find value missing in this scope\nerror: could not compile selected-library",
        )
        result = self.private(PASS_LOG, raw=raw, full=full)
        self.assertTrue(result["valid"])
        self.assertFalse(result["pass"])
        self.assertEqual(result["kind"], "compile_failure")
    def test_stdout_diagnostic_does_not_supply_failed_rebuild_provenance(self):
        log = PASS_LOG + (
            "---- crates/unselected.rs - unselected (line 1) stdout ----\n"
            "error[E0425]: cannot find value missing\n"
        )
        raw, full = fixture(log)
        full["steps"].insert(0, {"name": "grade:rebuild", "returncode": 101, "tail": "rebuild exited"})
        result = self.private(log, raw=raw, full=full, record=dict(RECORD, rebuild_cmds=["cargo build"]))
        self.assertFalse(result["valid"])
        self.assertIn("rebuild", result["error"])
    def test_failed_test_diagnostic_cannot_explain_unknown_failed_rebuild(self):
        log = PASS_LOG + "error[E0425]: actual test compilation failed\n"
        raw, full = fixture(log)
        full["steps"][0]["returncode"] = 101
        full["steps"].insert(0, {"name": "grade:rebuild", "returncode": 101, "tail": "unclassified rebuild failure"})
        result = self.private(log, raw=raw, full=full, record=dict(RECORD, rebuild_cmds=["cargo build"]))
        self.assertFalse(result["valid"])
        self.assertIn("rebuild", result["error"])

    def test_test_stdout_error_is_not_a_missing_status_compiler_explanation(self):
        log = "---- ordinary_test stdout ----\nerror[E0425]: printed test data\n"
        raw, full = fixture(log)
        full["steps"][0]["returncode"] = 101
        result = self.private(log, raw=raw, full=full)
        self.assertFalse(result["valid"])

    def test_selected_failure_is_preserved_when_error_text_is_test_stdout(self):
        log = FAIL_LOG + "---- selected_test stdout ----\nerror[E0425]: printed assertion detail\n"
        raw, full = fixture(log)
        full["steps"][0].update(returncode=101, tail=log)
        result = self.private(log, raw=raw, full=full)
        self.assertTrue(result["valid"])
        self.assertFalse(result["pass"])
        self.assertEqual(result["kind"], "test_failure")

    def test_nested_runner_lines_stay_in_test_output(self):
        # Runner-looking lines can themselves be captured nested Cargo output.
        section = "---- test_name stdout ----\nerror[E0001]: printed test data\n"
        self.assertIsNone(policy.compiler_diagnostic(section))
        for boundary in ("   Compiling nested-fixture v0.1.0\n",
                         "    Checking nested-fixture v0.1.0\n",
                         "     Running tests/nested.rs (bin)\n"):
            with self.subTest(boundary=boundary):
                self.assertIsNone(
                    policy.compiler_diagnostic(section + boundary + "error[E0425]: printed nested compiler failure\n")
                )
    def test_stderr_diagnostic_is_captured_test_output(self):
        self.assertIsNone(policy.compiler_diagnostic(
            "---- test_name stderr ----\nerror[E0425]: printed stderr\n"
        ))

    def test_nested_cargo_output_does_not_override_selected_pass(self):
        log = PASS_LOG + (
            "test unselected ... FAILED\n"
            "---- unselected stdout ----\n"
            "   Compiling nested-fixture v0.1.0\n"
            "error[E0425]: printed nested compiler failure\n"
            "failures:\n    unselected\n"
            "test result: FAILED. 2 passed; 1 failed; 0 ignored; 0 measured; 0 filtered out\n"
        )
        raw, full = fixture(log)
        full["steps"][0].update(returncode=101, tail=log)
        result = self.private(log, raw=raw, full=full)
        self.assertTrue(result["valid"])
        self.assertTrue(result["pass"])

    def test_post_capture_compiler_provenance_is_invalid_not_a_model_failure(self):
        log = PASS_LOG + (
            "---- unselected stdout ----\n"
            "printed diagnostic\n"
            "test result: FAILED. 2 passed; 1 failed; 0 ignored; 0 measured; 0 filtered out\n"
            "   Compiling another-crate v0.1.0\n"
            "error[E0425]: cannot attribute this to nested output or a new compiler\n"
        )
        raw, full = fixture(log)
        full["steps"][0].update(returncode=101, tail=log)
        result = self.private(log, raw=raw, full=full)
        self.assertFalse(result["valid"])
        self.assertIn("ambiguous", result["error"])


    def test_cargo_aggregate_test_failure_is_not_a_compiler_diagnostic(self):
        log = FAIL_LOG + "error: 3 targets failed:\n"
        raw, full = fixture(log)
        full["steps"][0]["returncode"] = 101
        result = self.private(log, raw=raw, full=full)
        self.assertTrue(result["valid"])
        self.assertFalse(result["pass"])
        self.assertEqual(result["kind"], "test_failure")
        self.assertIsNone(policy.compiler_diagnostic("error: 3 targets failed:"))

    def test_test_debug_error_field_is_not_a_compiler_diagnostic(self):
        for diagnostic in ('                error: "boom",\n',
                           'error: "boom",\n',
                           'error: ordinary test message\n'):
            with self.subTest(diagnostic=diagnostic):
                log = FAIL_LOG + "---- failed test stdout ----\nGenericError {\n" + diagnostic + "}\n"
                raw, full = fixture(log)
                full["steps"][0]["returncode"] = 101
                result = self.private(log, raw=raw, full=full)
                self.assertTrue(result["valid"])
                self.assertEqual(result["kind"], "test_failure")
                self.assertIsNone(policy.compiler_diagnostic(log))

    def test_compiler_headers_need_physical_rust_diagnostic_evidence(self):
        for diagnostic in ("error[E0425]: cannot find value missing\n",
                           "\x1b[31merror[E0425]\x1b[0m: cannot find value missing\n",
                           "error: malformed expression\n --> src/main.rs:2:3\n"):
            with self.subTest(diagnostic=diagnostic):
                self.assertIsNotNone(policy.compiler_diagnostic(diagnostic))

    def test_full_step_tails_are_required_even_when_statuses_are_complete(self):
        raw, full = fixture(PASS_LOG)
        full["steps"][0]["tail"] = SIGNAL
        self.assertFalse(self.private(PASS_LOG, raw=raw, full=full)["valid"])
        for tail in ("missing", None, 123, [], True):
            with self.subTest(tail=tail):
                stripped = copy.deepcopy(full)
                if tail == "missing":
                    for step in stripped["steps"]:
                        step.pop("tail")
                else:
                    stripped["steps"][0]["tail"] = tail
                result = self.private(PASS_LOG, raw=raw, full=stripped)
                self.assertFalse(result["valid"])
                self.assertTrue(result["error"])


    def test_review_scope_utf8_cut_retains_capture_context(self):
        suffix = ("\nerror[E0425]: printed diagnostic\n --> tests/u.rs:1:1\n"
                  "test result: FAILED. 2 passed; 1 failed; 0 ignored; 0 measured\n")
        padding = "x" * (4095 - len(suffix.encode()))
        log = PASS_LOG + "---- unselected stdout ----\né" + padding + suffix
        tail = control._decode_tail(base64.b64encode(log.encode()).decode())
        self.assertTrue(tail.startswith("\ufffd"))
        self.assertFalse(log.endswith(tail))
        raw, full = fixture(log)
        full["steps"][0].update(returncode=101, tail=tail)
        result = self.private(log, raw=raw, full=full)
        self.assertTrue(result["valid"], result)
        self.assertTrue(result["pass"], result)
        self.assertEqual(result["statuses"], {"bin::f": "pass", "bin::p": "pass"})

    def test_review_scope_nextest_legacy_headers_are_data(self):
        for stream in ("STDOUT", "STDERR"):
            with self.subTest(stream=stream):
                tail = (f"    FAIL [   0.010s] crate::ui trybuild_ui\n"
                        f"--- {stream}:              crate::ui trybuild_ui ---\n"
                        "error[E0308]: mismatched types\n --> tests/ui/x.rs:3:5\n")
                raw, full = fixture(PASS_LOG)
                full["steps"][0].update(returncode=101, tail=tail)
                result = self.private(PASS_LOG, raw=raw, full=full)
                self.assertTrue(result["valid"], result)
                self.assertTrue(result["pass"], result)

    def test_review_scope_captured_infrastructure_is_data(self):
        for stream in ("stdout", "stderr"):
            for text in ("write failed: No space left on device",
                         "write failed: Disk quota exceeded",
                         "open /tmp/fixture.txt: Permission denied",
                         "rustc: fatal error: terminated with signal 9"):
                with self.subTest(stream=stream, text=text):
                    captured = (f"---- f {stream} ----\n{text}\n"
                                "test result: FAILED. 1 passed; 1 failed; 0 ignored\n")
                    log = FAIL_LOG + captured
                    raw, full = fixture(log)
                    full["steps"][0].update(returncode=101, tail=captured)
                    result = self.private(log, raw=raw, full=full)
                    self.assertTrue(result["valid"], result)
                    self.assertFalse(result["pass"], result)
                    self.assertEqual(result["kind"], "test_failure")
                    self.assertEqual(result["statuses"], {"bin::f": "fail", "bin::p": "pass"})

    def test_review_scope_real_nextest_json_with_stderr(self):
        fixtures = Path(__file__).parent / "fixtures/multilang"
        log = (fixtures / "nextest_capture.jsonl").read_text()
        tail = (fixtures / "nextest_capture.stderr").read_text()
        parser = (
            "def parser(log):\n"
            "    import json\n"
            "    result = {}\n"
            "    for line in log.splitlines():\n"
            "        event = json.loads(line)\n"
            "        if event.get('type') == 'test' and event.get('event') in ('ok', 'failed'):\n"
            "            result[event['name']] = 'pass' if event['event'] == 'ok' else 'fail'\n"
            "    return result\n"
        )
        for name, passed, examples in (
            ("policy_capture_probe::policy_capture_probe$selected_pass", True, []),
            ("policy_capture_probe::policy_capture_probe$captured_stderr", False,
             ["policy_capture_probe::policy_capture_probe$captured_stderr"]),
        ):
            with self.subTest(selected=name):
                raw = {"pass": passed, "expected": 1, "not_passing": 0 if passed else 1,
                       "missing": 0, "examples": examples,
                       "oom_killed": False, "container_removed": True}
                full = dict(raw, steps=[
                    {"name": "grade:test[0]", "returncode": 100, "tail": tail},
                    {"name": "grade:print[0]", "returncode": 0, "tail": log},
                ])
                record = dict(RECORD, log_parser=parser, FAIL_TO_PASS=[name], PASS_TO_PASS=[])
                bundle = {"expected": {"fail_to_pass": 1, "pass_to_pass_kept": 0, "dropped": []}}
                result = policy.adjudicate_private(raw, full, record, bundle, log=log, runtime=OK)
                self.assertTrue(result["valid"], result)
                self.assertEqual(result["pass"], passed)
                self.assertEqual(result["kind"], "pass" if passed else "test_failure")
                self.assertEqual(result["statuses"], {name: "pass" if passed else "fail"})

    def test_review_scope_json_test_payload_is_data(self):
        log = json.dumps({"type": "test", "event": "failed", "name": "f",
                          "stdout": "open /tmp/fixture.txt: Permission denied is fixture data"})
        result = policy.classify_public(log, 101, runtime=OK)
        self.assertTrue(result["valid"], result)
        self.assertEqual(result["kind"], "functional_failure")

    def test_review_scope_streams_are_independent(self):
        log = FAIL_LOG + "---- f stdout ----\nordinary assertion data\n"
        raw, full = fixture(log)
        full["steps"][0].update(returncode=101, tail="error: No space left on device (os error 28)")
        result = self.private(log, raw=raw, full=full)
        self.assertFalse(result["valid"], result)
        self.assertIn("storage", result["error"])

    def test_review_scope_top_level_fault_after_nextest_capture(self):
        tail = ((Path(__file__).parent / "fixtures/multilang/nextest_capture.stderr").read_text()
                + "\nerror: No space left on device (os error 28)\n")
        raw, full = fixture(PASS_LOG)
        full["steps"][0].update(returncode=101, tail=tail)
        result = self.private(PASS_LOG, raw=raw, full=full)
        self.assertFalse(result["valid"], result)
        self.assertIn("storage", result["error"])


    def test_review_input_shapes_return_invalid_instead_of_raising(self):
        raw, full = fixture(PASS_LOG)
        valid = {"raw": raw, "full_evidence": full, "record": RECORD, "bundle": BUNDLE,
                 "log": PASS_LOG, "runtime": OK}
        for field in ("raw", "full_evidence", "record", "bundle"):
            for value in (None, "x", []):
                with self.subTest(field=field, value=value):
                    kwargs = dict(valid)
                    kwargs[field] = value
                    result = policy.adjudicate_private(**kwargs)
                    self.assertFalse(result["valid"], result)
                    self.assertFalse(result["pass"], result)
                    self.assertEqual(result["kind"], "measurement_invalid")
                    self.assertTrue(result["error"])

    def test_review_optional_rebuild_matches_executor(self):
        absent = dict(RECORD)
        absent.pop("rebuild_cmds")
        records = [absent] + [
            dict(RECORD, rebuild_cmds=value)
            for value in (None, [], [""], [" ", "\t", None, 4])
        ]
        for record in records:
            with self.subTest(rebuild=record.get("rebuild_cmds", "absent")):
                result = self.private(PASS_LOG, record=record)
                self.assertTrue(result["valid"], result)
                self.assertTrue(result["pass"], result)

    def test_review_optional_rebuild_does_not_hide_a_required_step(self):
        result = self.private(PASS_LOG, record=dict(RECORD, rebuild_cmds=[" ", "cargo build"]))
        self.assertFalse(result["valid"], result)
        self.assertIn("step", result["error"])


    def test_review_guard_cgroup_observations_are_integer_and_complete(self):
        for probes in (1, 2.0):
            with self.subTest(probes=probes):
                result = policy.classify_public("complete", 0, runtime=dict(OK, cgroup_probes=probes))
                self.assertFalse(result["valid"], result)
        self.assertTrue(policy.classify_public("complete", 0,
                                              runtime=dict(OK, cgroup_probes=3))["pass"])

    def test_review_guard_source_gutters_do_not_supply_infrastructure(self):
        for excerpt in ("7 | error: No space left on device",
                        "| open /tmp/fixture.txt: Permission denied"):
            with self.subTest(excerpt=excerpt):
                result = policy.classify_public(
                    "error: malformed expression\n --> src/lib.rs:7:1\n" + excerpt + "\n",
                    101, runtime=OK)
                self.assertTrue(result["valid"], result)
                self.assertEqual(result["kind"], "functional_failure")

    def test_review_guard_expected_sets_are_nonempty_and_unambiguous(self):
        for f2p, p2p, count in (
            ([], ["bin::p"], 1),
            (["bin::f", "bin::f"], ["bin::p"], 3),
            (["bin::f"], ["bin::f"], 2),
        ):
            with self.subTest(f2p=f2p, p2p=p2p):
                raw = {"pass": True, "expected": count, "not_passing": 0, "missing": 0,
                       "examples": [], "oom_killed": False, "container_removed": True}
                _, template = fixture(PASS_LOG)
                full = dict(raw, steps=template["steps"])
                record = dict(RECORD, FAIL_TO_PASS=f2p, PASS_TO_PASS=p2p)
                bundle = {"expected": {"fail_to_pass": len(f2p),
                                       "pass_to_pass_kept": len(p2p), "dropped": []}}
                result = policy.adjudicate_private(raw, full, record, bundle, log=PASS_LOG, runtime=OK)
                self.assertFalse(result["valid"], result)
                self.assertIn("expected set", result["error"])

    def test_review_guard_full_verdict_must_agree(self):
        for field, value in (("pass", False), ("expected", 3), ("not_passing", 1),
                             ("missing", 1), ("examples", ["bin::p"])):
            with self.subTest(field=field):
                raw, full = fixture(PASS_LOG)
                full[field] = value
                result = self.private(PASS_LOG, raw=raw, full=full)
                self.assertFalse(result["valid"], result)
                self.assertIn("contradicts", result["error"])

    def test_review_guard_unknown_expected_status_is_invalid(self):
        parser = "def parser(log):\n    return {'bin::f': 'future-status', 'bin::p': 'pass'}\n"
        raw, full = fixture(PASS_LOG)
        raw.update({"pass": False, "not_passing": 1, "examples": ["bin::f"]})
        full.update({"pass": False, "not_passing": 1, "examples": ["bin::f"]})
        result = self.private(PASS_LOG, raw=raw, full=full, record=dict(RECORD, log_parser=parser))
        self.assertFalse(result["valid"], result)
        self.assertIn("unknown expected status", result["error"])

    def test_review_guard_nondeterministic_parser_is_invalid(self):
        with tempfile.TemporaryDirectory(prefix="policy-parser-repeat-") as directory:
            counter = Path(directory) / "count"
            parser = (
                "def parser(log):\n"
                "    from pathlib import Path\n"
                f"    counter = Path({str(counter)!r})\n"
                "    count = int(counter.read_text()) if counter.exists() else 0\n"
                "    counter.write_text(str(count + 1))\n"
                "    return {'bin::f': 'pass' if count == 0 else 'fail', 'bin::p': 'pass'}\n"
            )
            result = self.private(PASS_LOG, record=dict(RECORD, log_parser=parser))
            self.assertFalse(result["valid"], result)
            self.assertIn("audit raw verdict", result["error"])
            self.assertGreaterEqual(int(counter.read_text()), 2)

    def test_review_guard_successful_steps_do_not_supply_compile_failure(self):
        diagnostic = "error[E0425]: example diagnostic from a successful command\n"
        log = PASS_LOG + diagnostic
        raw, full = fixture(log)
        full["steps"][0]["tail"] = diagnostic
        result = self.private(log, raw=raw, full=full)
        self.assertTrue(result["valid"], result)
        self.assertTrue(result["pass"], result)

    def test_review_guard_storage_requires_a_complete_diagnostic(self):
        result = policy.classify_public(
            "note: No space left on device is the text under test\n", 0, runtime=OK)
        self.assertTrue(result["valid"], result)
        self.assertTrue(result["pass"], result)

    def test_review_guard_test_step_exit_is_integer_and_nonfatal(self):
        for code in (-9, True, False):
            with self.subTest(code=code):
                raw, full = fixture(PASS_LOG)
                full["steps"][0]["returncode"] = code
                result = self.private(PASS_LOG, raw=raw, full=full)
                self.assertFalse(result["valid"], result)
                self.assertIn("step process", result["error"])


    def test_review_guard_rebuild_context_does_not_borrow_test_capture(self):
        diagnostic = "error[E0425]: genuine rebuild compiler failure\n"
        log = PASS_LOG + "---- unselected stdout ----\n" + diagnostic
        raw, full = fixture(log)
        full["steps"].insert(0, {"name": "grade:rebuild", "returncode": 101, "tail": diagnostic})
        result = self.private(log, raw=raw, full=full,
                              record=dict(RECORD, rebuild_cmds=["cargo build"]))
        self.assertTrue(result["valid"], result)
        self.assertFalse(result["pass"], result)
        self.assertEqual(result["kind"], "compile_failure")

    def test_review_input_nested_expected_mapping_is_invalid(self):
        for value in (None, "x", []):
            with self.subTest(expected=value):
                raw, full = fixture(PASS_LOG)
                result = policy.adjudicate_private(raw, full, RECORD, {"expected": value},
                                                  log=PASS_LOG, runtime=OK)
                self.assertFalse(result["valid"], result)
                self.assertFalse(result["pass"], result)
                self.assertTrue(result["error"])
