"""Prospective full capture through production control methods and real bash."""
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest import mock

import command_capture
import multilang_control as control
import multilang_tasks as live
import test_multilang_tasks as fixtures


class StreamControlTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.steps = []

    def local_exec(self, container, workdir, *args, **kwargs):
        self.assertEqual(container, "owned")
        self.assertEqual(workdir, str(self.root))
        return subprocess.run(args, cwd=self.root, input=kwargs.get("data"),
                              capture_output=True, text=True, timeout=kwargs.get("timeout"),
                              env=dict(os.environ, TMPDIR=str(self.root)))

    def run_record(self, record):
        with mock.patch.object(control, "_exec", self.local_exec):
            control.rebuild("owned", str(self.root), record, steps=self.steps,
                            state="grade", capture_streams=True)
            return control.run_tests("owned", str(self.root), record, steps=self.steps,
                                     state="grade", capture_streams=True)

    def test_long_stderr_and_each_print_stream_reach_the_real_consumer(self):
        record = {
            "rebuild_cmds":["printf rebuilt; printf diagnostic >&2"],
            "test_cmds":["printf test-out; printf 'capture header\\n' >&2; "
                         "printf '%05000d' 0 >&2; printf '\\nEND\\n' >&2; exit 101"],
            "print_cmds":["printf 'first=pass\\n'", "printf 'second=fail\\n' >&2"]}
        log = self.run_record(record)
        self.assertEqual(log, "first=pass\nsecond=fail\n")
        self.assertEqual([s["name"] for s in self.steps],
                         ["grade:rebuild","grade:test[0]","grade:print[0]","grade:print[1]"])
        self.assertEqual([s["returncode"] for s in self.steps], [0,101,0,0])
        expected = [(b"rebuilt",b"diagnostic"), (b"test-out",b"capture header\n"+b"0"*5000+b"\nEND\n"),
                    (b"first=pass\n",b""), (b"second=fail\n",b"")]
        for step, want in zip(self.steps,expected):
            self.assertEqual(command_capture.read_streams(step["capture"]),want)
            self.assertIs(step["capture"]["complete"],True)
        self.assertNotIn("capture header",self.steps[1]["tail"])

    def test_excess_test_output_is_retained_and_refused_before_print(self):
        record={"rebuild_cmds":[], "test_cmds":["printf '%05000d' 0"],
                "print_cmds":["touch should-not-print"]}
        with mock.patch.object(command_capture,"MAX_BYTES",32):
            with self.assertRaises(control.ControlError):
                self.run_record(record)
        self.assertEqual(len(self.steps),1)
        self.assertIs(self.steps[0]["capture"]["complete"],False)
        self.assertFalse((self.root/"should-not-print").exists())

    def test_excess_rebuild_output_is_retained_and_refused_before_tests(self):
        record={"rebuild_cmds":["printf '%05000d' 0"], "test_cmds":["touch should-not-test"],
                "print_cmds":["true"]}
        with mock.patch.object(command_capture,"MAX_BYTES",32):
            with self.assertRaises(control.ControlError):
                self.run_record(record)
        self.assertEqual(self.steps[0]["name"],"grade:rebuild")
        self.assertIs(self.steps[0]["capture"]["complete"],False)
        self.assertFalse((self.root/"should-not-test").exists())

    def test_print_failure_keeps_its_complete_diagnostics(self):
        log=self.run_record({"test_cmds":["true"],"print_cmds":["printf missing >&2; exit 9"]})
        self.assertEqual(log,"missing")
        self.assertEqual(self.steps[-1]["returncode"],9)
        self.assertEqual(command_capture.read_streams(self.steps[-1]["capture"]),(b"missing",b""))

    def test_malformed_transport_is_a_control_fault(self):
        with mock.patch.object(control,"_exec",return_value=type(
                "Result",(),{"stdout":"docker failed","returncode":125})()):
            with self.assertRaises(control.ControlError):
                control.run_tests("owned",str(self.root),
                                  {"test_cmds":["true"],"print_cmds":["true"]},
                                  capture_streams=True)

    def test_print_parts_exceeding_join_limit_are_not_silently_admitted(self):
        record={"test_cmds":["true"],"print_cmds":["printf '%020d' 0", "printf '%020d' 0"]}
        with mock.patch.object(command_capture,"MAX_BYTES",32), mock.patch.object(control,"MAX_LOG_BYTES",32):
            with self.assertRaises(control.ControlError):
                self.run_record(record)
        self.assertEqual(len(self.steps),3)
        self.assertIs(self.steps[-1]["truncated"],True)
    def test_exact_print_cap_is_complete_not_silently_truncated(self):
        record={"test_cmds":["true"],"print_cmds":["printf '%032d' 0"]}
        with mock.patch.object(command_capture,"MAX_BYTES",32), mock.patch.object(control,"MAX_LOG_BYTES",32):
            log=self.run_record(record)
        self.assertEqual(log,"0"*32)
        self.assertNotIn("truncated",self.steps[-1])
    def test_multibyte_print_join_uses_bytes_instead_of_characters(self):
        record={"test_cmds":["true"],"print_cmds":["printf '"+ "é"*20 +"'"]*2}
        with mock.patch.object(command_capture,"MAX_BYTES",64), mock.patch.object(control,"MAX_LOG_BYTES",64):
            with self.assertRaises(control.ControlError):
                self.run_record(record)
        self.assertEqual(len(self.steps),3)
        self.assertEqual(self.steps[-1]["capture"]["stdout"]["bytes"],40)
        self.assertIs(self.steps[-1]["truncated"],True)

    def test_incomplete_print_is_refused_even_when_its_bytes_fit(self):
        gate=self.root/"gate"
        os.mkfifo(gate)
        try:
            with self.assertRaises(control.ControlError):
                self.run_record({"test_cmds":["true"],
                                 "print_cmds":['cat "$TMPDIR/gate" & printf partial']})
        finally:
            import time
            deadline=time.monotonic()+3
            while True:
                try:
                    fd=os.open(gate,os.O_WRONLY|os.O_NONBLOCK)
                    os.close(fd)
                    break
                except OSError as exc:
                    if exc.errno!=6 or time.monotonic()>=deadline:
                        raise
                    time.sleep(0.01)
        self.assertEqual(self.steps[-1]["name"],"grade:print[0]")
        self.assertIs(self.steps[-1]["capture"]["complete"],False)

class LiveGradeCaptureTests(unittest.TestCase):
    def test_opt_in_full_grade_evidence_keeps_real_shell_streams(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            def docker(*args, **kwargs):
                if args[0]=="exec":
                    index=args.index("-w")
                    command=list(args[index+3:])
                    if command[0]=="bash":
                        return subprocess.run(command,capture_output=True,text=True,
                                              env=dict(os.environ,TMPDIR=directory),timeout=3)
                return type("Result",(),{"stdout":"false\n" if args[0]=="inspect" else "",
                                        "returncode":0})()
            record=fixtures.record(
                rebuild_cmds=["printf rebuilt"],
                test_cmds=["printf 'capture header\\n' >&2; printf '%05000d' 0 >&2; exit 101"],
                print_cmds=["printf 't::f1=pass\\nt::p1=pass\\nt::p3=pass\\n'"])
            with mock.patch("pilot.docker",docker):
                grader=live.live_grader(record,fixtures.live_bundle(root),"owned-image",root/"grades",
                                        capture_streams=True)
                result=grader("candidate","unit")
            self.assertTrue(result["pass"],result)
            saved=json.loads((Path(result["log"]).parent/"grade.json").read_text())
            self.assertEqual([s["name"] for s in saved["steps"]],
                             ["grade:rebuild","grade:test[0]","grade:print[0]"])
            self.assertTrue(all(s["capture"]["complete"] for s in saved["steps"]))
            stdout,stderr=command_capture.read_streams(saved["steps"][1]["capture"])
            self.assertEqual(stdout,b"")
            self.assertEqual(stderr,b"capture header\n"+b"0"*5000)
            self.assertNotIn("capture header",saved["steps"][1]["tail"])
            self.assertEqual(Path(result["log"]).read_text(),
                             "t::f1=pass\nt::p1=pass\nt::p3=pass\n")

    def test_live_grade_wires_declared_artifact_only_to_tests_and_saves_proof(self):
        import diagnostic_artifacts
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            subprocess.run(["git", "init", "-q", directory], check=True)
            def docker(*args, **kwargs):
                if args[0] == "exec":
                    index = args.index("-w")
                    command = list(args[index + 3:])
                    if command[0] == "bash":
                        return subprocess.run(command, cwd=root, capture_output=True, text=True,
                                              env=dict(os.environ, TMPDIR=directory), timeout=5)
                return type("Result", (), {"stdout": "false\n" if args[0] == "inspect" else "",
                                           "returncode": 0})()
            record = fixtures.record(rebuild_cmds=["printf rebuilt"],
                                     test_cmds=["printf 'compiler stderr\\n' >1; exit 101"],
                                     print_cmds=["printf 't::f1=pass\\nt::p1=pass\\nt::p3=pass\\n'"])
            with mock.patch("pilot.docker", docker):
                grader = live.live_grader(record, fixtures.live_bundle(root), "owned-image", root/"grades",
                                          capture_streams=True, diagnostic_artifacts={0: ["1"]})
                result = grader("candidate", "artifact")
            self.assertNotIn("error", result, result)
            saved = json.loads((Path(result["log"]).parent/"grade.json").read_text())
            proof = saved["steps"][1]["artifacts"]
            self.assertEqual(diagnostic_artifacts.read_files(proof, ["1"]), {"1": b"compiler stderr\n"})
            self.assertNotIn("artifacts", saved["steps"][0])
            self.assertEqual(saved["steps"][1]["returncode"], 101)

    def test_bad_capture_has_error_and_cannot_award_a_pass(self):
        with tempfile.TemporaryDirectory() as directory:
            def docker(*args,**kwargs):
                return type("Result",(),{"stdout":"broken transport" if args[0]=="exec" else "false\n",
                                        "returncode":0})()
            with mock.patch("pilot.docker",docker):
                grader=live.live_grader(fixtures.record(),fixtures.live_bundle(directory),
                                        "owned-image",Path(directory)/"grades",capture_streams=True)
                result=grader("candidate","unit")
            self.assertIs(result["pass"],False)
            self.assertIn("capture",result["error"])
            self.assertIs(result["container_removed"],True)


if __name__=="__main__":
    unittest.main()
