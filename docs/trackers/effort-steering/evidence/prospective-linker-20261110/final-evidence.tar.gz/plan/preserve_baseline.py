"""Seal the existing complete-stream source before any F6 edit."""
from pathlib import Path
import hashlib
import io
import json
import stat
import subprocess
import tarfile

root = Path.cwd()
out = root / ".superpowers/sdd/2026-11-10-prospective-linker-classification"
names = subprocess.check_output(["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z",
                                  "--", "tools/setup-ab-eval"]).decode().split("\0")
names = sorted(set(name for name in names if name and (root / name).is_file()))
manifest = {"head": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
            "files": {name: {"sha256": hashlib.sha256((root / name).read_bytes()).hexdigest(),
                            "mode": stat.S_IMODE((root / name).stat().st_mode)} for name in names}}
patch = subprocess.check_output(["git", "diff", "--binary", "--", "tools/setup-ab-eval"])
with (out / "baseline-wip.diff").open("xb") as f:
    f.write(patch)
raw = json.dumps(manifest, sort_keys=True, indent=2).encode()
archive = out / "baseline.tar.gz"
with tarfile.open(archive, "x:gz") as tar:
    for name in names:
        assert not (root / name).is_symlink()
        tar.inodes.clear()
        tar.add(root / name, arcname=name, recursive=False)
    info = tarfile.TarInfo("manifest.json")
    info.size = len(raw)
    tar.addfile(info, io.BytesIO(raw))
with tarfile.open(archive, "r:gz") as tar:
    assert json.load(tar.extractfile("manifest.json")) == manifest
    for name in names:
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == manifest["files"][name]["sha256"]
        assert hashlib.sha256((root / name).read_bytes()).hexdigest() == manifest["files"][name]["sha256"]
result = {"archive": str(archive), "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
          "reopened_source_files": len(names), "head": manifest["head"], "all_source_bytes_unchanged": True}
with (out / "baseline-receipt.json").open("x") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
