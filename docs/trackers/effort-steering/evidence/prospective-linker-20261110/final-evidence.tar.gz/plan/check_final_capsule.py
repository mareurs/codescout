"""Independent readback of every payload byte and the final source population."""
from pathlib import Path
import hashlib
import json
import tarfile
root = Path("/home/marius/work/claude/codescout/docs/trackers/effort-steering/evidence/prospective-linker-20261110")
receipt = json.loads((root / "closure.json").read_text())
archive = Path(receipt["archive"])
assert hashlib.sha256(archive.read_bytes()).hexdigest() == receipt["sha256"]
with tarfile.open(archive,"r:gz") as package:
    members = package.getmembers()
    manifest = json.load(package.extractfile("manifest.json"))
    names = [member.name for member in members]
    assert len(names) == len(set(names)) == len(manifest["files"]) + 1
    assert all(member.isfile() for member in members)
    source = sorted(name.removeprefix("source/") for name in manifest["files"] if name.startswith("source/"))
    assert source == manifest["source_files"] and len(source) == 99
    for name, expected in manifest["files"].items():
        value = package.extractfile(name).read()
        assert len(value) == expected["size"]
        assert hashlib.sha256(value).hexdigest() == expected["sha256"]
        assert package.getmember(name).mode == expected["mode"]
result = {"sha256":receipt["sha256"],"verified_regular_payloads":len(manifest["files"]),
          "verified_source_files":len(source),"duplicates":0,"nonregular_members":0,"paid_ready":False}
with (root / "independent-readback.json").open("x") as stream:
    json.dump(result,stream,indent=2)
print(json.dumps(result,indent=2))
