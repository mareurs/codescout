"""Registered no-model diagnostic controls; never grants paid admission."""
from pathlib import Path
import sys,json,hashlib,subprocess,time,datetime
W=Path("/home/marius/work/claude/codescout/.worktrees/grader-stream-provenance-01a15ca9")
sys.path.insert(0,str(W/"tools/setup-ab-eval"))
import multilang_tasks as tasks, multilang_grade as grade
import multilang_control as control
ROOT=W/".superpowers/sdd/2026-11-10-grader-stream-capture/fixed-oracle-diagnostic-v1"
M=Path("/home/marius/work/claude/codescout")
D=M/"docs/trackers/effort-steering/evidence/fixed-oracle-diagnostic-20261110"
ids=["yvgude__lean-ctx-1168","h4ckf0r0day__obscura-421"]
images=["sha256:b72f902d24c0a54516e4ef242d8218805f0ea3dc1d26ac809140979ba1f51d56",
        "sha256:b22988cd6022dd7a428a750799114b9c6f09bcaecc4fd9d8b86a0ef8502772d1"]
data=Path("/home/marius/work/claude/setup-ab-data/live/multilang-rust.jsonl")
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+"\n")
def records():
    assert sha(data.read_bytes())=="bf2dd8252a07d0f275663ef8f6ab87571dd9bc4ce386abf9ec98d3cd6bb51a81"
    found={}
    for line in data.open():
        r=json.loads(line)
        if r.get("instance_id") in ids: found[r["instance_id"]]=r
    assert set(found)==set(ids)
    return found
def sources(): return {str(p.relative_to(W)):sha(p.read_bytes()) for p in (W/"tools/setup-ab-eval").glob("*.py")}
def register():
    ROOT.mkdir(exist_ok=False);D.mkdir(exist_ok=False)
    found=records()
    selection=M/"docs/trackers/effort-steering/evidence/public-cohort-20261110/registration.json"
    reg={"schema":1,"scope":"unchanged full expected-set diagnostic, not complete prospective oracle admission",
         "registered_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),
         "selected_ids":ids,"public_selection_sha256":sha(selection.read_bytes()),
         "source_sha256":sources(),"dataset_sha256":sha(data.read_bytes()),
         "controls":["base","reference","reference-repeat"],"images":dict(zip(ids,images)),
         "capture_streams":True,"expected_policy":"all record F2P/P2P, no drops or post-outcome edits",
         "task_replacement_after_results":False,"automatic_retry":False,"experimental_model_calls":0,
         "paid_ready":False,"step_timeout_s":tasks.GRADE_STEP_TIMEOUT,
         "runtime_limits":["existing live_grader 4CPU/8GiB; default Docker swap; no claim of cargo-v2 runtime parity",
                          "observational before/final inspection and cgroup snapshots only; not campaign qualification"],
         "decision":"retain each base/reference/repeat outcome; any missing/failing reference or unstable expected status blocks paid task admission; never repair this by dropping expected tests",
         "records":{i:{"canonical_sha256":sha(json.dumps(found[i],sort_keys=True).encode()),
                        "f2p":len(found[i]["FAIL_TO_PASS"]),"p2p":len(found[i]["PASS_TO_PASS"]),
                        "reference_test_files_overlap":sorted(set(tasks.tasks.patch_files(found[i]["patch"]))&set(tasks.tasks.patch_files(found[i]["test_patch"])))}
                    for i in ids},
         "measured_nextest":{"h4ckf0r0day__obscura-421":"0.9.128 96bc6d4f4056abd8af1e27f9f18148d0d1f447ae",
                              "yvgude__lean-ctx-1168":"not installed; record uses cargo test"},
         "helper_sha256":sha(Path(__file__).read_bytes())}
    put(D/"registration.json",reg);put(ROOT/"registration.json",reg)
    print(json.dumps({"registered":str(D/"registration.json"),"selected_ids":ids,"paid_ready":False}))
def run(index):
    reg=json.loads((D/"registration.json").read_text())
    assert sources()==reg["source_sha256"],"grader source drift"
    assert sha(Path(__file__).read_bytes())==reg["helper_sha256"]
    found=records();tid=ids[index];r=found[tid];out=ROOT/tid;out.mkdir(exist_ok=False)
    f2p=r["FAIL_TO_PASS"];p2p=r["PASS_TO_PASS"]
    bundle={"workdir":"/testbed","expected":{"fail_to_pass":len(f2p),"pass_to_pass_kept":len(p2p),"dropped":[],"fail_to_pass_dropped":[]}}
    put(out/"bundle.json",bundle)
    # Capture the real runtime as observed, without changing live_grader arguments.
    original=tasks.pilot.docker
    observations=[]
    def observe(container,stage):
        item={"container":container,"stage":stage,"at":time.time()}
        try:
            p=original("inspect",container,check=False,timeout=120)
            item["inspect_returncode"]=p.returncode
            if p.returncode==0:item["inspect"]=json.loads(p.stdout)[0]
            p=original("exec",container,"sh","-c","for f in /sys/fs/cgroup/memory.events /sys/fs/cgroup/memory.max /sys/fs/cgroup/memory.swap.max /sys/fs/cgroup/cpu.max; do printf '%s\\n' \"$f\"; cat \"$f\"; done",check=False,timeout=120)
            item["cgroup_returncode"]=p.returncode;item["cgroup"]=p.stdout;item["cgroup_stderr"]=p.stderr
        except Exception as exc:item["error"]=repr(exc)
        observations.append(item)
        put(out/"runtime-observations.json",observations)
    def watched(*args,**kwargs):
        if args and args[0]=="rm":
            for a in args[1:]:
                if isinstance(a,str) and a.startswith(tasks.GRADE_PREFIX):observe(a,"before-remove")
        result=original(*args,**kwargs)
        if args and args[0]=="run" and result.returncode==0 and "--name" in args:
            observe(args[args.index("--name")+1],"after-start")
        return result
    tasks.pilot.docker=watched
    mapping={0:["rust/1"]} if index==0 else None
    grader=tasks.live_grader(r,bundle,images[index],out,capture_streams=True,diagnostic_artifacts=mapping)
    allresults=[]
    for name in reg["controls"]:
        started=time.time()
        raw=grader("" if name=="base" else r["patch"],name)
        result={"name":name,"raw":raw,"started":started,"ended":time.time(),"paid_ready":False}
        path=Path(raw.get("log",""))
        if path.is_file():
            log=path.read_text()
            statuses=grade.run_parser(r["log_parser"],log)
            result["log_sha256"]=sha(path.read_bytes())
            result["selected_statuses"]={k:statuses.get(k) for k in f2p+p2p}
            result["f2p_statuses"]={k:statuses.get(k) for k in f2p}
            result["parsed_keys"]=len(statuses)
        allresults.append(result);put(out/"results.json",allresults)
        print(json.dumps({"task":tid,"control":name,"raw":raw,"f2p":result.get("f2p_statuses")}),flush=True)
    put(out/"terminal.json",{"controls_completed":len(allresults),"experimental_model_calls":0,"paid_ready":False,
                             "source_unchanged":sources()==reg["source_sha256"]})
    print(json.dumps({"task":tid,"complete":True,"paid_ready":False}),flush=True)
if __name__=="__main__":
    if sys.argv[1]=="register":register()
    else:run(int(sys.argv[1]))
