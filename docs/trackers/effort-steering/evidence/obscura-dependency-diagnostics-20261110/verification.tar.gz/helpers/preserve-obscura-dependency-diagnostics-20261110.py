"""Seal completed trusted-reference dependency observations, without admitting an arm."""
from pathlib import Path
import hashlib, io, json, subprocess, tarfile
W=Path("/home/marius/work/claude/codescout/.worktrees/grader-stream-provenance-01a15ca9")
M=Path("/home/marius/work/claude/codescout")
L=W/".superpowers/sdd/2026-11-10-grader-stream-capture"
D=M/"docs/trackers/effort-steering/evidence/obscura-dependency-diagnostics-20261110"
SERIES=("trusted-reference-network-positive-v1","obscura-navigation-trace-v1","obscura-dom-trace-v1")
REGS=("trusted-reference-network-positive-20261110","obscura-navigation-trace-20261110","obscura-dom-trace-20261110")
def sha(b): return hashlib.sha256(b).hexdigest()
def put(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(v,indent=2,sort_keys=True)+"\n")
def main():
    members={}; origins={}; controls=[]
    def add(name,p):
        assert not p.is_symlink(), str(p)
        assert name not in members, name
        members[name]=p.read_bytes();origins[name]=p
    for series,regname in zip(SERIES,REGS):
        root=L/series
        regpath=M/"docs/trackers/effort-steering/evidence"/regname/"registration.json"
        reg=json.loads(regpath.read_text())
        assert all(sha((W/p).read_bytes())==h for p,h in reg["source_sha256"].items())
        task=root/"h4ckf0r0day__obscura-421"
        terminal=json.loads((task/"terminal.json").read_text())
        assert terminal["source_unchanged"] is True
        results=json.loads((task/"results.json").read_text());assert len(results)==1
        r=results[0];raw=r["raw"]
        assert not raw.get("error") and raw["missing"]==0 and raw["container_removed"] is True
        probe=subprocess.run(["docker","container","inspect",raw["container"]],capture_output=True,text=True,timeout=30)
        assert probe.returncode!=0 and "No such container" in probe.stderr
        assert sha(Path(raw["log"]).read_bytes())==r["log_sha256"]
        controls.append({"series":series,"name":r["name"],"expected":raw["expected"],
                         "not_passing":raw["not_passing"],"missing":raw["missing"],
                         "f2p_statuses":r["f2p_statuses"],"wall_seconds":raw["wall_seconds"],
                         "log_sha256":r["log_sha256"],"fresh_container_absence":True,
                         "source_hashes_unchanged":True})
        for p in sorted(root.rglob("*")):
            if p.is_file() and "__pycache__" not in p.parts:
                add(series+"/"+str(p.relative_to(root)),p)
        add("registrations/"+regname+".json",regpath)
    for p in (W/"tools/setup-ab-eval").iterdir():
        if p.is_file() and p.suffix in (".py",".sh"):add("grader-source/"+p.name,p)
    for name in ("probe-trusted-reference-network-20261110.py","probe-obscura-navigation-trace-20261110.py",
                 "probe-obscura-dom-trace-20261110.py","qualify-fixed-oracle-diagnostic-v2-20261110.py",
                 "qualify-fixed-oracle-diagnostic-20261110.py",Path(__file__).name):
        add("helpers/"+name,Path("/tmp")/name)
    for handle in ("cc","d0","d4"):
        p=Path("/tmp/codescout-bg/532382-bfc3fc33-bg_000000"+handle+".json")
        add("jobs/"+p.name,p)
    members["member-manifest.json"]=(json.dumps({n:{"sha256":sha(b),"bytes":len(b)} for n,b in sorted(members.items())},indent=2,sort_keys=True)+"\n").encode()
    D.mkdir(parents=True,exist_ok=True);archive=D/"verification.tar.gz";assert not archive.exists()
    with tarfile.open(archive,"w:gz") as tar:
        for name,b in sorted(members.items()):
            item=tarfile.TarInfo(name);item.size=len(b);item.mode=0o600;item.mtime=0
            tar.addfile(item,io.BytesIO(b))
    with tarfile.open(archive,"r:gz") as tar:
        items=tar.getmembers();assert all(i.isfile() for i in items)
        actual={i.name:tar.extractfile(i).read() for i in items}
    assert actual==members and all(origins[n].read_bytes()==members[n] for n in origins)
    closure={"schema":1,"scope":"trusted-reference diagnostics only","controls":controls,
             "paid_ready":False,"original_expected_sets_changed":False,"tasks_replaced":False,
             "experimental_model_repair_calls":0,"archive":{"bytes":archive.stat().st_size,
             "sha256":sha(archive.read_bytes()),"regular_members":len(members),
             "every_member_reopened_byte_equal":True,"source_files_unchanged_during_seal":True},
             "findings":["bridge resolves navigation/snapshot and title P2P; selector wait still fails",
                         "successful navigation followed by actual DOM h1=false and timeout",
                         "independent host raw HTML response has zero literal h1 start tags"],
             "limits":["diagnostic helper read calls may perturb timing","current service responses do not prove historic content",
                       "no hermetic service fixture qualified","no candidate/model networking authorization",
                       "no complete all-arm environment or efficacy qualification"]}
    put(D/"closure.json",closure);print(json.dumps(closure,indent=2))
if __name__=="__main__":main()
