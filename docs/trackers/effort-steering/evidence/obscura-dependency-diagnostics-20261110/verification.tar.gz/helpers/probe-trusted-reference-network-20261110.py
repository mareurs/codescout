"""Single trusted-reference egress diagnostic; never a model/candidate grading profile."""
from pathlib import Path
import importlib.util,json,sys
spec=importlib.util.spec_from_file_location("diagnostic_v2","/tmp/qualify-fixed-oracle-diagnostic-v2-20261110.py")
v2=importlib.util.module_from_spec(spec);spec.loader.exec_module(v2)
d=v2.d
d.ROOT=d.W/".superpowers/sdd/2026-11-10-grader-stream-capture/trusted-reference-network-positive-v1"
d.D=d.M/"docs/trackers/effort-steering/evidence/trusted-reference-network-positive-20261110"
original=d.tasks.pilot.docker
def trusted_reference_network(*args,**kwargs):
    if args and args[0]=="run":
        values=list(args);i=values.index("--network");assert values[i+1]=="none"
        values[i+1]="bridge";args=tuple(values)
    return original(*args,**kwargs)
d.tasks.pilot.docker=trusted_reference_network
if __name__=="__main__":
    if sys.argv[1]=="register":
        d.register()
        p=d.D/"registration.json";reg=json.loads(p.read_text())
        reg["controls"]=["reference-network-positive"]
        reg["scope"]="single known reference with explicit external networking; diagnostic only"
        reg["trusted_reference_only"]=True
        reg["private_runtime_profile"]={"user":"0:0","cpus":4,"memory":"8g","memory_swap":"8g","network":"bridge","cap_drop":"ALL"}
        reg["only_runtime_difference_from_v2"]="network none -> bridge"
        reg["external_network_authorized_for_model_candidates"]=False
        reg["no_host_home_or_token_mounts"]=True
        reg["decision"]="retain full expected set; passing reference supports network mismatch; failure leaves cause unresolved; neither outcome admits model/candidate network or paid work"
        reg["runtime_limits"]=["no host resource-floor or whole campaign qualification","external service availability may vary","trusted benchmark reference only"]
        reg["wrapper_sha256"]=d.sha(Path(__file__).read_bytes())
        d.put(p,reg);d.put(d.ROOT/"registration.json",reg)
    else:
        reg=json.loads((d.D/"registration.json").read_text())
        assert reg["trusted_reference_only"] is True and reg["controls"]==["reference-network-positive"]
        assert d.sha(Path(__file__).read_bytes())==reg["wrapper_sha256"]
        d.run(1)
