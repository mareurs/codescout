"""Explicit corrected private evaluator identity; v1 invalid evidence stays untouched."""
from pathlib import Path
import importlib.util,sys,json,hashlib
spec=importlib.util.spec_from_file_location("diagnostic_v1","/tmp/qualify-fixed-oracle-diagnostic-20261110.py")
d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
d.ROOT=d.W/".superpowers/sdd/2026-11-10-grader-stream-capture/fixed-oracle-diagnostic-v2"
d.D=d.M/"docs/trackers/effort-steering/evidence/fixed-oracle-diagnostic-v2-20261110"
original=d.tasks.pilot.docker
def private_runtime(*args,**kwargs):
    if args and args[0]=="run":
        args=("run","--user","0:0","--memory-swap","8g",*args[1:])
    return original(*args,**kwargs)
d.tasks.pilot.docker=private_runtime
if __name__=="__main__":
    if sys.argv[1]=="register":
        d.register()
        p=d.D/"registration.json";reg=json.loads(p.read_text())
        reg["predecessor"]={"path":str(d.M/"docs/trackers/effort-steering/evidence/fixed-oracle-diagnostic-20261110/registration.json"),
                            "disposition":"all six setup-invalid before any build/test; retained; not model failures"}
        reg["private_runtime_profile"]={"id":"private-evaluator-diagnostic-v2","user":"0:0","memory_swap":"8g",
                                       "root":"writable fresh container layer, no host source mounts",
                                       "reason":"UID1000 cannot apply patches to root-owned task source"}
        reg["runtime_limits"]=["source/runtime ownership probes and observation; not complete prospective admission",
                               "existing live_grader4CPU/8GiB with explicit totalmemory+swap8GiB and UID0:0",
                               "no cargo-v2 actor security/root parity claim; evaluator source patching requires separate writable layer"]
        reg["wrapper_sha256"]=d.sha(Path(__file__).read_bytes())
        reg["helper_path"]="/tmp/qualify-fixed-oracle-diagnostic-20261110.py"
        d.put(p,reg);d.put(d.ROOT/"registration.json",reg)
    else:
        reg=json.loads((d.D/"registration.json").read_text())
        assert d.sha(Path(__file__).read_bytes())==reg["wrapper_sha256"]
        d.run(int(sys.argv[1]))
