"""One trusted-reference transcript diagnostic; preserves original test assertions."""
from pathlib import Path
import importlib.util,json,sys,difflib
spec=importlib.util.spec_from_file_location("network_positive","/tmp/probe-trusted-reference-network-20261110.py")
n=importlib.util.module_from_spec(spec);spec.loader.exec_module(n)
d=n.d
d.ROOT=d.W/".superpowers/sdd/2026-11-10-grader-stream-capture/obscura-navigation-trace-v1"
d.D=d.M/"docs/trackers/effort-steering/evidence/obscura-navigation-trace-20261110"
original_records=d.records
def traced_records():
    records=original_records();r=records["h4ckf0r0day__obscura-421"]
    p="crates/obscura-cli/tests/mcp_client.rs"
    source=(Path("/home/marius/.cache/codescout-resident/codescout/evidence-cohort-20261110/common-obscura-421-v1/project")/p).read_text()
    old='        self.call("tools/call", serde_json::json!({ "name": name, "arguments": args }))'
    new='        eprintln!("EVAL_MCP_REQUEST {name} {args}");\n        let response = self.call("tools/call", serde_json::json!({ "name": name, "arguments": args }));\n        eprintln!("EVAL_MCP_RESPONSE {name} {response}");\n        response'
    assert source.count(old)==1
    modified=source.replace(old,new)
    patch="diff --git a/"+p+" b/"+p+"\n"+"".join(difflib.unified_diff(source.splitlines(True),modified.splitlines(True),fromfile="a/"+p,tofile="b/"+p))
    assert p not in d.tasks.tasks.patch_files(r["patch"])
    r["test_patch"]+="\n"+patch
    r["test_cmds"]=[r["test_cmds"][0].replace("--workspace","-p obscura-cli --test mcp_client test_wait_for_selector")]
    r["FAIL_TO_PASS"]=["obscura-cli::mcp_client$test_wait_for_selector"]
    r["PASS_TO_PASS"]=[]
    return records
d.records=traced_records
if __name__=="__main__":
    if sys.argv[1]=="register":
        d.register()
        p=d.D/"registration.json";reg=json.loads(p.read_text())
        reg["controls"]=["reference-navigation-trace"]
        reg["scope"]="single unchanged-assertion MCP wait test with request/response stderr observation"
        reg["trusted_reference_only"]=True;reg["network"]="bridge"
        reg["filtered"]=True;reg["original_full_expected_population_executed"]=False
        reg["decision"]="inspect previously ignored navigation result before wait; passing/failing filtered test grants no admission or model egress"
        reg["wrapper_sha256"]=d.sha(Path(__file__).read_bytes())
        reg["runtime_limits"]=["diagnostic only","source logging may affect timing","trusted reference only, no model/candidate networking"]
        d.put(p,reg);d.put(d.ROOT/"registration.json",reg)
    else:
        reg=json.loads((d.D/"registration.json").read_text())
        assert d.sha(Path(__file__).read_bytes())==reg["wrapper_sha256"]
        d.run(1)
