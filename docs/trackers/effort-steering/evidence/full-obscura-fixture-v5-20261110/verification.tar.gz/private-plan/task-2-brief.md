### Task 2: Full population and admission handoff

- [ ] Once fixture discrimination passes, preregister full331expected base/reference/reference-repeat. Baseline must fail only2F2P; reference/repeat all331pass with identical maps. Preserve all failures if expectations unmet.
- [ ] Verify unchanged assertions/expected population and final production/test/service hashes,networknone,readiness/requests,OOM/cleanup; preserve checked archive and exact runtime dependencies.
- [ ] Bind this PUBLIC fixture to common actor preparation/runtime and independent evaluation. No paid admission from evaluator-only success; parent all-arm qualification/review remains required.

## Self-review

Source inspected: McpClient::spawn launches only mcp; test_navigate_and_snapshot asserts domain,Example Domain and URL; env_allows_private_network accepts the child-only opt-in. Gold changes a separate JS bootstrap file. No claim yet that the local fixture compiles or passes; native discrimination is required. The plan introduces no candidate-production correction or task-specific repair prompt.


## Registered native discrimination — 2026-11-10

V2 serviceoff observed13pass/3fail but refused source-byte binding, retained as invalid for admission. [V3 registration](../evidence/hermetic-page-fixture-v3-20261110/registration.json) explicitly declares canonical public source + immutable-image tracked delta; no evaluator production edit. Native v3:serviceoff13pass/3fail(25.2s),correctpage16pass(20.0s),wrongpage15pass/selectorfail(22.3s),all0missing. All3complete streams/source/service bytes/runtime limits/networknone/global-private-env-absence/loopbackhosts/OOM0/fresh absence independently verified. Requests recorded0/8/8 respectively, including controller readiness. Task1 completion command:python3 .superpowers/sdd/2026-11-10-hermetic-page-fixture/verify_task1.py. Full331andcommonactorbinding remain Task2.

The first registration attempt stopped on a misspelled runner constant before any native run; failed helper preserved. Corrected NEXT contract and explicit empty stderr_files were read from actual source. A separate all-indexed-path audit measured all133Obscuraimagepaths:130match,3differ(.gitignore plus2sourcefiles). Lean audit refused gitlink160000 aur/lean-ctx-bin before producing a count; it does not establish broad Lean source parity. All such failed instruments and their exact outputs remain retained.
