### Task 1: Preregister and run native fixture discrimination

**Files:** private loopback_page.py,helper,derived record,registration,complete controls in a new grader-owned scratch directory. Public MCP test file may be modified only in fresh evaluator containers. No production edits.
**Interfaces:** fixture serves literal HTML title/h1 Example Domain on127.0.0.1:18080; runner owns readiness/start/stop and request logs. Derived record preserves original expected arrays and literal rebuild/test/print commands for full controls; a separate3test filtered record is diagnostic only.

- [ ] Verify original MCP source/args,URL occurrences,original assertions and gold paths; freeze exact test-input patch and fixture bytes before native runs.
- [ ] Run filtered known-reference with serviceoff:3dependent tests must fail,0missing,full streams; no setup error.
- [ ] Run filtered known-reference with serviceon:3dependent tests must pass,0missing,full streams,actual source/runtime/hosts/environment bindings.
- [ ] Run wrong-page negative control (no h1):selector must fail while navigation/title still pass. Keep all outcome/status records.

