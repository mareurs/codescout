"""Private evaluator diagnostics for a public fixed-page fixture; never paid admission."""
from pathlib import Path
import difflib,hashlib,json,subprocess,sys,tempfile,time
sys.dont_write_bytecode=True
W=Path("/home/marius/work/claude/codescout/.worktrees/grader-stream-provenance-01a15ca9")
M=Path("/home/marius/work/claude/codescout")
PLAN=W/".superpowers/sdd/2026-11-10-hermetic-page-fixture"
L=PLAN/"full-native-v4"
D=M/"docs/trackers/effort-steering/evidence/full-obscura-fixture-v4-20261110"
P=Path("/home/marius/.cache/codescout-resident/codescout/evidence-cohort-20261110/common-obscura-421-v1/project")
DATA=Path("/home/marius/work/claude/setup-ab-data/live/multilang-rust.jsonl")
IMAGE="sha256:b22988cd6022dd7a428a750799114b9c6f09bcaecc4fd9d8b86a0ef8502772d1"
TID="h4ckf0r0day__obscura-421"
TEST="crates/obscura-cli/tests/mcp_client.rs"
KEY="obscura-cli::mcp_client$"
WITNESSES=[KEY+n for n in ("test_navigate_and_snapshot","test_evaluate","test_wait_for_selector")]
sys.path.insert(0,str(W/"tools/setup-ab-eval"))
import multilang_tasks as tasks,multilang_grade as grade,stream_evidence as streams
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+"\n")
def sources():return {str(p.relative_to(W)):sha(p.read_bytes()) for p in (W/"tools/setup-ab-eval").glob("*.py")}
def original_record():
    assert sha(DATA.read_bytes())=="bf2dd8252a07d0f275663ef8f6ab87571dd9bc4ce386abf9ec98d3cd6bb51a81"
    return next(r for x in DATA.open() if (r:=json.loads(x)).get("instance_id")==TID)
def register():
    assert not D.exists() and not L.exists();D.mkdir();L.mkdir()
    (L/"loopback_page.py").write_bytes((PLAN/"native-v3/loopback_page.py").read_bytes())
    delta=(PLAN/"native-v3/public-image-baseline.patch").read_bytes()
    assert sha(delta)=="bc866989ce78547fde62c14b4d9abdde03a4b47ae69733916af09c802291256f"
    (L/"public-image-baseline.patch").write_bytes(delta)
    original=original_record();r=dict(original)
    fixture=(PLAN/"native-v3/public-fixture.patch").read_bytes()
    assert sha(fixture)==json.loads((PLAN/"native-v3/registration.json").read_text())["fixture_patch_sha256"]
    (L/"public-fixture.patch").write_bytes(fixture)
    r["test_patch"]=original["test_patch"]+"\n"+fixture.decode()
    assert all(r[k]==original[k] for k in ("rebuild_cmds","test_cmds","print_cmds","FAIL_TO_PASS","PASS_TO_PASS"))
    selected=r["FAIL_TO_PASS"]+r["PASS_TO_PASS"]
    assert len(selected)==len(set(selected))==331 and len(r["FAIL_TO_PASS"])==2
    put(L/"full-record.json",r)
    binding=Path(tempfile.mkdtemp(prefix="effort-obscura-full-source-",dir="/tmp"))
    paths=sorted(set(tasks.tasks.patch_files(original["patch"]))|set(tasks.tasks.patch_files(delta.decode()))|{TEST})
    for rel in paths:
        p=binding/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((P/rel).read_bytes())
    baseline=binding/"image-baseline.patch";baseline.write_bytes(delta)
    p=subprocess.run(["git","apply","--unsafe-paths",str(baseline)],cwd=binding,capture_output=True,text=True,timeout=30)
    put(binding/"baseline-apply.json",{"returncode":p.returncode,"stdout":p.stdout,"stderr":p.stderr});assert p.returncode==0
    expected_base={"/testbed/"+rel:sha((binding/rel).read_bytes()) for rel in paths}
    old='            .args(["mcp"])'
    changed=(P/TEST).read_text().replace("https://example.com","http://example.com:18080").replace(old,old+'\n            .env("OBSCURA_ALLOW_PRIVATE_NETWORK", "1")')
    expected_base["/testbed/"+TEST]=sha(changed.encode())
    ref=binding/"reference.patch";ref.write_text(original["patch"])
    p=subprocess.run(["git","apply","--unsafe-paths",str(ref)],cwd=binding,capture_output=True,text=True,timeout=30)
    put(binding/"reference-apply.json",{"returncode":p.returncode,"stdout":p.stdout,"stderr":p.stderr});assert p.returncode==0
    expected_ref={"/testbed/"+rel:sha((binding/rel).read_bytes()) for rel in paths}
    expected_ref["/testbed/"+TEST]=sha(changed.encode())
    reg={"schema":4,"task":TID,"scope":"full original331expected tests with public fixed-page fixture",
         "controls":{"base":"good","reference":"good","reference-repeat":"good"},
         "public_baseline":"canonical base PLUS declared existing immutable-image workingtree delta",
         "public_baseline_delta_sha256":sha(delta),"fixture_patch_sha256":sha(fixture),
         "original_dataset_sha256":sha(DATA.read_bytes()),"original_record_sha256":sha(json.dumps(original,sort_keys=True).encode()),
         "original_expected_sha256":sha(json.dumps([r["FAIL_TO_PASS"],r["PASS_TO_PASS"]],sort_keys=True).encode()),
         "record_sha256":sha((L/"full-record.json").read_bytes()),"helper_sha256":sha(Path(__file__).read_bytes()),
         "service_sha256":sha((L/"loopback_page.py").read_bytes()),"source_sha256":sources(),
         "expected_source_by_control":{"base":expected_base,"reference":expected_ref,"reference-repeat":expected_ref},
         "binding_source_root":str(binding),"expected_selected":selected,
         "original_f2p":r["FAIL_TO_PASS"],"original_p2p":r["PASS_TO_PASS"],
         "image":IMAGE,"step_timeout_s":900,
         "runtime":{"user":"0:0","network":"none","cpus":4,"memory":"8g","memory_swap":"8g","init":True,"add_host":"example.com:127.0.0.1"},
         "stream_registration":{"version":streams.VERSION,"commands_sha256":streams.commands_digest(r),"tests":[{"profile":streams.NEXT,"reports":[0],"stderr_files":[]}]},
         "assertions_unchanged":True,"commands_unchanged":True,"expected_population_unchanged":True,
         "experimental_model_calls":0,"paid_ready":False,
         "decision":"base must fail exactly2original F2P and pass329P2P; reference/repeat all331pass with identical maps",
         "limits":["HTTP fixture does not qualify TLS","common actor/public source/index/runtime binding still required","whole-admission review pending"]}
    put(D/"registration.json",reg);put(L/"registration.json",reg)
    print(json.dumps({"registration":str(D/"registration.json"),"expected":331,"paid_ready":False}))
def runtime_registration(role):
    reg=json.loads((D/"registration.json").read_text())
    assert role in reg["controls"]
    reg["expected_source"]=reg["expected_source_by_control"][role]
    return reg

def run(role):
    reg=runtime_registration(role);mode=reg["controls"][role]
    assert sources()==reg["source_sha256"]
    assert sha(Path(__file__).read_bytes())==reg["helper_sha256"]
    assert sha((L/"loopback_page.py").read_bytes())==reg["service_sha256"]
    assert sha((L/"full-record.json").read_bytes())==reg["record_sha256"]
    r=json.loads((L/"full-record.json").read_text())
    out=L/role;out.mkdir(exist_ok=False)
    docker=tasks.pilot.docker;observations=[]
    def observe(name,stage):
        item={"container":name,"stage":stage,"at":time.time()}
        p=docker("inspect",name,check=False,timeout=60);item["inspect_rc"]=p.returncode
        if p.returncode==0:item["inspect"]=json.loads(p.stdout)[0]
        p=docker("exec",name,"sh","-c","for f in /sys/fs/cgroup/memory.events /sys/fs/cgroup/memory.max /sys/fs/cgroup/memory.swap.max /sys/fs/cgroup/cpu.max; do printf '%s\\n' \"$f\"; cat \"$f\"; done",check=False,timeout=60)
        item["cgroup_rc"]=p.returncode;item["cgroup"]=p.stdout
        if stage=="before-remove":
            p=docker("exec",name,"sha256sum",*reg["expected_source"],check=False,timeout=60)
            item["source_rc"]=p.returncode;item["source_output"]=p.stdout
            if p.returncode==0:item["source_sha256"]={line.split(maxsplit=1)[1].strip():line.split()[0] for line in p.stdout.splitlines()}
            code="from pathlib import Path;import json,hashlib;root=Path('/tmp/effort-loopback-page');s=Path('/tmp/effort-loopback-page.py');print(json.dumps({'program_sha256':hashlib.sha256(s.read_bytes()).hexdigest(),'ready':json.loads((root/'ready.json').read_text()) if (root/'ready.json').exists() else None,'requests':[json.loads(x) for x in (root/'requests.jsonl').read_text().splitlines()] if (root/'requests.jsonl').exists() else []}))"
            p=docker("exec",name,"python3","-c",code,check=False,timeout=60)
            item["service_packet_rc"]=p.returncode
            if p.returncode==0:item["service_packet"]=json.loads(p.stdout)
        observations.append(item);put(out/"runtime.json",observations)
    def prepare(name):
        install="from pathlib import Path;import sys;Path('/tmp/effort-loopback-page.py').write_text(sys.stdin.read())"
        docker("exec","-i",name,"python3","-c",install,data=(L/"loopback_page.py").read_text(),timeout=60)
        if mode!="off":docker("exec","-d",name,"python3","-u","/tmp/effort-loopback-page.py",mode,timeout=60)
        probe="""import hashlib,json,os,socket,time,urllib.request
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
packet={'global_private_env':os.environ.get('OBSCURA_ALLOW_PRIVATE_NETWORK'),'resolved':sorted({a[4][0] for a in socket.getaddrinfo('example.com',18080)})}
for attempt in range(50):
    try:
        response=opener.open('http://example.com:18080',timeout=1);body=response.read()
        packet.update({'reachable':True,'status':response.status,'body_sha256':hashlib.sha256(body).hexdigest()});break
    except OSError as exc:
        packet.update({'reachable':False,'error':str(exc)})
        time.sleep(.05)
print(json.dumps(packet))
"""
        p=docker("exec",name,"python3","-c",probe,check=False,timeout=30)
        packet=json.loads(p.stdout) if p.returncode==0 else {"probe_error":p.stdout}
        put(out/"service-readiness.json",packet)
        assert packet.get("global_private_env") is None and packet.get("resolved")==["127.0.0.1"]
        assert packet.get("reachable") is (mode!="off")
    def watched(*args,**kwargs):
        if args and args[0]=="run":args=("run","--user","0:0","--memory-swap","8g","--init","--add-host","example.com:127.0.0.1",*args[1:])
        if args and args[0]=="rm":
            for a in args[1:]:
                if isinstance(a,str) and a.startswith(tasks.GRADE_PREFIX):observe(a,"before-remove")
        value=docker(*args,**kwargs)
        if args and args[0]=="run" and value.returncode==0:
            name=args[args.index("--name")+1];prepare(name);observe(name,"after-start")
        return value
    tasks.pilot.docker=watched;tasks.GRADE_STEP_TIMEOUT=reg["step_timeout_s"]
    bundle={"workdir":"/testbed","expected":{"fail_to_pass":len(r["FAIL_TO_PASS"]),"pass_to_pass_kept":len(r["PASS_TO_PASS"]),"dropped":[],"fail_to_pass_dropped":[]}}
    grader=tasks.live_grader(r,bundle,IMAGE,out,capture_streams=True)
    raw=grader("" if role=="base" else r["patch"],role)
    result={"name":role,"mode":mode,"raw":raw,"paid_ready":False,"original_full_expected_population_executed":True}
    p=Path(raw.get("log",""))
    if p.is_file():
        log=p.read_text();full=json.loads(p.with_name("grade.json").read_text())
        parsed=grade.run_parser(r["log_parser"],log)
        result["statuses"]={k:parsed.get(k) for k in reg["expected_selected"]}
        try:
            result["diagnostics"]=streams.qualify(full,r,log,reg["stream_registration"]);result["complete_stream_contract"]=True
        except streams.EvidenceError as exc:
            result["complete_stream_contract"]=False;result["stream_error"]=str(exc)
    p=subprocess.run(["docker","container","inspect",raw["container"]],capture_output=True,text=True,timeout=30)
    result["fresh_container_absent"]=p.returncode!=0 and "No such container" in p.stderr
    result["applied_source_bytes_verified"]=any(o.get("source_sha256")==reg["expected_source"] for o in observations)
    result["service_bytes_verified"]=any(o.get("service_packet",{}).get("program_sha256")==reg["service_sha256"] for o in observations)
    result["source_unchanged"]=sources()==reg["source_sha256"]
    put(out/"result.json",result)
    print(json.dumps({"name":role,"raw":raw,"streams":result.get("complete_stream_contract"),"source_bytes":result["applied_source_bytes_verified"],"service_bytes":result["service_bytes_verified"],"paid_ready":False},indent=2))
if __name__=="__main__":
    if sys.argv[1]=="register":register()
    else:run(sys.argv[1])
