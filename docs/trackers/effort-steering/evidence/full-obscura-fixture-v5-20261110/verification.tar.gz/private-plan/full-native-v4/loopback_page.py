"""Public static page fixture: loopback only, no external calls or test-state input."""
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
import hashlib, json, os, sys, time
GOOD=b"<!doctype html><html><head><title>Example Domain</title></head><body><h1>Example Domain</h1><p>Fixed local navigation fixture.</p></body></html>"
WRONG=b"<!doctype html><html><head><title>Example Domain</title></head><body><p>Fixed local navigation fixture without a heading.</p></body></html>"
mode=sys.argv[1]
assert mode in ("good","wrong")
body=GOOD if mode=="good" else WRONG
root=Path("/tmp/effort-loopback-page")
root.mkdir(exist_ok=True)
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        status=404 if self.path=="/robots.txt" else 200
        payload=b"" if status==404 else body
        self.send_response(status)
        self.send_header("Content-Type","text/html; charset=utf-8")
        self.send_header("Content-Length",str(len(payload)))
        self.send_header("Connection","close")
        self.end_headers()
        self.wfile.write(payload)
        with (root/"requests.jsonl").open("a") as out:
            out.write(json.dumps({"at":time.time(),"method":"GET","path":self.path,"status":status,
                                  "body_sha256":hashlib.sha256(payload).hexdigest()})+"\n")
    def log_message(self,*args):
        pass
server=HTTPServer(("127.0.0.1",18080),Handler)
(root/"ready.json").write_text(json.dumps({"pid":os.getpid(),"mode":mode,"address":["127.0.0.1",18080],
                                          "body_sha256":hashlib.sha256(body).hexdigest(),"started":time.time()})+"\n")
server.serve_forever()
