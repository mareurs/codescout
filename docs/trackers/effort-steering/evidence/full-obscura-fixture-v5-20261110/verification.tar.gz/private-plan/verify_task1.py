"""Fresh proof of native serviceoff/on/wrong-page discrimination, not admission."""
from pathlib import Path
import hashlib,json,subprocess,sys
sys.dont_write_bytecode=True
PLAN=Path(__file__).parent;L=PLAN/"native-v3"
W=PLAN.parents[2]
sys.path.insert(0,str(W/"tools/setup-ab-eval"))
import multilang_grade as grade,stream_evidence as streams
def sha(b):return hashlib.sha256(b).hexdigest()
def verify_public_inputs(reg,record):
    data=Path("/home/marius/work/claude/setup-ab-data/live/multilang-rust.jsonl")
    assert sha(data.read_bytes())==reg["original_dataset_sha256"]
    original=next(r for x in data.open() if (r:=json.loads(x)).get("instance_id")==reg["task"])
    public=Path("/home/marius/.cache/codescout-resident/codescout/evidence-cohort-20261110/common-obscura-421-v1/project/crates/obscura-cli/tests/mcp_client.rs").read_text()
    old='            .args(["mcp"])'
    new=old+'\n            .env("OBSCURA_ALLOW_PRIVATE_NETWORK", "1")'
    assert public.count(old)==1 and public.count("https://example.com")==7
    changed=public.replace("https://example.com","http://example.com:18080").replace(old,new)
    assert changed.replace("http://example.com:18080","https://example.com").replace(new,old)==public
    assert sha(changed.encode())==reg["expected_source"]["/testbed/crates/obscura-cli/tests/mcp_client.rs"]
    assert record["test_patch"]==original["test_patch"]+"\n"+(L/"public-fixture.patch").read_text()
    assert reg["expected_mcp"]==[k for k in original["FAIL_TO_PASS"]+original["PASS_TO_PASS"] if k.startswith("obscura-cli::mcp_client$")]
    assert original["rebuild_cmds"]==record["rebuild_cmds"] and original["print_cmds"]==record["print_cmds"]

def verify():
    reg=json.loads((L/"registration.json").read_text())
    assert all(sha((W/p).read_bytes())==h for p,h in reg["source_sha256"].items())
    assert sha((PLAN/"qualify_fixture_v3.py").read_bytes())==reg["helper_sha256"]
    assert sha((L/"loopback_page.py").read_bytes())==reg["service_sha256"]
    assert sha((L/"filtered-record.json").read_bytes())==reg["record_sha256"]
    assert sha((L/"public-image-baseline.patch").read_bytes())==reg["public_baseline_delta_sha256"]
    record=json.loads((L/"filtered-record.json").read_text())
    verify_public_inputs(reg,record)
    witnesses=reg["witnesses"];controls={}
    for role,mode in reg["controls"].items():
        root=L/role;result=json.loads((root/"result.json").read_text());raw=result["raw"]
        assert not raw.get("error") and raw["expected"]==16 and raw["missing"]==0
        assert result["complete_stream_contract"] is True and result["applied_source_bytes_verified"] is True
        assert result["service_bytes_verified"] is True and result["source_unchanged"] is True
        assert raw["oom_killed"] is False and raw["container_removed"] is True
        log=Path(raw["log"]);full=json.loads(log.with_name("grade.json").read_text())
        streams.qualify(full,record,log.read_text(),reg["stream_registration"])
        parsed=grade.run_parser(record["log_parser"],log.read_text())
        statuses={k:parsed.get(k) for k in reg["expected_mcp"]}
        assert statuses==result["statuses"] and all(v in ("pass","fail") for v in statuses.values())
        failed={k for k,v in statuses.items() if v=="fail"}
        expected_fail=set(witnesses) if mode=="off" else ({witnesses[2]} if mode=="wrong" else set())
        assert failed==expected_fail and raw["not_passing"]==len(expected_fail)
        readiness=json.loads((root/"service-readiness.json").read_text())
        assert readiness["global_private_env"] is None and readiness["resolved"]==["127.0.0.1"]
        assert readiness["reachable"] is (mode!="off")
        observations=json.loads((root/"runtime.json").read_text());assert len(observations)==2
        for item in observations:
            assert item["inspect_rc"]==item["cgroup_rc"]==0 and "oom_kill 0" in item["cgroup"]
            cfg=item["inspect"]["HostConfig"];env=item["inspect"]["Config"]["Env"]
            assert cfg["NetworkMode"]=="none" and cfg["ExtraHosts"]==["example.com:127.0.0.1"]
            assert cfg["Memory"]==cfg["MemorySwap"]==8589934592 and cfg["NanoCpus"]==4000000000
            assert cfg["Init"] is True and cfg["CapDrop"]==["ALL"] and cfg["PidsLimit"]==4096
            assert item["inspect"]["Config"]["User"]=="0:0"
            assert not any(x.startswith("OBSCURA_ALLOW_PRIVATE_NETWORK=") for x in env)
            assert not any(x["Type"]=="bind" for x in item["inspect"]["Mounts"])
        final=observations[-1];assert final["source_sha256"]==reg["expected_source"]
        packet=final["service_packet"];assert packet["program_sha256"]==reg["service_sha256"]
        if mode=="off":assert packet["ready"] is None and packet["requests"]==[]
        else:
            assert packet["ready"]["mode"]==mode and packet["ready"]["address"]==["127.0.0.1",18080]
            assert readiness["body_sha256"]==packet["ready"]["body_sha256"]
            assert len(packet["requests"])>=2
            assert all(x["body_sha256"]==packet["ready"]["body_sha256"] for x in packet["requests"] if x["status"]==200)
        p=subprocess.run(["docker","container","inspect",raw["container"]],capture_output=True,text=True,timeout=30)
        assert p.returncode!=0 and "No such container" in p.stderr
        controls[role]={"expected":16,"not_passing":len(failed),"missing":0,"failed_names":sorted(failed),
                        "wall_seconds":raw["wall_seconds"],"complete_streams_requalified":True,"source_and_service_bytes":True,
                        "global_private_env_absent":True,"actual_host_mapping_loopback_only":True,
                        "network_none_limits_and_oom_zero":True,"fresh_container_absence":True,
                        "fixture_requests_recorded":len(packet["requests"]),"log_sha256":sha(log.read_bytes())}
    proof={"task1_verified":True,"controls":controls,"assertions_unchanged":True,
           "public_baseline_delta_explicit":True,"full_original_population_executed":False,
           "common_actor_source_context_runtime_bound":False,"paid_ready":False,
           "known_limits":["HTTP fixture does not qualify TLS","Obscura old canonical public prep lacks2image source edits",
                           "Lean broader indexed-path audit refused unsupported gitlink160000 aur/lean-ctx-bin; no whole-source parity claim",
                           "full331base/reference/repeat pending","whole-admission independent review pending"]}
    (PLAN/"task1-verification.json").write_text(json.dumps(proof,indent=2,sort_keys=True)+"\n")
    return proof
if __name__=="__main__":print(json.dumps(verify(),indent=2))
