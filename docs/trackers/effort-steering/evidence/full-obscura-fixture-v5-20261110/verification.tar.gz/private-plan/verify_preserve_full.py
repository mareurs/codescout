"""Full original Obscura population audit; preserve v4 collision and v5 correction."""
from pathlib import Path
import hashlib,io,json,subprocess,sys,tarfile
sys.dont_write_bytecode=True
PLAN=Path(__file__).parent;W=PLAN.parents[2]
M=Path("/home/marius/work/claude/codescout")
L=PLAN/"full-native-v5"
D=M/"docs/trackers/effort-steering/evidence/full-obscura-fixture-v5-20261110"
sys.path.insert(0,str(W/"tools/setup-ab-eval"))
import multilang_grade as grade,stream_evidence as streams
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+"\n")
def verify():
    reg=json.loads((D/"registration.json").read_text());record=json.loads((L/"full-record.json").read_text())
    data=Path("/home/marius/work/claude/setup-ab-data/live/multilang-rust.jsonl")
    assert sha(data.read_bytes())==reg["original_dataset_sha256"]
    original=next(r for x in data.open() if (r:=json.loads(x)).get("instance_id")==reg["task"])
    for key in ("rebuild_cmds","test_cmds","print_cmds","FAIL_TO_PASS","PASS_TO_PASS"):assert record[key]==original[key]
    assert record["test_patch"]==original["test_patch"]+"\n"+(L/"public-fixture.patch").read_text()
    source=Path("/home/marius/.cache/codescout-resident/codescout/evidence-cohort-20261110/common-obscura-421-v1/project/crates/obscura-cli/tests/mcp_client.rs").read_text()
    old='            .args(["mcp"])';new=old+'\n            .env("OBSCURA_ALLOW_PRIVATE_NETWORK", "1")'
    changed=source.replace("https://example.com","http://fixture.example.com:18080").replace(old,new)
    assert source.count("https://example.com")==7 and source.count(old)==1
    assert changed.replace("http://fixture.example.com:18080","https://example.com").replace(new,old)==source
    assert sha((PLAN/"qualify_full_fixture_v5.py").read_bytes())==reg["helper_sha256"]
    assert sha((L/"full-record.json").read_bytes())==reg["record_sha256"]
    assert all(sha((W/p).read_bytes())==h for p,h in reg["source_sha256"].items())
    expected=original["FAIL_TO_PASS"]+original["PASS_TO_PASS"];assert len(expected)==len(set(expected))==331
    controls={};maps={}
    security="obscura-net::obscura_net$client::ssrf_tests::resolver_does_not_ssrf_block_public_host"
    for role in reg["controls"]:
        root=L/role;r=json.loads((root/"result.json").read_text());raw=r["raw"]
        assert not raw.get("error") and raw["expected"]==331 and raw["missing"]==0
        assert r["complete_stream_contract"] is True and r["source_unchanged"] is True
        assert r["applied_source_bytes_verified"] is True and r["service_bytes_verified"] is True
        assert raw["container_removed"] is True and raw["oom_killed"] is False
        log=Path(raw["log"]);full=json.loads(log.with_name("grade.json").read_text())
        streams.qualify(full,record,log.read_text(),reg["stream_registration"])
        parsed=grade.run_parser(record["log_parser"],log.read_text())
        statuses={k:parsed.get(k) for k in expected}
        assert statuses==r["statuses"] and all(v in ("pass","fail") for v in statuses.values())
        failed={k for k,v in statuses.items() if v!="pass"}
        assert failed==(set(original["FAIL_TO_PASS"]) if role=="base" else set())
        assert raw["not_passing"]==len(failed) and statuses[security]=="pass";maps[role]=statuses
        runtime=json.loads((root/"runtime.json").read_text());assert len(runtime)==2
        for item in runtime:
            assert item["inspect_rc"]==item["cgroup_rc"]==0 and "oom_kill 0" in item["cgroup"]
            cfg=item["inspect"]["HostConfig"]
            assert cfg["NetworkMode"]=="none" and cfg["ExtraHosts"]==["fixture.example.com:127.0.0.1"]
            assert cfg["Memory"]==cfg["MemorySwap"]==8589934592 and cfg["NanoCpus"]==4000000000
            assert cfg["Init"] is True and cfg["CapDrop"]==["ALL"] and cfg["PidsLimit"]==4096
            assert item["inspect"]["Config"]["User"]=="0:0"
            assert not any(x.startswith("OBSCURA_ALLOW_PRIVATE_NETWORK=") for x in item["inspect"]["Config"]["Env"])
            assert not any(x["Type"]=="bind" for x in item["inspect"]["Mounts"])
        expected_source=reg["expected_source_by_control"][role]
        assert runtime[-1]["source_sha256"]==expected_source
        assert expected_source["/testbed/crates/obscura-cli/tests/mcp_client.rs"]==sha(changed.encode())
        packet=runtime[-1]["service_packet"];ready=json.loads((root/"service-readiness.json").read_text())
        assert packet["program_sha256"]==reg["service_sha256"]==sha((L/"loopback_page.py").read_bytes())
        assert packet["ready"]["mode"]=="good" and packet["ready"]["address"]==["127.0.0.1",18080]
        assert ready["reachable"] is True and ready["resolved"]==["127.0.0.1"] and ready["global_private_env"] is None
        assert ready["body_sha256"]==packet["ready"]["body_sha256"]
        assert packet["requests"] and all(x["body_sha256"]==packet["ready"]["body_sha256"] for x in packet["requests"] if x["status"]==200)
        p=subprocess.run(["docker","container","inspect",raw["container"]],capture_output=True,text=True,timeout=30)
        assert p.returncode!=0 and "No such container" in p.stderr
        controls[role]={"expected":331,"not_passing":len(failed),"missing":0,"failed_names":sorted(failed),
                        "wall_seconds":raw["wall_seconds"],"security_p2p_pass":True,"complete_streams_requalified":True,
                        "source_service_and_runtime_verified":True,"fresh_container_absence":True,
                        "http_entries_including_readiness":len(packet["requests"]),"log_sha256":sha(log.read_bytes())}
    assert maps["reference"]==maps["reference-repeat"]
    return {"scope":"full original Obscura acceptance controls only","controls":controls,
            "reference_repeat_selected_maps_identical":True,"native_negative_positive_repeat_predicates_satisfied":True,
            "original_commands_assertions_expected_population_unchanged":True,"public_host_security_test_preserved":True,
            "public_baseline_delta_explicit":True,"common_actor_context_source_runtime_bound":False,
            "host_resource_floor_qualified":False,"whole_campaign_reviewed":False,"paid_ready":False}
def seal(proof):
    members={};origins={}
    def add(name,p):
        assert not p.is_symlink(),str(p)
        assert name not in members
        members[name]=p.read_bytes();origins[name]=p
    for p in sorted(PLAN.rglob("*")):
        if p.is_file():add("private-plan/"+str(p.relative_to(PLAN)),p)
    for version in ("full-native-v4","full-native-v5"):
        reg=json.loads((PLAN/version/"registration.json").read_text())
        root=Path(reg["binding_source_root"])
        for p in sorted(root.rglob("*")):
            if p.is_file():add(version+"-original-source-binding/"+str(p.relative_to(root)),p)
    for dirname in ("full-obscura-fixture-v4-20261110","full-obscura-fixture-v5-20261110"):
        add("registrations/"+dirname+".json",M/"docs/trackers/effort-steering/evidence"/dirname/"registration.json")
    for p in (W/"tools/setup-ab-eval").iterdir():
        if p.is_file() and p.suffix in (".py",".sh"):add("grader-source/"+p.name,p)
    for handle in ("e2","e3","e4","e5","e6"):
        p=Path("/tmp/codescout-bg/532382-bfc3fc33-bg_000000"+handle+".json");add("jobs/"+p.name,p)
    members["root-full-audit.json"]=(json.dumps(proof,indent=2,sort_keys=True)+"\n").encode()
    members["member-manifest.json"]=(json.dumps({n:{"bytes":len(b),"sha256":sha(b)} for n,b in sorted(members.items())},indent=2,sort_keys=True)+"\n").encode()
    archive=D/"verification.tar.gz";assert not archive.exists()
    with tarfile.open(archive,"w:gz") as tar:
        for n,b in sorted(members.items()):
            item=tarfile.TarInfo(n);item.size=len(b);item.mode=0o600;item.mtime=0
            tar.addfile(item,io.BytesIO(b))
    with tarfile.open(archive) as tar:
        items=tar.getmembers();assert all(i.isfile() for i in items)
        actual={i.name:tar.extractfile(i).read() for i in items}
    assert actual==members and all(origins[n].read_bytes()==members[n] for n in origins)
    closure={"schema":1,"proof":proof,"archive":{"bytes":archive.stat().st_size,"sha256":sha(archive.read_bytes()),
              "regular_members":len(members),"all_members_reopened_byte_equal":True,"all_originals_unchanged_during_seal":True},
              "preserved_failed_control_version":"v4hostname collision;2of3controls executed,repeat explicitly notexecuted",
              "experimental_model_repair_calls":0,"paid_ready":False,
              "open":["common public image delta+namespaced page fixture actor preparation/index/runtime binding",
                      "all-arm CLI/context/prompt/effort qualification","host resource floor","F6linker classification",
                      "whole-controller/accounting review and immutable paid preflight","low/xhigh efficacy"]}
    put(D/"closure.json",closure);return closure
if __name__=="__main__":
    proof=verify()
    if len(sys.argv)>1 and sys.argv[1]=="seal":out=seal(proof)
    else:out=proof
    print(json.dumps(out,indent=2))
