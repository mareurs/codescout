"""Read-only audit of tracked image changes against the public canonical commit."""
from pathlib import Path
import hashlib,json,subprocess,uuid
D=Path(__file__).parent/"image-working-tree-audit-v1";D.mkdir(exist_ok=False)
image="sha256:b22988cd6022dd7a428a750799114b9c6f09bcaecc4fd9d8b86a0ef8502772d1"
base="99ece0e12dd2cace768b5caa76fcbe1b5233f0f6"
name="sab-readonly-source-diff-"+uuid.uuid4().hex[:8]
args=["docker","run","--name",name,"--network","none","--read-only","--cap-drop","ALL","--security-opt","no-new-privileges","--user","0:0","--memory","2g","--memory-swap","2g","--cpus","1","--pids-limit","128","--entrypoint","git",image,"--no-optional-locks","-c","safe.directory=/testbed","-C","/testbed","diff","--binary",base]
(D/"registration.json").write_text(json.dumps({"argv":args,"scope":"read-only tracked source diff; no candidate or test run","paid_ready":False},indent=2)+"\n")
try:
    p=subprocess.run(args,capture_output=True,timeout=180)
    (D/"working-tree.patch").write_bytes(p.stdout);(D/"stderr").write_bytes(p.stderr)
    result={"returncode":p.returncode,"bytes":len(p.stdout),"sha256":hashlib.sha256(p.stdout).hexdigest(),
            "patch_file_headers":[x.decode() for x in p.stdout.splitlines() if x.startswith(b"diff --git ")],"paid_ready":False}
finally:
    p=subprocess.run(["docker","container","inspect",name],capture_output=True)
    (D/"inspect.json").write_bytes(p.stdout)
    p=subprocess.run(["docker","rm","-f",name],capture_output=True);result["remove_rc"]=p.returncode
    p=subprocess.run(["docker","container","inspect",name],capture_output=True);result["fresh_absence"]=p.returncode!=0 and b"No such container" in p.stderr
    (D/"result.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
