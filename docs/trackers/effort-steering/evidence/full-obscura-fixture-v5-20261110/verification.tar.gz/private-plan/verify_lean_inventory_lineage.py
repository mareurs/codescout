"""Calibrate the HEAD-scoped gitlink observation against the registered public base."""
from pathlib import Path
import json,subprocess,uuid
PLAN=Path(__file__).parent
ROOT=Path("/home/marius/.cache/codescout-resident/codescout/evidence-cohort-20261110")
audit=json.loads((PLAN/"tracked-source-parity-lean-v3/result.json").read_text())
rows=json.loads((PLAN/"tracked-source-parity-lean-v3/image-paths.json").read_text())["indexed_paths"]
export=json.loads((ROOT/"lean-ctx-1168-public-v1/registration.json").read_text())
manifest=json.loads((ROOT/"lean-ctx-1168-public-v1/public-source-manifest.json").read_text())
base=export["task"]["base_commit"];link="aur/lean-ctx-bin"
canonical=set(manifest["files"])|set(manifest["links"])
physical={k for k,v in rows.items() if v["kind"]!="gitlink"}
assert canonical==physical
name="sab-readonly-lean-lineage-"+uuid.uuid4().hex[:8]
args=["docker","run","--name",name,"--network","none","--read-only","--cap-drop","ALL","--user","0:0","--memory","2g","--memory-swap","2g","--cpus","1","--entrypoint","git",audit["image"],"--no-optional-locks","-c","safe.directory=/testbed","-C","/testbed","rev-parse","HEAD",base,base+":"+link]
try:
    p=subprocess.run(args,capture_output=True,text=True,timeout=120)
    assert p.returncode==0,p.stderr
    refs=p.stdout.splitlines();assert len(refs)==3 and refs[1]==base
    assert refs[2]==rows[link]["index_oid"]==rows[link]["canonical_oid"]
    assert rows[link]["materialized_names"]==[] and rows[link]["directory_exists"] is True
    proof={"scope":"canonical tracked-path inventory and empty gitlink lineage only",
           "canonical_base_commit":base,"observed_image_head":refs[0],"canonical_gitlink_oid":refs[2],
           "canonical_physical_path_count":len(canonical),"image_physical_path_count":len(physical),
           "canonical_and_image_physical_path_sets_equal":True,"gitlink_directory_empty_both_sides":True,
           "gitlink_oid_matches_registered_canonical_base":True,"HEAD_scoped_v3_probe_calibrated":True,
           "argv":args,"returncode":p.returncode,"stdout":p.stdout,"stderr":p.stderr,
           "paid_ready":False,"untracked_or_transitive_runtime_qualified":False}
finally:
    subprocess.run(["docker","rm","-f",name],capture_output=True,check=True)
    p=subprocess.run(["docker","container","inspect",name],capture_output=True,text=True,timeout=30)
    assert p.returncode!=0 and "No such container" in p.stderr
    proof["fresh_container_absence"]=True
(PLAN/"lean-inventory-lineage.json").write_text(json.dumps(proof,indent=2,sort_keys=True)+"\n")
print(json.dumps(proof,indent=2,sort_keys=True))
