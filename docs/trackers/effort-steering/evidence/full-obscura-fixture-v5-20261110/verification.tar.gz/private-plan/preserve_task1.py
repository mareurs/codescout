"""Seal all successful and failed fixture/source diagnostics without deleting originals."""
from pathlib import Path
import hashlib,io,json,subprocess,sys,tarfile
sys.dont_write_bytecode=True
PLAN=Path(__file__).parent
sys.path.insert(0,str(PLAN))
from verify_task1 import verify
M=Path("/home/marius/work/claude/codescout")
D=M/"docs/trackers/effort-steering/evidence/hermetic-page-fixture-v3-20261110"
def sha(b):return hashlib.sha256(b).hexdigest()
proof=verify()
members={};origins={}
def add(name,p):
    assert not p.is_symlink(),str(p)
    assert name not in members
    members[name]=p.read_bytes();origins[name]=p
for p in sorted(PLAN.rglob("*")):
    if p.is_file():add("private-plan/"+str(p.relative_to(PLAN)),p)
for dirname in ("hermetic-page-fixture-v2-20261110","hermetic-page-fixture-v3-20261110"):
    p=M/"docs/trackers/effort-steering/evidence"/dirname/"registration.json"
    add("registrations/"+dirname+".json",p)
for version in ("registration.json","native-v3/registration.json"):
    reg=json.loads((PLAN/version).read_text());root=Path(reg["binding_source_root"])
    label="source-binding-v2" if version=="registration.json" else "source-binding-v3"
    for p in sorted(root.rglob("*")):
        if p.is_file():add(label+"/"+str(p.relative_to(root)),p)
W=PLAN.parents[2]
for p in (W/"tools/setup-ab-eval").iterdir():
    if p.is_file() and p.suffix in (".py",".sh"):add("grader-source/"+p.name,p)
for handle in ("db","dc","de","df","e0"):
    p=Path("/tmp/codescout-bg/532382-bfc3fc33-bg_000000"+handle+".json")
    add("jobs/"+p.name,p)
probe=json.loads((PLAN/"source-binding-diagnostic-v1/result.json").read_text())
p=subprocess.run(["docker","container","inspect",probe["container"]],capture_output=True,text=True,timeout=30)
assert p.returncode!=0 and "No such container" in p.stderr
members["source-probe-absence-followup.json"]=(json.dumps({"original_predicate":probe["fresh_absence"],
    "original_predicate_limit":"docker inspect says No such object; initial code checked No such container",
    "followup_command":"docker container inspect "+probe["container"],"followup_returncode":p.returncode,
    "followup_stderr":p.stderr,"fresh_absence_confirmed":True},indent=2)+"\n").encode()
members["member-manifest.json"]=(json.dumps({n:{"bytes":len(b),"sha256":sha(b)} for n,b in sorted(members.items())},indent=2,sort_keys=True)+"\n").encode()
archive=D/"verification.tar.gz";assert not archive.exists()
with tarfile.open(archive,"w:gz") as tar:
    for n,b in sorted(members.items()):
        item=tarfile.TarInfo(n);item.size=len(b);item.mode=0o600;item.mtime=0
        tar.addfile(item,io.BytesIO(b))
with tarfile.open(archive) as tar:
    items=tar.getmembers();assert all(i.isfile() for i in items)
    recovered={i.name:tar.extractfile(i).read() for i in items}
assert recovered==members and all(origins[n].read_bytes()==members[n] for n in origins)
closure={"schema":1,"scope":"fixture discrimination and source-parity diagnostic only","proof":proof,
         "archive":{"sha256":sha(archive.read_bytes()),"bytes":archive.stat().st_size,"regular_members":len(members),
                    "all_members_reopened_byte_equal":True,"all_origin_bytes_unchanged_during_seal":True},
         "preserved_failures":["registration typo before native run","v2serviceoff final source-binding false",
                               "source probe initial wrong absent-container error-label check",
                               "Lean all-indexed-path audits refuse gitlink before producing population count"],
         "source_parity_observation":{"obscura_indexed_paths_measured":133,"match":130,
               "differences":[".gitignore","crates/obscura-js/js/bootstrap.js","crates/obscura-js/src/runtime.rs"],
               "lean_broad_source_parity":"unqualified; unsupported gitlink aur/lean-ctx-bin"},
         "common_actor_public_baseline_bound":False,"full_original_population_qualified":False,
         "experimental_model_repair_calls":0,"paid_ready":False,
         "open":["full331Obscura base/reference/repeat","public image delta+page fixture common actor/index/runtime binding",
                 "Lean gitlink-aware source inventory","host resource floor,F6,whole-controller/accounting/review"]}
(D/"closure.json").write_text(json.dumps(closure,indent=2,sort_keys=True)+"\n")
print(json.dumps(closure,indent=2))
