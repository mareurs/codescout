"""Observe immutable image/apply/build bytes; never alter task record or expected binding."""
from pathlib import Path
import hashlib,json,subprocess,time,uuid
L=Path(__file__).parent
D=L/"source-binding-diagnostic-v1";D.mkdir(exist_ok=False)
P=Path("/home/marius/.cache/codescout-resident/codescout/evidence-cohort-20261110/common-obscura-421-v1/project")
image="sha256:b22988cd6022dd7a428a750799114b9c6f09bcaecc4fd9d8b86a0ef8502772d1"
name="sab-source-binding-obscura-"+uuid.uuid4().hex[:8]
rel="crates/obscura-js/js/bootstrap.js"
record=next(r for x in Path("/home/marius/work/claude/setup-ab-data/live/multilang-rust.jsonl").open() if (r:=json.loads(x)).get("instance_id")=="h4ckf0r0day__obscura-421")
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+"\n")
def call(*args,data=None,timeout=120):
    p=subprocess.run(["docker",*args],input=data,capture_output=True,timeout=timeout)
    return p
def observe(stage):
    p=call("exec",name,"cat","/testbed/"+rel);assert p.returncode==0
    (D/(stage+"-bootstrap.js")).write_bytes(p.stdout)
    meta={"stage":stage,"bytes":len(p.stdout),"sha256":sha(p.stdout)}
    put(D/(stage+".json"),meta);return meta
out={"image":image,"container":name,"prepared_public_sha256":sha((P/rel).read_bytes()),"paid_ready":False,"observations":[]}
(D/"reference.patch").write_text(record["patch"])
try:
    p=call("run","-d","--name",name,"--network","none","--cpus","4","--memory","8g","--memory-swap","8g","--user","0:0","--init","--cap-drop","ALL","--pids-limit","4096",image,"sleep","infinity");assert p.returncode==0,p.stderr
    out["observations"].append(observe("image-base"))
    p=call("exec","-i","-w","/testbed",name,"git","apply","--binary","-",data=record["patch"].encode())
    put(D/"apply.json",{"returncode":p.returncode,"stdout":p.stdout.decode(),"stderr":p.stderr.decode()});assert p.returncode==0
    out["observations"].append(observe("after-original-reference"))
    p=call("exec","-w","/testbed",name,"cargo","build","--workspace",timeout=900)
    (D/"build.stdout").write_bytes(p.stdout);(D/"build.stderr").write_bytes(p.stderr);out["build_returncode"]=p.returncode
    out["observations"].append(observe("after-rebuild"))
finally:
    p=call("inspect",name);(D/"inspect-before-remove.json").write_bytes(p.stdout)
    p=call("rm","-f",name);out["remove_returncode"]=p.returncode
    p=call("inspect",name);out["fresh_absence"]=p.returncode!=0 and b"No such container" in p.stderr
    put(D/"result.json",out)
print(json.dumps(out,indent=2))
