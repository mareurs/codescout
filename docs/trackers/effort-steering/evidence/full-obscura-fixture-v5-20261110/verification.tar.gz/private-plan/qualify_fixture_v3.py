"""Private evaluator diagnostics for a public fixed-page fixture; never paid admission."""
from pathlib import Path
import difflib,hashlib,json,subprocess,sys,tempfile,time
sys.dont_write_bytecode=True
W=Path("/home/marius/work/claude/codescout/.worktrees/grader-stream-provenance-01a15ca9")
M=Path("/home/marius/work/claude/codescout")
PLAN=W/".superpowers/sdd/2026-11-10-hermetic-page-fixture"
L=PLAN/"native-v3"
D=M/"docs/trackers/effort-steering/evidence/hermetic-page-fixture-v3-20261110"
P=Path("/home/marius/.cache/codescout-resident/codescout/evidence-cohort-20261110/common-obscura-421-v1/project")
DATA=Path("/home/marius/work/claude/setup-ab-data/live/multilang-rust.jsonl")
IMAGE="sha256:b22988cd6022dd7a428a750799114b9c6f09bcaecc4fd9d8b86a0ef8502772d1"
TID="h4ckf0r0day__obscura-421"
TEST="crates/obscura-cli/tests/mcp_client.rs"
KEY="obscura-cli::mcp_client$"
WITNESSES=[KEY+n for n in ("test_navigate_and_snapshot","test_evaluate","test_wait_for_selector")]
sys.path.insert(0,str(W/"tools/setup-ab-eval"))
import multilang_tasks as tasks,multilang_grade as grade,stream_evidence as streams
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+"\n")
def sources():return {str(p.relative_to(W)):sha(p.read_bytes()) for p in (W/"tools/setup-ab-eval").glob("*.py")}
def original_record():
    assert sha(DATA.read_bytes())=="bf2dd8252a07d0f275663ef8f6ab87571dd9bc4ce386abf9ec98d3cd6bb51a81"
    return next(r for x in DATA.open() if (r:=json.loads(x)).get("instance_id")==TID)
def register():
    assert not D.exists() and not L.exists();D.mkdir();L.mkdir()
    (L/"loopback_page.py").write_bytes((PLAN/"loopback_page.py").read_bytes())
    delta=(PLAN/"image-working-tree-audit-v1/working-tree.patch").read_bytes()
    assert sha(delta)=="bc866989ce78547fde62c14b4d9abdde03a4b47ae69733916af09c802291256f"
    (L/"public-image-baseline.patch").write_bytes(delta)
    original=original_record();source=(P/TEST).read_text()
    old='            .args(["mcp"])'
    new=old+'\n            .env("OBSCURA_ALLOW_PRIVATE_NETWORK", "1")'
    assert source.count(old)==1 and source.count("https://example.com")==7
    changed=source.replace("https://example.com","http://example.com:18080").replace(old,new)
    assert changed.replace("http://example.com:18080","https://example.com").replace(new,old)==source
    patch="diff --git a/"+TEST+" b/"+TEST+"\n"+"".join(difflib.unified_diff(source.splitlines(True),changed.splitlines(True),fromfile="a/"+TEST,tofile="b/"+TEST))
    assert TEST not in tasks.tasks.patch_files(original["patch"])
    r=dict(original);r["test_patch"]=original["test_patch"]+"\n"+patch
    r["test_cmds"]=[c.replace("--workspace","-p obscura-cli --test mcp_client") for c in original["test_cmds"]]
    all_mcp=[k for k in original["FAIL_TO_PASS"]+original["PASS_TO_PASS"] if k.startswith(KEY)]
    assert len(all_mcp)==len(set(all_mcp))==16 and set(WITNESSES)<=set(all_mcp)
    r["FAIL_TO_PASS"]=WITNESSES;r["PASS_TO_PASS"]=[k for k in all_mcp if k not in WITNESSES]
    (L/"public-fixture.patch").write_text(patch);put(L/"filtered-record.json",r)
    binding=Path(tempfile.mkdtemp(prefix="effort-obscura-image-baseline-source-",dir="/tmp"))
    paths=sorted(set(tasks.tasks.patch_files(original["patch"]))|set(tasks.tasks.patch_files(delta.decode())))
    for rel in paths:
        p=binding/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((P/rel).read_bytes())
    for label,data in (("image-baseline",delta),("reference",original["patch"].encode())):
        file=binding/(label+".patch");file.write_bytes(data)
        applied=subprocess.run(["git","apply","--unsafe-paths",str(file)],cwd=binding,capture_output=True,text=True,timeout=30)
        put(binding/(label+"-apply.json"),{"returncode":applied.returncode,"stdout":applied.stdout,"stderr":applied.stderr})
        assert applied.returncode==0
    expected={"/testbed/"+rel:sha((binding/rel).read_bytes()) for rel in paths}
    expected["/testbed/"+TEST]=sha(changed.encode())
    assert expected["/testbed/crates/obscura-js/js/bootstrap.js"]=="3c47ad88bde1b765d8cbbd80234e5b48957db526ff7d66e39eb9b0a1f8a1b4dd"
    reg={"schema":3,"task":TID,"scope":"16MCP tests only, with3dependency witnesses; no full original population or paid admission",
         "controls":{"reference-service-off":"off","reference-page-on":"good","reference-wrong-page":"wrong"},
         "public_baseline":"canonical-base-commit PLUS explicitly declared immutable-image tracked-source delta",
         "public_baseline_delta_sha256":sha(delta),"public_baseline_delta_paths":tasks.tasks.patch_files(delta.decode()),
         "baseline_alignment_limit":"new public overlay/index/common actor binding still required before paid admission; original preparation preserved",
         "original_dataset_sha256":sha(DATA.read_bytes()),"original_record_sha256":sha(json.dumps(original,sort_keys=True).encode()),
         "original_expected_sha256":sha(json.dumps([original["FAIL_TO_PASS"],original["PASS_TO_PASS"]],sort_keys=True).encode()),
         "record_sha256":sha((L/"filtered-record.json").read_bytes()),"helper_sha256":sha(Path(__file__).read_bytes()),
         "service_sha256":sha((L/"loopback_page.py").read_bytes()),"fixture_patch_sha256":sha(patch.encode()),
         "expected_source":expected,"source_sha256":sources(),"binding_source_root":str(binding),
         "assertions_unchanged":True,"permitted_source_changes":["7navigation URL input literals only","local-network opt-in only on spawned test MCP child"],
         "image":IMAGE,"step_timeout_s":900,"expected_mcp":all_mcp,"witnesses":WITNESSES,
         "runtime":{"user":"0:0","network":"none","cpus":4,"memory":"8g","memory_swap":"8g","init":True,"add_host":"example.com:127.0.0.1"},
         "stream_registration":{"version":streams.VERSION,"commands_sha256":streams.commands_digest(r),"tests":[{"profile":streams.NEXT,"reports":[0],"stderr_files":[]}]},
         "paid_ready":False,"original_full_expected_population_executed":False,"experimental_model_calls":0,
         "limits":["HTTP fixture does not qualify TLS","not yet common actor preparation/runtime","whole admission review pending","no original assertion or expected array dropped"]}
    put(D/"registration.json",reg);put(L/"registration.json",reg)
    print(json.dumps({"registration":str(D/"registration.json"),"expected":16,"paid_ready":False}))
def run(role):
    reg=json.loads((D/"registration.json").read_text());mode=reg["controls"][role]
    assert sources()==reg["source_sha256"]
    assert sha(Path(__file__).read_bytes())==reg["helper_sha256"]
    assert sha((L/"loopback_page.py").read_bytes())==reg["service_sha256"]
    assert sha((L/"filtered-record.json").read_bytes())==reg["record_sha256"]
    r=json.loads((L/"filtered-record.json").read_text())
    out=L/role;out.mkdir(exist_ok=False)
    docker=tasks.pilot.docker;observations=[]
    def observe(name,stage):
        item={"container":name,"stage":stage,"at":time.time()}
        p=docker("inspect",name,check=False,timeout=60);item["inspect_rc"]=p.returncode
        if p.returncode==0:item["inspect"]=json.loads(p.stdout)[0]
        p=docker("exec",name,"sh","-c","for f in /sys/fs/cgroup/memory.events /sys/fs/cgroup/memory.max /sys/fs/cgroup/memory.swap.max /sys/fs/cgroup/cpu.max; do printf '%s\\n' \"$f\"; cat \"$f\"; done",check=False,timeout=60)
        item["cgroup_rc"]=p.returncode;item["cgroup"]=p.stdout
        if stage=="before-remove":
            p=docker("exec",name,"sha256sum",*reg["expected_source"],check=False,timeout=60)
            item["source_rc"]=p.returncode;item["source_output"]=p.stdout
            if p.returncode==0:item["source_sha256"]={line.split(maxsplit=1)[1].strip():line.split()[0] for line in p.stdout.splitlines()}
            code="from pathlib import Path;import json,hashlib;root=Path('/tmp/effort-loopback-page');s=Path('/tmp/effort-loopback-page.py');print(json.dumps({'program_sha256':hashlib.sha256(s.read_bytes()).hexdigest(),'ready':json.loads((root/'ready.json').read_text()) if (root/'ready.json').exists() else None,'requests':[json.loads(x) for x in (root/'requests.jsonl').read_text().splitlines()] if (root/'requests.jsonl').exists() else []}))"
            p=docker("exec",name,"python3","-c",code,check=False,timeout=60)
            item["service_packet_rc"]=p.returncode
            if p.returncode==0:item["service_packet"]=json.loads(p.stdout)
        observations.append(item);put(out/"runtime.json",observations)
    def prepare(name):
        install="from pathlib import Path;import sys;Path('/tmp/effort-loopback-page.py').write_text(sys.stdin.read())"
        docker("exec","-i",name,"python3","-c",install,data=(L/"loopback_page.py").read_text(),timeout=60)
        if mode!="off":docker("exec","-d",name,"python3","-u","/tmp/effort-loopback-page.py",mode,timeout=60)
        probe="""import hashlib,json,os,socket,time,urllib.request
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
packet={'global_private_env':os.environ.get('OBSCURA_ALLOW_PRIVATE_NETWORK'),'resolved':sorted({a[4][0] for a in socket.getaddrinfo('example.com',18080)})}
for attempt in range(50):
    try:
        response=opener.open('http://example.com:18080',timeout=1);body=response.read()
        packet.update({'reachable':True,'status':response.status,'body_sha256':hashlib.sha256(body).hexdigest()});break
    except OSError as exc:
        packet.update({'reachable':False,'error':str(exc)})
        time.sleep(.05)
print(json.dumps(packet))
"""
        p=docker("exec",name,"python3","-c",probe,check=False,timeout=30)
        packet=json.loads(p.stdout) if p.returncode==0 else {"probe_error":p.stdout}
        put(out/"service-readiness.json",packet)
        assert packet.get("global_private_env") is None and packet.get("resolved")==["127.0.0.1"]
        assert packet.get("reachable") is (mode!="off")
    def watched(*args,**kwargs):
        if args and args[0]=="run":args=("run","--user","0:0","--memory-swap","8g","--init","--add-host","example.com:127.0.0.1",*args[1:])
        if args and args[0]=="rm":
            for a in args[1:]:
                if isinstance(a,str) and a.startswith(tasks.GRADE_PREFIX):observe(a,"before-remove")
        value=docker(*args,**kwargs)
        if args and args[0]=="run" and value.returncode==0:
            name=args[args.index("--name")+1];prepare(name);observe(name,"after-start")
        return value
    tasks.pilot.docker=watched;tasks.GRADE_STEP_TIMEOUT=reg["step_timeout_s"]
    bundle={"workdir":"/testbed","expected":{"fail_to_pass":3,"pass_to_pass_kept":13,"dropped":[],"fail_to_pass_dropped":[]}}
    grader=tasks.live_grader(r,bundle,IMAGE,out,capture_streams=True)
    raw=grader(r["patch"],role)
    result={"name":role,"mode":mode,"raw":raw,"paid_ready":False,"original_full_expected_population_executed":False}
    p=Path(raw.get("log",""))
    if p.is_file():
        log=p.read_text();full=json.loads(p.with_name("grade.json").read_text())
        parsed=grade.run_parser(r["log_parser"],log)
        result["statuses"]={k:parsed.get(k) for k in reg["expected_mcp"]}
        try:
            result["diagnostics"]=streams.qualify(full,r,log,reg["stream_registration"]);result["complete_stream_contract"]=True
        except streams.EvidenceError as exc:
            result["complete_stream_contract"]=False;result["stream_error"]=str(exc)
    p=subprocess.run(["docker","container","inspect",raw["container"]],capture_output=True,text=True,timeout=30)
    result["fresh_container_absent"]=p.returncode!=0 and "No such container" in p.stderr
    result["applied_source_bytes_verified"]=any(o.get("source_sha256")==reg["expected_source"] for o in observations)
    result["service_bytes_verified"]=any(o.get("service_packet",{}).get("program_sha256")==reg["service_sha256"] for o in observations)
    result["source_unchanged"]=sources()==reg["source_sha256"]
    put(out/"result.json",result)
    print(json.dumps({"name":role,"raw":raw,"streams":result.get("complete_stream_contract"),"source_bytes":result["applied_source_bytes_verified"],"service_bytes":result["service_bytes_verified"],"paid_ready":False},indent=2))
if __name__=="__main__":
    if sys.argv[1]=="register":register()
    else:run(sys.argv[1])
