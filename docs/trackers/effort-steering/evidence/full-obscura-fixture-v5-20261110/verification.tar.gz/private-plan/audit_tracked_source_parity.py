"""Measure every indexed path in the fixed task image against public preparation."""
from pathlib import Path
import hashlib,json,os,stat,subprocess,sys,uuid
PLAN=Path(__file__).parent
ROLES={
 "lean":("sha256:b72f902d24c0a54516e4ef242d8218805f0ea3dc1d26ac809140979ba1f51d56","common-lean-ctx-1168-v1"),
 "obscura":("sha256:b22988cd6022dd7a428a750799114b9c6f09bcaecc4fd9d8b86a0ef8502772d1","common-obscura-421-v1")}
role=sys.argv[1];image,prepared=ROLES[role]
D=PLAN/("tracked-source-parity-"+role+"-v2");D.mkdir(exist_ok=False)
P=Path("/home/marius/.cache/codescout-resident/codescout/evidence-cohort-20261110")/prepared/"project"
name="sab-readonly-tracked-source-"+role+"-"+uuid.uuid4().hex[:8]
code="""from pathlib import Path
import hashlib,json,os,stat,subprocess
root=Path('/testbed')
p=subprocess.run(['git','--no-optional-locks','-c','safe.directory=/testbed','-C','/testbed','ls-files','--stage','-z'],capture_output=True,check=True)
rows={}
for entry in p.stdout.split(b'\\0'):
    if not entry:continue
    head,raw=entry.split(b'\\t',1);mode,blob,stage=head.decode().split()
    assert stage=='0' and mode in ('100644','100755','120000'),(stage,mode,raw.decode())
    rel=raw.decode('utf-8');path=root/rel
    info=path.lstat()
    if stat.S_ISLNK(info.st_mode):
        rows[rel]={'kind':'symlink','target':os.readlink(path)}
    else:
        assert stat.S_ISREG(info.st_mode)
        rows[rel]={'kind':'file','executable':bool(info.st_mode&0o111),'bytes':info.st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
print(json.dumps({'indexed_paths':rows},sort_keys=True))
"""
argv=["docker","run","--name",name,"--network","none","--read-only","--cap-drop","ALL","--security-opt","no-new-privileges",
      "--user","0:0","--memory","2g","--memory-swap","2g","--cpus","1","--pids-limit","128","--entrypoint","python3",image,"-c",code]
(D/"registration.json").write_text(json.dumps({"argv":argv,"prepared":str(P),"predicate":"ALL paths selected by git ls-files --stage stage0; compare actual regular-file bytes/executable bit or symlink target; no untracked paths or transitive runtime claimed","paid_ready":False},indent=2)+"\n")
result={"role":role,"image":image,"paid_ready":False}
try:
    p=subprocess.run(argv,capture_output=True,timeout=180)
    (D/"image-paths.json").write_bytes(p.stdout);(D/"stderr").write_bytes(p.stderr)
    result["returncode"]=p.returncode
    assert p.returncode==0,p.stderr.decode()
    rows=json.loads(p.stdout)["indexed_paths"];host={};differences={}
    for rel,actual in rows.items():
        path=P/rel
        if not path.exists() and not path.is_symlink():fact={"kind":"missing"}
        elif path.is_symlink():fact={"kind":"symlink","target":os.readlink(path)}
        elif path.is_file():
            info=path.stat();fact={"kind":"file","executable":bool(info.st_mode&0o111),"bytes":info.st_size,"sha256":hashlib.sha256(path.read_bytes()).hexdigest()}
        else:fact={"kind":"unsupported"}
        host[rel]=fact
        if actual!=fact:differences[rel]={"image":actual,"prepared":fact}
    (D/"prepared-paths.json").write_text(json.dumps(host,indent=2,sort_keys=True)+"\n")
    result.update(indexed_paths_measured=len(rows),matching_paths=len(rows)-len(differences),differing_paths=differences,
                  untracked_paths_measured=False,transitive_runtime_measured=False)
finally:
    p=subprocess.run(["docker","container","inspect",name],capture_output=True)
    (D/"inspect.json").write_bytes(p.stdout)
    p=subprocess.run(["docker","rm","-f",name],capture_output=True);result["remove_rc"]=p.returncode
    p=subprocess.run(["docker","container","inspect",name],capture_output=True);result["fresh_absence"]=p.returncode!=0 and b"No such container" in p.stderr
    (D/"result.json").write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
print(json.dumps(result,indent=2,sort_keys=True))
