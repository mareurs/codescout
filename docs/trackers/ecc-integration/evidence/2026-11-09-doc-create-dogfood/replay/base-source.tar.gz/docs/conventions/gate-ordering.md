---
kind: convention
status: active
title: Gate ordering — why the four commands run in that order
owners: []
tags:
  - testing
  - ci
  - gate
  - shared-target
---

# Gate ordering — why the four commands run in that order

Read-only verification uses `./scripts/gate.sh --check` without identity. Authored mode resolves a harness-neutral root context; an unavailable context reports a blocked formatter and still runs all other lanes under the lease. Default remains last after earlier failures. Options, numeric outcomes and evidence limits are in [harness-neutral-session-context.md](harness-neutral-session-context.md).

**Audience:** anyone about to change the pre-commit gate, shorten it, reorder it, or argue that one
of its commands is redundant. The gate itself lives in [`CLAUDE.md`](../../CLAUDE.md) §
*Development Commands* and stays there deliberately — a 2026-08-30 ruling in
`docs/trackers/gate-contract-consolidation.md` settled that *"`CLAUDE.md` stays inline — the copy a
Claude session actually executes."* This page holds the **evidence** for each of the four
commands and for their order, so the executable copy can stay short.

Every figure below was measured, on the date given, rather than reasoned about. Each command in the
gate was added or upgraded because a narrower form shipped a defect; the paragraphs are grouped by
which command they justify.

> **The gate sentence in `CLAUDE.md` is pinned byte-for-byte** by
> `claude_md_gate_lists_its_four_commands_in_the_load_bearing_order` (`src/prompts/mod.rs`).
> The line number this used to carry (`:1993`) was stale by 375 lines when checked on
> 2026-09-09 and is deliberately not replaced with a fresh one: a symbol name survives every
> edit above it, and a line number is a positional reference that decays exactly like the
> commit SHAs and orphaned refs this corpus keeps tripping over.
> It scopes to the run beginning ``**Run `./scripts/gate.sh``` and ending `before completing any task.**`,
> then asserts the four backtick-delimited commands appear in ascending byte order *within that
> slice*. Its own panic message reads: *"if it moved, move this test with it — do not delete it."*
> Two traps it is shaped around: `cargo nextest run --workspace` is a **prefix** of the lean form, so a
> bare-substring index finds the wrong lane; and both forms appear several times in surrounding
> prose, so any whole-file index is arbitrary.

## Why the order is load-bearing — the shared `target/` trap

We share one `target/`, and `tests/cli_doc.rs` resolves `target/debug/codescout` **by path at
run time** — so the lean lane leaves a librarian-less binary there, and a concurrent
default-features run then execs it and dies with `unrecognized subcommand 'artifact'` on 10 of 11
tests, reading exactly like a librarian feature-gating regression in whatever you just committed. It
is not one (`docs/issues/archive/2026-08-30-shared-target-dir-feature-clobber-reds-the-cli-tests.md`).
Ending on the default-features lane rebuilds the binary correctly, so **following the gate no longer
arms the trap for everyone else** — which the documented order did *by construction*, because the
lean lane was terminal and you walk away from it.

Measured 2026-08-30: after the lean lane `artifact --help` exits **2** — the subcommand is gone, not
empty — and the default lane restores all **8** verbs — the block prints **nine** lines, because
clap appends its own `help`, so count verbs rather than lines or you will re-derive this sentence as
wrong. It is 8-or-nothing by construction, so a partial count is not a weaker version of this bug
but a different one: the `#[cfg(feature = "librarian")]` sits on the whole `Commands::Artifact`
variant (`src/main.rs:175`), and none of `Verb`'s eight variants is individually gated.

**Two caveats kept deliberately.** This closes the **terminal state**, not the **window** — during
the lean lane the binary really is librarian-less, and the reorder only bounds that by the rest of
your own run while you are still present. And it is **not free**: 71.8s documented vs 80.4s
reordered vs 79.6s for the rejected appended-`cargo build` fix, so both remedies cost ~8s and the
reorder wins on structure rather than speed — it removes the proposition whose exit code could be
misread, where an appended build step is one more thing that can silently not have run.


### The `&&` exception — the "by construction" guarantee assumes the lanes RUN

**Measured 2026-09-01, by arming it.** The guarantee above holds for a gate that runs to
completion. Chained with `&&` it inverts, and it inverts *exactly when something is wrong*:

```
cargo fmt && cargo clippy … && cargo test --workspace --no-default-features && cargo test --workspace
                                                          ↑ fails here                  ↑ never runs
```

A session chained the four commands that way, the **lean** lane failed on an unrelated red (a
peer's bug file, momentarily tracked without its defect-class tag), and the default lane was
skipped — leaving `target/debug/codescout` librarian-less. So the terminal state was the lean
binary, which is the precise condition the reorder exists to prevent, reached *by following the
documented order*.

**And it is worse than "the repair was skipped" — sharpened 2026-09-01 by `codescout-b7`.**
`cargo test` has a build half and a test half, in that order. The build half is what overwrites
`target/debug/codescout`, and it has **already completed** by the time any test can fail. So a
lean-lane test failure does not prevent the trap from being set; it is reported *after* the trap
is set, and then blocks the only step that would clear it. The two halves run in the order that
**guarantees** the worst case rather than merely permitting it.

That reframes the remedy's weight. `;` is not "run the last lane anyway, in case it matters" —
it is the only thing that disarms a trap that is already armed by the time you read the red. The
failure that skips the rebuild is also the one that guarantees you are about to re-run and
re-fail, so the window is not short either.

The asymmetry worth naming: `&&` expresses "stop if a step fails", which is right for a gate
whose purpose is a **verdict**, and wrong for the one step whose purpose is a **side effect**.
The default lane is doing two jobs — reporting and rebuilding — and only the first should be
short-circuited.

**So chain the two test lanes with `;`, not `&&`**, and read the exit codes rather than relying
on the chain to surface them:

```
cargo nextest run --workspace --no-default-features --no-fail-fast 2>&1; echo "===LEAN exit $?==="
cargo test --workspace --doc --no-default-features                 2>&1; echo "===LEAN doc exit $?==="
cargo nextest run --workspace --no-fail-fast                       2>&1; echo "===DEFAULT exit $?==="
cargo test --workspace --doc                                       2>&1; echo "===DEFAULT doc exit $?==="
```

This does not weaken the gate: nothing is being committed on a red either way, and the change
only guarantees the rebuild happens. It is the same shape as the reorder itself — make the
correct path end in a safe state, so compliance cannot leave anything armed (CLAUDE.md §
*Observer Blindness*, remedy 3). The reorder closed the case where you *walk away* from the lean
lane; this closes the case where the gate *stops you* at it.

**What is measured here and what is deduced — because on this page the distinction is unusually
sharp.** The *premise* is measured, on 2026-08-30, in the section above: after a lean lane
`artifact --help` exits 2. The *2026-09-01 instance* is a deduction from it — the session that
armed it re-ran the default lane immediately and did not probe the binary in the intervening
moment, and by the time the gap was noticed the window had closed. Two sessions then declined to
reproduce it, for the same reason: **verifying this trap and arming it are the same act.** A
confirming run means leaving five other sessions on a shared checkout with a librarian-less
binary in order to re-demonstrate a mechanism already measured. That is the wrong trade, so the
prediction stands on the 2026-08-30 measurement plus cargo's build-then-test ordering, and not
on a fresh observation.

Recorded rather than glossed because a deduction in a page full of measurements will be read as
one of them. Both sessions verified the *current* state instead, which is the cheap half and
proves only that nothing is armed right now: `artifact --help` exits 0 against a 325 MB binary.
## Why the long clippy form, not `cargo clippy -- -D warnings`

The long clippy form is the gate, not garnish: bare `cargo clippy -- -D warnings` lints only the
root package's **non-test** targets with default features, so it passes trees CI fails —
`.github/workflows/ci.yml` runs both (`:50` and `:61`), and only the second reaches `#[test]` code
and `codescout-embed`'s feature-gated `local` module.

Measured 2026-08-27: ten task gates, ten task reviews and a whole-branch review all missed a
`doc_lazy_continuation` lint sitting in a test's doc comment
(`prompt-surface-measurement-session-log:F-45`).

## Why the lean lane exists at all

The lean `cargo nextest run --workspace --no-default-features` is there for the same reason one command
over: every other gate command runs **with** default features, so an unconditional module reaching a
`#[cfg(feature = "librarian")]` one compiles clean locally and fails only in CI's `no-features`
*test-matrix* lane — the slow 3-OS job, not the fast clippy job, which did not run that config at
all until 2026-11-09. The `clippy` job and the gate's clippy lane now lint it too
(`cargo clippy --workspace --all-targets --no-default-features -- -D warnings`), after it was found red
on a dead `ReadDenyList`; the test lane still builds it and still denies no warnings. Four instances of that class in one day (2026-08-27); the one that shipped left `experiments`
HEAD failing the lean build, so every session that merged inherited the break.

## The lean lane is VACUOUS for librarian code — the same gate, a second consequence

The section above says why the lean lane exists. This says what it cannot tell you, and the two
are one fact read in opposite directions.

`--no-default-features` switches the librarian **off**. That is precisely why a terminal lean lane
leaves a librarian-less binary — the trap § *Why the order is load-bearing* describes at length.
The corollary stayed unwritten for as long as the trap was documented: **the lane that produces a
librarian-less binary also never runs a librarian test.**

Measured 2026-09-04, one gate run, both lanes appended to one log:

```
sed -n '1,/^LEAN exit=/p' gate.log | grep -c '^test librarian::'    # 0
sed -n '/^LEAN exit=/,$p'  gate.log | grep -c '^test librarian::'    # 1676
```

Zero against 1676 — not a thinner sample of the librarian surface, its complete absence. So
`LEAN exit=0` on a librarian change is the output of a suite that never compiled the code under
test, returned identically whether that change is correct or catastrophically wrong.

That is § *Testing Discipline*'s first law reaching past an assertion to a whole **lane**: a suite
is monotone under every change to code it excludes. The reflex remedy — widen the sample — is a
no-op here, because the exclusion is a compile-time feature gate rather than a selection over
tests.

**Both consequences bite the same reader in opposite directions, which is why naming only the
first is worse than naming neither.** Someone who knows the ordering trap knows the lean lane
leaves a *degraded binary* — and has every reason to infer from that it at least *ran the tests*.
One hazard is about what the lane leaves behind; this one is about what it never did. A document
that carefully names one failure mode implies by omission that the rest are handled (`OB-1`).

Two sessions reached for it as evidence on the same evening, independently, both on
entirely-librarian changes: one cited `lean lane 3526 passed` in a commit message as gate evidence,
the other was one message from citing it to a peer as a pass. Neither is carelessness — the number
is real, the lane is in the gate, and nothing in its output mentions `librarian`, including by
omission. There is no line reading *0 librarian tests ran*; there is simply nothing where 1676
results would be.

**What to do instead.** On a librarian change the default lane is the only one of the two that is
evidence at all. Run it and read **your own test names** out of it:

```
grep -E '^test librarian::<module>::tests::' gate.log
```

Not the totals. A total is an aggregate over a population, and § *Testing Discipline* is explicit
that an aggregate cannot verify a claim about a member — `5130 passed` is equally satisfied by a
run in which your tests never existed.

This does **not** demote the lean lane. It still catches exactly what the section above says it
catches: an unconditional module reaching feature-gated code. That failure is a *compile* error,
and a compile error is the one class the lane can still see with the feature off.

## Why it is `test`, not `check` — and that upgrade is load-bearing

A `check` — even with `--all-targets` — compiles the lean test targets and never runs them, so a
lean-only *runtime* failure is invisible to it; the older form of this line omitted `--all-targets`
as well, so it did not even compile them.

Measured 2026-08-30: `2c6f2677` turned three pre-existing **ungated** tests red under
`--no-default-features`, and the lane stayed red for over a day while every documented gate command
ran green across at least three sessions. `cargo test --workspace --no-default-features` was the only
command that saw it — 3219 passed / 3 failed, green again at `f3dbfdf4` (3360/0). A fourth instance
of the class arrived inside that very fix: an `expect_err` that compiled clean by default and failed
to compile **lean**, because `Arc<dyn CodeEmbedder>` is not `Debug`. It subsumes the `check` it
replaces, so the gate is still four commands; ~20s incremental (the check was ~10s, the test phase
measured 6.96s on top).

## Why both test lanes carry `--workspace`

`--workspace` matches what CI actually runs (`.github/workflows/ci.yml:174`). **Both test lanes
carry it** — added 2026-08-30, and that was a swap, not a fifth command.

Bare `cargo test` builds only the **root package's** targets, so every test in a workspace member is
invisible to it; this is not a `tests/`-directory quirk, an inline `#[cfg(test)]` module is equally
unreachable. Measured that day: `codescout-embed` compiles **56** tests with `remote-embed` (52
executing — 4 `ollama_*` are `#[ignore]`d) and **19** without, so **37 were reached by neither test
command**, bare `cargo test` building 0 of them and the lean lane building the member with
`remote-embed` **off**.

The 33 live guards among those included the regression tests for three bugs fixed that same day —
one of them a crypto-provider install whose absence aborts the process for every external consumer
of the crate, whose own pre-existing test could not fail because its siblings installed the provider
first (`BL-66`, `BL-68`, `bug-fix-session-log:W-85`). CI's `default` matrix lane (`flags: ""`) always
covered them, so this was never missing coverage — it was `W-81`'s axis, *how long until the check
tells someone*, and the answer was "at push time".

The swap is safe because `--workspace` **strictly subsumes** the bare form: verified by `-- --list`
set-difference, **0** tests present in bare and absent from workspace (4924 → 4980). Cost **+2.6s**
warm (23.5s → 26.1s, two runs each, stable), so the gate is still four commands; that `+2.6s` is the
default lane **alone**, not the gate total — the whole gate measures 71.8s in the pre-reorder order
and 80.4s reordered.

## Why the test lanes run nextest, and why each has a doctest step

Both test lanes run `cargo nextest run`, not `cargo test`, since 2026-11-01. Measurements are in codescout memory `research/gate-speed-20261101`. The sections above and below name `cargo test` where they describe the command of their date; the live commands are in `CLAUDE.md` and `scripts/gate.sh`.

**Why.** The default lane's lib unit tests (8192 tests) took 72–80 s under nextest and 369–575 s under libtest, on the same binary and the same machine (64 cores, other sessions running; load medians 21–44). libtest runs every test as a thread of one process. In the one run measured for CPU split, that process used 776.5 s of user time and 6006.8 s of kernel time, so 88.5% of its CPU was in the kernel. The same tests under nextest used 1074.3 s of user time and 279.5 s of kernel time. The cause of the kernel time is not proven. The best candidate is contention on the process's memory lock while 64 threads fault pages and create thread stacks. One alternative is refuted: setting the glibc malloc thresholds so that malloc keeps its memory made the run worse (999.6 s).

**What it does not show.** Nothing here shows the gain on a runner with few cores. CI has few cores, so its gain is probably much smaller than this machine's. CI runs nextest anyway so that the gate and CI run the tests the same way.

**The doctest step.** nextest does not run doctests. Each test lane has a second command, `cargo test --workspace --doc` with the lane's feature flags. A lane is red when either command is red. The doctest step runs even when the nextest step is red (`;` and `||`, never `&&`, for the reason in the `&&` section above).

**`--no-fail-fast`.** nextest's default stops at the first failed test. The old `cargo test` stopped only after the failed test binary, so it ran every test in that binary. The gate keeps every failure visible.

**No retries, no fallback.** nextest can retry a failed test; no profile here sets `retries`, because a retry turns a flaky red into a green. If nextest is not installed, `gate.sh` exits 2 before the lease and prints `cargo install cargo-nextest --locked`. It does not fall back to libtest, because two machines would then run two different gates under one name.

**The dev profile.** `build_id_of` (`src/retrieval/index_state.rs`) hashes the whole running test binary, about 402 MB, once per process. Under nextest each test is its own process, and with `sha2` at `opt-level = 0` the hash took 11.8 s. `[profile.dev.package.sha2] opt-level = 3` (`Cargo.toml`) cut `tools::config::tests::project_status_compact_shape` from 11.815 s to 0.564 s.

## Name the commands, never number them

Named by what they *are*, not by position: an ordinal is a positional reference, correct for exactly
one arrangement and silently wrong after any reorder — the same defect a bare SHA has, which is why
this project pairs one with a patch-id. A paragraph that tells you its own order is load-bearing
must not then refer to its commands by number.

## Related

- The executable copy: [`CLAUDE.md`](../../CLAUDE.md) § *Development Commands*.
- Full command reference (every crate + fixture, `cargo rb` vs lean build) → memory
  `development-commands`.
- The binary symlink gotcha, and why a rebuild does not reach a running MCP server → memory
  `gotchas` (§ *MCP Binary Symlink*).
- Setting up the opt-in RAM tier for the gate's build trees on one machine:
  [`gate-ram-tier.md`](gate-ram-tier.md).
- The five-transcriptions problem and the ruling that keeps this split:
  `docs/trackers/gate-contract-consolidation.md`.
