---
id: 6be7b48495c0fd69
kind: doc
status: active
title: Memory overwrite history
---

# Memory overwrite history

Topic writes preserve their predecessor before publishing a replacement. This applies to MCP, the dashboard and internal MemoryStore writes, in public, private and explicitly selected stores. `force: true` bypasses shrink refusal; it does not bypass backup or read failures. Semantic remember/forget operations use their own database and are outside this topic-file contract.

## History and restoration

For a store at `<memories>`, a normalized target `nested/topic.md` has backups at `<memories>/.history/nested/topic.md/<uuid>.md.bak`. Each published .md.bak file contains the exact previous UTF-8 bytes, including BOM, Unicode and line endings. Backups are first written to a unique .pending file, synced, and then published without replacing an existing backup; interrupted partial writes never acquire a .md.bak name. History files use Unix mode0600, directories0700, and a local .gitignore excludes all history. Backups are excluded from memory list because their final extension is bak. The .history topic namespace is reserved.

There is no automatic purge. Inspect the backup as a file, choose the intended version, then restore it through a normal topic write; that write preserves the current version too. Do not rename, unlink or replace .history/write.lock while processes may write to the store: its stable inode coordinates them. Keep history with the store when taking a backup.

## Failure and concurrency behavior

Existing content must be readable, regular and valid UTF-8. A history failure refuses the overwrite even with force. Nested/leaf topic and history symlinks are refused; a configured store root symlink is resolved once and writes, backups and anchors use the pinned destination. Reads refuse the same shapes: `MemoryStore::read` (so `memory(action=read)`, the dashboard and onboarding) returns a `RecoverableError` for a leaf link, a directory at the topic path or a linked parent directory below the store root, and `read_anchor_file` does the same for a linked `<topic>.anchors.toml`. The `memory://` MCP resources list only regular files and re-check the type on read; `.codescout/system-prompt.md` is used only when it is a regular file. The store root itself may be a link, and every read and list then resolves through it: that exposure is an open decision, see `docs/issues/2026-10-18-memory-read-follows-a-leaf-symlink-and-serves-the-target.md`. Reads use `RecoverableError` where writes use `bail!`; the difference is deliberate. A `.gitignore` that is not a regular file is never read through or replaced when a private store is opened. The private store then ignores itself with its own `.gitignore` of `*` only if `.codescout` and `private-memories` are real directories and any existing `.gitignore` there is exactly `*`; otherwise a warning is logged and nothing makes git ignore the private store. New topic writes do not create a predecessor backup. Shrink refusals do not create one either.

A store-wide advisory lock covers reading, shrink evaluation, backup publication, topic replacement and anchor stamping. Other cooperating CodeScout writers wait up to five seconds; contention beyond that is a retryable save failure. Deletions participate in the lease and retain their existing deletion semantics; they do not create history. Every overwrite remains a whole-document replacement. Concurrent writers preserve each intermediate predecessor, but do not merge edits or detect stale reads. External programs that ignore this lock are outside the serialization guarantee.

Topic replacement uses a unique sibling temporary file, then an atomic rename. A failure before publication leaves the previous topic intact. Anchor failures after publication are returned as warnings. This is topic-level recovery, not a coordinated database/configuration backup or authorization to activate a laptop update.

## Client-side guards

What a harness-side guard may and may not assume of this contract, including that delete keeps no history: [`memory-write-client-overlap.md`](memory-write-client-overlap.md).
