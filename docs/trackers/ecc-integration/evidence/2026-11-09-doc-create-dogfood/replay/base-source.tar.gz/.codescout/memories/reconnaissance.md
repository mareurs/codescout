# Reconnaissance — promoted rules (distilled from docs/trackers/reconnaissance-patterns.md)

One-line imperatives promoted at their R-N promote-when thresholds. The ledger
entry holds the full narrative; this file carries only the rule.

- Before editing any tool description or enumerated prompt surface (get_guide
  topics, Iron Laws, tool lists), enumerate and run its budget/count gates
  first: grep `server::tests` for the tool name (per-tool description cap: 300 chars,
  1800 for `doc` and `librarian`, pinned by `every_tool_description_is_under_its_cap`)
  and grep the surface's tests for hardcoded counts (`len() == N`) — convert
  those to derive from the canonical const while there. (R-28 + R-37)

- Never conclude a codescout tool dropped an input, returned nothing, or
  ignored a flag from its **summary** — read the `@ref` buffer. Every buffered
  response carries `buffered_bytes` and names the ref: if that number is larger
  than the summary could account for, the summary is not the result. Checked
  twice against `symbols(path=<dir>, include_body=true)`, whose 43 bodies sat in
  a 56 KB buffer while its line-oriented summary showed none. (R-50)

- A green check proves nothing until you confirm it *can* fail. Before trusting
  it, ask what it would do if the guarded thing were broken; if the answer is
  "the same thing", it is decorative. Three instances in one session, each green
  for months: a single-value jq probe (the trailing CRLF is stripped, so it
  cannot see the defect), a `sleep 5 && touch x` cancellation test (`sleep` does
  not exist under cmd.exe, so it short-circuited and never exercised the kill
  path — hiding a total absence of Windows process-tree kill), and a 134-test
  suite that structurally could not reach `inject_tee`'s path validator.
  (cited source: claude-plugins `windows-shell-env-session-log.md` W-2. That file was not found under the claude-plugins or codescout docs on 2026-10-20, so these three instances are unverified)

- A red gate is not a finding until HEAD has been measured: `git stash`, re-run,
  compare. Attribute by measurement, never by reading the diff and reasoning
  about plausibility. This kept a clippy suggestion from deleting a `return`
  that is load-bearing on Unix (it only looks needless on Windows, where every
  following statement is `cfg(unix)`) and refuted a plausible self-blame for
  three EDR-quarantined test binaries. Corollary for flaky-vs-real: re-run the
  single test in isolation — deterministic 5/5 failure is real, passes-alone /
  fails-under-load is a timing flake. (cited source: the same log, W-3, with the same caveat)

- Shell-pipeline scouts must read exit status AND bytes, not output emptiness.
  A non-zero exit with non-empty output is common (jq with several inputs,
  compilers with `-k`) and defeats `${x:-default}` guards — the `_merge_cache`
  function in claude-plugins (`buddy/scripts/statusline-composed.sh`) is cited as
  having consumed a partial-success jq document and silently swapped the session
  JSON for a cache file. (cited source: claude-plugins reconnaissance-patterns
  R-4. That R-4 is the positive-control entry and does not record this incident,
  so the incident is unverified as of 2026-10-20)

- **A companion-plugin fix is inert until the version bumps.** All three
  profiles install codescout-companion from a *version-keyed cache*
  (`~/<profile>/plugins/cache/sdd-misc-plugins/codescout-companion/<version>/`),
  so editing `claude-plugins/codescout-companion/` changes nothing any running
  session reads. Verify at the bytes, not at the merge: `grep <the retired
  string> ~/{.claude,.claude-sdd,.claude-kat}/plugins/cache/.../hooks/<hook>.mjs`
  — three hits means three stale copies. Closing a companion bug therefore needs
  `plugin.json` bumped + reinstall in all three profiles, and until then
  "merged" and "in effect" are different claims. Measured twice on 2026-08-14:
  the retired "do NOT run index in worktrees" claim still present in all three
  caches after the fix merged to `main`, and the IL3 quoted-pipe false positive
  still firing from the hook while the rebuilt server correctly allowed the same
  command — that disagreement is the tell. (bug-fix work stream. The version-keyed
  cache layout was confirmed on 2026-10-20. The quoted "#1 cause" wording was not
  found in the version-bump-checklist tracker, so treat it as unverified)

- **Before attaching a conclusion to a measurement, state in one sentence what
  that measurement cannot see.** A real probe answering exactly what it was
  asked, bound to the wrong question, has twice reached committed artifacts
  here. Three forms: (1) when a tool reads a corpus it selects *itself* — a
  pinned worktree, a baseline SHA, a configured collection — verify against
  that corpus; the tree you are standing in is not evidence about it. (2) Never
  probe for presence with `A || B` — short-circuit makes absence of B
  unobservable whenever A succeeds, which is how one dual-GPU box got written up
  as two machines. (3) A tool's self-reported health field is a claim, not a
  probe of the thing it names; pick a call that *requires* the dependency
  (`references()` needs the LSP, `symbols()` is tree-sitter-backed and cannot
  tell up from down). When two hypotheses predict the same output from your
  current probe, the fix is a different probe, not a longer stare. Corollary
  that fired the promotion: an empty or zero result is a claim about your
  *query* first — `paths=["docs/issues"]` scanning 0 files looked like a silent
  no-op bug until the source showed `paths` takes globs. Reading it first
  prevented a false bug filing; not reading it produced one the day before.
  (R-91)


- **Importance × cost decides explore-vs-ask, and cheap+important is never a
  question.** Score what rests on the claim: **high** — it feeds a decision being
  executed *now* (a plan step, a dispatch brief, a gate, an edit about to land);
  **medium** — a later session in this work stream will read it; **low** —
  incidental to this turn. If importance is high and the exploration is cheap
  (one or two tool calls, seconds, no spend, no irreversible side effect),
  **run the exploration.** Do not assert it, do not hedge it, and above all do
  not put it to the user: asking spends a round-trip of their day to buy what
  one call buys, and a question is not a safer form of a guess. Reserve
  questions for what exploration genuinely cannot settle — spend, taste,
  priorities, external facts, or a judgement that is theirs by right. The
  asymmetry that makes this load-bearing: a controller's unverified claim
  becomes a subagent's committed code, and the code outlives the sentence that
  caused it. Promoted 2026-08-26 on user instruction, after one session both
  (a) filed `prompt-surface-measurement-session-log:F-20` for four
  inferred-but-measured-sounding claims in a single task — one of which reached
  a subagent's committed test — and (b) then asked the user whether the
  blast-radius fixture's 4/4/4 bucket mix resembles real codebases, a question
  answerable by two tool calls per symbol against any repo on this machine.
