---
id: b1e1f89b7d587cb8
kind: bug
status: fixed
title: Toolchain classifier mistakes compiler source excerpts for fatal signals
tags:
- cluster/unclassified
- effort-steering
- grader
closed: 2026-11-06
fix_branch: fix/grader-validity-20261106
fix_commit: a2ffc143266c5e828afd7d8ef2ceb665318df49f
fix_patch_id: 6d3afca0f9ca24e2ccc9032c5aea79f418b64b7c
opened: 2026-11-06
owner: marius
related:
- '54fe4b112aa4e423'
- '0a2929ec2a4f688f'
severity: medium
---

# Toolchain classifier mistakes compiler source excerpts for fatal signals

## Summary

`tools/setup-ab-eval/multilang_grade.py:129` matches bare Bus error / Segmentation fault anywhere, and `toolchain_crash` at line 141 excludes only test-status lines. An ordinary compiler diagnostic with source excerpt `2 |     println!(Bus error);` yields that excerpt as the crash line. Through the existing fake-Docker LiveGraderTests seam, zero parser statuses then produce infra=toolchain_crash plus truthy error at `multilang_tasks.py:461`, incorrectly converting a candidate compile failure into infrastructure.

## Class fit

Unclassified pending taxonomy review. This is an observed grader classification or evidence-attribution defect introduced in the isolated grader-validity implementation; its failure is distinct from the two original incidents.

## Reproduction

Run `PYTHONDONTWRITEBYTECODE=1 python3 /tmp/grader-validity-review-20261106/probe-edges.py`; inspect `edge-observations.json.classifier_false_positive`. This is a synthetic compiler-shaped diagnostic fed through the actual classifier and live grader with fake Docker; no native task was run.

## Environment

Uncommitted implementation on base `4c90f8fab45f1e1d3245749d58e7f17ec399b485`, worktree `/home/marius/work/claude/codescout.worktrees/grader-validity`; source snapshot `/tmp/grader-validity-review-20261106/originals/setup-ab-eval`.

## Evidence

Full probe code, inputs and observed output: `/tmp/grader-validity-review-20261106/probe-edges.py`, `/tmp/grader-validity-review-20261106/edge-observations.json`, `/tmp/grader-validity-review-20261106/logs/edge-observations.log`. Four-file baseline: 220 passed, 79 subtests passed.

## Fix

Constrain process-signal signatures to process diagnostics rather than quoted/source/log substrings; pin ordinary compiler excerpts containing each signal phrase and preserve genuine collect2/rustc/shell signals.

## Resume

Parent owns one offline fix pass. Reviewer has not edited production or tests.


## Verified correction — 2026-11-06

Anchored process-diagnostic regex replaces arbitrary signal-substring matching. Four compiler source excerpts and an actual live-grader boundary negative control first failed against original implementation, then pass.

Local isolated commit a2ffc143266c5e828afd7d8ef2ceb665318df49f on fix/grader-validity-20261106; stable patch-id 6d3afca0f9ca24e2ccc9032c5aea79f418b64b7c. Not merged or pushed. Whole changed suite227tests/85subtests passes. Full final gate12a CLOSED0, Python1642tests/529subtests, FMT/CLIPPY/LEAN/DEFAULT0, with printed scope exclusions retained. Changed setup-ab modules were also explicitly tested separately; the gate's1642 is not a combined total with227.

Original review12 applied8killed/4survived. Final reapplication11 original literals plus explicitly reanchored M02-v2 (error wording changed):12 applied11killed/1survived. M04 is redundant under anchored regex: four-cell targeted witness fixedguard/no-guard PASS/PASS, originalregexguard/no-guard PASS/FAIL. Do not claim12kills or count absent oldM02 as killed. No live guard defect remains demonstrated by these mutations.

Final audit docs/research/data/2026-11-06-grader-validity-audit-v2.json reproduces the first audit's four rows, all17protectedoldfilesunchanged. Original cohort/record/log/result bytes untouched, no model/provider/native regrade. Prospective LIVEpolicy/newcontrols/paid admission remain a separate gate. Evidence ROOT /home/marius/.cache/codescout-resident/codescout/grader-validity-20261106.


## Fix provenance

- **SHA:** `a2ffc143266c5e828afd7d8ef2ceb665318df49f` (`fix/grader-validity-20261106`, local only)
- **patch-id:** `6d3afca0f9ca24e2ccc9032c5aea79f418b64b7c`
