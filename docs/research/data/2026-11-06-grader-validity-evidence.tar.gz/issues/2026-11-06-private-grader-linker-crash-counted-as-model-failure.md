---
id: '54fe4b112aa4e423'
kind: bug
status: fixed
title: External private grading conflates linker crash with model test failure
tags:
- cluster/unclassified
- effort-steering
- evaluation
closed: 2026-11-06
fix_branch: fix/grader-validity-20261106
fix_commit: a2ffc143266c5e828afd7d8ef2ceb665318df49f
fix_patch_id: 6d3afca0f9ca24e2ccc9032c5aea79f418b64b7c
opened: 2026-11-06
owner: marius
severity: high
---

# BUG: External private grading conflates linker crash with model test failure

## Class fit

Unclassified evaluation-validity defect: a toolchain crash before any tests execute becomes a boolean model failure without an infrastructure-validity classification. Unlike an ordinary Rust source compilation diagnostic, this run reports an internal linker crash and no observed test outcomes.

## Evidence

Frozen cohort external-matched-repairs-20261105/results.json records Nushell18863 low passfalse, expected8622, missing8622, not_passing8622, no error and oom_killedfalse. Original log at nushell__nushell-18863--low/private-grader/low-a6931258/grade.log has526lines: linkingwithccfailed at502, LLVM backtrace506-521, `collect2: fatal error: ld terminated with signal 7 [Bus error], core dumped` at522 and couldnotcompile nu_plugin_polars(libtest)526. No test-result lines were found in this complete private log. Literal NoSpace/ENOSPC/quota patterns have0matches; this does not establish historical disk capacity or SIGBUS causation.

Read tools/setup-ab-eval/multilang_tasks.py live_grader: run_tests output goes directly to run_parser/verdict; no classification of no-tests/toolchaincrash. The outer /tmp/grade-external-candidate-01a15ca9-20261105.py rejects error/OOM/removal failures but accepts this result with noerror. CandidateSHA789cb6fa483752b1472f61d03e07e83d4ec03bb2686b8d1b86a46cd74080fd97.

## Containment and next action

Preserve original receipts/candidate/cost and raw boolean, but classify this observation as infrastructure-invalid, not8622observed test failures and not proven faulty candidate. Audit all4arms and parser coverage. Regrade the identical captured candidate in a fresh qualified environment without an LLM or candidate edits; preserve both attempts. Source/compiler failure due a genuinely invalid candidate remains distinct from linker SIGBUS. Diskpressure, memory pressure, LLVM fault or other cause is not yet attributed. Do not claim that more free disk alone proves the cause or correction.

## Historical disk correlation — 2026-11-06

Fresh system journal evidence overlaps the original failed grade: host ENOSPC and multiple rust-lld SIGBUS events at09:51:20 local. Structured COREDUMP_PID434016 has signal7/SIGBUS, Rust1.95.0 executable and cgroup docker-0cdda52eccee77301892550ddae51c6df0b6e794f8fdeff8e4930d414de2b0a7.scope. The lifecycle journal starts that container at09:38:18, adjacent dockerd network join names the exact recorded original grader sab-grade-nushell__nushell-18863-low-e9d452bc at09:38:19, and ends the scope at09:52:22 with8GiBmemory peak. Original grade.log/private-grade.json mtimes09:52:44/47. This ties the evaluation to a confirmed disk-pressure window; exact SIGBUS mechanism is not isolated from memory/toolchain factors. Allowlisted journal fields only retained (no environment metadata).

Evidence ROOT /home/marius/.cache/codescout-resident/codescout/external-grade-audit-20261106: linker-journal-window.json, linker-434016-cgroup-query.json, original-low-container-lifecycle.log, historical-disk-correlation.json. One same-candidate replay with exact original4CPU8GiB profile is active in nu-low-original-profile-replay; no model/provider calls, source/candidate hashes unchanged. Do not promote replay success, if any, to proof of a disk-only cause.

## Same-candidate diagnostic closure

Replay @bg_000000f7 exited0 after704.5s using the original4CPU8GiB profile and exact captured patch. Both registered F2P names now fail; all8620P2P pass; missing0. Source/candidate/original receipt hashes unchanged.70 resource samples/68successfulcontainerprobes show minimumroot322369671168bytes, no sampled oom/oom_kill, and8GiBlimit pressure. Container removed and independently absent. Thus the original infrastructure-invalid grade did not establish candidate quality; this separate replay establishes real semantic rejection. Both receipts retained; no model/provider calls or candidate resampling. The live_grader classification defect remains open, as it is not fixed by this derived audit. Reportfce51ffc4baf7906.


## Verified correction — 2026-11-06

live_grader now emits pass=false, infra=toolchain_crash and a truthy error when an anchored process-fatal diagnostic accompanies zero parsed statuses; normal compiler errors and logs with parsed statuses retain ordinary grading. Error wording names parser observations, not unmeasured execution counts.

Local isolated commit a2ffc143266c5e828afd7d8ef2ceb665318df49f on fix/grader-validity-20261106; stable patch-id 6d3afca0f9ca24e2ccc9032c5aea79f418b64b7c. Not merged or pushed. Whole changed suite227tests/85subtests passes. Full final gate12a CLOSED0, Python1642tests/529subtests, FMT/CLIPPY/LEAN/DEFAULT0, with printed scope exclusions retained. Changed setup-ab modules were also explicitly tested separately; the gate's1642 is not a combined total with227.

Original review12 applied8killed/4survived. Final reapplication11 original literals plus explicitly reanchored M02-v2 (error wording changed):12 applied11killed/1survived. M04 is redundant under anchored regex: four-cell targeted witness fixedguard/no-guard PASS/PASS, originalregexguard/no-guard PASS/FAIL. Do not claim12kills or count absent oldM02 as killed. No live guard defect remains demonstrated by these mutations.

Final audit docs/research/data/2026-11-06-grader-validity-audit-v2.json reproduces the first audit's four rows, all17protectedoldfilesunchanged. Original cohort/record/log/result bytes untouched, no model/provider/native regrade. Prospective LIVEpolicy/newcontrols/paid admission remain a separate gate. Evidence ROOT /home/marius/.cache/codescout-resident/codescout/grader-validity-20261106.


## Fix provenance

- **SHA:** `a2ffc143266c5e828afd7d8ef2ceb665318df49f` (`fix/grader-validity-20261106`, local only)
- **patch-id:** `6d3afca0f9ca24e2ccc9032c5aea79f418b64b7c`
