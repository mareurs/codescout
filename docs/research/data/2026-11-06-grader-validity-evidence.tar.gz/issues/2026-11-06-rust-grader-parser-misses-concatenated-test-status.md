---
id: '0a2929ec2a4f688f'
kind: bug
status: mitigated
title: Rust test parser misses passing test concatenated with test stdout
tags:
- cluster/unclassified
- effort-steering
- evaluation
closed: 2026-11-06
mitigation_branch: fix/grader-validity-20261106
mitigation_commit: a2ffc143266c5e828afd7d8ef2ceb665318df49f
mitigation_patch_id: 6d3afca0f9ca24e2ccc9032c5aea79f418b64b7c
opened: 2026-11-06
owner: marius
severity: high
---

# BUG: Rust grader parser misses passing test concatenated with test stdout

## Class fit

Unclassified measurement defect: line-oriented status parsing loses a real status when stdout is interleaved without a newline. Unlike a missing test execution, the exact expected test and passed status are present in the raw log.

## Observed evidence

Frozen external-matched-repairs-20261105 Nushell18863 xhigh private-grade.json expected8622/not_passing2/missing1. Missing example: target/debug/deps/tests-b7e6894743b0a1f5::last_result::bare_external_with_inherited_stdout_does_not_capture. Raw private-grader/xhigh-786d4b39/grade.log line3725 is `should_not_overwrite_lasttest last_result::bare_external_with_inherited_stdout_does_not_capture ... ok`. Thus this expected test has a real observed pass and the missing label is false. A separate test, mixed_str_length_result_does_replace_last, actually FAILED at3259 with assertion leftString(ab),rightInt2 at3731-3734.

## Scope

Original results remain immutable. Inspect the record's actual log_parser and all4private logs before correcting coverage counts. Do not convert an arbitrary matching substring into status: avoid failure-block/echoed-output false positives and retain exact binary/test identity. Add a real-log regression and apply mutations before modifying parser behavior. Correct missing classification in an explicit audit artifact; legitimate failing assertion must remain failed. No new LLM call or task patch change is required to audit/reparse.


## Historical audit mitigation — 2026-11-06

Commit a2ffc143266c5e828afd7d8ef2ceb665318df49f on fix/grader-validity-20261106, stable patch-id 6d3afca0f9ca24e2ccc9032c5aea79f418b64b7c, adds tested retrospective audit_reparse.py with unchanged record parser, exact expected binary/test identity, physical split attribution and original failure protection. Final audit docs/research/data/2026-11-06-grader-validity-audit-v2.json recovers the P2P pass at NUxhigh line3725:missing1to0/notpassing2to1; real failure remains. All17protectedoldfilesunchanged. Wholechanged227tests/85subtests plus fullgate12aGREEN. Original review survivors and final11killed/1inertsurvivor are recorded in the dedicated research evidence.

Status remains mitigated: the frozen dataset/live parser was deliberately not changed. A new prospective normalization/adjudication policy must be explicitly registered and qualified by fresh empty/gold/repeat controls before it can become a live oracle. Do not mark the production parser defect fixed from a historical audit. No old result rewrite, new model/provider call or repeated NUlow diagnostic. No merge/push.


## Fix provenance

- **SHA:** `a2ffc143266c5e828afd7d8ef2ceb665318df49f` (`fix/grader-validity-20261106`, local only)
- **patch-id:** `6d3afca0f9ca24e2ccc9032c5aea79f418b64b7c`
