---
id: '73efe0aa746d30f9'
kind: bug
status: fixed
title: Audit reparse attributes a recovered ordinary test to another test's glued line
tags:
- cluster/unclassified
- effort-steering
- grader
closed: 2026-11-06
fix_branch: fix/grader-validity-20261106
fix_commit: a2ffc143266c5e828afd7d8ef2ceb665318df49f
fix_patch_id: 6d3afca0f9ca24e2ccc9032c5aea79f418b64b7c
opened: 2026-11-06
owner: marius
related:
- '54fe4b112aa4e423'
- '0a2929ec2a4f688f'
severity: medium
---

# Audit reparse attributes a recovered ordinary test to another test's glued line

## Summary

`tools/setup-ab-eval/audit_reparse.py:49-56` compares cumulatively transformed prefixes for every split, then assigns every changed key to the current split without checking that the current split caused that key. With the unchanged fixture parser and three lines `Running tests/main.rs (binary-b)test first ... ok`, `test ordinary ... ok`, `outputtest second ... ok`, the output reports binary-b::ordinary as recovered on line 3 with raw `outputtest second ... ok`. Its real status was on line 2; splitting the earlier header changed the suite context.

## Class fit

Unclassified pending taxonomy review. This is an observed grader classification or evidence-attribution defect introduced in the isolated grader-validity implementation; its failure is distinct from the two original incidents.

## Reproduction

Run `PYTHONDONTWRITEBYTECODE=1 python3 /tmp/grader-validity-review-20261106/probe-edges.py`; inspect `edge-observations.json.audit_attribution`. All inputs are synthetic log strings and the original record parser; no frozen evidence is modified.

## Environment

Uncommitted implementation on base `4c90f8fab45f1e1d3245749d58e7f17ec399b485`, worktree `/home/marius/work/claude/codescout.worktrees/grader-validity`; source snapshot `/tmp/grader-validity-review-20261106/originals/setup-ab-eval`.

## Evidence

Full probe code, inputs and observed output: `/tmp/grader-validity-review-20261106/probe-edges.py`, `/tmp/grader-validity-review-20261106/edge-observations.json`, `/tmp/grader-validity-review-20261106/logs/edge-observations.log`. Four-file baseline: 220 passed, 79 subtests passed.

## Fix

Prove recovery and attribution from the current physical split with an exact binary/test identity guard; do not attribute downstream context changes to an unrelated status line. Add a regression for header concatenation plus a later unrelated split.

## Resume

Parent owns one offline fix pass. Reviewer has not edited production or tests.


## Verified correction — 2026-11-06

Audit compares the current physical split with a prefix where previous splits are already normalized and requires current status identity. The observed header-context example now leaves ordinary missing and attributes only first/second to their own lines.

Local isolated commit a2ffc143266c5e828afd7d8ef2ceb665318df49f on fix/grader-validity-20261106; stable patch-id 6d3afca0f9ca24e2ccc9032c5aea79f418b64b7c. Not merged or pushed. Whole changed suite227tests/85subtests passes. Full final gate12a CLOSED0, Python1642tests/529subtests, FMT/CLIPPY/LEAN/DEFAULT0, with printed scope exclusions retained. Changed setup-ab modules were also explicitly tested separately; the gate's1642 is not a combined total with227.

Original review12 applied8killed/4survived. Final reapplication11 original literals plus explicitly reanchored M02-v2 (error wording changed):12 applied11killed/1survived. M04 is redundant under anchored regex: four-cell targeted witness fixedguard/no-guard PASS/PASS, originalregexguard/no-guard PASS/FAIL. Do not claim12kills or count absent oldM02 as killed. No live guard defect remains demonstrated by these mutations.

Final audit docs/research/data/2026-11-06-grader-validity-audit-v2.json reproduces the first audit's four rows, all17protectedoldfilesunchanged. Original cohort/record/log/result bytes untouched, no model/provider/native regrade. Prospective LIVEpolicy/newcontrols/paid admission remain a separate gate. Evidence ROOT /home/marius/.cache/codescout-resident/codescout/grader-validity-20261106.


## Fix provenance

- **SHA:** `a2ffc143266c5e828afd7d8ef2ceb665318df49f` (`fix/grader-validity-20261106`, local only)
- **patch-id:** `6d3afca0f9ca24e2ccc9032c5aea79f418b64b7c`
