---
id: '77828ecdbae3b8c2'
kind: bug
status: fixed
title: Audit suite misses P2P recovery and three safety-guard mutations
tags:
- cluster/unclassified
- effort-steering
- grader
- test-coverage
closed: 2026-11-06
fix_branch: fix/grader-validity-20261106
fix_commit: a2ffc143266c5e828afd7d8ef2ceb665318df49f
fix_patch_id: 6d3afca0f9ca24e2ccc9032c5aea79f418b64b7c
opened: 2026-11-06
owner: marius
related:
- '0a2929ec2a4f688f'
severity: medium
---

# Audit regression suite does not detect removal of P2P recovery

## Summary

The audit tests recover only keys supplied as F2P. Deleting the P2P half of `expected = set(f2p) | set(p2p)` in `tools/setup-ab-eval/audit_reparse.py:41` survives the full four-file changed suite: 220 tests and 79 subtests pass. This is an observed regression-guard gap; production currently includes P2P correctly.

## Class fit

Unclassified pending taxonomy review. The implementation is correct at this site but its tests cannot distinguish loss of a load-bearing expected-set dimension, unlike the original parser incident itself.

## Reproduction

Frozen mutation M06 in `/tmp/grader-validity-review-20261106/mutation-population.json` replaces the exact union with `expected = set(f2p)`. It was actually applied once using `scripts/mutation-probe.sh` in an isolated copy. Full log: `/tmp/grader-validity-review-20261106/logs/M06.log`; baseline: `logs/baseline.log` in the same directory. Both ran the same four test modules and reported 220 passed, 79 subtests passed. The helper's cargo-only summary prints INCONCLUSIVE for pytest; the quoted counts are pytest's own output.

## Evidence

`tools/setup-ab-eval/test_audit_reparse.py:27` puts the recovered key in F2P and the pre-existing failure in P2P; the remaining reparse tests at lines 37,42,48,55,63,70 all pass an empty P2P list. Thus none observes a newly recovered expected P2P key.

## Additional frozen survivors observed

The same 220-test / 79-subtest suite also survived M07 removing the original-fail guard at `audit_reparse.py:44`, M09 removing the terminal anchor from `_STATUS` at line 6, and M10 treating ANSI-only prefixes as substantive at line 21. Diagnostic reruns of the SAME frozen mutations (no new mutation population) are preserved in `logs/M07-witness.log`, `logs/M09-witness.log`, `logs/M10-witness.log`; structured differences in `survivor-witness-results.json`.

M07 is redundant for the frozen fixture parser because that parser already ranks fail above pass. A synthetic record parser with last-observation wins, held unchanged across its before/after calls, demonstrates the standalone guard is meaningful: baseline retains original fail; M07 replaces it with recovered pass. The existing failure test at `test_audit_reparse.py:53` therefore does not pin the audit guard itself.

M09 changes a terminal-only transform into one that splits `outputtest t ... ok trailing noise`; M10 splits an already-valid ANSI-prefixed status. The direct split output/metadata changes were observed. The existing ANSI test at `test_audit_reparse.py:59` checks only reparse verdict/recovered results, so the unchanged record parser conceals the extra split. These two are splitter-contract/metadata gaps; the witness does not show a changed final frozen-parser verdict.

All four primary survivors were applied in isolated helper worktrees and each completed the full four-file pytest suite successfully. Supplemental witnesses print behavior; they are not counted as test suites.

## Fix

Add a regression that recovers an exact expected P2P key and asserts recovered identity, verdict and physical source line, then reapply frozen mutation M06 and observe it fail. No production behavior change needed for this finding.

## Resume

Parent owns the one offline fix pass; reviewer did not change source or tests.


## Verified correction — 2026-11-06

P2P recovery, standalone original-fail protection with an alternate unchanged last-wins parser, and direct terminal/ANSI splitter outputs now have regression tests. All four original surviving audit mutations M06/M07/M09/M10 were actually reapplied and killed.

Local isolated commit a2ffc143266c5e828afd7d8ef2ceb665318df49f on fix/grader-validity-20261106; stable patch-id 6d3afca0f9ca24e2ccc9032c5aea79f418b64b7c. Not merged or pushed. Whole changed suite227tests/85subtests passes. Full final gate12a CLOSED0, Python1642tests/529subtests, FMT/CLIPPY/LEAN/DEFAULT0, with printed scope exclusions retained. Changed setup-ab modules were also explicitly tested separately; the gate's1642 is not a combined total with227.

Original review12 applied8killed/4survived. Final reapplication11 original literals plus explicitly reanchored M02-v2 (error wording changed):12 applied11killed/1survived. M04 is redundant under anchored regex: four-cell targeted witness fixedguard/no-guard PASS/PASS, originalregexguard/no-guard PASS/FAIL. Do not claim12kills or count absent oldM02 as killed. No live guard defect remains demonstrated by these mutations.

Final audit docs/research/data/2026-11-06-grader-validity-audit-v2.json reproduces the first audit's four rows, all17protectedoldfilesunchanged. Original cohort/record/log/result bytes untouched, no model/provider/native regrade. Prospective LIVEpolicy/newcontrols/paid admission remain a separate gate. Evidence ROOT /home/marius/.cache/codescout-resident/codescout/grader-validity-20261106.


## Fix provenance

- **SHA:** `a2ffc143266c5e828afd7d8ef2ceb665318df49f` (`fix/grader-validity-20261106`, local only)
- **patch-id:** `6d3afca0f9ca24e2ccc9032c5aea79f418b64b7c`
