import sys, json, pathlib, tempfile
sys.path.insert(0, "/tmp/grader-validity-review-20261106/originals/setup-ab-eval")
import audit_reparse as audit, multilang_grade as grade
from test_multilang_tasks import LiveGraderTests, FakeDocker, PATCH, record
root = pathlib.Path("/tmp/grader-validity-review-20261106")
record0 = json.loads((root/"originals/setup-ab-eval/fixtures/multilang/rust_concat_record.json").read_text())
compiler_log = 'error: format argument must be a string literal\n --> src/main.rs:2:14\n  |\n2 |     println!(Bus error);\n  |              ^^^^^^^^^\nerror: could not compile candidate due to previous error\n'
case=LiveGraderTests();case.setUp()
try:
    fake=FakeDocker();fake.GOLD_LOG=compiler_log
    result=case.grade(PATCH, fake=fake, rec=record(log_parser=record0["log_parser"]))
finally: case.doCleanups()
log = "Running tests/main.rs (binary-b)test first ... ok\ntest ordinary ... ok\noutputtest second ... ok\n"
keys=["binary-b::first", "binary-b::ordinary", "binary-b::second"]
attribution = audit.reparse(record0, log, keys, [])
out = {"classifier_false_positive": {"log":compiler_log, "signal":grade.toolchain_crash(compiler_log), "grade":result}, "audit_attribution": {"log":log, "expected":keys, "result":attribution}}
(root/"edge-observations.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps(out,indent=2))
