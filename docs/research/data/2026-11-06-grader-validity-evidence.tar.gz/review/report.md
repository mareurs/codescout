# Grader-validity final review — changes requested

Reviewed the uncommitted implementation on `4c90f8fab45f1e1d3245749d58e7f17ec399b485` in `/home/marius/work/claude/codescout.worktrees/grader-validity`. No original source, tests, index, or HEAD were edited. Original snapshots, fixture and tracked diff are preserved under this directory. MAIN issue records were written through the librarian.

## Findings

**Critical: none observed.**

**Important R1 — compiler source excerpts become infrastructure crashes.** At `multilang_grade.py:129` and `:141`, bare signal phrases are matched anywhere except a line starting with `test `. A synthetic ordinary compiler diagnostic containing `2 |     println!(Bus error);` returns that source excerpt as a crash. Running the actual live-grader function through its fake-Docker seam produces `infra=toolchain_crash` and truthy `error` at `multilang_tasks.py:461`. This violates the genuine-compile-error requirement. Constrain signatures to process diagnostic shapes and pin quoted/source/caret cases. [Issue b1e1f89b7d587cb8](/home/marius/work/claude/codescout/docs/issues/2026-11-06-toolchain-classifier-source-excerpt-false-signal.md). Exact observation: [edge-observations.json](edge-observations.json).

**Important R2 — cumulative reparsing misattributes a test to an unrelated raw line.** `audit_reparse.py:49-56` compares the original prefix to a prefix with *all* earlier splits applied. With the unchanged fixture parser, this three-line input reports `binary-b::ordinary` as recovered on line 3 with raw text naming `second`:

```text
Running tests/main.rs (binary-b)test first ... ok
test ordinary ... ok
outputtest second ... ok
```

Splitting the first line changes the suite context for the ordinary second-line status; the third split is then credited with that earlier change. Compare the current split against the same prefix with earlier splits already applied, and enforce the exact current status identity. [Issue 73efe0aa746d30f9](/home/marius/work/claude/codescout/docs/issues/2026-11-06-audit-reparse-cumulative-line-misattribution.md). Inputs and outputs are in `edge-observations.json.audit_attribution`.

**Important R3 — tests miss P2P recovery and the audit's own failure protection.** Applied mutations M06 and M07 each ran the complete changed suite with **220 tests and 79 subtests passing**. M06 removes `set(p2p)` from `audit_reparse.py:41`; the recovery tests at `test_audit_reparse.py:27,37,42,48,55,63,70` put recovered keys in F2P. The actual Nushell recovered key is P2P. The diagnostic witness shows M06 changes a recovered P2P pass to missing/failing.

M07 removes `original.get(key) != "fail"` at `audit_reparse.py:44`. The frozen fixture parser already preserves the strongest severity, so the current failure test does not exercise the audit's independent guard. A synthetic last-result-wins record parser, held unchanged between before/after calls, demonstrates the guard's effect: baseline preserves the original failure; M07 reports a recovered pass. Add direct regression coverage for both guards. [Issue 77828ecdbae3b8c2](/home/marius/work/claude/codescout/docs/issues/2026-11-06-audit-tests-miss-p2p-recovery.md).

**Minor R4 — splitter metadata guards are not pinned.** M09 removes the terminal anchor at `audit_reparse.py:6`; M10 removes ANSI-prefix normalization at `:21`. Both survive the same full suite. Supplemental witnesses show that M09 splits `outputtest t ... ok trailing noise` and M10 splits an already-valid ANSI-prefixed status. These change transformed bytes and split metadata; the witnesses do **not** show a changed final verdict under the frozen parser. The test at `test_audit_reparse.py:59` checks reparse output only. Assert the splitter output directly. Recorded in the same coverage issue.

## Observed mutation results

Population frozen before execution: [mutation-population.json](mutation-population.json), SHA256 `576653570458ad5001ce1abda93280c6543d9db5f24017ec03de5513cf5388c2`.

**12 candidates actually applied; 8 killed, 4 survived.** Each used `scripts/mutation-probe.sh` isolated mode, carrying the original tracked/untracked working tree. There were no helper refusals. The helper reports INCONCLUSIVE for pytest because its verdict parser counts Cargo output only; these results come from actual pytest summaries and assertion output, not exit status alone.

| ID | Mutation | Observed result |
|---|---|---|
| M01 | Remove zero-status restriction | Killed: 1 failed, 219 passed, 79 subtests passed |
| M02 | Empty the compatibility error | Killed: 1 failed, 219 passed, 79 subtests passed |
| M03 | Disable signal detection | Killed: 5 failed, 217 passed, 77 subtests passed |
| M04 | Admit test names as signals | Killed: 1 failed, 220 passed, 78 subtests passed |
| M05 | Recover all parsed identities | Killed: 2 failed, 218 passed, 79 subtests passed |
| M06 | Drop P2P recovery | Survived: 220 passed, 79 subtests passed |
| M07 | Remove original-failure guard | Survived: 220 passed, 79 subtests passed |
| M08 | Replace raw line with split suffix | Killed: 1 failed, 219 passed, 79 subtests passed |
| M09 | Remove terminal status anchor | Survived: 220 passed, 79 subtests passed |
| M10 | Admit ANSI-only prefix | Survived: 220 passed, 79 subtests passed |
| M11 | Assign every recovery line 1 | Killed: 2 failed, 218 passed, 79 subtests passed |
| M12 | Use whole-log attribution prefix | Killed: 1 failed, 219 passed, 79 subtests passed |

M03 and M04 failures include subtest failures; these printed counts must not be added to infer a different test population. Full logs `logs/M01.log` through `logs/M12.log`, structured summaries in [mutation-results.json](mutation-results.json). Baseline: [logs/baseline.log](logs/baseline.log), 220 passed/79 subtests passed.

The same four survivor mutations were reapplied for diagnostic witnesses, without changing the frozen population. Witnesses print behavior and are not counted as additional test suites. [survivor-witness-results.json](survivor-witness-results.json).

## Strengths and audit calibration

- M01/M02 directly pin the zero-status boundary and the truthy error required by the old external wrapper (`/tmp/grade-external-candidate-01a15ca9-20261105.py:31` checks error, not infra).
- Exact expected/binary identity is tested: M05 is killed by outside-expected and other-binary assertions.
- Raw-line and multiple-suite assertions kill M08/M11/M12, though the contextual R2 counterexample remains.
- The fixture parser is byte-identical to the original Nushell record parser.
- Independent full-log recalculation reproduces all four saved original verdicts and every audit-artifact row. The 17 unique protected files were hashed against the artifact and again after calibration; every digest matched.

Artifact SHA256: `2221fee48b54ee56e0040be7bbd4676f802494747c6ad41b4b72af6bf70657b4`. Nushell low: zero parsed keys plus observed crash signature. Nushell xhigh: 8,724 parsed keys; one expected P2P recovered at physical line 3725; missing 1→0 and not-passing 2→1; the actual mixed-string failure remains. Rust-analyzer xhigh/low: 8,194/8,193 parsed keys respectively, with 8,182 expected keys each and both expected-set verdicts passing. These are distinct measured populations. No low/xhigh effect or parity claim follows. See [audit-calibration.json](audit-calibration.json).

The parent-owned gate record and full log were independently read and copied to `gate-record.json` and `logs/parent-gate.log`: exit 0, Python 1,642 passed/529 subtests passed, FMT/CLIPPY/LEAN/DEFAULT all 0. Reviewer did not rerun that gate.

## Declined to judge — explicit parent rulings requested

| ID | Behavior | Why |
|---|---|---|
| D1 | Disk, RAM, LLVM or candidate causation of SIGBUS (`multilang_grade.py:134`) | Signal text cannot establish cause; causal instrumentation/regrade is outside this review. |
| D2 | Prospective live-oracle/new-cohort admission (old wrapper source hash checks at `:20,30`) | This is a retrospective audit; new source needs registration and controls. No admission is implied. |
| D3 | Authenticity of arbitrary stdout byte-identical to expected libtest text (`audit_reparse.py:6,18-25`) | Text parsing cannot identify the producer of indistinguishable bytes. This review checks bounded transformation, identity and attribution. |
| D4 | Broader language/status dialects or actual native task execution (`audit_reparse.py:6`; `multilang_tasks.py:432-459`) | The specified Rust suffix transform, stored logs and fake-Docker boundaries are the tested scope; no native regrade/container/model/provider call was run. |
| D5 | Coverage outside the completed gate's declared scope | Its log explicitly excludes heavy Python, server-stack, local ONNX-weight tests and librarian in the lean lane. Zero exits do not qualify those behaviors. |

## Evidence and handback

Original eight scoped files still match their pre-review byte snapshots: [original-integrity.json](original-integrity.json). Full source/test directory snapshot: `originals/setup-ab-eval/`; original tracked diff: `original-tracked.diff`. The evidence manifest includes report, population, snapshots, scripts and actual logs and excludes itself: [evidence-manifest.json](evidence-manifest.json).

One bounded review is complete. Parent may now perform the authorized offline fix/test pass and reapply the exact frozen mutations. If a frozen literal disappears after a structural fix, report it as not applied/retired and rule on that explicitly; do not count it as killed. No new review cycle requested.

Ledger checked: 54fe4b112aa4e423, 0a2929ec2a4f688f, b1e1f89b7d587cb8, 73efe0aa746d30f9, 77828ecdbae3b8c2.
