import hashlib, json, pathlib, sys
root=pathlib.Path("/tmp/grader-validity-review-20261106")
sys.path.insert(0,str(root/"originals/setup-ab-eval"))
import audit_reparse as audit, multilang_grade as grade, multilang_tasks as tasks
artifactpath=pathlib.Path("/home/marius/work/claude/codescout/docs/research/data/2026-11-06-grader-validity-audit.json")
artifact=json.loads(artifactpath.read_text())
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
before={p:sha(p) for p in artifact["protected_files_before_after"]}
assert before == artifact["protected_files_before_after"]
fixture=json.loads((root/"originals/setup-ab-eval/fixtures/multilang/rust_concat_record.json").read_text())
rows=[]
for row in artifact["rows"]:
    bundlepath=pathlib.Path("/home/marius/work/claude/setup-ab-data/fresh-tasks")/row["task"]/"bundle.json"
    bundle=json.loads(bundlepath.read_text())
    recordpath=pathlib.Path(bundle["record_path"]); record=json.loads(recordpath.read_text())
    logpath=pathlib.Path(row["log"]); raw=logpath.read_text()
    f2p,p2p=tasks.expected_sets(record,bundle)
    statuses=grade.run_parser(record["log_parser"],raw)
    original=grade.verdict(statuses,f2p,p2p)
    reparsed=audit.reparse(record,raw,f2p,p2p)
    assert reparsed == {k:row[k] for k in ["original","adjusted","recovered"]}
    assert original == row["original"] and len(statuses)==row["parsed_status_keys"]
    oldgrade=json.loads((logpath.parent.parent.parent/"private-grade.json").read_text())
    assert all(original[k]==oldgrade[k] for k in original)
    assert sha(logpath)==row["log_sha256"] and sha(recordpath)==row["record_sha256"]
    if row["task"].startswith("nushell"):
        assert fixture["log_parser"]==record["log_parser"] and fixture["record_sha256"]==sha(recordpath)
    _,splits=audit.split_concatenated_status(raw)
    assert len(splits)==row["split_lines"]
    assert grade.toolchain_crash(raw)==row["crash_line"]
    for recovered in reparsed["recovered"]:
        assert raw.splitlines()[recovered["line"]-1]==recovered["raw"]
        assert recovered["key"] in set(f2p)|set(p2p)
    rows.append({"task":row["task"],"effort":row["effort"],"parsed_status_keys":len(statuses),"expected_keys":len(f2p)+len(p2p),"original_verdict_matches_saved":True,"audit_matches_artifact":True,"recovered":reparsed["recovered"],"failed_expected_keys":[k for k in f2p+p2p if statuses.get(k)=="fail"]})
after={p:sha(p) for p in before}
assert before==after
out={"artifact_sha256":sha(artifactpath),"protected_unique_files_measured":len(before),"protected_hashes_before_after":after,"fixture_matches_original_parser":True,"rows":rows}
(root/"audit-calibration.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps({"artifact_sha256":out["artifact_sha256"],"protected_unique_files_measured":len(before),"rows":rows},indent=2))
