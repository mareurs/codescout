import json, os, pathlib, sys
sys.path.insert(0,os.path.join(os.getcwd(),"tools/setup-ab-eval"))
import audit_reparse as audit
record=json.loads(pathlib.Path("tools/setup-ab-eval/fixtures/multilang/rust_concat_record.json").read_text())
running="Running tests/main.rs (binary)\n"
glued="outputtest t ... ok\n"
last_wins={"log_parser": "def parser(log):\n    import re\n    out = {}\n    for line in log.splitlines():\n        match = re.fullmatch(r'test (\\S+) \\.\\.\\. (ok|FAILED)', line)\n        if match: out['binary::' + match[1]] = 'pass' if match[2] == 'ok' else 'fail'\n    return out\n"}
print(json.dumps({
"p2p":audit.reparse(record,running+glued,[],["binary::t"]),
"last_wins_failure_guard":audit.reparse(last_wins,"test t ... FAILED\n"+glued,["binary::t"],[]),
"terminal":audit.split_concatenated_status(running+"outputtest t ... ok trailing noise\n"),
"ansi":audit.split_concatenated_status(running+"\u001b[32mtest t ... ok\n")
},indent=2))
