import json, os, pathlib, subprocess, time
root = pathlib.Path("/tmp/grader-validity-review-20261106")
worktree = "/home/marius/work/claude/codescout.worktrees/grader-validity"
pop = json.loads((root/"mutation-population.json").read_text())["mutations"]
env = dict(os.environ, CODEX_SESSION_ID="01a15ca9-f939-7603-acb5-01c6b02f68e2", PYTHONDONTWRITEBYTECODE="1")
tests = ["tools/setup-ab-eval/" + x for x in ["test_multilang_grade.py", "test_multilang_tasks.py", "test_run.py", "test_audit_reparse.py"]]
results = []
for m in pop[1:]:
    command = ["./scripts/mutation-probe.sh", "--file", m["file"], "--find", m["find"], "--replace", m["replace"], "--", "python3", "-m", "pytest", "-p", "no:cacheprovider", *tests, "-q"]
    started = time.time()
    with (root/"logs"/(m["id"]+".log")).open("w") as log:
        p = subprocess.run(command, cwd=worktree, env=env, stdout=log, stderr=subprocess.STDOUT)
    results.append({"id":m["id"], "exit_code":p.returncode, "seconds":round(time.time()-started, 3), "command":command})
    (root/"execution.json").write_text(json.dumps(results,indent=2)+"\n")
    print(m["id"], p.returncode, flush=True)
