"""Audit scaffold: does not alter any log or grade."""
import re

import multilang_grade as grade

_STATUS = re.compile(r"test (?P<name>\S+) \.\.\. (?P<status>ok|FAILED|ignored)\s*$")
_ANSI = re.compile(r"\x1b(?:\[[0-?]*[ -/]*[@-~]|\][^\x07\x1b]*(?:\x07|\x1b\\)|[@-_])")

def split_concatenated_status(log):
    """Insert only a newline before a terminal glued Rust libtest status.

    Exact binary/test keys still come exclusively from the record's unchanged parser.
    This is an audit transform, never an alternate live oracle.
    """
    output, splits = [], []
    for number, line in enumerate(log.splitlines(keepends=True), 1):
        raw = line.rstrip("\r\n")
        match = _STATUS.search(raw)
        if match:
            prefix = raw[:match.start()]
            if _ANSI.sub("", prefix).strip():
                status_line = raw[match.start():]
                output.append(prefix + "\n" + status_line + line[len(raw):])
                splits.append({"line": number, "prefix": prefix, "status_line": status_line,
                               "name": match["name"], "raw": raw})
                continue
        output.append(line)
    return "".join(output), splits

def reparse(record, log, f2p, p2p):
    """Compare the record parser before/after splitting; expected identities only.

    A recovered key is attributed by a parser difference on that physical line's
    complete prefix, so repeated test names in distinct binaries cannot alias.
    Original failures are never replaced by recovered passes.
    """
    parser = record["log_parser"]
    original = grade.run_parser(parser, log)
    split_log, splits = split_concatenated_status(log)
    reparsed = grade.run_parser(parser, split_log)
    expected = set(f2p) | set(p2p)
    changed = {key for key in expected
               if key in reparsed and original.get(key) != reparsed[key]
               and original.get(key) != "fail"}
    adjusted = dict(original)
    recovered = []
    lines = log.splitlines(keepends=True)
    for split in splits:
        prefix = "".join(lines[:split["line"]])
        before = grade.run_parser(parser, prefix)
        after = grade.run_parser(parser, split_concatenated_status(prefix)[0])
        for key in sorted(changed):
            if before.get(key) != after.get(key) and after.get(key) == reparsed[key]:
                adjusted[key] = reparsed[key]
                recovered.append({"key": key, "status": reparsed[key], "line": split["line"],
                                  "raw": split["raw"]})
                changed.remove(key)
    return {"original": grade.verdict(original, f2p, p2p),
            "adjusted": grade.verdict(adjusted, f2p, p2p), "recovered": recovered}
