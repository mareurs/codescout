"""Audit-only tests use the dataset parser verbatim; no native/paid task runs."""
import json
import unittest
from pathlib import Path

import audit_reparse as audit

RECORD = json.loads((Path(__file__).parent / "fixtures/multilang/rust_concat_record.json").read_text())
SUITE = "target/debug/deps/tests-b7e6894743b0a1f5"
RUNNING = "Running tests/main.rs (" + SUITE + ")\n"
BARE = "last_result::bare_external_with_inherited_stdout_does_not_capture"
BAD = "last_result::mixed_str_length_result_does_replace_last"
GLUED = "should_not_overwrite_lasttest " + BARE + " ... ok\n"


class ReparseTests(unittest.TestCase):
    def test_split_retains_exact_stdout_prefix_and_line_identity(self):
        text, splits = audit.split_concatenated_status("header\n" + GLUED)
        self.assertEqual(text, "header\nshould_not_overwrite_last\ntest " + BARE + " ... ok\n")
        self.assertEqual(len(splits), 1)
        self.assertEqual(splits[0]["line"], 2)
        self.assertEqual(splits[0]["prefix"], "should_not_overwrite_last")
        self.assertEqual(splits[0]["status_line"], "test " + BARE + " ... ok")

    def test_recovers_expected_pass_without_hiding_real_failure(self):
        log = RUNNING + "test " + BAD + " ... FAILED\n" + GLUED
        result = audit.reparse(RECORD, log, [SUITE + "::" + BARE], [SUITE + "::" + BAD])
        self.assertEqual((result["original"]["missing"], result["adjusted"]["missing"]), (1, 0))
        self.assertEqual(result["adjusted"]["not_passing"], 1)
        self.assertIs(result["adjusted"]["pass"], False)
        self.assertEqual(result["adjusted"]["examples"], [SUITE + "::" + BAD])
        self.assertEqual(result["recovered"], [{"key": SUITE + "::" + BARE, "status": "pass",
                                              "line": 3, "raw": GLUED.rstrip("\n")}])

    def test_expected_identity_includes_binary_not_only_test_name(self):
        log = "Running tests/main.rs (other-binary)\n" + GLUED
        result = audit.reparse(RECORD, log, [SUITE + "::" + BARE], [])
        self.assertEqual(result["adjusted"]["missing"], 1)
        self.assertEqual(result["recovered"], [])

    def test_does_not_recover_an_unexpected_name(self):
        result = audit.reparse(RECORD, RUNNING + GLUED, [SUITE + "::" + BAD], [])
        self.assertEqual(result["recovered"], [])
        self.assertEqual(result["adjusted"], result["original"])

    def test_glued_failure_beats_an_earlier_ok(self):
        log = RUNNING + "test " + BARE + " ... ok\nprefixtest " + BARE + " ... FAILED\n"
        result = audit.reparse(RECORD, log, [SUITE + "::" + BARE], [])
        self.assertTrue(result["original"]["pass"])
        self.assertFalse(result["adjusted"]["pass"])
        self.assertEqual(result["recovered"][0]["status"], "fail")

    def test_glued_pass_never_overwrites_an_earlier_failure(self):
        log = RUNNING + "test " + BARE + " ... FAILED\n" + GLUED
        result = audit.reparse(RECORD, log, [SUITE + "::" + BARE], [])
        self.assertFalse(result["adjusted"]["pass"])
        self.assertEqual(result["recovered"], [])

    def test_ansi_and_carriage_return_statuses_already_parsed_are_not_recovered(self):
        for prefix in ("\x1b[32m", "\r", "    "):
            with self.subTest(prefix=prefix):
                log = RUNNING + prefix + "test " + BARE + " ... ok\n"
                result = audit.reparse(RECORD, log, [SUITE + "::" + BARE], [])
                self.assertTrue(result["original"]["pass"])
                self.assertEqual(result["adjusted"], result["original"])
                self.assertEqual(result["recovered"], [])

    def test_multiple_suites_do_not_misattribute_same_test_name(self):
        log = RUNNING + GLUED + "Running tests/main.rs (other-binary)\n" + GLUED
        result = audit.reparse(RECORD, log, [SUITE + "::" + BARE, "other-binary::" + BARE], [])
        self.assertTrue(result["adjusted"]["pass"])
        self.assertEqual([(r["key"], r["line"]) for r in result["recovered"]],
                         [(SUITE + "::" + BARE, 2), ("other-binary::" + BARE, 4)])
