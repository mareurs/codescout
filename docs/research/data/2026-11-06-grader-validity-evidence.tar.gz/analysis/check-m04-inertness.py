"""Two-site counterfactual witness, not an additional mutation population.

The helper applies one literal; this witness varies regex and test-name guard in
four scratch copies to distinguish dead guard coverage from a live regression gap.
Original worktree and the twelve frozen review mutations are never changed.
"""
import hashlib, json, os, pathlib, re, shutil, subprocess, sys
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/grader-validity-20261106")
WT=pathlib.Path("/home/marius/work/claude/codescout.worktrees/grader-validity/tools/setup-ab-eval")
REVIEW=pathlib.Path("/tmp/grader-validity-review-20261106")
OUT=ROOT/"m04-inertness"

def main():
    if OUT.exists():raise ValueError("Refuse overwrite")
    OUT.mkdir()
    fixed=(WT/"multilang_grade.py").read_text()
    old=(REVIEW/"originals/setup-ab-eval/multilang_grade.py").read_text()
    pattern=r"_TOOLCHAIN_SIGNAL = re.compile\(.*?\n\)"
    fixedmatch=re.search(pattern,fixed,re.S);oldmatch=re.search(pattern,old,re.S)
    if not fixedmatch or not oldmatch:raise ValueError("Cannot locate exact regex")
    guard='not line.lstrip().startswith("test ") and '
    if fixed.count(guard)!=1:raise ValueError("Guard not unique")
    rows=[]
    for version in ("fixed_regex","original_regex"):
        for present in (True,False):
            name=version+("-guard" if present else "-no-guard");cell=OUT/name;cell.mkdir()
            body=fixed if version=="fixed_regex" else fixed[:fixedmatch.start()]+oldmatch[0]+fixed[fixedmatch.end():]
            if not present:body=body.replace(guard,"",1)
            (cell/"multilang_grade.py").write_text(body)
            shutil.copyfile(WT/"test_multilang_grade.py",cell/"test_multilang_grade.py")
            proc=subprocess.run([sys.executable,"-B","-m","pytest","-p","no:cacheprovider","test_multilang_grade.py","-k","ignores_compile_error_and_test_names","-q"],cwd=cell,capture_output=True,text=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1"),timeout=30)
            text=proc.stdout+proc.stderr;(cell/"suite.log").write_text(text)
            if "deselected" not in text or "passed" not in text or "SyntaxError" in text:raise ValueError("Invalid witness")
            rows.append({"cell":name,"exit_code":proc.returncode,"log":str(cell/"suite.log"),
                         "sha256":hashlib.sha256(body.encode()).hexdigest(),
                         "summary":text.splitlines()[-1]})
    if [r["exit_code"] for r in rows]!=[0,0,0,1]:raise ValueError("Expected inertness relationship not observed")
    result={"rows":rows,"ruling":"M04 is observationally redundant after anchored-regex fix on tested overlap. Removing guard becomes harmful when original broad regex is restored; no claim of full independent guard coverage.","extra_mutations_counted":0,"original_worktree_edited":False,"provider_calls":0}
    (ROOT/"m04-inertness.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))
if __name__=="__main__":main()
