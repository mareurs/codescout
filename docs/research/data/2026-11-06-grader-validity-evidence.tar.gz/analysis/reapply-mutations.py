"""Reapply frozen review mutations on helper-isolated trees; report literal drift honestly."""
import hashlib, json, os, pathlib, re, subprocess, time
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/grader-validity-20261106")
REVIEW=pathlib.Path("/tmp/grader-validity-review-20261106")
WT=pathlib.Path("/home/marius/work/claude/codescout.worktrees/grader-validity")
OUT=ROOT/"fix-mutations"
TESTS=["tools/setup-ab-eval/"+n for n in ("test_multilang_grade.py","test_multilang_tasks.py","test_run.py","test_audit_reparse.py")]
ENV=dict(os.environ,CODEX_SESSION_ID="01a15ca9-f939-7603-acb5-01c6b02f68e2",PYTHONDONTWRITEBYTECODE="1")

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def execute(mutation):
    command=["./scripts/mutation-probe.sh","--file",mutation["file"],"--find",mutation["find"],
             "--replace",mutation["replace"],"--","python3","-m","pytest","-p","no:cacheprovider",*TESTS,"-q"]
    path=OUT/(mutation["id"]+".log")
    with path.open("w") as log:
        result=subprocess.run(command,cwd=WT,env=ENV,stdout=log,stderr=subprocess.STDOUT,timeout=240)
    text=path.read_text()
    summaries=[line for line in text.splitlines() if re.search(r"\b\d+ passed\b",line) and "subtests" in line]
    if not summaries or any(s in text for s in ("SyntaxError","ModuleNotFoundError","ERROR collecting")):
        raise ValueError("Invalid mutation harness "+mutation["id"])
    summary=summaries[-1]
    if result.returncode==0 and "227 passed" not in summary:raise ValueError("Unexpected surviving population")
    if result.returncode!=0 and not re.search(r"\b\d+ failed\b",summary):raise ValueError("No observed assertion failure")
    return {"id":mutation["id"],"applied":True,"exit_code":result.returncode,
            "observed":"killed" if result.returncode else "survived","pytest_summary":summary,
            "helper_verdict":"INCONCLUSIVE for pytest; use observed inner pytest summary",
            "log":str(path),"sha256":sha(path),"command":command}

def main():
    if OUT.exists():raise ValueError("Refuse overwrite")
    OUT.mkdir()
    population=json.loads((REVIEW/"mutation-population.json").read_text())["mutations"]
    scoped=[WT/"tools/setup-ab-eval"/name for name in ("multilang_grade.py","multilang_tasks.py","test_multilang_grade.py","test_multilang_tasks.py","test_run.py","audit_reparse.py","test_audit_reparse.py","fixtures/multilang/rust_concat_record.json")]
    original={str(p):sha(p) for p in scoped}
    results=[]
    for mutation in population:
        body=(WT/mutation["file"]).read_text()
        if body.count(mutation["find"])!=1:
            if mutation["id"]!="M02":raise ValueError("Unexpected literal drift "+mutation["id"])
            results.append({"id":"M02","applied":False,"reason":"Error text corrected from an unmeasured execution claim to no parsed statuses; original literal preserved in reviewer population, not counted killed."})
            continue
        results.append(execute(mutation))
        (OUT/"progress.json").write_text(json.dumps(results,indent=2)+"\n")
        print(results[-1]["id"],results[-1]["observed"],flush=True)
    old=next(m for m in population if m["id"]=="M02")
    adapted=dict(old,id="M02-v2",find=old["find"].replace("before any test ran","with no parsed test statuses"))
    (OUT/"resited-population.json").write_text(json.dumps({"original_id":"M02","source_scope":"same truthy-error field, corrected observation wording","mutation":adapted},indent=2)+"\n")
    if (WT/adapted["file"]).read_text().count(adapted["find"])!=1:raise ValueError("Reanchored mutation not unique")
    results.append(execute(adapted))
    for path,expected in original.items():
        if sha(pathlib.Path(path))!=expected:raise ValueError("Owned source changed")
    record={"original_population":12,"original_literals_applied":sum(r.get("applied",False) for r in results if r["id"]!="M02-v2"),
            "original_literal_not_applied":["M02"],"explicitly_resited_applied":["M02-v2"],
            "applied_cases":sum(r.get("applied",False) for r in results),
            "killed":sum(r.get("observed")=="killed" for r in results),
            "survived":sum(r.get("observed")=="survived" for r in results),
            "results":results,"source_hashes_unchanged":original,"provider_calls":0}
    (ROOT/"fix-mutation-results.json").write_text(json.dumps(record,indent=2)+"\n")
    print(json.dumps({k:v for k,v in record.items() if k not in ("results","source_hashes_unchanged")},indent=2),flush=True)
if __name__=="__main__":main()
