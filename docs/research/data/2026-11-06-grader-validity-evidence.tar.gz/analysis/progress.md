# Grader validity ledger

Plan MAIN144495d0b8e0f23e. Parent01a15ca9 took over existing clean fix/grader-validity-20261106 at4c90f8fab after user confirmed original session only ran205baseline tests and never started edits. No merge/push or paid/model call.

Original205pass69subtests. Added helper/crashboundarytests; first live fixture erroneously made toy parser reject diagnostics. Production wiring removed, fixture corrected, observed intended1failure2pass, then wiring reapplied. Errorfunction missing red separate.212pass76subtests. WrongreasonRED retained classifier-red.log; lesson MAINbug-fix-session-log:F-213.

Audit module importmissing red then no-op4assertionfailures/4pass, implementation8pass3subtests. Verbatim parser fixture from actual Nushell record; audit helper stays out of live grader. Scope never claims primary live qualification.

Read-only cohort audit SHA2221fee48b54ee56e0040be7bbd4676f802494747c6ad41b4b72af6bf70657b4,17unique old inputs unchanged;4rawverdicts reproduce. NUlowzero statuses/SIGBUS. NUxhigh1split/expectedpassrecovered3725,missing1to0/notpassing2to1,realFAILremains. RA8182selectedexpectedpassboth. SamecandidateNUlowdiagnostic alreadyclosedf7, no regrade repetition.

Full gate127 ACTIVE. Single fresh independent grader_validity_review at/tmp/grader-validity-review-20261106 froze12literalmutations before execution. Parent permits one offline fix pass then same exact reapplication. Source frozen during review/gate. Any observed bug MAIN immediately. No commit until relevant checks pass; no broad source refactor.

Pending after boundedgraderfix: explicit prospectiveLIVEparser/infra policy plus fresh2taskempty/gold/repeatcontrols, concretepaidadapter/midstage-resourcepolicy, fixedsixpilot. The goal remains genericlowtoxhighquality atlowerwholeworkflowcost; effectnotmeasured. Do not spend days on additional equivalent wiring/reviewfixtures.
