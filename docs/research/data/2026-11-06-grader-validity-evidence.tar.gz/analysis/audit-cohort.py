"""Read-only audit of four frozen grades, never a live regrade."""
import hashlib, json, pathlib, sys
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
COHORT=ROOT/"external-matched-repairs-20261105"
SOURCE=pathlib.Path("/home/marius/work/claude/codescout.worktrees/grader-validity/tools/setup-ab-eval")
DATA=pathlib.Path("/home/marius/work/claude/setup-ab-data/fresh-tasks")
OUT=pathlib.Path("/home/marius/work/claude/codescout/docs/research/data/2026-11-06-grader-validity-audit.json")
sys.path.insert(0,str(SOURCE))
import audit_reparse, multilang_grade, multilang_tasks

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    if OUT.exists():raise ValueError("Refuse overwrite")
    protected={str(COHORT/"results.json"):sha(COHORT/"results.json")}
    rows=[]
    for task,effort in json.loads((COHORT/"registration.json").read_text())["repair_order"]:
        out=COHORT/(task+"--"+effort)
        old=json.loads((out/"private-grade.json").read_text())
        bundlepath=DATA/task/"bundle.json";bundle=json.loads(bundlepath.read_text())
        recordpath=pathlib.Path(bundle["record_path"]);record=json.loads(recordpath.read_text())
        logpath=pathlib.Path(old["log"])
        for path in (logpath,out/"private-grade.json",out/"candidate.patch",bundlepath,recordpath):
            protected[str(path)]=sha(path)
        f2p,p2p=multilang_tasks.expected_sets(record,bundle)
        raw=logpath.read_text();audit=audit_reparse.reparse(record,raw,f2p,p2p)
        for key,value in audit["original"].items():
            if old[key]!=value:raise ValueError("Raw verdict mismatch "+task+" "+key)
        statuses=multilang_grade.run_parser(record["log_parser"],raw)
        _,splits=audit_reparse.split_concatenated_status(raw)
        crash=multilang_grade.toolchain_crash(raw)
        rows.append({"task":task,"effort":effort,"log":str(logpath),"log_sha256":sha(logpath),
                     "record_sha256":sha(recordpath),"bundle_sha256":sha(bundlepath),
                     "parsed_status_keys":len(statuses),"split_lines":len(splits),
                     "crash_line":crash,"prospective_zero_status_crash":not statuses and crash is not None,
                     **audit})
    if sum(r["split_lines"] for r in rows)!=1:raise ValueError("Unexpected split population")
    if sum(len(r["recovered"]) for r in rows)!=1:raise ValueError("Unexpected recovery population")
    if sum(r["prospective_zero_status_crash"] for r in rows)!=1:raise ValueError("Unexpected crash population")
    for path,expected in protected.items():
        if sha(pathlib.Path(path))!=expected:raise ValueError("Protected evidence changed")
    receipt={"scope":"Audit only; frozen results/logs/parser bytes unchanged; not prospective live parser qualification.",
             "rows":rows,"protected_files_before_after":protected,
             "analysis_source_sha256":{str(p):sha(p) for p in (SOURCE/"audit_reparse.py",SOURCE/"multilang_grade.py",SOURCE/"multilang_tasks.py")},
             "old_cohort_verdicts_overwritten":False,"model_provider_calls":0,"native_regrades":0,
             "existing_nulow_diagnostic":"Already closed @bg_000000f7, 2F2P fail/8620P2P pass/missing0; not repeated."}
    OUT.write_text(json.dumps(receipt,indent=2)+"\n")
    print(json.dumps({"artifact":str(OUT),"sha256":sha(OUT),"protected_unique_files":len(protected),
                      "rows":[{k:r[k] for k in ("task","effort","parsed_status_keys","split_lines","prospective_zero_status_crash","original","adjusted","recovered")} for r in rows]},indent=2))
if __name__=="__main__":main()
