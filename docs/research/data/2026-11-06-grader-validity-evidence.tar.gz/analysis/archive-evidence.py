"""Preserve source/review/fix evidence; reopen every payload. No models or native tasks."""
import hashlib, io, json, pathlib, subprocess, tarfile
MAIN=pathlib.Path("/home/marius/work/claude/codescout")
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/grader-validity-20261106")
REVIEW=pathlib.Path("/tmp/grader-validity-review-20261106")
OUT=MAIN/"docs/research/data/2026-11-06-grader-validity-evidence.tar.gz"

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    if OUT.exists() or OUT.with_suffix(".json").exists():raise ValueError("Refuse overwrite")
    commit=json.loads((ROOT/"commit-verification.json").read_text())
    wt=pathlib.Path(commit["worktree"])
    if subprocess.check_output(["git","-C",str(wt),"rev-parse","HEAD"]).decode().strip()!=commit["commit"]:raise ValueError("HEAD drift")
    if subprocess.check_output(["git","-C",str(wt),"status","--porcelain"]):raise ValueError("Worktree drift")
    for name,expected in commit["committed_input_hashes_match_all_eight"].items():
        if sha(pathlib.Path(name))!=expected:raise ValueError("Source drift")
    gate=json.loads((ROOT/"gate-final.json").read_text())
    if gate["state"]!="exited" or gate["exit_code"]!=0:raise ValueError("Gate not green")
    mutations=json.loads((ROOT/"fix-mutation-results.json").read_text())
    if (mutations["original_literals_applied"],mutations["applied_cases"],mutations["killed"],mutations["survived"])!=(11,12,11,1):raise ValueError("Unexpected mutations")
    if [r["id"] for r in mutations["results"] if r.get("observed")=="survived"]!=["M04"]:raise ValueError("Unexpected survivor")
    inert=json.loads((ROOT/"m04-inertness.json").read_text())
    if [r["exit_code"] for r in inert["rows"]]!=[0,0,0,1]:raise ValueError("Inertness unproven")
    paths=[MAIN/("docs/research/data/2026-11-06-grader-validity-audit"+suffix+".json") for suffix in ("","-v2")]
    first,last=[json.loads(p.read_text()) for p in paths]
    if sha(paths[0])!="2221fee48b54ee56e0040be7bbd4676f802494747c6ad41b4b72af6bf70657b4":raise ValueError("Original audit rewritten")
    if first["rows"]!=last["rows"] or first["protected_files_before_after"]!=last["protected_files_before_after"]:raise ValueError("Audit calibration changed")
    for name,expected in last["protected_files_before_after"].items():
        if sha(pathlib.Path(name))!=expected:raise ValueError("Historical input drift")
    review=json.loads((REVIEW/"evidence-manifest.json").read_text())
    for name,expected in review["files"].items():
        if sha(REVIEW/name)!=expected:raise ValueError("Review evidence drift")
    payload={}
    for prefix,root in (("analysis",ROOT),("review",REVIEW)):
        for path in sorted(root.rglob("*")):
            if path.is_dir() or "__pycache__" in path.parts or path.name=="peer-enumeration-before-commit.txt":continue
            if path.is_symlink() or not path.is_file():raise ValueError("Unexpected artifact type")
            payload[prefix+"/"+str(path.relative_to(root))]=path
    for path in paths:payload["audits/"+path.name]=path
    for name in commit["committed_input_hashes_match_all_eight"]:
        path=pathlib.Path(name);payload["final/"+str(path.relative_to(wt))]=path
    payload["plan.md"]=MAIN/"docs/superpowers/plans/2026-11-06-grader-validity-classification.md"
    for path in (MAIN/"docs/issues").glob("2026-11-06-*.md"):
        if any(t in path.name for t in ("private-grader-linker-crash","rust-grader-parser-misses","toolchain-classifier-source","audit-reparse-cumulative","audit-tests-miss-p2p")):
            payload["issues/"+path.name]=path
    manifest={"unit":"payload file records, excluding manifest","records":[{"name":n,"source":str(p),"bytes":p.stat().st_size,"sha256":sha(p)} for n,p in sorted(payload.items())],"scope":{"source_commit":commit["commit"],"patch_id":commit["patch_id"],"protected_unique_files":len(last["protected_files_before_after"]),"review_manifest_payloads_rehashed":len(review["files"]),"provider_calls":0,"native_regrades":0,"prospective_live_admission":False}}
    with tarfile.open(OUT,"w:gz") as tar:
        for row in manifest["records"]:tar.add(payload[row["name"]],arcname=row["name"],recursive=False)
        raw=(json.dumps(manifest,indent=2)+"\n").encode();entry=tarfile.TarInfo("manifest.json");entry.size=len(raw);tar.addfile(entry,io.BytesIO(raw))
    with tarfile.open(OUT,"r:gz") as tar:
        if len(tar.getmembers())!=len(payload)+1:raise ValueError("Archive population mismatch")
        for row in manifest["records"]:
            raw=tar.extractfile(row["name"]).read()
            if len(raw)!=row["bytes"] or hashlib.sha256(raw).hexdigest()!=row["sha256"]:raise ValueError("Archive verification failed")
    receipt={"archive":str(OUT),"sha256":sha(OUT),"bytes":OUT.stat().st_size,"payload_files":len(payload),"manifest_files":1,"all_payloads_reopened_verified":True,**manifest["scope"]}
    OUT.with_suffix(".json").write_text(json.dumps(receipt,indent=2)+"\n");print(json.dumps(receipt,indent=2))
if __name__=="__main__":main()
