# Review rulings and bounded fix pass — 2026-11-06

R1 b1e1f89b7d587cb8 accepted after reading actualsource/edge output: plain compiler source text cannot be evidence of a process fatal signal. Added four signal-phrase source excerpts and actual live-grader boundary negative control. Observed6 failing assertion/subtest outcomes across this and R2 before sourcefix. Anchored actual collect2/toolchain, rustc process exit and standalone shell signal signatures. No causal attribution. Error wording now says no parsed test statuses: the instrument measures parser outputs, not whether a test executed.

R2 73efe0aa746d30f9 accepted: cumulative original-vs-transformed prefixes attributed context-only earlier changes to an unrelated split. Current split compares against same prefix with earlier splits already applied and demands exact current status identity. Downstream ordinary status remains missing rather than falsely attributed/recovered.

R3/R4 77828ecdbae3b8c2 accepted: actual reviewer mutants M06,M07,M09,M10 survived220tests/79subtests. Added P2P recovery, alternate unchanged last-observation-wins parser to exercise audit's own failure guard, direct terminal-suffix and ANSI-only-prefix byte/metadata assertions. Actual same mutants must be reapplied, not a coverage argument.

Initial review12 applied8killed4survived. Postfix wholechanged227tests/85subtestsPASS. Reapplication pending. Original literal M02 necessarily disappears because error observation text changed: report un-applied original and explicitly re-site same empty-error mutation as M02-v2, never count absent literal as killed. Original review manifest/population untouched. Anchored classification may render M04 test-name exclusion observationally redundant; if it survives, prove this on the same targeted test with original-vs-fixed regex and rule on inertness rather than invent coverage.

D1 accepted scope limit: signal signature establishes termination text, not disk/RAM/LLVM/candidate cause. Existing historicalreplayclosed; do not repeat it or claim cause.
D2 accepted: retrospective audit does not admit a future live oracle/cohort. New exact source registration/prospective policy plus fresh2taskempty/gold/repeatcontrols remain before paid entry.
D3 accepted: text alone cannot authenticate producer of byte-identical expected stdout. Exact key/line checks bound transformation; do not advertise oracle authenticity/adversarial security. Prospective policy must explicitly address ambiguity.
D4 accepted: documented Rustsuffixdialect only; no broaderlanguage claim, no nativeactor/model/provider/regrade in thisfix. Qualify actual native behavior under subsequent registeredcontrols.
D5 accepted: fullgate127 green within printed exclusions only (heavyPython/server-stack/localONNX/librarianlean). Finalgate12a pending afteronefixpass. No unrelated infrastructure expansion.

One fresh wholebranchreview complete, no secondreviewcycle planned. No oldcohort/record/log/results altered. Auditv1 SHA2221fee48b54ee56e0040be7bbd4676f802494747c6ad41b4b72af6bf70657b4 preserved; finalcode recalibration will be separatelyversioned, never overwritten. Bounded fix does not establish the scientific effort-steering effect.

## Observed closure

Final source commit a2ffc143266c5e828afd7d8ef2ceb665318df49f onfix/grader-validity-20261106, stablepatch-id6d3afca0f9ca24e2ccc9032c5aea79f418b64b7c; all8committed source/test/fixture hashes match verified input, worktreeclean. Not merged/pushed.

Finalgate12aCLOSED0, FMT/CLIPPY/LEAN/DEFAULT/Python0. Pythonlight1642tests529subtests is its own scope; targeted227tests85subtests separately covers allfourchangedsetup-ab modules, which are not named in gate'sPythonlightlog. Never add these as a grandtotal. Exclusions remain.

Reapplication11 originalfrozenliterals actuallyapplied; oldM02literal absent because errorwording corrected, explicitlyresitedM02-v2applied;12 appliedcases,11killed/1survivedM04. Allfour originalauditsurvivorsM06/M07/M09/M10killed. M04inertness actuallyverified infourcells ontestedoverlap: fixedregexguardPASS/no-guardPASS, originalbroadregexguardPASS/no-guardFAIL. No newtestcould demonstrate independentprotectionwhere currentanchoredregexalreadyexcludestestnames; recordredundancyinstead ofclaim12kills. Keeping the explicit guard is a cheap defensive condition, not independently evidenced coverage. No further fix/review loop.

Finalsourceauditv2 identical4rows/17protectedhashes to preservedv1. Original dataset/live gluedparser defect0a2929ec2a4f688f remainsMITIGATED, notfixed: retrospectivehelper qualified but no prospective livepolicy yet. Originaltoolchainclassification54fe4b112aa4e423 andthree actualreviewissuesfixed. No furtherNUlowdiagnostic, nativeactor/model/providercall inthisstep.
