"""Five predeclared focused development controls; no model, credentials, private oracle or source cohort writes."""
import datetime
import hashlib
import json
import os
import pathlib
import re
import shutil
import subprocess
import threading
import time

BASE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
ROOT=BASE/"semantic-contract-probe-20261106"
OLD=BASE/"external-matched-repairs-20261105"
NU="nushell__nushell-18863"
CASE="last_result::failed_line_does_not_replace_last"
COMMAND=["cargo","test","--offline","-p","nu-cli","--test","tests",CASE,"--","--exact"]
NAME="cs-contract-probe-01a15ca9-nu"
def save(path,value):
    path.write_text(json.dumps(value,indent=2)+"\n")
def run(argv,**kwargs):
    return subprocess.run(argv,capture_output=True,**kwargs)
def sha(data):
    return hashlib.sha256(data).hexdigest()
def section(patch,path):
    chunks=re.split(r"(?=^diff --git )",patch,flags=re.M)
    selected=[c for c in chunks if c.startswith("diff --git a/"+path+" b/"+path+"\n")]
    assert len(selected)==1,path
    return selected[0]

assert not (ROOT/"registration.json").exists(),"Existing probe must be reconciled, never reset"
assert shutil.disk_usage(BASE).free>=80*1024**3
cfg=json.loads((OLD/(NU+"--low")/"prepared.json").read_text())
low_path=OLD/(NU+"--low")/"candidate.patch"
high_path=OLD/(NU+"--xhigh")/"candidate.patch"
for path in [low_path,high_path]:
    capture=json.loads((path.parent/"candidate-capture.json").read_text())
    assert sha(path.read_bytes())==capture["sha256"]
low=low_path.read_text()
high=high_path.read_text()
test_path="crates/nu-cli/tests/last_result.rs"
prod_path="crates/nu-cli/src/util.rs"
weak=section(low,test_path)
lowprod=section(low,prod_path)
highprod=section(high,prod_path)
weak_body='''fn failed_line_does_not_replace_last() -> Result {
    let mut session = Interactive::new();
    session.run("ls");
    // A type error on `$ans.last` yields an error value; it must not become `$ans.last`.
    session.run("$ans.last | str length");
    let last = session.last_payload()?;
    assert!(
        matches!(last, Value::List { .. }),
        "expected previous list in last after failed line, got {last:?}"
    );
    Ok(())
}'''
strong_body='''fn failed_line_does_not_replace_last() -> Result {
    let mut session = Interactive::new();
    session.run("ls");
    let expected = session.last_payload()?;
    session.run("$ans.last | str length");
    assert_eq!(session.last_payload()?, expected);
    Ok(())
}'''
phases=[
    {"id":"low-production-weak-assertion","expected_exit":0,"expected_passed":1,"expected_failed":0},
    {"id":"baseline-production-weak-assertion","expected_exit":0,"expected_passed":1,"expected_failed":0},
    {"id":"baseline-production-strong-assertion","expected_exit":101,"expected_passed":0,"expected_failed":1},
    {"id":"low-production-strong-assertion","expected_exit":101,"expected_passed":0,"expected_failed":1},
    {"id":"xhigh-production-strong-assertion","expected_exit":0,"expected_passed":1,"expected_failed":0},
]
save(ROOT/"registration.json",{
    "utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"provider_calls":0,
    "purpose":"Actual same-image test-assertion discrimination controls on an exposed development case; not a new repair attempt or hidden-oracle grade",
    "image":cfg["image"],"baseline_commit":cfg["baseline_commit"],"command":COMMAND,"phases":phases,
    "low_candidate_sha256":sha(low_path.read_bytes()),"xhigh_candidate_sha256":sha(high_path.read_bytes()),
    "weak_test_patch_sha256":sha(weak.encode()),"low_prod_patch_sha256":sha(lowprod.encode()),"xhigh_prod_patch_sha256":sha(highprod.encode()),
    "strong_test_body_sha256":sha(strong_body.encode()),"source_cohort_read_only":True,
    "disk_preflight_available_bytes":shutil.disk_usage(BASE).free,
    "resources":{"cpus":4,"memory_gib":32,"tmpfs_gib":4,"exec":True},
})
(ROOT/"weak-test.patch").write_text(weak)
(ROOT/"low-production.patch").write_text(lowprod)
(ROOT/"xhigh-production.patch").write_text(highprod)
(ROOT/"strong-test-body.rs").write_text(strong_body)
stop=threading.Event()
cid=None
rows=[]
def monitor():
    while not stop.wait(10):
        row={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"host_root_available_bytes":shutil.disk_usage(BASE).free}
        if cid:
            p=run(["docker","exec",cid,"python3","-c","import json,os,pathlib;s=os.statvfs('/tmp');print(json.dumps({'tmp_available_bytes':s.f_bavail*s.f_frsize,'memory_events':pathlib.Path('/sys/fs/cgroup/memory.events').read_text(),'memory_peak':pathlib.Path('/sys/fs/cgroup/memory.peak').read_text()}))"],timeout=10)
            row["probe_exit_code"]=p.returncode
            if p.returncode==0:row["container"]=json.loads(p.stdout)
        with (ROOT/"resources.jsonl").open("a") as f:f.write(json.dumps(row)+"\n")
        if row["host_root_available_bytes"]<40*1024**3 and cid:
            save(ROOT/"resource-abort.json",row)
            run(["docker","stop","--time","3",cid],timeout=15)
            return

def apply(text,reverse=False):
    argv=["docker","exec","-i",cid,"git","-C","/testbed","apply"]
    if reverse:argv.append("-R")
    p=run(argv,input=text.encode(),timeout=20)
    assert p.returncode==0,p.stderr.decode(errors="replace")

def check(index):
    phase=phases[index]
    start=time.monotonic()
    p=run(["docker","exec","-w","/testbed",cid,*COMMAND],timeout=1800)
    data=p.stdout+p.stderr
    (ROOT/(str(index)+"-"+phase["id"]+".log")).write_bytes(data)
    text=data.decode(errors="replace")
    summaries=re.findall(r"test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;",text)
    row={**phase,"exit_code":p.returncode,"wall_s":time.monotonic()-start,"log_sha256":sha(data),"test_summaries":summaries}
    rows.append(row);save(ROOT/"progress.json",rows)
    print(json.dumps(row),flush=True)
    assert p.returncode==phase["expected_exit"],"Unexpected focused-check exit; preserve and investigate"
    assert len(summaries)==1 and tuple(map(int,summaries[0]))==(phase["expected_passed"],phase["expected_failed"]),"Expected actual one-test outcome absent"
    if phase["expected_failed"]:
        assert "assertion" in text and "left:" in text and "right:" in text,"No observed semantic assertion failure"
    assert not (ROOT/"resource-abort.json").exists()
    diff=run(["docker","exec",cid,"git","-C","/testbed","diff","--name-only"],timeout=15)
    assert diff.returncode==0
    changed=set(diff.stdout.decode().splitlines())
    assert changed <= {test_path,prod_path},changed
    save(ROOT/(str(index)+"-source-diff.json"),{"changed_paths":sorted(changed)})

thread=threading.Thread(target=monitor,daemon=True)
try:
    launched=run(["docker","run","-d","--name",NAME,"--network","none","--cpus","4","--memory","32g","--memory-swap","32g","--init","--user","1000:1000","--cap-drop","ALL","--security-opt","no-new-privileges","--pids-limit","4096","--tmpfs","/tmp:rw,exec,size=4g,uid=1000,gid=1000","--entrypoint","sleep",cfg["image"],"infinity"],timeout=30)
    assert launched.returncode==0,launched.stderr.decode(errors="replace")
    cid=launched.stdout.decode().strip()
    save(ROOT/"container.json",{"id":cid,"name":NAME})
    head=run(["docker","exec",cid,"git","-C","/testbed","rev-parse","HEAD"],timeout=15)
    assert head.returncode==0 and head.stdout.decode().strip()==cfg["baseline_commit"]
    thread.start()
    apply(weak);apply(lowprod)
    check(0)
    apply(lowprod,reverse=True)
    check(1) # Actual deletion mutation survived before adding the stronger assertion.
    p=run(["docker","exec",cid,"cat","/testbed/"+test_path],timeout=15)
    assert p.returncode==0
    test_source=p.stdout.decode()
    assert test_source.count(weak_body)==1,"Weak test body drift"
    strong_source=test_source.replace(weak_body,strong_body)
    p=run(["docker","exec","-i",cid,"python3","-c","import pathlib,sys;pathlib.Path(sys.argv[1]).write_bytes(sys.stdin.buffer.read())","/testbed/"+test_path],input=strong_source.encode(),timeout=15)
    assert p.returncode==0,p.stderr.decode(errors="replace")
    check(2)
    apply(lowprod);check(3)
    apply(lowprod,reverse=True);apply(highprod);check(4)
    save(ROOT/"results.json",{"provider_calls":0,"phases":rows,"all_predeclared_observations_matched":True,"meaning":"Weak agent test passes even with production correction removed; stronger value assertion rejects baseline and low production but passes xhigh production. Exposed development evidence only."})
finally:
    stop.set()
    if thread.is_alive():thread.join(15)
    if cid:
        p=run(["docker","rm","-f",cid],timeout=60)
        absent=run(["docker","inspect",cid],timeout=15)
        save(ROOT/"cleanup.json",{"id":cid,"remove_exit_code":p.returncode,"independently_absent":absent.returncode!=0 and b"no such" in absent.stderr.lower()})
