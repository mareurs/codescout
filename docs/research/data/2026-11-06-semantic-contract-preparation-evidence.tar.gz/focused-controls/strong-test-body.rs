fn failed_line_does_not_replace_last() -> Result {
    let mut session = Interactive::new();
    session.run("ls");
    let expected = session.last_payload()?;
    session.run("$ans.last | str length");
    assert_eq!(session.last_payload()?, expected);
    Ok(())
}