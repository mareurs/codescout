"""Only the two unexecuted focused controls after an explicitly preserved exit-code instrument error."""
import datetime,hashlib,json,pathlib,re,shutil,subprocess,threading,time
BASE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
PARENT=BASE/"semantic-contract-probe-20261106"
ROOT=PARENT/"remaining-checks"
ROOT.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+"\n")
def run(argv,**kwargs):return subprocess.run(argv,capture_output=True,**kwargs)
reg=json.loads((PARENT/"registration.json").read_text())
prior=json.loads((PARENT/"progress.json").read_text())
assert [r["exit_code"] for r in prior]==[0,0,1]
assert prior[2]["test_summaries"]==[["0","1"]]
assert json.loads((PARENT/"cleanup.json").read_text())["independently_absent"]
assert shutil.disk_usage(BASE).free>=80*1024**3
for filename,key in [("weak-test.patch","weak_test_patch_sha256"),("low-production.patch","low_prod_patch_sha256"),("xhigh-production.patch","xhigh_prod_patch_sha256"),("strong-test-body.rs","strong_test_body_sha256")]:
    assert sha(PARENT/filename)==reg[key]
CASE="last_result::failed_line_does_not_replace_last"
command=reg["command"]
assert CASE in command and "--exact" in command
phases=[{"id":"low-production-strong-assertion","expected_passed":0,"expected_failed":1},{"id":"xhigh-production-strong-assertion","expected_passed":1,"expected_failed":0}]
save(ROOT/"registration.json",{"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"parent_registration_sha256":sha(PARENT/"registration.json"),"parent_progress_sha256":sha(PARENT/"progress.json"),"parent_script_sha256":sha(PARENT/"control.py"),"instrument_correction":"Require actual named test summary/assertion and nonzero semantic failure; exact101 was an invalid assumption. No previous phase rerun.","provider_calls":0,"command":command,"image":reg["image"],"baseline_commit":reg["baseline_commit"],"phases":phases})
cid=None
stop=threading.Event()
rows=[]
def monitor():
    while not stop.wait(10):
        row={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"host_root_available_bytes":shutil.disk_usage(BASE).free}
        if cid:
            p=run(["docker","exec",cid,"python3","-c","import json,os,pathlib;s=os.statvfs('/tmp');print(json.dumps({'tmp_available_bytes':s.f_bavail*s.f_frsize,'memory_events':pathlib.Path('/sys/fs/cgroup/memory.events').read_text(),'memory_peak':pathlib.Path('/sys/fs/cgroup/memory.peak').read_text()}))"],timeout=10)
            row["probe_exit_code"]=p.returncode
            if p.returncode==0:row["container"]=json.loads(p.stdout)
        with (ROOT/"resources.jsonl").open("a") as f:f.write(json.dumps(row)+"\n")
        if row["host_root_available_bytes"]<40*1024**3 and cid:
            save(ROOT/"resource-abort.json",row)
            run(["docker","stop","--time","3",cid],timeout=15)
            return
def apply(filename,reverse=False):
    argv=["docker","exec","-i",cid,"git","-C","/testbed","apply"]+(["-R"] if reverse else [])
    p=run(argv,input=(PARENT/filename).read_bytes(),timeout=20)
    assert p.returncode==0,p.stderr.decode(errors="replace")
def check(index):
    phase=phases[index];start=time.monotonic()
    p=run(["docker","exec","-w","/testbed",cid,*command],timeout=1800)
    for suffix,data in [("stdout",p.stdout),("stderr",p.stderr)]:
        (ROOT/(str(index)+"-"+phase["id"]+"."+suffix+".log")).write_bytes(data)
    text=(p.stdout+p.stderr).decode(errors="replace")
    summaries=re.findall(r"test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;",text)
    statuses=re.findall(r"^test "+re.escape(CASE)+r" \.\.\. (ok|FAILED)\s*$",text,re.M)
    row={**phase,"exit_code":p.returncode,"wall_s":time.monotonic()-start,"summaries":summaries,"named_statuses":statuses,"stdout_sha256":hashlib.sha256(p.stdout).hexdigest(),"stderr_sha256":hashlib.sha256(p.stderr).hexdigest()}
    rows.append(row);save(ROOT/"progress.json",rows);print(json.dumps(row),flush=True)
    assert len(summaries)==1 and tuple(map(int,summaries[0]))==(phase["expected_passed"],phase["expected_failed"])
    assert statuses==(["FAILED"] if phase["expected_failed"] else ["ok"])
    assert (p.returncode!=0) if phase["expected_failed"] else (p.returncode==0)
    if phase["expected_failed"]:assert "assertion" in text and "left:" in text and "right:" in text
    assert not (ROOT/"resource-abort.json").exists()
    diff=run(["docker","exec",cid,"git","-C","/testbed","diff","--name-only"],timeout=15)
    assert diff.returncode==0 and set(diff.stdout.decode().splitlines())<={"crates/nu-cli/src/util.rs","crates/nu-cli/tests/last_result.rs"}
    save(ROOT/(str(index)+"-source-diff.json"),{"changed_paths":diff.stdout.decode().splitlines()})
thread=threading.Thread(target=monitor,daemon=True)
try:
    p=run(["docker","run","-d","--name","cs-contract-remaining-01a15ca9-nu","--network","none","--cpus","4","--memory","32g","--memory-swap","32g","--init","--user","1000:1000","--cap-drop","ALL","--security-opt","no-new-privileges","--pids-limit","4096","--tmpfs","/tmp:rw,exec,size=4g,uid=1000,gid=1000","--entrypoint","sleep",reg["image"],"infinity"],timeout=30)
    assert p.returncode==0,p.stderr.decode(errors="replace")
    cid=p.stdout.decode().strip();save(ROOT/"container.json",{"id":cid})
    head=run(["docker","exec",cid,"git","-C","/testbed","rev-parse","HEAD"],timeout=15)
    assert head.returncode==0 and head.stdout.decode().strip()==reg["baseline_commit"]
    thread.start()
    apply("weak-test.patch");apply("low-production.patch")
    path="/testbed/crates/nu-cli/tests/last_result.rs"
    p=run(["docker","exec",cid,"cat",path],timeout=15);assert p.returncode==0
    source=p.stdout.decode()
    begin=source.index("fn failed_line_does_not_replace_last() -> Result {")
    end=source.index("\n}\n",begin)+2
    strong=(PARENT/"strong-test-body.rs").read_text()
    source=source[:begin]+strong+source[end:]
    p=run(["docker","exec","-i",cid,"python3","-c","import pathlib,sys;pathlib.Path(sys.argv[1]).write_bytes(sys.stdin.buffer.read())",path],input=source.encode(),timeout=15)
    assert p.returncode==0
    check(0)
    apply("low-production.patch",reverse=True);apply("xhigh-production.patch");check(1)
    save(ROOT/"results.json",{"provider_calls":0,"phases":rows,"all_predeclared_observations_matched":True,"parent_first_three_observations_preserved":True,"parent_registration_unchanged":sha(PARENT/"registration.json")==json.loads((ROOT/"registration.json").read_text())["parent_registration_sha256"]})
finally:
    stop.set()
    if thread.is_alive():thread.join(15)
    if cid:
        p=run(["docker","rm","-f",cid],timeout=60)
        absent=run(["docker","inspect",cid],timeout=15)
        save(ROOT/"cleanup.json",{"id":cid,"remove_exit_code":p.returncode,"independently_absent":absent.returncode!=0 and b"no such" in absent.stderr.lower()})
