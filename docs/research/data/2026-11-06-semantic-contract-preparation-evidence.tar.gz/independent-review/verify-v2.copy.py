"""Read-only input validation controls. Imports verifier without calling freeze."""
import copy
import hashlib
import importlib.util
import json
import pathlib
import sys
from decimal import Decimal

ROOT=pathlib.Path(__file__).resolve().parent
def run(verifier_path=None):
    spec=importlib.util.spec_from_file_location("frozen_verifier",verifier_path or ROOT/"freeze-prompts.py")
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    reg=json.loads((ROOT/"prompt-inputs-registration.json").read_text())
    rows=json.loads((ROOT/"matrix.json").read_text())["arms"]
    observed={"baseline":mod.verify(reg,rows),"negative_controls":[]}
    def reject(name,change,expected):
        r,a,o=copy.deepcopy(reg),copy.deepcopy(rows),{}
        change(r,a,o)
        try:
            mod.verify(r,a,o)
        except ValueError as exc:
            reason=str(exc)
            if reason!=expected:raise AssertionError((name,"wrong rejection",reason,expected))
            observed["negative_controls"].append({"name":name,"rejected":True,"reason":reason})
        else:raise AssertionError((name,"accepted"))
    def arm(field,value):
        return lambda r,a,o:a[0].__setitem__(field,value)
    def registration(field,value):
        return lambda r,a,o:r.__setitem__(field,value)
    def budget(field,value,recompute=False):
        def change(r,a,o):
            r["budget"][field]=value
            if recompute:
                r["budget"]["worst_reserved_series_usd"]=str(Decimal(r["budget"]["known_prior_usd"])+6*Decimal(r["budget"]["reserve_usd_each"]))
        return change
    reject("duplicate-id",lambda r,a,o:a[1].__setitem__("arm_id",a[0]["arm_id"]),"variant population")
    reject("unique-wrong-id",arm("arm_id","unique-wrong-id"),"arm identity")
    reject("wrong-effort",arm("effort","xhigh"),"real effort differs from variant")
    def prompt_change(treatment):
        def change(r,a,o):
            row=next(x for x in a if (x["variant"]=="low-contract")==treatment)
            base=(ROOT/"shared"/row["task"]/"base-prompt.txt").read_bytes()
            protocol=(ROOT/"protocol.txt").read_bytes()
            data=base if treatment else base+mod.SEPARATOR.encode()+protocol
            o[row["prompt"]]=data
            row["prompt_sha256"]=hashlib.sha256(data).hexdigest()
        return change
    reject("removed-protocol-resigned",prompt_change(True),"treatment prompt delta")
    reject("contaminated-control-resigned",prompt_change(False),"treatment prompt delta")
    task=rows[0]["task"]
    reject("global-rules",lambda r,a,o:o.__setitem__(str(ROOT/"shared"/task/"global-CLAUDE.md"),b"drift"),"common rules drift")
    reject("common-prompt",lambda r,a,o:o.__setitem__(str(ROOT/"shared"/task/"base-prompt.txt"),b"drift"),"common prompt drift")
    reject("project-rules",lambda r,a,o:o.__setitem__(str(ROOT/"shared"/task/"CLAUDE.md"),b"drift"),"project rules drift")
    reject("image",arm("image","wrong-image"),"source identity")
    reject("baseline",arm("baseline_commit","wrong-source"),"source identity")
    reject("runtime",arm("input_identity","wrong-runtime"),"shared inputs")
    reject("public-checks",arm("public_checks",[]),"shared inputs")
    reject("arm-stage",arm("stage","paid-ready"),"arm launch state")
    reject("arm-launch",arm("launch_admitted",True),"arm launch state")
    reject("registration-stage",registration("stage","paid-ready"),"registration stage")
    reject("registration-launch",registration("launch_admitted",True),"launch state")
    reject("budget-arithmetic",budget("worst_reserved_series_usd","1"),"budget")
    reject("budget-ceiling",budget("series_ceiling_usd","100"),"budget")
    for value in ("0","-1","21"):
        reject("cli-cap-"+value,budget("cli_cap_usd_each",value),"budget bounds")
    for value in ("0","-1"):
        reject("reserve-"+value,budget("reserve_usd_each",value,True),"budget bounds")
    reject("negative-prior",budget("known_prior_usd","-1"),"budget bounds")
    for field in ("known_prior_usd","reserve_usd_each","cli_cap_usd_each","worst_reserved_series_usd","series_ceiling_usd"):
        for value in ("NaN","Infinity","-Infinity"):
            reject("finite-"+field+"-"+value,budget(field,value),"finite budget")
    observed["verifier_sha256"]=hashlib.sha256(pathlib.Path(verifier_path or ROOT/"freeze-prompts.py").read_bytes()).hexdigest()
    return observed

if __name__=="__main__":
    result=run(sys.argv[1] if len(sys.argv)>1 else None)
    print(json.dumps(result,indent=2))
