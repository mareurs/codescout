"""Freeze prompt/input-only development artifacts; no launch, credential or provider code."""
import copy,datetime,hashlib,json,pathlib,re
from decimal import Decimal

BASE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
OLD=BASE/"external-matched-repairs-20261105"
ROOT=BASE/"semantic-contract-pilot-20261106"
SPEC=pathlib.Path("/home/marius/work/claude/codescout/docs/superpowers/specs/2026-11-06-semantic-contract-pilot-design.md")
TASKS=["nushell__nushell-18863","rust-lang__rust-analyzer-22992"]
ORDER=[(TASKS[0],"low-control"),(TASKS[1],"xhigh-control"),(TASKS[0],"low-contract"),(TASKS[1],"low-control"),(TASKS[0],"xhigh-control"),(TASKS[1],"low-contract")]
SEPARATOR="\n\nAdditional behavioral-contract protocol:\n"
def digest(data):return hashlib.sha256(data).hexdigest()
def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2)+"\n")
def freeze():
    assert not (ROOT/"prompt-inputs-registration.json").exists(),"Existing bundle must not be silently overwritten"
    design=SPEC.read_text()
    blocks=re.findall(r"\x60\x60\x60text\n(.*?)\n\x60\x60\x60",design,re.S)
    assert len(blocks)==1
    protocol=(blocks[0]+"\n").encode()
    assert not any(task.encode() in protocol for task in TASKS)
    (ROOT/"protocol.txt").write_bytes(protocol)
    projects={}
    protected={}
    for task in TASKS:
        low=json.loads((OLD/(task+"--low")/"prepared.json").read_text())
        high=json.loads((OLD/(task+"--xhigh")/"prepared.json").read_text())
        assert low["prompt"]==high["prompt"],"Original common task prompts differ"
        assert low["image"]==high["image"] and low["baseline_commit"]==high["baseline_commit"]
        shared=ROOT/"shared"/task
        shared.mkdir(parents=True)
        prompt=low["prompt"].encode()
        (shared/"base-prompt.txt").write_bytes(prompt)
        rules=(OLD/(task+"--low")/"client-home/.claude/CLAUDE.md").read_bytes()
        assert digest(rules)==low["files"][low["global_rules"]]
        assert rules==(OLD/(task+"--xhigh")/"client-home/.claude/CLAUDE.md").read_bytes()
        (shared/"global-CLAUDE.md").write_bytes(rules)
        snapshot=BASE/"external-runtime-snapshots-20261105"/task
        manifest=json.loads((snapshot/"manifest.json").read_text())
        assert manifest["image"]==low["image"] and manifest["actor_baseline"]==low["baseline_commit"]
        observed=[]
        for rel,proof in manifest["files"].items():
            relpath=pathlib.PurePosixPath(rel)
            assert not relpath.is_absolute() and ".." not in relpath.parts
            path=snapshot/rel
            assert path.is_file() and digest(path.read_bytes())==proof["sha256"],rel
            observed.append(rel)
        for name in ["CLAUDE.md","AGENTS.md"]:
            data=(snapshot/"instructions"/name).read_bytes()
            original=pathlib.Path(low["actor"])/name
            assert digest(data)==low["files"][str(original)]
            (shared/name).write_bytes(data)
        public_checks=low["checks"]
        assert public_checks==high["checks"]
        projects[task]={
            "image":low["image"],"baseline_commit":low["baseline_commit"],
            "base_prompt_sha256":digest(prompt),"global_rules_sha256":digest(rules),
            "project_rules_sha256":{name:digest((shared/name).read_bytes()) for name in ["CLAUDE.md","AGENTS.md"]},
            "runtime_snapshot_manifest":str(snapshot/"manifest.json"),
            "runtime_snapshot_manifest_sha256":digest((snapshot/"manifest.json").read_bytes()),
            "logical_snapshot_id":manifest["logical_snapshot_id"],"runtime_snapshot_id":manifest["snapshot_id"],
            "selected_runtime_payload_hashes_verified":len(observed),
            "cli":low["cli"],"cli_sha256":low["files"][low["cli"]],"plugin":low["plugin"],
            "checks":public_checks,
        }
        for effort in ["low","xhigh"]:
            for name in ["prepared.json","candidate.patch","candidate-capture.json","private-grade.json","receipt.json","cost-reconciled.json"]:
                path=OLD/(task+"--"+effort)/name
                protected[str(path)]=digest(path.read_bytes())
    original=json.loads((OLD/"results.json").read_text())
    prior=Decimal(original["known_series_subtotal_usd"])
    ceiling=Decimal("200");reserve=Decimal("20");cli_cap=Decimal("19")
    assert prior==Decimal("58.180531399999999104")
    assert prior+len(ORDER)*reserve<=ceiling
    rows=[]
    for task,variant in ORDER:
        arm=task+"--"+variant
        out=ROOT/"arms"/arm
        out.mkdir(parents=True)
        common=(ROOT/"shared"/task/"base-prompt.txt").read_bytes()
        prompt=common+(SEPARATOR.encode()+protocol if variant=="low-contract" else b"")
        (out/"prompt.txt").write_bytes(prompt)
        item={
            "arm_id":arm,"task":task,"variant":variant,
            "effort":"xhigh" if variant=="xhigh-control" else "low",
            "prompt":str(out/"prompt.txt"),"prompt_sha256":digest(prompt),
            "image":projects[task]["image"],"baseline_commit":projects[task]["baseline_commit"],
            "stage":"prompt-inputs-only","launch_admitted":False,
            "public_checks":projects[task]["checks"],"input_identity":projects[task]["runtime_snapshot_id"],
        }
        save(out/"inputs.json",item)
        rows.append(item)
    registration={
        "utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"stage":"prompt-inputs-only","launch_admitted":False,
        "provider_calls":0,"credential_reads":0,"attempts_started":0,"onboarding_calls":0,
        "model":"claude-sonnet-5-5","source_native_fix":"36fec1201b0f809d6f21cc31082def4d651b6cf8",
        "protocol_sha256":digest(protocol),"protocol_words":len(protocol.decode().split()),
        "spec":str(SPEC),"spec_sha256":digest(SPEC.read_bytes()),"order":[list(x) for x in ORDER],"projects":projects,
        "budget":{"known_prior_usd":str(prior),"reserve_usd_each":str(reserve),"cli_cap_usd_each":str(cli_cap),"series_ceiling_usd":str(ceiling),"worst_reserved_series_usd":str(prior+len(rows)*reserve),"new_author_cost_usd":"0","historical_once_only_author_cost_usd":original["author_cost_usd"]},
        "not_created":["prepared.json","native argv","writable database clones","actor CLI contexts","synthetic CLI wire evidence","paid launch/controller admission"],
        "remaining_admission":["committed reviewed grader","prospective qualified parser policy","fresh negative/gold/repeat controls","six isolated native state copies","six-arm actual synthetic CLI wire proof","source-bound controller/grade registration"],
        "protected_original_hashes":protected,
    }
    save(ROOT/"matrix.json",{"arms":rows})
    save(ROOT/"prompt-inputs-registration.json",registration)
    return registration,rows
def verify(registration,rows,prompt_overrides=None):
    override=prompt_overrides or {}
    def content(path):return override.get(str(path),pathlib.Path(path).read_bytes())
    def require(ok,reason):
        if not ok:raise ValueError(reason)
    require(registration["launch_admitted"] is False,"launch state")
    require(len(rows)==6 and len({r["arm_id"] for r in rows})==6,"variant population")
    require([(r["task"],r["variant"]) for r in rows]==[tuple(p) for p in registration["order"]],"frozen order")
    protocol=content(ROOT/"protocol.txt")
    require(digest(protocol)==registration["protocol_sha256"],"protocol drift")
    for task,p in registration["projects"].items():
        require(digest(content(ROOT/"shared"/task/"base-prompt.txt"))==p["base_prompt_sha256"],"common prompt drift")
        require(digest(content(ROOT/"shared"/task/"global-CLAUDE.md"))==p["global_rules_sha256"],"common rules drift")
        for name,d in p["project_rules_sha256"].items():
            require(digest(content(ROOT/"shared"/task/name))==d,"project rules drift")
    for r in rows:
        project=registration["projects"][r["task"]]
        effort="xhigh" if r["variant"]=="xhigh-control" else "low"
        require(r["effort"]==effort,"real effort differs from variant")
        base=content(ROOT/"shared"/r["task"]/"base-prompt.txt")
        expected=base+(SEPARATOR.encode()+protocol if r["variant"]=="low-contract" else b"")
        actual=content(r["prompt"])
        require(actual==expected,"treatment prompt delta")
        require(digest(actual)==r["prompt_sha256"],"prompt hash")
        require(r["launch_admitted"] is False and r["stage"]=="prompt-inputs-only","arm launch state")
        require(r["image"]==project["image"] and r["baseline_commit"]==project["baseline_commit"],"source identity")
        require(r["public_checks"]==project["checks"] and r["input_identity"]==project["runtime_snapshot_id"],"shared inputs")
    budget=registration["budget"]
    pass # REVIEW MUTATION: guard removed
    return {"variants":len(rows),"unique_tasks":len(registration["projects"]),"treatment_arms":sum(r["variant"]=="low-contract" for r in rows),"all_semantic_checks_passed":True,"launch_admitted":False}

if __name__=="__main__":
    registration,rows=freeze()
    baseline=verify(registration,rows)
    mutations=[]
    def rejected(name,mutate):
        r=copy.deepcopy(rows);over={}
        mutate(r,over)
        try:verify(registration,r,over)
        except ValueError as e:
            mutations.append({"mutation":name,"observed":"rejected","reason":str(e)})
        else:raise AssertionError("Mutation survived: "+name)
    rejected("duplicate arm ID",lambda r,o:r[1].update(arm_id=r[0]["arm_id"]))
    rejected("wrong actual effort",lambda r,o:r[0].update(effort="xhigh"))
    def remove_treatment(r,o):
        row=next(x for x in r if x["variant"]=="low-contract")
        data=(ROOT/"shared"/row["task"]/"base-prompt.txt").read_bytes()
        o[row["prompt"]]=data;row["prompt_sha256"]=digest(data)
    rejected("remove treatment and update its local digest",remove_treatment)
    def contaminate_control(r,o):
        row=r[0];data=pathlib.Path(row["prompt"]).read_bytes()+SEPARATOR.encode()+(ROOT/"protocol.txt").read_bytes()
        o[row["prompt"]]=data;row["prompt_sha256"]=digest(data)
    rejected("add protocol to control and update its local digest",contaminate_control)
    task=registration["order"][0][0]
    rejected("change common frozen rules",lambda r,o:o.update({str(ROOT/"shared"/task/"global-CLAUDE.md"):b"changed rules\n"}))
    for name,d in registration["protected_original_hashes"].items():assert digest(pathlib.Path(name).read_bytes())==d,name
    result={**baseline,"mutations":mutations,"observed_mutations_rejected":len(mutations),"original_selected_inputs_unchanged":True,"runtime_payloads_verified":{task:p["selected_runtime_payload_hashes_verified"] for task,p in registration["projects"].items()},"provider_calls":0,"credential_reads":0,"onboarding_calls":0,"budget":registration["budget"]}
    save(ROOT/"verification.json",result)
    print(json.dumps(result,indent=2))
