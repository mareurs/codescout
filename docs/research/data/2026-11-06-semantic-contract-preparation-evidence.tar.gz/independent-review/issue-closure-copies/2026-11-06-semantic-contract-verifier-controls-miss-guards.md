---
id: '51f42e8ae1499528'
kind: bug
status: fixed
title: Semantic-contract verifier controls miss four load-bearing guards
owners:
- marius
tags:
- cluster/guard-narrower-than-its-name
- effort-steering
- semantic-contract
- test-coverage
closed: 2026-11-06
fix_scope: private research helper only; no repository source commit or paid admission
no_fix_commit: Uncommitted private resident-scratch research helper only; exact v1/v2 SHA256, read-only controls and observed guard mutation results are the fix provenance. No product source change or Git commit was authorized.
opened: 2026-11-06
---

# BUG: Semantic-contract verifier controls miss four load-bearing guards

## Summary

The five negative controls in the private prompt freezer reject their intended perturbations but do not detect deletion of four load-bearing verify() guards. This is a regression-coverage gap, not evidence that the current frozen bundle violates those guards.

## Class fit

The successful verification suite covers fewer invariants than the helper's all_semantic_checks_passed result can encourage a reader to assume protected. Unlike a production admission bypass, this instance is a zero-provider private research helper whose present guards still reject the corresponding invalid inputs.

## Symptom (Effect)

Deleting source identity, shared runtime/public-check identity, arm stage, or budget enforcement individually leaves the baseline and all five registered negatives passing. Future removal of any of these protections would be silent to the existing suite.

## Reproduction

Run python3 -B /tmp/semantic-contract-evidence-review-20261106/review_harness.py. It imports only copies, reads the original frozen inputs, calibrates the original helper against the baseline and five negatives, applies eight actual one-guard deletions, and runs the same suite for each. Observed: 4 killed, 4 survived. No production/cohort mutation or provider calls.

## Environment

2026-11-06; source native base/head36fec1201; resident helper /home/marius/.cache/codescout-resident/codescout/semantic-contract-pilot-20261106/freeze-prompts.py.

## Root cause

Five data mutations exercise unique population, effort, treatment/control delta and common rules. None perturbs the source, shared runtime/check identity, stage or budget predicates at freeze-prompts.py:132-136.

## Evidence

Original helper guards: freeze-prompts.py:132-136; mutation-results.json in the review root records removed source line and complete observed suite result for each mutant. mutation.stdout.log:6-9 records four survivors; lines10-13 show original rejects corresponding additional negatives after survivor measurement. Original baseline and five negatives calibrated at mutation.stdout.log:1. Original verification.json:7-33 lists its five controls.

## Hypotheses tried

Actual guard deletion, not a coverage argument. Four other guards were killed by the same calibrated instrument.

## Fix

The private helper's expanded read-only verify-v2.py runner now covers source image/commit, runtime/public checks, arm stage/launch and budget arithmetic/ceiling. Independent copied-helper review recalibrated the real baseline plus39 observed rejected negatives, then actually reapplied all8 original guard removals plus4 new guard removals:12 killed,0 survived. The4 original survivors are now killed. This fixes the measured private-helper coverage gap; it is not runtime/paid admission coverage.

Verified helper SHA256 ed53f792e54866c1bf5053a813a417ed7c4328a2f4622887e30c4f37b7d50780. Originalv1 SHA2565f016d61e2f56723b14a8b81844075b50cf58129640a75c38a40cb9446660a3b retained as freeze-prompts-v1.py and review copies. Historical source-line references in this issue refer to that preservedv1. No repository fix SHA/patch-id exists because this is an uncommitted private research helper, not product code. No issue-file archive move is performed.

## Tests added

Resident verify-v2.py contains39 observed rejecting negative controls plus the real frozen baseline. Independent copies and all12 applied guard mutations, stdout/stderr, v2-baseline.json and v2-mutation-results.json are retained in /tmp/semantic-contract-evidence-review-20261106. v2-mutation.stdout.log:1-14 records actual outcomes. No actor/model/provider test was rerun.

## Workarounds

Independently rehash and validate the present frozen data; do not treat the five-control suite as broad launch-admission coverage. Paid launch remains unadmitted.

## Resume — 2026-11-06

Closed for the measured private-helper scope after independent reapplication:39 negatives rejected,12 selected guard-removal mutations killed,0 survived. Original findings and observedv1 survivors remain retained. Source/native/paid admission remains a separate future gate.

## References

Design28aab59cb5842630; planc1947b8eba0620dd; review root /tmp/semantic-contract-evidence-review-20261106.
