---
id: af727dad8cd9ce91
kind: bug
status: fixed
title: Semantic-contract verifier accepts noncanonical arm identity and registration stage
owners:
- marius
tags:
- cluster/guard-narrower-than-its-name
- effort-steering
- semantic-contract
closed: 2026-11-06
fix_scope: private research helper only; no repository source commit or paid admission
no_fix_commit: Uncommitted private resident-scratch research helper only; exact v1/v2 SHA256, read-only controls and observed guard mutation results are the fix provenance. No product source change or Git commit was authorized.
opened: 2026-11-06
---

# BUG: Semantic-contract verifier accepts noncanonical arm identity and registration stage

## Summary

The prompt/input verifier checks six unique arm_id strings but does not bind them to task+variant, and checks arm stage but omits registration stage. It returns all_semantic_checks_passed for mismatched identity metadata. The current frozen files have correct identities and stage; this is a verifier gap, not an observed corrupted cohort.

## Class fit

The population and stage checks cover a subset of the identity contract: uniqueness without canonical task/variant identity and per-arm stage without registration stage. Unlike older runtime admission bugs, this private helper cannot launch anything and launch_admitted stays false throughout the observed reproductions.

## Symptom (Effect)

Set rows[0]['arm_id']='arbitrary-unique-id' while preserving task, variant and frozen order: verify() accepts. Separately set registration['stage']='paid-ready': verify() accepts and reports launch_admitted=false. A later preparer using these labels could consume inconsistent metadata if it relies only on this verifier.

## Reproduction

python3 -B /tmp/semantic-contract-evidence-review-20261106/review_harness.py. Uses deep copies of real registration/matrix and copied helper; no original writes. mutation.stdout.log:14-15 records both observed accepts.

## Environment

2026-11-06; private /home/marius/.cache/codescout-resident/codescout/semantic-contract-pilot-20261106/freeze-prompts.py.

## Root cause

verify():113 checks registration launch_admitted only; :114 requires row count and unique IDs only; :115 checks task/variant order but never arm_id==task+'--'+variant. :132 checks arm stage but no analogous top-level stage predicate.

## Evidence

freeze-prompts.py:113-115,132; /tmp/semantic-contract-evidence-review-20261106/mutation-results.json additional_negative_controls; mutation.stdout.log:14-15.

## Hypotheses tried

Actually evaluated two independent copied-input corruptions. Both accepted; original five registered negatives all rejected.

## Fix

Private verify() now requires registration stage prompt-inputs-only and arm_id==task+'--'+variant. Expanded runner rejects unique-wrong-id and registration-stage. Independent copied-helper review actually deleted each added guard; both mutants were killed by the corresponding negative now being accepted. The baseline and39 negatives pass unmutated. Launch remains false; no native runtime states or paid controller were created.

Verified helper SHA256 ed53f792e54866c1bf5053a813a417ed7c4328a2f4622887e30c4f37b7d50780. Originalv1 SHA2565f016d61e2f56723b14a8b81844075b50cf58129640a75c38a40cb9446660a3b retained as freeze-prompts-v1.py and review copies. Historical source-line references in this issue refer to that preservedv1. No repository fix SHA/patch-id exists because this is an uncommitted private research helper, not product code. No issue-file archive move is performed.

## Tests added

Resident verify-v2.py contains39 observed rejecting negative controls plus the real frozen baseline. Independent copies and all12 applied guard mutations, stdout/stderr, v2-baseline.json and v2-mutation-results.json are retained in /tmp/semantic-contract-evidence-review-20261106. v2-mutation.stdout.log:1-14 records actual outcomes. No actor/model/provider test was rerun.

## Workarounds

Independently check canonical IDs and stage against the fixed design before native preparation. Current frozen data passes those separate checks.

## Resume — 2026-11-06

Closed for the measured private-helper scope after independent reapplication:39 negatives rejected,12 selected guard-removal mutations killed,0 survived. Original findings and observedv1 survivors remain retained. Source/native/paid admission remains a separate future gate.

## References

Design28aab59cb5842630; planc1947b8eba0620dd; /tmp/semantic-contract-evidence-review-20261106.
