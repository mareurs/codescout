---
id: cd0ad8d33b2aae97
kind: bug
status: fixed
title: Semantic-contract verifier accepts nonpositive caps and reserves
owners:
- marius
tags:
- cluster/guard-narrower-than-its-name
- effort-steering
- semantic-contract
closed: 2026-11-06
fix_scope: private research helper only; no repository source commit or paid admission
no_fix_commit: Uncommitted private resident-scratch research helper only; exact v1/v2 SHA256, read-only controls and observed guard mutation results are the fix provenance. No product source change or Git commit was authorized.
opened: 2026-11-06
---

# BUG: Semantic-contract verifier accepts nonpositive caps and reserves

## Summary

The private prompt/input verifier checks reserve arithmetic but omits the positive CLI cap and reserve relationship. Actual copied-input controls accept CLI caps0,-1,21 with reserve20, and reserves0,-1 when the arithmetic total is recomputed. Current frozen values19/20 and prior58.180531399999999104 remain correct; no paid launch is admitted.

## Class fit

The budget guard covers arithmetic consistency and ceiling but not valid bounded amounts. Unlike resource accounting bugs that miscount actual spend, this research helper accepts invalid trusted configuration metadata while reporting all semantic checks passed.

## Symptom (Effect)

verify() accepts nonpositive CLI caps, a CLI cap larger than the reserved per-attempt allowance, and nonpositive reserves. Downstream preparation cannot treat its result as sufficient evidence that a bounded budget configuration was checked.

## Reproduction

Read-only copied-helper runs are retained in /tmp/semantic-contract-evidence-review-20261106/budget-negative.stdout.log:1-5 and budget-negative-results.json. They load freeze-prompts.original.py, deep-copy the real registration, modify one field and recompute worst_reserved_series_usd only for reserve tests. All five were observed accepted with launch_admitted=false. No source/cohort edits or provider calls.

## Environment

2026-11-06; private semantic-contract-pilot-20261106 helper, native source36fec1201.

## Root cause

freeze-prompts.py:135-136 never reads cli_cap_usd_each and accepts any Decimal reserve whose arithmetic identity fits the ceiling. freeze():73 creates valid constants, but verify() does not guard their configuration invariants.

## Evidence

freeze-prompts.py:73,135-136; review budget-negative.stdout.log:1-5. The current prompt-inputs-registration.json:114-122 records valid19/20 values.

## Hypotheses tried

Five actual negative controls on copied real input; all accepted. This is independent of the previously observed deletion-surviving budget guard coverage gap (51f42e8ae1499528).

## Fix

Private verify() now requires finite prior/reserve/cap/worst/ceiling, nonnegative prior, positive ceiling and0<cap<=reserve. Expanded runner rejects the5 previously accepted cap/reserve cases, negative prior and15 NaN/Infinity/-Infinity cases. Independent review actually removed the finite and bound guards: both mutants killed; bounds removal accepts cli-cap0, finite removal raises Decimal.InvalidOperation instead of the registered finite-budget rejection. Unmodified baseline and39 controls pass. Current fixed19/20 budget remains unchanged.

Verified helper SHA256 ed53f792e54866c1bf5053a813a417ed7c4328a2f4622887e30c4f37b7d50780. Originalv1 SHA2565f016d61e2f56723b14a8b81844075b50cf58129640a75c38a40cb9446660a3b retained as freeze-prompts-v1.py and review copies. Historical source-line references in this issue refer to that preservedv1. No repository fix SHA/patch-id exists because this is an uncommitted private research helper, not product code. No issue-file archive move is performed.

## Tests added

Resident verify-v2.py contains39 observed rejecting negative controls plus the real frozen baseline. Independent copies and all12 applied guard mutations, stdout/stderr, v2-baseline.json and v2-mutation-results.json are retained in /tmp/semantic-contract-evidence-review-20261106. v2-mutation.stdout.log:1-14 records actual outcomes. No actor/model/provider test was rerun.

## Workarounds

Independently validate exact frozen budget values before next native preparation. Paid launch remains unadmitted and no spend occurred here.

## Resume — 2026-11-06

Closed for the measured private-helper scope after independent reapplication:39 negatives rejected,12 selected guard-removal mutations killed,0 survived. Original findings and observedv1 survivors remain retained. Source/native/paid admission remains a separate future gate.

## References

Design28aab59cb5842630; planc1947b8eba0620dd; 51f42e8ae1499528.
