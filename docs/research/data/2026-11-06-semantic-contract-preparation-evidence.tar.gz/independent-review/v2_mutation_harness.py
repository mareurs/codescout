import ast,hashlib,importlib.util,json,pathlib,traceback
OUT=pathlib.Path('/tmp/semantic-contract-evidence-review-20261106')
ROOT=pathlib.Path('/home/marius/.cache/codescout-resident/codescout/semantic-contract-pilot-20261106')
source=(ROOT/'freeze-prompts.py').read_text()
(OUT/'freeze-prompts.v2.py').write_text(source)
runner_source=(ROOT/'verify-v2.py').read_text();(OUT/'verify-v2.copy.py').write_text(runner_source)
spec=importlib.util.spec_from_file_location('copied_v2_runner',OUT/'verify-v2.copy.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
runner.ROOT=ROOT # copied runner reads original frozen inputs; never calls freeze
baseline=runner.run(OUT/'freeze-prompts.v2.py')
print('CALIBRATION '+json.dumps({'baseline':baseline['baseline'],'observed_negative_controls':len(baseline['negative_controls']),'all_rejected':all(x['rejected'] for x in baseline['negative_controls']),'verifier_sha256':baseline['verifier_sha256']}),flush=True)
(OUT/'v2-baseline.json').write_text(json.dumps(baseline,indent=2)+'\n')
guards=[('unique_variant_population','variant population'),('exact_protocol_delta','treatment prompt delta'),('actual_effort','real effort differs from variant'),('common_global_rules','common rules drift'),('source_identity','source identity'),('budget','budget'),('shared_runtime_and_checks','shared inputs'),('arm_stage','arm launch state'),('canonical_arm_identity','arm identity'),('registration_stage','registration stage'),('finite_budget','finite budget'),('budget_bounds','budget bounds')]
observations=[]
for name,reason in guards:
    lines=source.splitlines(keepends=True)
    indices=[i for i,line in enumerate(lines) if 'require(' in line and '"'+reason+'"' in line]
    assert len(indices)==1,(name,indices)
    i=indices[0];removed=lines[i].strip();lines[i]=' '*(len(lines[i])-len(lines[i].lstrip()))+'pass # REVIEW MUTATION: guard removed\n'
    mutated=''.join(lines);ast.parse(mutated)
    path=OUT/('v2-mutant-'+name+'.py');path.write_text(mutated)
    try:result=runner.run(path)
    except Exception as e:row={'name':name,'source_line':i+1,'removed_guard':removed,'observed':'killed','exception_type':type(e).__name__,'exception_message':str(e)}
    else:row={'name':name,'source_line':i+1,'removed_guard':removed,'observed':'survived','negative_controls':len(result['negative_controls'])}
    observations.append(row);print('MUTATION '+json.dumps(row),flush=True)
result={'v2_source_sha256':hashlib.sha256(source.encode()).hexdigest(),'negative_controls_observed':len(baseline['negative_controls']),'mutation_population':len(observations),'killed':sum(x['observed']=='killed' for x in observations),'survived':sum(x['observed']=='survived' for x in observations),'mutations':observations}
# Prove preserved source and frozen old outputs remain unchanged.
original=(OUT/'freeze-prompts.original.py').read_bytes()
assert original==(ROOT/'freeze-prompts-v1.py').read_bytes()==(OUT/'evidence-v1'/ROOT.name/'freeze-prompts.py').read_bytes()
for name in ['verification.json','prompt-inputs-registration.json','matrix.json']:
    assert (ROOT/name).read_bytes()==(OUT/'evidence-v1'/ROOT.name/name).read_bytes(),name
result['v1_source_and_registration_matrix_verification_preserved']=True
(OUT/'v2-mutation-results.json').write_text(json.dumps(result,indent=2)+'\n')
print('COUNTS '+json.dumps({k:result[k] for k in ['negative_controls_observed','mutation_population','killed','survived','v1_source_and_registration_matrix_verification_preserved']}),flush=True)
