import ast,hashlib,json,pathlib,re,datetime,copy,importlib.util
from decimal import Decimal
OUT=pathlib.Path('/tmp/semantic-contract-evidence-review-20261106')
BASE=pathlib.Path('/home/marius/.cache/codescout-resident/codescout')
ROOT=BASE/'semantic-contract-pilot-20261106'
PROBE=BASE/'semantic-contract-probe-20261106'
def sha(data):return hashlib.sha256(data).hexdigest()
def readj(p):return json.loads(p.read_text())
def digest(p):return sha(p.read_bytes())
reg=readj(ROOT/'prompt-inputs-registration.json');rows=readj(ROOT/'matrix.json')['arms']
separator=next(ast.literal_eval(n.value).encode() for n in ast.parse((OUT/'freeze-prompts.original.py').read_text()).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SEPARATOR' for t in n.targets))
spec=pathlib.Path(reg['spec']);design=spec.read_text()
protocol=(re.findall(r'```text\n(.*?)\n```',design,re.S)[0]+'\n').encode()
assert (ROOT/'protocol.txt').read_bytes()==protocol
assert digest(spec)==reg['spec_sha256']
assert len(protocol.decode().split())==reg['protocol_words']==153
assert sha(protocol)==reg['protocol_sha256']
assert reg['stage']=='prompt-inputs-only' and reg['launch_admitted'] is False
assert reg['order']==[[t,v] for t,v in [('nushell__nushell-18863','low-control'),('rust-lang__rust-analyzer-22992','xhigh-control'),('nushell__nushell-18863','low-contract'),('rust-lang__rust-analyzer-22992','low-control'),('nushell__nushell-18863','xhigh-control'),('rust-lang__rust-analyzer-22992','low-contract')]]
assert [(r['task'],r['variant']) for r in rows]==[tuple(x) for x in reg['order']]
assert len(rows)==6 and len({r['arm_id'] for r in rows})==6
old=BASE/'external-matched-repairs-20261105'
projects={}
for task,p in reg['projects'].items():
    low=readj(old/(task+'--low')/'prepared.json');high=readj(old/(task+'--xhigh')/'prepared.json')
    assert low['prompt']==high['prompt']
    assert (ROOT/'shared'/task/'base-prompt.txt').read_bytes()==low['prompt'].encode()
    frozen=(old/(task+'--low')/'client-home/.claude/CLAUDE.md').read_bytes()
    assert frozen==(old/(task+'--xhigh')/'client-home/.claude/CLAUDE.md').read_bytes()
    assert sha(frozen)==low['files'][low['global_rules']]==p['global_rules_sha256']
    assert (ROOT/'shared'/task/'global-CLAUDE.md').read_bytes()==frozen
    assert p['checks']==low['checks']==high['checks']
    assert p['image']==low['image']==high['image']
    assert p['baseline_commit']==low['baseline_commit']==high['baseline_commit']
    manifest_path=pathlib.Path(p['runtime_snapshot_manifest']);manifest=readj(manifest_path)
    assert digest(manifest_path)==p['runtime_snapshot_manifest_sha256']
    assert manifest['image']==p['image'] and manifest['actor_baseline']==p['baseline_commit']
    assert manifest['snapshot_id']==p['runtime_snapshot_id'] and manifest['logical_snapshot_id']==p['logical_snapshot_id']
    count=0;payload_bytes=0
    for rel,proof in manifest['files'].items():
        relpath=pathlib.PurePosixPath(rel)
        assert not relpath.is_absolute() and '..' not in relpath.parts
        path=manifest_path.parent/rel
        assert path.is_file() and digest(path)==proof['sha256'],path
        count+=1;payload_bytes+=path.stat().st_size
    assert count==p['selected_runtime_payload_hashes_verified']
    for name,h in p['project_rules_sha256'].items():
        data=(ROOT/'shared'/task/name).read_bytes()
        assert sha(data)==h==low['files'][str(pathlib.Path(low['actor'])/name)]
        assert data==(manifest_path.parent/'instructions'/name).read_bytes()
    projects[task]={'payload_files_rehashed':count,'payload_bytes_rehashed':payload_bytes,'snapshot_id':manifest['snapshot_id'],'common_rules_match_old_frozen':True}
for r in rows:
    assert r['arm_id']==r['task']+'--'+r['variant']
    assert r['effort']==('xhigh' if r['variant']=='xhigh-control' else 'low')
    assert r['launch_admitted'] is False and r['stage']=='prompt-inputs-only'
    assert readj(pathlib.Path(r['prompt']).parent/'inputs.json')==r
    data=pathlib.Path(r['prompt']).read_bytes();common=(ROOT/'shared'/r['task']/'base-prompt.txt').read_bytes()
    assert data==common+(separator+protocol if r['variant']=='low-contract' else b''),r['arm_id']
    assert sha(data)==r['prompt_sha256']
protected=[]
for p,h in reg['protected_original_hashes'].items():
    assert digest(pathlib.Path(p))==h,p
    protected.append(p)
assert len(protected)==24
budget=reg['budget'];prior=readj(old/'results.json')
assert Decimal(prior['known_series_subtotal_usd'])==Decimal(budget['known_prior_usd'])==Decimal('58.180531399999999104')
assert Decimal(budget['reserve_usd_each'])==20 and Decimal(budget['cli_cap_usd_each'])==19
assert Decimal(budget['known_prior_usd'])+len(rows)*Decimal(budget['reserve_usd_each'])==Decimal(budget['worst_reserved_series_usd'])==Decimal('178.180531399999999104')<=Decimal(budget['series_ceiling_usd'])==200
assert budget['historical_once_only_author_cost_usd']==prior['author_cost_usd']
files=[p for p in ROOT.rglob('*') if p.is_file()]
for forbidden in ['prepared.json','native-argv.json','actor-context.json','wire-proof.json']:
    assert not any(p.name==forbidden for p in files),forbidden
# Five observations: first three raw logs have stdout then stderr, no chronology inference.
registration=readj(PROBE/'registration.json');progress=readj(PROBE/'progress.json')
continuation=PROBE/'remaining-checks';creg=readj(continuation/'registration.json');results=readj(continuation/'results.json')
assert digest(PROBE/'registration.json')==creg['parent_registration_sha256']
assert digest(PROBE/'progress.json')==creg['parent_progress_sha256']
assert digest(PROBE/'control.py')==creg['parent_script_sha256']
assert len(progress)==3 and len(results['phases'])==2
case='last_result::failed_line_does_not_replace_last'
observed=[]
for i,row in enumerate(progress):
    path=PROBE/(str(i)+'-'+row['id']+'.log');data=path.read_bytes()
    assert sha(data)==row['log_sha256']
    text=data.decode(errors='replace')
    statuses=re.findall(r'^test '+re.escape(case)+r' \.\.\. (ok|FAILED)\s*$',text,re.M)
    summaries=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;',text)
    assert len(summaries)==1 and [list(x) for x in summaries]==row['test_summaries']
    want=('ok','1','0') if i<2 else ('FAILED','0','1')
    assert statuses==[want[0]] and summaries==[(want[1],want[2])]
    if i==2: assert 'assertion' in text and 'left:' in text and 'right:' in text
    observed.append({'phase':row['id'],'exit_code':row['exit_code'],'named_statuses':statuses,'summaries':summaries,'source_log':str(path),'assertion_excerpt':next((line[:350] for line in text.splitlines() if 'left:' in line),'')})
for i,row in enumerate(results['phases']):
    streams=[]
    for suffix in ['stdout','stderr']:
        path=continuation/(str(i)+'-'+row['id']+'.'+suffix+'.log');data=path.read_bytes()
        assert sha(data)==row[suffix+'_sha256'];streams.append(data)
    text=b''.join(streams).decode(errors='replace')
    statuses=re.findall(r'^test '+re.escape(case)+r' \.\.\. (ok|FAILED)\s*$',text,re.M)
    summaries=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;',text)
    assert statuses==row['named_statuses']
    assert [list(x) for x in summaries]==row['summaries']
    if i==0:assert row['exit_code']!=0 and statuses==['FAILED'] and summaries==[('0','1')] and 'assertion' in text and 'left:' in text and 'right:' in text
    else:assert row['exit_code']==0 and statuses==['ok'] and summaries==[('1','0')]
    observed.append({'phase':row['id'],'exit_code':row['exit_code'],'named_statuses':statuses,'summaries':summaries,'source_log':str(continuation/(str(i)+'-'+row['id']+'.stdout.log')),'assertion_excerpt':next((line[:350] for line in text.splitlines() if 'left:' in line),'')})
assert [x['phase'] for x in observed]==[x['id'] for x in registration['phases']]
for root in [PROBE,continuation]:
    cleanup=readj(root/'cleanup.json');assert cleanup['remove_exit_code']==0 and cleanup['independently_absent'] is True
    assert cleanup['id']==readj(root/'container.json')['id']
    samples=[json.loads(x) for x in (root/'resources.jsonl').read_text().splitlines()]
    assert samples and not (root/'resource-abort.json').exists()
source_manifest={str(p):digest(p) for p in [*files,*[p for p in PROBE.rglob('*') if p.is_file()]]}
# Preserve byte evidence before parent revises helper; capture all small frozen artifacts and logs.
for source in [ROOT,PROBE]:
    for p in source.rglob('*'):
        if p.is_file():
            target=OUT/'evidence-v1'/source.name/p.relative_to(source)
            target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
report={'protocol_words_whitespace':153,'six_variants_exact':True,'per_arm_inputs_equal_matrix':True,'projects':projects,'protected_old_files_rehashed':len(protected),'budget':budget,'focused_observations':observed,'cleanup_receipts_both_independently_absent':True,'absence_checked_within_bundle':['prepared.json','native-argv.json','actor-context.json','wire-proof.json'],'source_root_file_population':len(files),'all_independent_checks_passed':True,'scope':'Read-only bytes and receipts audit; no Docker/provider/credential calls, no new tests in actors'}
(OUT/'integrity-results.json').write_text(json.dumps(report,indent=2)+'\n')
(OUT/'input-hash-manifest.json').write_text(json.dumps(source_manifest,indent=2)+'\n')
print(json.dumps(report,indent=2))
