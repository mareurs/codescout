# Semantic-contract development evidence review — 2026-11-06

Review status: v1 complete; v2 helper repair and independent reapplication pending. The existing development observations and frozen prompt/input bytes are suitable for archival with the limitations and findings below. Next native preparation should consume a reviewed verifier repair; paid launch is NOT ADMITTED.

## Scope and method

Read MAIN CLAUDE.md first, loaded semantic-contract memory, checked the open/taken/investigating/zombie issue ledger, fetched librarian guidance, and inspected helper functions through CodeScout symbols. Compared actual evidence against MAIN design28aab59cb5842630 and planc1947b8eba0620dd. Product native base/head36fec1201 is not the review object; no success conclusion derives from an empty Git diff.

Review executed only copied Python helper imports, copied guard mutations, read-only validation and rehashing. It did not run Docker, a model/provider/client, credentials, onboarding, actor tests, commits or pushes. The only MAIN writes are the required new issue records. All review scripts/results/copies live under /tmp/semantic-contract-evidence-review-20261106.

Aliases: A=/home/marius/.cache/codescout-resident/codescout/semantic-contract-probe-20261106; B=A/remaining-checks; C=/home/marius/.cache/codescout-resident/codescout/semantic-contract-pilot-20261106. Review copies of all small A/B/C artifacts are in evidence-v1/. input-hash-manifest.json binds the inspected original small files. freeze-prompts.original.py preserves the exact v1 helper independently of later repair.

## Findings

Critical: none observed within this preparation scope.

Important — 51f42e8ae1499528: four load-bearing verifier guards lack coverage in the registered negative suite. Actually removing source identity, shared runtime/public-check identity, arm stage and budget guards one at a time leaves the real baseline and all five registered negatives passing. Four other guard removals were killed. This is a regression-coverage gap; the current original guards reject the corresponding new negatives. Evidence: C/freeze-prompts-v1.py:132-136; mutation.stdout.log:6-9; mutation-results.json. The survivors were measured before recommending or adding any follow-up controls.

Important for future bounded preparation — cd0ad8d33b2aae97: the original verifier accepts CLI caps0,-1,21 with reserve20, and reserves0,-1 when the total is adjusted consistently. It never checks CLI cap, positive reserve or cap<=reserve. Current frozen19/20 values are correct. No paid execution is possible in this phase. Evidence: C/freeze-prompts-v1.py:135-136; budget-negative.stdout.log:1-5; budget-negative-results.json.

Minor at the present nonlaunch stage — af727dad8cd9ce91: a unique arm_id inconsistent with task+'--'+variant is accepted; registration stage='paid-ready' is also accepted although launch_admitted stays false. The actual files have correct IDs/stage. Bind canonical IDs and top-level stage before using this verifier as a downstream preparation contract. Evidence: C/freeze-prompts-v1.py:113-115,132; mutation.stdout.log:14-15.

Known, not duplicated — 32efc4f2deafd517: initial probe expected failed Cargo tests to exit101, while the actual custom focused harness exits1. This stopped the script after three observed tests. The old registration/progress/logs remain intact, and a distinct continuation ran only the remaining two phases using named-status, one-test-summary and assertion checks. Evidence: A/control.py:110-125; A/registration.json:33-45; A/progress.json:33-47; B/registration.json:3-7; B/results.json:3-43. Grader issues54fe4b112aa4e423 and0a2929ec2a4f688f remain outside this review's repair scope.

## Actual mutation measurements

Calibration: original copied verify() accepted the real six-row bundle and rejected all five registered perturbations. The protocol-removal and control-contamination perturbations recomputed their local prompt digests, so hash checks alone could not reject them.

Eight guard deletions were actually applied to individual helper copies and executed against that same calibrated suite:4 killed,4 survived. Killed: unique population, exact protocol delta, actual effort and common global rules. Survived: source identity, budget, shared runtime/check identity and arm stage. See mutation.stdout.log:1-9 and mutation-results.json for each removed source line and observed case result. These counts describe precisely eight selected mutations, not a general coverage score.

After recording those survivors, independent additional data negatives were run against unmodifiedv1. Source/image drift, runtime identity drift, arm-stage drift and a too-small ceiling were rejected. Canonical arm-ID mismatch and top-level stage mismatch were accepted. The separate five invalid budget configurations above were also accepted. No original helper/data was edited by the reviewer.

## Evidence integrity and narrow conclusion

The raw logs independently show exactly one named test per phase:

| Phase | Named status | Summary | Process exit |
|---|---|---|---|
| low production + weak type assertion | ok |1 passed,0 failed|0|
| baseline production + same weak assertion | ok |1 passed,0 failed|0|
| baseline production + value equality | FAILED |0 passed,1 failed|1|
| low production + value equality | FAILED |0 passed,1 failed|1|
| xhigh production + value equality | ok |1 passed,0 failed|0|

The baseline weak-test pass is an observed correction-deletion survivor before the assertion was strengthened. Failure logs show assertion left=List([Error(...)]) versus the expected prior record list. The exact strong assertion compares the previous payload after ls with the payload after the erroneous pipeline (A/strong-test-body.rs:1-8); weak test checks only Value::List (A/weak-test.patch:14-18). These results establish discrimination of this one exposed behavior. They do not establish general correctness of xhigh's patch or an effect of the proposed prompt protocol. Evidence: integrity-results.json focused_observations, and the raw paths/hashes bound there and in input-hash-manifest.json.

The first three combined logs are stdout followed by stderr; ordering across those streams is not a timeline. The continuation preserves stdout/stderr separately, binds unchanged parent script/registration/progress hashes, and contains only the remaining two phases (B/registration.json:3-7,23-33). No first-three replay was performed by this review. Both cleanup receipts record remove_exit_code0 and independently_absent=true, matching their container IDs (A/cleanup.json:1-5; B/cleanup.json:1-5). This review audited those receipts; it did not perform a new Docker absence query.

The independent byte audit rehashed every selected payload in each actual runtime manifest:985 NU files and965 RA files. It compared old low/xhigh common prompts, old client-home frozen global rules against old expected hashes, project instruction bytes against old hashes and pristine snapshot instructions, source images/commits, public commands and logical/runtime identities. All24 selected protected old file hashes matched. Each of the six on-disk inputs.json files equals its matrix row. Canonical IDs, fixed order, actual efforts low/low/xhigh and both task populations match the design. Both treatment prompts append the exact153 whitespace-word protocol once with the frozen separator; all controls equal old common prompt bytes. Evidence: integrity.stdout.log:1-116 and integrity-results.json; C/freeze-prompts-v1.py:26-69,76-91; C/prompt-inputs-registration.json:16-108.

Decimal arithmetic independently reconciles prior58.180531399999999104 +6*20 =178.180531399999999104 <=200, with CLI cap19. Prior author17.837117099999999 remains included once. These are prior reported spend and planned reserves, not new model charges. Evidence: integrity-results.json budget and C/prompt-inputs-registration.json:110-119, checked against old results.json.

The entire inspected C file inventory contains only helper/registration/matrix/protocol/verification, shared text inputs and six prompt/input pairs. No prepared.json, native argv, actor contexts, writable DB copies, synthetic CLI evidence or paid runner exists there. Registration and all arms remain prompt-inputs-only with launch_admitted=false. This is an inventory of C, not a machine-wide absence assertion. Evidence: C/prompt-inputs-registration.json:2-9,121-138 and integrity-results.json.

Two initial integrity-review harness errors were corrected before the successful audit: a guessed separator mismatch and a tuple/list representation comparison. Their original stderr is preserved as integrity-instrument-first-error.log and integrity-instrument-second-error.log; final integrity.stdout.log/err show the corrected byte checks exited0. Those were review instrumentation errors, not cohort reruns or changed outcomes.

## Declined to judge

- Whether the generic protocol improves low or matches xhigh: no new model attempts exist; the two tasks are already exposed development cases.
- Whether either original candidate meets complete acceptance/preservation beyond the one focused checked behavior: no private grader or full actor suite was rerun here.
- Prospective grader/parser validity or actual CLI delivery: owned elsewhere and not yet supplied as admitted source/wire evidence.
- Isolation of six writable runtime states, source-bound paid controller, provider cost closure or new whole-workflow success: none exists in this prompt/input-only stage.
- Current live container absence beyond the independent cleanup receipts: no Docker calls authorized for this review.
- Fresh product gate correctness: no product source changed; the parent reports prior full gates green. This research-helper/data review ran its direct calibrations and hash audits, and does not relabel historical native gates as newly rerun.

## Readiness

ARCHIVAL: the original five development observations and frozen bundle can be archived honestly with this v1 source, raw logs, mutations, receipts and findings retained. The assertion result is exposed-case evidence and the verifier failures are part of the record.

NEXT ZERO-PROVIDER PREPARATION: conditional on a reviewed verifier repair covering the observed survivors and invalid identities/budget metadata, or a separately bound equivalent independent validation that explicitly supersedesv1. Preserve v1. Do not fabricate native readiness from this bundle.

PAID LAUNCH/MERGE: no approval or success claim. Remaining spec gates include the peer's committed/reviewed grader, prospective complete-status parser policy and qualified negative/gold/repeat controls, six physical native state copies, actual six-arm synthetic CLI wire proof, source/input/controller registration, whole-cohort cost/stop/cleanup discipline and fresh headroom admission.

Ledger checked:32efc4f2deafd517,54fe4b112aa4e423,0a2929ec2a4f688f,51f42e8ae1499528,af727dad8cd9ce91,cd0ad8d33b2aae97.
