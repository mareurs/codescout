import ast, copy, hashlib, importlib.util, json, pathlib, re, sys, traceback
from decimal import Decimal
OUT=pathlib.Path('/tmp/semantic-contract-evidence-review-20261106')
BASE=pathlib.Path('/home/marius/.cache/codescout-resident/codescout')
ROOT=BASE/'semantic-contract-pilot-20261106'
SOURCE=ROOT/'freeze-prompts.py'
original=SOURCE.read_text()
(OUT/'freeze-prompts.original.py').write_text(original)
# Import copies only: the __main__ block never executes.
def load(source,name):
    target=OUT/(name+'.py'); target.write_text(source)
    spec=importlib.util.spec_from_file_location(name,target)
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module
m=load(original,'baseline_verifier')
reg=json.loads((ROOT/'prompt-inputs-registration.json').read_text())
rows=json.loads((ROOT/'matrix.json').read_text())['arms']
def negatives(reg,rows):
    cases=[]
    def add(name,edit):
        r=copy.deepcopy(rows);o={};edit(r,o);cases.append((name,r,o))
    add('duplicate arm ID',lambda r,o:r[1].update(arm_id=r[0]['arm_id']))
    add('wrong actual effort',lambda r,o:r[0].update(effort='xhigh'))
    def remove(r,o):
        row=next(x for x in r if x['variant']=='low-contract')
        data=(ROOT/'shared'/row['task']/'base-prompt.txt').read_bytes()
        o[row['prompt']]=data;row['prompt_sha256']=m.digest(data)
    add('remove treatment and resign local digest',remove)
    def contaminate(r,o):
        row=next(x for x in r if x['variant']=='low-control')
        data=pathlib.Path(row['prompt']).read_bytes()+m.SEPARATOR.encode()+(ROOT/'protocol.txt').read_bytes()
        o[row['prompt']]=data;row['prompt_sha256']=m.digest(data)
    add('contaminate control and resign local digest',contaminate)
    def rules(r,o):
        p=ROOT/'shared'/r[0]['task']/'global-CLAUDE.md'
        o[str(p)]=p.read_bytes()+b'\nreview corruption\n'
    add('change common frozen rules',rules)
    return cases
cases=negatives(reg,rows)
def suite(module):
    details=[]
    try: result=module.verify(copy.deepcopy(reg),copy.deepcopy(rows))
    except Exception as e:return {'passed':False,'baseline_error':repr(e),'details':details}
    for name,r,o in cases:
        try:module.verify(copy.deepcopy(reg),copy.deepcopy(r),dict(o))
        except ValueError as e:details.append({'case':name,'rejected':True,'reason':str(e)})
        else:details.append({'case':name,'rejected':False})
    return {'passed':all(x['rejected'] for x in details),'baseline':result,'details':details}
cal=suite(m)
assert cal['passed'],cal
print('CALIBRATION '+json.dumps(cal),flush=True)
# Mutate one guard at a time in copied helper, then execute the same calibrated suite.
guards=[('unique_variant_population','variant population'),('exact_protocol_delta','treatment prompt delta'),('actual_effort','real effort differs from variant'),('common_global_rules','common rules drift'),('source_identity','source identity'),('budget','budget'),('shared_runtime_and_checks','shared inputs'),('arm_stage','arm launch state')]
mutants=[]
for name,reason in guards:
    lines=original.splitlines(keepends=True)
    matched=[i for i,line in enumerate(lines) if 'require(' in line and '"'+reason+'"' in line]
    assert len(matched)==1,(name,matched)
    i=matched[0]; removed=lines[i].strip(); lines[i]=' '*(len(lines[i])-len(lines[i].lstrip()))+'pass # REVIEW MUTATION: guard removed\n'
    source=''.join(lines);ast.parse(source)
    mutant=load(source,'mutant_'+name)
    observation=suite(mutant)
    entry={'name':name,'removed_guard':removed,'line':i+1,'observed':'survived' if observation['passed'] else 'killed','suite':observation}
    mutants.append(entry);print('MUTATION '+json.dumps(entry),flush=True)
# Additional coverage is measured only AFTER the survivors above are recorded.
extra=[]
def evaluate(name,registration,r,override=None):
    try:result=m.verify(registration,r,override)
    except ValueError as e:entry={'name':name,'observed':'rejected','reason':str(e)}
    else:entry={'name':name,'observed':'accepted','result':result}
    extra.append(entry);print('ADDITIONAL_NEGATIVE '+json.dumps(entry),flush=True)
r=copy.deepcopy(rows);r[0]['image']='wrong-image';evaluate('source identity drift',copy.deepcopy(reg),r)
r=copy.deepcopy(rows);r[0]['input_identity']='wrong-snapshot';evaluate('shared input drift',copy.deepcopy(reg),r)
r=copy.deepcopy(rows);r[0]['stage']='prepared';evaluate('arm stage drift',copy.deepcopy(reg),r)
g=copy.deepcopy(reg);g['budget']['series_ceiling_usd']='100';evaluate('budget ceiling too low',g,copy.deepcopy(rows))
# Contract defects: identities that the verifier presently does not constrain.
r=copy.deepcopy(rows);r[0]['arm_id']='arbitrary-unique-id';evaluate('unique but wrong arm ID',copy.deepcopy(reg),r)
g=copy.deepcopy(reg);g['stage']='paid-ready';evaluate('registration stage drift',g,copy.deepcopy(rows))
report={'calibration':cal,'mutants':mutants,'mutants_killed':sum(x['observed']=='killed' for x in mutants),'mutants_survived':sum(x['observed']=='survived' for x in mutants),'additional_negative_controls':extra}
(OUT/'mutation-results.json').write_text(json.dumps(report,indent=2)+'\n')
print('COUNTS '+json.dumps({k:report[k] for k in ['mutants_killed','mutants_survived']}),flush=True)
