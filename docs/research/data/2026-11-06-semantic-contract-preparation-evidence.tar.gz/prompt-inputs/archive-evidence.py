"""Archive closed zero-provider evidence; reopen every member and verify bytes."""
import datetime
import hashlib
import io
import json
import pathlib
import subprocess
import tarfile

BASE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
MAIN=pathlib.Path("/home/marius/work/claude/codescout")
ROOT=BASE/"semantic-contract-pilot-20261106"
REVIEW=pathlib.Path("/tmp/semantic-contract-evidence-review-20261106")
OUT=MAIN/"docs/research/data/2026-11-06-semantic-contract-preparation-evidence.tar.gz"
RECEIPT=MAIN/"docs/research/data/2026-11-06-semantic-contract-preparation-evidence.json"
def sha(data):return hashlib.sha256(data).hexdigest()
def main():
    if OUT.exists() or RECEIPT.exists():raise RuntimeError("archive already exists; refuse overwrite")
    reg=json.loads((ROOT/"prompt-inputs-registration.json").read_text())
    prior_archive=MAIN/"docs/research/data/2026-11-06-private-grade-disk-audit-evidence.tar.gz"
    with tarfile.open(prior_archive) as t:
        prior=json.load(t.extractfile("MANIFEST.json"))
    prior_by_source={f["source"]:f for f in prior["files"]}
    original=reg["protected_original_hashes"]
    preservation=[]
    for path,expected in original.items():
        data=pathlib.Path(path).read_bytes()
        assert sha(data)==expected,(path,"changed since freeze")
        assert path in prior_by_source,(path,"not in old archive")
        assert prior_by_source[path]["sha256"]==expected,(path,"old archive differs")
        preservation.append({"source":path,"sha256":expected,"matches_prior_archive":True})
    cleanup=[]
    for root in (BASE/"semantic-contract-probe-20261106",BASE/"semantic-contract-probe-20261106/remaining-checks"):
        receipt=json.loads((root/"cleanup.json").read_text())
        # Query the daemon inventory independently; an inspect error alone is insufficient.
        cid=json.loads((root/"container.json").read_text())["id"]
        query=subprocess.run(["docker","ps","-aq","--no-trunc"],capture_output=True,text=True,timeout=30)
        assert query.returncode==0,query.stderr
        assert cid not in query.stdout.splitlines(),cid
        cleanup.append({"container_id":cid,"daemon_inventory_exit":query.returncode,"independently_absent_now":True,"original_receipt":receipt})
    closure={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"protected_originals":preservation,"protected_original_count":len(preservation),"container_cleanup":cleanup}
    (ROOT/"archive-closure-checks.json").write_text(json.dumps(closure,indent=2)+"\n")
    payload={}
    def add_file(name,path):
        assert name not in payload,name
        assert path.is_file() and not path.is_symlink(),str(path)
        payload[name]=(str(path),path.read_bytes())
    def add_tree(prefix,root):
        for path in sorted(root.rglob("*")):
            if "__pycache__" in path.parts or path.suffix==".pyc":continue
            if path.is_file():add_file(prefix+"/"+str(path.relative_to(root)),path)
    add_tree("focused-controls",BASE/"semantic-contract-probe-20261106")
    add_tree("prompt-inputs",ROOT)
    add_tree("independent-review",REVIEW)
    for task,record in reg["projects"].items():
        add_file("snapshot-manifests/"+task+".json",pathlib.Path(record["runtime_snapshot_manifest"]))
    for name in ("2026-11-06-semantic-contract-pilot-design.md","2026-11-06-semantic-contract-pilot.md"):
        parent="specs" if name.endswith("design.md") else "plans"
        add_file("design/"+name,MAIN/"docs/superpowers"/parent/name)
    for job in ("00000104","00000106","00000107"):
        path=pathlib.Path("/tmp/codescout-bg/455879-a720241d-bg_"+job+".json")
        add_file("jobs/"+path.name,path)
        record=json.loads(path.read_text())
        # Archive recorded streams only when the record names existing files.
        for key,value in record.items():
            if isinstance(value,str) and value.startswith("/tmp/") and pathlib.Path(value).is_file() and value!=str(path):
                p=pathlib.Path(value)
                if "log" in key or p.suffix==".log":
                    name="jobs/"+job+"-"+p.name
                    if name not in payload:add_file(name,p)
    manifest={"utc":closure["utc"],"scope":"Zero-provider exposed-case focused-test controls, prompt-input-only six-arm freeze, original and corrected verifier, applied independent mutations and design. No runtime stores, credentials, private oracle, model calls or launch admission.","files":[{"name":name,"source":source,"size":len(data),"sha256":sha(data)} for name,(source,data) in sorted(payload.items())]}
    with tarfile.open(OUT,"w:gz") as tar:
        for name,(source,data) in sorted(payload.items()):
            info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0
            tar.addfile(info,io.BytesIO(data))
        data=(json.dumps(manifest,indent=2)+"\n").encode()
        info=tarfile.TarInfo("MANIFEST.json");info.size=len(data);info.mtime=0
        tar.addfile(info,io.BytesIO(data))
    with tarfile.open(OUT) as tar:
        m=json.load(tar.extractfile("MANIFEST.json"))
        assert len(tar.getmembers())==len(payload)+1
        for f in m["files"]:
            data=tar.extractfile(f["name"]).read()
            assert len(data)==f["size"] and sha(data)==f["sha256"],f["name"]
    receipt={"archive":str(OUT),"sha256":sha(OUT.read_bytes()),"bytes":OUT.stat().st_size,"payload_files":len(payload),"manifest_files":1,"all_payloads_reopened_and_hash_verified":True,"protected_originals_match_previous_archive":len(preservation),"both_containers_independently_absent_now":True}
    RECEIPT.write_text(json.dumps(receipt,indent=2)+"\n")
    print(json.dumps(receipt,indent=2))

if __name__=="__main__":main()
