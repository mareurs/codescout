"""Archive this bounded adapter qualification; reopen and verify every payload."""
import hashlib
import io
import json
import pathlib
import tarfile
import time

ROOT=pathlib.Path(__file__).resolve().parent
MAIN=pathlib.Path("/home/marius/work/claude/codescout")
TARGET=MAIN/"docs/research/data/2026-11-06-semantic-contract-adapter-evidence.tar.gz"


def sha(data):return hashlib.sha256(data).hexdigest()


def main():
    if TARGET.exists():raise ValueError("refuse archive overwrite")
    if not (ROOT/"common-result.json").exists() and not (ROOT/"common-stopped.json").exists():
        raise ValueError("native common attempt has not closed")
    payloads={}
    omitted=[]
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file():continue
        relative=path.relative_to(ROOT)
        if path.name in ("peer-inventory.txt","peer-inventory.stderr"):continue
        if "__pycache__" in relative.parts or relative.suffix==".pyc":continue
        # Large reusable snapshot payloads already have source-bound snapshot manifests;
        # record current hashes separately, retain resident bytes, archive native logs/receipts.
        if len(relative.parts)>1 and relative.parts[0]=="common" and relative.parts[1] in ("knowledge","member-state","native-home"):
            omitted.append({"path":relative.as_posix(),"bytes":path.stat().st_size,"sha256":sha(path.read_bytes()),
                            "retained_resident":str(path)})
            continue
        if path.is_symlink():raise ValueError("archive source symlink requires explicit closure")
        payloads[relative.as_posix()]=path.read_bytes()
    payloads["resident-reused-inputs.json"]=(json.dumps({"scope":"Reusable cloned state retained outside archive, hashes only; no deletion authorized",
                                                       "files":omitted},indent=2)+"\n").encode()
    manifest={name:{"bytes":len(raw),"sha256":sha(raw)} for name,raw in payloads.items()}
    data=(json.dumps({"utc_unix":time.time(),"files":manifest,"payloads":len(manifest),
        "limits":"Only this new adapter/review/common qualification. Prior control/source archives remain separately bound. Reused snapshot state retained resident."},indent=2)+"\n").encode()
    payloads["MANIFEST.json"]=data
    TARGET.parent.mkdir(parents=True,exist_ok=True)
    with tarfile.open(TARGET,"x:gz") as archive:
        for name,raw in payloads.items():
            info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=int(time.time());info.mode=0o644
            archive.addfile(info,io.BytesIO(raw))
    with tarfile.open(TARGET,"r:gz") as archive:
        entries=archive.getmembers()
        if {p.name for p in entries}!=set(payloads) or len(entries)!=len(payloads):
            raise ValueError("archive population mismatch")
        for entry in entries:
            raw=archive.extractfile(entry).read()
            if raw!=payloads[entry.name]:raise ValueError("archive payload mismatch")
    receipt={"archive":str(TARGET),"sha256":sha(TARGET.read_bytes()),"bytes":TARGET.stat().st_size,
        "verified_payloads":len(manifest),"verified_manifest":True,"retained_reused_snapshot_files":len(omitted),
        "paid_admission":False,"provider_calls":0}
    (ROOT/"archive-receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
    TARGET.with_name(TARGET.name+".json").write_text(json.dumps(receipt,indent=2)+"\n")
    print(json.dumps(receipt,indent=2))


if __name__=="__main__":main()
