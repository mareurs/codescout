"""Execute the skill's two enumerate blocks and merger, read-only, one shell."""
import pathlib
import re
import subprocess

SKILL=pathlib.Path("/home/marius/.codex/plugins/cache/sdd-misc-plugins/codescout-companion/1.20.29/skills/reaching-peer-sessions")
ROOT=pathlib.Path(__file__).resolve().parent


def main():
    paths=[SKILL/"references/claude-code.md",SKILL/"references/codex.md",SKILL/"SKILL.md"]
    blocks=[re.findall(r"```bash\n(.*?)\n```",path.read_text(),re.S)[0] for path in paths]
    program="{\n"+blocks[0]+"\n"+blocks[1]+"\n} | {\n"+blocks[2]+"\n}\n"
    result=subprocess.run(["bash","-c",program],capture_output=True,text=True,timeout=45)
    (ROOT/"peer-inventory.txt").write_text(result.stdout)
    (ROOT/"peer-inventory.stderr").write_text(result.stderr)
    print(result.stdout,end="")
    raise SystemExit(result.returncode)


if __name__=="__main__":main()
