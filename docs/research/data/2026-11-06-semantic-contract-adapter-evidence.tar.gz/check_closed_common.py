"""At-rest audit of the INVALID v1 common attempt. No retry or actor call."""
import json
import pathlib
import subprocess
import time

from paid_backend import PaidBackend
import campaign

ROOT=pathlib.Path(__file__).resolve().parent


def main():
    reg=campaign.load(ROOT/"common-registration.json");out=pathlib.Path(reg["arms"][0]["out"])
    campaign.check_hashes(reg["shared_hashes"])
    campaign.check_hashes(reg["arms"][0]["immutable_hashes"])
    real=campaign.load(ROOT/"real-inputs-before.json")
    paths={}
    for hashes in real.values():campaign.check_hashes(hashes);paths.update(hashes)
    backend=PaidBackend(reg,qualification_plan=reg["scripted_plan"]);backend.validate_shared(reg)
    receipt=campaign.load(out/"receipt.json")
    if (receipt["scripted"] is not True or receipt["forwarded"]!=0 or receipt["unknown_provider_cost"] is not False
            or campaign.amount(receipt["cost_usd"])!=0):
        raise ValueError("unexpected invalid-fixture cost state")
    if campaign.load(out/"launch.json")["real_credentials_read"] is not False:
        raise ValueError("fixture read credentials")
    daemon=subprocess.run(["docker","info","--format","{{json .ServerVersion}}"],capture_output=True,text=True,timeout=20)
    if daemon.returncode:raise ValueError("daemon absence check unavailable")
    absent=[]
    for path in sorted(out.glob("mcp-launch-*.json")):
        name=campaign.load(path)["name"]
        result=subprocess.run(["docker","inspect",name],capture_output=True,text=True,timeout=20)
        if result.returncode==0 or "no such object" not in result.stderr.lower():
            raise ValueError("named worker absence not proven")
        absent.append({"name":name,"exit":result.returncode,"stdout":result.stdout,"stderr":result.stderr})
    samples=[json.loads(line) for line in (out/"resource-samples.jsonl").read_text().splitlines()]
    final=campaign.load(out/"supervision-final.json")
    result={"qualified":False,"paid_admission":False,"scope":"Invalid v1 common fixture, no actor/native/model rerun",
        "source_commit":reg["source_commit"],"source_paths_rehashed":len(reg["shared_hashes"]),
        "protected_real_unique_paths":len(paths),"common_immutable_hash_records":len(reg["arms"][0]["immutable_hashes"]),
        "synthetic_cost_usd":"0","forwarded_model_messages":0,"real_credentials_read":False,
        "resource_sample_rows":len(samples),"cgroup_probes":final["cgroup_probes"],
        "cgroup_health":"unknown; no successful probe","known_identity_failure":final["errors"],
        "host_minimum_bytes":{key:min(row["host"][key] for row in samples) for key in ("root_free","tmp_free","mem_available")},
        "daemon_query_succeeded":True,"named_worker_absence":absent,"candidate_capture_complete":False,
        "private_outcomes_unread":True,"retry_allowed":False,"unix":time.time()}
    campaign.save(ROOT/"common-closed-audit.json",result,exclusive=True)
    print(json.dumps(result,indent=2))


if __name__=="__main__":main()
