{
  "file_id": "@file_b27d81ce",
  "total_lines": 55,
  "hint": "use \"@file_b27d81ce\" — start_line/end_line to browse the full content"
}