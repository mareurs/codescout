import hashlib
import json
import pathlib
import shutil

ROOT=pathlib.Path(__file__).resolve().parent
SOURCE=pathlib.Path("/home/marius/.codex/worktrees/ca35/codescout")


def main():
    dest=ROOT/"reapplication"
    if dest.exists():raise ValueError("refuse exact reapplication overwrite")
    dest.mkdir()
    mutations=json.loads((ROOT/"review/mutations.json").read_text())["mutations"]
    for name in ["baseline",*(row["id"] for row in mutations)]:
        tree=dest/name
        for group in ("agent_lifecycle","hint_authority_pilot","hint_authority_workflow","hint_authority_resume"):
            shutil.copytree(SOURCE/"tools"/group,tree/"tools"/group,
                            ignore=shutil.ignore_patterns("__pycache__","*.pyc"))
        for file in ("supervision.py","paid_backend.py","test_adapter_supervision.py","test_paid_backend.py"):
            shutil.copyfile(ROOT/file,tree/file)
        test=tree/"test_paid_backend.py"
        content=test.read_text()
        old='SOURCE=pathlib.Path("/home/marius/.codex/worktrees/ca35/codescout")'
        if content.count(old)!=1:raise ValueError("copy-source rewrite selector differs")
        test.write_text(content.replace(old,"SOURCE=pathlib.Path("+json.dumps(str(tree))+")"))
    for row in mutations:
        tree=dest/row["id"];path=tree/row["file"]
        text=path.read_text()
        if text.count(row["original"])!=1:raise ValueError("exact mutation selector differs: "+row["id"])
    (dest/"prepared.json").write_text(json.dumps({"mutants":len(mutations),
        "copy_path_rewrite_only":"test_paid_backend.SOURCE","originals_changed":False},indent=2)+"\n")
    print(json.dumps({"prepared_mutants":len(mutations),"dest":str(dest)}))


if __name__=="__main__":main()
