import hashlib
import json
import pathlib
import sys
import tempfile
import types
import unittest
from decimal import Decimal
from unittest.mock import patch

import paid_backend

SOURCE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/semantic-contract-adapter-20261106/reapplication/M01")
POLICY=pathlib.Path("/home/marius/work/claude/codescout.worktrees/grader-validity/tools/setup-ab-eval/grade_policy.py")
sys.path.insert(0,str(SOURCE/"tools/agent_lifecycle"))
from test_external_entry import ExternalEntryTests
from test_supervision import PROGRAM


class BackendTests(unittest.TestCase):
    def fixture(self,root):
        ExternalEntryTests().fixture(root)
        state=root/"state.db";state.write_text("pristine")
        global_md=root/"global.md"
        reg={"qualified_source":str(SOURCE),"shared_hashes":{str(POLICY):hashlib.sha256(POLICY.read_bytes()).hexdigest()},
             "public_policy":str(POLICY),"reserve_usd":"20","cli_cap_usd":"19","mode":"paid"}
        row={"out":str(root),"effort":"low","arm_id":"offline",
             "immutable_hashes":{str(global_md):hashlib.sha256(global_md.read_bytes()).hexdigest()},
             "writable_hashes":{str(state):hashlib.sha256(state.read_bytes()).hexdigest()}}
        return reg,row

    def test_prelaunch_source_drift_blocks_external_and_credentials(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);reg,row=self.fixture(root)
            reg["shared_hashes"][str(POLICY)]="0"*64
            backend=paid_backend.PaidBackend(reg)
            with patch.object(backend.external,"launch",side_effect=AssertionError("launch forbidden")):
                with self.assertRaisesRegex(ValueError,"drift"):
                    backend.launch(row,Decimal("20"),Decimal("19"))
            self.assertFalse((root/"started.json").exists())

    def test_backend_calls_actual_external_entry_and_supervised_workflow(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);reg,row=self.fixture(root)
            script=root/"client";script.write_text("#!/usr/bin/python3\n"+PROGRAM.replace('"guard-test"',"__import__('sys').argv[__import__('sys').argv.index('--session-id')+1]"));script.chmod(0o755)
            cfg=json.loads((root/"prepared.json").read_text());cfg["cli"]=str(script)
            cfg["files"][str(script)]=hashlib.sha256(script.read_bytes()).hexdigest()
            (root/"prepared.json").write_text(json.dumps(cfg))
            reg["mode"]="qualification";events=[]
            class Supervisor:
                def __init__(self,*a,**kw):pass
                def bind(self,**kw):events.append("bind")
                def check(self):pass
                def client_started(self,p):events.append("owned-client")
                def before_public(self):events.append("before-public")
                def after_public(self,*a):events.append("after-public")
                def finish(self):events.append("finish")
            backend=paid_backend.PaidBackend(reg,qualification_plan=[],supervisor_factory=Supervisor)
            def native(out,image,command,log,timeout):
                log.write_text("ok");return 0
            with patch.object(backend,"validate_shared"),\
                 patch.object(backend.external.workflow,"native_check",side_effect=native),\
                 patch.object(backend.external.workflow,"preserve_background_logs",return_value={"complete":True,"logs":[],"errors":[]}),\
                 patch.object(backend.external.workflow,"cleanup_native"),\
                 patch.object(backend.external,"capture_patch",return_value={"complete":True}):
                receipt=backend.launch(row,Decimal("20"),Decimal("19"))
            self.assertEqual(events,["bind","owned-client","before-public","after-public","finish"])
            self.assertEqual(receipt["cost_usd"],"0")
            self.assertTrue(receipt["scripted"])
            self.assertFalse(json.loads((root/"launch.json").read_text())["real_credentials_read"])
            self.assertFalse(receipt["context_valid"])

    def test_reconcile_uses_calibrated_terminal_and_provider_coverage(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);reg,row=self.fixture(root);backend=paid_backend.PaidBackend(reg)
            result={"type":"result","session_id":"paid-fixture","total_cost_usd":"1.25","is_error":False,"subtype":"success"}
            (root/"stream.jsonl").write_text(json.dumps(result)+"\n")
            (root/"stdout.json").write_text(json.dumps(result))
            receipt={"session_id":"paid-fixture","cost_usd":"1.25","scripted":False,
                     "unknown_provider_cost":False,"upper_usage_cost":"1","campaign_available_usd":"20",
                     "forwarded":1,"cost_coverage":{"forwarded_at_terminal":1,"forwarded_total":1}}
            self.assertEqual(backend.reconcile(row,receipt,Decimal("20")),Decimal("1.25"))
            receipt["cost_coverage"]["forwarded_total"]=2
            with self.assertRaises(ValueError):backend.reconcile(row,receipt,Decimal("20"))

    def test_cleanup_requires_live_daemon_and_exact_cid_absence(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);reg,row=self.fixture(root);backend=paid_backend.PaidBackend(reg)
            cid="c"*64
            (root/"supervision-final.json").write_text(json.dumps({"observed_container_ids":[cid],"container_name":"hfa-native-test"}))
            (root/"cleanup.json").write_text(json.dumps([{"name":"hfa-native-test","absent":True}]))
            calls=[]
            def absent(args,**kwargs):
                calls.append(args)
                if args[1]=="info":return types.SimpleNamespace(returncode=0,stdout="{}",stderr="")
                return types.SimpleNamespace(returncode=1,stdout="",stderr="Error: No such object")
            with patch.object(paid_backend.subprocess,"run",side_effect=absent):
                result=backend.cleanup(row)
            self.assertTrue(result["independently_absent"])
            self.assertIn(["docker","inspect",cid],calls)
            def permission(args,**kwargs):
                return types.SimpleNamespace(returncode=1,stdout="",stderr="permission denied")
            with patch.object(paid_backend.subprocess,"run",side_effect=permission):
                with self.assertRaises(ValueError):backend.cleanup(row)

    def test_missing_final_proof_cannot_be_accepted(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);reg,row=self.fixture(root);backend=paid_backend.PaidBackend(reg)
            with self.assertRaises((ValueError,FileNotFoundError)):
                backend.valid_public(row,{"supervision_error":None})
            self.assertFalse(hasattr(backend,"grade"))
    def test_public_recheck_binds_every_round_log_and_classification(self):
        from test_adapter_supervision import Docker,HEALTHY,CID,IMAGE,NAME
        from supervision import Supervisor
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);reg,row=self.fixture(root)
            (root/("mcp-launch-"+NAME+".json")).write_text(json.dumps({"name":NAME}))
            supervisor=Supervisor(POLICY,host=lambda:dict(HEALTHY),docker=Docker(),interval=100)
            supervisor.bind(out=root,image=IMAGE,server=types.SimpleNamespace())
            self.addCleanup(supervisor.stop_monitor)
            expected=json.loads((root/"prepared.json").read_text())["checks"][0]
            result=None
            for i,code in enumerate((1,0)):
                directory=root/("verification-"+str(i));directory.mkdir()
                log=directory/"0.log";log.write_text("assertion failed" if code else "ok")
                supervisor.before_public();supervisor.after_public(expected["command"],log,code)
                result={"round":i,"status":"completed","passed":code==0,"error":None,
                        "checks":[dict(expected,exit_code=code,log=str(log))]}
                (directory/"receipt.json").write_text(json.dumps(result))
            supervisor.finish()
            backend=paid_backend.PaidBackend(reg)
            receipt={"supervision_error":None,"public_verification":result}
            self.assertEqual(backend.valid_public(row,receipt),{"valid":True,"rounds":2,"checks":2})
            (root/"verification-0/0.log").write_text("changed after classification")
            with self.assertRaisesRegex(ValueError,"bytes differ"):
                backend.valid_public(row,receipt)

    def test_late_public_infrastructure_fault_stops_campaign_after_recording_known_cost(self):
        from test_adapter_supervision import Docker,HEALTHY,CID,IMAGE,NAME
        from supervision import Supervisor
        import test_campaign
        case=test_campaign.CampaignTests();case.setUp();self.addCleanup(case.doCleanups)
        first=case.reg["arms"][0]
        out=pathlib.Path(first["out"])
        # Replace only this synthetic campaign's first fixture configuration, not a real arm.
        for p in out.iterdir():p.unlink()
        reg,row=self.fixture(out)
        script=out/"client"
        script.write_text("""#!/usr/bin/python3
import http.client,json,os,sys,urllib.parse
sid=sys.argv[sys.argv.index('--session-id')+1]
effort=sys.argv[sys.argv.index('--effort')+1]
for line in sys.stdin:
    url=urllib.parse.urlsplit(os.environ['ANTHROPIC_BASE_URL'])
    conn=http.client.HTTPConnection(url.hostname,url.port,timeout=3)
    body={'model':'claude-sonnet-5-5','output_config':{'effort':effort},
          'messages':[{'role':'user','content':'GLOBAL\\nPROJECT'}]}
    conn.request('POST','/v1/messages',json.dumps(body),{'Content-Type':'application/json'})
    response=conn.getresponse();response.read();conn.close()
    if response.status!=200:raise RuntimeError('local scripted request failed')
    print(json.dumps({'type':'result','session_id':sid,'subtype':'success','is_error':False,'total_cost_usd':0}),flush=True)
""")
        script.chmod(0o755)
        cfg=json.loads((out/"prepared.json").read_text());cfg["cli"]=str(script)
        cfg["files"][str(script)]=hashlib.sha256(script.read_bytes()).hexdigest()
        (out/"prepared.json").write_text(json.dumps(cfg))
        first["immutable_hashes"]={str(out/"prepared.json"):hashlib.sha256((out/"prepared.json").read_bytes()).hexdigest()}
        first["writable_hashes"]=row["writable_hashes"]
        case.reg.update(reg,arms=case.reg["arms"],mode="qualification")
        case.bind()
        def factory(policy):
            return Supervisor(policy,host=lambda:dict(HEALTHY),docker=Docker(),interval=100)
        backend=paid_backend.PaidBackend(case.reg,qualification_plan=[],supervisor_factory=factory)
        launches=[]
        original=backend.external.launch
        def entry(directory,**kwargs):
            launches.append(str(directory))
            (directory/("mcp-launch-"+NAME+".json")).write_text(json.dumps({"name":NAME}))
            return original(directory,**kwargs)
        def native(directory,image,command,log,timeout):
            log.write_text("rustc: fatal error: terminated with signal 7 [Bus error]");return 101
        def capture(directory,*args):
            patch=directory/"candidate.patch";patch.write_bytes(b"")
            result={"complete":True,"bytes":0,"sha256":hashlib.sha256(b"").hexdigest()}
            (directory/"candidate-capture.json").write_text(json.dumps(result))
            return result
        # Host/daemon/credential costs are boundary fixtures; campaign, backend entry,
        # public policy, supervisor, session, local proxy and filesystem are actual.
        with patch.object(paid_backend.campaign,"preflight",return_value={"offline_fixture":True}),\
             patch.object(backend,"validate_shared"),\
             patch.object(backend,"reconcile",return_value=Decimal("0")),\
             patch.object(backend.external,"launch",side_effect=entry),\
             patch.object(backend.external,"capture_patch",side_effect=capture),\
             patch.object(backend.external.workflow,"native_check",side_effect=native),\
             patch.object(backend.external.workflow,"preserve_background_logs",return_value={"complete":True,"logs":[],"errors":[]}),\
             patch.object(backend.external.workflow,"cleanup_native"):
            with self.assertRaisesRegex(ValueError,"Public verification invalid"):
                paid_backend.campaign.run(case.root,case.regfile,case.admit,backend)
        stopped=json.loads((case.root/"campaign-stopped.json").read_text())
        self.assertEqual(launches,[str(out)])
        self.assertEqual(len(stopped["known_charges"]),1)
        self.assertIsNone(stopped["unreconciled_attempt"])
        self.assertTrue(stopped["private_outcomes_embargoed"])
        receipt=json.loads((out/"receipt.json").read_text())
        self.assertTrue(receipt["context_valid"])
        self.assertEqual(receipt["lifecycle"]["continuations"],0)
    def test_each_arm_input_dimension_drift_blocks_before_external_launch(self):
        for dimension in ("writable_hashes","immutable_hashes"):
            with self.subTest(dimension=dimension),tempfile.TemporaryDirectory() as d:
                root=pathlib.Path(d);reg,row=self.fixture(root)
                target=root/("registered-"+dimension)
                target.write_text("pristine")
                row[dimension]={str(target):hashlib.sha256(target.read_bytes()).hexdigest()}
                backend=paid_backend.PaidBackend(reg)
                target.write_text("drift")
                with patch.object(backend,"validate_shared"),\
                     patch.object(backend.external,"launch",side_effect=AssertionError("external must not launch")):
                    with self.assertRaisesRegex(ValueError,"drift"):
                        backend.launch(row,Decimal("20"),Decimal("19"))
                self.assertFalse((root/"started.json").exists())

    def test_actual_shared_validation_blocks_plugin_or_readonly_drift(self):
        import importlib.util
        helper=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/semantic-contract-plugin-binding-20261106/tree_identity.py")
        spec=importlib.util.spec_from_file_location("fixture_identity",helper)
        identity=importlib.util.module_from_spec(spec);spec.loader.exec_module(identity)
        for dimension in ("plugin","readonly"):
            with self.subTest(dimension=dimension),tempfile.TemporaryDirectory() as d:
                root=pathlib.Path(d);reg,row=self.fixture(root)
                plugin=root/"plugin";skill=plugin/"SKILL.md";skill.write_text("full fixture skill")
                plugin_manifest=root/"plugin-manifest.json"
                plugin_manifest.write_text(json.dumps({"plugin":str(plugin),"identity":identity.capture(plugin)}))
                readonly=root/"readonly";readonly.mkdir();source=readonly/"source.py";source.write_text("frozen source")
                readonly_manifest=root/"readonly-manifest.json"
                readonly_manifest.write_text(json.dumps({"/bench-ro":{"source.py":{"sha256":hashlib.sha256(source.read_bytes()).hexdigest()}}}))
                native=root/"mcp-native-argv.json";argv=json.loads(native.read_text())
                argv[-4:-4]=["--mount","type=bind,src="+str(readonly)+",dst=/bench-ro,readonly"]
                native.write_text(json.dumps(argv))
                cfg=json.loads((root/"prepared.json").read_text())
                cfg["files"][str(native)]=hashlib.sha256(native.read_bytes()).hexdigest()
                (root/"prepared.json").write_text(json.dumps(cfg))
                reg.update(plugin_helper=str(helper),plugin_manifest=str(plugin_manifest),
                           readonly_manifest=str(readonly_manifest),arms=[row])
                backend=paid_backend.PaidBackend(reg)
                backend.validate_shared(reg)  # prove otherwise healthy real sibling inputs
                (skill if dimension=="plugin" else source).write_text("changed")
                with patch.object(backend.external,"launch",side_effect=AssertionError("external must not launch")):
                    with self.assertRaises(ValueError):
                        backend.launch(row,Decimal("20"),Decimal("19"))
                self.assertFalse((root/"started.json").exists())

    def test_each_round_metadata_dimension_is_independently_required(self):
        for field,value in (("round",1),("status","incomplete"),("error","capture lost")):
            with self.subTest(field=field),tempfile.TemporaryDirectory() as d:
                root=pathlib.Path(d);reg,row=self.fixture(root);backend=paid_backend.PaidBackend(reg)
                proof={"complete":True,"resource_ok":True,"cgroup_probes":2,"oom_kill":0,"errors":[]}
                (root/"supervision-final.json").write_text(json.dumps(proof))
                directory=root/"verification-0";directory.mkdir();log=directory/"0.log";log.write_text("ok")
                expected=json.loads((root/"prepared.json").read_text())["checks"][0]
                result={"round":0,"status":"completed","error":None,"passed":True,
                        "checks":[dict(expected,exit_code=0,log=str(log))]}
                bound={"checks":[{"command":expected["command"],"log":str(log),"bytes":2,
                    "sha256":hashlib.sha256(b"ok").hexdigest(),"exit_code":0,
                    "classification":paid_backend.classify(POLICY,"ok",0,proof)}]}
                (root/"public-classifications.json").write_text(json.dumps(bound))
                (directory/"receipt.json").write_text(json.dumps(result))
                receipt={"supervision_error":None,"public_verification":result}
                backend.valid_public(row,receipt)
                result[field]=value
                (directory/"receipt.json").write_text(json.dumps(result))
                with self.assertRaisesRegex(ValueError,"round incomplete"):
                    backend.valid_public(row,receipt)

    def test_daemon_failure_is_not_masked_by_successful_absence_observations(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);reg,row=self.fixture(root);backend=paid_backend.PaidBackend(reg)
            (root/"supervision-final.json").write_text(json.dumps({"observed_container_ids":["c"*64]}))
            (root/"cleanup.json").write_text(json.dumps([{"name":"hfa-native-test","absent":True}]))
            def response(args,**kwargs):
                if args[1]=="info":
                    return types.SimpleNamespace(returncode=1,stdout="",stderr="permission denied")
                return types.SimpleNamespace(returncode=1,stdout="",stderr="Error: No such object")
            with patch.object(paid_backend.subprocess,"run",side_effect=response):
                with self.assertRaisesRegex(ValueError,"daemon not queryable"):
                    backend.cleanup(row)


if __name__=="__main__":unittest.main()
