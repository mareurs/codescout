"""Owned host/runtime supervision for the fixed prospective adapter."""
import pathlib
import hashlib
import json
import math
import os
import re
import shutil
import signal
import subprocess
import threading
import time

FLOORS = {"root_free":80*1024**3, "tmp_free":4*1024**3, "mem_available":48*1024**3}


def host_sample():
    mem = {line.split()[0].rstrip(":"):int(line.split()[1])*1024
           for line in pathlib.Path("/proc/meminfo").read_text().splitlines()
           if len(line.split())>=2 and line.split()[1].isdigit()}
    return {"root_free":shutil.disk_usage("/home/marius/.cache").free,
            "tmp_free":shutil.disk_usage("/tmp").free,"mem_available":mem["MemAvailable"],
            "pressure":{name:(pathlib.Path("/proc/pressure")/name).read_text()
                        for name in ("cpu","memory","io")}}


def docker_run(args):
    return subprocess.run(["docker",*args],capture_output=True,text=True,timeout=20)


def classify(policy, log, code, runtime):
    # Separate interpreter: the grader and native worker both import modules named run.
    program = ("import json,sys;sys.path.insert(0,sys.argv[1]);"
               "from grade_policy import classify_public;"
               "d=json.load(sys.stdin);print(json.dumps(classify_public(**d)))")
    result = subprocess.run([sys.executable,"-B","-c",program,str(policy.parent)],
        input=json.dumps({"log":log,"exit_code":code,"runtime":runtime}),
        text=True,capture_output=True,timeout=30)
    if result.returncode:
        raise ValueError("public policy process failed: "+result.stderr[-500:])
    return json.loads(result.stdout)


import sys

MAX_LOG_BYTES = 64*1024**2

class Supervisor:
    def __init__(self, policy, *, host=host_sample, docker=docker_run, interval=10):
        self.policy=pathlib.Path(policy).resolve()
        self.host,self.docker,self.interval=host,docker,interval
        self.out=None;self.image=None;self.server=None;self.proc=None
        self.cid=None;self.name=None;self.errors=[];self.probes=0;self.oom=0
        self.finished=False;self.classifications=[];self.known_ids=[]
        self.lock=threading.RLock();self.stop=threading.Event();self.thread=None
        self.policy_hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in (self.policy,self.policy.with_name("audit_reparse.py"),
                      self.policy.with_name("multilang_grade.py"),self.policy.with_name("multilang_tasks.py"))}

    def save(self, name, value):
        (self.out/name).write_text(json.dumps(value,indent=2)+"\n")

    def bind(self, *, out, image, server):
        if self.out is not None:raise ValueError("supervisor already bound")
        self.out=pathlib.Path(out).resolve();self.image=image;self.server=server
        server.request_guard=self.check
        self.sample("initial-host",discover=False)
        self.check()
        self.thread=threading.Thread(target=self.watch,daemon=True)
        self.thread.start()

    def stop_monitor(self):
        self.stop.set()
        if self.thread is not None and self.thread is not threading.current_thread():
            self.thread.join(timeout=45)
            if self.thread.is_alive():self.fault("resource monitor did not stop")

    def watch(self):
        while not self.stop.wait(self.interval):
            self.sample("periodic")
            if self.errors:return

    def fault(self, message):
        if message not in self.errors:self.errors.append(message)
        self.stop.set()
        # Only this exact returned Popen grants process-group ownership.
        if self.proc is not None and self.proc.poll() is None:
            try:os.killpg(self.proc.pid,signal.SIGTERM)
            except ProcessLookupError:pass
            except OSError as exc:self.errors.append("owned client abort failed: "+str(exc))
        # cid is set only after image, label, name and full actor profile validation.
        if self.cid is not None:
            try:
                result=self.docker(["kill",self.cid])
                if result.returncode:self.errors.append("owned container abort failed")
            except Exception as exc:self.errors.append("owned container abort failed: "+str(exc))

    def check(self):
        if self.errors:raise ValueError("runtime supervision failed: "+"; ".join(self.errors))

    def client_started(self, proc):
        if self.proc is not None or not isinstance(proc,subprocess.Popen):
            raise ValueError("actual single Popen required for client ownership")
        argv=json.loads((self.out/"launch.json").read_text())["argv"]
        if proc.poll() is not None or proc.args!=argv or os.getpgid(proc.pid)!=proc.pid:
            raise ValueError("client ownership or argv mismatch")
        self.proc=proc
        self.save("client-ownership.json",{"pid":proc.pid,"pgid":proc.pid,"argv":argv})
        self.check()

    def identify(self, *, required):
        names=[]
        for path in self.out.glob("mcp-launch-*.json"):
            name=json.loads(path.read_text())["name"]
            if not re.fullmatch(r"hfa-native-[0-9a-f]{32}",name):
                raise ValueError("native launch name invalid")
            names.append(name)
        live=[]
        for name in sorted(set(names)):
            result=self.docker(["inspect",name])
            if result.returncode:
                if "No such" in result.stderr:continue
                raise ValueError("native identity probe failed")
            info=json.loads(result.stdout)
            if not isinstance(info,list) or len(info)!=1:raise ValueError("native identity ambiguous")
            info=info[0]
            if info.get("State",{}).get("Running") is True:live.append((name,info))
        if not live:
            if required or self.cid is not None:raise ValueError("native worker missing")
            return None
        if len(live)!=1:raise ValueError("multiple live native workers")
        name,info=live[0];cid=info["Id"]
        if (not re.fullmatch(r"[0-9a-f]{64}",cid) or info["Image"]!=self.image
                or info.get("Name")!="/"+name):
            raise ValueError("native image/label/identity mismatch")
        h=info["HostConfig"];state=info["State"];tmp=set(h.get("Tmpfs",{}).get("/tmp","").split(","))
        if (h.get("Memory")!=32*1024**3 or h.get("NanoCpus")!=4*10**9
                or h.get("NetworkMode")!="none" or state.get("OOMKilled") is not False
                or not {"rw","exec","uid=1000","gid=1000"}<=tmp
                or not ({"size=4g","size=4294967296"}&tmp) or "noexec" in tmp):
            raise ValueError("native actor profile mismatch")
        if self.cid is not None and (self.cid!=cid or self.name!=name):
            raise ValueError("native immutable CID changed")
        self.cid,self.name=cid,name
        if cid not in self.known_ids:self.known_ids.append(cid)
        return info

    def sample(self, phase, *, discover=True, required=False):
        with self.lock:
            row={"time":time.time(),"monotonic":time.monotonic(),"phase":phase,"container":self.cid}
            try:
                host=self.host();row["host"]=host
                if any(type(host.get(k)) not in (int,float) or not math.isfinite(host[k]) or host[k]<v
                       for k,v in FLOORS.items()):
                    raise ValueError("host resource floor violated")
                info=self.identify(required=required) if discover else None
                if info is not None:
                    row["profile"]=info;row["container"]=self.cid
                    result=self.docker(["exec",self.cid,"cat","/sys/fs/cgroup/memory.events"])
                    if result.returncode:raise ValueError("cgroup probe failed")
                    pairs=[line.split() for line in result.stdout.splitlines()]
                    if any(len(pair)!=2 for pair in pairs):raise ValueError("malformed cgroup counters")
                    events={k:int(v) for k,v in pairs}
                    if len(events)!=len(pairs) or "oom_kill" not in events or any(v<0 for v in events.values()):
                        raise ValueError("unknown cgroup counters")
                    row["memory_events"]=events;self.probes+=1
                    self.oom=max(self.oom,events["oom_kill"]+events.get("oom_group_kill",0))
                    if self.oom:raise ValueError("native OOM kill observed")
            except Exception as exc:
                row["error"]=type(exc).__name__+": "+str(exc)
                self.fault(row["error"])
            finally:
                try:
                    with (self.out/"resource-samples.jsonl").open("a") as stream:
                        stream.write(json.dumps(row)+"\n");stream.flush()
                except Exception as exc:self.fault("cannot preserve resource sample: "+str(exc))

    def proof(self, *, final=False):
        return {"complete":not self.errors and self.probes>=2 and (self.finished if final else True),
                "resource_ok":not self.errors,"cgroup_probes":self.probes,"oom_kill":self.oom,
                "errors":list(self.errors),"container_id":self.cid,"container_name":self.name,
                "observed_container_ids":list(self.known_ids),"nominal_interval_s":self.interval,
                "limits":"Sampled host and owned native cgroup observations; no continuous guarantee or peer census."}

    def before_public(self):
        self.sample("before-public",required=True)
        self.check()

    def after_public(self, command, log, code):
        self.sample("after-public",required=True)
        self.check()
        log=pathlib.Path(log)
        try:
            if log.is_symlink() or not log.resolve().is_relative_to(self.out) or not log.is_file():
                raise ValueError("public capture is not an owned regular file")
            size=log.stat().st_size
            if size>MAX_LOG_BYTES:raise ValueError("public capture exceeds bounded full-log limit")
            with log.open("rb") as stream:raw=stream.read(MAX_LOG_BYTES+1)
            if len(raw)!=size or len(raw)>MAX_LOG_BYTES:raise ValueError("public capture incomplete")
            for path,expected in self.policy_hashes.items():
                if hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()!=expected:
                    raise ValueError("public policy source drift")
            classification=classify(self.policy,raw.decode("utf-8",errors="replace"),code,self.proof())
            self.classifications.append({"command":command,"log":str(log),"bytes":len(raw),
                "sha256":hashlib.sha256(raw).hexdigest(),"exit_code":code,"classification":classification})
            self.save("public-classifications.json",{"checks":self.classifications})
            if classification.get("valid") is not True:
                raise ValueError("public verification invalid: "+str(classification.get("error")))
        except Exception as exc:
            self.fault(type(exc).__name__+": "+str(exc))
            raise

    def finish(self):
        if self.finished:
            self.check()
            return
        self.stop_monitor()
        self.sample("final",required=True)
        self.finished=True
        proof=self.proof(final=True)
        self.save("supervision-final.json",proof)
        if not proof["complete"]:
            raise ValueError("final runtime proof incomplete: "+"; ".join(self.errors))
