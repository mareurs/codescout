#![allow(dead_code, non_snake_case, non_camel_case_types, non_upper_case_globals)]
#[repr(C)]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct __BindgenBitfieldUnit<Storage> {
    storage: Storage,
}
impl<Storage> __BindgenBitfieldUnit<Storage> {
    #[inline]
    pub const fn new(storage: Storage) -> Self {
        Self { storage }
    }
}
impl<Storage> __BindgenBitfieldUnit<Storage>
where
    Storage: AsRef<[u8]> + AsMut<[u8]>,
{
    #[inline]
    fn extract_bit(byte: u8, index: usize) -> bool {
        let bit_index = if cfg!(target_endian = "big") {
            7 - (index % 8)
        } else {
            index % 8
        };
        let mask = 1 << bit_index;
        byte & mask == mask
    }
    #[inline]
    pub fn get_bit(&self, index: usize) -> bool {
        debug_assert!(index / 8 < self.storage.as_ref().len());
        let byte_index = index / 8;
        let byte = self.storage.as_ref()[byte_index];
        Self::extract_bit(byte, index)
    }
    #[inline]
    pub unsafe fn raw_get_bit(this: *const Self, index: usize) -> bool {
        debug_assert!(index / 8 < core::mem::size_of::<Storage>());
        let byte_index = index / 8;
        let byte = unsafe {
            *(core::ptr::addr_of!((*this).storage) as *const u8)
                .offset(byte_index as isize)
        };
        Self::extract_bit(byte, index)
    }
    #[inline]
    fn change_bit(byte: u8, index: usize, val: bool) -> u8 {
        let bit_index = if cfg!(target_endian = "big") {
            7 - (index % 8)
        } else {
            index % 8
        };
        let mask = 1 << bit_index;
        if val { byte | mask } else { byte & !mask }
    }
    #[inline]
    pub fn set_bit(&mut self, index: usize, val: bool) {
        debug_assert!(index / 8 < self.storage.as_ref().len());
        let byte_index = index / 8;
        let byte = &mut self.storage.as_mut()[byte_index];
        *byte = Self::change_bit(*byte, index, val);
    }
    #[inline]
    pub unsafe fn raw_set_bit(this: *mut Self, index: usize, val: bool) {
        debug_assert!(index / 8 < core::mem::size_of::<Storage>());
        let byte_index = index / 8;
        let byte = unsafe {
            (core::ptr::addr_of_mut!((*this).storage) as *mut u8)
                .offset(byte_index as isize)
        };
        unsafe { *byte = Self::change_bit(*byte, index, val) };
    }
    #[inline]
    pub fn get(&self, bit_offset: usize, bit_width: u8) -> u64 {
        debug_assert!(bit_width <= 64);
        debug_assert!(bit_offset / 8 < self.storage.as_ref().len());
        debug_assert!(
            (bit_offset + (bit_width as usize) + 7) / 8 <= self.storage.as_ref().len(),
        );
        if bit_width == 0 {
            return 0;
        }
        let mut val = 0u64;
        let storage = self.storage.as_ref();
        let start_byte = bit_offset / 8;
        let bit_shift = bit_offset % 8;
        let bytes_needed = (bit_width as usize + bit_shift + 7) / 8;
        if cfg!(target_endian = "big") {
            for i in 0..bytes_needed {
                val |= (storage[start_byte + i].reverse_bits() as u64) << (i * 8);
            }
        } else {
            for i in 0..bytes_needed {
                val |= (storage[start_byte + i] as u64) << (i * 8);
            }
        }
        val >>= bit_shift;
        if bit_width < 64 {
            val &= (1u64 << bit_width) - 1;
        }
        if cfg!(target_endian = "big") {
            val = val.reverse_bits() >> (64 - bit_width as usize);
        }
        val
    }
    #[inline]
    pub unsafe fn raw_get(this: *const Self, bit_offset: usize, bit_width: u8) -> u64 {
        debug_assert!(bit_width <= 64);
        debug_assert!(bit_offset / 8 < core::mem::size_of::<Storage>());
        debug_assert!(
            (bit_offset + (bit_width as usize) + 7) / 8
                <= core::mem::size_of::<Storage>(),
        );
        if bit_width == 0 {
            return 0;
        }
        let mut val = 0u64;
        let start_byte = bit_offset / 8;
        let bit_shift = bit_offset % 8;
        let bytes_needed = (bit_width as usize + bit_shift + 7) / 8;
        let storage_ptr = unsafe { core::ptr::addr_of!((*this).storage) as *const u8 };
        if cfg!(target_endian = "big") {
            for i in 0..bytes_needed {
                let byte = unsafe { *storage_ptr.add(start_byte + i) };
                val |= (byte.reverse_bits() as u64) << (i * 8);
            }
        } else {
            for i in 0..bytes_needed {
                let byte = unsafe { *storage_ptr.add(start_byte + i) };
                val |= (byte as u64) << (i * 8);
            }
        }
        val >>= bit_shift;
        if bit_width < 64 {
            val &= (1u64 << bit_width) - 1;
        }
        if cfg!(target_endian = "big") {
            val = val.reverse_bits() >> (64 - bit_width as usize);
        }
        val
    }
    #[inline]
    pub fn set(&mut self, bit_offset: usize, bit_width: u8, val: u64) {
        debug_assert!(bit_width <= 64);
        debug_assert!(bit_offset / 8 < self.storage.as_ref().len());
        debug_assert!(
            (bit_offset + (bit_width as usize) + 7) / 8 <= self.storage.as_ref().len(),
        );
        if bit_width == 0 {
            return;
        }
        let mut val = val;
        if bit_width < 64 {
            val &= (1u64 << bit_width) - 1;
        }
        if cfg!(target_endian = "big") {
            val = val.reverse_bits() >> (64 - bit_width as usize);
        }
        let storage = self.storage.as_mut();
        let start_byte = bit_offset / 8;
        let bit_shift = bit_offset % 8;
        let bytes_needed = (bit_width as usize + bit_shift + 7) / 8;
        val <<= bit_shift;
        let field_mask = if bit_width as usize + bit_shift >= 64 {
            !0u64 << bit_shift
        } else {
            ((1u64 << bit_width) - 1) << bit_shift
        };
        for i in 0..bytes_needed {
            let byte_val = (val >> (i * 8)) as u8;
            let byte_mask = (field_mask >> (i * 8)) as u8;
            if cfg!(target_endian = "big") {
                let byte = storage[start_byte + i].reverse_bits();
                let new_byte = (byte & !byte_mask) | (byte_val & byte_mask);
                storage[start_byte + i] = new_byte.reverse_bits();
            } else {
                storage[start_byte + i] = (storage[start_byte + i] & !byte_mask)
                    | (byte_val & byte_mask);
            }
        }
    }
    #[inline]
    pub unsafe fn raw_set(this: *mut Self, bit_offset: usize, bit_width: u8, val: u64) {
        debug_assert!(bit_width <= 64);
        debug_assert!(bit_offset / 8 < core::mem::size_of::<Storage>());
        debug_assert!(
            (bit_offset + (bit_width as usize) + 7) / 8
                <= core::mem::size_of::<Storage>(),
        );
        if bit_width == 0 {
            return;
        }
        let mut val = val;
        if bit_width < 64 {
            val &= (1u64 << bit_width) - 1;
        }
        if cfg!(target_endian = "big") {
            val = val.reverse_bits() >> (64 - bit_width as usize);
        }
        let start_byte = bit_offset / 8;
        let bit_shift = bit_offset % 8;
        let bytes_needed = (bit_width as usize + bit_shift + 7) / 8;
        val <<= bit_shift;
        let field_mask = if bit_width as usize + bit_shift >= 64 {
            !0u64 << bit_shift
        } else {
            ((1u64 << bit_width) - 1) << bit_shift
        };
        let storage_ptr = unsafe { core::ptr::addr_of_mut!((*this).storage) as *mut u8 };
        for i in 0..bytes_needed {
            let byte_val = (val >> (i * 8)) as u8;
            let byte_mask = (field_mask >> (i * 8)) as u8;
            let byte_ptr = unsafe { storage_ptr.add(start_byte + i) };
            if cfg!(target_endian = "big") {
                let byte = unsafe { (*byte_ptr).reverse_bits() };
                let new_byte = (byte & !byte_mask) | (byte_val & byte_mask);
                unsafe { *byte_ptr = new_byte.reverse_bits() };
            } else {
                unsafe { *byte_ptr = (*byte_ptr & !byte_mask) | (byte_val & byte_mask) };
            }
        }
    }
}
/// Const-generic methods for efficient bitfield access when offset and width
/// are known at compile time.
impl<const N: usize> __BindgenBitfieldUnit<[u8; N]> {
    /// Get a field using const generics for compile-time optimization.
    /// Uses native word size operations when the field fits in usize.
    #[inline]
    pub const fn get_const<const BIT_OFFSET: usize, const BIT_WIDTH: u8>(&self) -> u64 {
        debug_assert!(BIT_WIDTH <= 64);
        debug_assert!(BIT_OFFSET / 8 < N);
        debug_assert!((BIT_OFFSET + (BIT_WIDTH as usize) + 7) / 8 <= N);
        if BIT_WIDTH == 0 {
            return 0;
        }
        let start_byte = BIT_OFFSET / 8;
        let bit_shift = BIT_OFFSET % 8;
        let bytes_needed = (BIT_WIDTH as usize + bit_shift + 7) / 8;
        if BIT_WIDTH as usize + bit_shift <= usize::BITS as usize {
            let mut val = 0usize;
            if cfg!(target_endian = "big") {
                let mut i = 0;
                while i < bytes_needed {
                    val
                        |= (self.storage[start_byte + i].reverse_bits() as usize)
                            << (i * 8);
                    i += 1;
                }
            } else {
                let mut i = 0;
                while i < bytes_needed {
                    val |= (self.storage[start_byte + i] as usize) << (i * 8);
                    i += 1;
                }
            }
            val >>= bit_shift;
            if (BIT_WIDTH as u32) < usize::BITS {
                val &= (1usize << BIT_WIDTH) - 1;
            }
            if cfg!(target_endian = "big") {
                val = val.reverse_bits() >> (usize::BITS as usize - BIT_WIDTH as usize);
            }
            val as u64
        } else {
            let mut val = 0u64;
            if cfg!(target_endian = "big") {
                let mut i = 0;
                while i < bytes_needed {
                    val
                        |= (self.storage[start_byte + i].reverse_bits() as u64)
                            << (i * 8);
                    i += 1;
                }
            } else {
                let mut i = 0;
                while i < bytes_needed {
                    val |= (self.storage[start_byte + i] as u64) << (i * 8);
                    i += 1;
                }
            }
            val >>= bit_shift;
            if BIT_WIDTH < 64 {
                val &= (1u64 << BIT_WIDTH) - 1;
            }
            if cfg!(target_endian = "big") {
                val = val.reverse_bits() >> (64 - BIT_WIDTH as usize);
            }
            val
        }
    }
    /// Set a field using const generics for compile-time optimization.
    /// Uses native word size operations when the field fits in usize.
    #[inline]
    pub fn set_const<const BIT_OFFSET: usize, const BIT_WIDTH: u8>(&mut self, val: u64) {
        debug_assert!(BIT_WIDTH <= 64);
        debug_assert!(BIT_OFFSET / 8 < N);
        debug_assert!((BIT_OFFSET + (BIT_WIDTH as usize) + 7) / 8 <= N);
        if BIT_WIDTH == 0 {
            return;
        }
        let start_byte = BIT_OFFSET / 8;
        let bit_shift = BIT_OFFSET % 8;
        let bytes_needed = (BIT_WIDTH as usize + bit_shift + 7) / 8;
        if BIT_WIDTH as usize + bit_shift <= usize::BITS as usize {
            let mut val = val as usize;
            if (BIT_WIDTH as u32) < usize::BITS {
                val &= (1usize << BIT_WIDTH) - 1;
            }
            if cfg!(target_endian = "big") {
                val = val.reverse_bits() >> (usize::BITS as usize - BIT_WIDTH as usize);
            }
            val <<= bit_shift;
            let field_mask = if BIT_WIDTH as usize + bit_shift >= usize::BITS as usize {
                !0usize << bit_shift
            } else {
                ((1usize << BIT_WIDTH) - 1) << bit_shift
            };
            let mut i = 0;
            while i < bytes_needed {
                let byte_val = (val >> (i * 8)) as u8;
                let byte_mask = (field_mask >> (i * 8)) as u8;
                if cfg!(target_endian = "big") {
                    let byte = self.storage[start_byte + i].reverse_bits();
                    let new_byte = (byte & !byte_mask) | (byte_val & byte_mask);
                    self.storage[start_byte + i] = new_byte.reverse_bits();
                } else {
                    self.storage[start_byte + i] = (self.storage[start_byte + i]
                        & !byte_mask) | (byte_val & byte_mask);
                }
                i += 1;
            }
        } else {
            let mut val = val;
            if BIT_WIDTH < 64 {
                val &= (1u64 << BIT_WIDTH) - 1;
            }
            if cfg!(target_endian = "big") {
                val = val.reverse_bits() >> (64 - BIT_WIDTH as usize);
            }
            val <<= bit_shift;
            let field_mask = if BIT_WIDTH as usize + bit_shift >= 64 {
                !0u64 << bit_shift
            } else {
                ((1u64 << BIT_WIDTH) - 1) << bit_shift
            };
            let mut i = 0;
            while i < bytes_needed {
                let byte_val = (val >> (i * 8)) as u8;
                let byte_mask = (field_mask >> (i * 8)) as u8;
                if cfg!(target_endian = "big") {
                    let byte = self.storage[start_byte + i].reverse_bits();
                    let new_byte = (byte & !byte_mask) | (byte_val & byte_mask);
                    self.storage[start_byte + i] = new_byte.reverse_bits();
                } else {
                    self.storage[start_byte + i] = (self.storage[start_byte + i]
                        & !byte_mask) | (byte_val & byte_mask);
                }
                i += 1;
            }
        }
    }
    /// Raw pointer get using const generics for compile-time optimization.
    /// Uses native word size operations when the field fits in usize.
    #[inline]
    pub const unsafe fn raw_get_const<const BIT_OFFSET: usize, const BIT_WIDTH: u8>(
        this: *const Self,
    ) -> u64 {
        debug_assert!(BIT_WIDTH <= 64);
        debug_assert!(BIT_OFFSET / 8 < N);
        debug_assert!((BIT_OFFSET + (BIT_WIDTH as usize) + 7) / 8 <= N);
        if BIT_WIDTH == 0 {
            return 0;
        }
        let start_byte = BIT_OFFSET / 8;
        let bit_shift = BIT_OFFSET % 8;
        let bytes_needed = (BIT_WIDTH as usize + bit_shift + 7) / 8;
        let storage_ptr = unsafe { core::ptr::addr_of!((*this).storage) as *const u8 };
        if BIT_WIDTH as usize + bit_shift <= usize::BITS as usize {
            let mut val = 0usize;
            if cfg!(target_endian = "big") {
                let mut i = 0;
                while i < bytes_needed {
                    let byte = unsafe { *storage_ptr.add(start_byte + i) };
                    val |= (byte.reverse_bits() as usize) << (i * 8);
                    i += 1;
                }
            } else {
                let mut i = 0;
                while i < bytes_needed {
                    let byte = unsafe { *storage_ptr.add(start_byte + i) };
                    val |= (byte as usize) << (i * 8);
                    i += 1;
                }
            }
            val >>= bit_shift;
            if (BIT_WIDTH as u32) < usize::BITS {
                val &= (1usize << BIT_WIDTH) - 1;
            }
            if cfg!(target_endian = "big") {
                val = val.reverse_bits() >> (usize::BITS as usize - BIT_WIDTH as usize);
            }
            val as u64
        } else {
            let mut val = 0u64;
            if cfg!(target_endian = "big") {
                let mut i = 0;
                while i < bytes_needed {
                    let byte = unsafe { *storage_ptr.add(start_byte + i) };
                    val |= (byte.reverse_bits() as u64) << (i * 8);
                    i += 1;
                }
            } else {
                let mut i = 0;
                while i < bytes_needed {
                    let byte = unsafe { *storage_ptr.add(start_byte + i) };
                    val |= (byte as u64) << (i * 8);
                    i += 1;
                }
            }
            val >>= bit_shift;
            if BIT_WIDTH < 64 {
                val &= (1u64 << BIT_WIDTH) - 1;
            }
            if cfg!(target_endian = "big") {
                val = val.reverse_bits() >> (64 - BIT_WIDTH as usize);
            }
            val
        }
    }
    /// Raw pointer set using const generics for compile-time optimization.
    /// Uses native word size operations when the field fits in usize.
    #[inline]
    pub unsafe fn raw_set_const<const BIT_OFFSET: usize, const BIT_WIDTH: u8>(
        this: *mut Self,
        val: u64,
    ) {
        debug_assert!(BIT_WIDTH <= 64);
        debug_assert!(BIT_OFFSET / 8 < N);
        debug_assert!((BIT_OFFSET + (BIT_WIDTH as usize) + 7) / 8 <= N);
        if BIT_WIDTH == 0 {
            return;
        }
        let start_byte = BIT_OFFSET / 8;
        let bit_shift = BIT_OFFSET % 8;
        let bytes_needed = (BIT_WIDTH as usize + bit_shift + 7) / 8;
        let storage_ptr = this.cast::<[u8; N]>().cast::<u8>();
        if BIT_WIDTH as usize + bit_shift <= usize::BITS as usize {
            let mut val = val as usize;
            if (BIT_WIDTH as u32) < usize::BITS {
                val &= (1usize << BIT_WIDTH) - 1;
            }
            if cfg!(target_endian = "big") {
                val = val.reverse_bits() >> (usize::BITS as usize - BIT_WIDTH as usize);
            }
            val <<= bit_shift;
            let field_mask = if BIT_WIDTH as usize + bit_shift >= usize::BITS as usize {
                !0usize << bit_shift
            } else {
                ((1usize << BIT_WIDTH) - 1) << bit_shift
            };
            let mut i = 0;
            while i < bytes_needed {
                let byte_val = (val >> (i * 8)) as u8;
                let byte_mask = (field_mask >> (i * 8)) as u8;
                let byte_ptr = unsafe { storage_ptr.add(start_byte + i) };
                if cfg!(target_endian = "big") {
                    let byte = unsafe { (*byte_ptr).reverse_bits() };
                    let new_byte = (byte & !byte_mask) | (byte_val & byte_mask);
                    unsafe { *byte_ptr = new_byte.reverse_bits() };
                } else {
                    unsafe {
                        *byte_ptr = (*byte_ptr & !byte_mask) | (byte_val & byte_mask)
                    };
                }
                i += 1;
            }
        } else {
            let mut val = val;
            if BIT_WIDTH < 64 {
                val &= (1u64 << BIT_WIDTH) - 1;
            }
            if cfg!(target_endian = "big") {
                val = val.reverse_bits() >> (64 - BIT_WIDTH as usize);
            }
            val <<= bit_shift;
            let field_mask = if BIT_WIDTH as usize + bit_shift >= 64 {
                !0u64 << bit_shift
            } else {
                ((1u64 << BIT_WIDTH) - 1) << bit_shift
            };
            let mut i = 0;
            while i < bytes_needed {
                let byte_val = (val >> (i * 8)) as u8;
                let byte_mask = (field_mask >> (i * 8)) as u8;
                let byte_ptr = unsafe { storage_ptr.add(start_byte + i) };
                if cfg!(target_endian = "big") {
                    let byte = unsafe { (*byte_ptr).reverse_bits() };
                    let new_byte = (byte & !byte_mask) | (byte_val & byte_mask);
                    unsafe { *byte_ptr = new_byte.reverse_bits() };
                } else {
                    unsafe {
                        *byte_ptr = (*byte_ptr & !byte_mask) | (byte_val & byte_mask)
                    };
                }
                i += 1;
            }
        }
    }
}
#[repr(C)]
#[derive(Debug, Default, Copy, Clone)]
pub struct A {
    pub _bindgen_align: [u32; 0],
    pub x: ::std::os::raw::c_uchar,
    pub _bitfield_1: __BindgenBitfieldUnit<[u8; 2usize]>,
    pub y: ::std::os::raw::c_uchar,
}
#[allow(clippy::unnecessary_operation, clippy::identity_op)]
const _: () = {
    ["Size of A"][::std::mem::size_of::<A>() - 4usize];
    ["Alignment of A"][::std::mem::align_of::<A>() - 4usize];
    ["Offset of field: A::x"][::std::mem::offset_of!(A, x) - 0usize];
    ["Offset of field: A::y"][::std::mem::offset_of!(A, y) - 3usize];
};
impl A {
    #[inline]
    pub fn b1(&self) -> ::std::os::raw::c_uint {
        self._bitfield_1.get_const::<0usize, 1u8>() as u32 as _
    }
    #[inline]
    pub fn set_b1(&mut self, val: ::std::os::raw::c_uint) {
        let val: u32 = val as _;
        self._bitfield_1.set_const::<0usize, 1u8>(val as u64)
    }
    #[inline]
    pub unsafe fn b1_raw(this: *const Self) -> ::std::os::raw::c_uint {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 2usize],
            >>::raw_get_const::<0usize, 1u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u32 as _
        }
    }
    #[inline]
    pub unsafe fn set_b1_raw(this: *mut Self, val: ::std::os::raw::c_uint) {
        unsafe {
            let val: u32 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 2usize],
            >>::raw_set_const::<
                0usize,
                1u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn b2(&self) -> ::std::os::raw::c_uint {
        self._bitfield_1.get_const::<1usize, 1u8>() as u32 as _
    }
    #[inline]
    pub fn set_b2(&mut self, val: ::std::os::raw::c_uint) {
        let val: u32 = val as _;
        self._bitfield_1.set_const::<1usize, 1u8>(val as u64)
    }
    #[inline]
    pub unsafe fn b2_raw(this: *const Self) -> ::std::os::raw::c_uint {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 2usize],
            >>::raw_get_const::<1usize, 1u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u32 as _
        }
    }
    #[inline]
    pub unsafe fn set_b2_raw(this: *mut Self, val: ::std::os::raw::c_uint) {
        unsafe {
            let val: u32 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 2usize],
            >>::raw_set_const::<
                1usize,
                1u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn b3(&self) -> ::std::os::raw::c_uint {
        self._bitfield_1.get_const::<2usize, 1u8>() as u32 as _
    }
    #[inline]
    pub fn set_b3(&mut self, val: ::std::os::raw::c_uint) {
        let val: u32 = val as _;
        self._bitfield_1.set_const::<2usize, 1u8>(val as u64)
    }
    #[inline]
    pub unsafe fn b3_raw(this: *const Self) -> ::std::os::raw::c_uint {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 2usize],
            >>::raw_get_const::<2usize, 1u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u32 as _
        }
    }
    #[inline]
    pub unsafe fn set_b3_raw(this: *mut Self, val: ::std::os::raw::c_uint) {
        unsafe {
            let val: u32 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 2usize],
            >>::raw_set_const::<
                2usize,
                1u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn b4(&self) -> ::std::os::raw::c_uint {
        self._bitfield_1.get_const::<3usize, 1u8>() as u32 as _
    }
    #[inline]
    pub fn set_b4(&mut self, val: ::std::os::raw::c_uint) {
        let val: u32 = val as _;
        self._bitfield_1.set_const::<3usize, 1u8>(val as u64)
    }
    #[inline]
    pub unsafe fn b4_raw(this: *const Self) -> ::std::os::raw::c_uint {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 2usize],
            >>::raw_get_const::<3usize, 1u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u32 as _
        }
    }
    #[inline]
    pub unsafe fn set_b4_raw(this: *mut Self, val: ::std::os::raw::c_uint) {
        unsafe {
            let val: u32 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 2usize],
            >>::raw_set_const::<
                3usize,
                1u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn b5(&self) -> ::std::os::raw::c_uint {
        self._bitfield_1.get_const::<4usize, 1u8>() as u32 as _
    }
    #[inline]
    pub fn set_b5(&mut self, val: ::std::os::raw::c_uint) {
        let val: u32 = val as _;
        self._bitfield_1.set_const::<4usize, 1u8>(val as u64)
    }
    #[inline]
    pub unsafe fn b5_raw(this: *const Self) -> ::std::os::raw::c_uint {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 2usize],
            >>::raw_get_const::<4usize, 1u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u32 as _
        }
    }
    #[inline]
    pub unsafe fn set_b5_raw(this: *mut Self, val: ::std::os::raw::c_uint) {
        unsafe {
            let val: u32 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 2usize],
            >>::raw_set_const::<
                4usize,
                1u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn b6(&self) -> ::std::os::raw::c_uint {
        self._bitfield_1.get_const::<5usize, 1u8>() as u32 as _
    }
    #[inline]
    pub fn set_b6(&mut self, val: ::std::os::raw::c_uint) {
        let val: u32 = val as _;
        self._bitfield_1.set_const::<5usize, 1u8>(val as u64)
    }
    #[inline]
    pub unsafe fn b6_raw(this: *const Self) -> ::std::os::raw::c_uint {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 2usize],
            >>::raw_get_const::<5usize, 1u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u32 as _
        }
    }
    #[inline]
    pub unsafe fn set_b6_raw(this: *mut Self, val: ::std::os::raw::c_uint) {
        unsafe {
            let val: u32 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 2usize],
            >>::raw_set_const::<
                5usize,
                1u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn b7(&self) -> ::std::os::raw::c_uint {
        self._bitfield_1.get_const::<6usize, 1u8>() as u32 as _
    }
    #[inline]
    pub fn set_b7(&mut self, val: ::std::os::raw::c_uint) {
        let val: u32 = val as _;
        self._bitfield_1.set_const::<6usize, 1u8>(val as u64)
    }
    #[inline]
    pub unsafe fn b7_raw(this: *const Self) -> ::std::os::raw::c_uint {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 2usize],
            >>::raw_get_const::<6usize, 1u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u32 as _
        }
    }
    #[inline]
    pub unsafe fn set_b7_raw(this: *mut Self, val: ::std::os::raw::c_uint) {
        unsafe {
            let val: u32 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 2usize],
            >>::raw_set_const::<
                6usize,
                1u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn b8(&self) -> ::std::os::raw::c_uint {
        self._bitfield_1.get_const::<7usize, 1u8>() as u32 as _
    }
    #[inline]
    pub fn set_b8(&mut self, val: ::std::os::raw::c_uint) {
        let val: u32 = val as _;
        self._bitfield_1.set_const::<7usize, 1u8>(val as u64)
    }
    #[inline]
    pub unsafe fn b8_raw(this: *const Self) -> ::std::os::raw::c_uint {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 2usize],
            >>::raw_get_const::<7usize, 1u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u32 as _
        }
    }
    #[inline]
    pub unsafe fn set_b8_raw(this: *mut Self, val: ::std::os::raw::c_uint) {
        unsafe {
            let val: u32 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 2usize],
            >>::raw_set_const::<
                7usize,
                1u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn b9(&self) -> ::std::os::raw::c_uint {
        self._bitfield_1.get_const::<8usize, 1u8>() as u32 as _
    }
    #[inline]
    pub fn set_b9(&mut self, val: ::std::os::raw::c_uint) {
        let val: u32 = val as _;
        self._bitfield_1.set_const::<8usize, 1u8>(val as u64)
    }
    #[inline]
    pub unsafe fn b9_raw(this: *const Self) -> ::std::os::raw::c_uint {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 2usize],
            >>::raw_get_const::<8usize, 1u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u32 as _
        }
    }
    #[inline]
    pub unsafe fn set_b9_raw(this: *mut Self, val: ::std::os::raw::c_uint) {
        unsafe {
            let val: u32 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 2usize],
            >>::raw_set_const::<
                8usize,
                1u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn b10(&self) -> ::std::os::raw::c_uint {
        self._bitfield_1.get_const::<9usize, 1u8>() as u32 as _
    }
    #[inline]
    pub fn set_b10(&mut self, val: ::std::os::raw::c_uint) {
        let val: u32 = val as _;
        self._bitfield_1.set_const::<9usize, 1u8>(val as u64)
    }
    #[inline]
    pub unsafe fn b10_raw(this: *const Self) -> ::std::os::raw::c_uint {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 2usize],
            >>::raw_get_const::<9usize, 1u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u32 as _
        }
    }
    #[inline]
    pub unsafe fn set_b10_raw(this: *mut Self, val: ::std::os::raw::c_uint) {
        unsafe {
            let val: u32 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 2usize],
            >>::raw_set_const::<
                9usize,
                1u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn new_bitfield_1(
        b1: ::std::os::raw::c_uint,
        b2: ::std::os::raw::c_uint,
        b3: ::std::os::raw::c_uint,
        b4: ::std::os::raw::c_uint,
        b5: ::std::os::raw::c_uint,
        b6: ::std::os::raw::c_uint,
        b7: ::std::os::raw::c_uint,
        b8: ::std::os::raw::c_uint,
        b9: ::std::os::raw::c_uint,
        b10: ::std::os::raw::c_uint,
    ) -> __BindgenBitfieldUnit<[u8; 2usize]> {
        let mut __bindgen_bitfield_unit: __BindgenBitfieldUnit<[u8; 2usize]> = Default::default();
        __bindgen_bitfield_unit
            .set_const::<
                0usize,
                1u8,
            >({
                let b1: u32 = b1 as _;
                b1 as u64
            });
        __bindgen_bitfield_unit
            .set_const::<
                1usize,
                1u8,
            >({
                let b2: u32 = b2 as _;
                b2 as u64
            });
        __bindgen_bitfield_unit
            .set_const::<
                2usize,
                1u8,
            >({
                let b3: u32 = b3 as _;
                b3 as u64
            });
        __bindgen_bitfield_unit
            .set_const::<
                3usize,
                1u8,
            >({
                let b4: u32 = b4 as _;
                b4 as u64
            });
        __bindgen_bitfield_unit
            .set_const::<
                4usize,
                1u8,
            >({
                let b5: u32 = b5 as _;
                b5 as u64
            });
        __bindgen_bitfield_unit
            .set_const::<
                5usize,
                1u8,
            >({
                let b6: u32 = b6 as _;
                b6 as u64
            });
        __bindgen_bitfield_unit
            .set_const::<
                6usize,
                1u8,
            >({
                let b7: u32 = b7 as _;
                b7 as u64
            });
        __bindgen_bitfield_unit
            .set_const::<
                7usize,
                1u8,
            >({
                let b8: u32 = b8 as _;
                b8 as u64
            });
        __bindgen_bitfield_unit
            .set_const::<
                8usize,
                1u8,
            >({
                let b9: u32 = b9 as _;
                b9 as u64
            });
        __bindgen_bitfield_unit
            .set_const::<
                9usize,
                1u8,
            >({
                let b10: u32 = b10 as _;
                b10 as u64
            });
        __bindgen_bitfield_unit
    }
}
#[repr(C)]
#[derive(Debug, Default, Copy, Clone)]
pub struct B {
    pub _bindgen_align: [u32; 0],
    pub _bitfield_1: __BindgenBitfieldUnit<[u8; 4usize]>,
}
#[allow(clippy::unnecessary_operation, clippy::identity_op)]
const _: () = {
    ["Size of B"][::std::mem::size_of::<B>() - 4usize];
    ["Alignment of B"][::std::mem::align_of::<B>() - 4usize];
};
impl B {
    #[inline]
    pub fn foo(&self) -> ::std::os::raw::c_uint {
        self._bitfield_1.get_const::<0usize, 31u8>() as u32 as _
    }
    #[inline]
    pub fn set_foo(&mut self, val: ::std::os::raw::c_uint) {
        let val: u32 = val as _;
        self._bitfield_1.set_const::<0usize, 31u8>(val as u64)
    }
    #[inline]
    pub unsafe fn foo_raw(this: *const Self) -> ::std::os::raw::c_uint {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 4usize],
            >>::raw_get_const::<0usize, 31u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u32 as _
        }
    }
    #[inline]
    pub unsafe fn set_foo_raw(this: *mut Self, val: ::std::os::raw::c_uint) {
        unsafe {
            let val: u32 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 4usize],
            >>::raw_set_const::<
                0usize,
                31u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn bar(&self) -> ::std::os::raw::c_uchar {
        self._bitfield_1.get_const::<31usize, 1u8>() as u8 as _
    }
    #[inline]
    pub fn set_bar(&mut self, val: ::std::os::raw::c_uchar) {
        let val: u8 = val as _;
        self._bitfield_1.set_const::<31usize, 1u8>(val as u64)
    }
    #[inline]
    pub unsafe fn bar_raw(this: *const Self) -> ::std::os::raw::c_uchar {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 4usize],
            >>::raw_get_const::<31usize, 1u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u8 as _
        }
    }
    #[inline]
    pub unsafe fn set_bar_raw(this: *mut Self, val: ::std::os::raw::c_uchar) {
        unsafe {
            let val: u8 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 4usize],
            >>::raw_set_const::<
                31usize,
                1u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn new_bitfield_1(
        foo: ::std::os::raw::c_uint,
        bar: ::std::os::raw::c_uchar,
    ) -> __BindgenBitfieldUnit<[u8; 4usize]> {
        let mut __bindgen_bitfield_unit: __BindgenBitfieldUnit<[u8; 4usize]> = Default::default();
        __bindgen_bitfield_unit
            .set_const::<
                0usize,
                31u8,
            >({
                let foo: u32 = foo as _;
                foo as u64
            });
        __bindgen_bitfield_unit
            .set_const::<
                31usize,
                1u8,
            >({
                let bar: u8 = bar as _;
                bar as u64
            });
        __bindgen_bitfield_unit
    }
}
#[repr(C)]
#[derive(Debug, Default, Copy, Clone)]
pub struct C {
    pub x: ::std::os::raw::c_uchar,
    pub _bitfield_1: __BindgenBitfieldUnit<[u8; 1usize]>,
    pub baz: ::std::os::raw::c_uint,
}
#[allow(clippy::unnecessary_operation, clippy::identity_op)]
const _: () = {
    ["Size of C"][::std::mem::size_of::<C>() - 8usize];
    ["Alignment of C"][::std::mem::align_of::<C>() - 4usize];
    ["Offset of field: C::x"][::std::mem::offset_of!(C, x) - 0usize];
    ["Offset of field: C::baz"][::std::mem::offset_of!(C, baz) - 4usize];
};
impl C {
    #[inline]
    pub fn b1(&self) -> ::std::os::raw::c_uint {
        self._bitfield_1.get_const::<0usize, 1u8>() as u32 as _
    }
    #[inline]
    pub fn set_b1(&mut self, val: ::std::os::raw::c_uint) {
        let val: u32 = val as _;
        self._bitfield_1.set_const::<0usize, 1u8>(val as u64)
    }
    #[inline]
    pub unsafe fn b1_raw(this: *const Self) -> ::std::os::raw::c_uint {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 1usize],
            >>::raw_get_const::<0usize, 1u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u32 as _
        }
    }
    #[inline]
    pub unsafe fn set_b1_raw(this: *mut Self, val: ::std::os::raw::c_uint) {
        unsafe {
            let val: u32 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 1usize],
            >>::raw_set_const::<
                0usize,
                1u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn b2(&self) -> ::std::os::raw::c_uint {
        self._bitfield_1.get_const::<1usize, 1u8>() as u32 as _
    }
    #[inline]
    pub fn set_b2(&mut self, val: ::std::os::raw::c_uint) {
        let val: u32 = val as _;
        self._bitfield_1.set_const::<1usize, 1u8>(val as u64)
    }
    #[inline]
    pub unsafe fn b2_raw(this: *const Self) -> ::std::os::raw::c_uint {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 1usize],
            >>::raw_get_const::<1usize, 1u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u32 as _
        }
    }
    #[inline]
    pub unsafe fn set_b2_raw(this: *mut Self, val: ::std::os::raw::c_uint) {
        unsafe {
            let val: u32 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 1usize],
            >>::raw_set_const::<
                1usize,
                1u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn new_bitfield_1(
        b1: ::std::os::raw::c_uint,
        b2: ::std::os::raw::c_uint,
    ) -> __BindgenBitfieldUnit<[u8; 1usize]> {
        let mut __bindgen_bitfield_unit: __BindgenBitfieldUnit<[u8; 1usize]> = Default::default();
        __bindgen_bitfield_unit
            .set_const::<
                0usize,
                1u8,
            >({
                let b1: u32 = b1 as _;
                b1 as u64
            });
        __bindgen_bitfield_unit
            .set_const::<
                1usize,
                1u8,
            >({
                let b2: u32 = b2 as _;
                b2 as u64
            });
        __bindgen_bitfield_unit
    }
}
#[repr(C)]
#[derive(Debug, Default, Copy, Clone)]
pub struct Date1 {
    pub _bindgen_align: [u16; 0],
    pub _bitfield_1: __BindgenBitfieldUnit<[u8; 3usize]>,
    pub __bindgen_padding_0: u8,
}
#[allow(clippy::unnecessary_operation, clippy::identity_op)]
const _: () = {
    ["Size of Date1"][::std::mem::size_of::<Date1>() - 4usize];
    ["Alignment of Date1"][::std::mem::align_of::<Date1>() - 2usize];
};
impl Date1 {
    #[inline]
    pub fn nWeekDay(&self) -> ::std::os::raw::c_ushort {
        self._bitfield_1.get_const::<0usize, 3u8>() as u16 as _
    }
    #[inline]
    pub fn set_nWeekDay(&mut self, val: ::std::os::raw::c_ushort) {
        let val: u16 = val as _;
        self._bitfield_1.set_const::<0usize, 3u8>(val as u64)
    }
    #[inline]
    pub unsafe fn nWeekDay_raw(this: *const Self) -> ::std::os::raw::c_ushort {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 3usize],
            >>::raw_get_const::<0usize, 3u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u16 as _
        }
    }
    #[inline]
    pub unsafe fn set_nWeekDay_raw(this: *mut Self, val: ::std::os::raw::c_ushort) {
        unsafe {
            let val: u16 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 3usize],
            >>::raw_set_const::<
                0usize,
                3u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn nMonthDay(&self) -> ::std::os::raw::c_ushort {
        self._bitfield_1.get_const::<3usize, 6u8>() as u16 as _
    }
    #[inline]
    pub fn set_nMonthDay(&mut self, val: ::std::os::raw::c_ushort) {
        let val: u16 = val as _;
        self._bitfield_1.set_const::<3usize, 6u8>(val as u64)
    }
    #[inline]
    pub unsafe fn nMonthDay_raw(this: *const Self) -> ::std::os::raw::c_ushort {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 3usize],
            >>::raw_get_const::<3usize, 6u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u16 as _
        }
    }
    #[inline]
    pub unsafe fn set_nMonthDay_raw(this: *mut Self, val: ::std::os::raw::c_ushort) {
        unsafe {
            let val: u16 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 3usize],
            >>::raw_set_const::<
                3usize,
                6u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn nMonth(&self) -> ::std::os::raw::c_ushort {
        self._bitfield_1.get_const::<9usize, 5u8>() as u16 as _
    }
    #[inline]
    pub fn set_nMonth(&mut self, val: ::std::os::raw::c_ushort) {
        let val: u16 = val as _;
        self._bitfield_1.set_const::<9usize, 5u8>(val as u64)
    }
    #[inline]
    pub unsafe fn nMonth_raw(this: *const Self) -> ::std::os::raw::c_ushort {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 3usize],
            >>::raw_get_const::<9usize, 5u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u16 as _
        }
    }
    #[inline]
    pub unsafe fn set_nMonth_raw(this: *mut Self, val: ::std::os::raw::c_ushort) {
        unsafe {
            let val: u16 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 3usize],
            >>::raw_set_const::<
                9usize,
                5u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn nYear(&self) -> ::std::os::raw::c_ushort {
        self._bitfield_1.get_const::<16usize, 8u8>() as u16 as _
    }
    #[inline]
    pub fn set_nYear(&mut self, val: ::std::os::raw::c_ushort) {
        let val: u16 = val as _;
        self._bitfield_1.set_const::<16usize, 8u8>(val as u64)
    }
    #[inline]
    pub unsafe fn nYear_raw(this: *const Self) -> ::std::os::raw::c_ushort {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 3usize],
            >>::raw_get_const::<16usize, 8u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u16 as _
        }
    }
    #[inline]
    pub unsafe fn set_nYear_raw(this: *mut Self, val: ::std::os::raw::c_ushort) {
        unsafe {
            let val: u16 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 3usize],
            >>::raw_set_const::<
                16usize,
                8u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn new_bitfield_1(
        nWeekDay: ::std::os::raw::c_ushort,
        nMonthDay: ::std::os::raw::c_ushort,
        nMonth: ::std::os::raw::c_ushort,
        nYear: ::std::os::raw::c_ushort,
    ) -> __BindgenBitfieldUnit<[u8; 3usize]> {
        let mut __bindgen_bitfield_unit: __BindgenBitfieldUnit<[u8; 3usize]> = Default::default();
        __bindgen_bitfield_unit
            .set_const::<
                0usize,
                3u8,
            >({
                let nWeekDay: u16 = nWeekDay as _;
                nWeekDay as u64
            });
        __bindgen_bitfield_unit
            .set_const::<
                3usize,
                6u8,
            >({
                let nMonthDay: u16 = nMonthDay as _;
                nMonthDay as u64
            });
        __bindgen_bitfield_unit
            .set_const::<
                9usize,
                5u8,
            >({
                let nMonth: u16 = nMonth as _;
                nMonth as u64
            });
        __bindgen_bitfield_unit
            .set_const::<
                16usize,
                8u8,
            >({
                let nYear: u16 = nYear as _;
                nYear as u64
            });
        __bindgen_bitfield_unit
    }
}
#[repr(C)]
#[derive(Debug, Default, Copy, Clone)]
pub struct Date2 {
    pub _bindgen_align: [u16; 0],
    pub _bitfield_1: __BindgenBitfieldUnit<[u8; 4usize]>,
}
#[allow(clippy::unnecessary_operation, clippy::identity_op)]
const _: () = {
    ["Size of Date2"][::std::mem::size_of::<Date2>() - 4usize];
    ["Alignment of Date2"][::std::mem::align_of::<Date2>() - 2usize];
};
impl Date2 {
    #[inline]
    pub fn nWeekDay(&self) -> ::std::os::raw::c_ushort {
        self._bitfield_1.get_const::<0usize, 3u8>() as u16 as _
    }
    #[inline]
    pub fn set_nWeekDay(&mut self, val: ::std::os::raw::c_ushort) {
        let val: u16 = val as _;
        self._bitfield_1.set_const::<0usize, 3u8>(val as u64)
    }
    #[inline]
    pub unsafe fn nWeekDay_raw(this: *const Self) -> ::std::os::raw::c_ushort {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 4usize],
            >>::raw_get_const::<0usize, 3u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u16 as _
        }
    }
    #[inline]
    pub unsafe fn set_nWeekDay_raw(this: *mut Self, val: ::std::os::raw::c_ushort) {
        unsafe {
            let val: u16 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 4usize],
            >>::raw_set_const::<
                0usize,
                3u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn nMonthDay(&self) -> ::std::os::raw::c_ushort {
        self._bitfield_1.get_const::<3usize, 6u8>() as u16 as _
    }
    #[inline]
    pub fn set_nMonthDay(&mut self, val: ::std::os::raw::c_ushort) {
        let val: u16 = val as _;
        self._bitfield_1.set_const::<3usize, 6u8>(val as u64)
    }
    #[inline]
    pub unsafe fn nMonthDay_raw(this: *const Self) -> ::std::os::raw::c_ushort {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 4usize],
            >>::raw_get_const::<3usize, 6u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u16 as _
        }
    }
    #[inline]
    pub unsafe fn set_nMonthDay_raw(this: *mut Self, val: ::std::os::raw::c_ushort) {
        unsafe {
            let val: u16 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 4usize],
            >>::raw_set_const::<
                3usize,
                6u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn nMonth(&self) -> ::std::os::raw::c_ushort {
        self._bitfield_1.get_const::<9usize, 5u8>() as u16 as _
    }
    #[inline]
    pub fn set_nMonth(&mut self, val: ::std::os::raw::c_ushort) {
        let val: u16 = val as _;
        self._bitfield_1.set_const::<9usize, 5u8>(val as u64)
    }
    #[inline]
    pub unsafe fn nMonth_raw(this: *const Self) -> ::std::os::raw::c_ushort {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 4usize],
            >>::raw_get_const::<9usize, 5u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u16 as _
        }
    }
    #[inline]
    pub unsafe fn set_nMonth_raw(this: *mut Self, val: ::std::os::raw::c_ushort) {
        unsafe {
            let val: u16 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 4usize],
            >>::raw_set_const::<
                9usize,
                5u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn nYear(&self) -> ::std::os::raw::c_ushort {
        self._bitfield_1.get_const::<16usize, 8u8>() as u16 as _
    }
    #[inline]
    pub fn set_nYear(&mut self, val: ::std::os::raw::c_ushort) {
        let val: u16 = val as _;
        self._bitfield_1.set_const::<16usize, 8u8>(val as u64)
    }
    #[inline]
    pub unsafe fn nYear_raw(this: *const Self) -> ::std::os::raw::c_ushort {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 4usize],
            >>::raw_get_const::<16usize, 8u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u16 as _
        }
    }
    #[inline]
    pub unsafe fn set_nYear_raw(this: *mut Self, val: ::std::os::raw::c_ushort) {
        unsafe {
            let val: u16 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 4usize],
            >>::raw_set_const::<
                16usize,
                8u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn byte(&self) -> ::std::os::raw::c_uchar {
        self._bitfield_1.get_const::<24usize, 8u8>() as u8 as _
    }
    #[inline]
    pub fn set_byte(&mut self, val: ::std::os::raw::c_uchar) {
        let val: u8 = val as _;
        self._bitfield_1.set_const::<24usize, 8u8>(val as u64)
    }
    #[inline]
    pub unsafe fn byte_raw(this: *const Self) -> ::std::os::raw::c_uchar {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 4usize],
            >>::raw_get_const::<24usize, 8u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u8 as _
        }
    }
    #[inline]
    pub unsafe fn set_byte_raw(this: *mut Self, val: ::std::os::raw::c_uchar) {
        unsafe {
            let val: u8 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 4usize],
            >>::raw_set_const::<
                24usize,
                8u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn new_bitfield_1(
        nWeekDay: ::std::os::raw::c_ushort,
        nMonthDay: ::std::os::raw::c_ushort,
        nMonth: ::std::os::raw::c_ushort,
        nYear: ::std::os::raw::c_ushort,
        byte: ::std::os::raw::c_uchar,
    ) -> __BindgenBitfieldUnit<[u8; 4usize]> {
        let mut __bindgen_bitfield_unit: __BindgenBitfieldUnit<[u8; 4usize]> = Default::default();
        __bindgen_bitfield_unit
            .set_const::<
                0usize,
                3u8,
            >({
                let nWeekDay: u16 = nWeekDay as _;
                nWeekDay as u64
            });
        __bindgen_bitfield_unit
            .set_const::<
                3usize,
                6u8,
            >({
                let nMonthDay: u16 = nMonthDay as _;
                nMonthDay as u64
            });
        __bindgen_bitfield_unit
            .set_const::<
                9usize,
                5u8,
            >({
                let nMonth: u16 = nMonth as _;
                nMonth as u64
            });
        __bindgen_bitfield_unit
            .set_const::<
                16usize,
                8u8,
            >({
                let nYear: u16 = nYear as _;
                nYear as u64
            });
        __bindgen_bitfield_unit
            .set_const::<
                24usize,
                8u8,
            >({
                let byte: u8 = byte as _;
                byte as u64
            });
        __bindgen_bitfield_unit
    }
}
#[repr(C)]
#[derive(Debug, Default, Copy, Clone)]
pub struct Date3 {
    pub _bindgen_align: [u16; 0],
    pub _bitfield_1: __BindgenBitfieldUnit<[u8; 3usize]>,
    pub byte: ::std::os::raw::c_uchar,
}
#[allow(clippy::unnecessary_operation, clippy::identity_op)]
const _: () = {
    ["Size of Date3"][::std::mem::size_of::<Date3>() - 4usize];
    ["Alignment of Date3"][::std::mem::align_of::<Date3>() - 2usize];
    ["Offset of field: Date3::byte"][::std::mem::offset_of!(Date3, byte) - 3usize];
};
impl Date3 {
    #[inline]
    pub fn nWeekDay(&self) -> ::std::os::raw::c_ushort {
        self._bitfield_1.get_const::<0usize, 3u8>() as u16 as _
    }
    #[inline]
    pub fn set_nWeekDay(&mut self, val: ::std::os::raw::c_ushort) {
        let val: u16 = val as _;
        self._bitfield_1.set_const::<0usize, 3u8>(val as u64)
    }
    #[inline]
    pub unsafe fn nWeekDay_raw(this: *const Self) -> ::std::os::raw::c_ushort {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 3usize],
            >>::raw_get_const::<0usize, 3u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u16 as _
        }
    }
    #[inline]
    pub unsafe fn set_nWeekDay_raw(this: *mut Self, val: ::std::os::raw::c_ushort) {
        unsafe {
            let val: u16 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 3usize],
            >>::raw_set_const::<
                0usize,
                3u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn nMonthDay(&self) -> ::std::os::raw::c_ushort {
        self._bitfield_1.get_const::<3usize, 6u8>() as u16 as _
    }
    #[inline]
    pub fn set_nMonthDay(&mut self, val: ::std::os::raw::c_ushort) {
        let val: u16 = val as _;
        self._bitfield_1.set_const::<3usize, 6u8>(val as u64)
    }
    #[inline]
    pub unsafe fn nMonthDay_raw(this: *const Self) -> ::std::os::raw::c_ushort {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 3usize],
            >>::raw_get_const::<3usize, 6u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u16 as _
        }
    }
    #[inline]
    pub unsafe fn set_nMonthDay_raw(this: *mut Self, val: ::std::os::raw::c_ushort) {
        unsafe {
            let val: u16 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 3usize],
            >>::raw_set_const::<
                3usize,
                6u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn nMonth(&self) -> ::std::os::raw::c_ushort {
        self._bitfield_1.get_const::<9usize, 5u8>() as u16 as _
    }
    #[inline]
    pub fn set_nMonth(&mut self, val: ::std::os::raw::c_ushort) {
        let val: u16 = val as _;
        self._bitfield_1.set_const::<9usize, 5u8>(val as u64)
    }
    #[inline]
    pub unsafe fn nMonth_raw(this: *const Self) -> ::std::os::raw::c_ushort {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 3usize],
            >>::raw_get_const::<9usize, 5u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u16 as _
        }
    }
    #[inline]
    pub unsafe fn set_nMonth_raw(this: *mut Self, val: ::std::os::raw::c_ushort) {
        unsafe {
            let val: u16 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 3usize],
            >>::raw_set_const::<
                9usize,
                5u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn nYear(&self) -> ::std::os::raw::c_ushort {
        self._bitfield_1.get_const::<16usize, 8u8>() as u16 as _
    }
    #[inline]
    pub fn set_nYear(&mut self, val: ::std::os::raw::c_ushort) {
        let val: u16 = val as _;
        self._bitfield_1.set_const::<16usize, 8u8>(val as u64)
    }
    #[inline]
    pub unsafe fn nYear_raw(this: *const Self) -> ::std::os::raw::c_ushort {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 3usize],
            >>::raw_get_const::<16usize, 8u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u16 as _
        }
    }
    #[inline]
    pub unsafe fn set_nYear_raw(this: *mut Self, val: ::std::os::raw::c_ushort) {
        unsafe {
            let val: u16 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 3usize],
            >>::raw_set_const::<
                16usize,
                8u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn new_bitfield_1(
        nWeekDay: ::std::os::raw::c_ushort,
        nMonthDay: ::std::os::raw::c_ushort,
        nMonth: ::std::os::raw::c_ushort,
        nYear: ::std::os::raw::c_ushort,
    ) -> __BindgenBitfieldUnit<[u8; 3usize]> {
        let mut __bindgen_bitfield_unit: __BindgenBitfieldUnit<[u8; 3usize]> = Default::default();
        __bindgen_bitfield_unit
            .set_const::<
                0usize,
                3u8,
            >({
                let nWeekDay: u16 = nWeekDay as _;
                nWeekDay as u64
            });
        __bindgen_bitfield_unit
            .set_const::<
                3usize,
                6u8,
            >({
                let nMonthDay: u16 = nMonthDay as _;
                nMonthDay as u64
            });
        __bindgen_bitfield_unit
            .set_const::<
                9usize,
                5u8,
            >({
                let nMonth: u16 = nMonth as _;
                nMonth as u64
            });
        __bindgen_bitfield_unit
            .set_const::<
                16usize,
                8u8,
            >({
                let nYear: u16 = nYear as _;
                nYear as u64
            });
        __bindgen_bitfield_unit
    }
}
