#![allow(dead_code, non_snake_case, non_camel_case_types, non_upper_case_globals)]
#[path = "./struct_with_bitfields.rs"]
mod bitfields;
use bitfields::*;
#[repr(C)]
#[derive(Debug, Default, Copy, Clone)]
pub struct C {
    pub x: ::std::os::raw::c_uchar,
    pub _bitfield_1: __BindgenBitfieldUnit<[u8; 1usize]>,
    pub baz: ::std::os::raw::c_uint,
}
#[allow(clippy::unnecessary_operation, clippy::identity_op)]
const _: () = {
    ["Size of C"][::std::mem::size_of::<C>() - 8usize];
    ["Alignment of C"][::std::mem::align_of::<C>() - 4usize];
    ["Offset of field: C::x"][::std::mem::offset_of!(C, x) - 0usize];
    ["Offset of field: C::baz"][::std::mem::offset_of!(C, baz) - 4usize];
};
impl C {
    #[inline]
    pub fn b1(&self) -> ::std::os::raw::c_uint {
        self._bitfield_1.get_const::<0usize, 1u8>() as u32 as _
    }
    #[inline]
    pub fn set_b1(&mut self, val: ::std::os::raw::c_uint) {
        let val: u32 = val as _;
        self._bitfield_1.set_const::<0usize, 1u8>(val as u64)
    }
    #[inline]
    pub unsafe fn b1_raw(this: *const Self) -> ::std::os::raw::c_uint {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 1usize],
            >>::raw_get_const::<0usize, 1u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u32 as _
        }
    }
    #[inline]
    pub unsafe fn set_b1_raw(this: *mut Self, val: ::std::os::raw::c_uint) {
        unsafe {
            let val: u32 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 1usize],
            >>::raw_set_const::<
                0usize,
                1u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn b2(&self) -> ::std::os::raw::c_uint {
        self._bitfield_1.get_const::<1usize, 1u8>() as u32 as _
    }
    #[inline]
    pub fn set_b2(&mut self, val: ::std::os::raw::c_uint) {
        let val: u32 = val as _;
        self._bitfield_1.set_const::<1usize, 1u8>(val as u64)
    }
    #[inline]
    pub unsafe fn b2_raw(this: *const Self) -> ::std::os::raw::c_uint {
        unsafe {
            <__BindgenBitfieldUnit<
                [u8; 1usize],
            >>::raw_get_const::<1usize, 1u8>(::std::ptr::addr_of!((*this)._bitfield_1))
                as u32 as _
        }
    }
    #[inline]
    pub unsafe fn set_b2_raw(this: *mut Self, val: ::std::os::raw::c_uint) {
        unsafe {
            let val: u32 = val as _;
            <__BindgenBitfieldUnit<
                [u8; 1usize],
            >>::raw_set_const::<
                1usize,
                1u8,
            >(::std::ptr::addr_of_mut!((*this)._bitfield_1), val as u64)
        }
    }
    #[inline]
    pub fn new_bitfield_1(
        b1: ::std::os::raw::c_uint,
        b2: ::std::os::raw::c_uint,
    ) -> __BindgenBitfieldUnit<[u8; 1usize]> {
        let mut __bindgen_bitfield_unit: __BindgenBitfieldUnit<[u8; 1usize]> = Default::default();
        __bindgen_bitfield_unit
            .set_const::<
                0usize,
                1u8,
            >({
                let b1: u32 = b1 as _;
                b1 as u64
            });
        __bindgen_bitfield_unit
            .set_const::<
                1usize,
                1u8,
            >({
                let b2: u32 = b2 as _;
                b2 as u64
            });
        __bindgen_bitfield_unit
    }
}
