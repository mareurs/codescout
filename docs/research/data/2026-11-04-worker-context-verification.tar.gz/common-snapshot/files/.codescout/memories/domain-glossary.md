## Terms
- libclang — LLVM's C API that bindgen uses to parse headers (via `clang-sys`); needs >= 9 (`book/src/requirements.md`). Used by bindgen, bindgen-cli, bindgen-tests, bindgen-integration.
- IR — internal representation of parsed items, built in `bindgen/ir/`; see project bindgen glossary for details.
- Builder — `bindgen::Builder`, the config object used by the CLI, tests and build scripts alike.
- Expectation — checked-in output snapshot under `bindgen-tests/tests/expectations/tests/` that bindgen output is compared with.
- bindgen-flags — `// bindgen-flags:` header comment giving CLI flags to a test (bindgen-tests; same flag grammar as bindgen-cli via `builder_from_flags`).
- ParseCallbacks — user hook trait (`bindgen/callbacks.rs`) exercised in bindgen-integration `build.rs` and `bindgen-tests/tests/parse_callbacks/`.
- Roundtrip — regenerate from `Builder::command_line_flags` to prove CLI/Builder parity (bindgen-tests; flags in `bindgen/options/`).
- MSRV — minimum supported Rust version, 1.70.0.
- `__testing_only_*` — internal features pinning libclang version/extra assertions, forwarded through every crate's `Cargo.toml`.
