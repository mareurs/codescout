Languages: rust, markdown, c, cpp
Root: .
Manifest: Cargo.toml