## Purpose
Root layer of the rust-bindgen repository (Cargo virtual workspace at `Cargo.toml`). bindgen reads C/C++/Objective-C headers via libclang and generates Rust FFI bindings. This "testbed" project is the repo root: manifests, CI, docs (`book/`), release/fuzzing tooling. Crate code lives in the sibling projects `bindgen`, `bindgen-cli`, `bindgen-integration`, `bindgen-tests`.

## Tech Stack
- Rust, edition 2021, MSRV `rust-version = "1.70.0"` (`Cargo.toml` `[workspace.package]`; README "MSRV" section).
- Key deps centralised in `[workspace.dependencies]`: clang-sys, cexpr, quote, syn, proc-macro2, prettyplease, clap, regex, bitflags.
- Non-Rust: C/C++ test headers, `ci/*.sh|*.bat`, `csmith-fuzzing/*.py`, mdBook docs in `book/`.

## Runtime Requirements
- libclang >= 9.0 (`book/src/requirements.md`); set `LIBCLANG_PATH` if several LLVMs are installed (CONTRIBUTING.md "Building").
- `rustfmt` check needs the nightly toolchain (`cargo +nightly fmt --check`, CONTRIBUTING.md; CI job `rustfmt`).
- Optional: graphviz `dot` (needed by `bindgen-tests/tests/test-one.sh`), `csmith`, `creduce`.
- Env vars: `BINDGEN_EXTRA_CLANG_ARGS[_<TARGET>]` (README "Environment Variables").

## Entry Points
- `Cargo.toml` — workspace members: bindgen, bindgen-cli, bindgen-integration, bindgen-tests, bindgen-tests/tests/quickchecking, bindgen-tests/tests/expectations; `default-members` = bindgen, bindgen-cli, bindgen-tests.
- Library entry `bindgen/lib.rs`; CLI entry `bindgen-cli/main.rs` (binary name `bindgen`).
- CI entry `.github/workflows/bindgen.yml` -> `ci/test.sh`.
- Tooling note: at onboarding time the LSP mux failed to start and the semantic index was not built, so this was written from tree-sitter symbols, grep and file reads only.
