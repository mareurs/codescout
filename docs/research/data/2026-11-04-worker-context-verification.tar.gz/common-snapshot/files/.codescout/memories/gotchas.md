## Gotchas
- Root `cargo test`/`build` covers only `default-members` (bindgen, bindgen-cli, bindgen-tests). `bindgen-integration`, `tests_expectations` and `quickchecking` need `cd` + `cargo test` (`Cargo.toml`, CONTRIBUTING.md). Symptom: green root run but CI failures in `test-expectations`/`test`. Workaround: run all three extra commands.
- Changing bindgen output requires updating `bindgen-tests/tests/expectations/tests/*.rs` (and libclang-9/16 variants) — otherwise snapshot tests fail and `ci/test.sh` `assert_no_diff` flags a dirty tree. Use `BINDGEN_OVERWRITE_EXPECTED=1 cargo test`.
- Adding a Builder option without CLI support fails the roundtrip check in bindgen-tests ("fix Builder::command_line_flags"): edit `bindgen/options/mod.rs`, `cli.rs`, `as_args.rs` together.
- CLI flags are defined in the `bindgen` library, not `bindgen-cli`.
- CONTRIBUTING.md says `src/...`; real paths have no `src/` for bindgen and bindgen-cli. Also its `./tests/quickchecking` path is really `bindgen-tests/tests/quickchecking`.
- Multiple LLVM installs: wrong libclang picked -> set `LIBCLANG_PATH`; libclang < 9 only warns and may generate invalid code.
- `ci/test.sh` uses `set -u`: running it without all `BINDGEN_*`/`LLVM_PATH` vars errors; its Rust-for-Linux branch clones Linux from the network.
- Codescout tooling at onboarding: rust LSP mux failed (symbol-name search returned 0 with a warning), semantic index not built, memory writes warn "cross-embed failed ... no sparse vector" (hint: `CODESCOUT_DISABLE_SPARSE=1` or a dense+sparse embedder). Memories were still written; recall by meaning may be degraded.
- `tests/expectations` has 622 files: scope searches or results drown.
