## Project Map
- `testbed/` — repo root layer: workspace manifest, CI, book, tooling · entry-point: `Cargo.toml` (workspace) · activate: `workspace(action="activate", path="testbed")`
- `bindgen/` — core library: libclang -> IR -> analyses -> codegen -> formatting · entry-point: `bindgen/lib.rs:Builder::generate` / `Bindings::generate` · activate: `workspace(action="activate", path="bindgen")`
- `bindgen-cli/` — `bindgen` executable, thin wrapper over `builder_from_flags` · entry-point: `bindgen-cli/main.rs:main` · activate: `workspace(action="activate", path="bindgen-cli")`
- `bindgen-integration/` — C++ + generated bindings runtime assertions · entry-point: `bindgen-integration/build.rs:setup_macro_test`, tests in `src/lib.rs` · activate: `workspace(action="activate", path="bindgen-integration")`
- `bindgen-tests/` — header/expectation snapshot suite, parse-callback tests, quickchecking, `tests_expectations` · entry-point: `bindgen-tests/tests/tests.rs:compare_generated_header` · activate: `workspace(action="activate", path="bindgen-tests")`
Prefer `project_id="<id>"` on single calls over activating (and always re-activate the home project afterwards).

## Cross-Project Dependencies
- bindgen-cli → bindgen (`builder_from_flags`, features `__cli`, `experimental`, `prettyplease`; `bindgen-cli/Cargo.toml`)
- bindgen-integration → bindgen (build-dependency: `Builder`, `ParseCallbacks`; also `cc`)
- bindgen-tests → bindgen (dev-dependency with `__cli`; `builder_from_flags`, `Builder`, `clang_version`)
- bindgen-tests/tests/expectations compiles outputs of bindgen run on `bindgen-tests/tests/headers`
- testbed owns the shared `[workspace.dependencies]`, lints and `rust-version`.
- The codescout project table reports no inter-project "Depends On"; the above is from the Cargo manifests.

## Shared Infrastructure
- CI: `.github/workflows/bindgen.yml` jobs rustfmt, clippy, msrv, minimal, docs, quickchecking, test-expectations, test (LLVM 9.0/16.0 matrix), test-book, test-no-headers, success.
- Other workflows: `release.yml`, `publish.yml`, `create-tag.yml`, `bump-version.yml`, `deploy-book.yml`.
- `ci/test.sh` (Linux/macOS) and `ci/test.bat` (Windows), `appveyor.yml`.
- Release: `cargo release` metadata in root/`bindgen/Cargo.toml`, `dist-workspace.toml` (cargo-dist), `releases/`.
- `triagebot.toml`, `rustfmt.toml`, `clippy.toml`.

## Top-Level Code Map
- `Cargo.toml`/`Cargo.lock` — workspace, deps, lints.
- `README.md`, `CONTRIBUTING.md`, `CHANGELOG.md`, `LICENSE` — docs; CONTRIBUTING is the best architecture overview (note: its `src/` paths are stale, sources are directly under `bindgen/`).
- `book/` — mdBook user guide (`book/src/*.md`; `requirements.md`, `library-usage.md`, `command-line-usage.md`).
- `ci/test.sh`, `ci/test.bat`, `ci/no-includes.sh`, `ci/assert-no-diff.bat` — CI scripts.
- `csmith-fuzzing/` — `driver.py`, `predicate.py`, `csmith.h`, README for fuzzing/creduce.
- `releases/friends.sh`, `releases/release-announcement-template.md`.
- `example-graphviz-ir.png` — doc image; `appveyor.yml` — legacy CI; `.gitattributes`, `.gitignore`.

## Generic Navigation
- Build/test/lint: `memory(topic="development-commands")`, then per-project.
- Pipeline understanding: `memory(project_id="bindgen", topic="architecture")`.
- Changing generated output: `memory(project_id="bindgen-tests", topic="gotchas")` and `development-commands`.
- Cross-project pitfalls: `memory(topic="gotchas")`.
- Terms: `memory(topic="domain-glossary")`.
- Flag/CLI questions: `bindgen/options/cli.rs`, not `bindgen-cli/`.
- Tooling status: LSP mux failed and semantic index not built at onboarding; use `grep` and `symbols(path=...)`.
