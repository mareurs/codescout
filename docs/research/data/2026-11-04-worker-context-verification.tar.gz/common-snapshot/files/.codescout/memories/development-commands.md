Sources: CONTRIBUTING.md, `.github/workflows/bindgen.yml`, `ci/test.sh`. Commands were read, not run, during onboarding; no test result is claimed.

## Whole-Repo
- Build default members: `cargo build` (bindgen, bindgen-cli, bindgen-tests).
- Snapshot tests: `cargo test` (root default-members).
- Full CI sequence (`ci/test.sh`): `RUSTFLAGS="-Dwarnings" cargo check` -> `(cd bindgen-tests && cargo test)` -> `assert_no_diff` -> `(cd bindgen-integration && cargo test)`. Needs `LLVM_PATH`, `BINDGEN_RELEASE_BUILD`, `BINDGEN_NO_DEFAULT_FEATURES`, `BINDGEN_FEATURE_RUNTIME`, `BINDGEN_FEATURE_EXTRA_ASSERTS`, `BINDGEN_RUST_FOR_LINUX_TEST` set (it dereferences them with `set -u`).
- Extra crates: `(cd bindgen-tests/tests/expectations && cargo test)`, `(cd bindgen-tests/tests/quickchecking && cargo test)`.
- Format: `cargo +nightly fmt -- --check`.
- Clippy: `cargo clippy --all-targets --workspace --exclude bindgen-integration --exclude tests_expectations -- -D warnings`.
- Docs: `RUSTDOCFLAGS="-D warnings" cargo doc --document-private-items --no-deps -p bindgen` (and `-p bindgen-cli`); book: `mdbook build book && mdbook test book`.
- MSRV: `cargo +1.70.0 test --package bindgen`.

## Dev Startup
- Not a service. Local loop: `export LIBCLANG_PATH=<llvm>/lib` if needed; `cargo run -- header.h`; `RUST_LOG=bindgen` for logs; `BINDGEN_OVERWRITE_EXPECTED=1 cargo test` after intended output changes.
- Codescout: semantic index needs `index(action="build")`; LSP for rust was not working at onboarding (mux startup failure).

## Per-Project
- testbed: see memory(project_id: "testbed", topic: "development-commands")
- bindgen: see memory(project_id: "bindgen", topic: "development-commands")
- bindgen-cli: see memory(project_id: "bindgen-cli", topic: "development-commands")
- bindgen-integration: see memory(project_id: "bindgen-integration", topic: "development-commands")
- bindgen-tests: see memory(project_id: "bindgen-tests", topic: "development-commands")
