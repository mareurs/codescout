## Shared
- Edition 2021, MSRV 1.70.0 for all crates (`Cargo.toml` `[workspace.package]`; README); versions/deps/lints inherited via `workspace = true` / `lints.workspace = true`.
- Formatting: nightly rustfmt, `max_width = 80`, `binop_separator = "back"` (`rustfmt.toml`); run `cargo +nightly fmt -- --check`. Expectations tree is exempt.
- Lints: clippy pedantic as warn with allow-list (root `Cargo.toml`), `clippy.toml` `missing-docs-in-crate-items = true`; CI uses `-D warnings`.
- Commits/PRs: every commit stands alone and passes tests; squash fixups; reviewer requested with `r? @name` (CONTRIBUTING.md "Pull Requests and Code Reviews"). Merge queue: `merge_group` trigger in CI.
- `CHANGELOG.md`: add entries under `# Unreleased` (Added/Changed/Removed/Fixed/Security).
- Internal Cargo features `__*` are not public API.
- Sources of bindgen/bindgen-cli live directly in the crate dir (`lib.rs`, `main.rs`), no `src/`.
- Generated expectation changes must be committed in the same change (`ci/test.sh` `assert_no_diff`).

## Per-Project
- testbed: see memory(project_id: "testbed", topic: "conventions")
- bindgen: see memory(project_id: "bindgen", topic: "conventions")
- bindgen-cli: see memory(project_id: "bindgen-cli", topic: "conventions")
- bindgen-integration: see memory(project_id: "bindgen-integration", topic: "conventions")
- bindgen-tests: see memory(project_id: "bindgen-tests", topic: "conventions")
