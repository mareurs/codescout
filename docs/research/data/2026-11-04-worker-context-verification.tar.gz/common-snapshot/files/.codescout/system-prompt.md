# rust-bindgen — Code Explorer Guidance

Workspace of 5 codescout projects over one Cargo workspace: `testbed` (repo root), `bindgen` (library), `bindgen-cli`, `bindgen-integration`, `bindgen-tests`. Read `memory(topic="architecture")` first.

## Entry Points
- `bindgen/lib.rs` — `builder()` -> `Builder::generate` -> `Bindings::generate` -> `parse` + `codegen::codegen` (`bindgen/codegen/mod.rs`) -> `Bindings::write`.
- `bindgen/options/cli.rs` — `builder_from_flags`, all CLI flags (not in `bindgen-cli/`).
- `bindgen-cli/main.rs` — `main`, thin wrapper (binary name `bindgen`).
- `bindgen-tests/tests/tests.rs` — `compare_generated_header`, `create_bindgen_builder`, `test_header!`.
- `bindgen-integration/build.rs` + `src/lib.rs` — C++ fixtures and runtime assertions.
- Sources sit directly in `bindgen/` and `bindgen-cli/` (no `src/`), despite CONTRIBUTING.md saying `src/`.

## Key Abstractions
- `Builder` / `BindgenOptions` (`bindgen/lib.rs`, `bindgen/options/mod.rs`) — configuration; options defined via the `options!` macro.
- `BindgenContext` (`bindgen/ir/context.rs`) — owns the IR and analysis results.
- `Item` / `ItemId` / `ItemKind` (`bindgen/ir/item.rs`) — IR graph nodes.
- `MonotoneFramework` analyses (`bindgen/ir/analysis/`) — derive, vtable, sizedness, template params.
- `ParseCallbacks` (`bindgen/callbacks.rs`) — user hooks; exercised in integration and parse_callbacks tests.

## Search Tips
- Semantic index was NOT built at onboarding; run `index(action="build")` first, otherwise use `grep` (fallback) and `symbols(path=...)`.
- Scope everything: `semantic_search("...", project_id="bindgen")` etc. Project-specific starters:
  - `bindgen`: "allowlist traversal of items", "derive analysis", "bitfield codegen"
  - `bindgen-cli`: "exit code on error" (flags live in `bindgen`)
  - `bindgen-integration`: "parse callbacks macro hooks", "bitfield accessor tests"
  - `bindgen-tests`: "compare generated header against expectation", "parse callback rename"
  - `testbed`: "workspace lints and shared dependencies"
- `bindgen-tests/tests/expectations/` has 622 files and `tests/headers/` hundreds: always pass `path=`/`glob`.
- Rust LSP mux failed to start at onboarding: `symbols(name=...)` may return 0 matches with a warning, which is not proof of absence. `symbols(path=...)` (tree-sitter) works.
- Callers/impact: `references` / `call_graph` need LSP; fall back to `grep` with `whole_word=true`.

## Navigation Strategy
1. `memory(topic="architecture")`, then `memory(project_id="<id>", topic="architecture")`.
2. Know a file: `symbols(path)`; know a name: `symbols(name=..., include_body=true)`; concept: `semantic_search` (once indexed) else `grep`.
3. Output change questions: pipeline `parse` (`ir/`, `clang.rs`) -> `codegen/` -> `codegen/postprocessing`; then snapshot in `bindgen-tests/tests/expectations/tests/<header>.rs`.
4. New option: `bindgen/options/mod.rs` + `cli.rs` + `as_args.rs`, tests via a header with `// bindgen-flags:`.
5. Pass `project_id` on single calls rather than activating; re-activate the home project after any `workspace(action="activate")`.
6. Memories: `memory(topic="gotchas")` before changing output or options.

## Project Rules
- Do not claim tests pass without running them; commands are listed in `memory(topic="development-commands")` (sources: CONTRIBUTING.md, `.github/workflows/bindgen.yml`, `ci/test.sh`).
- Root `cargo test` only covers bindgen, bindgen-cli, bindgen-tests; also run `bindgen-integration` and `bindgen-tests/tests/expectations` from their directories.
- Formatting: `cargo +nightly fmt -- --check` (`rustfmt.toml`: width 80). Clippy pedantic via workspace lints, CI `-D warnings`.
- Changed generated output means updating `bindgen-tests/tests/expectations/tests/*` (and `libclang-9/`, `libclang-16/` variants); `BINDGEN_OVERWRITE_EXPECTED=1 cargo test`.
- MSRV 1.70.0; add `CHANGELOG.md` entries under `# Unreleased`.
- libclang >= 9 is required; set `LIBCLANG_PATH` when several LLVMs exist.
- Read `memory(topic="language-patterns")` before writing Rust.
