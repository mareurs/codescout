Languages: rust, cpp
Root: bindgen-integration
Manifest: Cargo.toml