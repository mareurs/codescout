## Gotchas
- Flag definitions are in the library (`bindgen/options/cli.rs`) behind the `__cli` feature; editing `bindgen-cli/main.rs` will not add flags.
- Source file is `bindgen-cli/main.rs` (no `src/`); binary name is `bindgen` while the package is `bindgen-cli`, so `cargo run -p bindgen-cli` produces `target/*/bindgen`.
- `clang_version_check` only compiles with `logging`; under `--no-default-features` it vanishes and its call is cfg-gated too.
- Panics inside generation are caught only to print `print_verbose_err` hints (`--verbose`), then the original panic message is printed; exit status for panics is Rust's default, errors exit 1.
- The `prettyplease` feature is forced on via the dependency features list and also exposed as its own feature.
