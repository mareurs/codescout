# bindgen-integration Domain Glossary

_No project-specific domain glossary. See workspace domain-glossary memory._
