## Terms
- Expectation — the checked-in `.rs` file in `tests/expectations/tests/` that a header's generated bindings must equal.
- bindgen-flags — `// bindgen-flags: ...` comment on a test header holding CLI flags for that test.
- Roundtrip test — regenerates via `Builder::command_line_flags` to prove the CLI flags reproduce the same output.
- libclang-N variant — alternative expectation under `libclang-9/` or `libclang-16/` for version-dependent output.
- `__testing_only_libclang_*` — Cargo features forcing which libclang variant is checked.
- tests_expectations — crate compiling all expectations and running layout tests.
- quickchecking — property-test crate generating random C headers, judged by `csmith-fuzzing/predicate.py`.
- stylo sanity — big Mozilla Stylo header generation smoke test (`tests/stylo_sanity.rs`).
