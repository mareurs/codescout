## Purpose
`bindgen-tests` (unpublished, v0.1.0): the snapshot test suite for bindgen. For every header in `tests/headers/` it generates bindings and compares with `tests/expectations/tests/<name>.rs`; also hosts API-level tests in `tests/tests.rs`, parse-callback tests, a quickcheck fuzzing crate, and the `tests_expectations` crate that compiles the expected outputs.

## Tech Stack
- Rust 2021, MSRV 1.70.0; C/C++ headers as test inputs (hundreds under `tests/headers/`; 622 files under `tests/expectations/`).
- dev-dependencies: `bindgen` (default + `__cli`, `experimental`), `similar` (diffs), `owo-colors`, `prettyplease`, `syn`, `regex`, `shlex`, `tempfile`.
- `tests_expectations` deps: `block`, `libloading`, `objc`; `quickchecking` uses `quickcheck` and python3.

## Runtime Requirements
- libclang >= 9; optional `__testing_only_libclang_9|16` features to force which `libclang-N/` expectation variant is used.
- Env: `BINDGEN_OVERWRITE_EXPECTED`, `BINDGEN_TESTS_DIFFTOOL`, `BINDGEN_DISABLE_ROUNDTRIP_TEST`, `BINDGEN_EXTRA_CLANG_ARGS`.
- graphviz `dot` only for `tests/test-one.sh`.

## Entry Points
- `bindgen-tests/tests/tests.rs` — `compare_generated_header` (L122), `create_bindgen_builder` (L266), `test_header!` macro (L351), plus ~15 API tests (`test_header_contents`, `test_macro_fallback_*`, `emit_depfile`, `dump_preprocessed_input`, `test_wrap_static_fns`).
- `bindgen-tests/build.rs` — scans `tests/headers/*.{h,hpp}` and writes `$OUT_DIR/tests.rs` of `test_header!(header_<name>, path)` lines.
- `bindgen-tests/src/lib.rs` — placeholder crate root (no symbols).
- Run: `cargo test` (from root or `bindgen-tests/`).
