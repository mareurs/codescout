## Module Map
- `build.rs` — drives `cc::Build` (C++ -> `libtest.a`) and `bindgen::Builder` (binds `cpp/Test.h`); defines parse callbacks.
- `cpp/Test.h`, `cpp/Test.cc` — C++ fixtures: bitfields, destructors, overloads, templates, macros, etc.
- `include/stub.h` — extra include dir passed with `-I include`.
- `src/lib.rs` — `mod bindings { include!(concat!(env!("OUT_DIR"), "/test.rs")) }`, `mod extern_bindings` (`extern.rs`), and the tests.
- `Cargo.toml` — build-dependencies and feature forwarding.

## Key Abstractions
- `MacroCallback` (`build.rs`) — `ParseCallbacks` impl checking macro hooks (`will_parse_macro`, `int_macro`, `modify_macro`, derives/attributes); its `Drop` asserts hook-call counts (3 str macros, 5 func macros).
- `WrappedVaListCallback` (`build.rs`) — `wrap_as_variadic_fn` returns `<name>_wrapped`.
- `setup_macro_test` (`build.rs`) — central build routine; Builder uses `enable_cxx_namespaces`, `new_type_alias`, `opaque_type`, `depfile`.
- `bindings::testing::Bar` — comes from a `module_raw_line`, imported in `src/lib.rs`.

## Data Flow
`cargo test` -> `build.rs` (cc compiles C++, bindgen generates `test.rs` + `extern.rs` into `$OUT_DIR`) -> `src/lib.rs` includes them -> tests call into the C++ library and compare results. Imports `Builder`, `ParseCallbacks`, `Formatter`, `EnumVariation` from the bindgen project (not documented here).

## Search Tips
- `semantic_search("bitfield accessor tests", project_id="bindgen-integration")` -> `src/lib.rs` `test_bitfields_*`.
- `semantic_search("parse callbacks macro hooks", project_id="bindgen-integration")` -> `build.rs`.
- `grep("fn test_", path="bindgen-integration/src/lib.rs")` for the test list.
- Too broad unscoped: "callbacks" (also in `bindgen/callbacks.rs` and `bindgen-tests/tests/parse_callbacks`).
- Index not built at onboarding; use grep fallback.
