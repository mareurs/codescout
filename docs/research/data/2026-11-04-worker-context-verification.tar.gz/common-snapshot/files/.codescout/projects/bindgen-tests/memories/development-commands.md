Sources: CONTRIBUTING.md "Testing", `ci/test.sh`, `.github/workflows/bindgen.yml`, `bindgen-tests/tests/test-one.sh`, `bindgen-tests/tests/quickchecking/README.md`. Read, not executed.

## Build
- `cargo build -p bindgen-tests --tests` (build.rs enumerates headers)
- Expectations crate: `cd bindgen-tests/tests/expectations && cargo build`

## Test
- `cargo test` (header snapshots; from `bindgen-tests/` as `ci/test.sh` does: `(cd bindgen-tests && cargo test $CARGO_ARGS)`)
- Overwrite snapshots: `BINDGEN_OVERWRITE_EXPECTED=1 cargo test`
- Skip CLI roundtrip: `BINDGEN_DISABLE_ROUNDTRIP_TEST=1 cargo test`
- Visual diff: `BINDGEN_TESTS_DIFFTOOL=meld cargo test`
- Pin libclang variant: `cargo test --features __testing_only_libclang_16` (or `_9`)
- Compile generated bindings: `cd bindgen-tests/tests/expectations && cargo test [name]`
- One header end to end (needs graphviz, prebuilt `../target/debug/bindgen`): `./bindgen-tests/tests/test-one.sh <fuzzy-name>`
- Property tests: `cd bindgen-tests/tests/quickchecking && cargo test` (CI) / `cargo run --bin=quickchecking -- -h` (needs python3)

## Lint / Format
- `cargo clippy --all-targets --workspace --exclude bindgen-integration --exclude tests_expectations -- -D warnings`
- `cargo +nightly fmt -- --check` (expectations tree excluded by its `rustfmt.toml`)
- `ci/test.sh` calls `assert_no_diff` after tests: snapshots must be committed in sync.

## Run
- No binary; the test harness is `bindgen-tests/tests/tests.rs`. Single test: `cargo test header_<name>`.
