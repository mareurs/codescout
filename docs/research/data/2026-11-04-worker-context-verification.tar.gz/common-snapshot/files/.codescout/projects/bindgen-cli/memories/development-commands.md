Sources: `bindgen-cli/Cargo.toml`, `.github/workflows/bindgen.yml`, `ci/test.sh`. Read, not executed.

## Build
- `cargo build -p bindgen-cli` (binary `target/debug/bindgen`)
- MSRV build: `cargo +1.70.0 build --package bindgen-cli` (CI reads the version from root `Cargo.toml`).
- Distribution profile: `[profile.dist]` in root `Cargo.toml` (cargo-dist).

## Test
- No unit tests. Smoke: `cargo run -- --help`, `cargo run -- --version`, `cargo run -- --generate-shell-completions=bash`.
- Kernel-style build step in `ci/test.sh`: `(cd bindgen-cli && cargo build --target-dir ${HOME}/.bindgen $CARGO_ARGS)`.

## Lint / Format
- `cargo clippy --all-targets -p bindgen-cli -- -D warnings`
- `cargo +nightly fmt -- --check`
- `RUSTDOCFLAGS="-D warnings" cargo doc --document-private-items --no-deps -p bindgen-cli`

## Run
- `cargo run -- path/to/header.h -o out.rs -- -I include`
- `RUST_LOG=bindgen ./target/debug/bindgen header.h` for debug logs.
