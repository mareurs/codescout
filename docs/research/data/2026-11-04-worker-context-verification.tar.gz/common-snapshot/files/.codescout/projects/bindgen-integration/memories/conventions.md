## Naming
- Tests are `test_<feature>` free functions in `src/lib.rs`; bitfield cases are numbered ordinals (`test_bitfields_first`..`seventh`).
- C++ fixture names use prefixes like `my_prefixed_*` and `Test*` so the Builder flags in `build.rs` can target them (e.g. `blocklist_function("my_prefixed_function_to_remove")`).

## Testing
- Plain `cargo test` inside `bindgen-integration/`; assertions run against real compiled C++ (`cpp/Test.cc`).
- Generated code is formatted with `Formatter::None` and `#![allow(warnings)]` in `src/lib.rs`, so lint cleanliness of bindings is not checked here.

## Patterns
- Behaviour under test is configured exclusively in `build.rs`; adding a feature test = edit `cpp/Test.h`/`Test.cc` + Builder call in `build.rs` + `#[test]` in `src/lib.rs`.
- Callback counters verified in `Drop` impls (panic if hooks not exercised).
- CI excludes this crate from clippy (`--exclude bindgen-integration`), but runs it from `ci/test.sh` via `(cd bindgen-integration && cargo test $CARGO_ARGS)`.
