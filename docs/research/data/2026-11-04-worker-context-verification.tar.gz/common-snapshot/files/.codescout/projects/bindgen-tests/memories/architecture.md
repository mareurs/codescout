## Module Map
- `build.rs` — generates `$OUT_DIR/tests.rs` with one `test_header!(header_<sanitised_name>, "<path>")` per `tests/headers/*.h|*.hpp` (names lowercased, non-alphanumerics -> `_`).
- `src/lib.rs` — empty crate root.
- `tests/tests.rs` — harness: `compare_generated_header`, `create_bindgen_builder`, `test_header!`, `error_diff_mismatch`, `show_diff`, API tests.
- `tests/headers/` — C/C++ inputs (+ subdirs `allowlisted/`); first-line `// bindgen-flags:` comments set CLI flags.
- `tests/expectations/tests/` — expected `.rs` snapshots; `libclang-9/` and `libclang-16/` subdirs hold version-specific variants.
- `tests/expectations/` — crate `tests_expectations` (`Cargo.toml`, `lib.rs`, `build.rs`) that compiles all snapshots and runs their layout tests; has its own `rustfmt.toml`.
- `tests/parse_callbacks/` — `mod.rs` (`lookup()` returns named `ParseCallbacks` impls such as `RemovePrefixParseCallback`, `EnumVariantRename`, `FieldVisibility`, `WrapAsVariadicFn`) + `add_derives_callback/`, `item_discovery_callback/`.
- `tests/quickchecking/` — property tests crate (`src/{bin,fuzzers,lib}.rs`, `tests/fuzzed-c-headers.rs`) using `csmith-fuzzing/predicate.py`.
- `tests/stylo_sanity.rs`, `tests/stylo.hpp` — large Stylo generation sanity (release + libclang feature only); `tests/test-one.sh` — single-header workflow; `tests/macro_fallback_test_headers/`, `tests/uses/` — fixtures.

## Key Abstractions
- `test_header!` macro (`tests.rs` L351) — one `#[test]` per header.
- `compare_generated_header` (L122) — picks the expectation (version-specific dir first, then default), generates, formats via prettyplease, diffs.
- `create_bindgen_builder` (L266) — parses `bindgen-flags:` comment, adds defaults (derive-default, raw lines), builds a `BuilderState`.
- `BuilderState::into_builder` — optionally produces a roundtrip builder from `Builder::command_line_flags`.
- `parse_callbacks::lookup` — maps a flag value to a callback impl.

## Data Flow
Header -> `create_bindgen_builder` -> `builder.generate()` -> `format_code` -> compare with expectation file; on mismatch `error_diff_mismatch` (writes expectation if `BINDGEN_OVERWRITE_EXPECTED`, runs `BINDGEN_TESTS_DIFFTOOL`). Then, unless `BINDGEN_DISABLE_ROUNDTRIP_TEST`, re-run using `command_line_flags` output and compare again.

## Search Tips
- `semantic_search("compare generated header against expectation", project_id="bindgen-tests")` -> `tests/tests.rs`.
- `semantic_search("parse callback rename", project_id="bindgen-tests")` -> `tests/parse_callbacks/mod.rs`.
- Locate a header's snapshot: `tree(glob="**/expectations/tests/**/<name>.rs")`.
- Too broad unscoped: any C++ keyword ("template", "union", "bitfield") matches hundreds of header/expectation files; add `path="bindgen-tests/tests/headers"` or `glob`.
- Index was not built at onboarding; use `grep(pattern, glob="*.h*", path="bindgen-tests/tests/headers")`.
