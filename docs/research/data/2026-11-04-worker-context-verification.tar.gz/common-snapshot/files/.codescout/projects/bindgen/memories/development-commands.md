Sources: `bindgen/Cargo.toml`, `.github/workflows/bindgen.yml`, CONTRIBUTING.md. Read, not executed during onboarding.

## Build
- `cargo build -p bindgen`
- No default features: `cargo check -p bindgen --no-default-features --features=runtime` (CI `minimal`, `RUSTFLAGS=-D warnings`)
- Static libclang: `--features static` (not CI-testable per workflow FIXME).

## Test
- `cargo test --package bindgen` (unit tests; CI `msrv` job runs it on the MSRV toolchain).
- With libclang version pinning: `cargo test --features __testing_only_libclang_16` (or `_9`).
- Extra assertions: `--features __testing_only_extra_assertions`.

## Lint / Format
- `cargo +nightly fmt -- --check`
- `cargo clippy --all-targets -p bindgen -- -D warnings`
- `RUSTDOCFLAGS="-D warnings" cargo doc --document-private-items --no-deps -p bindgen`

## Run
- Library only; exercise through `cargo run -- <header>` (bindgen-cli) or `bindgen-integration/build.rs`.
- Debug: `RUST_LOG=bindgen`; set `LIBCLANG_PATH` if libclang is not found.
