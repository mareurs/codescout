## Naming
- Package `bindgen-cli`, binary `bindgen`; features mirror `bindgen`'s names (`logging`, `runtime`, `static`, `libcpp`, `prettyplease`, `__testing_only_*`).

## Testing
- No tests inside this crate. CLI behaviour is exercised by `bindgen-tests` (flags in `// bindgen-flags:` header comments, `builder_from_flags` in `bindgen-tests/tests/tests.rs`) and by CI job `test-no-headers` (`cargo run -- --help`, `--version`, `--generate-shell-completions=bash`; `.github/workflows/bindgen.yml`).

## Patterns
- Keep this crate minimal; new flags go in `bindgen/options/cli.rs` and `bindgen/options/mod.rs`.
- Logging code is gated with `#[cfg(feature = "logging")]` and initialised by `env_logger::init()`.
- Errors: print to stderr and `std::process::exit(1)`, no `anyhow`.
- Lints inherited (`lints.workspace = true`); CI builds the CLI on the MSRV toolchain (`cargo +<msrv> build --package bindgen-cli`).
