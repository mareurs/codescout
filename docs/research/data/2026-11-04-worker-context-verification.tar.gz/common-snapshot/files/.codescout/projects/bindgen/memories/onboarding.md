Languages: rust
Root: bindgen
Manifest: Cargo.toml