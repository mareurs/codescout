## Gotchas
- Not a default workspace member: root `cargo test` skips it; run from `bindgen-integration/` (`Cargo.toml` `default-members`).
- `MacroCallback::drop` asserts hook counters (3 and 5); adding/removing a string macro or function-like macro in `cpp/Test.h` without updating those numbers panics at the end of `build.rs`.
- `build.rs` uses relative paths (`cpp/Test.cc`, `include`) so it relies on cargo's cwd = crate dir; the depfile path is computed relative to the parent of `current_dir`, so don't move the crate.
- `src/lib.rs` `type MacroInteger = isize` must match the `IntKind::Custom { name: "crate::MacroInteger" }` set by the `int_macro` callback.
- Its `Cargo.lock` is gitignored (`.gitignore`); do not commit it.
