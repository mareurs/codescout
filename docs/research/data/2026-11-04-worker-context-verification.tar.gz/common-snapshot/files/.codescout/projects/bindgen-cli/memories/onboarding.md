Languages: rust
Root: bindgen-cli
Manifest: Cargo.toml