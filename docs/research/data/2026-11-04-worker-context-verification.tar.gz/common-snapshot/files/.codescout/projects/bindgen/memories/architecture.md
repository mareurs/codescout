## Module Map
- `lib.rs` — public API: `Builder`, `Bindings`, `BindgenError`, `Formatter`, `CargoCallbacks`, `clang_version`, target helpers (`rust_to_clang_target`, `find_effective_target`).
- `options/` — `mod.rs` (`options!` macro defining `BindgenOptions` and Builder setters), `cli.rs` (`builder_from_flags`, clap CLI), `as_args.rs`, `helpers.rs`.
- `clang.rs` — safe wrappers over `clang-sys` (`Cursor`, `Type`, `TranslationUnit::parse`, ...).
- `parse.rs` — `ClangSubItemParser` trait, `ParseResult`/`ParseError`.
- `ir/` — IR: `context.rs` (`BindgenContext`), `item.rs` (`Item`), `ty.rs`, `comp.rs` (structs/unions), `function.rs`, `var.rs`, `enum_ty.rs`, `layout.rs`, `module.rs`, `objc.rs`, `template.rs`, `traversal.rs`, `dot.rs`, `analysis/` (derive, has_vtable, has_destructor, has_float, sizedness, template_params).
- `codegen/` — `mod.rs` (`codegen()`, `CodeGenerator`), `struct_layout.rs`, `bitfield_unit.rs`, `dyngen.rs` (dynamic loading), `impl_debug.rs`, `impl_partialeq.rs`, `serialize.rs` (wrap-static-fns C code), `helpers.rs`, `error.rs`, `postprocessing/` (`PASSES`, `merge_extern_blocks`, `sort_semantically`).
- `callbacks.rs`, `diagnostics.rs`, `features.rs` (Rust target features), `regex_set.rs`, `deps.rs` (depfile), `time.rs`, `log_stubs.rs`, `extra_assertions.rs`.

## Key Abstractions
- `Builder` / `BindgenOptions` — user-facing config (`options/mod.rs`).
- `BindgenContext` (`ir/context.rs`) — owns all IR items, analyses results, and options.
- `Item` / `ItemId` / `ItemKind` (`ir/item.rs`) — IR graph node; kinds Module, Type, Function, Var.
- `MonotoneFramework` fix-point analyses (`ir/analysis/mod.rs`) — derive-ability, vtables, sizedness, template params.
- `CodeGenerator` trait (`codegen/mod.rs`) — emits `proc_macro2::TokenStream` via `quote!`.
- `ParseCallbacks` (`callbacks.rs`) — hooks for macros, derives, renames.

## Data Flow
`Builder::generate` -> `BindgenOptions::build` -> `Bindings::generate` (fix clang args/target, include-path detection, header checks) -> `BindgenContext::new` -> `parse(&mut ctx)` (libclang AST -> IR) -> `codegen::codegen(ctx)` (runs analyses, traverses allowlisted items, `postprocessing`) -> `Bindings{options, module}` -> `Bindings::write` / `format_tokens` (prettyplease or rustfmt). Per CONTRIBUTING.md "Code Overview".

## Search Tips
- `semantic_search("allowlist traversal of items", project_id="bindgen")` (index was not built at onboarding; use `grep` in `bindgen/**/*.rs` meanwhile).
- `semantic_search("derive Copy/Debug analysis", project_id="bindgen")` -> `ir/analysis/derive.rs`.
- `semantic_search("bitfield codegen", project_id="bindgen")` -> `codegen/bitfield_unit.rs`, `ir/comp.rs`.
- Too broad unscoped: "options", "type" — `ir/` and `options/` both match everything; scope with `path="bindgen/ir"`.
- New Builder option: add to the `options!` macro in `options/mod.rs`, plus CLI in `options/cli.rs`.
