## Purpose
`bindgen-cli` (v0.72.0): the `bindgen` command-line executable. It is a thin wrapper: parse argv into a `bindgen::Builder` via `bindgen::builder_from_flags`, call `generate()`, write the result. All real logic is in the `bindgen` project.

## Tech Stack
- Rust 2021, MSRV 1.70.0 (README notes the CLI MSRV may exceed the library's because of `clap`).
- Deps (`bindgen-cli/Cargo.toml`): `bindgen` with features `__cli`, `experimental`, `prettyplease`; optional `env_logger` + `log`; `proc-macro2`, `shlex`.
- Features: default = `logging`, `runtime`; also `static`, `libcpp`, `prettyplease`, `__testing_only_*` forwarded to `bindgen`.
- `[package.metadata.dist] dist = true` — shipped via cargo-dist (`dist-workspace.toml`).

## Runtime Requirements
- libclang >= 9 on the machine (or `LIBCLANG_PATH`); `BINDGEN_EXTRA_CLANG_ARGS` honoured via the library.
- `RUST_LOG=bindgen` enables logs when built with `logging`.

## Entry Points
- `bindgen-cli/main.rs`: `main` (L27-60), `clang_version_check` (L6-25, `logging` feature only), `print_verbose_err` (L62-74). Binary target: `[[bin]] name = "bindgen"`, `path = "main.rs"` (no `src/` dir).
- Run: `cargo run -- <header> [bindgen flags] -- [clang flags]`.
