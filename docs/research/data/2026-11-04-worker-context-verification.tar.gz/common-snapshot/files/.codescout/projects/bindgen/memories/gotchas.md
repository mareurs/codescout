## Gotchas
- Sources are not under `src/`: `[lib] path = "lib.rs"`. CONTRIBUTING.md still refers to `src/clang.rs`, `src/ir/*`, `src/codegen/*`; read those as `bindgen/clang.rs`, `bindgen/ir/`, `bindgen/codegen/` (doc-vs-layout drift, verified by `tree`).
- Output formatting: with `--no-default-features` (no `prettyplease`) formatting differs/needs rustfmt; tests compare prettyplease-formatted output (CONTRIBUTING.md "Overview").
- Changing generated output means regenerating `bindgen-tests/tests/expectations/tests/*.rs` (`BINDGEN_OVERWRITE_EXPECTED=1 cargo test`) and checking per-libclang variants in `libclang-9/`, `libclang-16/` subdirs.
- `Bindings::generate` mutates clang args: auto-adds `--target=` for non-host targets, appends `-isystem` search paths from detected clang, and pushes the last header as a clang arg (`lib.rs` ~L749-926). Argument-order bugs usually originate here.
- Feature `runtime` loads libclang dynamically (`ensure_libclang_is_loaded`); without it libclang is linked, so link errors vs load errors depend on features.
- `ir/context.rs` `item_id_newtype` macro generates ID types; symbol listings show confusing generic entries (`T/can_derive_debug`) for it.
- Tooling: LSP unavailable at onboarding (mux startup failure) so `symbols(name=...)` returned nothing for `codegen`; use `symbols(path=...)` overview or `grep`.
