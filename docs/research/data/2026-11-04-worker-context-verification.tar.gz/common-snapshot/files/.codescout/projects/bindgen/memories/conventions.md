## Naming
- Flat module layout: files directly in `bindgen/` (no `src/`); submodules `ir/`, `codegen/`, `options/`.
- Internal API is `pub(crate)`; public surface is small and lives in `lib.rs` and `callbacks.rs`.
- Cargo features for internals start with `__`; test-only features `__testing_only_*`.
- IR trait names: `CanDeriveX`, `Trace`, `ItemCanonicalName`, `TryToRustTy` (see `ir/context.rs`, `codegen/mod.rs`).

## Testing
- Unit tests live inline (`lib.rs` e.g. `test_rust_to_clang_target*`, `codegen/bitfield_unit_tests.rs`). Run: `cargo test --package bindgen` (CI `msrv` job).
- Behavioural coverage is in `bindgen-tests` and `bindgen-integration` (see those projects).

## Patterns
- Logging via `log` macros guarded by feature `logging`; fallbacks in `log_stubs.rs` when disabled.
- Feature-gated code: `#[cfg(feature = "runtime")]` around libclang loading (`ensure_libclang_is_loaded`).
- Code generation uses `quote!`; options implemented with `syn` go in `codegen/postprocessing` as a new field + free function named as the field + `pass!` entry in `PASSES` (CONTRIBUTING.md "Implementing new options using `syn`").
- IR analyses implement `MonotoneFramework` and are fix-point algorithms (`ir/analysis/mod.rs`).
- Lints: workspace clippy pedantic, `lints.workspace = true`; `rustfmt` width 80 (nightly).
- New/changed user-visible behaviour should be noted under `# Unreleased` in `CHANGELOG.md`.
