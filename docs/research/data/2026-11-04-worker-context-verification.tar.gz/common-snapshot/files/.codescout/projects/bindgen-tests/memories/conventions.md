## Naming
- Header `tests/headers/foo-bar.hpp` <-> expectation `tests/expectations/tests/foo-bar.rs`; generated test fn `header_foo_bar_hpp` style (see `build.rs`: replace non-alphanumerics with `_`, collapse `__`, lowercase).
- Only `.h` and `.hpp` headers are picked up by `build.rs` (other extensions like `.hh`/`.hxx` are not; a TODO in `build.rs` notes the mismatch with `file_is_cpp` in `bindgen/lib.rs`).
- Version-specific expectations: `tests/expectations/tests/libclang-9/<name>.rs`, `libclang-16/<name>.rs`.

## Testing
- Flags go in the header: `// bindgen-flags: --enable-cxx-namespaces -- -std=c++14` (CONTRIBUTING.md "Authoring New Tests"; parsed in `create_bindgen_builder`).
- Add `// bindgen-parse-callbacks: <name>` style callbacks via `parse_callbacks::lookup` (see `tests/parse_callbacks/mod.rs`; exact flag spelling is read in `create_bindgen_builder`).
- After adding a header, generate the expectation and verify it compiles: `cd bindgen-tests/tests/expectations && cargo test <name>`.

## Patterns
- Output compared after `prettyplease` formatting (`format_code` in `tests.rs`), so whitespace differences don't matter.
- Default flags added to every test: derive-default plus raw lines allowing non-idiomatic names (mirrored in `test-one.sh`).
- `rustfmt` is disabled for the expectations tree; `tests_expectations` has relaxed lint allows (dead_code, non_snake_case, etc.).
- Tests use env vars rather than CLI args for behaviour toggles (`BINDGEN_OVERWRITE_EXPECTED`, `BINDGEN_DISABLE_ROUNDTRIP_TEST`).
