## Purpose
The `bindgen` library crate (version 0.72.0, `bindgen/Cargo.toml`): "Automatically generates Rust FFI bindings to C and C++ libraries." Used from `build.rs` scripts or by `bindgen-cli`. It drives libclang to parse headers, builds an IR, analyses it and emits Rust tokens.

## Tech Stack
- Rust 2021, MSRV 1.70.0 (workspace inheritance). Library target `name = "bindgen"`, `path = "lib.rs"` — note: sources are directly under `bindgen/`, not `bindgen/src/`.
- Key deps: `clang-sys` (feature `clang_11_0`), `cexpr` (C macro evaluation), `quote`/`proc-macro2`/`syn` (codegen + postprocessing), `prettyplease` (default formatter), `regex`, `bitflags`, `itertools`, `rustc-hash`, `shlex`.
- Features: default = `logging`, `prettyplease`, `runtime`; also `static`, `libcpp`, `experimental` (annotate-snippets diagnostics); internal `__cli`, `__testing_only_extra_assertions`, `__testing_only_libclang_9|16`.

## Runtime Requirements
- libclang >= 9 (warning emitted by `Bindings::generate` in `bindgen/lib.rs` when older, under `runtime` feature); located via clang-sys (`LIBCLANG_PATH`).
- Env: `BINDGEN_EXTRA_CLANG_ARGS`, `BINDGEN_EXTRA_CLANG_ARGS_<TARGET>` (README; read by `get_extra_clang_args`/`get_target_dependent_env_var` in `lib.rs`).
- `rustfmt` binary only needed if `Formatter::Rustfmt` is selected.

## Entry Points
- `bindgen/lib.rs`: `builder()` (L291) -> `Builder::generate` (L315) -> `Bindings::generate` (L749) -> `parse` (L1129) + `codegen::codegen` (`codegen/mod.rs` L5277); `Bindings::write`/`write_to_file`.
- `bindgen/build.rs` — crate build script.
- Callback extension point: `bindgen/callbacks.rs` (`ParseCallbacks`; `CargoCallbacks` in `lib.rs`).
- Line numbers from tree-sitter symbol listings; they drift with edits. LSP was unavailable at onboarding.
