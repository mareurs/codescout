## Gotchas
- A header with no matching expectation panics with "missing test expectation file and/or '__testing_only_libclang_$VERSION' feature" (`compare_generated_header`); create or generate the initial `.rs` expectation file first. `BINDGEN_OVERWRITE_EXPECTED=1` updates an expectation only after `compare_generated_header` has opened an existing file; it cannot bypass the missing-expectation panic (`bindgen-tests/tests/tests.rs`).
- If bindgen fails on a header, the test compares against the literal `/* error generating bindings */`, so error-case expectations contain that string.
- Expectation lookup tries `libclang-16` (or `-9`) subdir first and falls back to the default dir; an unparseable clang version defaults to `libclang-16`.
- Roundtrip failure message "You probably need to fix Builder::command_line_flags": a new Builder option lacks CLI/`as_args` handling in `bindgen/options/`.
- `tests/stylo_sanity.rs` only compiles in release builds with a `__testing_only_libclang_*` feature, so default `cargo test` never runs it.
- `bindgen-tests/tests/expectations` and `quickchecking` are separate workspace members with gitignored `Cargo.lock`; plain `cargo test` in `bindgen-tests` does not compile the expectations.
- Bash `test-one.sh` does not rebuild bindgen and requires `../target/debug/bindgen` plus `dot`.
- `tests/expectations/` holds 622 files: avoid unscoped greps/semantic searches there.
