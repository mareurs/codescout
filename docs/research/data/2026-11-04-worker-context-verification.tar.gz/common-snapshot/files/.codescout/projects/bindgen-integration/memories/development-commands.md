Sources: CONTRIBUTING.md "Integration Tests", `ci/test.sh`, `bindgen-integration/Cargo.toml`. Read, not executed.

## Build
- `cd bindgen-integration && cargo build` (runs `build.rs`: needs libclang and a C++ compiler).

## Test
- `cd bindgen-integration && cargo test`
- Variants used by CI via `$CARGO_ARGS`: `--release`, `--no-default-features`, `--features runtime`, `--features __testing_only_extra_assertions` (`ci/test.sh` `get_cargo_args`).

## Lint / Format
- Excluded from CI clippy: `cargo clippy --all-targets --workspace --exclude bindgen-integration --exclude tests_expectations -- -D warnings`.
- `cargo +nightly fmt -- --check` still applies to `build.rs` and `src/lib.rs`.

## Run
- Library-only test crate; nothing to run directly.
- `build.rs` has no `rerun-if-changed` lines (grep verified), so cargo's default applies: rerun when any package file changes.
