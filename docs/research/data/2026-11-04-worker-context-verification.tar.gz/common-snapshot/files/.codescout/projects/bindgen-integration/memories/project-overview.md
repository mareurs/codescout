## Purpose
`bindgen-integration` (unpublished, v0.1.0): "A package to test various bindgen features" end-to-end. Its `build.rs` compiles C++ (`cpp/Test.cc`) with `cc`, runs `bindgen` on `cpp/Test.h`, and `src/lib.rs` `include!`s the generated Rust and asserts values on both the Rust and C++ side.

## Tech Stack
- Rust 2021, MSRV 1.70.0, `publish = false`.
- Build-dependencies only: `bindgen` (default features + `experimental`), `cc`.
- Features forward to bindgen: `static`, `runtime`, `__testing_only_extra_assertions`, `__testing_only_libclang_9|16`.

## Runtime Requirements
- libclang >= 9 plus a working C++ compiler (for `cc`).
- Not in the workspace `default-members`, so it must be run from its directory.
- `bindgen-integration/Cargo.lock` is gitignored.

## Entry Points
- `bindgen-integration/build.rs` — `MacroCallback`/`WrappedVaListCallback` (`ParseCallbacks` impls), `setup_macro_test` (compiles `cpp/Test.cc`, builds bindings to `$OUT_DIR/test.rs`), plus an extern/wrap-static-fns setup producing `$OUT_DIR/extern.rs`.
- `bindgen-integration/src/lib.rs` — ~29 `#[test]` functions (`test_static_array`, `test_bitfields_*`, `test_custom_derive`, `test_wrap_static_fns`, ...).
- Run: `cd bindgen-integration && cargo test`.
