## Module Map
- `bindgen-cli/main.rs` — the whole crate (74 lines): argument handling, error reporting.
- `bindgen-cli/Cargo.toml` — features forwarding to `bindgen`, cargo-dist metadata.
- `bindgen-cli/LICENSE`.
- CLI flag definitions are NOT here: `bindgen/options/cli.rs` (`builder_from_flags`, clap structs; imports from the `bindgen` project).

## Key Abstractions
- `bindgen::builder_from_flags(env::args())` -> `(Builder, output writer, verbose flag)` (imported from bindgen, `bindgen/options/cli.rs`).
- `main` — sets a panic hook that prints `print_verbose_err` guidance when `--verbose`.
- `clang_version_check` — logs libclang version; the expected-version assertion is commented out.

## Data Flow
`main` -> `builder_from_flags` (Err -> eprintln + exit 1) -> `builder.generate()` (Err -> "Unable to generate bindings", exit 1) -> `bindings.write(&mut output)`. Panic hook is installed before generate and removed (`take_hook`) afterwards.

## Search Tips
- `semantic_search("command line flags definitions", project_id="bindgen")` — flags live in the bindgen project, not here.
- `grep("builder_from_flags", glob="*.rs")` to see both ends.
- `semantic_search("exit code on error", project_id="bindgen-cli")` hits only `main.rs`.
- Too broad unscoped: "generate", "write" (match the library heavily).
- Semantic index was not built at onboarding; use grep fallback.
