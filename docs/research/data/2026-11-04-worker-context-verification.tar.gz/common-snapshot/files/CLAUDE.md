# rust-bindgen

Generates Rust FFI bindings from C/C++ headers via libclang. Cargo workspace: `bindgen` (library, sources directly in `bindgen/`, entry `bindgen/lib.rs`), `bindgen-cli` (`bindgen-cli/main.rs`), `bindgen-tests` (header snapshot suite), `bindgen-integration` (C++ runtime tests). MSRV 1.70.0. Requires libclang >= 9 (`LIBCLANG_PATH` if several LLVMs).

## Commands
Taken from CONTRIBUTING.md, `.github/workflows/bindgen.yml` and `ci/test.sh`.

- Build: `cargo build`
- Snapshot tests: `cargo test` (root covers bindgen, bindgen-cli, bindgen-tests only)
- Compile expected outputs: `cd bindgen-tests/tests/expectations && cargo test`
- Integration: `cd bindgen-integration && cargo test`
- Update snapshots after intended output change: `BINDGEN_OVERWRITE_EXPECTED=1 cargo test`
- Format: `cargo +nightly fmt -- --check`
- Clippy: `cargo clippy --all-targets --workspace --exclude bindgen-integration --exclude tests_expectations -- -D warnings`
- Run CLI: `cargo run -- header.h`; logs with `RUST_LOG=bindgen`

## Tests
Add a header to `bindgen-tests/tests/headers/` (flags via `// bindgen-flags: ...` on its first lines) and its expected output to `bindgen-tests/tests/expectations/tests/`.

## Codescout discovery / navigation
- This repo is a codescout workspace with projects `testbed`, `bindgen`, `bindgen-cli`, `bindgen-integration`, `bindgen-tests`. Start with `memory(action="list")` and `memory(topic="architecture")`; per project: `memory(project_id="<id>", topic="architecture")`.
- Memory topics per project: project-overview, architecture, conventions, development-commands, domain-glossary, gotchas. Workspace topics: architecture, conventions, development-commands, domain-glossary, gotchas, language-patterns.
- Always scope `semantic_search` with `project_id`, and scope greps with `path`/`glob`: `bindgen-tests/tests/expectations/` (622 files) and `tests/headers/` flood results.
- CLI flag definitions are in `bindgen/options/cli.rs`, not `bindgen-cli/`.
- The semantic index must be built (`index(action="build")`) before `semantic_search`; until then use `grep` and `symbols(path=...)`. Rust LSP may be unavailable; `symbols(name=...)` returning 0 is then not proof of absence.
- Always-on guidance lives in `.codescout/system-prompt.md`.
