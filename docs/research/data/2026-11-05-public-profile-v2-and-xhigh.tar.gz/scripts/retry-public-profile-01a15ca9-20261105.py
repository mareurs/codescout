"""Repeat the known-reference control with disk-backed candidate/build/evidence storage."""
import hashlib
import importlib.util
import json
import pathlib
import shutil
import sys
import traceback

ORIGINAL = pathlib.Path("/tmp/verified-public-profile-01a15ca9-20261105.py")
ROOT = pathlib.Path("/home/marius/.cache/codescout-resident/codescout/public-profile-reference-20261105-v2")
EXPECTED_SCRIPT = "3369ee8d629ff14155deccc96a5021d2b3a1d3a641bc483c8cf29f830d65b7f4"
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    if sha(ORIGINAL) != EXPECTED_SCRIPT:
        raise ValueError("Original control changed; stop before launching")
    if ROOT.exists():
        raise FileExistsError("Exclusive retry root already exists")
    capacity = shutil.disk_usage(ROOT.parent)
    if capacity.free < 30 * 1024**3:
        raise ValueError("Less than 30 GiB free on disk-backed experiment storage")
    spec = importlib.util.spec_from_file_location("public_profile_reference_v2", ORIGINAL)
    control = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(control)
    control.ROOT = ROOT
    preflight = {
        "retry_script": str(pathlib.Path(__file__)),
        "retry_script_sha256": sha(pathlib.Path(__file__)),
        "original_script": str(ORIGINAL), "original_script_sha256": sha(ORIGINAL),
        "failed_root": "/tmp/verified-public-profile-01a15ca9-20261105",
        "new_root": str(ROOT), "disk_available_bytes_before": capacity.free,
        "change": "Only candidate/build/evidence location changes from tmpfs to disk; commands, native argv construction and timeouts unchanged.",
        "provider_calls": 0, "real_credentials_read": False,
    }
    exit_code = 1
    error = None
    try:
        exit_code = control.main()
    except BaseException:
        error = traceback.format_exc()
        raise
    finally:
        if ROOT.exists():
            preflight["control_exit_code"] = exit_code
            preflight["outer_error"] = error
            (ROOT / "retry-preflight.json").write_text(json.dumps(preflight, indent=2) + "\n")
    return exit_code

if __name__ == "__main__":
    sys.exit(main())
