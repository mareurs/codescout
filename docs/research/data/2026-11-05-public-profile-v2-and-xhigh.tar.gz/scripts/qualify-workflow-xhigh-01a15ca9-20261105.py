"""Actual CLI/native xhigh request compatibility; scripted provider, zero model spend."""
import hashlib
import json
import pathlib
import shutil
import sys
from unittest.mock import patch

V = pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
ROOT = pathlib.Path("/home/marius/.cache/codescout-resident/codescout/workflow-xhigh-20261105")
sys.path[:0] = [str(V/"tools/agent_lifecycle"), str(V/"tools/hint_authority_pilot")]
import qualify_workflow as qualification
import run as worker
import transport
from qualify import NoCredential, no_upstream

def main():
    ROOT.mkdir()
    frozen = worker.P/"launch-budget-requalification-20261104"
    shutil.copytree(frozen/"source", ROOT/"source")
    shutil.copytree(frozen/"skill-only-plugin", ROOT/"skill-only-plugin")
    worker.TOKEN = NoCredential()
    transport.Proxy.upstream = no_upstream
    original = worker.one
    def xhigh(label, effort, declaration, scripted, **kwargs):
        if effort != "low" or declaration or scripted is not True:
            raise ValueError("Qualification fixture changed")
        return original(label, "xhigh", declaration, scripted, **kwargs)
    inputs = {"effort": "xhigh", "declaration": False, "scripted": True,
        "script_sha256": hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
        "qualification_sha256": hashlib.sha256(pathlib.Path(qualification.__file__).read_bytes()).hexdigest(),
        "source_commit": "0998c3b64f81c13331db26e0091ff25404272c66"}
    worker.save(ROOT/"inputs.json", inputs)
    with patch.object(worker, "one", xhigh):
        result = qualification.cell(ROOT, frozen, "success")
    worker.save(ROOT/"result.json", result)
    print(json.dumps({"qualified": True, "effort": "xhigh", "cost_usd": result["receipt"]["cost_usd"],
        "workflow_completed": result["receipt"]["workflow_completed"], "root": str(ROOT)}), flush=True)

if __name__ == "__main__":
    main()
