# Independent six-arm CLI delivery review — 2026-11-06

The six preserved scripted cases support the claimed fixture-scoped CLI delivery: actual effort, complete visible rules, exact prompt/protocol, full Recon body, deferred native discovery, successful native calls, terminal receipts, zero forwarding/cost, capture, and recorded cleanup. No actual context/input/cost defect was observed in those six cases. Paid launch remains **unadmitted**: prospective full-plugin identity is missing, and this review does not close the separate grader, controller, pilot, or budget gates.

This is the independent review of wire plan d25ae1f4beca1f9c against spec 28aab59cb5842630. It is separate from the completed runtime-preparation review. Original sources, raw cases, index, HEAD, and real prepared arms were read-only. All experiments used copies under this review directory. The reviewer launched no CLI, container, provider request, or credential operation.

## Findings by actual effect

**Critical: none observed within this review's scope.**

**Important — prospective plugin identity is absent (open: fed51e144f55bcf3).** Original and remaining-five registrations bind the Python sources and prepared files, but do not bind the full external plugin content prospectively. A plugin path and a post-capture Recon-body reference do not establish the plugin version used before execution. The actual captured body can be compared in full, and it matches the post-capture reference; the provenance requirement remains unsatisfied. Retain the six cases, freeze the full plugin prospectively for future admission, and explicitly decide whether a fresh smoke is required. Do not relabel a post-run hash as prospective evidence.

**Important — v2 accepts a truncated Recon body (b927a5226173dfce).** At control-v2.py:47, the checker accepts the marker `A **seam** is a place` without validating the complete body. The actual `truncated_recon` data mutation replaced body-bearing strings with only that marker; v2 still accepted the case. This is a checker false acceptance, not an observed truncation in the original cases. Parent offline v3 checks the full body against an explicitly post-capture reference and rejects the preserved negative. The provenance finding above remains open.

**Important — v2 accepts wrong native-call inputs (bd7a3c20c824d2ce).** The v2 loop at control-v2.py:51–62 checks names and successful matched results without binding each call to the registered arguments. The actual `wrong_symbols_input` mutation changed the symbols path to `unrelated/other.rs`; v2 accepted. Original calls used the expected paths and arguments. Parent offline v3 requires the exact registered inputs, including path/name/include_body and read_file force, and rejects this negative.

**Minor — the initial review prompt control masked a deleted guard (fixed: eb476f6785f282f5).** Removing the whole prompt also removed common guidance. C01, which deleted the full-prompt guard, survived the first control suite because a separate guidance guard still rejected that input. Only after observing that survivor did the reviewer add `altered_prompt_suffix`, changing the final prompt character while preserving guidance/protocol. Original v2 rejected it; C01 accepted it. The original survivor and the refinement are both preserved.

Known historical instrumentation issue **0d9aaf0242c284d8** was filed before this review: original job 111 incorrectly expected native declarations in the first request. Actual CLI deferred discovery is valid. The first case was retained and verified offline; it was not rerun.

All newly observed issues were filed through the MAIN document catalog after literal duplicate checks, each with exactly one cluster tag. The three new Important findings were sent promptly to the parent. Parent remediation is recorded separately below.

## Independent raw evidence

The full audit is `raw-audit.json`, with the executing audit in `audit_raw.py` and its output in `raw-audit.log`. The population is six cases and **36 actual request files**. There are 162 message records across those repeated request histories; that is not a count of unique messages.

- The six actual effort settings are **low, xhigh, low, low, xhigh, low**. Every actual request has the expected model and effort. Launch argv/settings record the 19 USD CLI cap, 20 USD reservation, user/project/local setting sources, allowed tools, and strict MCP configuration.
- Each first request contains its full frozen prompt. Protocol presence is exactly treatment-dependent; the common guidance is preserved. Global and project files in actor contexts match their frozen originals.
- Every actual request contains the ordered complete **visible** global rules (41 lines), plus the visible project rules (18 lines for Nushell; 42 for rust-analyzer). The visibility operation removes HTML comments and blank lines; this does not claim those removed bytes were on the wire.
- Every case contains the full Recon body, with five repeated occurrences across request histories. The reviewer compared the entire body to a post-capture reference. Raw skill SHA256: `2d8ab25571531737c27e3ebc4bebea41dc110b57154c1f4afdb81484f3c3959b`. Reviewer's stripped-body SHA256: `49e937a2161ccc2fba61d8373dc28b2e759cbc73ab4472125f88ec37da1fb8d8`. This is delivery evidence, not prospective plugin identity.
- First requests contain DeferredToolPlaceholder and ToolSearch, with native declarations appearing after discovery. Exact Skill, read_file, and symbols inputs were checked against the intended plan, along with matched non-error, nonempty results. The read_file result contains full common guidance, and the symbols result refers to the intended source main function.
- All six cases have six requests, context-valid receipts, completed workflow receipts, known zero synthetic cost and upper cost, zero forwarded requests, scripted mode, no real credentials, no errors, and no budget-stop signal. Terminal output records successful FUNCTIONAL_TRANSPORT_DONE and no permission denials.
- The only completion check is the explicit `source_guidance_present` fixture, `test -s .codescout/system-prompt.md`. It does not establish public-test success, repair quality, or task completion on the real benchmark.
- Capture metadata and patch bytes match their recorded hashes. The captured change only adds the private-memory ignore entry to .gitignore; it is not a model repair.
- Twelve saved native-launch records (two per case) record 4 CPUs, 32 GiB memory, an executable 4 GiB tmpfs, network none, and UID/GID 1000. Writable mount paths stay within each disposable wire copy. The resource floors were recorded before each case; continuous resource availability or performance was not measured.
- Cleanup names match launch records. Saved inspect results report absence, and completed caller receipts record cleanup success. The reviewer made **no new daemon query**; this is an audit of historical cleanup evidence, not a fresh claim about live daemon state.

The independent audit rehashed **39 Python source files** and **5,886 protected real-preparation files** (5,850 payload files plus 36 other files). They match both registrations; the recorded parent hashes also match. The first completed case appears once, followed by the fixed five-case order with the original indices. The initial job's exit 1 is the known verifier failure; continuation job 112 closed exit 0. The registered closed-parent result matches the first-case offline verification. The real prepared arms retain no actor-start/launch/receipt markers. Original copied raw files were byte-compared to their sources.

## Applied mutations and observed results

These are applied experiments against real copied captures and copied verifier source, not coverage predictions. The fixed population and exact edits are preserved in `data-mutation-results.json`, `code-mutations.json`, the data-mutants directories, each C01–C04 directory, and `prompt-control-refinement.json`.

| Phase | Population | Observed result |
|---|---:|---|
| Original v2 baseline | 6 actual cases | 6 accepted |
| Initial data mutations | 13 | 11 rejected, 2 accepted |
| Added isolated prompt-suffix mutation | 1 | Rejected by v2; accepted by C01 |
| Combined v2 data population | 14 | 12 rejected, 2 accepted |
| Initial copied-v2 guard deletions | 4 | 3 killed, 1 survived |
| Same four deletions after observed-control refinement | 4 | 4 killed, 0 survived |
| Parent offline v3 baseline | 6 actual cases | 6 accepted |
| Parent offline v3 same data population | 14 | 14 rejected |
| Parent offline v3 code-guard population | 6 | 6 killed, 0 survived |

The 14 data controls cover wrong request effort; missing prompt; extra control protocol; missing visible global rule; missing visible project rule; missing native result; missing native call; charged receipt; forwarded request; wrong launch effort; truncated Recon; wrong symbols path; missing treatment protocol; and altered prompt suffix. All wire-review experiments completed without import, syntax, or harness errors.

| Copied v2 mutation | Exact deletion/replacement | Observed detection |
|---|---|---|
| C01 | Full-prompt predicate → `if False:` | Initially survived; killed by isolated suffix control after observed refinement |
| C02 | `for request in requests` → `for request in []` around audit_request | Wrong actual effort/global/project negatives accepted |
| C03 | `for tool in required` → `for tool in set()` | Missing native call/result negatives accepted |
| C04 | Forwarded/scripted receipt predicate → `if False:` | Forwarded-request negative accepted |

A mutation is counted as killed when removing the guard changes a baseline-rejected control into acceptance. The two original v2 data acceptances are findings, not harness failures. The initial C01 survivor is retained as evidence of a deficient review control; it is not silently folded into the later four-of-four result.

## Parent's one offline fix pass

The parent preserved v1, v2, all raw captures, and all initial failures, then produced an offline-only v3. The reviewer read the resulting receipts and checked the copied mutant hashes and per-control results; the reviewer did not launch actors, rerun cases, perform another source review, or claim the parent's run as an independently executed test run.

Copied evidence is under `parent-remediation/`. Verifier SHA256: `a2f7fc7a98094d4cc787b4031be007b4c8ab95624f6ad9dee3fdd3bcbcd97b5f`. Its main raises `Offline verifier only; no CLI actor launch`. Parent v3 rejects the same 14 negatives and retains all six original baselines. The four original guard deletions plus full-Recon and exact-input guard deletions are all killed. The full-body reference is explicitly marked post-capture, with prospective_full_plugin_identity false. Its stripping convention produces a different body hash from the reviewer's reference; neither hash supplies missing prospective plugin provenance.

The parent reports closure of the first-request and two v2 checker defects using these receipts. The review's control issue is catalogued fixed. The prospective plugin issue is confirmed open. These conclusions do not imply general verifier completeness.

## Scope-specific readiness and declined judgments

Ready to retain and cite: the six-case, scripted, zero-provider, fixture-scoped delivery evidence and the preserved negative-control results. **Not admitted for paid launch.**

Before paid admission, resolve prospective full-plugin binding and the required future smoke decision, and satisfy the separate grader-validity, paid-controller/accounting, budget/authorization, and pilot gates applicable to the intended launch. This review provides no substitute for those decisions.

The reviewer declines to judge provider behavior, semantic model-effort effects, repair quality, full public-suite or private-grade success, Docker/kernel isolation beyond recorded controls, fresh live cleanup, full plugin provenance, performance, continuous resource headroom, all possible malformed frames, and future paid-run behavior. It also does not re-review runtime preparation or the unrelated MAIN negative-fixture gate seam.

The parent subsequently reported runtime gate 10e closed exit 0 across PYTHON_LIGHT/FMT/CLIPPY/LEAN/DEFAULT. This is attributed parent evidence, not a gate run by this reviewer, and it does not close the wire provenance gap.

Source hashes are in `source-sha256.json`; report/evidence bytes are bound by `review-evidence-sha256.json`. The JSON companion retains machine-readable counts and provenance distinctions.

Ledger checked: 0d9aaf0242c284d8, fed51e144f55bcf3, b927a5226173dfce, bd7a3c20c824d2ce, eb476f6785f282f5.
