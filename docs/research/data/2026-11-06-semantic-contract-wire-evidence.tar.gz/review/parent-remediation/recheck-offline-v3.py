"""Recheck the same captured cases and actual reviewer mutations; no actor/process launch."""
import importlib.util
import json
import pathlib
import hashlib

ROOT=pathlib.Path(__file__).resolve().parent
REVIEW=pathlib.Path("/tmp/semantic-contract-wire-review-20261106")

def main():
    spec=importlib.util.spec_from_file_location("wire_review_controls",REVIEW/"negative_controls.py")
    controls=importlib.util.module_from_spec(spec);spec.loader.exec_module(controls)
    implementation=ROOT/"control-v3-offline.py"
    module=controls.subject(implementation)
    baseline=[controls.check(module,pathlib.Path(c["copy"]),c) for c in controls.CASES]
    assert all(r["observed"]=="accepted" for r in baseline),baseline
    def negatives(mod):
        observed=[]
        for path in sorted((REVIEW/"data-mutants").iterdir()):
            case=controls.CASES[2] if path.name=="missing_treatment" else controls.CASES[0]
            observed.append({"name":path.name,**controls.check(mod,path,case)})
        return observed
    data=negatives(module)
    assert len(data)==14 and all(r["observed"]=="rejected" for r in data),data
    changes=json.loads((REVIEW/"code-mutations.json").read_text())
    changes += [
      {"id":"C05","old":'if not any(body in s for s in all_strings):',"new":"if False:","purpose":"drop full Recon body guard"},
      {"id":"C06","old":'call.get("input")==expected_inputs[tool]',"new":"True","purpose":"drop exact native call input guard"}]
    source=implementation.read_text()
    out=ROOT/"offline-v3-mutants";out.mkdir()
    mutations=[]
    for item in changes:
        assert source.count(item["old"])==1,item["id"]
        path=out/(item["id"]+".py");path.write_text(source.replace(item["old"],item["new"],1))
        mod=controls.subject(path)
        rows=negatives(mod)
        killed=any(r["observed"]=="accepted" for r in rows)
        (out/(item["id"]+"-controls.json")).write_text(json.dumps(rows,indent=2)+"\n")
        mutations.append({"id":item["id"],"observed":"killed" if killed else "survived",
                          "newly_accepted":[r["name"] for r in rows if r["observed"]=="accepted"],
                          "source_sha256":hashlib.sha256(path.read_bytes()).hexdigest()})
    result={"captured_baseline_cases":len(baseline),"baseline":baseline,"negative_cases":len(data),
            "negative_rejected":sum(r["observed"]=="rejected" for r in data),"data":data,
            "code_mutations":len(mutations),"killed":sum(r["observed"]=="killed" for r in mutations),
            "survived":sum(r["observed"]=="survived" for r in mutations),"mutations":mutations,
            "verifier_sha256":hashlib.sha256(implementation.read_bytes()).hexdigest(),
            "prospective_full_plugin_identity":False}
    (ROOT/"offline-v3-results.json").write_text(json.dumps(result,indent=2)+"\n")
    assert result["survived"]==0,result
    print(json.dumps(result,indent=2))
if __name__=="__main__":main()
