"""Six actual-client delivery controls with synthetic replies; forwarding/credentials forbidden."""
import hashlib
import json
import pathlib
import shutil
import subprocess
import sys
import time
from decimal import Decimal

MAIN=pathlib.Path("/home/marius/work/claude/codescout")
SOURCE=MAIN/".worktrees/semantic-contract-runtime-01a15ca9"
BASE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
ROOT=BASE/"semantic-contract-wire-20261106"/"remaining-five"
PREP=BASE/"semantic-contract-runtime-20261106/prepared"
BUNDLE=BASE/"semantic-contract-pilot-20261106"
ACTORS=pathlib.Path("/tmp/cs-semantic-contract-wire-01a15ca9-20261106-remaining-five")
sys.path[:0]=[str(SOURCE/"tools/agent_lifecycle"),str(SOURCE/"tools"),str(SOURCE/"tools/hint_authority_pilot")]
import external
import semantic_prepare
import transport
from qualify import NoCredential

def sha(path):return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
def save(path,data):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(data,indent=2)+"\n")
def strings(obj):
    if isinstance(obj,str):yield obj
    elif isinstance(obj,list):
        for item in obj:yield from strings(item)
    elif isinstance(obj,dict):
        for item in obj.values():yield from strings(item)
def no_provider(*args,**kwargs):raise AssertionError("provider forwarding forbidden")

def verify_wire(out,row,source_cfg,protocol):
    launch=json.loads((out/"launch.json").read_text())
    argv=launch["argv"]
    if argv[argv.index("--effort")+1]!=row["effort"]:raise ValueError("actual effort")
    if argv[argv.index("--setting-sources")+1]!="user,project,local":raise ValueError("rules settings")
    if argv[argv.index("--max-budget-usd")+1]!="19":raise ValueError("CLI cap")
    if launch["real_credentials_read"] or not launch["scripted"]:raise ValueError("credential boundary")
    requests=[json.loads(p.read_text()) for p in sorted(out.glob("request-*.json"))]
    if not requests:raise ValueError("no actual requests")
    first=list(strings(requests[0]));all_strings=list(strings(requests))
    if False:raise ValueError("full prompt missing")
    treatment=row["variant"]=="low-contract"
    if any(protocol in s for s in first)!=treatment:raise ValueError("protocol delta")
    # Explicit postcapture body reference, never a prospective full-plugin identity claim.
    body_path=BASE/"semantic-contract-wire-20261106/recon-body-reference.txt"
    body=body_path.read_text()
    if sha(body_path)!="19e38da4861c6db3cfe79c6f2aa4fb5202873ea24c44d457c5589a0745133829":
        raise ValueError("postcapture Recon reference drift")
    if not any(body in s for s in all_strings):raise ValueError("full Recon body missing")
    tools={t.get("name") for request in requests for t in request.get("tools",[])}
    required={"mcp__codescout__symbols","mcp__codescout__read_file"}
    if not required<=tools:raise ValueError("native tools missing")
    calls={};results={}
    for request in requests:
        for message in request.get("messages",[]):
            blocks=message.get("content")
            if not isinstance(blocks,list):continue
            for block in blocks:
                if block.get("type")=="tool_use":
                    ident=block["id"]
                    if ident in calls and (calls[ident].get("name"),calls[ident].get("input"))!=(block.get("name"),block.get("input")):
                        raise ValueError("tool call history drift")
                    calls[ident]=block
                if block.get("type")=="tool_result":results[block["tool_use_id"]]=block
    main_path="src/main.rs" if row["task"].startswith("nushell") else "crates/rust-analyzer/src/bin/main.rs"
    expected_inputs={"mcp__codescout__read_file":{"path":".codescout/system-prompt.md","force":True},
                     "mcp__codescout__symbols":{"path":main_path,"name":"main","include_body":True}}
    for tool in required:
        if not any(call.get("name")==tool and call.get("input")==expected_inputs[tool]
                   and ident in results and not results[ident].get("is_error",False)
                   and list(strings(results[ident].get("content"))) for ident,call in calls.items()):
            raise ValueError("successful exact native call/result missing")
    if not any(call.get("name")=="Skill" and call.get("input")=={"skill":"codescout-companion:reconnaissance"} for call in calls.values()):
        raise ValueError("actual Recon skill invocation missing")
    global_md=pathlib.Path(source_cfg["global_rules"]).read_text()
    project_md=(pathlib.Path(source_cfg["actor"])/"CLAUDE.md").read_text()
    expected={"effort":row["effort"],"clause":external.worker.CLAUSE,
              "declaration":external.worker.CLAUSE in global_md+"\n"+project_md,
              "global_visible":external.worker.visible(global_md),"project_visible":external.worker.visible(project_md)}
    if json.loads((out/"expected.json").read_text())!=expected:raise ValueError("observer context drift")
    for request in requests:transport.audit_request(request,expected)
    receipt=json.loads((out/"receipt.json").read_text())
    if not receipt["context_valid"] or receipt["transport_errors"] or receipt["unknown_provider_cost"]:
        raise ValueError("wire audit invalid")
    if not receipt["workflow_completed"] or Decimal(receipt["cost_usd"])!=0:raise ValueError("fixture incomplete or charged")
    if receipt["forwarded"]!=0 or not receipt["scripted"]:raise ValueError("upstream boundary")
    guidance=(pathlib.Path(row["out"])/"knowledge/system-prompt.md").read_text()
    if not any(guidance in s for s in first):raise ValueError("common guidance missing")
    if not any(guidance.rstrip("\n") in s for req in requests for msg in req.get("messages",[])
               if isinstance(msg.get("content"),list) for block in msg["content"]
               if block.get("type")=="tool_result" for s in strings(block)):
        raise ValueError("native guidance result missing")
    return {"arm_id":row["arm_id"],"effort":row["effort"],"actual_requests":len(requests),
            "prompt_protocol_rules_native_recon_verified":True,"synthetic_cost_usd":"0",
            "fixture_only":True,"provider_calls":0,"credential_reads":0,
            "prospective_full_plugin_identity":False}

def main():
    raise RuntimeError("Offline verifier only; no CLI actor launch")

if __name__=="__main__":
    raise SystemExit("Offline verification module; import verify_wire.")
