"""Offline captured-frame controls. Never invokes a client/controller main."""
import importlib.util,json,pathlib,shutil,sys
R=pathlib.Path("/tmp/semantic-contract-wire-review-20261106")
CASES=json.loads((R/"cases.json").read_text())
PROTOCOL=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/semantic-contract-pilot-20261106/protocol.txt").read_text()
def subject(path):
    spec=importlib.util.spec_from_file_location("wire_subject",path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    def forbidden(*a,**k):raise AssertionError("review client/process call forbidden")
    mod.external.launch=forbidden
    mod.transport.Proxy.upstream=forbidden
    return mod
def walk(value,fn):
    if isinstance(value,str):return fn(value)
    if isinstance(value,list):return [walk(x,fn) for x in value]
    if isinstance(value,dict):return {k:walk(v,fn) for k,v in value.items()}
    return value
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False))
def mutate(root,kind,case):
    frames=[json.loads(p.read_text()) for p in sorted(root.glob("request-*.json"))]
    launch=json.loads((root/"launch.json").read_text());receipt=json.loads((root/"receipt.json").read_text())
    if kind=="wrong_request_effort":frames[3]["output_config"]["effort"]="high"
    elif kind=="missing_prompt":frames[0]=walk(frames[0],lambda s:s.replace(case["source_cfg"]["prompt"],"REMOVED_PROMPT"))
    elif kind=="extra_protocol_control":frames[0]["messages"].append({"role":"user","content":PROTOCOL})
    elif kind in ("missing_global","missing_project"):
        expected=json.loads((root/"expected.json").read_text());key="global_visible" if kind=="missing_global" else "project_visible"
        line=max(expected[key],key=len)
        frames=[walk(f,lambda s:s.replace(line,"REMOVED_RULE")) for f in frames]
    elif kind in ("missing_native_result","missing_native_call"):
        ids={b["id"] for f in frames for m in f["messages"] if isinstance(m.get("content"),list) for b in m["content"] if b.get("type")=="tool_use" and b.get("name")=="mcp__codescout__symbols"}
        for f in frames:
            for m in f["messages"]:
                if isinstance(m.get("content"),list):
                    m["content"]=[b for b in m["content"] if not (b.get("type")==("tool_result" if kind=="missing_native_result" else "tool_use") and (b.get("tool_use_id") if kind=="missing_native_result" else b.get("id")) in ids)]
    elif kind=="charged":receipt["cost_usd"]="0.25"
    elif kind=="forwarded":receipt["forwarded"]=1
    elif kind=="wrong_launch_effort":launch["argv"][launch["argv"].index("--effort")+1]="high"
    elif kind=="truncated_recon":
        frames=[walk(f,lambda s:"A **seam** is a place" if "A **seam** is a place" in s else s) for f in frames]
    elif kind=="wrong_symbols_input":
        for f in frames:
            for m in f["messages"]:
                if isinstance(m.get("content"),list):
                    for b in m["content"]:
                        if b.get("type")=="tool_use" and b.get("name")=="mcp__codescout__symbols":b["input"]["path"]="unrelated/other.rs"
    elif kind=="missing_treatment":
        case=case
        frames[0]=walk(frames[0],lambda s:s.replace(PROTOCOL,"REMOVED_PROTOCOL"))
    else:raise ValueError(kind)
    for i,f in enumerate(frames):save(root/f"request-{i}.json",f)
    save(root/"launch.json",launch);save(root/"receipt.json",receipt)
def check(mod,root,case):
    try:
        result=mod.verify_wire(root,case["row"],case["source_cfg"],PROTOCOL)
        return {"observed":"accepted","result":result}
    except (ValueError,KeyError) as e:return {"observed":"rejected","exception":type(e).__name__,"reason":str(e)}
if __name__=="__main__":
    mode=sys.argv[1];module_path=pathlib.Path(sys.argv[2]) if len(sys.argv)>2 else R/"control-v2.py"
    mod=subject(module_path);results=[]
    if mode=="baseline":
        for c in CASES:results.append({"case":c["row"]["arm_id"],**check(mod,pathlib.Path(c["copy"]),c)})
    elif mode=="create":
        kinds=["wrong_request_effort","missing_prompt","extra_protocol_control","missing_global","missing_project","missing_native_result","missing_native_call","charged","forwarded","wrong_launch_effort","truncated_recon","wrong_symbols_input","missing_treatment"]
        for kind in kinds:
            c=CASES[2] if kind=="missing_treatment" else CASES[0]
            dst=R/"data-mutants"/kind;shutil.copytree(c["copy"],dst)
            mutate(dst,kind,c)
            results.append({"mutation":kind,"case":c["row"]["arm_id"],**check(mod,dst,c)})
    elif mode=="guards":
        kinds=["wrong_request_effort","missing_prompt","extra_protocol_control","missing_global","missing_project","missing_native_result","missing_native_call","charged","forwarded","wrong_launch_effort","missing_treatment"]
        for kind in kinds:
            c=CASES[2] if kind=="missing_treatment" else CASES[0]
            results.append({"mutation":kind,**check(mod,R/"data-mutants"/kind,c)})
    else:raise ValueError(mode)
    print(json.dumps(results,indent=2))
    if mode=="guards":sys.exit(0 if all(x["observed"]=="rejected" for x in results) else 1)
