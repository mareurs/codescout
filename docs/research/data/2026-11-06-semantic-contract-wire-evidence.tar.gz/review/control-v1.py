"""Six actual-client delivery controls with synthetic replies; forwarding/credentials forbidden."""
import hashlib
import json
import pathlib
import shutil
import subprocess
import sys
import time
from decimal import Decimal

MAIN=pathlib.Path("/home/marius/work/claude/codescout")
SOURCE=MAIN/".worktrees/semantic-contract-runtime-01a15ca9"
BASE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
ROOT=BASE/"semantic-contract-wire-20261106"
PREP=BASE/"semantic-contract-runtime-20261106/prepared"
BUNDLE=BASE/"semantic-contract-pilot-20261106"
ACTORS=pathlib.Path("/tmp/cs-semantic-contract-wire-01a15ca9-20261106")
sys.path[:0]=[str(SOURCE/"tools/agent_lifecycle"),str(SOURCE/"tools"),str(SOURCE/"tools/hint_authority_pilot")]
import external
import semantic_prepare
import transport
from qualify import NoCredential

def sha(path):return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
def save(path,data):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(data,indent=2)+"\n")
def strings(obj):
    if isinstance(obj,str):yield obj
    elif isinstance(obj,list):
        for item in obj:yield from strings(item)
    elif isinstance(obj,dict):
        for item in obj.values():yield from strings(item)
def no_provider(*args,**kwargs):raise AssertionError("provider forwarding forbidden")

def verify_wire(out,row,source_cfg,protocol):
    launch=json.loads((out/"launch.json").read_text())
    argv=launch["argv"]
    if argv[argv.index("--effort")+1]!=row["effort"]:raise ValueError("actual effort")
    if argv[argv.index("--setting-sources")+1]!="user,project,local":raise ValueError("rules settings")
    if argv[argv.index("--max-budget-usd")+1]!="19":raise ValueError("CLI cap")
    if launch["real_credentials_read"] or not launch["scripted"]:raise ValueError("credential boundary")
    requests=[json.loads(p.read_text()) for p in sorted(out.glob("request-*.json"))]
    if not requests:raise ValueError("no actual requests")
    first=list(strings(requests[0]));all_strings=list(strings(requests))
    if not any(source_cfg["prompt"] in s for s in first):raise ValueError("full prompt missing")
    treatment=row["variant"]=="low-contract"
    if any(protocol in s for s in first)!=treatment:raise ValueError("protocol delta")
    if not any("A **seam** is a place" in s for s in all_strings):raise ValueError("Recon body missing")
    tools={t["name"] for t in requests[0].get("tools",[])}
    if not {"mcp__codescout__symbols","mcp__codescout__read_file"}<=tools:raise ValueError("native tools missing")
    expected=json.loads((out/"expected.json").read_text())
    if expected["effort"]!=row["effort"]:raise ValueError("observer effort")
    # transport audit verifies the full visible global/project rule bodies against expected.
    receipt=json.loads((out/"receipt.json").read_text())
    if not receipt["context_valid"] or receipt["transport_errors"] or receipt["unknown_provider_cost"]:
        raise ValueError("wire audit invalid")
    if not receipt["workflow_completed"] or Decimal(receipt["cost_usd"])!=0:raise ValueError("fixture incomplete or charged")
    guidance=(pathlib.Path(row["out"])/"knowledge/system-prompt.md").read_text()
    if not any(guidance in s for s in first):raise ValueError("common guidance missing")
    if not any(guidance.rstrip("\n") in s for req in requests for msg in req.get("messages",[])
               if isinstance(msg.get("content"),list) for block in msg["content"]
               if block.get("type")=="tool_result" for s in strings(block)):
        raise ValueError("native guidance result missing")
    return {"arm_id":row["arm_id"],"effort":row["effort"],"actual_requests":len(requests),
            "prompt_protocol_rules_native_recon_verified":True,"synthetic_cost_usd":"0",
            "fixture_only":True,"provider_calls":0,"credential_reads":0}

def main():
    if (ROOT/"registration.json").exists() or ACTORS.exists():raise ValueError("one-shot destination exists")
    transport.Proxy.upstream=no_provider
    matrix=json.loads((PREP/"prepared-manifests.json").read_text())
    reg=json.loads((BUNDLE/"prompt-inputs-registration.json").read_text())
    protocol=(BUNDLE/"protocol.txt").read_text()
    source_hashes={str(p):sha(p) for folder in ("agent_lifecycle","hint_authority_pilot") for p in sorted((SOURCE/"tools"/folder).rglob("*.py"))}
    protected={}
    for row in matrix["arms"]:
        out=pathlib.Path(row["out"])
        for p in out.rglob("*"):
            if p.is_file():protected[str(p)]=sha(p)
    if (ROOT/"results.json").exists():raise ValueError("existing wire results")
    save(ROOT/"registration.json",{"arms":matrix["arms"],"source_hashes":source_hashes,
         "prepared_hashes":protected,"helper_sha256":sha(__file__),"provider_calls":0,
         "launch_admitted":False,"checks":"short source-guidance-present fixture; not original public checks",
         "upstream_policy":"Proxy.upstream raises; scripted_plan and NoCredential; no real provider",
         "resource_policy":"root>=80GiB, MemAvailable>=48GiB before each case; sequential capped native reads only"})
    ACTORS.mkdir()
    results=[]
    for index,row in enumerate(matrix["arms"]):
        mem={line.split()[0].rstrip(":"):int(line.split()[1])*1024 for line in pathlib.Path("/proc/meminfo").read_text().splitlines() if len(line.split())>=2 and line.split()[1].isdigit()}
        if shutil.disk_usage(ROOT).free<80*1024**3 or mem["MemAvailable"]<48*1024**3:raise ValueError("wire headroom floor")
        source=pathlib.Path(row["out"]);out=ROOT/"arms"/row["arm_id"]
        cfg=json.loads((source/"prepared.json").read_text())
        snap=pathlib.Path(reg["projects"][row["task"]]["runtime_snapshot_manifest"]).parent
        manifest=json.loads((snap/"manifest.json").read_text())
        semantic_prepare.clone_snapshot(snap,out,manifest)
        actor=ACTORS/str(index);actor.mkdir()
        for name in ("CLAUDE.md","AGENTS.md"):shutil.copyfile(source/"actor-context"/name,actor/name)
        native=json.loads((source/"mcp-native-argv.json").read_text())
        name="cs-semantic-wire-01a15ca9-"+str(index)
        native=semantic_prepare.rewrite_native(native,out,manifest["projects"],name)
        save(out/"mcp-native-argv.json",native)
        cfg.update(actor=str(actor),checks=[{"id":"source_guidance_present","command":"test -s .codescout/system-prompt.md"}],
                   timeout_s=300,check_timeout_s=30,max_continuations=4)
        cfg["files"]={str(p):sha(p) for p in (out/"mcp-native-argv.json",pathlib.Path(cfg["global_rules"]),
                   pathlib.Path(cfg["cli"]),actor/"CLAUDE.md",actor/"AGENTS.md")}
        save(out/"prepared.json",cfg)
        plan=[("Skill",{"skill":"codescout-companion:reconnaissance"}),
              ("mcp__codescout__read_file",{"path":".codescout/system-prompt.md","force":True}),
              ("mcp__codescout__symbols",{"path":"src/main.rs" if row["task"].startswith("nushell") else "crates/rust-analyzer/src/bin/main.rs","name":"main","include_body":True})]
        save(out/"registered-scripted-plan.json",{"plan":plan,"started_unix":time.time(),
             "root_free":shutil.disk_usage(ROOT).free,"host_mem_available":mem["MemAvailable"]})
        external.launch(out,effort=row["effort"],allowance=Decimal("20"),cli_cap=Decimal("19"),
                        scripted_plan=plan,token_path=NoCredential())
        result=verify_wire(out,row,json.loads((source/"prepared.json").read_text()),protocol)
        inventory=subprocess.run(["docker","ps","-aq","--no-trunc"],capture_output=True,text=True,timeout=30)
        if inventory.returncode!=0:raise ValueError("daemon inventory query failed")
        for entry in json.loads((out/"cleanup.json").read_text()):
            inspect=subprocess.run(["docker","inspect",entry["name"]],capture_output=True,text=True,timeout=10)
            if inspect.returncode==0 or "no such" not in inspect.stderr.lower():raise ValueError("container still present or unverifiable")
        for p,d in protected.items():
            if sha(p)!=d:raise ValueError("real prepared arm changed")
        for p,d in source_hashes.items():
            if sha(p)!=d:raise ValueError("source changed during control")
        result["recorded_containers_independently_absent"]=True
        save(out/"result.json",result);results.append(result)
        save(ROOT/"progress.json",{"arms":results,"completed":len(results),"launch_admitted":False})
        print(json.dumps(result),flush=True)
    save(ROOT/"results.json",{"arms":results,"provider_calls":0,"credential_reads":0,"onboarding_calls":0,
         "launch_admitted":False,"all_real_prepared_bytes_unchanged":True,
         "limits":"Synthetic delivery/permission/native capture fixture; no model repair or original public-workflow success."})

if __name__=="__main__":
    try:main()
    except BaseException as exc:
        save(ROOT/"error.json",{"error":repr(exc),"launch_admitted":False})
        raise
