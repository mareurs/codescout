"""Independent closed-artifact audit. No client, Docker or provider operations."""
import pathlib,json,hashlib,re
from decimal import Decimal
R=pathlib.Path("/tmp/semantic-contract-wire-review-20261106")
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/semantic-contract-wire-20261106")
BASE=ROOT.parent
def load(p):return json.loads(pathlib.Path(p).read_text())
def sha(p):
    h=hashlib.sha256()
    with pathlib.Path(p).open("rb") as f:
        for chunk in iter(lambda:f.read(1048576),b""):h.update(chunk)
    return h.hexdigest()
def strings(x):
    if isinstance(x,str):yield x
    elif isinstance(x,list):
        for y in x:yield from strings(y)
    elif isinstance(x,dict):
        for y in x.values():yield from strings(y)
def visible(text):return [x.strip() for x in re.sub(r"<!--.*?-->","",text,flags=re.S).splitlines() if x.strip()]
def ordered(text,lines):
    pos=0
    for line in lines:
        n=text.find(line,pos);assert n>=0,line
        pos=n+len(line)
def option(argv,name):
    assert argv.count(name)==1,(name,argv)
    return argv[argv.index(name)+1]
cases=load(R/"cases.json");original=load(ROOT/"registration.json");cont=load(ROOT/"remaining-five/registration.json")
record1=load("/tmp/codescout-bg/455879-a720241d-bg_00000111.json")
record2=load("/tmp/codescout-bg/455879-a720241d-bg_00000112.json")
assert (record1["state"],record1["exit_code"])==("exited",1)
assert (record2["state"],record2["exit_code"])==("exited",0)
assert original["arms"]==[c["row"] for c in cases]
assert cont["arms"]==[c["row"] for c in cases][1:]
assert original["prepared_hashes"]==cont["prepared_hashes"]
assert original["source_hashes"]==cont["source_hashes"]
for p,d in original["source_hashes"].items():assert sha(p)==d,p
for p,d in original["prepared_hashes"].items():assert sha(p)==d,p
for p,d in cont["parent_hashes"].items():assert sha(p)==d,p
assert sha(ROOT/"control.py")==original["helper_sha256"]
assert sha(ROOT/"control-v2.py")==cont["helper_sha256"]
assert load(ROOT/"first-case-offline-v2.json")==cont["closed_parent_result"]
assert set(x.name for x in (ROOT/"arms").iterdir())=={cases[0]["row"]["arm_id"]}
assert set(x.name for x in (ROOT/"remaining-five/arms").iterdir())=={c["row"]["arm_id"] for c in cases[1:]}
summary=load(ROOT/"remaining-five/results.json")
assert [x["arm_id"] for x in summary["arms"]]==[c["row"]["arm_id"] for c in cases[1:]]
assert summary["provider_calls"]==summary["credential_reads"]==summary["onboarding_calls"]==0 and summary["launch_admitted"] is False
frozen=load(BASE/"semantic-contract-pilot-20261106/prompt-inputs-registration.json")
protocol=(BASE/"semantic-contract-pilot-20261106/protocol.txt").read_text()
skill=pathlib.Path(cases[0]["source_cfg"]["plugin"])/"skills/reconnaissance/SKILL.md"
skill_raw=skill.read_text();assert skill_raw.startswith("---\n")
skill_body=skill_raw.split("---",2)[2].strip()
# This is a post-capture comparison reference, not prospective plugin provenance.
(R/"post-capture-recon-body.txt").write_text(skill_body+"\n")
efforts=["low","xhigh","low","low","xhigh","low"];reports=[];all_request_files=[];start_times=[];native_records=0;total_messages=0
for index,c in enumerate(cases):
    row=c["row"];out=pathlib.Path(c["original"]);source=pathlib.Path(row["out"]);source_cfg=c["source_cfg"]
    assert row["effort"]==efforts[index]
    for forbidden in ("started.json","launch.json","receipt.json"):assert not (source/forbidden).exists()
    cfg=load(out/"prepared.json");launch=load(out/"launch.json");argv=launch["argv"]
    assert cfg["prompt"]==source_cfg["prompt"]
    assert cfg["checks"]==[{"id":"source_guidance_present","command":"test -s .codescout/system-prompt.md"}]
    assert (cfg["timeout_s"],cfg["check_timeout_s"],cfg["max_continuations"])==(300,30,4)
    assert argv[0]==source_cfg["cli"]
    for flag,value in (("--model","claude-sonnet-5-5"),("--effort",row["effort"]),("--setting-sources","user,project,local"),("--max-budget-usd","19"),("--plugin-dir",source_cfg["plugin"]),("--tools","Skill,ToolSearch"),("--allowedTools","Skill,ToolSearch,mcp__codescout__*"),("--output-format","stream-json"),("--input-format","stream-json")):assert option(argv,flag)==value
    assert "--strict-mcp-config" in argv
    assert launch["scripted"] is True and launch["real_credentials_read"] is False
    assert launch["source_image"]==source_cfg["image"] and launch["public_checks"]==cfg["checks"]
    actor=pathlib.Path(cfg["actor"])
    for name in ("CLAUDE.md","AGENTS.md"):
        assert (actor/name).read_bytes()==(source/"actor-context"/name).read_bytes()
    global_text=pathlib.Path(source_cfg["global_rules"]).read_text()
    project_text=(pathlib.Path(source_cfg["actor"])/"CLAUDE.md").read_text()
    assert (out/"client-home/.claude/CLAUDE.md").read_text()==global_text
    for p,d in cfg["files"].items():assert sha(p)==d,p
    settings=load(out/"settings.json")
    assert settings["permissions"]["allow"]==["Skill","ToolSearch","mcp__codescout__*"]
    assert set(settings["hooks"])=={"PostToolUse"}
    assert settings["hooks"]["PostToolUse"][0]["matcher"]=="mcp__codescout__run_command"
    frame_files=sorted(out.glob("request-*.json"))
    assert [p.name for p in frame_files]==["request-"+str(i)+".json" for i in range(6)]
    frames=[load(p) for p in frame_files];all_request_files.extend(str(p) for p in frame_files)
    first=list(strings(frames[0]));guidance=(source/"knowledge/system-prompt.md").read_text()
    assert any(cfg["prompt"] in s for s in first)
    assert any(protocol in s for s in first)==(row["variant"]=="low-contract")
    assert any(guidance in s for s in first)
    body_occurrences=0;calls={};results={};declared=[];skill_call_ids=set()
    for i,frame in enumerate(frames):
        assert frame["model"]=="claude-sonnet-5-5" and frame["output_config"]["effort"]==row["effort"]
        context="\n".join(strings(frame.get("system",[])))+"\n"+"\n".join(strings(frame["messages"]))
        ordered(context,visible(global_text));ordered(context,visible(project_text))
        body_occurrences+=sum(skill_body in s for s in strings(frame["messages"]))
        declared.append([x["name"] for x in frame["tools"]])
        total_messages+=len(frame["messages"])
        for message in frame["messages"]:
            blocks=message.get("content",[])
            if not isinstance(blocks,list):continue
            for block in blocks:
                if block.get("type")=="tool_use":
                    ident=block["id"]
                    if ident in calls:assert calls[ident]==block
                    calls[ident]=block
                elif block.get("type")=="tool_result":
                    ident=block["tool_use_id"]
                    if ident in results:assert results[ident]==block
                    results[ident]=block
    assert body_occurrences>=1
    expected_steps=[
      ("Skill",{"skill":"codescout-companion:reconnaissance"}),
      ("mcp__codescout__read_file",{"path":".codescout/system-prompt.md","force":True}),
      ("mcp__codescout__symbols",{"path":"src/main.rs" if row["task"].startswith("nushell") else "crates/rust-analyzer/src/bin/main.rs","name":"main","include_body":True})]
    registered=load(out/"registered-scripted-plan.json")
    assert registered["plan"]==[[a,b] for a,b in expected_steps]
    assert registered["root_free"]>=80*1024**3 and registered["host_mem_available"]>=48*1024**3
    start_times.append(registered["started_unix"])
    call_evidence=[]
    for name,args in expected_steps:
        matching=[(ident,b) for ident,b in calls.items() if b["name"]==name]
        assert len(matching)==1,(row["arm_id"],name)
        ident,b=matching[0];assert b["input"]==args
        result=results[ident];assert not result.get("is_error",False)
        text=list(strings(result.get("content")));assert text
        if name=="mcp__codescout__read_file":assert any(guidance.rstrip("\n") in s for s in text)
        if name=="mcp__codescout__symbols":assert any(args["path"] in s and "main" in s for s in text)
        call_evidence.append({"name":name,"id":ident,"inputs":args,"result_sha256":hashlib.sha256(json.dumps(result,sort_keys=True).encode()).hexdigest()})
    assert "DeferredToolPlaceholder" in declared[0]
    for name,_ in expected_steps[1:]:
        assert name not in declared[0]
        searches=[b for b in calls.values() if b["name"]=="ToolSearch" and b["input"]=={"query":"select:"+name,"max_results":1}]
        assert len(searches)==1
        search=searches[0]
        assert any(s==name for s in strings(results[search["id"]]))
        assert any(name in names for names in declared[1:])
    receipt=load(out/"receipt.json");stdout=load(out/"stdout.json");life=load(out/"lifecycle-receipt.json")
    assert receipt["requests"]==len(frames)==6
    assert receipt["scripted"] and receipt["context_valid"] and receipt["workflow_completed"]
    assert receipt["forwarded"]==0 and receipt["cost_coverage"]=={"forwarded_at_terminal":0,"forwarded_total":0}
    assert receipt["transport_errors"]==[] and receipt["unknown_provider_cost"] is False and receipt["budget_stop"] is None
    assert Decimal(receipt["cost_usd"])==Decimal(receipt["upper_usage_cost"])==0
    assert receipt["campaign_available_usd"]=="20" and receipt["cleanup_error"] is None and receipt["exit_code"]==0
    assert stdout["subtype"]=="success" and stdout["is_error"] is False and stdout["result"]=="FUNCTIONAL_TRANSPORT_DONE" and stdout["total_cost_usd"]==0
    assert stdout["permission_denials"]==[]
    assert life["status"]=="settled" and life["error"] is None and life["cost_is_final"] and life["all_jobs_succeeded"] and life["cost_usd"]=="0" and life["exit_code"]==0
    verification=load(out/"public-verification.json")
    assert verification["status"]=="completed" and verification["passed"] and verification["error"] is None
    assert [(x["id"],x["command"],x["exit_code"]) for x in verification["checks"]]==[("source_guidance_present","test -s .codescout/system-prompt.md",0)]
    cap=load(out/"candidate-capture.json");patch=(out/"candidate.patch").read_bytes()
    assert cap["complete"] and cap["image"]==source_cfg["image"] and cap["baseline_commit"]==source_cfg["baseline_commit"]
    assert cap["edited"]==[".gitignore"] and len(patch)==cap["bytes"] and hashlib.sha256(patch).hexdigest()==cap["sha256"]
    additions=[line for line in patch.decode().splitlines() if line.startswith("+") and not line.startswith("+++")]
    deletions=[line for line in patch.decode().splitlines() if line.startswith("-") and not line.startswith("---")]
    assert additions==["+.codescout/private-memories/"] and deletions==[]
    assert receipt["artifact_evidence"]["complete"] and receipt["artifact_evidence"]["sha256"]==cap["sha256"]
    cleanup=load(out/"cleanup.json")
    observations=[json.loads(x) for x in (out/"cleanup-observations.jsonl").read_text().splitlines()]
    launches=[load(p) for p in out.glob("mcp-launch-*.json")]
    names=set()
    for native in launches:
        args=native["argv"];names.add(option(args,"--name"));native_records+=1
        for flag,value in (("--cpus","4"),("--memory","32g"),("--tmpfs","/tmp:rw,exec,size=4g,uid=1000,gid=1000"),("--network","none"),("--user","1000:1000")):assert option(args,flag)==value
        for i,x in enumerate(args):
            if x=="--mount":
                fields=dict((s.split("=",1)+[""])[:2] for s in args[i+1].split(","))
                if "readonly" not in fields:assert pathlib.Path(fields["src"]).is_relative_to(out),(row["arm_id"],fields)
    assert names=={x["name"] for x in cleanup}=={x["name"] for x in observations}
    assert all(x["absent"] for x in cleanup)
    assert all(x["inspect_exit_code"]!=0 and "no such" in x["stderr"].lower() for x in observations)
    reports.append({"arm_id":row["arm_id"],"effort":row["effort"],"request_count":len(frames),"full_visible_global_lines":len(visible(global_text)),"full_visible_project_lines":len(visible(project_text)),"full_recon_body_occurrences":body_occurrences,"declarations_by_request":declared,"actual_calls":call_evidence,"native_records":len(launches),"recorded_cleanup_names":sorted(names),"capture_patch_sha256":cap["sha256"],"synthetic_cost_usd":"0","fixture_only":True})
assert start_times==sorted(start_times) and len(set(start_times))==6
report={"status":"pass","cases":reports,"actual_request_files":len(all_request_files),"actual_message_records_across_frames":total_messages,
"native_launch_records":native_records,"real_prepared_hashes_rechecked":len(original["prepared_hashes"]),"source_hashes_rechecked":len(original["source_hashes"]),
"source_and_parent_hashes_unchanged":True,"first_case_not_repeated":True,"fixed_remaining_order":True,
"post_capture_recon_reference_sha256":sha(skill),"post_capture_recon_body_sha256":hashlib.sha256(skill_body.encode()).hexdigest(),
"prospective_full_plugin_identity_established":False,"cleanup_scope":"Saved cleanup observations and caller success checked; no new daemon query by reviewer",
"provider_calls_recorded":0,"credential_reads_recorded":0,"launch_admitted":False,"fixture_only":True}
(R/"raw-audit.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report,indent=2))
