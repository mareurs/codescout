import pathlib,json,sys
R=pathlib.Path("/tmp/semantic-contract-wire-review-20261106")
sys.path.insert(0,str(R))
from negative_controls import subject,check,CASES
results=[]
for name,path in [("baseline",R/"control-v2.py")]+[(n,R/n/"control-v2.py") for n in ("C01","C02","C03","C04")]:
    results.append({"implementation":name,**check(subject(path),R/"data-mutants/altered_prompt_suffix",CASES[0])})
print(json.dumps(results,indent=2))
