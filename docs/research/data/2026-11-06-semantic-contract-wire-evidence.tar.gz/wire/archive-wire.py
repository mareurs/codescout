"""Close captured delivery evidence only; never launch an actor or read credentials."""
import datetime
import hashlib
import io
import json
import pathlib
import subprocess
import tarfile

MAIN = pathlib.Path("/home/marius/work/claude/codescout")
BASE = pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
ROOT = BASE / "semantic-contract-wire-20261106"
REVIEW = pathlib.Path("/tmp/semantic-contract-wire-review-20261106")
OUT = MAIN / "docs/research/data/2026-11-06-semantic-contract-wire-evidence.tar.gz"
RECEIPT = OUT.with_suffix(OUT.suffix + ".json")

def digest(data):
    return hashlib.sha256(data).hexdigest()

def load(path):
    return json.loads(path.read_text())

def main():
    if OUT.exists() or RECEIPT.exists() or (ROOT/"archive-closure-checks.json").exists():
        raise ValueError("Refuse to overwrite closure")
    if not (REVIEW/"review-report.md").is_file():
        raise ValueError("Review not stable")
    jobs = [pathlib.Path("/tmp/codescout-bg/455879-a720241d-bg_"+key+".json") for key in ("00000111","00000112")]
    for path, expected in zip(jobs, (1,0)):
        job = load(path)
        if job["state"] != "exited" or (job["exit_code"] == 0) != (expected == 0):
            raise ValueError("Unexpected original job outcome")
    continuation = load(ROOT/"remaining-five/registration.json")
    populations = {}
    for key in ("prepared_hashes","source_hashes","parent_hashes"):
        hashes = continuation[key]
        for path, expected in hashes.items():
            if digest(pathlib.Path(path).read_bytes()) != expected:
                raise ValueError(key+" drift: "+path)
        populations[key] = len(hashes)
    matrix = load(BASE/"semantic-contract-runtime-20261106/prepared/prepared-manifests.json")["arms"]
    if len(matrix) != 6 or [r["arm_id"] for r in continuation["arms"]] != [r["arm_id"] for r in matrix[1:]]:
        raise ValueError("Fixed population/order changed")
    verification = load(ROOT/"offline-v3-results.json")
    if [r["result"]["arm_id"] for r in verification["baseline"]] != [r["arm_id"] for r in matrix]:
        raise ValueError("Offline verifier did not observe exact six cases")
    if (verification["captured_baseline_cases"],verification["negative_cases"],verification["negative_rejected"],verification["code_mutations"],verification["killed"],verification["survived"]) != (6,14,14,6,6,0):
        raise ValueError("Offline controls unresolved")
    if digest((ROOT/"control-v3-offline.py").read_bytes()) != verification["verifier_sha256"]:
        raise ValueError("Verifier drift")
    inventory = subprocess.run(["docker","ps","-aq","--no-trunc"],capture_output=True,text=True,timeout=30)
    if inventory.returncode:
        raise ValueError("Daemon unavailable")
    cases = []
    requests = 0
    for index,row in enumerate(matrix):
        real = pathlib.Path(row["out"])
        if (real/"started.json").exists() or (real/"launch.json").exists():
            raise ValueError("Real pilot arm unexpectedly launched")
        out = (ROOT if index == 0 else ROOT/"remaining-five")/"arms"/row["arm_id"]
        receipt = load(out/"receipt.json")
        files = sorted(out.glob("request-*.json"))
        if len(files) != receipt["requests"] or receipt["forwarded"] != 0 or receipt["cost_usd"] != "0" or not receipt["scripted"]:
            raise ValueError("Unexpected request/cost boundary")
        if not receipt["workflow_completed"] or not receipt["context_valid"]:
            raise ValueError("Fixture incomplete")
        observations=[]
        for entry in load(out/"cleanup.json"):
            inspect=subprocess.run(["docker","inspect",entry["name"]],capture_output=True,text=True,timeout=10)
            if inspect.returncode == 0 or "no such" not in inspect.stderr.lower():
                raise ValueError("Container present or absence unverifiable")
            observations.append({"name":entry["name"],"inspect_exit_code":inspect.returncode,"stderr":inspect.stderr,"absent":True})
        cases.append({"index":index,"arm_id":row["arm_id"],"captured_requests":len(files),"cleanup":observations})
        requests += len(files)
    closure={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"cases":cases,
             "actual_cli_cases":len(cases),"captured_request_files":requests,
             "protected_hash_populations_rechecked":populations,
             "real_prepared_arms_unstarted":True,"provider_calls":0,"credential_reads":0,"onboarding_calls":0,
             "synthetic_cost_usd":"0","daemon_inventory_exit_code":inventory.returncode,
             "prospective_full_plugin_identity":False,"launch_admitted":False,
             "limits":"Synthetic delivery fixtures only, no model behavior or full-public-suite/repair evidence. Full plugin prospective identity remains unestablished."}
    (ROOT/"archive-closure-checks.json").write_text(json.dumps(closure,indent=2)+"\n")
    payload={}
    def add(name,path):
        if name in payload or path.is_symlink() or not path.is_file():
            raise ValueError("Unsafe or duplicate archive payload "+name)
        payload[name]=(str(path),path.read_bytes())
    excluded={"knowledge","member-state","native-home"}
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or "__pycache__" in path.parts:
            continue
        rel=path.relative_to(ROOT)
        parts=rel.parts
        if "arms" in parts:
            index=parts.index("arms")
            if len(parts)>index+2 and parts[index+2] in excluded:
                continue
        add("wire/"+rel.as_posix(),path)
    for path in sorted(REVIEW.rglob("*")):
        if path.is_file() and "__pycache__" not in path.parts and path.suffix in {".py",".json",".jsonl",".log",".md",".txt",".patch"}:
            add("review/"+path.relative_to(REVIEW).as_posix(),path)
    for path in jobs:
        add("jobs/"+path.name,path)
        job=load(path)
        add("jobs/"+job["handle"].lstrip("@")+"-"+pathlib.Path(job["log_path"]).name,pathlib.Path(job["log_path"]))
    add("plan.md",MAIN/"docs/superpowers/plans/2026-11-06-semantic-contract-wire.md")
    manifest={"utc":closure["utc"],"scope":closure["limits"],
              "excludes":"Writable knowledge/member-state/native-home databases and model caches, credentials. Includes actor instructions and captured request bytes.",
              "files":[{"name":n,"source":p,"bytes":len(data),"sha256":digest(data)} for n,(p,data) in sorted(payload.items())]}
    with tarfile.open(OUT,"w:gz") as tar:
        for name,(_,data) in sorted(payload.items()):
            info=tarfile.TarInfo(name); info.size=len(data); info.mtime=0
            tar.addfile(info,io.BytesIO(data))
        data=(json.dumps(manifest,indent=2)+"\n").encode()
        info=tarfile.TarInfo("MANIFEST.json"); info.size=len(data); info.mtime=0
        tar.addfile(info,io.BytesIO(data))
    with tarfile.open(OUT) as tar:
        recovered=json.load(tar.extractfile("MANIFEST.json"))
        if len(tar.getmembers())!=len(payload)+1:
            raise ValueError("Archive population mismatch")
        for item in recovered["files"]:
            data=tar.extractfile(item["name"]).read()
            if len(data)!=item["bytes"] or digest(data)!=item["sha256"]:
                raise ValueError("Archive payload mismatch")
    result={"archive":str(OUT),"sha256":digest(OUT.read_bytes()),"bytes":OUT.stat().st_size,
            "payload_files":len(payload),"manifest_files":1,"all_payloads_reopened_and_hash_verified":True,"closure":closure}
    RECEIPT.write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))

if __name__=="__main__":
    main()
