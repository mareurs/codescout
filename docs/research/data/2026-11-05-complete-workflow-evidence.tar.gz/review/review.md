# Independent review — complete-workflow calibration

**Verdict: accepted for the reviewed change.** No remaining Critical or Important findings in this finite review. The parent must finish its repository gate, commit the exact reviewed source, install the review binding, and run the registered no-cost admission check before launching. This review does not establish paired model quality or external transfer.

## Scope and source identity

Read-only review of V `/home/marius/.codex/worktrees/615e/codescout`, branch `research/fixed-acceptance-population-20261101`, initial BASE/HEAD `7e57bf8f91a2fd369411a2d89db51cf97c070d9f`. Reviewed the five requested uncommitted paths against MAIN plan `ea0f4cf74fd4ba8f`, V CLAUDE.md/testing discipline and the code-reviewer template.

Only the five requested tool directories were copied into this exclusive resident-scratch directory. No checkout/index/branch mutations, native Docker execution, model/provider calls, credentials, paid helper, or peer/subagent dispatch occurred. Mutation edits used Codescout edit_code on the private copy. Source snapshots include the new/untracked files.

Initial source hashes: [source-hashes.json](source-hashes.json). Final source hashes, including all five changed paths and all 39 copied files: [source-hashes-final.json](source-hashes-final.json). The parent applied a controlled source delta during review: regression tests plus the explicit unknown-cost finality flag. The focused recheck below covers that delta.

## Strengths

- Both arms reserve their full USD4 before the first call against the new USD8 allocation, retaining the USD40 thread ceiling and prior spend.
- An exclusive start marker prevents implicit resume. Raw stream and stdout costs/session identities are reconciled before continuing; known costs persist atomically before grading. The final source marks totals nonfinal before each launch.
- Success requires registered public commands and exit codes, settled lifecycle, valid context, and private acceptance. CLI completion alone cannot set acceptance.
- Default legacy CLI budget remains0.65; the explicit workflow-only custom budget reaches the actual argv and is bounded by the paid proxy allowance.
- The full composition extends the legacy frozen-input fingerprint with all five Python module directories, public manifest and plan; review binds qualification and acceptance proof bytes.

## Findings and disposition

No remaining Critical findings. Five Important regression-guard gaps were reported immediately, filed by the parent, fixed, and observed killed on focused recheck:

| Issue | Original site / missing test | Applied original mutation | Initial result | Final focused result |
| --- | --- | --- | --- | --- |
| 7ecbe51427e022c5 | driver.py:43; test_driver.py default composition discovery | Remove agent_lifecycle from default directory inventory | M04 survived,13 tests | R04 killed,17 tests |
| d468588cea173d29 | driver.py:56; test_driver.py multi-terminal reconciliation | Select first stream terminal instead of latest | M05 survived,13 tests | R05 killed,17 tests |
| edf04832a5809d11 | driver.py:67; test_driver.py independent total coverage | Remove forwarded_total equality | M06 survived,13 tests | R06 killed,17 tests |
| c29e0d85ccbd0d27 | driver.py:114 final; test_driver.py lifecycle predicate | Remove settled-lifecycle requirement while other success flags remain true | M07 survived,13 tests | R07 killed,17 tests |
| c51237303dcfa962 | run.py:130; test_runtime.py legacy launch argv | Change only default CLI argv0.65 to0.64 | M12 survived,44 tests | R12 killed,44 tests |

The parent separately found and fixed b0214bf90135b9b1: an unknown interrupted attempt left a total without an explicit nonfinal marker. Reviewer applied R13, changing the prelaunch `cost_is_final=False` assignment to True; the17-test driver suite failed at the new finality assertion. Restored source passes.

M03 survived removal of the registration prior-thread arithmetic guard. It was not promoted to a defect: real historical() requires the exact closed-pilot total and check() compares the full registered plan; the changed-history fixture remained rejected. This review has not experimentally removed the sibling fixed-total validator, so it does not claim independently proven semantic inertness. The survival remains visible in the matrix.

No Minor findings requiring action.

## Applied mutation evidence

All counts below count actual separate applied mutations and observed unittest process exits, not inferred coverage. An exit1 includes an actual FAIL/ERROR header; complete raw logs are retained.

| ID | Mutation | Suite tests | Exit | Result |
| --- | --- | ---: | ---: | --- |
| M01 | Pair reserve threshold8→4 |13|1|Killed|
| M02 | Run low twice instead of low/xhigh |13|1|Killed|
| M03 | Remove prior-thread arithmetic guard |13|0|Survived; disposition above|
| M04 | Drop lifecycle directory from default fingerprint |13|0|Survived; fixed|
| M05 | Read first stream terminal |13|0|Survived; fixed|
| M06 | Drop total-forwarded coverage equality |13|0|Survived; fixed|
| M07 | Drop settled-lifecycle acceptance predicate |13|0|Survived; fixed|
| M08 | Remove cost persistence before private grading |13|1|Killed|
| M09 | Bypass exact public checks |13|1|Killed|
| M10 | Remove context-invalid stop |13|1|Killed|
| M11 | Remove custom CLI budget≤proxy allowance check |44|1|Killed|
| M12 | Default legacy CLI argv0.65→0.64 |44|0|Survived; fixed|

Initial matrix:12 applied,6 killed,6 survived. Focused closeout:6 applied (R04/R05/R06/R07/R12 plus new R13),6 killed,0 survived. This is not an assertion that all original12 mutations were rerun after the final source delta.

Every mutation has an exact `Mxx_*.patch` or `Rxx_*.patch`, raw `.log`, and result `.json` in this directory. Patch reconstruction SHA-256 was checked against the bytes actually executed. After each mutation the edited file compared byte-identically with its snapshot. Final [restoration-final.json](restoration-final.json) verifies all39 copied files and unchanged final V hashes for all five requested files.

[aggregate.json](aggregate.json) includes exact failure headers, per-run counts/statuses and all evidence references. [mutations.json](mutations.json) and [focused-mutations.json](focused-mutations.json) identify exact symbol, old/new text and suite.

## Final restored verification

All five offline suites were run again after final restoration, each in its own Python process:

| Suite | Tests | Exit |
| --- | ---: | ---: |
| hint_authority_workflow |17|0|
| agent_lifecycle |44|0|
| hint_authority_pilot |28|0|
| hint_authority_completion |9|0|
| hint_authority_resume |3|0|

Total101 unittest test methods across these five discovered suites; subtests are not counted as separate methods. Logs are `final-restored-<suite>.log`; [final-restored-tests.json](final-restored-tests.json) records actual command outcomes. Repository Rust/full gate remains parent-owned; reviewer did not run or claim its result.

## Proof binding and readback

Campaign: `/home/marius/.cache/codescout-resident/codescout/complete-workflow-calibration-20261105`.

- Complete composition, calculated by canonical V driver.composition only: `faf053c592896d9bdabb98ec554258a4584abdfdf89e4c04bee0b87a9bfa739a`.
- plan.json SHA-256: `4f02d5617c80fb23d402fb69ed169b62cada2ba4f18829aa55e7de375fe1c1c5`.
- qualification.json SHA-256: `d3f1e46878f8e6cac9f2e631ebd2c2b1eb68e1fab837a677e81ebc4b01e6792c`.
- acceptance-controls.json SHA-256: `f7c687a442db2980cc1c72f6672060146c288c2cf36ddc233a7e97f586637497`.

Read-only independent readback verified all16 runtime source hashes, the qualification readback hash, four actual saved receipt hashes and their launch argv budget4. Every saved request file passed core.audit_request:19 low-success,21 low-repair,19 low-unknown,19 xhigh-success. Each receipt is scripted, forwarded0 and cost0. Success/repair/success completed; unknown did not. The12 recorded cleanup inspection results all report absent identities; reviewer did not launch new Docker inspections.

For private acceptance, reviewer verified the recorded2060 old-candidate file hashes for each of baseline/positive and all four raw grade-log hashes. The baseline log contains two actual assertion failures after successful compilation. Positive logs report2 acceptance tests,9 chunk tests and39 indexer tests passing. The parent's equality proof between newly prepared and previous candidates is bound by acceptance-controls.json; reviewer did not prepare another candidate or rerun grading.

Raw proof metadata and exact checked paths: [proof-readback.json](proof-readback.json). Original transport snapshots of campaign driver/tests are explicitly labeled unexecuted snapshots in qualification.json; the current campaign code is bound separately by this composition and mutation review.

## Declined to judge

- Fresh low/xhigh model quality, complete paid repair outcomes and transfer: no new provider run has happened in this review; scripted controls do not establish them.
- Full V gate outcome: execution belongs to the parent and was not independently observed by this reviewer.
- Live cleanup at review time: checked stored inspection evidence; new native commands were forbidden.
- M03 independent semantic inertness: surrounding fixed-total/plan checks explain why the existing fixture still rejects; no sibling-validator removal was performed.
- Newly prepared private-control candidate equality: accepted the parent's hash-bound equality proof and verified stored prior-candidate bytes/logs; preparing candidates was outside reviewer authorization.
- Statistical authority effects/generalization: the registered task is exposed and the pair is diagnostic.

## Assessment

**Ready for the reviewed change: Yes.** The five verified test gaps are closed by observed mutation kills, and the final restored101-test offline suite is green. The exact reviewed composition and proof hashes may be used for the parent's review.json once its gate/commit/admission steps are complete. Any source/proof changes invalidate this binding. No merge/push or provider launch is authorized by the reviewer artifact itself.
