"""Withdraw remaining admission only after first cost is reconciled; preserve signed review."""
import json,pathlib
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/complete-workflow-calibration-20261105")
receipt=json.loads((ROOT/"workflow-0-low/receipt.json").read_text())
ledger=json.loads((ROOT/"results.json").read_text())
assert receipt["unknown_provider_cost"] is False and receipt["cost_usd"]=="0.4249394"
assert receipt["lifecycle"]["error"]=="TimeoutError: lifecycle deadline exceeded"
assert ledger["cost_is_final"] is True and len(ledger["results"])==1
assert not (ROOT/"workflow-1-xhigh").exists()
reason=dict(reason="Cold Rust workflow exceeded an unqualified warm-cache deadline",
    issue="39785443931155d4 is a separate identity issue; see cold-workflow deadline issue",
    first_known_cost_usd=receipt["cost_usd"],remaining_model_admission=False,
    code_review_still_accepted=True,source_unchanged=True,operator_scope="Autonomous experiment validity containment")
with (ROOT/"admission-revoked.json").open("x") as output:json.dump(reason,output,indent=2)
(ROOT/"review.json").rename(ROOT/"review-before-cold-deadline-revocation.json")
print(json.dumps(reason))
