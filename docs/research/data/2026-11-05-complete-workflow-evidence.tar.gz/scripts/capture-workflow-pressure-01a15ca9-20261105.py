"""Read-only cgroup memory-pressure sample, scoped to a live attested campaign worker."""
import json,pathlib,subprocess,time
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/complete-workflow-calibration-20261105")
rows=[]
for out in ROOT.glob("workflow-[01]-*"):
    owner=out/"record-owner.json"
    if not owner.exists():continue
    name=json.loads(owner.read_text())["name"]
    inspected=subprocess.run(["docker","inspect",name],capture_output=True,text=True,timeout=5)
    if inspected.returncode:continue
    identity=json.loads(inspected.stdout)[0]
    assert identity["Config"]["Labels"].get("codescout.hfa")==name
    values={}
    for filename in ("memory.current","memory.max","memory.events","memory.pressure"):
        read=subprocess.run(["docker","exec",name,"cat","/sys/fs/cgroup/"+filename],capture_output=True,text=True,timeout=5)
        if read.returncode==0:values[filename]=read.stdout.strip()
    rows.append(dict(observed_unix_s=time.time(),attempt=out.name,container_id=identity["Id"],cgroup_values=values))
with (ROOT/"resource-pressure-observations.jsonl").open("a") as output:
    for row in rows:output.write(json.dumps(row)+"\n")
print(json.dumps(rows,indent=2))
