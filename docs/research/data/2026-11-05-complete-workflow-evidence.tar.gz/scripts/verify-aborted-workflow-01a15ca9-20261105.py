"""Independent aborted-cohort readback. Never restores admission or calls a provider."""
import hashlib,importlib.util,json,pathlib,re,subprocess,sys
from decimal import Decimal
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/complete-workflow-calibration-20261105")
sys.path[:0]=[str(V/"tools/hint_authority_pilot")]
from core import amount,audit_request,extract_result
def load(p):return json.loads(pathlib.Path(p).read_text())
def digest(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def names(p):return set(re.findall(r"^test (\S+) \.\.\. ok$",pathlib.Path(p).read_text(errors="replace"),re.M))
def main():
    spec=importlib.util.spec_from_file_location("aborted_campaign",V/"tools/hint_authority_workflow/driver.py")
    driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
    assert load(ROOT/"plan.json")==driver.registration()
    fp=driver.composition(ROOT)
    review=load(ROOT/"review-before-cold-deadline-revocation.json")
    assert review["accepted"] is True and review["fingerprint"]==fp
    for key,file in (("qualification_sha256","qualification.json"),("acceptance_sha256","acceptance-controls.json"),("plan_sha256","plan.json")):
        assert review[key]==digest(ROOT/file)
    assert digest(review["review_report"])==review["review_report_sha256"]
    for path,want in load(review["source_hashes"])["five_files"].items():assert digest(V/path)==want
    qualification=load(ROOT/"qualification.json")
    assert qualification["qualified"] is True and qualification["provider_cost_usd"]=="0"
    assert qualification["cli_budget_usd"]=="4" and qualification["cells"]==["low:success","low:repair","low:unknown","xhigh:success"]
    for path,want in qualification["runtime_hashes"].items():assert digest(path)==want
    controls=load(ROOT/"acceptance-controls.json")
    assert controls["baseline_rejected"] and controls["reference_accepted"] and controls["oracle_version"]==2
    revoked=load(ROOT/"admission-revoked.json")
    assert revoked["remaining_model_admission"] is False and not (ROOT/"review.json").exists()
    assert not (ROOT/"workflow-1-xhigh").exists()
    job=load("/tmp/codescout-bg/455879-a720241d-bg_00000067.json")
    assert job["state"]=="exited" and job["exit_code"]==1
    assert "review.json" in pathlib.Path(job["log_path"]).read_text()
    ledger=load(ROOT/"results.json")
    assert len(ledger["results"])==1 and ledger["cost_is_final"] is True and not ledger.get("pair_completed",False)
    row=ledger["results"][0];out=ROOT/"workflow-0-low";receipt=load(out/"receipt.json")
    assert row["effort"]=="low" and row["declaration"] is False and row["fingerprint"]==fp
    raw=[json.loads(l) for l in (out/"stream.jsonl").read_text().splitlines() if l.strip()]
    terminals=[r for r in raw if r.get("type")=="result"]
    terminal=extract_result(terminals[-1:],receipt["session_id"])
    assert all(r["session_id"]==receipt["session_id"] for r in terminals)
    cost=terminal["cost"]
    assert cost==amount(row["cost_usd"])==amount(receipt["cost_usd"])==amount(ledger["new_cost_usd"])==Decimal("0.4249394")
    assert not receipt["unknown_provider_cost"] and not receipt["scripted"] and receipt["budget_stop"] is None
    assert receipt["cost_coverage"]["forwarded_at_terminal"]==receipt["cost_coverage"]["forwarded_total"]==receipt["forwarded"]
    assert cost<=4 and amount(receipt["upper_usage_cost"])<=4 and not receipt["transport_errors"]
    requests=list(out.glob("request-*.json"));expected=load(out/"expected.json")
    assert expected["effort"]=="low" and expected["declaration"] is False
    assert len(requests)==receipt["requests"]
    for path in requests:audit_request(load(path),expected)
    assert load(out/"context-audit.json")["valid"] is True
    assert receipt["lifecycle"]["status"]=="incomplete" and receipt["lifecycle"]["error"]=="TimeoutError: lifecycle deadline exceeded"
    assert receipt["public_verification"] is None and not receipt["workflow_completed"]
    assert row["workflow_verified"] is False and row["accepted"] is False
    assert not list(out.glob("verification-*/receipt.json"))
    assert receipt["cleanup_error"] is None
    positive=next(r for r in controls["controls"] if r["kind"]=="positive")
    reference_only={
        "librarian::catalog::chunk::tests::a_line_offset_shifts_every_range_and_moves_no_entry_token",
        "librarian::indexer::tests::a_stored_chunks_range_points_at_that_text_in_the_file",
    }
    patch_text=(ROOT/"reference.patch").read_text()
    for name in reference_only:
        assert "+    #[test]\n+    fn "+name.rsplit("::",1)[1]+"(" in patch_text
    required={step["filter"]:names(step["log"])-reference_only for step in positive["grade"]["steps"]}
    grade=row["grade"];assert grade["exit_code"]==0
    private=[]
    assert len(grade["steps"])==len(required)
    for step in grade["steps"]:
        passed=names(step["log"])
        assert step["exit_code"]==0 and step["process_exit"]==0 and step["execution_witness"] is True
        assert required[step["filter"]] and required[step["filter"]].issubset(passed)
        private.append(dict(filter=step["filter"],passed_named_tests=len(passed),log_sha256=digest(step["log"])))
    actor=out/"project"
    patch=subprocess.check_output(["git","diff","--binary"],cwd=actor)
    status=subprocess.check_output(["git","status","--porcelain"],cwd=actor,text=True)
    (out/"candidate.patch").write_bytes(patch);(out/"candidate-status.txt").write_text(status)
    cleanup=load(out/"cleanup.json")
    assert cleanup and all(r["absent"] for r in cleanup)
    live=[json.loads(l) for l in (ROOT/"runtime-live-observations.jsonl").read_text().splitlines()]
    own=[r for r in live if r["attempt"]==out.name]
    ids={r["container_id"] for r in own};assert len(ids)==1
    inspections=[]
    for identity in sorted({r["name"] for r in cleanup}|ids):
        p=subprocess.run(["docker","inspect",identity],capture_output=True,text=True,timeout=5)
        assert p.returncode!=0 and "no such" in p.stderr.lower()
        inspections.append(dict(identity=identity,exit_code=p.returncode,stderr=p.stderr))
    thread=amount(ledger["thread_cost_usd"])
    assert thread==Decimal("31.797419199999999964")+cost<=40
    result=dict(verified=True,complete_pair=False,cohort_status="aborted_after_low_deadline_before_xhigh",
        fingerprint=fp,paid_arms=1,completed_workflows=0,accepted_workflows=0,private_patch_passes=1,
        new_model_cost_usd=str(cost),thread_cost_usd=str(thread),thread_remaining_within_40=str(Decimal(40)-thread),
        original_pilot_cost_usd="2.57626490000000013",
        low=dict(model_requests=len(requests),cli_terminal_events=len(terminals),workflow_wall_s=receipt["wall_s"],
            workflow_error=receipt["lifecycle"]["error"],public_checks_executed=0,private_named_tests=private,
            context_valid=True,patch_sha256=digest(out/"candidate.patch"),receipt_sha256=digest(out/"receipt.json")),
        cleanup_inspections=inspections,admission_withdrawn=True,withdrawal_issue="f458f9840337469e",
        background_identity_gap="39785443931155d4: mocked replacement accepted; actual LOW samples show one ID, not continuous attestation",
        evidence_limit="Native background full log was not copied before container cleanup; only earlier tail observations remain. No public verification ran.",
        inference_limit="Patch passes private tests, but workflow was deadline-censored. No low/xhigh quality/cost or generic transfer comparison.")
    (ROOT/"independent-paid-readback.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))
if __name__=="__main__":main()
