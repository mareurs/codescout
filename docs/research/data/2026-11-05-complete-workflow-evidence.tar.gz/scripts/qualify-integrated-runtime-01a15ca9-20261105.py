"""Actual CLI/native compatibility of the integrated runtime, no paid forwarding."""
import hashlib
import json
import pathlib
import shutil
import subprocess
import sys
from unittest.mock import patch

V = pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
BASE = pathlib.Path("/home/marius/.cache/codescout-resident/codescout/verified-worker-runtime-20261105")
ROOT = BASE/"qualification"
sys.path[:0] = [str(V/"tools/agent_lifecycle"), str(V/"tools/hint_authority_pilot")]
import qualify_workflow as qualification
import workflow
import run as worker

original_check = workflow.native_check
def observed_check(out, image, command, log, timeout_s):
    code = original_check(out, image, command, log, timeout_s)
    owner = json.loads((out/"record-owner.json").read_text())
    process = subprocess.run(["docker","inspect",owner["container_id"]],check=True,capture_output=True,text=True,timeout=5)
    row = json.loads(process.stdout)[0]
    host = row["HostConfig"]
    actor = next(m for m in row["Mounts"] if m["Destination"] == "/testbed")
    env = dict(item.split("=",1) for item in row["Config"]["Env"] if "=" in item)
    witness = {"container_id":row["Id"],"image":row["Image"],"init":host["Init"],
        "nano_cpus":host["NanoCpus"],"pids_limit":host["PidsLimit"],"memory_bytes":host["Memory"],
        "actor_source":actor["Source"],"actor_read_write":actor["RW"],
        "cargo_target_dir":env["CARGO_TARGET_DIR"],"command":command,"exit_code":code}
    assert witness["init"] is True and witness["nano_cpus"] == 2000000000 and witness["pids_limit"] == 512
    assert witness["container_id"] == owner["container_id"] and witness["image"] == image
    assert pathlib.Path(witness["actor_source"]) == (out/"project").resolve()
    assert witness["actor_read_write"] and witness["cargo_target_dir"] == "/testbed/target"
    with (out/"native-runtime-observations.jsonl").open("a") as output:
        output.write(json.dumps(witness)+"\n")
    return code

def main():
    workflow.native_check = observed_check
    files = []
    for directory in ("agent_lifecycle","hint_authority_pilot","hint_authority_completion","hint_authority_resume"):
        files += [p for p in (V/"tools"/directory).glob("*.py") if not p.name.startswith("test_")]
    hashes = {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
    sys.argv = [qualification.__file__,str(ROOT)]
    qualification.main()
    worker.save(ROOT/"integrated-runtime-inputs.json",{"runtime_source_hashes":hashes,
        "observer_script_sha256":hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()})
    frozen = worker.P/"launch-budget-requalification-20261104"
    xroot = BASE/"qualification-xhigh"
    xroot.mkdir()
    shutil.copytree(frozen/"source",xroot/"source")
    shutil.copytree(frozen/"skill-only-plugin",xroot/"skill-only-plugin")
    original_one = worker.one
    def xhigh(label,effort,declaration,scripted,**kwargs):
        assert effort == "low" and not declaration and scripted
        return original_one(label,"xhigh",declaration,scripted,**kwargs)
    with patch.object(worker,"one",xhigh):
        result = qualification.cell(xroot,frozen,"success")
    worker.save(xroot/"result.json",result)
    for path,want in hashes.items():
        assert hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest() == want
    worker.save(BASE/"qualification-summary.json",{"qualified":True,"low_controls":["success","repair","unknown"],
        "xhigh_controls":["success"],"runtime_source_hashes":hashes,"provider_cost_usd":"0"})
    print(json.dumps({"integrated_qualified":True,"provider_cost_usd":"0","root":str(BASE)}),flush=True)

if __name__ == "__main__":
    main()
