#!/usr/bin/env python3
"""Independently read complete qualification populations and inspect exact cleanup."""
import hashlib, json, pathlib, subprocess
from decimal import Decimal
BASE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/verified-worker-runtime-20261105-final")
def load(p): return json.loads(p.read_text())
def lines(p): return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    summary=load(BASE/"qualification-summary.json")
    assert summary["qualified"] and summary["provider_cost_usd"]=="0"
    for path,want in summary["runtime_source_hashes"].items():
        assert digest(pathlib.Path(path))==want, path
    rows=[]
    absent=[]
    for arm,mode in (("low","success"),("low","repair"),("low","unknown"),("xhigh","success")):
        out=BASE/("qualification" if arm=="low" else "qualification-xhigh")/mode
        receipt=load(out/"receipt.json")
        assert receipt["scripted"] and receipt["forwarded"]==0
        assert Decimal(receipt["cost_usd"])==0 and not receipt["unknown_provider_cost"]
        assert receipt["transport_errors"]==[] and receipt["budget_stop"] is None
        assert receipt["cleanup_error"] is None
        expected_turns=3 if mode=="repair" else 2
        life=receipt["lifecycle"]
        assert life["turns"]==expected_turns and life["continuations"]==expected_turns-1
        assert life["session_id"]==receipt["session_id"]==load(out/"launch.json")["session_id"]
        terminals=[r for r in lines(out/"stream.jsonl") if r.get("type")=="result"]
        assert len(terminals)==expected_turns
        assert all(r["session_id"]==receipt["session_id"] and Decimal(str(r["total_cost_usd"]))==0 for r in terminals)
        requests=sorted(out.glob("request-*.json"))
        assert len(requests)==receipt["requests"] and len(requests)>0
        assert all(load(p)["output_config"]["effort"]==arm for p in requests)
        actor=out/"project"
        preflight=load(out/"runtime-preflight.json")
        assert pathlib.Path(preflight["actor"])==actor.resolve()
        assert preflight["filesystem"] in {"ext2/ext3","xfs","btrfs","zfs"}
        assert preflight["minimum_free_bytes"]==30*1024**3
        assert preflight["free_bytes"]>=preflight["minimum_free_bytes"]
        assert (actor/".git/HEAD").is_file()
        owner=load(out/"record-owner.json")
        witnesses=lines(out/"native-runtime-observations.jsonl")
        assert len(witnesses)==(8 if mode=="repair" else 1 if mode=="unknown" else 4)
        for w in witnesses:
            assert w["container_id"]==owner["container_id"]
            assert w["init"] is True and w["nano_cpus"]==2000000000 and w["pids_limit"]==512
            assert w["memory_bytes"]==6*1024**3
            assert pathlib.Path(w["actor_source"])==actor.resolve() and w["actor_read_write"]
            assert w["cargo_target_dir"]=="/testbed/target"
        rounds=[load(p) for p in sorted(out.glob("verification-*/receipt.json"))]
        codes=[[c["exit_code"] for c in r["checks"]] for r in rounds]
        expected=([[0,1,0,0],[0,0,0,0]] if mode=="repair" else [[0]] if mode=="unknown" else [[0,0,0,0]])
        assert codes==expected,(arm,mode,codes)
        assert receipt["workflow_completed"]==(mode!="unknown")
        assert life["status"]==("incomplete" if mode=="unknown" else "settled")
        if mode=="unknown":
            assert rounds[-1]["status"]=="incomplete" and not rounds[-1]["passed"]
            assert "TimeoutExpired" in rounds[-1]["error"]
        else:
            assert rounds[-1]["status"]=="completed" and rounds[-1]["passed"]
        for rnd in rounds:
            for check in rnd["checks"]:
                content=pathlib.Path(check["log"]).read_text()
                if check["id"] in {"format","lean","default"}:
                    assert content==check["id"].upper()
                elif mode=="success":
                    assert content=="COMPILE"
        if mode=="repair": assert (actor/"workflow-repaired.txt").is_file()
        cleanup=load(out/"cleanup.json")
        assert cleanup and all(r["absent"] for r in cleanup)
        names={r["name"] for r in cleanup}
        identities=names|{owner["container_id"]}
        for identity in sorted(identities):
            probe=subprocess.run(["docker","inspect",identity],capture_output=True,text=True,timeout=5)
            assert probe.returncode!=0 and "no such" in probe.stderr.lower(),(identity,probe.stdout,probe.stderr)
            absent.append({"arm":arm,"mode":mode,"identity":identity,"exit_code":probe.returncode,"stderr":probe.stderr})
        rows.append({"arm":arm,"mode":mode,"requests":len(requests),"terminal_events":len(terminals),
            "public_exit_codes":codes,"runtime_witnesses":len(witnesses),"cleanup_names":len(names),
            "workflow_completed":receipt["workflow_completed"],"provider_cost_usd":"0",
            "receipt_sha256":digest(out/"receipt.json"),"filesystem":preflight["filesystem"],
            "free_bytes_at_preflight":preflight["free_bytes"]})
    result={"verified":True,"qualification_root":str(BASE),"runtime_source_hashes":summary["runtime_source_hashes"],
        "cells":rows,"cleanup_inspections":absent,"provider_cost_usd":"0",
        "limits":"Scripted transport/public probes only; no model quality or full Rust repair conclusion."}
    (BASE/"independent-readback.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({"verified":True,"cells":len(rows),"cleanup_inspections":len(absent),"provider_cost_usd":"0"}))
if __name__=="__main__":main()
