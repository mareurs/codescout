"""Read actual wire controls and preserve unexecuted campaign snapshots separately."""
import hashlib,json,pathlib,sys
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
sys.path.insert(0,str(V/"tools/hint_authority_pilot"))
import audit
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/complete-workflow-calibration-20261105")
q=json.loads((ROOT/"qualification.json").read_text())
with (ROOT/"qualification-as-produced.json").open("x") as output:json.dump(q,output,indent=2)
nonexecuted={p:h for p,h in q["runtime_hashes"].items() if "/hint_authority_workflow/" in p}
q["campaign_snapshots_not_executed_by_transport_control"]=nonexecuted
q["runtime_hashes"]={p:h for p,h in q["runtime_hashes"].items() if p not in nonexecuted}
for p,h in q["runtime_hashes"].items():
    assert hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()==h
wire=[]
base=ROOT/"qualification-budget4"
for effort,mode in (("low","success"),("low","repair"),("low","unknown"),("xhigh","success")):
    out=base/("qualification" if effort=="low" else "qualification-xhigh")/mode
    result=audit.inspect_cell(out)
    assert result["hint_visible_on_wire"] and result["boundary_denied"],(effort,mode,result)
    expected=json.loads((out/"expected.json").read_text())
    from core import audit_request
    requests=list(out.glob("request-*.json"))
    for p in requests:audit_request(json.loads(p.read_text()),expected)
    wire.append(dict(effort=effort,mode=mode,requests=len(requests),**result))
q["wire_controls"]=wire
q["runtime_scope"]="Only actual transport/native execution dependencies; final campaign code is independently tested/reviewed and bound by complete composition fingerprint."
(ROOT/"qualification.json").write_text(json.dumps(q,indent=2)+"\n")
print(json.dumps(dict(wire_cells=len(wire),runtime_hashes_verified=len(q["runtime_hashes"]),provider_cost_usd="0")))
