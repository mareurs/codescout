#!/usr/bin/env python3
"""Independent post-run checks over the complete registered pair; no model calls."""
import hashlib,importlib.util,json,pathlib,re,subprocess,sys
from decimal import Decimal
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/complete-workflow-calibration-20261105")
sys.path[:0]=[str(V/"tools/hint_authority_pilot")]
import audit,run as worker
from core import amount,audit_request,extract_result
def load(p):return json.loads(p.read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def absent(identity):
    p=subprocess.run(["docker","inspect",identity],capture_output=True,text=True,timeout=5)
    assert p.returncode!=0 and "no such" in p.stderr.lower(),identity
    return dict(identity=identity,exit_code=p.returncode,stderr=p.stderr)
def test_names(text):
    return set(re.findall(r"^test (\S+) \.\.\. ok$",text,re.M))
def main():
    spec=importlib.util.spec_from_file_location("verified_campaign",V/"tools/hint_authority_workflow/driver.py")
    driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
    fingerprint=driver.check(ROOT)
    ledger=load(ROOT/"results.json")
    assert ledger["cost_is_final"] is True and ledger["pair_completed"] is True
    assert len(ledger["results"])==2 and not (ROOT/"halt.json").exists()
    manifest=load(V/"tools/hint_authority_workflow/public-checks.json")["checks"]
    private_controls=load(ROOT/"acceptance-controls.json")
    positive=next(r for r in private_controls["controls"] if r["kind"]=="positive")
    reference_only={
        "librarian::catalog::chunk::tests::a_line_offset_shifts_every_range_and_moves_no_entry_token",
        "librarian::indexer::tests::a_stored_chunks_range_points_at_that_text_in_the_file",
    }
    patch_text=(ROOT/"reference.patch").read_text()
    for name in reference_only:
        assert "+    #[test]\n+    fn "+name.rsplit("::",1)[1]+"(" in patch_text
    required_private={step["filter"]:test_names(pathlib.Path(step["log"]).read_text(errors="replace"))-reference_only for step in positive["grade"]["steps"]}
    total=Decimal(0)
    rows=[];cleanup=[]
    for index,effort in enumerate(("low","xhigh")):
        row=ledger["results"][index];out=ROOT/f"workflow-{index}-{effort}"
        receipt=load(out/"receipt.json")
        assert row["effort"]==effort and row["declaration"] is False and row["fingerprint"]==fingerprint
        raw=[json.loads(l) for l in (out/"stream.jsonl").read_text().splitlines() if l.strip()]
        terminals=[r for r in raw if r.get("type")=="result"]
        assert terminals and all(r["session_id"]==receipt["session_id"] for r in terminals)
        terminal=extract_result(terminals[-1:],receipt["session_id"])
        assert terminal["cost"]==amount(row["cost_usd"])==amount(receipt["cost_usd"])
        assert receipt["unknown_provider_cost"] is False and receipt["scripted"] is False
        assert receipt["cost_coverage"]["forwarded_at_terminal"]==receipt["cost_coverage"]["forwarded_total"]==receipt["forwarded"]
        assert terminal["cost"]<=4 and amount(receipt["upper_usage_cost"])<=4
        total+=terminal["cost"]
        expected=load(out/"expected.json")
        assert expected["effort"]==effort and expected["declaration"] is False
        requests=list(out.glob("request-*.json"));assert len(requests)==receipt["requests"]
        for path in requests:audit_request(load(path),expected)
        assert load(out/"context-audit.json")["valid"] is True
        rounds=[load(p) for p in sorted(out.glob("verification-*/receipt.json"))]
        public=receipt["public_verification"]
        if receipt["workflow_completed"]:
            assert public and rounds and rounds[-1]==public
            assert public["status"]=="completed" and public["passed"] is True
            assert receipt["lifecycle"]["status"]=="settled"
            assert len(public["checks"])==len(manifest)
            for actual,expected_check in zip(public["checks"],manifest):
                assert actual["id"]==expected_check["id"] and actual["command"]==expected_check["command"]
                assert actual["exit_code"]==0 and pathlib.Path(actual["log"]).is_file()
        grade=row["grade"]
        private_names={}
        for step in grade["steps"]:
            text=pathlib.Path(step["log"]).read_text(errors="replace")
            names=test_names(text)
            missing=required_private[step["filter"]]-names
            private_names[step["filter"]]=dict(passed_named_tests=len(names),missing_required=sorted(missing))
            if grade["exit_code"]==0:
                assert step["exit_code"]==0 and step["execution_witness"] and not missing,(effort,step["filter"],missing)
        assert row["accepted"]==(receipt["workflow_completed"] and grade["exit_code"]==0)
        actor=out/"project"
        subprocess.run(["git","diff","--binary"],cwd=actor,check=True,stdout=(out/"candidate.patch").open("wb"))
        status=subprocess.check_output(["git","status","--porcelain"],cwd=actor,text=True)
        (out/"candidate-status.txt").write_text(status)
        owner=load(out/"record-owner.json")
        names={r["name"] for r in load(out/"cleanup.json")}
        assert names and all(r["absent"] for r in load(out/"cleanup.json"))
        owner_id=owner.get("container_id")
        identities=names|({owner_id} if owner_id else set())
        cleanup.extend(dict(effort=effort,**absent(i)) for i in sorted(identities))
        live_path=ROOT/"runtime-live-observations.jsonl"
        live=[json.loads(line) for line in live_path.read_text().splitlines()] if live_path.exists() else []
        own_live=[r for r in live if r["attempt"]==out.name]
        live_ids={r["container_id"] for r in own_live}
        if owner_id:
            assert all(identity==owner_id for identity in live_ids),(effort,live_ids,owner_id)
        preflight=load(out/"runtime-preflight.json")
        assert pathlib.Path(preflight["actor"])==actor.resolve() and preflight["free_bytes"]>=30*1024**3
        assert preflight["filesystem"] in {"ext2/ext3","xfs","btrfs","zfs"}
        argv=load(out/"mcp-native-argv.json")
        assert "--init" in argv and argv[argv.index("--cpus")+1]=="2" and argv[argv.index("--pids-limit")+1]=="512"
        rows.append(dict(effort=effort,cost_usd=str(terminal["cost"]),workflow_completed=receipt["workflow_completed"],
            accepted=row["accepted"],private_grade_exit=grade["exit_code"],private_named_tests=private_names,
            cli_terminal_events=len(terminals),continuations=receipt["lifecycle"]["continuations"],
            public_round_exit_codes=[[c["exit_code"] for c in r["checks"]] for r in rounds],
            workflow_wall_s=receipt["wall_s"],outer_with_grading_wall_s=row["complete_wall_s"],
            model_requests=len(requests),context_valid=True,
            live_native_samples=len(own_live),live_native_ids=sorted(live_ids),public_owner_id=owner_id,
            receipt_sha256=digest(out/"receipt.json"),
            patch_sha256=digest(out/"candidate.patch")))
    assert total==amount(ledger["new_cost_usd"])<=8
    assert amount(ledger["thread_cost_usd"])==Decimal("31.797419199999999964")+total<=40
    result=dict(verified=True,complete_pair=True,fingerprint=fingerprint,results=rows,
        completed_workflows=sum(r["workflow_completed"] is True for r in rows),
        accepted_workflows=sum(r["accepted"] is True for r in rows),
        background_identity_scope="Public worker ID is pinned; background reader has known gap39785443931155d4. Independent live ID samples are compared with later public ownership; samples are not continuous attestation.",
        new_model_cost_usd=str(total),thread_cost_usd=ledger["thread_cost_usd"],
        thread_remaining_usd=str(Decimal(40)-amount(ledger["thread_cost_usd"])),
        original_pilot_cost_usd="2.57626490000000013",cleanup_inspections=cleanup,
        timing_scope="workflow_wall_s covers retained CLI/model/background/public-check loop; outer includes setup/private grading and its shared cache asymmetry.",
        limits="One exposed task, fixed order, no ablation or transfer/authority-effect inference.")
    (ROOT/"independent-paid-readback.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))
if __name__=="__main__":main()
