#!/usr/bin/env python3
"""Four actual CLI/native controls at the new CLI budget; no real provider."""
import hashlib,importlib.util,json,pathlib
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/complete-workflow-calibration-20261105")
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    obj=importlib.util.module_from_spec(spec);spec.loader.exec_module(obj);return obj
def main():
    q=module("budget4_integrated","/tmp/qualify-integrated-runtime-01a15ca9-20261105.py")
    q.BASE=ROOT/"qualification-budget4"
    q.ROOT=q.BASE/"qualification"
    q.BASE.mkdir()
    old_one=q.worker.one
    def one(*args,**kwargs):
        kwargs["client_budget_usd"]="4"
        return old_one(*args,**kwargs)
    q.worker.one=one
    q.main()
    readback=module("budget4_readback","/tmp/readback-runtime-01a15ca9-20261105.py")
    readback.BASE=q.BASE;readback.main()
    for effort,mode in (("low","success"),("low","repair"),("low","unknown"),("xhigh","success")):
        out=q.BASE/("qualification" if effort=="low" else "qualification-xhigh")/mode
        launch=json.loads((out/"launch.json").read_text())
        argv=launch["argv"]
        assert argv[argv.index("--max-budget-usd")+1]=="4"
    original=json.loads((q.BASE/"qualification-summary.json").read_text())["runtime_source_hashes"]
    for directory in ("hint_authority_workflow",):
        for p in (V/"tools"/directory).glob("*.py"):
            original[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
    proof=dict(qualified=True,cli_budget_usd="4",provider_cost_usd="0",
        runtime_hashes=original,cells=["low:success","low:repair","low:unknown","xhigh:success"],
        readback=str(q.BASE/"independent-readback.json"),
        readback_sha256=hashlib.sha256((q.BASE/"independent-readback.json").read_bytes()).hexdigest(),
        script_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest())
    (ROOT/"qualification.json").write_text(json.dumps(proof,indent=2)+"\n")
    print(json.dumps(dict(qualified=True,provider_cost_usd="0",cli_budget_usd="4")),flush=True)
if __name__=="__main__":main()
