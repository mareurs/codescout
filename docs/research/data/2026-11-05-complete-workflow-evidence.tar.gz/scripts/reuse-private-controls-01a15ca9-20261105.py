#!/usr/bin/env python3
"""Reuse existing zero-model oracle controls only after exact candidate/log binding."""
import hashlib,json,pathlib,shutil,subprocess,sys
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
sys.path.insert(0,str(V/"tools/hint_authority_pilot"))
import prepare
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/complete-workflow-calibration-20261105")
OLD=prepare.P/"launch-budget-requalification-20261104"
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def population(path):
    return {str(p.relative_to(path)):digest(p) for p in path.rglob("*")
        if p.is_file() and not set(p.relative_to(path).parts)&{".git","target"}}
def main():
    staging=ROOT/"acceptance-control-byte-witness-v2"
    staging.mkdir()
    rows=[]
    for suffix in ("baseline","positive"):
        candidate=staging/suffix
        shutil.copytree(ROOT/"source",candidate)
        if suffix=="positive":
            subprocess.run(["git","apply",str(ROOT/"reference.patch")],cwd=candidate,check=True)
        prepare.append_oracle(candidate,old_api=suffix=="baseline")
        label="control-0ef13885-"+suffix
        expected=population(candidate);actual=population(OLD/label)
        differences={p for p in set(expected)|set(actual) if expected.get(p)!=actual.get(p)}
        assert not differences,(suffix,sorted(differences))
        grade=json.loads((OLD/(label+"-grade.json")).read_text())
        logs=[]
        for step in grade["steps"]:
            log=pathlib.Path(step["log"])
            text=log.read_text(errors="replace")
            assert str(OLD/label) in " ".join(step["argv"]) and prepare.IMAGE in step["argv"]
            logs.append(dict(path=str(log),sha256=digest(log),bytes=log.stat().st_size))
            if suffix=="positive":
                assert step["exit_code"]==0 and step["execution_witness"]
                assert "test result: ok." in text
                if step["filter"]=="hfa_acceptance":assert prepare.acceptance_executed(text)
        assert grade["oracle_version"]==2
        if suffix=="positive":assert grade["exit_code"]==0 and len(grade["steps"])==3
        else:
            assert grade["exit_code"]!=0 and grade["steps"][0]["filter"]=="hfa_acceptance"
            assert "test result: FAILED. 0 passed; 2 failed;" in pathlib.Path(grade["steps"][0]["log"]).read_text()
        rows.append(dict(kind=suffix,files=len(expected),candidate_hashes=expected,
            old_candidate=str(OLD/label),grade=grade,grade_sha256=digest(OLD/(label+"-grade.json")),logs=logs))
    proof=dict(baseline_rejected=True,reference_accepted=True,oracle_version=2,
        reused=True,reason="Exact prepared candidate file populations and original actual Docker grade logs match.",
        prepare_sha256=digest(V/"tools/hint_authority_pilot/prepare.py"),controls=rows,
        script_sha256=digest(pathlib.Path(__file__)),provider_cost_usd="0")
    (ROOT/"acceptance-controls.json").write_text(json.dumps(proof,indent=2)+"\n")
    print(json.dumps(dict(reused_controls=2,files=[r["files"] for r in rows],provider_cost_usd="0")))
if __name__=="__main__":main()
