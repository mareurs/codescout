"""Offline reproducer: a pinned name+ID whose inspection returns a replacement ID."""
import importlib.util,json,pathlib,subprocess,sys,tempfile
from unittest.mock import patch
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
sys.path[:0]=[str(V/"tools/agent_lifecycle"),str(V/"tools/hint_authority_pilot")]
import qualify
def main():
    name="offline-native-owner"
    identity=dict(Id="replacement-id",Image=qualify.worker.IMAGE,Config=dict(Labels={"codescout.hfa":name}))
    record=dict(state="exited",exit_code=0)
    def run(argv,**kwargs):
        value=[identity] if argv[:2]==["docker","inspect"] else record
        return subprocess.CompletedProcess(argv,0,json.dumps(value),"")
    with tempfile.TemporaryDirectory() as temporary:
        out=pathlib.Path(temporary)
        (out/"record-owner.json").write_text(json.dumps(dict(name=name,container_id="original-id")))
        with patch.object(qualify.subprocess,"run",side_effect=run):
            returned=qualify.native_record(out,"/tmp/codescout-bg/7-abcdef-bg_00000001.json")
        result=dict(pinned_id="original-id",inspected_id="replacement-id",
            replacement_record_accepted=returned==record,provider_calls=0,
            source_sha256=__import__("hashlib").sha256((V/"tools/agent_lifecycle/qualify.py").read_bytes()).hexdigest())
        pathlib.Path("/tmp/background-owner-pin-probe-01a15ca9.json").write_text(json.dumps(result,indent=2)+"\n")
        print(json.dumps(result))
if __name__=="__main__":main()
