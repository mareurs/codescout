"""Install the accepted exact-byte review only after the full gate and clean commit."""
import hashlib,importlib.util,json,pathlib,subprocess
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/complete-workflow-calibration-20261105")
REVIEW=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/workflow-campaign-review-20261105")
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    gate=json.loads(pathlib.Path("/tmp/codescout-bg/455879-a720241d-bg_00000063.json").read_text())
    assert gate["state"]=="exited" and gate["exit_code"]==0
    text=pathlib.Path(gate["log_path"]).read_text()
    assert "PYTHON LIGHT EXIT -> PYTHON_LIGHT=0" in text
    assert "GATE EXITS -> FMT=0 CLIPPY=0 LEAN=0 DEFAULT=0 FMT_STATE=passed" in text
    assert not subprocess.check_output(["git","status","--porcelain"],cwd=V,text=True)
    hashes=json.loads((REVIEW/"source-hashes-final.json").read_text())["five_files"]
    for path,want in hashes.items():assert digest(V/path)==want,path
    binding=json.loads((REVIEW/"review-binding.json").read_text())
    for filename,key in (("plan.json","plan_sha256"),("qualification.json","qualification_sha256"),("acceptance-controls.json","acceptance_sha256")):
        assert digest(ROOT/filename)==binding[key]
    assert digest(pathlib.Path(binding["review_report"]))==binding["review_report_sha256"]
    spec=importlib.util.spec_from_file_location("campaign_admission",V/"tools/hint_authority_workflow/driver.py")
    driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
    assert driver.composition(ROOT)==binding["fingerprint"] and binding["accepted"] is True
    aggregate=json.loads((REVIEW/"aggregate.json").read_text())
    assert len(aggregate["initial"]["runs"])==12
    assert sum(r["exit_code"]!=0 for r in aggregate["initial"]["runs"])==6
    assert len(aggregate["focused"]["runs"])==6
    assert all(r["exit_code"]!=0 and r["restored_byte_identical"] for r in aggregate["focused"]["runs"])
    with (ROOT/"review.json").open("xb") as output:output.write((REVIEW/"review-binding.json").read_bytes())
    fingerprint=driver.check(ROOT)
    assert fingerprint==binding["fingerprint"]
    row=dict(preflight_passed=True,fingerprint=fingerprint,provider_calls=0,source_head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=V,text=True).strip(),
        gate=gate,allocation_usd="8",arm_cap_usd="4",prior_thread_cost_usd=str(driver.THREAD_PRIOR))
    (ROOT/"preflight.json").write_text(json.dumps(row,indent=2)+"\n")
    print(json.dumps(row))
if __name__=="__main__":main()
