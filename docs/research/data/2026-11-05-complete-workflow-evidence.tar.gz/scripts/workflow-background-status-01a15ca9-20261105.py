import json,pathlib
root=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/complete-workflow-calibration-20261105")
rows=[]
for out in root.glob("workflow-[01]-*"):
    path=out/"record-observations.jsonl"
    if not path.is_file():continue
    records={}
    for line in path.read_text().splitlines():
        try:row=json.loads(line)
        except ValueError:continue
        r=row["record"];records[r["handle"]]=r
    rows.append(dict(attempt=out.name,observed_jobs=list(records.values())))
print(json.dumps(rows,indent=2))
