#!/usr/bin/env python3
"""Archive completed campaign evidence without build trees, homes or credentials."""
import gzip,hashlib,io,json,os,pathlib,tarfile
MAIN=pathlib.Path("/home/marius/work/claude/codescout")
DATA=MAIN/"docs/research/data"
BASE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
ROOT=BASE/"complete-workflow-calibration-20261105"
REVIEW=BASE/"workflow-campaign-review-20261105"
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
def sha(content):return hashlib.sha256(content).hexdigest()
def load(p):return json.loads(p.read_text())
def main():
    record=load(pathlib.Path("/tmp/codescout-bg/455879-a720241d-bg_00000067.json"))
    assert record["state"]=="exited"
    payload={}
    skip={"source","skill-only-plugin","native-home","client-home","project","target","grader-target",".git","__pycache__","tools","pristine","final-pristine"}
    for label,root in (("campaign",ROOT),("review",REVIEW),("implementation",BASE/"workflow-calibration-driver-20261105")):
        for current,dirs,files in os.walk(root,followlinks=False):
            dirs[:]=[d for d in dirs if d not in skip and not d.endswith("-grader") and not d.startswith("acceptance-control-byte-witness")]
            for name in files:
                p=pathlib.Path(current)/name
                if p.is_symlink() or p.suffix in {".pyc",".tar",".gz"}:continue
                payload[label+"/"+str(p.relative_to(root))]=p.read_bytes()
    for control in load(ROOT/"acceptance-controls.json")["controls"]:
        for log in control["logs"]:
            content=pathlib.Path(log["path"]).read_bytes()
            assert sha(content)==log["sha256"]
            payload["reused-control-logs/"+pathlib.Path(log["path"]).name]=content
    for path,want in load(REVIEW/"source-hashes-final.json")["five_files"].items():
        content=(V/path).read_bytes();assert sha(content)==want
        payload["source/"+path]=content
    scripts=("verify-aborted-workflow-01a15ca9-20261105.py","revoke-cold-workflow-admission-01a15ca9-20261105.py","qualify-budget4-workflow-01a15ca9-20261105.py","bind-budget4-proofs-01a15ca9-20261105.py",
        "reuse-private-controls-01a15ca9-20261105.py","bind-workflow-campaign-review-01a15ca9-20261105.py",
        "verify-complete-workflow-pair-01a15ca9-20261105.py","workflow-pair-status-01a15ca9-20261105.py",
        "preserve-complete-workflow-01a15ca9-20261105.py","qualify-integrated-runtime-01a15ca9-20261105.py",
        "readback-runtime-01a15ca9-20261105.py","capture-workflow-native-01a15ca9-20261105.py","probe-background-owner-pin-01a15ca9-20261105.py","capture-workflow-pressure-01a15ca9-20261105.py","workflow-background-status-01a15ca9-20261105.py")
    for name in scripts:payload["scripts/"+name]=(pathlib.Path("/tmp")/name).read_bytes()
    for name in ("workflow-driver-red","workflow-budget-red","workflow-budget-green","workflow-admission-red","workflow-admission-green",
                 "workflow-budget-isolation-red","workflow-endpoint-red","workflow-endpoint-green","workflow-final-cost-red","workflow-final-cost-green",
                 "workflow-final-driver-suite","workflow-final-lifecycle-suite","workflow-pilot-suite","workflow-completion-suite","workflow-resume-suite"):
        p=pathlib.Path("/tmp")/(name+"-01a15ca9.log")
        if p.exists():payload["test-logs/"+p.name]=p.read_bytes()
    gate=load(pathlib.Path("/tmp/codescout-bg/455879-a720241d-bg_00000063.json"))
    payload["jobs/gate.json"]=json.dumps(gate,indent=2).encode()
    payload["jobs/gate.log"]=pathlib.Path(gate["log_path"]).read_bytes()
    payload["jobs/paid.json"]=json.dumps(record,indent=2).encode()
    payload["jobs/paid.log"]=pathlib.Path(record["log_path"]).read_bytes()
    manifest={name:dict(sha256=sha(content),bytes=len(content)) for name,content in sorted(payload.items())}
    archive=DATA/"2026-11-05-complete-workflow-evidence.tar.gz"
    with tarfile.open(archive,"w:gz") as tar:
        for name,content in payload.items():
            info=tarfile.TarInfo(name);info.size=len(content);tar.addfile(info,io.BytesIO(content))
        content=(json.dumps(manifest,indent=2)+"\n").encode()
        info=tarfile.TarInfo("manifest.json");info.size=len(content);tar.addfile(info,io.BytesIO(content))
    with tarfile.open(archive,"r:gz") as tar:
        assert set(tar.getnames())==set(manifest)|{"manifest.json"}
        assert json.load(tar.extractfile("manifest.json"))==manifest
        for name,want in manifest.items():
            content=tar.extractfile(name).read()
            assert len(content)==want["bytes"] and sha(content)==want["sha256"]
    for source,destination in (("results.json","results"),("preflight.json","preflight"),("independent-paid-readback.json","verification")):
        p=ROOT/source
        if p.exists():(DATA/("2026-11-05-complete-workflow-"+destination+".json")).write_bytes(p.read_bytes())
    with gzip.open(DATA/"2026-11-05-complete-workflow-gate.log.gz","wb") as output:
        output.write(payload["jobs/gate.log"])
    row=dict(archive=str(archive.relative_to(MAIN)),sha256=sha(archive.read_bytes()),
        payload_files=len(payload),every_payload_hash_verified=True,job=record)
    (DATA/"2026-11-05-complete-workflow-archive.json").write_text(json.dumps(row,indent=2)+"\n")
    print(json.dumps(row,indent=2))
if __name__=="__main__":main()
