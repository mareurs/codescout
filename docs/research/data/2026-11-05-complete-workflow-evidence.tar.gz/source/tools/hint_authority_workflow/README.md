# Complete-workflow calibration

The driver allocates a fresh fixed low/xhigh pair, declaration absent, with USD4 per arm and USD8 total inside the existing USD40 thread cap. It reuses frozen onboarding, global/project instructions, native runtime and private oracle. The public manifest runs before private grading. The task is exposed; outcomes are diagnostic, not external transfer evidence.

Prepare an exclusive disk-backed root with `python3 -B tools/hint_authority_workflow/driver.py --prepare <root>`. Preparation reads historical receipts and frozen inputs but never credentials/providers. Bind actual CLI/native budget4 qualification and exact private-control evidence in qualification.json and acceptance-controls.json. A final independent review must bind their hashes and the complete composition fingerprint in review.json. `--check <root>` fails closed without these bindings. `--paid <root>` additionally creates an exclusive start marker; there is no retry/resume mode.

The atomic results ledger records reconciled cost before grading, retains failed/censored outcomes and stops on unknown cost or unsafe context/transport/cleanup. A passing CLI terminal is insufficient: all registered public checks, settled lifecycle, valid context and private acceptance are required. All historical spending remains charged. Never reuse old cohort markers or lower the second-arm reserve to buy a partial pair.

`run.one` retains its default CLI limit0.65; explicit custom budgets require workflow mode, must be positive<=4 and cannot exceed their paid proxy allowance. Scripted controls use a dummy credential and zero forwarded calls. Actual provider billing uncertainty remains a halt, not a zero.

Offline: `python3 -B -m unittest discover -s tools/hint_authority_workflow -p 'test_*.py'`.
