"""Campaign contracts exercised with local receipt-producing worker/grader boundaries."""
import importlib.util
import json
import pathlib
import sys
import tempfile
import unittest
from decimal import Decimal
from unittest.mock import patch
HERE=pathlib.Path(__file__).resolve().parent
sys.path[:0]=[str(HERE.parent/"hint_authority_pilot"),str(HERE)]
spec=importlib.util.spec_from_file_location("workflow_campaign",HERE/"driver.py")
driver=importlib.util.module_from_spec(spec)
if spec.loader and (HERE/"driver.py").exists():
    spec.loader.exec_module(driver)

class DriverTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=pathlib.Path(self.temp.name)
        self.calls=[]
    def require(self):
        self.assertTrue(hasattr(driver,"execute_pair"),"complete-workflow campaign driver is missing")
    def cell(self,label,effort,allowance):
        self.calls.append((label,effort,allowance))
        out=self.root/label
        out.mkdir()
        sid="session-"+effort
        terminal=dict(type="result",session_id=sid,total_cost_usd=.4,is_error=False,subtype="success")
        (out/"stream.jsonl").write_text(json.dumps(terminal)+"\n")
        (out/"stdout.json").write_text(json.dumps(terminal))
        receipt=dict(session_id=sid,cost_usd="0.4",unknown_provider_cost=False,scripted=False,
            campaign_available_usd=str(allowance),forwarded=2,upper_usage_cost="0.5",
            cost_coverage=dict(forwarded_at_terminal=2,forwarded_total=2),
            workflow_completed=True,context_valid=True,lifecycle=dict(status="settled"),
            public_verification=dict(status="completed",passed=True,
                checks=[dict(c,exit_code=0) for c in json.loads((HERE/"public-checks.json").read_text())["checks"]]),
            transport_errors=[],budget_stop=None,cleanup_error=None)
        (out/"receipt.json").write_text(json.dumps(receipt))
        return receipt
    def invoke(self,**kw):
        self.require()
        return driver.execute_pair(self.root,check=lambda:"frozen",run_cell=kw.pop("run_cell",self.cell),
            grade_cell=kw.pop("grade_cell",lambda label:dict(exit_code=0)),**kw)
    def test_pair_reserves_both_arms_and_charges_cost_before_private_grade(self):
        self.require()
        seen=[]
        def grade(label):
            row=json.loads((self.root/"results.json").read_text())
            seen.append(Decimal(row["new_cost_usd"]))
            return dict(exit_code=0)
        result=self.invoke(grade_cell=grade)
        self.assertEqual([(e,a) for _,e,a in self.calls],[("low",Decimal(4)),("xhigh",Decimal(4))])
        self.assertEqual(seen,[Decimal(".4"),Decimal(".8")])
        self.assertEqual(Decimal(result["thread_cost_usd"]),Decimal("32.597419199999999964"))
        self.assertEqual([r["accepted"] for r in result["results"]],[True,True])
    def test_insufficient_pair_balance_blocks_every_paid_call(self):
        self.require()
        with self.assertRaises(ValueError):
            self.invoke(thread_remaining=Decimal("7.999"))
        self.assertEqual(self.calls,[])
    def test_known_failed_workflow_is_charged_and_is_not_success(self):
        self.require()
        def run(label,effort,allowance):
            row=self.cell(label,effort,allowance)
            row["workflow_completed"]=False
            return row
        result=self.invoke(run_cell=run)
        self.assertEqual(Decimal(result["new_cost_usd"]),Decimal(".8"))
        self.assertFalse(any(r["accepted"] for r in result["results"]))
    def test_each_unknown_cost_identity_or_coverage_defect_stops_before_second_call(self):
        self.require()
        for key,value in (("unknown_provider_cost",True),("cost_usd","NaN"),("cost_usd","0.41"),
                          ("session_id","another"),("cost_coverage",dict(forwarded_at_terminal=1,forwarded_total=2)),
                          ("cost_coverage",dict(forwarded_at_terminal=2,forwarded_total=1))):
            with self.subTest(key=key), tempfile.TemporaryDirectory() as tmp:
                self.root=pathlib.Path(tmp);self.calls=[]
                def run(label,effort,allowance):
                    row=self.cell(label,effort,allowance);row[key]=value
                    return row
                with self.assertRaises(ValueError):self.invoke(run_cell=run)
                self.assertEqual(len(self.calls),1)
                self.assertTrue((self.root/"halt.json").exists())
    def test_grade_exception_retains_known_cost_and_start_marker_blocks_reentry(self):
        self.require()
        def grade(label):raise RuntimeError("grade unavailable")
        with self.assertRaises(RuntimeError):self.invoke(grade_cell=grade)
        result=json.loads((self.root/"results.json").read_text())
        self.assertEqual(Decimal(result["new_cost_usd"]),Decimal(".4"))
        with self.assertRaises(FileExistsError):self.invoke()
        self.assertEqual(len(self.calls),1)
    def test_preflight_failure_does_not_call_worker(self):
        self.require()
        def bad():raise ValueError("changed composition")
        with self.assertRaises(ValueError):
            driver.execute_pair(self.root,check=bad,run_cell=self.cell,grade_cell=lambda _:None)
        self.assertEqual(self.calls,[])
    def test_known_transport_or_cleanup_failure_is_charged_then_stops(self):
        self.require()
        for key,value in (("transport_errors",["broken"]),("cleanup_error","remaining")):
            with self.subTest(key=key), tempfile.TemporaryDirectory() as tmp:
                self.root=pathlib.Path(tmp);self.calls=[]
                def run(label,effort,allowance):
                    row=self.cell(label,effort,allowance);row[key]=value
                    return row
                result=self.invoke(run_cell=run)
                self.assertEqual(len(self.calls),1)
                self.assertEqual(Decimal(result["new_cost_usd"]),Decimal(".4"))
                self.assertFalse(result["results"][0]["accepted"])
    def test_composition_hash_covers_new_modules_and_plan_outside_legacy_fingerprint(self):
        self.assertTrue(hasattr(driver,"composition"),"complete composition fingerprint is missing")
        code=self.root/"code.py";code.write_text("one")
        plan=self.root/"plan.json";plan.write_text("{}")
        with patch.object(driver.audit,"fingerprint",return_value="legacy"):
            before=driver.composition(self.root,files=[code,plan])
            code.write_text("two")
            self.assertNotEqual(before,driver.composition(self.root,files=[code,plan]))
            code.write_text("one");plan.write_text('{"changed":true}')
            self.assertNotEqual(before,driver.composition(self.root,files=[code,plan]))
    def preflight_fixture(self):
        self.assertTrue(hasattr(driver,"check"),"campaign preflight is missing")
        self.enterContext(patch.object(driver,"historical",return_value=Decimal("2.57626490000000013")))
        self.enterContext(patch.object(driver,"composition",return_value="frozen"))
        plan=driver.registration()
        driver.save(self.root/"plan.json",plan)
        qualification=dict(qualified=True,cli_budget_usd="4",provider_cost_usd="0",
            runtime_hashes={},cells=["low:success","low:repair","low:unknown","xhigh:success"])
        controls=dict(baseline_rejected=True,reference_accepted=True,oracle_version=2)
        driver.save(self.root/"qualification.json",qualification)
        driver.save(self.root/"acceptance-controls.json",controls)
        review=dict(accepted=True,fingerprint="frozen",
            qualification_sha256=driver.digest(self.root/"qualification.json"),
            acceptance_sha256=driver.digest(self.root/"acceptance-controls.json"))
        driver.save(self.root/"review.json",review)
        return plan,qualification,controls,review

    def test_preflight_rejects_changed_plan_history_review_and_qualification(self):
        self.preflight_fixture()
        self.assertEqual(driver.check(self.root),"frozen")
        for filename,key,bad in (("plan.json","allocation_usd","4"),("plan.json","arm_cap_usd","2"),
            ("review.json","accepted",False),("review.json","fingerprint","changed"),
            ("qualification.json","cli_budget_usd","0.65"),("qualification.json","qualified",False),
            ("acceptance-controls.json","reference_accepted",False)):
            with self.subTest(filename=filename,key=key):
                path=self.root/filename;original=path.read_text()
                value=json.loads(original);value[key]=bad;driver.save(path,value)
                with self.assertRaises(ValueError):driver.check(self.root)
                path.write_text(original)
        with patch.object(driver,"historical",return_value=Decimal("2.58")):
            with self.assertRaises(ValueError):driver.check(self.root)

    def test_registration_never_resets_old_pilot_or_expands_thread_cap(self):
        self.preflight_fixture()
        plan=driver.registration()
        self.assertEqual(plan["cells"],[["low",False],["xhigh",False]])
        self.assertEqual(Decimal(plan["allocation_usd"]),Decimal(8))
        self.assertEqual(Decimal(plan["thread_prior_usd"]),Decimal("31.797419199999999964"))
        self.assertEqual(Decimal(plan["thread_cap_usd"]),Decimal(40))
        self.assertEqual(Decimal(plan["old_pilot_spent_usd"]),Decimal("2.57626490000000013"))

    def test_unknown_runtime_input_hash_and_changed_source_block_preflight(self):
        self.preflight_fixture()
        q=json.loads((self.root/"qualification.json").read_text())
        code=self.root/"runtime.py";code.write_text("source")
        q["runtime_hashes"]={str(code):driver.digest(code)}
        driver.save(self.root/"qualification.json",q)
        review=json.loads((self.root/"review.json").read_text())
        review["qualification_sha256"]=driver.digest(self.root/"qualification.json")
        driver.save(self.root/"review.json",review)
        self.assertEqual(driver.check(self.root),"frozen")
        code.write_text("changed")
        with self.assertRaises(ValueError):driver.check(self.root)
    def test_public_success_flag_without_every_required_check_is_not_accepted(self):
        self.require()
        for defect in ("missing","failed","wrong-command"):
            with self.subTest(defect=defect), tempfile.TemporaryDirectory() as tmp:
                self.root=pathlib.Path(tmp)
                def run(label,effort,allowance):
                    row=self.cell(label,effort,allowance)
                    checks=[dict(c,exit_code=0) for c in json.loads((HERE/"public-checks.json").read_text())["checks"]]
                    if defect=="missing":checks.pop()
                    elif defect=="failed":checks[1]["exit_code"]=1
                    else:checks[1]["command"]="true"
                    row["public_verification"]["checks"]=checks
                    return row
                result=self.invoke(run_cell=run)
                self.assertFalse(any(r["accepted"] for r in result["results"]))

    def test_bad_context_is_charged_and_prevents_a_second_model_run(self):
        self.require()
        def run(label,effort,allowance):
            row=self.cell(label,effort,allowance);row["context_valid"]=False
            return row
        result=self.invoke(run_cell=run)
        self.assertEqual(len(self.calls),1)
        self.assertEqual(Decimal(result["new_cost_usd"]),Decimal(".4"))
        self.assertFalse(result["results"][0]["accepted"])
    def test_unknown_attempt_leaves_ledger_explicitly_nonfinal(self):
        self.require()
        def run(label,effort,allowance):
            self.cell(label,effort,allowance)
            raise RuntimeError("client lost after response")
        with self.assertRaises(RuntimeError):self.invoke(run_cell=run)
        row=json.loads((self.root/"results.json").read_text())
        self.assertIs(row.get("cost_is_final"),False)
    def test_default_composition_discovers_every_composed_tool_directory(self):
        self.assertTrue(hasattr(driver,"composition"))
        tools=self.root/"tools"
        names=("agent_lifecycle","hint_authority_pilot","hint_authority_completion","hint_authority_resume","hint_authority_workflow")
        for name in names:
            (tools/name).mkdir(parents=True)
            (tools/name/"module.py").write_text("initial")
        (tools/"hint_authority_workflow/public-checks.json").write_text("{}")
        (self.root/"plan.json").write_text("{}")
        with patch.object(driver,"HERE",tools/"hint_authority_workflow"), patch.object(driver.audit,"fingerprint",return_value="legacy"):
            before=driver.composition(self.root)
            for name in names:
                path=tools/name/"module.py"
                path.write_text("changed")
                self.assertNotEqual(before,driver.composition(self.root),name)
                path.write_text("initial")

    def test_multiturn_reconciliation_uses_latest_cumulative_terminal(self):
        self.require()
        def run(label,effort,allowance):
            row=self.cell(label,effort,allowance)
            path=self.root/label/"stream.jsonl"
            latest=path.read_text()
            earlier=json.loads(latest);earlier["total_cost_usd"]=.1
            path.write_text(json.dumps(earlier)+"\n"+latest)
            return row
        result=self.invoke(run_cell=run)
        self.assertEqual(Decimal(result["new_cost_usd"]),Decimal(".8"))
    def test_nonsettled_lifecycle_is_not_accepted_despite_all_other_success_flags(self):
        self.require()
        for status in ("incomplete","waiting",None):
            with self.subTest(status=status), tempfile.TemporaryDirectory() as tmp:
                self.root=pathlib.Path(tmp)
                def run(label,effort,allowance):
                    row=self.cell(label,effort,allowance);row["lifecycle"]["status"]=status
                    return row
                result=self.invoke(run_cell=run)
                self.assertFalse(any(r["accepted"] for r in result["results"]))
