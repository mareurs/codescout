# SDD ledger — plan: docs/superpowers/plans/2026-11-05-complete-workflow-calibration.md

Task 1 in progress; base7e57bf8f9. One coupled implementation task, inline execution, independent final reviewer required. Resident scratch outside repo overrides skill workspace helper per project convention.

Ruling: operator said allocation can be larger. Use8USD fresh allocation,4USD per arm, within remaining8.202580800000000036 of40USD thread cap. Old pilot and costs stay closed/unmodified. CLI32turns/output8192 and public profile unchanged; budgets raised equally. CLI budget guard opt-in to preserve default behavior.

RED new driver8tests allfail missingimplementation; GREEN8. Admissiontests then RED11tests3fail missingpreflight. Runtimebudget RED9tests1failure missingkeyword; GREEN9. Admission implementation currently under test. No credentials/provider calls.

Next: finalize independent public/context endpoint assertions and historical/admission tests, qualify newbudgetargv actualnative controls, privatecontrolproof reuse with exactcandidate/logbindings; independentreview/appliedmutations; finalgate/commit; reviewedpreflightthenpaidpair. No modelcalls beforeadmission.

## Verification checkpoint

Final driver17tests GREEN; lifecycle44 GREEN; pilot28/completion9/resume3 GREEN. Parent observed RED unknowncostfinality14tests1failure before adding ledger cost_is_final=false during each launched attempt. Six findings filed immediately MAIN: b0214bf90135b9b1,7ecbe51427e022c5,d468588cea173d29,edf04832a5809d11,c29e0d85ccbd0d27,c51237303dcfa962. Reviewer initial12mutations6killed6survived, one invariant-equivalent; five guard gaps have targeted added tests, focused recheck pending.

ActualCLI/native budget4controls @bg_00000062 EXITED0, four cells with independent readback/contextwire/hint/canary boundary checks, providercost0,12absenceinspections. Fullgate @bg_00000063 RUNNING, record/tmp/codescout-bg/455879-a720241d-bg_00000063.json. Freshcampaignroot /home/marius/.cache/codescout-resident/codescout/complete-workflow-calibration-20261105 prepared without paidcalls. Closedpilotcostindependentlyreconciles2.57626490000000013; threadprior31.797419199999999964 unchanged.

Ruling: reuse private controls onlyafter rebuilding candidatebytes with sameoracle(old_apiTruefornegative), comparing complete2060filepopulations per candidate and reading originalactualDockerlogs. Negative has2assertionfailures; positive2acceptancetests+bothregressionfiltersrun/pass. Initialbaselinewitness usedwrongAPI, comparisonrejected; retainedfailedstaging, freshv2nowexact. No newRustrecompile/provideronboarding necessary for identical controlinputs.

Ruling: transportqualification script snapshots campaignfiles but doesnotexecute driver. Preserve originalqualification-as-produced.json; move those snapshots under explicitnotexecutedmetadata. Enforced runtime_hashes are16actualworker/lifecycleexecutiondependencies; finaldriver+testsboundseparatelybycompletecompositionandreview. This avoids claiming atransportprobequalifiedcampaignlogic. Source stable after finaltestadditions; reviewerperformingfocusedM04/05/06/07/12+nonfinalcostrecheck. No review.json/paidstartmarker yet.

## Reviewed source committed; paid pair active

Focused6appliedmutations allkilled, no remainingImportant findings. Finaloffline17/44/28/9/3suites=101testmethods. Reviewbindingactualcompositionfaf053c592896d9bdabb98ec554258a4584abdfdf89e4c04bee0b87a9bfa739a, qSHA d3f1e46878f8e6cac9f2e631ebd2c2b1eb68e1fab837a677e81ebc4b01e6792c, acceptanceSHA f7c687a442db2980cc1c72f6672060146c288c2cf36ddc233a7e97f586637497. Parentreadfullreport/actualmutantrecords;bindinghelperverifiedsource5hashes/costmatrix/gate/reporthash/proofhashes.

Vgate@bg63EXITED0/all5lanes0. Localcommit c278effb9b36259480e079051d16238d66314e8e,stablepatch-id3daaab6a1223c754beb4366f6425de4bd6e26d45,canonicalSID,fiveexactpaths,Vclean. No merge/push. Commitartifactlookupskippednorunnablebinary;otherguards passed. Actual --check returnsregisteredfpfaf... withprovider_calls0. review.json installedfromactualreviewbindingonlyaftercommitgateall0.

PAIDPAIR STARTED @bg_00000067,record /tmp/codescout-bg/455879-a720241d-bg_00000067.json, commandpython3 -B tools/hint_authority_workflow/driver.py --paid /home/marius/.cache/codescout-resident/codescout/complete-workflow-calibration-20261105. DoNOTrelaunch/resetroot. Awaitactualoutcomes/cost/privategrade, preserveinflightmarkers. Modelcostnotyetreconciled. Allsixissuesnowfixedwithsourceanchors;sourcequalitydoesnotestablishmodelquality. Primaryrepair/publicworkflowtiming isreceipt.wall_s; outercomplete_wall_salsoincludesprivategradingmeasurementoverhead, whose sharedcache is warm forsecondarm. Do notcompareouterlatencieswithoutthiscaveat.

## Incidental prior-runtime ownership finding

While reading live background progress, actual qualify.native_record source was opened. Offline mocked externalDocker reproduction proved it accepts replacement-id despite ownerfileoriginal-id whenname/image/labelmatch. FiledMAIN39785443931155d4 immediately. This is prior-runtimecode, notnewdriverchange. No evidenceofreplacementinactivepair. Keepfrozenactivecodeunchanged; independentactualDockerliveobservationscaptureIDs/resourcesandfinalreadbackmustcompareagainstpublicownership. Donotrelabelexperimentfailedfromsimulatedcaseorresetrun. Fixbeforefuturecohortsafterpreservingthispair.

Readonly /tmp/capture-workflow-native-01a15ca9-20261105.py actualLOWworkerwitnessobservedinittrue,CPU2,PID512,memory6GiB,writablecorrectactor,CARGO_TARGET_DIR/testbed/target. Lowfirstterminalcumulative0.4249394 isnotfinalcost; actualbackgroundfullcargo profile stillrunning. Statushelpercountsrequestartifacts,notbillableruns. No successclaimuntilallpublic/privateoutcomes.
