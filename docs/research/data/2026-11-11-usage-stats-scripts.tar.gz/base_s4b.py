import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from base_common import *
P='/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad/base_probe.json'
d=json.load(open(P))
print("probe (live DB at run time, not id-bounded): calls",d['calls'],"errors",d['errors'],"err%",d['error_pct'],"unclassified",d['unclassified'])
ir=d['immediate_repeat']; E=sum(x['errors'] for x in ir); R=sum(x['immediate_repeats'] for x in ir)
print("probe immediate-repeat overall (families n>=5 only):",R,"/",E,f"{100*R/E:.1f}%")
print("| err_family | errors | immediate repeats | rate | via msg proxy |")
for x in ir: print(f"| {x['err_family']} | {x['errors']} | {x['immediate_repeats']} | {x['repeat_rate']} | {x['via_msg_proxy']} |")
print("\n| err_family | errors | recovered | unrecovered(25) | %unrec | median | p90 | mean |")
cr=d['calls_to_recovery']
for x in sorted(cr,key=lambda x:-x['errors']): print(f"| {x['err_family']} | {x['errors']} | {x['recovered']} | {x['unrecovered']} | {x['pct_unrecovered']} | {x['median_calls']} | {x['p90_calls']} | {x['mean_calls']} |")
print("overall recovered",sum(x['recovered'] for x in cr),"unrecovered",sum(x['unrecovered'] for x in cr))
print("error_runs",d['error_runs'])
# principal-keyed own computation
c=conn()
rows=c.execute(f"select id,tool_name,outcome,err_family,substr(error_msg,1,60) m,session_id,coalesce(agent_id,'') a from tool_calls where id<={MAXID} order by id").fetchall()
def keyfn(k):
    per=collections.defaultdict(list)
    for r in rows: per[k(r)].append(r)
    return per
def sig(r): return r['err_family'] or (r['tool_name']+':'+r['m'])
def analyse(per,label):
    pt=collections.defaultdict(lambda: collections.Counter()); dist=collections.defaultdict(list)
    tot=collections.Counter(); runs=collections.Counter(); alld=[]
    for s,seq in per.items():
        cur=0
        for i,r in enumerate(seq):
            err=r['outcome']!='success'
            if err: cur+=1
            else:
                if cur: runs[cur]+=1
                cur=0
            if not err: continue
            t=r['tool_name']; pt[t]['errs']+=1; tot['errs']+=1
            if i+1<len(seq):
                n=seq[i+1]
                if n['outcome']!='success' and sig(n)==sig(r): pt[t]['rep']+=1; tot['rep']+=1
            dd=None
            for j in range(i+1,min(i+26,len(seq))):
                if seq[j]['outcome']=='success': dd=j-i; break
            if dd is None: pt[t]['unrec']+=1; tot['unrec']+=1
            else: dist[t].append(dd); alld.append(dd)
        if cur: runs[cur]+=1
    print(f"\n## {label}: errors {tot['errs']}, immediate repeat {tot['rep']} ({100*tot['rep']/tot['errs']:.1f}%), unrecovered within 25 calls {tot['unrec']} ({100*tot['unrec']/tot['errs']:.1f}%), recovery calls median {pct(alld,50)} p90 {pct(alld,90)} mean {sum(alld)/len(alld):.2f}")
    ge2=sum(n for l,n in runs.items() if l>=2); e2=sum(l*n for l,n in runs.items() if l>=2); te=sum(l*n for l,n in runs.items())
    print("runs hist",dict(sorted(runs.items())),"runs>=2",ge2,"errors in runs>=2",e2,f"{100*e2/te:.1f}%")
    print("| tool | errors | imm repeat | rate% | unrecovered(25) | rec median | rec p90 |")
    for t,x in sorted(pt.items(), key=lambda x:-x[1]['errs']):
        v=dist[t]; print(f"| {t} | {x['errs']} | {x['rep']} | {100*x['rep']/x['errs']:.1f} | {x['unrec']} | {pct(v,50)} | {pct(v,90)} |")
analyse(keyfn(lambda r:r['session_id']),"keyed by session_id (probe convention), id<=299175")
analyse(keyfn(lambda r:(r['session_id'],r['a'])),"keyed by (session_id, agent_id) principal")
