import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_enrich import *
rows=enrich()
Z=[r for r in rows if r['out'].get('zero') and r['has_in']]
print('zero with input',len(Z))
c2=collections.Counter()
for r in Z:
    ws=r['ip'].get('workspace') or r['root']
    c2['main' if ws==PROJ else ('exists' if ws and os.path.isdir(ws) else 'missing')]+=1
print(c2)
print(collections.Counter(r['root'] for r in Z).most_common(6))
print(collections.Counter(path_class(r['ip'].get('path')) for r in Z))
