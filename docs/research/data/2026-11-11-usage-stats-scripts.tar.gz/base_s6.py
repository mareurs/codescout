import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from base_common import *
import datetime, subprocess
c=conn()
rows=c.execute(f"select id,called_at,codescout_sha,codescout_dirty,project_sha,session_id from tool_calls where id<={MAXID}").fetchall()
N=len(rows)
print("codescout_sha null/empty",sum(1 for r in rows if not r['codescout_sha']),"dirty values",collections.Counter(r['codescout_dirty'] for r in rows),"project_sha null/empty",sum(1 for r in rows if not r['project_sha']))
sha=collections.Counter(r['codescout_sha'] for r in rows)
print("distinct codescout_sha",len(sha),"distinct project_sha",len({r['project_sha'] for r in rows}))
first={}; last={}; sess=collections.defaultdict(set); dirty=collections.Counter()
for r in rows:
    s=r['codescout_sha']; first.setdefault(s,r['called_at']); last[s]=r['called_at']; sess[s].add(r['session_id']); dirty[s]+= 1 if r['codescout_dirty'] else 0
def gitdate(s):
    if not s: return None
    try:
        o=subprocess.run(['git','-C','/home/marius/work/claude/codescout','show','-s','--format=%cI',s],capture_output=True,text=True,timeout=10)
        return o.stdout.strip() or None
    except Exception: return None
print("\n| codescout_sha | calls | share% | sessions | dirty calls | first seen | last seen | commit date (git, committer) |")
print("|---|---|---|---|---|---|---|---|")
for s,n in sha.most_common(10):
    print(f"| {s} | {n} | {100*n/N:.1f} | {len(sess[s])} | {dirty[s]} | {first[s][:16]} | {last[s][:16]} | {gitdate(s)} |")
print("top10 share",100*sum(n for _,n in sha.most_common(10))/N)
# resolvable shas
res={}
for s in sha:
    res[s]=gitdate(s)
ok=sum(1 for s in res if res[s]); print("shas resolvable in git:",ok,"/",len(res),"calls covered",sum(sha[s] for s in res if res[s]),f"{100*sum(sha[s] for s in res if res[s])/N:.1f}%")
# build age at call time
def pd(s): return datetime.datetime.fromisoformat(s)
ages=[]
for r in rows:
    d=res.get(r['codescout_sha'])
    if d:
        a=(datetime.datetime.strptime(r['called_at'][:19],'%Y-%m-%d %H:%M:%S').replace(tzinfo=datetime.timezone.utc)-pd(d)).total_seconds()/86400
        ages.append(a)
print("age (days) of commit date vs call time, resolvable rows",len(ages),"p50 %.2f p90 %.2f max %.1f"%(pct(ages,50),pct(ages,90),max(ages)),"negative",sum(a<0 for a in ages))
for th in (1,3,7,14):
    print(f"calls served by build whose commit is older than {th}d at call time: {sum(a>th for a in ages)} ({100*sum(a>th for a in ages)/len(ages):.1f}% of resolvable)")
# weekly dirty
def wk(s):
    d=datetime.date.fromisoformat(s[:10]); return (d-datetime.timedelta(days=d.weekday())).isoformat()
w=collections.defaultdict(collections.Counter)
for r in rows:
    k=wk(r['called_at']); w[k]['n']+=1; w[k]['dirty']+= 1 if r['codescout_dirty'] else 0; w[k]['sha'] =0
ws=collections.defaultdict(set)
for r in rows: ws[wk(r['called_at'])].add(r['codescout_sha'])
print("\n| week | calls | dirty calls | dirty% | distinct shas |")
for k in sorted(w): print(f"| {k} | {w[k]['n']} | {w[k]['dirty']} | {100*w[k]['dirty']/w[k]['n']:.1f} | {len(ws[k])} |")
print("overall dirty",sum(1 for r in rows if r['codescout_dirty']),100*sum(1 for r in rows if r['codescout_dirty'])/N)
# project_sha
ps=collections.Counter(r['project_sha'] for r in rows)
print("\nproject_sha top5",ps.most_common(5),"distinct",len(ps))
print("sample project_sha",[r['project_sha'] for r in rows[:2]])
# shas per day
# sha length forms
print("sha lengths",collections.Counter(len(s or '') for s in sha))
