import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_common import *
rows=load()
cnt=collections.Counter()
ex={}
for r in rows:
    t=out_text(r['oj'])
    if t is None: continue
    first=t.split('\n',1)[0]
    k=re.sub(r'\d+','N',first)[:60]
    cnt[k]+=1; ex.setdefault(k,(r['id'],t[:200]))
for k,n in cnt.most_common(25): print(n,repr(k),ex[k][0])
# error rows
c=collections.Counter()
for r in rows:
    if r['outcome']!='success': c[(r['outcome'],r['fam'],(r['err'] or '')[:80])]+=1
for k,n in c.most_common(20): print(n,k)
