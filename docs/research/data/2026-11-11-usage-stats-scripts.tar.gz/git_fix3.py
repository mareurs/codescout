p = "/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad/git_bench/src/main.rs"
s = open(p).read()
a = '    if want("blame") {'
b = '''    if want("scale") {
        for n in [1usize, 20, 200, 1000, 5000] {
            bench(&format!("revwalk TIME first {n} commits, oids only"), "git2", move || {
                let repo = Repository::open(r).unwrap();
                let mut w = repo.revwalk().unwrap();
                w.push_head().unwrap();
                w.set_sorting(Sort::TIME).unwrap();
                w.take(n).flatten().count()
            }, 10);
            bench(&format!("revwalk NONE-sort first {n} commits, oids only"), "git2", move || {
                let repo = Repository::open(r).unwrap();
                let mut w = repo.revwalk().unwrap();
                w.push_head().unwrap();
                w.take(n).flatten().count()
            }, 10);
            bench(&format!("log first {n} commits"), "CLI log -n N --format=%H", move || {
                cli(r, &["log", "-n", &n.to_string(), "--format=%H"]).len()
            }, 10);
        }
        bench("revparse HEAD~200 (ancestor walk, repo open per iter)", "git2", || {
            let repo = Repository::open(r).unwrap();
            let x = repo.revparse_single("HEAD~200").unwrap().id().to_string().len(); x
        }, 10);
        bench("revparse HEAD~200", "CLI rev-parse HEAD~200", || cli(r, &["rev-parse", "HEAD~200"]).len(), 10);
    }
''' + a
assert a in s
s = s.replace(a, b, 1)
open(p, "w").write(s)
print("ok")
