#!/bin/bash
# usage: git_runbench.sh <label> [filter]
SP=/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad
OUT=$SP/git_bench_$1.txt
{
  echo "## batch $1 filter=${2:-all}"
  echo "load before: $(uptime)"
  $SP/git_bench/target/release/git_bench /home/marius/work/claude/codescout ${2:-}
  echo "load after: $(uptime)"
} > "$OUT" 2>&1
echo done "$OUT"
