p = "/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad/stats-git-library.md"
s = open(p).read()
reps = [
 ('The user\'s figure "93 git2 sites" matches 97 lines minus 3 comments minus 1 (rounding of my regex versus theirs).',
  'The user\'s figure "93 git2 sites" is close to my 94 code lines (97 lines minus 3 comments); the 1-line difference is regex and counting convention, not checked line by line.'),
 ('first CLI site is merge_worktree 365c2df81, 2026-07-17)',
  'oldest hit in the first 15 results of `git log -S \'Command::new("git")\' -- src` is merge_worktree 365c2df81, 2026-07-17; I did not page further back)'),
 ('| append_entry | REMOVE the dependency question: 0 production sites; the 12 git2 lines are test fixtures only (the unpushed guard was dropped in 232f133cc) | - | - | S (tests to CLI) |',
  '| append_entry | no production git2 or CLI site (grep: all 12 git2 lines are at or after line 1688, inside `mod tests`, which starts at 471) | - | - | S (tests to CLI if the library is ever dropped) |'),
 ('at least +6 ms per tool call just for #1 on Linux', 'about +5 ms per tool call just for #1 on Linux (4 discovers x (1.47 - 0.17) ms)'),
 ('| worktree list (39 worktrees at the time) |', '| worktree list (39 linked worktrees at that moment) |'),
 ('this repo has 43 worktrees', 'this repo had about 40 linked worktrees (`git worktree list` showed 43 lines at the start)'),
 (', git_sites / git_git2_sites.txt.', ', git_git2_sites.txt (raw grep of every git2 line).'),
]
for a, b in reps:
    assert a in s, a[:60]
    s = s.replace(a, b)
open(p, "w").write(s)
print("ok")
