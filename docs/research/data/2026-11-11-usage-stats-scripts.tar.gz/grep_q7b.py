import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_common import *
from grep_shell import *
import pickle
C=pickle.load(open('grep_shell_calls.pkl','rb'))
FAMS=['git grep','rg','grep_recursive','grep_files','find','fd','grep_filter','grep_buffer']
def norm_flags(rec):
    fl=set(rec['flags']); fam=rec['fam']; out=set()
    m={'-n':'-n','--line-number':'-n','-l':'-l','--files-with-matches':'-l','-L':'-L','-c':'-c','--count':'-c','--count-matches':'-c',
       '-A':'-A/-B/-C','-B':'-A/-B/-C','-C':'-A/-B/-C','--context':'-A/-B/-C','--after-context':'-A/-B/-C','--before-context':'-A/-B/-C',
       '-t':'--type/-t','--type':'--type/-t','-T':'--type-not','--type-not':'--type-not',
       '-g':'-g/--glob','--glob':'-g/--glob','--iglob':'-g/--glob','--include':'--include','--exclude':'--exclude','--exclude-dir':'--exclude-dir',
       '-P':'-P/--pcre2','--pcre2':'-P/--pcre2','-w':'-w','--word-regexp':'-w','-i':'-i','--ignore-case':'-i','-S':'-S smart-case','-F':'-F','--fixed-strings':'-F','-E':'-E','--extended-regexp':'-E',
       '--no-ignore':'--no-ignore/-u','-u':'--no-ignore/-u','--no-ignore-vcs':'--no-ignore/-u','--hidden':'--hidden/-.','-.':'--hidden/-.','-U':'multiline -U/-z','--multiline':'multiline -U/-z','-z':'multiline -U/-z',
       '-o':'-o only-matching','--only-matching':'-o only-matching','-m':'-m/--max-count','--max-count':'-m/--max-count','-v':'-v invert','--invert-match':'-v invert',
       '--files':'--files','-r':('-r recursive' if fam=='grep' else '-r replace'),'-R':'-r recursive','--recursive':'-r recursive','--json':'--json','--stats':'--stats',
       '-H':'-H/-h filename','-h':'-H/-h filename','--no-filename':'-H/-h filename','--with-filename':'-H/-h filename','-q':'-q','-s':'-s','--no-index':'--no-index','--untracked':'--untracked','--cached':'--cached',
       '-p':'-p/-W function ctx','-W':'-p/-W function ctx','--heading':'--heading','--no-heading':'--no-heading','--color':'--color','--sort':'--sort','-I':'-I','-a':'-a text','--text':'-a text','-j':'-j','--all-match':'--and/--all-match','--and':'--and/--all-match','-e':'-e','-f':'-f','--max-depth':'--max-depth','-d':'-d','-x':'-x/--exec','--exec':'-x/--exec','-e/ext':'ext'}
    for f in fl:
        if f in m: out.add(m[f])
    return out
def pcre_look(p): return bool(p) and bool(re.search(r'\(\?<[=!]|\(\?[=!]|\\[1-9]|\(\?>|\\K',p))
res={}
for fam in FAMS:
    xs=[]
    for (id_,sid,aid,ca,lat,ov,cmd,recs,hasout,text,cwd) in C:
        # choose rec of this sub
        rr=[r for r in recs if r['sub']==fam]
        if not rr: continue
        # only count call under this family if it is the call-level family
        subs={r['sub'] for r in recs}
        top=next(f for f in ['git grep','rg','grep_recursive','grep_dir_no_r','grep_files','find','fd','grep_filter','grep_buffer'] if f in subs)
        if top!=fam and not (fam=='grep_files' and top=='grep_dir_no_r'): continue
        xs.append((id_,aid,rr[0],cmd,hasout,text,ov,lat,cwd,sid))
    res[fam]=xs
print('FLAG SHARES (per call; rec = first segment of the family in the call)')
for fam in FAMS:
    xs=res[fam]
    if not xs: continue
    cnt=collections.Counter()
    for (id_,aid,rec,cmd,hasout,text,ov,lat,cwd,sid) in xs:
        for f in norm_flags(rec): cnt[f]+=1
        if fam=='rg' or fam=='git grep' or fam=='grep_recursive' or fam=='grep_files':
            if pcre_look(rec['pattern']): cnt['(PCRE-only pattern: look-around/backref)']+=1
            if rec['pattern'] and re.fullmatch(r'[A-Za-z_]\w*',rec['pattern']): cnt['(pattern is bare identifier)']+=1
            if rec['pattern'] and '|' in rec['pattern']: cnt['(pattern has alternation)']+=1
            if fam=='git grep':
                if rec.get('revs'): cnt['(git grep with rev arg)']+=1
                if rec.get('dd'): cnt['(git grep pathspec after --)']+=1
            if rec['paths']: cnt['(has explicit path/pathspec arg)']+=1
            else: cnt['(no path arg = cwd default)']+=1
    print(f'== {fam}: {len(xs)} calls')
    print('   '+', '.join(f"{k}: {v} ({100*v/len(xs):.0f}%)" for k,v in cnt.most_common(30)))
# output behaviour
print('\nOUTPUT BEHAVIOUR (calls with output_json)')
print('family | calls | with out | out bytes p50 | p90 | max | buffered(output_id) | overflowed | exit1(no match) | bounded head/tail | bounded -m')
for fam in FAMS:
    xs=res[fam]
    if not xs: continue
    w=[x for x in xs if x[4]]
    by=[len(x[5].encode()) for x in w]
    buf=sum(1 for x in w if '"output_id"' in x[5])
    ex1=sum(1 for x in w if re.search(r'"exit_code":\s*1\b',x[5]))
    bh=sum(1 for x in xs if re.search(r'\|\s*(head|tail)\b',x[3]))
    bm=sum(1 for x in xs if re.search(r'(^|\s)(-m\s*\d+|-m\d+|--max-count)',x[3]))
    ov=sum(1 for x in xs if x[6])
    print(f"{fam} | {len(xs)} | {len(w)} | {pct(by,50) if by else None} | {pct(by,90) if by else None} | {max(by) if by else None} | {buf} ({100*buf/max(1,len(w)):.0f}%) | {ov} | {ex1} | {bh} ({100*bh/len(xs):.0f}%) | {bm}")
pickle.dump(res,open('grep_shell_res.pkl','wb'))
