#!/bin/bash
SP=/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad
B=$SP/git_build
cd "$B" || exit 1
export RUSTC_WRAPPER= CARGO_BUILD_JOBS=8 CARGO_TARGET_DIR=$B/target_gx_release
nice -n 19 cargo build --offline --release --bin gxbench --manifest-path $B/gx/Cargo.toml > $B/gxbench_build.txt 2>&1
echo "build exit $?" >> $B/gxbench_build.txt
{
  echo "load before: $(uptime)"
  $B/target_gx_release/release/gxbench /home/marius/work/claude/codescout
  echo "load after: $(uptime)"
} > $B/gxbench_out.txt 2>&1
echo done
