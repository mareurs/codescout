import re
SP = "/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad"
s = open(SP + "/bench_tables.py").read()
s = s.replace('''    for r in d["results"]:
        t = [x * 1000 for x in r["times"]]
        out[r["command"]] = (st.median(t), min(t), q(t, .9))
    return out''', '''    for r in d["results"]:
        t = [m["time_wall_clock"]["value"] * 1000 for m in r["measurements"]]
        cpu = [m["time_cpu"]["value"] * 1000 for m in r["measurements"]]
        out[r["name"]] = (st.median(t), min(t), q(t, .9), st.median(cpu))
    return out''')
s = s.replace('''def hc(h):
    return "-" if h is None else "%.1f / %.1f / %.1f" % h''', '''def hc(h):
    return "-" if h is None else "%.1f / %.1f / %.1f" % h[:3]''')
open(SP + "/bench_tables.py", "w").write(s)
