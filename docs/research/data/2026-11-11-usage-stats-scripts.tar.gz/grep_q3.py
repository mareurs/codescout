import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_enrich import *
from grep_q23 import classify
rows=enrich()
O=[r for r in rows if r['out']['has_out']]
print('rows with output',len(O),'parent',sum(r['parent'] for r in O),'sub',sum(not r['parent'] for r in O))
def full(r): return r['out']['text']
phr={'hidden_paths_warning':'Hidden paths','this_zero_describes':'this zero describes','no_file_passed_glob':'No file under','walk_cut':'walk cut','time budget':'time budget','Showing N of M':'Showing ','capped_floor':'floor, not a count','byte budget':'byte budget','skipped_large':'not searched; a missing','binary skipped':'binary file(s) skipped','literal_fallback':'literal fallback','gitignore second':'Gitignore rules are a','walk could not read':'The walk could not read','reads_resolving_warn':'Reads are resolving','no workspace pin':'carried no workspace= pin','param corrected':'is not a parameter of grep','unreadable':'unreadable', 'hidden_skipped(nonzero)':'hidden'}
for nm,ph in phr.items():
    tot=[r for r in O if ph in full(r)]
    z=[r for r in tot if r['out']['zero']]
    print(f"{nm:28s} all {len(tot):5d} (parent {sum(r['parent'] for r in tot)}, sub {sum(not r['parent'] for r in tot)}) of which zero-rows {len(z)}")
# header kinds
hk=collections.Counter((r['out']['hkind'],r['out']['env']) for r in O)
print('header kind (kind,envelope):',hk)
unk=[r for r in O if r['out']['hkind'] is None and not r['out']['zero']]
print('unparsed headers',len(unk)); 
c=collections.Counter(re.sub(r'\d+','N',r['out']['first'])[:70] for r in unk)
for k,n in c.most_common(12): print('  ',n,repr(k))
# distribution of n
buckets=[(0,0),(1,1),(2,5),(6,20),(21,50),(51,10**9)]
cnt=collections.Counter()
for r in O:
    n=0 if r['out']['zero'] else r['out']['n']
    if n is None: cnt['unparsed']+=1; continue
    for lo,hi in buckets:
        if lo<=n<=hi: cnt[f'{lo}-{hi if hi<10**9 else "inf"}']+=1
print('match-count buckets (rows with output)',cnt)
ns=[r['out']['n'] for r in O if r['out']['n'] is not None]
print('n p50/p90/p99/max',pct(ns,50),pct(ns,90),pct(ns,99),max(ns))
# zero
Z=[r for r in O if r['out']['zero']]
print('zeros',len(Z),'exact bare "0 matches"',sum(1 for r in Z if r['out']['body'].strip()=='0 matches' and not r['out']['warns']),'with warnings/notes',sum(1 for r in Z if r['out']['body'].strip()!='0 matches' or r['out']['warns']))
print('zero parent/sub',sum(r['parent'] for r in Z),sum(not r['parent'] for r in Z))
# zero by date
zd=collections.defaultdict(lambda:[0,0])
for r in O:
    d=r['called_at'][:10]; zd[d][0]+=1; zd[d][1]+=r['out']['zero']
# overflow
ov=[r for r in rows if r['overflowed']]
print('overflowed rows',len(ov),'of',len(rows),'; with env json',sum(1 for r in ov if r['out'].get('env')),'; env but not overflowed',sum(1 for r in O if r['out'].get('env') and not r['overflowed']))
ot=[r['otok'] for r in ov if r['otok']]
print('overflow_tokens n',len(ot),'p50/p90/max',pct(ot,50),pct(ot,90),max(ot) if ot else None)
print('overflow by parent/sub',sum(r['parent'] for r in ov),sum(not r['parent'] for r in ov))
# bytes
by=[r['out']['bytes'] for r in O]
print('output_json bytes p50/p90/p99/max',pct(by,50),pct(by,90),pct(by,99),max(by),'mean',sum(by)/len(by),'total MB',sum(by)/1e6)
byt=[len(r['out']['text'].encode()) for r in O]
print('text bytes p50/p90/p99/max',pct(byt,50),pct(byt,90),pct(byt,99),max(byt))
# bytes by mode
for key in ('files','lines'):
    pass
# bytes by context_lines>0
for nm,f in (('ctx0',lambda r:r['has_in'] and not r['ip'].get('context_lines')), ('ctx>0',lambda r:r['has_in'] and r['ip'].get('context_lines') not in (None,0,'0'))):
    b=[r['out']['bytes'] for r in O if f(r)]
    print(nm,len(b),pct(b,50),pct(b,90),max(b))
# max output rows
for r in sorted(O,key=lambda r:-r['out']['bytes'])[:5]: print('big',r['id'],r['out']['bytes'],r['overflowed'],(r['ij'] or '')[:150])
# capped
print('capped header rows',sum(1 for r in O if r['out'].get('capped')))
# truncation 'showing'
sh=[r for r in O if re.search(r'Showing \d+ of \d+',full(r))]
print('Showing N of M rows',len(sh))
# output_json truncated at db level?
print('max len oj',max(len(r['oj']) for r in O))
