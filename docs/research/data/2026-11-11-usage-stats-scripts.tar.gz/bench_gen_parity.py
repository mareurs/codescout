import sys, json
sys.path.insert(0, "/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad")
import bench_common as b
jobs = []
for p, sk, s in b.combos():
    if p["pcre"]:
        # one call to capture the rejection text
        jobs.append(dict(label=f"{p[chr(105)+chr(100)]}|{sk}|cs-lines", tool="grep", args=b.cs_args(p, s), repeats=0))
        continue
    jobs.append(dict(label=f"{p[chr(105)+chr(100)]}|{sk}|cs-files", tool="grep", args=b.cs_args(p, s, "files"), repeats=0,
                     drain=f"{b.SP}/parity/cs_{p[chr(105)+chr(100)]}_{sk}.json"))
json.dump(dict(nonce="par1", settle=30, out=f"{b.SP}/bench_out_parity.json", jobs=jobs), open(f"{b.SP}/bench_spec_parity.json", "w"))
print(len(jobs))
