import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from base_common import *
c=conn()
cnt=collections.Counter(); roots=collections.defaultdict(set)
for r,n in c.execute(f"select project_root,count(*) from tool_calls where id<={MAXID} group by 1"):
    k=classify_root(r); cnt[k]+=n; roots[k].add(r)
for k,v in cnt.most_common(): print(k,v,len(roots[k]))
for k in ('other','tmp_harness','null'):
    print(k, sorted(roots[k])[:60])
