import json, sqlite3, statistics as st
SP = "/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad"
d = json.load(open(SP + "/bench_out_ovh.json"))
db = sqlite3.connect("file:/home/marius/work/claude/codescout/.codescout/usage.db?mode=ro", uri=True)
mk = db.execute("select id, session_id from tool_calls where tool_name='run_command' and input_json like ? order by id desc limit 1", ('{"command":"echo bench_marker_ovh1%',)).fetchone()
rows = db.execute("select tool_name, latency_ms, input_json from tool_calls where session_id=? and id>? and tool_name in ('read_file','run_command') order by id", (mk[1], mk[0])).fetchall()
for t in ("read_file", "run_command"):
    lat = [r[1] for r in rows if r[0] == t][1:]
    print(t, "latency_ms median", st.median(lat), "n", len(lat))
for r in d["results"]:
    runs = [x for x in r["runs"] if not x["warm"]]
    print(r["label"], "client wall median", st.median(x["wall_ms"] for x in runs), "min", min(x["wall_ms"] for x in runs), "cpu ms/call", sum(x["cpu_ticks"] for x in runs) * 10 / len(runs))
