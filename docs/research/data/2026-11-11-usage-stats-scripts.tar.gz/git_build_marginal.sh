#!/bin/bash
# Marginal cost of git2 over what the repo already needs: build libgit2-sys, then url (already a direct dep of codescout), then git2+g2.
SP=/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad
B=$SP/git_build
cd "$B" || exit 1
export RUSTC_WRAPPER=
for prof in release dev; do
  T=$B/target_g2_${prof}_marginal
  rm -rf "$T"
  export CARGO_BUILD_JOBS=8 CARGO_TARGET_DIR=$T
  flag=""; [ "$prof" = release ] && flag="--release"
  R="python3 -I $SP/git_rusage.py nice -n 19 cargo build --offline $flag --manifest-path $B/g2/Cargo.toml"
  {
    echo "== marginal $prof start: $(uptime)"
    echo "-- step1: -p url (what codescout already pays for)"
    $R -p url
    echo "-- step2: -p libgit2-sys"
    $R -p libgit2-sys
    echo "-- step3: rest (git2 crate + g2 main)"
    $R
    echo "end: $(uptime)"
  } > $B/results2_g2_${prof}_marginal.txt 2>&1
done
echo done
