import sys, json
sys.path.insert(0, "/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad")
import bench_common as b
jobs = []
for p, sk, s in b.combos():
    if p["pcre"]: continue
    a = b.cs_args(p, s, "files")
    if s.get("reg"): a["time_budget_ms"] = 300000
    pid = p["id"]; lab = f"{pid}|{sk}|cs-files"
    jobs.append(dict(variants=[dict(label=lab, tool="grep", args=a)], repeats=0, warmup=1, drain={lab: f"{b.SP}/parity2/cs_{pid}_{sk}.json"}))
json.dump(dict(nonce="par2", settle=20, out=f"{b.SP}/bench_out_parity2.json", jobs=jobs), open(f"{b.SP}/bench_spec_parity2.json", "w"))
print(len(jobs))
