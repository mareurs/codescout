import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_enrich import *
rows=enrich()
W=[r for r in rows if r['has_in']]
n=len(W)
def vc(key,top=12,f=lambda v:v):
    c=collections.Counter()
    for r in W:
        if key in r['ip']: c[repr(f(r['ip'][key]))]+=1
    print('--',key,sum(c.values()),'of',n); 
    for v,k in c.most_common(top): print('  ',v,k)
for k in ['mode','output_mode','limit','head_limit','context_lines','context','ignore_case','whole_word','include_hidden','time_budget_ms','multiline','-n','-i','-C','-A','-B','offset']:
    vc(k)
# path classes
c=collections.Counter(path_class(r['ip'].get('path')) for r in W)
print('path class',c)
for pc in ('root','subdir','file','buffer','abs_outside'):
    pass
# workspace
c=collections.Counter(r['ip'].get('workspace') for r in W if 'workspace' in r['ip'])
print('workspace top'); 
for v,k in c.most_common(8): print('  ',v,k)
# split workspace by parent/sub
print('workspace present parent/sub', sum(1 for r in W if 'workspace' in r['ip'] and r['parent']), sum(1 for r in W if 'workspace' in r['ip'] and not r['parent']))
# glob shapes
gc=collections.Counter(); gex={}
for r in W:
    g=r['ip'].get('glob')
    if g is None: continue
    shapes=[]
    if isinstance(g,list): shapes.append('array(len%d)'%len(g)); gl=g
    else: shapes.append('string'); gl=[g]
    for x in gl:
        if not isinstance(x,str): shapes.append('nonstr'); continue
        if '{' in x: shapes.append('brace')
        if '**' in x: shapes.append('doublestar')
        if x.startswith('/'): shapes.append('absolute')
        if x.startswith('!'): shapes.append('negation')
        if ',' in x and '{' not in x: shapes.append('comma_no_brace')
        if x.startswith('**/'): shapes.append('leading**/')
        elif '/' in x: shapes.append('has_slash')
        if re.fullmatch(r'\*\.[A-Za-z0-9]+',x): shapes.append('simple *.ext')
    for s in set(shapes):
        gc[s]+=1; gex.setdefault(s,(r['id'],g))
ng=sum(1 for r in W if 'glob' in r['ip'])
print('glob shapes of',ng)
for s,k in gc.most_common(): print('  ',s,k,gex[s])
# mode x output_mode cross
c=collections.Counter((r['ip'].get('mode'),r['ip'].get('output_mode')) for r in W if 'mode' in r['ip'] or 'output_mode' in r['ip'])
print('mode x output_mode',c)
# time_budget values
print([ (r['id'],r['ip']['time_budget_ms']) for r in W if 'time_budget_ms' in r['ip']])
# top limits split and effective
# pattern len
pl=[len(r['ip']['pattern']) for r in W if isinstance(r['ip'].get('pattern'),str)]
print('pattern len p50/p90/p99/max',pct(pl,50),pct(pl,90),pct(pl,99),max(pl))
# ctx value x limit
