import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from base_common import *
c=conn()
print("bg check:", c.execute(f"select count(*), sum(input_json like '%run_in_background%') from tool_calls where id<={MAXID} and tool_name='run_command' and emitted_output_id like '@bg_%'").fetchone()[:])
print("run_in_background in input anywhere (run_command):", c.execute(f"select count(*), sum(overflowed) from tool_calls where id<={MAXID} and tool_name='run_command' and input_json like '%\"run_in_background\":true%'").fetchone()[:])
rows=c.execute(f"select id,tool_name,outcome,err_family,error_msg,agent_id,session_id from tool_calls where id<={MAXID} and outcome<>'success'").fetchall()
E=len(rows); print("errors",E)
print("outcome",collections.Counter(r['outcome'] for r in rows))
H='— hint:'
hint=[r for r in rows if r['error_msg'] and H in r['error_msg']]
print("with '— hint:'",len(hint),f"{100*len(hint)/E:.1f}%","recoverable with hint",sum(r['outcome']=='recoverable_error' for r in hint),"hard with hint",sum(r['outcome']=='error' for r in hint))
print("error_msg null/empty",sum(1 for r in rows if not r['error_msg']))
alt=[r for r in rows if r['error_msg'] and ('hint:' in r['error_msg'] or 'Hint' in r['error_msg']) and H not in r['error_msg']]
print("other 'hint:' variant w/o em-dash form",len(alt), [r['error_msg'][:100] for r in alt[:3]])
# hint text distinct
ht=collections.Counter(r['error_msg'].split(H,1)[1].strip() for r in hint)
print("distinct hint texts",len(ht),"top share: hints appearing >=10 times:",sum(1 for v in ht.values() if v>=10),"singletons",sum(1 for v in ht.values() if v==1))
print("hint texts normalised (digits->#, quotes content trimmed) distinct:",len({re.sub(r'\d+','#',k)[:120] for k in ht}))
print("top 10 hint texts:")
for k,v in ht.most_common(10): print(v,k[:140])
# by tool: error w/ hint share
bt=collections.defaultdict(lambda: collections.Counter())
for r in rows:
    d=bt[r['tool_name']]; d['err']+=1; d['hint']+= bool(r['error_msg'] and H in r['error_msg']); d['hard']+= r['outcome']=='error'
print("| tool | errors | with hint | hint% | hard |")
for k,d in sorted(bt.items(), key=lambda x:-x[1]['err']): print(f"| {k} | {d['err']} | {d['hint']} | {100*d['hint']/d['err']:.0f} | {d['hard']} |")
# no hint recov errors
nh=[r for r in rows if not (r['error_msg'] and H in r['error_msg'])]
print("errors w/o hint",len(nh),"by tool",collections.Counter(r['tool_name'] for r in nh).most_common(8))
print("hard errors:",collections.Counter((r['tool_name'],(r['error_msg'] or '')[:70]) for r in rows if r['outcome']=='error').most_common(12))
# err_family
fam=collections.Counter(r['err_family'] for r in rows)
nulls=[r for r in rows if r['err_family'] is None]
print("\nerr_family distinct",len(fam)-(1 if None in fam else 0),"NULL",len(nulls),f"{100*len(nulls)/E:.1f}%")
print("NULL by tool",collections.Counter(r['tool_name'] for r in nulls).most_common(8),"NULL by outcome",collections.Counter(r['outcome'] for r in nulls))
pf=collections.Counter((r['error_msg'] or '')[:60] for r in nulls)
print("NULL top 60-char prefixes:")
for k,v in pf.most_common(15): print(v,repr(k))
print("\n| err_family | n | share% of errors | tools | hard n |")
for k,v in fam.most_common(60):
    tl=collections.Counter(r['tool_name'] for r in rows if r['err_family']==k).most_common(3)
    print(f"| {k} | {v} | {100*v/E:.1f} | {', '.join(f'{a}:{b}' for a,b in tl)} | {sum(1 for r in rows if r['err_family']==k and r['outcome']=='error')} |")
