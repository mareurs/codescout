import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_enrich import *
c=conn()
cur=c.execute("select id,tool_name,session_id,agent_id,input_json,output_json from tool_calls where id<=? order by id",(MAXID,))
last={}; pairs=0; same=0; same_pat=0; n=0; samez=0; ids=[]
seqprev={}
for id_,tn,sid,aid,ij,oj in cur:
    key=(sid,aid)
    prev=seqprev.get(key)
    if tn=='grep' and ij:
        n+=1
        if prev and prev[0]=='grep' and prev[1]:
            pj=inp(prev[1]); cj=inp(ij)
            if pj==cj:
                same+=1; ids.append(id_)
                if prev[2] and out_text(prev[2]).strip().startswith('0 matches'): samez+=1
    seqprev[key]=(tn,ij,oj)
print('grep rows with input',n,'immediate repeat of previous call (same principal, grep, identical parsed input)',same,'of which previous was a zero',samez,ids[:10])
# repeat within next 3 calls identical (non-adjacent)
