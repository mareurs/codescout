import collections, statistics
R='/home/marius/work/claude/codescout/.codescout/'
L=[l.rstrip('\n').split('\t') for l in open(R+'usage-lock-holds.log')]
print('lock-holds lines',len(L),'first',L[0][0],'last',L[-1][0])
print('field counts',collections.Counter(len(x) for x in L))
k=collections.defaultdict(list)
for x in L: k[x[3]].append(int(x[4]))
for kind,v in k.items():
    v.sort(); print(kind,len(v),'p50',v[len(v)//2],'p90',v[int(len(v)*.9)],'max',v[-1],'sum_s',round(sum(v)/1000,1))
d=collections.Counter(x[0][:10] for x in L); print('by day',sorted(d.items()))
c=collections.Counter((x[3],x[5].split(' ')[0]) for x in L if x[3]=='insert'); print('insert by tool',c.most_common(8))
print('distinct pids',len({x[1] for x in L}))
print('holds >=1000ms:',sum(1 for x in L if int(x[4])>=1000),' >=5000:',sum(1 for x in L if int(x[4])>=5000))
print('backfill samples'); 
for x in L:
    if x[3]=='backfill': print(x); break
D=[l.rstrip('\n').split('\t') for l in open(R+'usage-dropped-rows.log')]
print('\ndropped lines',len(D),'first',D[0][0],'last',D[-1][0],'field counts',collections.Counter(len(x) for x in D))
print('by day',sorted(collections.Counter(x[0][:10] for x in D).items()))
print('by tool',collections.Counter(x[1] for x in D).most_common(10))
print('by error',collections.Counter(x[3][:50] if len(x)>3 else '' for x in D).most_common(5))
w=[int(x[6]) for x in D if len(x)>=7 and x[6].isdigit()]
print('wait_ms n',len(w), 'p50',sorted(w)[len(w)//2] if w else None,'min',min(w) if w else None,'max',max(w) if w else None)
print('sample',D[-1])
print('roots',collections.Counter(x[2].split('/.worktrees/')[0][-45:] if '/.worktrees/' in x[2] else x[2][-45:] for x in D).most_common(6))
