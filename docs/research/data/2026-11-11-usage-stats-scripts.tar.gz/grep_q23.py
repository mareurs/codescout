import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_enrich import *
IDENT=re.compile(r'^[A-Za-z_][A-Za-z0-9_]*$')
QUAL=re.compile(r'^[A-Za-z_][\w:.\-/]*$')
PATHLIKE=re.compile(r'^[\w.\-*/]+$')
EXT=re.compile(r'\.(rs|md|toml|json|py|sh|ts|js|yml|yaml|txt|mjs|jsonl|db|lock|rst)$')
def has_unescaped_pipe(p):
    inbr=False; i=0
    depth=0
    while i<len(p):
        c=p[i]
        if c=='\\': i+=2; continue
        if c=='[': inbr=True
        elif c==']': inbr=False
        elif c=='|' and not inbr: return True
        i+=1
    return False
META=set('^$\\[](){}+*?')
def has_meta(p):
    return any(c in META for c in p)
def classify(p):
    if not isinstance(p,str): return 'nonstring'
    if len(p)>150: return 'very_long(>150)'
    if has_unescaped_pipe(p):
        q=re.sub(r'\\[bB]','',p); q=re.sub(r'\\[^A-Za-z0-9]','',q)
        return 'alternation_literal' if not has_meta(q) else 'alternation_regex'
    if has_meta(p): return 'regex_meta'
    if ' ' in p.strip() or '\t' in p: return 'multiword_text'
    if IDENT.match(p): return 'identifier'
    if '/' in p and PATHLIKE.match(p): return 'path_like'
    if EXT.search(p) and PATHLIKE.match(p): return 'path_like'
    if QUAL.match(p): return 'qualified_identifier'
    return 'other_literal'
if __name__=='__main__':
    rows=enrich()
    W=[r for r in rows if r['has_in']]
    for r in W: r['pc']=classify(r['ip'].get('pattern')); r['pthc']=path_class(r['ip'].get('path'))
    print('classification of',len(W))
    cl=collections.defaultdict(list)
    for r in W: cl[r['pc']].append(r)
    print('class | n | share | n_with_out | zero% (of out) | overflowed% (all) | capped% | lat p50 | p90 | bytes p50 | p90')
    for k,rs in sorted(cl.items(),key=lambda x:-len(x[1])):
        wo=[r for r in rs if r['out']['has_out']]
        z=sum(r['out']['zero'] for r in wo)
        ov=sum(1 for r in rs if r['overflowed'])
        cap=sum(1 for r in wo if r['out'].get('capped'))
        lat=[r['latency'] for r in rs if r['latency'] is not None]
        by=[r['out']['bytes'] for r in wo]
        print(f"{k} | {len(rs)} | {100*len(rs)/len(W):.1f}% | {len(wo)} | {100*z/max(1,len(wo)):.1f}% ({z}) | {100*ov/len(rs):.1f}% ({ov}) | {100*cap/max(1,len(wo)):.1f}% | {pct(lat,50):.0f} | {pct(lat,90):.0f} | {pct(by,50):.0f} | {pct(by,90):.0f}")
    for k in cl:
        print('EXAMPLES',k,[r['ip']['pattern'][:70] for r in cl[k][:6]])
    # by parent/sub for multiword count
    for k in ('multiword_text','identifier'):
        print(k,'parent',sum(1 for r in cl[k] if r['parent']),'sub',sum(1 for r in cl[k] if not r['parent']))
    # crude filter reproduction: contains space and no | ? 
    crude=[r for r in rows if r['has_in'] and isinstance(r['ip'].get('pattern'),str) and ' ' in r['ip']['pattern']]
    print('any-space patterns',len(crude))
    print('whole corpus rows incl no-input', len(rows))
