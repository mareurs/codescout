import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_enrich import *
rows=enrich()
c=conn()
cur=c.execute("select id,tool_name,session_id,agent_id,outcome,substr(input_json,1,200),err_family from tool_calls where id<=? order by id",(MAXID,))
seqs=collections.defaultdict(list)
for t in cur: seqs[(t[2],t[3])].append(t)
pos={}
for k,s in seqs.items():
    for i,t in enumerate(s): pos[t[0]]=(k,i)
E=[r for r in rows if r['fam']=='param_not_applied']
print('grep param_not_applied rows',len(E),'(grep rows with err_family=param_not_applied)')
print('error text kinds',collections.Counter(re.sub(r"'[^']*' was not applied","'X' was not applied",(r['err'] or '')[:70]) for r in E).most_common(4))
print('values',collections.Counter(re.search(r"'(\w+)' was not applied",r['err'] or '').group(1) if re.search(r"'(\w+)' was not applied",r['err'] or '') else None for r in E))
nxt=collections.Counter(); rec=collections.Counter(); ex=[]
for r in E:
    k,i=pos[r['id']]; s=seqs[k]; n3=s[i+1:i+4]
    nxt[n3[0][1] if n3 else 'END']+=1
    ok=None
    for t in n3:
        if t[1]=='grep' and t[4]=='success': ok='recovered_with_grep_within3'; break
    if ok is None and n3 and any(t[1]=='run_command' for t in n3): ok='routed_to_run_command'
    if ok is None: ok='other/none'
    rec[ok]+=1
    if i+1<len(s) and s[i+1][1]=='grep' and len(ex)<3: ex.append((r['id'],r['ij'][:140],s[i+1][5][:140],s[i+1][4]))
print('next tool',nxt.most_common(6)); print('recovery',rec)
for e in ex: print(e)
# first-seen date and parent/sub
print('dates',min(r['called_at'] for r in E),max(r['called_at'] for r in E),'parent',sum(r['parent'] for r in E),'sub',sum(not r['parent'] for r in E))
# successful rows carrying param-corrected note
W=[r for r in rows if r['out'].get('warns') and any('is not a parameter of grep' in w for w in r['out']['warns'])]
print('rows with success note "X is not a parameter of grep - corrected to Y"',len(W))
print(collections.Counter(re.search(r"'([^']+)' is not a parameter of grep — corrected to '([^']+)'",w).groups() for r in W for w in r['out']['warns'] if re.search(r"'([^']+)' is not a parameter of grep — corrected to '([^']+)'",w)).most_common(8))
# all native-style params used: output_mode value=content -> works? 
oc=collections.Counter()
for r in rows:
    if r['has_in'] and 'output_mode' in r['ip']:
        oc[(r['ip']['output_mode'],r['outcome'],bool(r['out'].get('warns')))]+=1
print(oc.most_common(12))
# per-param ignored silently? head_limit, -n etc: rows with those keys and any note
for key in ('head_limit','-n','-i','-C','-A','-B','context','multiline','offset','-o','max_matches'):
    ks=[r for r in rows if r['has_in'] and key in r['ip']]
    noted=sum(1 for r in ks if r['out'].get('warns') and any(("'"+key+"'") in w for w in r['out']['warns']))
    err=sum(1 for r in ks if r['outcome']!='success')
    print(key,len(ks),'noted',noted,'errors',err)
