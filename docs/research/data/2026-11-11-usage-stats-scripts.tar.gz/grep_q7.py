import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_common import *
from grep_shell import *
import pickle, datetime, subprocess
PROJ='/home/marius/work/claude/codescout'
R=load('run_command')
print('run_command rows',len(R),'with input',sum(1 for r in R if r['ij']),'with output',sum(1 for r in R if r['oj']))
calls=[]
for r in R:
    ip=inp(r['ij'])
    if not ip: continue
    cmd=ip.get('command') or ''
    if not cmd or ip.get('interactive'): pass
    # skip my own analysis commands? bound by id already; exclude commands that are mine: those run by this analyst contain grep_ scratch paths
    if 'scratchpad/grep_' in cmd or 'scratchpad/friction' in cmd: continue
    recs=analyze_command(cmd)
    if not recs: continue
    for rc in recs:
        fam=rc['fam']
        if fam=='grep':
            paths=rc['paths']
            if any(p.startswith('@') for p in paths): sub='grep_buffer'
            elif rc['piped'] or not paths: sub='grep_filter'
            elif ('-r' in rc['flags'] or '-R' in rc['flags'] or '--recursive' in rc['flags']) : sub='grep_recursive'
            elif any(p.endswith('/') or os.path.isdir(os.path.join(ip.get('cwd') and os.path.join(PROJ,ip['cwd']) or PROJ,p)) for p in paths): sub='grep_dir_no_r'
            else: sub='grep_files'
        else: sub=fam
        rc['sub']=sub
    calls.append((r,ip,cmd,recs))
print('run_command calls with any search-family segment',len(calls))
fam_priority=['git grep','rg','grep_recursive','grep_dir_no_r','grep_files','find','fd','grep_filter','grep_buffer']
def call_family(recs):
    subs={x['sub'] for x in recs}
    for f in fam_priority:
        if f in subs: return f
fam_calls=collections.defaultdict(list)
for t in calls:
    fam_calls[call_family(t[3])].append(t)
print('call-level family (priority git grep>rg>grep_recursive>...):')
tot_rc=len(R)
print('family | calls | % of all run_command | sessions | parent | sub | with out | ')
for f in fam_priority:
    xs=fam_calls.get(f,[])
    print(f"{f} | {len(xs)} | {100*len(xs)/tot_rc:.1f}% | {len({t[0]['sid'] for t in xs})} | {sum(1 for t in xs if t[0]['aid'] is None)} | {sum(1 for t in xs if t[0]['aid'] is not None)} | {sum(1 for t in xs if t[0]['oj'])}")
pickle.dump([(t[0]['id'],t[0]['sid'],t[0]['aid'],t[0]['called_at'],t[0]['latency'],t[0]['overflowed'],t[2],t[3],bool(t[0]['oj']),(out_text(t[0]['oj']) if t[0]['oj'] else None),t[1].get('cwd')) for t in calls],open('grep_shell_calls.pkl','wb'))
# weekly trend
def week(ca):
    d=datetime.date.fromisoformat(ca[:10]); return (d-datetime.timedelta(days=d.weekday())).isoformat()
allw=collections.Counter(week(r['called_at']) for r in R)
fw=collections.defaultdict(collections.Counter)
for f,xs in fam_calls.items():
    for t in xs: fw[f][week(t[0]['called_at'])]+=1
weeks=sorted(allw)
print('week | run_command total | '+' | '.join(fam_priority))
for w in weeks: print(w,'|',allw[w],'|',' | '.join(str(fw[f][w]) for f in fam_priority))
# grep tool weekly
G=load('grep'); gw=collections.Counter(week(r['called_at']) for r in G)
print('grep tool per week',[ (w,gw[w]) for w in weeks])
