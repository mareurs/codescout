import sys, json, shlex
sys.path.insert(0, "/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad")
import bench_common as b
S = [("S1", "fn clamp_match", "repo"), ("S2", "wall-clock budget", "repo"), ("S3", "Result<Value>", "src"),
     ("S4", "RecoverableError", "repo"), ("S5", "^pub fn", "src"), ("S6", "fn ", "repo")]
jobs = []; local = []
for sid, pat, sk in S:
    sc = b.SCOPES[sk]; p = dict(id=sid, pat=pat, i=False, w=False, pcre=False)
    q = shlex.quote(pat); path = " " + sc["path"] if sc.get("path") else ""
    cmds = {"rg-n": f"rg -n -e {q}{path}", "rg-vimgrep": f"rg --vimgrep -e {q}{path}", "rg-l": f"rg -l -e {q}{path}", "rg-c": f"rg -c -e {q}{path}",
            "gg-n": b.gg_cmd(p, sc)}
    vs = [dict(label=f"{sid}|cs-lines", tool="grep", args=b.cs_args(p, sc)), dict(label=f"{sid}|cs-files", tool="grep", args=b.cs_args(p, sc, "files"))]
    for k, c in cmds.items():
        vs.append(dict(label=f"{sid}|{k}", tool="run_command", args=dict(command=c, effect="read")))
        local.append((sid, k, c))
    jobs.append(dict(variants=vs, repeats=2, warmup=1, drain={f"{sid}|cs-lines": f"{b.SP}/tok/{sid}_cs-lines.json", f"{sid}|cs-files": f"{b.SP}/tok/{sid}_cs-files.json"}))
json.dump(dict(nonce="tok1", settle=20, out=f"{b.SP}/bench_out_tok.json", jobs=jobs), open(f"{b.SP}/bench_spec_tok.json", "w"))
json.dump(local, open(f"{b.SP}/bench_tok_local.json", "w"))
# gate cases
G = [("G1", "rg -n \"fn \" src/ | head -50"), ("G2", "rg -n \"fn \" src/ | wc -l"), ("G3", "rg -n RecoverableError src/ | sort | uniq -c | sort -rn | head"),
     ("G4", "git grep -n -E \"fn \" -- src/ | head -50"), ("G5", "rg -n RecoverableError src/tools/grep.rs && echo ok"), ("G6", "rg -n RecoverableError src/tools/grep.rs ; echo done"),
     ("G7", "grep -rn RecoverableError src/ | head"), ("G8", "rg -n \"fn \" src/ > " + b.SP + "/tok/g8.txt"), ("G9", "rg -l RecoverableError src/"),
     ("G10", "rg --files src/ | head -5"), ("G11", "rg -n -U \"fn clamp_match.*\\n\" src/tools/grep.rs"), ("G12", "grep -rn RecoverableError src/"),
     ("G13", "rg -n -m 3 RecoverableError src/"), ("G14", "git grep -n -E RecoverableError HEAD -- src/tools/grep.rs"), ("G15", "rg -n --stats RecoverableError src/tools/grep.rs"),
     ("G16", "rg -c -e RecoverableError --sort path src/tools")]
gj = [dict(variants=[dict(label=k, tool="run_command", args=dict(command=c, effect="read"))], repeats=0, warmup=1) for k, c in G]
json.dump(dict(nonce="gate1", settle=15, out=f"{b.SP}/bench_out_gate.json", jobs=gj), open(f"{b.SP}/bench_spec_gate.json", "w"))
print(len(jobs), len(gj))
