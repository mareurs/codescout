import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_enrich import *
rows=enrich()
O=[r for r in rows if r['out']['has_out']]
shown=0
for r in O:
    t=r['out']['text']
    if 'Hidden paths' in t and not r['out']['zero'] and shown<2:
        shown+=1; i=t.find('Hidden paths'); print(r['id'],repr(t[max(0,i-200):i+400]))
c=collections.Counter()
for r in O:
    t=r['out']['text']
    for m in re.finditer(r'(Hidden paths[^.]{0,60}|hidden[^.\n]{0,50}were not searched[^.\n]{0,30})',t):
        c[re.sub(r'\d+','N',m.group(0))[:80]]+=1
for k,n in c.most_common(8): print(n,repr(k))
for r in O:
    t=r['out']['text']
    if 'time budget' in t: print('TB',r['id'],r['latency'],r['ij'][:150] if r['ij'] else None, repr(t[:300]))
for r in O:
    t=r['out']['text']
    if 'walk cut' in t: print('WC',r['id'],r['latency'],(r['ij'] or '')[:130], repr(t[t.find('walk cut'):t.find('walk cut')+120]))
lat=[(r['latency'],r['id']) for r in rows if r['latency'] and r['latency']>=15000]
print('lat>=15s',sorted(lat))
