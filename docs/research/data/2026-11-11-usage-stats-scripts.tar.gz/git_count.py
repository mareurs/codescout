#!/usr/bin/env python3
"""Classify git2:: and Command::new("git") lines as prod/test/comment.
Test region = from first line matching '#[cfg(test)]' directly followed (within 2 lines) by 'mod ' to EOF,
or whole file if path is *tests.rs, *_tests.rs, tests/**, declared_member_tests.rs."""
import re, subprocess, sys, collections
ROOT = "/home/marius/work/claude/codescout"
def files(pat):
    out = subprocess.run(["grep", "-rlE", pat, "src", "crates", "tests", "--include=*.rs"], cwd=ROOT, capture_output=True, text=True).stdout.split()
    return out
def test_start(lines):
    for i, l in enumerate(lines):
        if l.strip() == "#[cfg(test)]":
            nxt = " ".join(x.strip() for x in lines[i+1:i+3])
            if re.search(r"\bmod \w+", nxt):
                return i + 1  # 1-indexed line of attribute
    return None
def whole_test(p):
    return p.startswith("tests/") or p.endswith("tests.rs") or p.endswith("_tests.rs") or "/tests/" in p
def classify(pat):
    res = collections.OrderedDict()
    for p in sorted(files(pat)):
        lines = open(f"{ROOT}/{p}", encoding="utf-8", errors="replace").read().split("\n")
        ts = test_start(lines)
        prod = test = comment = 0
        prod_lines = []
        for i, l in enumerate(lines, 1):
            if re.search(pat, l):
                s = l.strip()
                if s.startswith("//"):
                    comment += 1
                elif whole_test(p) or (ts and i >= ts):
                    test += 1
                else:
                    prod += 1
                    prod_lines.append(i)
        res[p] = (prod, test, comment, ts, prod_lines)
    return res
for name, pat in (("git2::", r"git2::"), ("Command::new(\"git\")", r'Command::new\("git"\)')):
    r = classify(pat)
    tp = sum(v[0] for v in r.values()); tt = sum(v[1] for v in r.values()); tc = sum(v[2] for v in r.values())
    print(f"== {name}: files={len(r)} prod={tp} test={tt} comment={tc}")
    for p, (a, b, c, ts, pl) in r.items():
        print(f"  {p}: prod={a} test={b} comment={c} test_start={ts} prod_lines={pl}")
