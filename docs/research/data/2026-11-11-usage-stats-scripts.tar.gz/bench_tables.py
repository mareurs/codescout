import json, sys, statistics as st
sys.path.insert(0, "/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad")
import bench_common as b, bench_summ as bs
SP = b.SP


def q(v, f):
    v = sorted(v); k = (len(v) - 1) * f; lo = int(k); hi = min(lo + 1, len(v) - 1)
    return v[lo] + (v[hi] - v[lo]) * (k - lo)


def hf(path):
    d = json.load(open(path)); out = {}
    for r in d["results"]:
        t = [m["time_wall_clock"]["value"] * 1000 for m in r["measurements"]]
        cpu = [m["time_cpu"]["value"] * 1000 for m in r["measurements"]]
        out[r["name"]] = (st.median(t), min(t), q(t, .9), st.median(cpu))
    return out


def agent(path):
    return {r["label"]: r for r in bs.summ(path)}


def cell(r):
    if r is None:
        return "-"
    return "%.0f / %.0f / %.0f" % (r["lat_med"], r["lat_min"], r["lat_p90"])


def hc(h):
    return "-" if h is None else "%.1f / %.1f / %.1f" % h[:3]


scopes = ["repo", "src", "globrs", "docs", "reg"]
other = {"src": "c", "repo": "c", "globrs": "a", "docs": "a", "reg": "a"}
md = []; flags = []; var = []
for sc in scopes:
    A = agent("%s/timing/t_%s_q.joined.json" % (SP, sc))
    A2 = agent("%s/timing/t_%s_%s.joined.json" % (SP, sc, other[sc]))
    H = hf("%s/hf/hf_%s_q.json" % (SP, sc))
    pats = b.RPATS if sc == "reg" else b.PATS
    md.append("\n#### Scope `%s`\n" % sc)
    md.append("| pat | cs lines med/min/p90 | cs files med/min/p90 | rg via run_command med/min/p90 | git grep via run_command med/min/p90 | rg raw med/min/p90 | git grep raw med/min/p90 | cs-lines / rg-run_command | cs-lines / rg raw |")
    md.append("|---|---|---|---|---|---|---|---|---|")
    for p in pats:
        pid = p["id"]
        f = lambda k: A.get("%s|%s|%s" % (pid, sc, k))
        csl, csf, rgc, ggc = f("cs-lines"), f("cs-files"), f("rg"), f("gg")
        hr, hg = H.get("%s|%s|rg" % (pid, sc)), H.get("%s|%s|gg" % (pid, sc))
        r1 = (csl["lat_med"] / rgc["lat_med"]) if csl and rgc else None
        r2 = (csl["lat_med"] / hr[0]) if csl and hr else None
        name = "%s %s `%s`" % (pid, p["label"], p["pat"])
        if csl is None:
            md.append("| %s | rejected (look-around) | - | %s | %s | %s | %s | - | - |" % (name, cell(rgc), cell(ggc), hc(hr), hc(hg)))
            continue
        md.append("| %s | %s | %s | %s | %s | %s | %s | %.2fx | %.1fx |" % (name, cell(csl), cell(csf), cell(rgc), cell(ggc), hc(hr), hc(hg), r1, r2))
        if r1 > 2:
            flags.append((sc, pid, p["pat"], "cs-lines vs rg(run_command)", round(r1, 2), csl["lat_med"], rgc["lat_med"]))
        if r2 > 2:
            flags.append((sc, pid, p["pat"], "cs-lines vs rg raw", round(r2, 1), csl["lat_med"], round(hr[0], 1)))
        rf = (csf["lat_med"] / rgc["lat_med"]) if csf and rgc else None
        if rf and rf > 2:
            flags.append((sc, pid, p["pat"], "cs-files vs rg(run_command)", round(rf, 2), csf["lat_med"], rgc["lat_med"]))
        for k in ("cs-lines", "cs-files", "rg", "gg"):
            a, b2 = A.get("%s|%s|%s" % (pid, sc, k)), A2.get("%s|%s|%s" % (pid, sc, k))
            if a and b2 and a["lat_med"] and b2["lat_med"]:
                var.append((sc, pid, k, a["lat_med"], b2["lat_med"]))
open(SP + "/bench_tables.md", "w").write("\n".join(md))
json.dump(dict(flags=flags, var=var), open(SP + "/bench_flags.json", "w"))
rel = [abs(a - c) / max(a, c) for _, _, _, a, c in var]
print("tables written; q vs other-batch median rel diff of cell medians: median %.2f over %d cells; >50%% in %d cells" % (st.median(rel), len(rel), sum(1 for r in rel if r > .5)))
print("flags", len(flags))
