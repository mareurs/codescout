#!/bin/bash
# usage: bench_run_batch.sh SCOPE RUN [MAXWAIT_SECS]  -- waits for 1-min load < 12, records load before/after
SP=/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad
scope=$1; run=$2; maxwait=${3:-0}
python3 -I $SP/bench_gen_timing.py $scope $run
waited=0
while [ $waited -lt $maxwait ]; do
  l=$(cut -d" " -f1 /proc/loadavg)
  if awk -v l=$l "BEGIN{exit !(l<12)}"; then break; fi
  sleep 5; waited=$((waited+5))
done
echo "before: $(uptime) waited=${waited}s" > $SP/timing/load_${scope}_${run}.txt
python3 -I $SP/bench_mcp2.py $SP/timing/spec_${scope}_${run}.json
echo "after: $(uptime)" >> $SP/timing/load_${scope}_${run}.txt
python3 -I $SP/bench_collect.py $SP/timing/t_${scope}_${run}.json
cat $SP/timing/load_${scope}_${run}.txt
