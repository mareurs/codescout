import pickle, collections, json
rows=pickle.load(open('lat_rows.pkl','rb'))
# spikes: 250ms bins for lat>=1000, non-run_command, count per bin per tool where count>=8
c=collections.defaultdict(list)
for r in rows:
    if r['tool']!='run_command' and r['lat']>=1000: c[(r['tool'],r['lat']//250)].append(r)
print('spike bins (non-run_command, 250ms bins, n>=6): tool, bin start ms, n, outcomes, date range, #sessions')
for (t,b),l in sorted(c.items(),key=lambda kv:-len(kv[1])):
    if len(l)<6: break
    print(t,b*250,len(l),dict(collections.Counter(r['out'][:4] for r in l)),min(r['ca'] for r in l)[:10],max(r['ca'] for r in l)[:10],len({r['sess'] for r in l}))
w=[r for r in rows if 40000<=r['lat']<=40700]
print('\nrows in [40000,40700]:',len(w),collections.Counter(r['tool'] for r in w),'dates',min(r['ca'] for r in w)[:10],max(r['ca'] for r in w)[:10],'outcomes',collections.Counter(r['out'] for r in w),'sessions',len({r['sess'] for r in w}),'time_s',round(sum(r['lat'] for r in w)/1000))
e=[r for r in rows if r['tool']=='edit_code' and 15000<=r['lat']<=19000]
print('edit_code 15-19s',len(e),collections.Counter(r['fam'] for r in e),collections.Counter(r['out'] for r in e),min(r['ca'] for r in e)[:10],max(r['ca'] for r in e)[:10]); 
for r in e[:2]: print(r['err'][:200])
w5=[r for r in rows if r['tool']!='run_command' and 5000<=r['lat']<=5120]
print('rows in [5000,5120] non-rc',len(w5),collections.Counter(r['tool'] for r in w5),collections.Counter(r['fam'] for r in w5).most_common(4))
