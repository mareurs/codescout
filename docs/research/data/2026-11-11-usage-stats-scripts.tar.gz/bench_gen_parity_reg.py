import sys, json
sys.path.insert(0, "/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad")
import bench_common as b
jobs = []
for p in b.RPATS:
    if p["pcre"]: continue
    a = b.cs_args(p, b.SCOPES["reg"], "files"); a["time_budget_ms"] = 300000
    lab = f"{p[chr(105)+chr(100)]}|reg|cs-files-bigbudget"
    jobs.append(dict(variants=[dict(label=lab, tool="grep", args=a)], repeats=0, warmup=1, drain={lab: f"{b.SP}/parity/cs_{p[chr(105)+chr(100)]}_reg.json"}))
json.dump(dict(nonce="parreg", settle=30, out=f"{b.SP}/bench_out_parity_reg.json", jobs=jobs), open(f"{b.SP}/bench_spec_parity_reg.json", "w"))
print(len(jobs))
