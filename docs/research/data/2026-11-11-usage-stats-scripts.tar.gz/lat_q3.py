import pickle, collections, re, json
rows=pickle.load(open('lat_rows.pkl','rb'))
def pct(v,q):
    v=sorted(v)
    if not v: return 0
    k=(len(v)-1)*q; f=int(k); c=min(f+1,len(v)-1); return v[f]+(v[c]-v[f])*(k-f)
by=collections.defaultdict(list)
for r in rows: by[r['tool']].append(r)
def short(r):
    i=r['inp'] or ''
    return i[:150].replace('\n',' ')
for t in ['librarian','workspace','doc','index','memory','edit_code','symbols','read_file','edit_file','create_file','grep','references','call_graph','tree','get_guide','semantic_search','symbol_at']:
    l=by[t]; n=len(l); k=max(20,n//100) if n>=2000 else min(20,n)
    if t in('librarian','workspace','memory','index'): k=min(n,20)
    top=sorted(l,key=lambda r:-r['lat'])[:k]
    thr=top[-1]['lat']
    print(f"\n=== {t}: n={n}, tail size {k}, threshold>= {thr} ms; tail time {sum(r['lat'] for r in top)/1000:.0f}s = {100*sum(r['lat'] for r in top)/sum(r['lat'] for r in l):.0f}% of tool time")
    print(' outcomes',dict(collections.Counter(r['out'] for r in top)),'overflowed',sum(r['ov'] for r in top))
    print(' sessions',collections.Counter(r['sess'][:8] for r in top).most_common(5),'distinct',len({r['sess'] for r in top}))
    print(' agent(sub)',sum(1 for r in top if r['ag']),'/',k,' roots',collections.Counter(('main' if r['pr'].endswith('/work/claude/codescout') else 'wt/other') for r in top))
    print(' action',collections.Counter(r['action'] for r in top).most_common(6),' has_input',sum(r['has_in'] for r in top))
    for r in top[:(8 if k>8 else k)]:
        print('  ',r['id'],r['ca'][5:16],r['lat'],r['out'][:4],'gap',round(r['gap']),'|',short(r))
