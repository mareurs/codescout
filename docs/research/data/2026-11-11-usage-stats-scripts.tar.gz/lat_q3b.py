import pickle, collections, re, json, bisect, datetime as dt
rows=pickle.load(open('lat_rows.pkl','rb'))
def pct(v,q):
    v=sorted(v)
    if not v: return 0
    k=(len(v)-1)*q; f=int(k); c=min(f+1,len(v)-1); return v[f]+(v[c]-v[f])*(k-f)
P=lambda s: dt.datetime.strptime(s[:23],'%Y-%m-%d %H:%M:%S.%f')
rf=[r for r in rows if r['tool']=='read_file']
print('read_file n',len(rf),'lat bucket counts:')
for lo,hi in [(0,1),(1,3),(3,10),(10,33),(33,100),(100,1000),(1000,1e9)]:
    print(f' [{lo},{hi})',sum(1 for r in rf if lo<=r['lat']<hi))
# kind: buffer ref vs file vs md heading vs json
def rkind(r):
    i=r['inp'] or ''
    try: d=json.loads(r['inp']) if r['inp'] and r['inp'].endswith('}') else {}
    except: d={}
    p=d.get('path') or r['path'] or ''
    if p.startswith('@'): return 'buffer-ref'
    if 'heading' in d or 'headings' in d: return 'md-heading'
    if p.endswith('.md'): return 'md-whole/map'
    if p.endswith('.rs'): return 'rs'
    if p.endswith('.json') or 'json_path' in d: return 'json'
    if p=='' : return 'no-input'
    return 'other'
bk=collections.defaultdict(list)
for r in rf: bk[rkind(r)].append(r['lat'])
print('read_file by kind: n p50 p90 p99 max')
for k,v in bk.items(): print(' ',k,len(v),round(pct(v,.5)),round(pct(v,.9)),round(pct(v,.99)),max(v))
# system-stall: for rf with lat>=100, count other rows (different tool) completing within +-2s having lat>=1000 or gap>=1000
cas=[P(r['ca']) for r in rows]
slow=[r for r in rf if r['lat']>=100]
hit=0
for r in slow:
    t=P(r['ca']); i=bisect.bisect_left(cas,t-dt.timedelta(seconds=3)); 
    ok=False
    while i<len(rows) and cas[i]<=t+dt.timedelta(seconds=3):
        o=rows[i]
        if o['id']!=r['id'] and o['tool']!='run_command' and (o['gap']>=1000) : ok=True;break
        i+=1
    hit+=ok
print('read_file lat>=100:',len(slow),' of which a non-rc row within +-3s has gap>=1000:',hit)
# baseline: fraction of random read_file rows lat<100 with same condition
import random
random.seed(1)
fast=random.sample([r for r in rf if r['lat']<100],2000); hit2=0
for r in fast:
    t=P(r['ca']); i=bisect.bisect_left(cas,t-dt.timedelta(seconds=3)); ok=False
    while i<len(rows) and cas[i]<=t+dt.timedelta(seconds=3):
        o=rows[i]
        if o['id']!=r['id'] and o['tool']!='run_command' and o['gap']>=1000: ok=True;break
        i+=1
    hit2+=ok
print('baseline fast read_file (2000 sample) same condition:',hit2)
print('rf lat>=100 outcomes',collections.Counter(r['out'] for r in slow),'errfam',collections.Counter(r['fam'] for r in slow).most_common(5))
print('rf lat>=100 by root', collections.Counter('main' if r['pr'].endswith('/work/claude/codescout') else 'other' for r in slow))
print('rf slow day',collections.Counter(r['ca'][:10] for r in slow).most_common(6))
