import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_common import *
import pickle, subprocess, os
PROJ='/home/marius/work/claude/codescout'; HOME='/home/marius'
res=pickle.load(open('grep_shell_res.pkl','rb'))
def pcre_look(p): return bool(p) and bool(re.search(r'\(\?<[=!]|\(\?[=!]|\\[1-9]|\(\?>|\\K',p))
IDENT=re.compile(r'^(?:(?:pub(?:\([a-z]+\))?\s+)?(?:async\s+)?(?:fn|struct|enum|trait|impl|type|const|static|mod|def|class|interface)\s+)?[A-Za-z_]\w*\(?$')
def abspaths(rec,cmd,cwd):
    base=os.path.join(PROJ,cwd) if cwd and not cwd.startswith('/') else (cwd or PROJ)
    m=re.search(r'(?:^|&&|;)\s*cd\s+([^\s;&|]+)',cmd)
    if m and not cmd.lstrip().startswith('git -C'):
        d=m.group(1).strip('"\''); d=d.replace('~',HOME,1) if d.startswith('~') else d
        base=d if d.startswith('/') else os.path.join(base,d)
    m2=re.search(r'git\s+-C\s+(\S+)',cmd)
    if m2: base=m2.group(1).strip('"\'')
    out=[]
    for p in rec['paths']:
        if p.startswith(':') or p.startswith('!'): continue
        if any(ch in p for ch in '*?[{'): continue
        if p.startswith('~'): p=HOME+p[1:]
        out.append(p if p.startswith('/') else os.path.normpath(os.path.join(base,p)))
    return out
cand=set(); items=[]
for fam in ['git grep','rg','grep_recursive','grep_files','find']:
    for (id_,aid,rec,cmd,hasout,text,ov,lat,cwd,sid) in res[fam]:
        ap=abspaths(rec,cmd,cwd); items.append((fam,id_,aid,rec,cmd,ap,sid))
        for a in ap:
            if a.startswith(PROJ+'/'): cand.add(os.path.relpath(a,PROJ))
p=subprocess.run(['git','check-ignore','--stdin'],input='\n'.join(sorted(cand)),capture_output=True,text=True,cwd=PROJ)
ign={x for x in p.stdout.split('\n') if x}
def is_ign(rel): return rel in ign or any(rel.startswith(x.rstrip('/')+'/') for x in ign)
def hidden(rel): return any(s.startswith('.') and s not in ('.','..') for s in rel.split('/'))
cat=collections.defaultdict(collections.Counter); ex={}
tgt=collections.defaultdict(collections.Counter)
for fam,id_,aid,rec,cmd,ap,sid in items:
    fl=set(rec['flags']); pat=rec['pattern']
    who='parent' if aid is None else 'sub'
    # target classes
    tcs=set()
    if not ap: tcs.add('cwd default (project root)')
    for a in ap:
        if not (a.startswith(PROJ+'/') or a==PROJ):
            if '/.cache/cc-tmp' in a or a.startswith('/tmp') or 'scratch' in a: tcs.add('outside repo: scratch/tmp/cache')
            elif a.startswith(HOME+'/.claude'): tcs.add('outside repo: ~/.claude* (sessions/config)')
            elif a.startswith(HOME+'/work/claude/'): tcs.add('outside repo: sibling repo/worktree')
            else: tcs.add('outside repo: other')
        else:
            rel=os.path.relpath(a,PROJ)
            if is_ign(rel): tcs.add('in repo: gitignored path')
            elif hidden(rel): tcs.add('in repo: hidden dir (not gitignored)')
            else: tcs.add('in repo: visible')
    for t in tcs: tgt[fam][t]+=1
    # servability, exclusive priority
    if fam=='git grep' and rec.get('revs'): c='A rev search (git grep <rev>): grep tool has no revision param'
    elif fl&{'-P','--pcre2'} and pcre_look(pat): c='B PCRE look-around/backref: Rust-regex grep tool cannot'
    elif fl&{'-U','--multiline','-z'}: c='C multiline: grep tool is line-based (refuses multiline)'
    elif fl&{'--no-ignore','-u','--no-ignore-vcs','--no-index','--untracked'}: c='D lifts gitignore: grep tool cannot lift gitignore'
    elif fam=='find' and any(f in fl for f in ('-mtime','-newer','-newermt','-mmin','-size','-exec','-delete','-printf','-ls','-empty','-perm','-user')): c='E find by time/size/exec/printf: no tool equivalent'
    elif fam=='find': c='F find by name/type/path only: nearest is tree/grep mode=files, not a file-name search'
    elif fam=='rg' and '--files' in fl: c='G rg --files (file listing): no grep equivalent'
    elif fl&{'-o','--only-matching','-v','--invert-match'} or (fam=='rg' and fl&{'-r','--json','--stats'}): c='H output form (-o/-v/-r/--json): not offered'
    elif any(t.startswith('in repo: gitignored') for t in tcs): c='I target in gitignored path: tool prunes via gitignore'
    elif any(t.startswith('outside repo') for t in tcs): c='J target outside repo (abs path): grep(path=abs) can serve, if not denied'
    elif pat and IDENT.match(pat.strip()) and fam!='find': c='K bare identifier/definition regex: symbols/references/grep serve'
    else: c='L plain regex, in-repo visible target: grep tool serves (flags -n -i -E -l -c -A/-B/-C map to context_lines/ignore_case/mode)'
    cat[fam][c]+=1; cat[fam][c+'|'+who]+=0
    ex.setdefault((fam,c),(id_,cmd[:140].replace('\n',' ')))
FAMS=['git grep','rg','grep_recursive','grep_files','find']
print('TARGETS (a call can hit several classes)')
for fam in FAMS:
    n=len(res[fam]); print('==',fam,n); 
    for c,v in tgt[fam].most_common(): print(f'   {c}: {v} ({100*v/n:.0f}%)')
print('\nSERVABILITY (exclusive; heuristic)')
tot=collections.Counter()
for fam in FAMS:
    n=len(res[fam]); print('==',fam,n)
    for c,v in sorted(((c,v) for c,v in cat[fam].items() if '|' not in c),key=lambda x:-x[1]):
        if v: print(f'   {v} ({100*v/n:.0f}%) {c}'); tot[c]+=v
print('TOTAL over the 5 families',sum(tot.values()))
for c,v in tot.most_common(): print(f'   {v} ({100*v/sum(tot.values()):.0f}%) {c}')
for (f,c),e in ex.items(): print('EX',f,c[:30],e)
