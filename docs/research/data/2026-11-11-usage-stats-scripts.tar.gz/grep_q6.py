import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_enrich import *
from grep_q23 import classify
import random
c=conn()
cur=c.execute("select id,tool_name,session_id,agent_id,input_json,outcome from tool_calls where id<=? order by id",(MAXID,))
seqs=collections.defaultdict(list)
for id_,tn,sid,aid,ij,oc in cur:
    seqs[(sid,aid)].append((id_,tn,ij or '',oc))
rows=enrich(); G={r['id']:r for r in rows}
def norm(p):
    if not p: return None
    if p.startswith(PROJ+'/'): p=p[len(PROJ)+1:]
    return p.lstrip('./') if p.startswith('./') else p
EDIT={'edit_file','edit_code','create_file'}
NAV={'read_file','symbols','symbol_at','edit_file','edit_code','references','call_graph'}
def hitfiles(r):
    b=r['out'].get('body') or ''
    fs=set()
    for l in b.split('\n'):
        m=re.match(r'^\s{0,2}(\S.*?) \((\d+)\)$',l)
        if m: fs.add(norm(m.group(1)))
    return fs
stats=collections.Counter(); N=0
nextc=collections.Counter()
rep_ident=0; rep_pairs=0
ident_rows=[]
for key,seq in seqs.items():
    for i,(id_,tn,ij,oc) in enumerate(seq):
        if tn!='grep' or id_ not in G: continue
        r=G[id_]
        if not r['has_in']: continue
        N+=1
        nxt=seq[i+1:i+4]
        nextc[nxt[0][1] if nxt else 'END']+=1
        ip=r['ip']; P=ip.get('pattern')
        # immediate repeat: same input exactly as the previous call of same tool by this principal
        if i>0 and seq[i-1][1]=='grep' and seq[i-1][2]==ij: stats['immediate_repeat_identical_input']+=1
        if i>0 and seq[i-1][1]=='grep':
            pi=inp(seq[i-1][2]) or {}
            if pi.get('pattern')==P: stats['same_pattern_as_previous_call']+=1
        if r['out'].get('zero') or not r['out'].get('has_out'): pass
        hf=hitfiles(r) if r['out'].get('has_out') and not r['out']['zero'] else set()
        if hf: stats['nonzero_with_parsed_files']+=1
        acted=False
        for (nid,ntn,nij,noc) in nxt:
            if ntn in NAV:
                nip=inp(nij) or {}
                np_=norm(nip.get('path') or nip.get('file_path'))
                if np_ and (np_ in hf or any(np_.endswith('/'+h) or h.endswith('/'+np_) for h in hf)): acted=True
        if hf and acted: stats['acted_on_hit_file_next3']+=1
        # kinds in next 3
        tools3=[t for (_,t,_,_) in nxt]
        if hf:
            if any(t in ('read_file',) for t in tools3): pass
        if 'run_command' in tools3 and any(re.search(r'\b(grep|rg)\b',(inp(x[2]) or {}).get('command','')) for x in nxt if x[1]=='run_command'): stats['next3_has_run_command_grep']+=1
        # narrower second grep: next grep related with deeper path or added glob
        for (nid,ntn,nij,noc) in nxt:
            if ntn=='grep':
                nip=inp(nij) or {}
                if nip.get('pattern')==P and (nip.get('path'),nip.get('glob'))!=(ip.get('path'),ip.get('glob')):
                    stats['next3_same_pattern_scope_changed']+=1; break
        for (nid,ntn,nij,noc) in nxt:
            if ntn=='grep' and (inp(nij) or {}).get('pattern')==P: stats['next3_same_pattern_any']+=1; break
        cl=classify(P)
        if cl=='identifier':
            ident_rows.append((key,i,P,r))
            stats['identifier_greps']+=1
            ntools=[t for (_,t,_,_) in seq[i+1:i+4]]
            for (nid,ntn,nij,noc) in seq[i+1:i+11]:
                if ntn in ('references','call_graph') and P in nij: stats['ident_followed_by_refs_or_callgraph_same_name_10']+=1; break
            for (nid,ntn,nij,noc) in seq[i+1:i+4]:
                if ntn in ('references','call_graph') and P in nij: stats['ident_followed_by_refs_or_callgraph_same_name_3']+=1; break
            for (nid,ntn,nij,noc) in seq[i+1:i+4]:
                if ntn=='symbols' and P in nij: stats['ident_followed_by_symbols_same_name_3']+=1; break
# edit within 20 for identifier greps vs placebo
random.seed(11)
idents=[p for (_,_,p,_) in ident_rows]
def edit_hit(seq,i,tok,win=20):
    for (nid,ntn,nij,noc) in seq[i+1:i+1+win]:
        if ntn in ('edit_file','edit_code') and tok in nij: return True
    return False
def any_edit(seq,i,win=20):
    return any(t in ('edit_file','edit_code') for (_,t,_,_) in seq[i+1:i+1+win])
real=sum(edit_hit(seqs[k],i,p) for (k,i,p,_) in ident_rows)
plac=0; rep=20
for _ in range(rep):
    plac+=sum(edit_hit(seqs[k],i,random.choice(idents)) for (k,i,p,_) in ident_rows)
anyed=sum(any_edit(seqs[k],i) for (k,i,p,_) in ident_rows)
# base rate any edit in next 20 over all calls of principals having >=1 grep
base_n=0; base_e=0
for key,seq in seqs.items():
    for i in range(len(seq)):
        base_n+=1; base_e+=any_edit(seq,i)
print('grep rows with input analysed',N)
print('next call tool after grep',nextc.most_common(8))
for k,v in stats.items(): print(k,v)
print('identifier greps',len(ident_rows),'edit of same identifier within 20:',real,'(%.1f%%)'%(100*real/len(ident_rows)),'placebo (random other identifier) mean',plac/rep,'(%.1f%%)'%(100*plac/rep/len(ident_rows)))
print('any edit within 20 after identifier grep',anyed,'(%.1f%%)'%(100*anyed/len(ident_rows)),'; base any-edit-in-next-20 over all calls %.1f%% of %d'%(100*base_e/base_n,base_n))
# same for all grep patterns: any edit within 20
allg=[(k,i) for k,seq in seqs.items() for i,(id_,tn,ij,oc) in enumerate(seq) if tn=='grep']
print('any edit within 20 after ANY grep %.1f%% of %d'%(100*sum(any_edit(seqs[k],i) for k,i in allg)/len(allg),len(allg)))
