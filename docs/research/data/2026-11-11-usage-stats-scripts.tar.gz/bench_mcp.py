#!/usr/bin/env python3
"""Minimal MCP stdio driver: spawns `codescout start -p ROOT`, runs jobs from a JSON spec.
spec: {"jobs":[{"label":..,"tool":..,"args":{..},"repeats":N,"warmup":1}], "out":path}
Records client wall ms + response bytes (+ whether it overflowed) per call."""
import re, json, subprocess, sys, time, os, select

ROOT = "/home/marius/work/claude/codescout"
spec = json.load(open(sys.argv[1]))
p = subprocess.Popen(["/home/marius/.cargo/bin/codescout", "start", "-p", ROOT] + (["--debug"] if spec.get("debug") else []), cwd=ROOT,
                     stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, bufsize=0)
_id = 0
buf = b""
def send(obj):
    p.stdin.write((json.dumps(obj) + "\n").encode())
    p.stdin.flush()
def recv_until(rid, timeout=120):
    global buf
    end = time.time() + timeout
    while time.time() < end:
        while b"\n" in buf:
            line, buf = buf.split(b"\n", 1)
            if not line.strip():
                continue
            try:
                m = json.loads(line)
            except Exception:
                continue
            if m.get("id") == rid and ("result" in m or "error" in m):
                return m
        r, _, _ = select.select([p.stdout], [], [], 1.0)
        if r:
            d = os.read(p.stdout.fileno(), 1 << 20)
            if not d:
                raise SystemExit("server closed")
            buf += d
    raise SystemExit("timeout waiting for %s" % rid)
def call(method, params):
    global _id
    _id += 1
    send({"jsonrpc": "2.0", "id": _id, "method": method, "params": params})
    return recv_until(_id)

call("initialize", {"protocolVersion": "2024-11-05", "capabilities": {}, "clientInfo": {"name": "bench", "version": "0"}})
send({"jsonrpc": "2.0", "method": "notifications/initialized"})
time.sleep(spec.get("settle", 0))
nonce = spec.get("nonce", "x")
call("tools/call", {"name": "run_command", "arguments": {"command": "echo bench_marker_" + nonce, "effect": "read"}})
results = []
for job in spec["jobs"]:
    n = job.get("repeats", 7)
    runs = []
    for i in range(job.get("warmup", 1) + n):
        t0 = time.perf_counter()
        m = call("tools/call", {"name": job["tool"], "arguments": job["args"]})
        dt = (time.perf_counter() - t0) * 1000
        text = ""
        res = m.get("result", {})
        for c in res.get("content", []) if isinstance(res, dict) else []:
            if c.get("type") == "text":
                text += c.get("text", "")
        runs.append({"i": i, "warm": i < job.get("warmup", 1), "wall_ms": round(dt, 1), "bytes": len(text.encode()),
                     "isError": res.get("isError") if isinstance(res, dict) else None})
        if i == 0 or job.get("keep_text"):
            last_text = text
        if job.get("drain") and i == 0:
            mo = re.search(r"@tool_[0-9a-f]+", text)
            if mo:
                call("tools/call", {"name": "run_command", "arguments": {"command": "cat " + mo.group(0) + " > " + job["drain"], "effect": "write"}})
    results.append({"label": job["label"], "tool": job["tool"], "args": job["args"], "runs": runs,
                    "sample_text": last_text if job.get("keep_text", True) else last_text[:600]})
    json.dump({"nonce": nonce, "results": results}, open(spec["out"], "w"))
p.stdin.close()
try:
    p.wait(5)
except Exception:
    p.kill()
