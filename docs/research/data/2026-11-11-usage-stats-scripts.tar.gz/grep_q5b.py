import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_enrich import *
S=load('symbols')
print('symbols rows',len(S))
def row(nm,xs):
    xs=[x for x in xs if x is not None]
    return f"{nm} | {len(xs)} | {pct(xs,50):.0f} | {pct(xs,90):.0f} | {pct(xs,99):.0f} | {max(xs)} | {sum(1 for x in xs if x>=1000)} ({100*sum(1 for x in xs if x>=1000)/len(xs):.1f}%)"
nm=[r for r in S if (inp(r['ij']) or {}).get('name')]
ov=[r for r in S if (inp(r['ij']) or {}).get('path') and not (inp(r['ij']) or {}).get('name')]
print(row('symbols name search',[r['latency'] for r in nm]))
nmp=[r for r in nm if (inp(r['ij']) or {}).get('path')]; nmn=[r for r in nm if not (inp(r['ij']) or {}).get('path')]
print(row('  name + path',[r['latency'] for r in nmp])); print(row('  name, no path (project-wide)',[r['latency'] for r in nmn]))
inc=[r for r in nm if (inp(r['ij']) or {}).get('include_body')]
print(row('  name + include_body',[r['latency'] for r in inc]))
print(row('symbols overview (path only)',[r['latency'] for r in ov]))
print(row('symbols all',[r['latency'] for r in S]))
print('symbols rows with input',sum(1 for r in S if r['ij']),'; calls',len(S))
# grep zero-result time vs symbols
import statistics
