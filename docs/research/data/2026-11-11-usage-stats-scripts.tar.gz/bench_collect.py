#!/usr/bin/env python3
"""Join driver output with usage.db latency_ms by (tool, args) groups, chronologically within a group.
A group whose row count differs from its call count (usage recorder dropped rows) is left unjoined."""
import json, sqlite3, sys
out = json.load(open(sys.argv[1]))
db = sqlite3.connect("file:/home/marius/work/claude/codescout/.codescout/usage.db?mode=ro", uri=True)
mk = db.execute("select id, session_id from tool_calls where tool_name=\"run_command\" and input_json like ? order by id desc limit 1",
                ("{\"command\":\"echo bench_marker_" + out["nonce"] + "%",)).fetchone()
rows = db.execute("select id, tool_name, latency_ms, outcome, input_json from tool_calls where session_id=? and id>? and tool_name in (\"grep\",\"run_command\") order by id", (mk[1], mk[0])).fetchall()
rows = [r for r in rows if not r[4].startswith("{\"command\":\"cat @tool_")]
key = lambda t, a: t + "|" + json.dumps(a, sort_keys=True)
rg = {}
for r in rows:
    try: a = json.loads(r[4])
    except Exception: continue
    rg.setdefault(key(r[1], a), []).append(r)
cg = {}
for rec in out["results"]:
    for run in rec["runs"]:
        cg.setdefault(key(rec["tool"], rec["args"]), []).append(run)
bad = 0; ok = 0
for k, runs in cg.items():
    rr = rg.get(k, [])
    if len(rr) != len(runs):
        bad += len(runs); print("GROUP MISMATCH calls=%d rows=%d %s" % (len(runs), len(rr), k[:100]), file=sys.stderr); continue
    for run, r in zip(runs, rr):
        run["row_id"], run["latency_ms"], run["outcome"] = r[0], r[2], r[3]; ok += 1
json.dump(out, open(sys.argv[1].replace(".json", ".joined.json"), "w"))
print("joined", ok, "unjoined", bad)
