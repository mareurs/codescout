import pickle, collections, json, sqlite3
rows=pickle.load(open('lat_rows.pkl','rb'))
def pct(v,q):
    v=sorted(v)
    if not v: return 0
    k=(len(v)-1)*q; f=int(k); c=min(f+1,len(v)-1); return v[f]+(v[c]-v[f])*(k-f)
def full(r):
    try: return json.loads(r['inp']) if r['inp'] and r['inp'].endswith('}') else {}
    except: return {}
def key(r): return (r['sess'],r['pr'])
LSPT=('references','call_graph','symbol_at','edit_code','symbols','workspace')
def isname(r):
    if r['tool']!='symbols': return True
    return bool(full(r).get('name')) if r['has_in'] else False
print('| tool(subset) | first n | first p50 | first p90 | later n | later p50 | later p90 | penalty p50 | penalty mean |')
print('|---|---|---|---|---|---|---|---|---|')
def report(label,sel):
    seen=set(); F=[];Lt=[]
    for r in rows:
        if not sel(r): continue
        k=key(r)
        if k in seen: Lt.append(r['lat'])
        else: seen.add(k); F.append(r['lat'])
    if not F or not Lt: print('|',label,len(F),'|-|-|',len(Lt),'|-|-|-|-|'); return
    print(f"| {label} | {len(F)} | {pct(F,.5):.0f} | {pct(F,.9):.0f} | {len(Lt)} | {pct(Lt,.5):.0f} | {pct(Lt,.9):.0f} | {pct(F,.5)-pct(Lt,.5):.0f} | {sum(F)/len(F)-sum(Lt)/len(Lt):.0f} |")
for t in ['references','call_graph','symbol_at','edit_code','workspace']:
    report(t,lambda r,t=t:r['tool']==t)
report('workspace activate',lambda r:r['tool']=='workspace' and r['action']=='activate')
report('symbols(name, any)',lambda r:r['tool']=='symbols' and r['has_in'] and bool(full(r).get('name')))
report('symbols(name+path)',lambda r:r['tool']=='symbols' and r['has_in'] and bool(full(r).get('name')) and bool(full(r).get('path')))
report('symbols(path only)',lambda r:r['tool']=='symbols' and r['has_in'] and not full(r).get('name'))
report('edit_code insert',lambda r:r['tool']=='edit_code' and r['action']=='insert')
report('edit_code replace',lambda r:r['tool']=='edit_code' and r['action']=='replace')
# first LSP-using call of ANY of the tools in (session,root)
LS=lambda r: r['tool'] in ('references','call_graph','symbol_at','edit_code') or (r['tool']=='symbols' and r['has_in'] and full(r).get('name') and full(r).get('path'))
report('ANY LSP-class call (refs/cg/sym_at/edit_code/symbols name+path)',LS)
# per-extension for first references/call_graph
print('\nreferences/call_graph/symbol_at by path extension (all calls, p50/p90):')
ext=collections.defaultdict(list)
for r in rows:
    if r['tool'] in ('references','call_graph','symbol_at'):
        p=(full(r).get('path') or '') if r['has_in'] else ''
        e=p.rsplit('.',1)[-1] if '.' in p.split('/')[-1] else ('noext/none' if not p else 'dir')
        ext[(r['tool'],e)].append(r['lat'])
for k,v in sorted(ext.items(),key=lambda kv:-len(kv[1])): print(' ',k,len(v),round(pct(v,.5)),round(pct(v,.9)))
# distribution of first references calls by index within session
# n-th references call per session position
pos=collections.defaultdict(list); cnt=collections.Counter()
for r in rows:
    if r['tool']=='references':
        k=key(r); cnt[k]+=1; pos[min(cnt[k],6)].append(r['lat'])
print('\nreferences by ordinal within (session,root):',{k:(len(v),round(pct(v,.5)),round(pct(v,.9))) for k,v in sorted(pos.items())})
# references around 45000
rf=[r['lat'] for r in rows if r['tool']=='references']
print('references hist (s):',sorted(collections.Counter(min(x//5000*5,60) for x in rf).items()))
print('references in [44000,46500]:',sum(44000<=x<=46500 for x in rf),' [29900,30300]',sum(29900<=x<=30300 for x in rf))
# LSP events
con=sqlite3.connect('file:/home/marius/work/claude/codescout/.codescout/usage.db?mode=ro',uri=True)
print('\nlsp_events (all rows, filtered to snapshot window):')
q="select language,reason,outcome,count(*),group_concat(handshake_ms),group_concat(first_response_ms) from lsp_events where started_at>='2026-10-12 08:00' and started_at<='2026-11-10 22:24' group by 1,2,3"
print('| language | reason | outcome | n | handshake p50 | handshake p90 | first_response n | first_response p50 | first_response p90 | max first_resp |')
print('|---|---|---|---|---|---|---|---|---|---|')
for lang,reason,out,n,hs,fr in con.execute(q):
    H=[int(x) for x in hs.split(',')]; Fr=[int(x) for x in fr.split(',') if x not in ('','None')] if fr else []
    print(f"| {lang} | {reason} | {out} | {n} | {pct(H,.5):.0f} | {pct(H,.9):.0f} | {len(Fr)} | {pct(Fr,.5):.0f} | {pct(Fr,.9):.0f} | {max(Fr) if Fr else '-'} |")
print('\nper language overall:')
for lang,n,hs,fr in con.execute("select language,count(*),group_concat(handshake_ms),group_concat(first_response_ms) from lsp_events where started_at>='2026-10-12 08:00' and started_at<='2026-11-10 22:24' and outcome='success' group by 1"):
    H=[int(x) for x in hs.split(',')]; Fr=[int(x) for x in fr.split(',') if x not in ('','None')] if fr else []
    print(f"| {lang} | {n} | hs p50 {pct(H,.5):.0f} p90 {pct(H,.9):.0f} | fr n={len(Fr)} p50 {pct(Fr,.5):.0f} p90 {pct(Fr,.9):.0f} max {max(Fr) if Fr else '-'} |")
print(con.execute("select outcome,count(*) from lsp_events where started_at>='2026-10-12 08:00' and started_at<='2026-11-10 22:24' group by 1").fetchall())
print(con.execute("select error,count(*) from lsp_events where started_at>='2026-10-12 08:00' and started_at<='2026-11-10 22:24' and outcome<>'success' group by 1 order by 2 desc limit 5").fetchall())
