#!/bin/bash
D=/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad/git_sem
export GIT_AUTHOR_NAME=t GIT_AUTHOR_EMAIL=t@e GIT_COMMITTER_NAME=t GIT_COMMITTER_EMAIL=t@e GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_NOSYSTEM=1
git init -q $D/ignoredonly
cd $D/ignoredonly || exit 1
echo 'target/' > .gitignore
echo a > a.txt
git add -A
git commit -q -m c1
mkdir -p target
echo junk > target/junk.o
echo "CLI porcelain (clean tree except ignored dir): [$(git status --porcelain)]"
python3 - <<'EOF'
import re
p = "/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad/git_bench/src/bin/sem.rs"
s = open(p).read()
if "ignoredonly" not in s:
    s = s.replace('("packed-refs only", "packedrefs"),', '("packed-refs only", "packedrefs"),\n        ("clean except gitignored target/ (dashboard git_info dirty?)", "ignoredonly"),')
    open(p, "w").write(s)
print("patched")
EOF
