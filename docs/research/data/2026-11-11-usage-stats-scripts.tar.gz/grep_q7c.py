import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_common import *
import pickle, random
res=pickle.load(open('grep_shell_res.pkl','rb'))
random.seed(5)
gg=res['git grep']
withrev=[x for x in gg if x[2].get('revs')]
revs=collections.Counter(r for x in withrev for r in x[2]['revs'])
print('rev tokens top',revs.most_common(15))
for x in random.sample(withrev,8): print(x[0],'REVS',x[2]['revs'],'|',x[3][:200].replace('\n',' '))
print('--- no rev')
for x in random.sample([x for x in gg if not x[2].get('revs')],6): print(x[0],'|',x[3][:200].replace('\n',' '))
print('parent/sub git grep with rev', sum(1 for x in withrev if x[1] is None), sum(1 for x in withrev if x[1] is not None))
