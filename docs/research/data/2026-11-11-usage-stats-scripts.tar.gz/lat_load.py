import sqlite3, json, pickle, datetime as dt, sys
S='/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad/'
con=sqlite3.connect('file:/home/marius/work/claude/codescout/.codescout/usage.db?mode=ro',uri=True)
cur=con.execute("""select id,tool_name,called_at,started_at,latency_ms,outcome,overflowed,session_id,agent_id,input_json,output_json,project_root,codescout_sha,codescout_dirty,err_family,attribution_ms,attribution_outcome,effect_class,error_msg from tool_calls where id<=299175 order by id""")
def p(s):
    return dt.datetime.strptime(s[:23],'%Y-%m-%d %H:%M:%S.%f') if '.' in s[:23] else dt.datetime.strptime(s[:19],'%Y-%m-%d %H:%M:%S')
rows=[]
for r in cur:
    (id,tool,ca,sa,lat,out,ov,sess,ag,inj,outj,pr,sha,dirty,fam,ams,aout,eff,err)=r
    inp={}
    if inj:
        try: inp=json.loads(inj)
        except Exception: inp={}
        if not isinstance(inp,dict): inp={}
    c=ca; s=sa
    wall=(p(ca)-p(sa)).total_seconds()*1000
    d=dict(id=id,tool=tool,ca=ca,sa=sa,lat=lat,out=out,ov=ov,sess=sess,ag=ag,pr=pr,sha=sha,dirty=dirty,fam=fam,ams=ams,aout=aout,eff=eff,wall=wall,gap=wall-lat,
      has_in=bool(inj),has_out=bool(outj),
      cmd=inp.get('command') if tool=='run_command' else None,
      tmo=inp.get('timeout_secs'), bg=bool(inp.get('run_in_background')),
      action=inp.get('action'), path=inp.get('path'), name=inp.get('name') or inp.get('symbol'), kind=inp.get('kind'),
      timed_out=('Command timed out after' in outj and 'timed_out\\": true' in outj) if outj else None,
      err=(err or '')[:200], inkeys=sorted(inp.keys()), inp=(inj[:400] if inj else None))
    rows.append(d)
pickle.dump(rows,open(S+'lat_rows.pkl','wb'))
print(len(rows))
