import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from base_common import *
c=conn()
rows=c.execute(f"select id,tool_name,called_at,session_id,agent_id,deliveries_json dj,outcome,error_msg from tool_calls where id<={MAXID}").fetchall()
N=len(rows)
print("deliveries_json null",sum(1 for r in rows if r['dj'] is None),"[] ",sum(1 for r in rows if r['dj']=='[]'),"non-empty",sum(1 for r in rows if r['dj'] not in (None,'[]')))
print("null by outcome",collections.Counter(r['outcome'] for r in rows if r['dj'] is None))
eng=collections.Counter(); keyc=collections.Counter(); ses_eng=collections.defaultdict(set); ses_key=collections.defaultdict(set); byts=collections.Counter(); hintflag=collections.Counter()
prin_key=collections.defaultdict(set); ndel=0; multi=0; dtool=collections.Counter()
keys_per_call=collections.Counter()
for r in rows:
    if r['dj'] in (None,'[]'): continue
    try: L=json.loads(r['dj'])
    except Exception: continue
    ndel+=1; multi+= len(L)>1; dtool[r['tool_name']]+=1
    for e in L:
        en=e.get('engine'); eng[en]+=1; ses_eng[en].add(r['session_id']); hintflag[(en,e.get('hint'))]+=1
        b=sum(x.get('bytes',0) for x in e.get('blocks',[])); byts[en]+=b
        for k in e.get('ledger_keys',[]):
            keyc[(en,k)]+=1; ses_key[(en,k)].add(r['session_id']); prin_key[(en,k)].add((r['session_id'],r['agent_id'] or ''))
print("rows with non-empty deliveries",ndel,"rows with >1 engine entry",multi)
allses=len({r['session_id'] for r in rows})
print("\n| engine | deliveries | sessions | bytes delivered (sum) | hint=true | hint=false |")
for k,v in eng.most_common(): print(f"| {k} | {v} | {len(ses_eng[k])} / {allses} | {byts[k]} | {hintflag[(k,True)]} | {hintflag[(k,False)]} |")
print("\n| engine | ledger_key | deliveries | sessions | principals |")
for (en,k),v in keyc.most_common(60): print(f"| {en} | {k} | {v} | {len(ses_key[(en,k)])} | {len(prin_key[(en,k)])} |")
print("distinct ledger keys",len(keyc))
print("deliveries by tool",dtool.most_common(10))
# per session: number of sessions with any delivery; per-session guide sections count dist
sg=collections.defaultdict(set)
for (en,k),ss in ses_key.items():
    if en=='guide-sections':
        for s in ss: sg[s].add(k)
v=[len(x) for x in sg.values()]
print("\nsessions with >=1 guide-sections key",len(sg),"keys per session p50",pct(v,50),"p90",pct(v,90),"max",max(v))
# guide topic (before #) by sessions
topic=collections.defaultdict(set)
for (en,k),ss in ses_key.items():
    if en=='guide-sections': topic[k.split('#')[0]]|=ss
print("guide topic -> sessions:",sorted(((k,len(v)) for k,v in topic.items()),key=lambda x:-x[1]))
# session-opener
so=ses_eng['session-opener']; print("sessions with session-opener",len(so))
# explicit get_guide calls: topics
gg=collections.Counter(); gs=collections.defaultdict(set)
for r in rows:
    if r['tool_name']=='get_guide':
        pass
for r in c.execute(f"select input_json,session_id from tool_calls where id<={MAXID} and tool_name='get_guide' and input_json<>''"):
    try: t=json.loads(r[0]).get('topic')
    except Exception: t=None
    gg[t]+=1; gs[t].add(r[1])
print("explicit get_guide topics (rows w/ input)",gg.most_common(15),"sessions",{k:len(v) for k,v in gs.items()})
print("get_guide total rows",sum(1 for r in rows if r['tool_name']=='get_guide'))
# errors hint
H='— hint:'
er=[r for r in rows if r['outcome']!='success']
print("\nerrors",len(er),"w/ hint",sum(1 for r in er if H in r['error_msg']))
# daily deliveries timeline for first appearance of each engine
fe={}
for r in rows:
    if r['dj'] in (None,'[]'): continue
    for e in json.loads(r['dj']): fe.setdefault(e['engine'],r['called_at'])
print("first seen per engine",fe)
# deliveries to errors?
print("non-empty deliveries on error rows",sum(1 for r in er if r['dj'] not in (None,'[]')))
