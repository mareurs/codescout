import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_enrich import *
from grep_q23 import classify
import subprocess, pickle, datetime
def sh(args,timeout=60,cwd=PROJ):
    try:
        p=subprocess.run(args,cwd=cwd,capture_output=True,text=True,timeout=timeout,errors='replace')
        return p.returncode,p.stdout,p.stderr
    except subprocess.TimeoutExpired:
        return 124,'',''
EXC=['-g','!.codescout/audit','-g','!.codescout/usage*','-g','!.codescout/*.jsonl','-g','!.git','-g','!target','-g','!.worktrees','-g','!node_modules','-g','!.claude/worktrees']
def globs_of(ip):
    g=ip.get('glob')
    if g is None: return []
    return list(g) if isinstance(g,list) else [g]
def parse_iso(s): return datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
def run_row(r):
    ip=r['ip']; P=ip.get('pattern'); out={'id':r['id'],'pc':classify(P)}
    path=ip.get('path') or '.'
    if path.startswith('@'): out['verdict']='buffer_path_expired'; return out
    ap=path if path.startswith('/') else os.path.join(PROJ,path)
    out['path_exists']=os.path.exists(ap)
    gl=globs_of(ip)
    hid=['--hidden'] if ip.get('include_hidden') in (True,'true') else []
    flags=[]
    if ip.get('ignore_case') in (True,'true'): flags.append('-i')
    if ip.get('whole_word') in (True,'true'): flags.append('-w')
    gargs=[]
    for g in gl: gargs+=['-g',g]
    scope=[path]
    # S1: files admitted by scope
    isfile=os.path.isfile(ap)
    scwd=ap if os.path.isdir(ap) else PROJ
    sscope='.' if os.path.isdir(ap) else path
    sg=gargs if os.path.isdir(ap) else []   # explicit file root: the walker does not apply globs to it
    rc,so,se=sh(['rg','--files']+hid+sg+['--',sscope],cwd=scwd)
    nfiles=len([l for l in so.split('\n') if l]) if rc in (0,1) else None
    out['files_in_scope']=nfiles
    # S0: same-scope search (current tree)
    rc0,so0,se0=sh(['rg','-c','--no-messages','-e',P]+flags+hid+sg+['--',sscope],cwd=scwd)
    if rc0==2 and not so0: out['rg_error']=se0[:120]
    hits0=[]
    if rc0 in (0,2):
        for l in so0.split('\n'):
            if not l: continue
            f=path if (isfile and l.strip().isdigit()) else (l.rsplit(':',1)[0] if ':' in l else l)
            if not isfile and scwd!=PROJ:
                f=os.path.relpath(os.path.join(scwd,f),PROJ)
            hits0.append(f)
    if len(hits0)==0 and path and os.path.isfile(ap):
        pass
    out['hits_same_scope_now']=len(hits0)
    out['hit_files']=hits0[:5]
    # S2: whole repo, widened
    rc2,so2,se2=sh(['rg','-l','--no-messages','--hidden','--no-ignore','-i','-e',P]+EXC+['--','.'])
    wide=[l for l in so2.split('\n') if l]
    out['hits_widened_now']=len(wide); out['wide_files']=wide[:5]
    # classify wide hits as hidden/ignored vs visible tracked
    vis=[]
    if wide:
        rc3,so3,_=sh(['rg','-l','--no-messages','-i','-e',P]+EXC+['--','.'])
        vis=[l for l in so3.split('\n') if l]
    out['hits_visible_repo_now']=len(vis)
    codeish=[f for f in vis if re.match(r'^(\./)?(src|crates|tests|scripts|\.github|benches|examples)/',f) or re.search(r'\.(rs|py|sh|toml|mjs|js|ts)$',f)]
    out['visible_code_hits']=len(codeish)
    called=parse_iso(r['called_at']+'+00:00') if '+' not in r['called_at'] else parse_iso(r['called_at'])
    if not os.path.exists(ap):
        rc,so,_=sh(['git','log','--all','-1','--format=%h','--',path])
        out['verdict']='path_missing_now_but_in_git_history' if so.strip() else 'path_never_existed_in_git'
        return out
    if nfiles==0:
        out['verdict']='starved_scope_admits_no_file_now'
        out['warned']= 'No file under' in r['out']['text']
        return out
    if len(hits0)>0:
        # tree-change test per file
        stable=True; why=[]
        for f in hits0[:5]:
            f=f[2:] if f.startswith('./') else f
            if f.startswith('../') or f.startswith('/home') and not f.startswith(PROJ+'/'): stable=False; why.append('outside_repo_unversioned:'+f); continue
            rc,a,_=sh(['git','log','--diff-filter=A','--format=%aI','--',f]); rc,m,_=sh(['git','log','-1','--format=%aI','--',f])
            a=a.strip().split('\n')[-1] if a.strip() else None; m=m.strip().split('\n')[0] if m.strip() else None
            if a is None: stable=False; why.append('untracked:'+f); continue
            if parse_iso(m)>called: stable=False; why.append('modified_after_call:'+f)
            if parse_iso(a)>called: stable=False; why.append('added_after_call:'+f)
        out['why']=why[:3]
        if stable:
            out['verdict']='FALSE_zero_current_tree_matches_file_untouched'; return out
        f0=hits0[0][2:] if hits0[0].startswith('./') else hits0[0]
        if why and why[0].startswith('outside_repo'): out['verdict']='tree_unversioned_outside_repo'; return out
        lit=P if not any(c in set('^$\\[](){}+*?|') for c in P) else None
        flag=['-S'+lit] if lit else ['-G'+P]
        since=r['called_at'].replace(' ','T')+'Z'
        rc,so,se=sh(['git','log','--since='+since]+flag+['--format=%h','-n','1','--',f0],timeout=60)
        rc2_,do,_=sh(['git','diff','HEAD']+flag+['--stat','--',f0],timeout=60)
        if rc!=0: out['verdict']='tree_changed_unresolved(pickaxe_error)'
        elif so.strip() or do.strip(): out['verdict']='tree_changed_match_introduced_or_removed_after_call'
        else: out['verdict']='FALSE_zero_file_modified_after_call_but_matching_text_unchanged'
        return out
    # zero holds in scope now
    if len(wide)==0:
        out['verdict']='true_zero_absent_everywhere_now'
        # pickaxe: was a literal removed after the call date?
        lit=P if not any(c in set('^$\\[](){}+*?|') for c in P) else None
        if lit:
            rc,so,_=sh(['git','log','--since='+r['called_at'].replace(' ','T')+'Z','-S'+lit,'--format=%h','-n','1'],timeout=60)
            out['removed_since_call']= bool(so.strip()) if rc==0 else None
        return out
    if len(vis)==0: out['verdict']='scope_miss_match_only_in_hidden_or_ignored'
    else: out['verdict']='scope_miss_code_elsewhere' if codeish else 'scope_miss_only_docs_or_records_elsewhere'
    return out
rows=enrich()
Z=[r for r in rows if r['out'].get('zero') and r['has_in']]
main=[r for r in Z if (r['ip'].get('workspace') or r['root'])==PROJ]
print('main zero rows',len(main))
res=[]
import time; t0=time.time()
for k,r in enumerate(main):
    try: res.append(run_row(r))
    except Exception as e: res.append({'id':r['id'],'verdict':'script_error:'+repr(e)[:80]})
    if time.time()-t0>800: print('time cut at',k); break
pickle.dump(res,open('grep_q4b.pkl','wb'))
c=collections.Counter(x['verdict'] for x in res)
for k,n in c.most_common(): print(n,k)
