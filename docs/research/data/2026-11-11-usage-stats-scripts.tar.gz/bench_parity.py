#!/usr/bin/env python3
"""Parity: rg / git grep / codescout(files mode) per (pattern, scope). Read-only.
usage: bench_parity.py A   -> snapshot rg/gg sets before the codescout run
       bench_parity.py B   -> snapshot again, compare with A (drift check) and with codescout counts"""
import sys, os, re, json, subprocess, shlex
sys.path.insert(0, "/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad")
import bench_common as b
ROOT = b.ROOT
phase = sys.argv[1]
def sh(cmd, cwd):
    r = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True, errors="replace")
    return r.stdout
def parse_lines(out):
    s = set()
    for ln in out.splitlines():
        m = re.match(r"^(.*?):(\d+):", ln)
        if m: s.add((m.group(1).removeprefix("./"), int(m.group(2))))
    return s
def counts(s):
    d = {}
    for f, _ in s: d[f] = d.get(f, 0) + 1
    return d
def snapshot():
    snap = {}
    for p, sk, s in b.combos():
        if p["pcre"]: continue
        key = p["id"] + "|" + sk
        if s.get("reg"):
            rgc = b.rg_cmd(p, dict(path=".", glob=None)); ggc = b.gg_cmd(p, dict(reg=True, path=b.REG)).replace("git -C " + shlex.quote(b.REG) + " ", "git ")
            snap[key] = dict(rg=parse_lines(sh(rgc, b.REG)), gg=parse_lines(sh(ggc, b.REG)), rgh=None, ggu=None)
        else:
            snap[key] = dict(rg=parse_lines(sh(b.rg_cmd(p, s), ROOT)), gg=parse_lines(sh(b.gg_cmd(p, s), ROOT)),
                             rgh=parse_lines(sh(b.rg_cmd(p, s, ["--hidden"]), ROOT)), ggu=parse_lines(sh(b.gg_cmd(p, s, ["--untracked"]), ROOT)))
    return snap
snap = snapshot()
fa = b.SP + "/parity2/snapA.json"
if phase == "A":
    json.dump({k: {n: (None if v is None else sorted(v)) for n, v in d.items()} for k, d in snap.items()}, open(fa, "w"))
    print("snapshot A", len(snap)); sys.exit(0)
A = json.load(open(fa))
out = json.load(open(b.SP + "/bench_out_parity2.json"))
par = {r["label"].rsplit("|", 1)[0]: r for r in out["results"]}
def cs_counts(key):
    pid, sk = key.split("|")
    f = f"{b.SP}/parity2/cs_{pid}_{sk}.json"
    meta = {}
    if os.path.exists(f):
        j = json.load(open(f))
        meta = {k: j[k] for k in ("walk_cut", "skipped_binary", "skipped_large", "completeness_warning") if k in j}
        return {x["file"]: x["count"] for x in j["files"]}, meta
    r = par[key]; t = r.get("text_last") or r.get("text_first") or ""
    if "walk cut" in t: meta["walk_cut"] = True
    d = {}
    for ln in t.splitlines():
        m = re.match(r"^\s+(\d+)  (.+)$", ln)
        if m: d[m.group(2)] = int(m.group(1))
    hm = re.search(r"(\d+) matches in (\d+) files", t)
    if hm and int(hm.group(2)) != len(d): meta["inline_files_listed_vs_header"] = (len(d), int(hm.group(2)))
    return d, meta
res = []
for p, sk, s in b.combos():
    if p["pcre"]: continue
    key = p["id"] + "|" + sk
    cur = snap[key]
    stable = {n: (None if cur[n] is None else sorted(cur[n]) == [tuple(x) for x in A[key][n]]) for n in cur}
    rg, gg = cur["rg"], cur["gg"]
    csd, meta = cs_counts(key)
    if s.get("reg"):
        csd = {k.replace(b.REG + "/", "", 1).removeprefix("./"): v for k, v in csd.items()}
    rgc_, ggc_ = counts(rg), counts(gg)
    def diff(a, c):
        return dict(only_a=sorted(set(a) - set(c)), only_c=sorted(set(c) - set(a)),
                    count_diff=sorted((f, a[f], c[f]) for f in set(a) & set(c) if a[f] != c[f]))
    res.append(dict(id=p["id"], scope=sk, pat=p["pat"], stable=stable,
                    rg_lines=len(rg), rg_files=len(rgc_), gg_lines=len(gg), gg_files=len(ggc_),
                    cs_lines=sum(csd.values()), cs_files=len(csd), cs_meta=meta,
                    rgh_lines=None if cur["rgh"] is None else len(cur["rgh"]), ggu_lines=None if cur["ggu"] is None else len(cur["ggu"]),
                    rg_vs_gg_lines=dict(only_rg=len(rg - gg), only_gg=len(gg - rg)),
                    rg_vs_cs=diff(rgc_, csd), gg_vs_cs=diff(ggc_, csd), rg_vs_gg_files=diff(rgc_, ggc_)))
json.dump(res, open(b.SP + "/bench_parity_result.json", "w"), indent=1)
print("rows", len(res))
