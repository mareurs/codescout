import pickle, collections, re
rows=pickle.load(open('lat_rows.pkl','rb'))
rc=[r for r in rows if r['tool']=='run_command']
f=[r for r in rc if r['timed_out'] and r['tmo']]
d=[round(r['lat']-r['tmo']*1000) for r in f]
print(len(f),sorted(d)[:5],sorted(d)[-5:],collections.Counter(min(max(x,-1),200)//50 for x in d))
# default timeout when tmo None
nf=[r for r in rc if r['timed_out'] and not r['tmo']]
print('flag without tmo',len(nf),sorted(r['lat'] for r in nf)[:10])
# rows not flagged but lat within [tmo*1000, tmo*1000+150]
g=[r for r in rc if not r['timed_out'] and r['tmo'] and 0<=r['lat']-r['tmo']*1000<=300]
print('unflagged-near-timeout',len(g),'has_out',sum(r['has_out'] for r in g))
g2=[r for r in rc if r['timed_out'] is False and r['tmo'] and 0<=r['lat']-r['tmo']*1000<=300]
print('explicitly timed_out absent but lat>=tmo',len(g2))
# in the has_out rows: how does a non-timeout output look? check key e.g. 'timed_out' absent 
print(collections.Counter(r['timed_out'] for r in rc))
