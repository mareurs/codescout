import pickle, collections, json, re, datetime as dt
rows=pickle.load(open('lat_rows.pkl','rb'))
def pct(v,q):
    v=sorted(v)
    if not v: return 0
    k=(len(v)-1)*q; f=int(k); c=min(f+1,len(v)-1); return v[f]+(v[c]-v[f])*(k-f)
WAIT=re.compile(r'\b(until|while|sleep)\b|pgrep -f')
for r in rows:
    r['wait']=r['tool']=='run_command' and r['cmd'] is not None and bool(WAIT.search(r['cmd']))
    T=r['tmo'] if r['tmo'] else (30 if r['has_in'] else None)
    r['to']=r['tool']=='run_command' and (bool(r['timed_out']) or (T is not None and 0<=r['lat']-T*1000<=300))
    r['exw']=not(r['wait'] or r['to'])
TOP=['run_command','symbols','grep','read_file','edit_file','doc','edit_code','create_file','memory','workspace']
def cell(l):
    return f"{len(l)} / {pct(l,.5):.0f} / {pct(l,.9):.0f}" if l else '-'
def seg(name,keyf,tools=TOP,use_exw=True):
    groups=collections.defaultdict(lambda: collections.defaultdict(list))
    for r in rows:
        if r['tool'] in tools and (r['exw'] or not use_exw):
            groups[keyf(r)][r['tool']].append(r['lat'])
    print(f"\n### {name} (cells: n / p50 / p90 ms; run_command excludes wait loops and timeouts)\n")
    print('| segment | '+' | '.join(tools)+' |'); print('|---'*(len(tools)+1)+'|')
    for k in sorted(groups,key=str):
        print(f"| {k} | "+' | '.join(cell(groups[k][t]) for t in tools)+' |')
seg('Parent vs subagent',lambda r:'subagent' if r['ag'] else 'parent(agent_id NULL)')
def rootc(r):
    p=r['pr']
    if p=='/home/marius/work/claude/codescout': return 'main checkout'
    if '/.worktrees/' in p or '/.claude/worktrees/' in p or '/.codex/worktrees/' in p: return 'worktree (.worktrees/.claude/.codex)'
    if p.startswith('/tmp/') or '/tmp/' in p: return 'tmp checkout'
    if p.startswith('/home/marius/work/claude/codescout'): return 'other under codescout'
    return 'other repo'
seg('Root class',rootc)
print('\nroot class counts',collections.Counter(rootc(r) for r in rows))
def week(r):
    d=dt.date.fromisoformat(r['ca'][:10]); w=(d-dt.date(2026,10,12)).days//7
    return f"W{w+1} (from {dt.date(2026,10,12)+dt.timedelta(days=7*w)})"
seg('Week (UTC, Mon-start)',week)
seg('codescout_dirty',lambda r:f"dirty={r['dirty']}")
# hour-of-day
print('\n### Hour of day UTC: load vs p90\n| hour | rows | non-rc p50 | non-rc p90 | rc(ex wait/to) p50 | rc p90 | gap p90 | rows with gap>1s |\n|---|---|---|---|---|---|---|---|')
H=collections.defaultdict(list)
for r in rows: H[int(r['ca'][11:13])].append(r)
for h in range(24):
    l=H[h]; nrc=[r['lat'] for r in l if r['tool']!='run_command']; rc=[r['lat'] for r in l if r['tool']=='run_command' and r['exw']]
    print(f"| {h:02d} | {len(l)} | {pct(nrc,.5):.0f} | {pct(nrc,.9):.0f} | {pct(rc,.5):.0f} | {pct(rc,.9):.0f} | {pct([r['gap'] for r in l],.9):.0f} | {sum(r['gap']>1000 for r in l)} |")
# top 5 shas
print('\n### Top 5 codescout_sha by frequency (p50 ms per tool; n)')
cs=collections.Counter(r['sha'] for r in rows); print('distinct shas',len(cs))
top=[s for s,_ in cs.most_common(5)]
print('| sha | dirty | rows | first..last | '+' | '.join(TOP[:7])+' |'); print('|---'*(4+7)+'|')
for s in top:
    l=[r for r in rows if r['sha']==s]
    cells=[]
    for t in TOP[:7]:
        v=[r['lat'] for r in l if r['tool']==t and r['exw']]
        cells.append(f"{pct(v,.5):.0f} (n{len(v)})" if v else '-')
    print(f"| {s} | {collections.Counter(r['dirty'] for r in l).most_common(1)[0][0]} | {len(l)} | {min(r['ca'] for r in l)[:10]}..{max(r['ca'] for r in l)[:10]} | "+' | '.join(cells)+' |')
