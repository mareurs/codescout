import pickle, collections
S='./'
rows=pickle.load(open(S+'lat_rows.pkl','rb'))
top=sorted(rows,key=lambda r:-r['gap'])[:12]
for r in top: print(r['id'],r['tool'],r['sa'],r['ca'],'lat',r['lat'],'gap',round(r['gap']),r['pr'][-40:],r['sess'][:8],(r['cmd'] or '')[:60].replace('\n',' '),r['bg'])
print()
h=collections.Counter(int(r['gap']//100) for r in rows if 500<=r['gap']<8000)
for k in sorted(h): print(f"{k*100}-{k*100+99}",h[k])
