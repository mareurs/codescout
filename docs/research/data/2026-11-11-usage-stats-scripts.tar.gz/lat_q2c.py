import pickle, collections, re
rows=pickle.load(open('lat_rows.pkl','rb'))
WAIT=re.compile(r'\b(until|while|sleep)\b|pgrep -f')
rc=[r for r in rows if r['tool']=='run_command']
w=[r for r in rc if r['cmd'] and WAIT.search(r['cmd'])]
def grp(label,sel):
    l=[r for r in w if sel(r['cmd'])]; print(f"| {label} | {len(l)} | {sum(r['lat'] for r in l)/1000:.0f} | {sorted(r['lat'] for r in l)[len(l)//2]/1000 if l else 0:.0f} |")
print('| wait-loop kind | n | sum_s | p50_s |\n|---|---|---|---|')
grp('polls a @bg_ job (until/while ... @bg_N)',lambda c:'@bg_' in c)
grp('pgrep -f / pgrep',lambda c:'pgrep' in c)
grp('polls a file/grep (until grep -q / [ -f ]) not @bg',lambda c:('@bg_' not in c and 'pgrep' not in c and re.search(r'until|while',c) is not None))
grp('plain sleep N only (no until/while)',lambda c:not re.search(r'\b(until|while)\b',c) and 'pgrep' not in c)
print('total',len(w),round(sum(r['lat'] for r in w)/1000))
print('parent vs subagent wait loops:',{k:(sum(1 for r in w if bool(r['ag'])==k),round(sum(r['lat'] for r in w if bool(r['ag'])==k)/1000)) for k in (False,True)})
bysess=collections.Counter(); 
for r in w: bysess[r['sess'][:8]]+=r['lat']
print('top sessions by wait-loop time s',[(k,round(v/1000)) for k,v in bysess.most_common(5)],'distinct sessions',len(bysess))
# background launches: rc rows with run_in_background true
bg=[r for r in rc if r['bg']]; print('run_in_background rows',len(bg),'p50',sorted(r['lat'] for r in bg)[len(bg)//2],'max',max(r['lat'] for r in bg))
# time by week of wait loops
print(sorted(collections.Counter({k:0 for k in []}).items()))
import datetime as dt
d=collections.defaultdict(lambda:[0,0])
for r in w:
    k=(dt.date.fromisoformat(r['ca'][:10])-dt.date(2026,10,12)).days//7+1; d[k][0]+=1; d[k][1]+=r['lat']/1000
print('wait loops by week',{k:(v[0],round(v[1])) for k,v in sorted(d.items())})
