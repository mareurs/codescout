use git2::{DiffFindOptions, DiffOptions, Repository, Sort, StatusOptions};
use std::path::Path;
use std::process::{Command, Stdio};
use std::time::Instant;

const WARM: usize = 3;
const ITERS: usize = 20;

fn cli(repo: &str, args: &[&str]) -> Vec<u8> {
    let out = Command::new("git")
        .arg("-C")
        .arg(repo)
        .args(args)
        .env("GIT_OPTIONAL_LOCKS", "0")
        .stdin(Stdio::null())
        .stderr(Stdio::null())
        .output()
        .expect("spawn git");
    out.stdout
}

fn bench<F: FnMut() -> usize>(name: &str, kind: &str, mut f: F, iters: usize) -> (f64, f64, usize) {
    let mut sink = 0usize;
    for _ in 0..WARM {
        sink ^= f();
    }
    let mut t: Vec<f64> = Vec::with_capacity(iters);
    for _ in 0..iters {
        let s = Instant::now();
        sink ^= f();
        t.push(s.elapsed().as_secs_f64() * 1000.0);
    }
    t.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let med = (t[(t.len() - 1) / 2] + t[t.len() / 2]) / 2.0;
    let p90 = t[((t.len() as f64 * 0.9).ceil() as usize - 1).min(t.len() - 1)];
    let min = t[0];
    println!("| {name} | {kind} | {med:.2} | {p90:.2} | {min:.2} | {iters} | {sink} |");
    (med, p90, sink)
}

fn main() {
    let repo_path = std::env::args().nth(1).expect("repo path");
    if std::env::var("STRICT").as_deref() == Ok("0") {
        unsafe { git2::opts::strict_hash_verification(false); }
        println!("STRICT_HASH_VERIFICATION=off");
    }
    let only = std::env::args().nth(2);
    let want = |n: &str| only.as_deref().map_or(true, |o| n.contains(o));
    let r = &repo_path;
    let deep = format!("{r}/src/librarian/tools");
    let repo0 = Repository::open(r).unwrap();
    let head_oid = repo0.revparse_single("HEAD").unwrap().id().to_string();
    let c5 = repo0.revparse_single("HEAD~5").unwrap().id().to_string();
    let c200 = repo0.revparse_single("HEAD~200").unwrap().id().to_string();
    let c50 = repo0.revparse_single("HEAD~50").unwrap().id().to_string();
    drop(repo0);
    println!("head={head_oid} head5={c5} head50={c50} head200={c200}");
    println!("| operation | mechanism | median ms | p90 ms | min ms | n | sink |");
    println!("|---|---|---|---|---|---|---|");

    if want("discover") {
        bench("discover(subdir)", "git2 Repository::discover+workdir", || {
            Repository::discover(&deep).unwrap().workdir().unwrap().as_os_str().len()
        }, ITERS);
        bench("discover(subdir)", "CLI rev-parse --show-toplevel", || {
            cli(&deep, &["rev-parse", "--show-toplevel"]).len()
        }, ITERS);
        bench("open(root)", "git2 Repository::open", || {
            Repository::open(r).unwrap().path().as_os_str().len()
        }, ITERS);
    }
    if want("head") {
        bench("HEAD full oid (open+revparse)", "git2", || {
            let repo = Repository::open(r).unwrap();
            let x = repo.revparse_single("HEAD").unwrap().id().to_string().len(); x
        }, ITERS);
        bench("HEAD full oid (open+revparse)", "CLI rev-parse HEAD", || {
            cli(r, &["rev-parse", "HEAD"]).len()
        }, ITERS);
        bench("HEAD short id (open+revparse+short_id)", "git2", || {
            let repo = Repository::open(r).unwrap();
            let o = repo.revparse_single("HEAD").unwrap();
            o.short_id().unwrap().as_str().unwrap().len()
        }, ITERS);
        bench("HEAD short id", "CLI rev-parse --short HEAD", || {
            cli(r, &["rev-parse", "--short", "HEAD"]).len()
        }, ITERS);
        let repo = Repository::open(r).unwrap();
        bench("HEAD resolve, repo already open", "git2 revparse_single", || {
            repo.revparse_single("HEAD").unwrap().id().to_string().len()
        }, ITERS);
        bench("remotes() (probe_has_git_remote)", "git2 open+remotes", || {
            Repository::open(r).unwrap().remotes().unwrap().len() + 1
        }, ITERS);
        bench("remotes()", "CLI git remote", || cli(r, &["remote"]).len() + 1, ITERS);
    }
    if want("status") {
        bench("status incl. untracked (dashboard: statuses(None))", "git2 default opts (ignored listed)", || {
            let repo = Repository::open(r).unwrap();
            let x = repo.statuses(None).unwrap().len(); x
        }, ITERS);
        bench("status incl. untracked, no ignored, recurse", "git2 StatusOptions", || {
            let repo = Repository::open(r).unwrap();
            let mut o = StatusOptions::new();
            o.include_untracked(true).recurse_untracked_dirs(true).include_ignored(false).renames_head_to_index(false);
            let x = repo.statuses(Some(&mut o)).unwrap().len(); x
        }, ITERS);
        bench("status incl. untracked", "CLI status --porcelain=v2 -z --untracked-files=all", || {
            cli(r, &["status", "--porcelain=v2", "-z", "--untracked-files=all"]).len()
        }, ITERS);
        bench("status v1 (observe.rs flags)", "CLI status --porcelain=v1 -z --no-renames --untracked-files=all", || {
            cli(r, &["status", "--porcelain=v1", "-z", "--no-renames", "--untracked-files=all"]).len()
        }, ITERS);
        bench("status tracked only", "CLI status --porcelain=v2 -z -uno", || {
            cli(r, &["status", "--porcelain=v2", "-z", "-uno"]).len()
        }, ITERS);
        bench("status one file (delete dry run)", "git2 status_file", || {
            let repo = Repository::open(r).unwrap();
            repo.status_file(Path::new("Cargo.toml")).unwrap().bits() as usize + 1
        }, ITERS);
        bench("status one file (delete dry run)", "CLI status --porcelain=v1 --ignored -- Cargo.toml", || {
            cli(r, &["status", "--porcelain=v1", "--ignored", "--", "Cargo.toml"]).len() + 1
        }, ITERS);
    }
    if want("diff") {
        for (label, base) in [("HEAD~5..HEAD", &c5), ("HEAD~200..HEAD", &c200)] {
            let b = base.clone();
            let h = head_oid.clone();
            bench(&format!("tree-to-tree diff {label} (+renames)"), "git2 diff_tree_to_tree+find_similar", || {
                let repo = Repository::open(r).unwrap();
                let t1 = repo.find_commit(git2::Oid::from_str(&b).unwrap()).unwrap().tree().unwrap();
                let t2 = repo.find_commit(git2::Oid::from_str(&h).unwrap()).unwrap().tree().unwrap();
                let mut opts = DiffOptions::new();
                let mut d = repo.diff_tree_to_tree(Some(&t1), Some(&t2), Some(&mut opts)).unwrap();
                let mut fo = DiffFindOptions::new();
                fo.renames(true);
                d.find_similar(Some(&mut fo)).unwrap();
                d.deltas().len()
            }, ITERS);
            let b = base.clone();
            let h = head_oid.clone();
            bench(&format!("tree-to-tree diff {label} (+renames)"), "CLI diff-tree -r --name-status -z -M", || {
                cli(r, &["diff-tree", "-r", "--name-status", "-z", "-M", &b, &h]).len()
            }, ITERS);
            let b = base.clone();
            let h = head_oid.clone();
            bench(&format!("tree-to-tree diff {label} (no renames)"), "git2 diff_tree_to_tree only", || {
                let repo = Repository::open(r).unwrap();
                let t1 = repo.find_commit(git2::Oid::from_str(&b).unwrap()).unwrap().tree().unwrap();
                let t2 = repo.find_commit(git2::Oid::from_str(&h).unwrap()).unwrap().tree().unwrap();
                let x = repo.diff_tree_to_tree(Some(&t1), Some(&t2), None).unwrap().deltas().len(); x
            }, ITERS);
            let b = base.clone();
            let h = head_oid.clone();
            bench(&format!("tree-to-tree diff {label} (no renames)"), "CLI diff-tree -r --name-status -z", || {
                cli(r, &["diff-tree", "-r", "--name-status", "-z", &b, &h]).len()
            }, ITERS);
        }
    }
    if want("ignore") {
        bench("is_path_ignored target/debug/x (ignored)", "git2", || {
            let repo = Repository::open(r).unwrap();
            repo.is_path_ignored("target/debug/x").unwrap() as usize + 1
        }, ITERS);
        bench("is_path_ignored src/lib.rs (not ignored)", "git2", || {
            let repo = Repository::open(r).unwrap();
            repo.is_path_ignored("src/lib.rs").unwrap() as usize + 1
        }, ITERS);
        bench("check-ignore target/debug/x", "CLI check-ignore -q", || {
            cli(r, &["check-ignore", "-q", "target/debug/x"]).len() + 1
        }, ITERS);
    }
    if want("index") {
        bench("index read + iterate all entries (build_tracked_dirs)", "git2 index().iter()", || {
            let repo = Repository::open(r).unwrap();
            let idx = repo.index().unwrap();
            let mut n = 0usize;
            for e in idx.iter() {
                n += e.path.len();
            }
            n
        }, ITERS);
        bench("ls-files all tracked", "CLI ls-files -z", || cli(r, &["ls-files", "-z"]).len(), ITERS);
    }
    if want("walk") {
        bench("revwalk last 200 commits (+summary)", "git2 revwalk TIME", || {
            let repo = Repository::open(r).unwrap();
            let mut w = repo.revwalk().unwrap();
            w.push_head().unwrap();
            w.set_sorting(Sort::TIME).unwrap();
            let mut n = 0;
            for oid in w.take(200).flatten() {
                n += repo.find_commit(oid).unwrap().summary().map_or(0, |s| s.len());
            }
            n
        }, ITERS);
        bench("revwalk last 200 commits", "CLI log -n 200 --format=%H", || {
            cli(r, &["log", "-n", "200", "--format=%H"]).len()
        }, ITERS);
        bench("revwalk ALL commits oids only (gc.rs)", "git2", || {
            let repo = Repository::open(r).unwrap();
            let mut w = repo.revwalk().unwrap();
            w.push_head().unwrap();
            w.count()
        }, ITERS);
        bench("revwalk ALL commits oids only (gc.rs)", "CLI rev-list HEAD", || {
            cli(r, &["rev-list", "HEAD"]).len()
        }, ITERS);
        bench("revwalk ALL commits TOPO|REVERSE + find_commit(time,summary) (reindex backfill_commits)", "git2", || {
            let repo = Repository::open(r).unwrap();
            let mut w = repo.revwalk().unwrap();
            w.set_sorting(Sort::TOPOLOGICAL | Sort::REVERSE).unwrap();
            w.push_head().unwrap();
            let mut n = 0usize;
            for oid in w.flatten() {
                let c = repo.find_commit(oid).unwrap();
                n += c.summary().map_or(0, |s| s.len()) + c.time().seconds() as usize % 7;
            }
            n
        }, 10);
        bench("revwalk ALL commits TOPO|REVERSE + hash,time,subject (reindex backfill_commits)", "CLI log --topo-order --reverse --format=%H%x00%ct%x00%s", || {
            cli(r, &["log", "--topo-order", "--reverse", "--format=%H%x00%ct%x00%s"]).len()
        }, 10);
        // doctor paths_touched_since: walk up to 4000 commits, diff each in-window commit against its parent
        let cutoff = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_secs() as i64 - 7 * 86400;
        bench("doctor paths_touched_since: <=4000 commits, diff in-window vs parent, no pathspec", "git2", || {
            let repo = Repository::open(r).unwrap();
            let mut w = repo.revwalk().unwrap();
            w.push_head().unwrap();
            let _ = w.set_sorting(Sort::TIME);
            let mut paths = std::collections::HashSet::new();
            for (seen, oid) in w.flatten().enumerate() {
                if seen >= 4000 { break; }
                let c = repo.find_commit(oid).unwrap();
                if c.time().seconds() < cutoff { continue; }
                let t = c.tree().unwrap();
                let pt = c.parent(0).ok().and_then(|p| p.tree().ok());
                let d = repo.diff_tree_to_tree(pt.as_ref(), Some(&t), None).unwrap();
                for delta in d.deltas() {
                    for f in [delta.new_file(), delta.old_file()] {
                        if let Some(p) = f.path().and_then(|p| p.to_str()) { paths.insert(p.to_string()); }
                    }
                }
            }
            paths.len()
        }, 10);
        bench("doctor paths_touched_since equivalent: since 7 days names only", "CLI log -n 4000 --since=7.days --name-only --format= -z", || {
            cli(r, &["log", "-n", "4000", "--since=7.days.ago", "--name-only", "--format=", "-z"]).len()
        }, 10);
    }
    if want("scale") {
        for n in [1usize, 20, 200, 1000, 5000] {
            bench(&format!("revwalk TIME first {n} commits, oids only"), "git2", move || {
                let repo = Repository::open(r).unwrap();
                let mut w = repo.revwalk().unwrap();
                w.push_head().unwrap();
                w.set_sorting(Sort::TIME).unwrap();
                w.take(n).flatten().count()
            }, 10);
            bench(&format!("revwalk NONE-sort first {n} commits, oids only"), "git2", move || {
                let repo = Repository::open(r).unwrap();
                let mut w = repo.revwalk().unwrap();
                w.push_head().unwrap();
                w.take(n).flatten().count()
            }, 10);
            bench(&format!("log first {n} commits"), "CLI log -n N --format=%H", move || {
                cli(r, &["log", "-n", &n.to_string(), "--format=%H"]).len()
            }, 10);
        }
        bench("revparse HEAD~200 (ancestor walk, repo open per iter)", "git2", || {
            let repo = Repository::open(r).unwrap();
            let x = repo.revparse_single("HEAD~200").unwrap().id().to_string().len(); x
        }, 10);
        bench("revparse HEAD~200", "CLI rev-parse HEAD~200", || cli(r, &["rev-parse", "HEAD~200"]).len(), 10);
    }
    if want("blame") {
        bench("blame_file src/librarian/tools/gather.rs", "git2 blame_file", || {
            let repo = Repository::open(r).unwrap();
            let x = repo.blame_file(Path::new("src/librarian/tools/gather.rs"), None).unwrap().len(); x
        }, 10);
        bench("blame src/librarian/tools/gather.rs", "CLI blame --porcelain", || {
            cli(r, &["blame", "--porcelain", "src/librarian/tools/gather.rs"]).len()
        }, 10);
    }
    if want("worktree") {
        bench("worktree list", "git2 worktrees()", || {
            let repo = Repository::open(r).unwrap();
            repo.worktrees().unwrap().len()
        }, ITERS);
        bench("worktree list", "CLI worktree list --porcelain", || {
            cli(r, &["worktree", "list", "--porcelain"]).len()
        }, ITERS);
    }
    if want("config") {
        bench("config read user.name", "git2 open+config+get_string", || {
            let repo = Repository::open(r).unwrap();
            repo.config().unwrap().get_string("user.name").map(|s| s.len()).unwrap_or(0) + 1
        }, ITERS);
        bench("config read user.name", "CLI config --get user.name", || {
            cli(r, &["config", "--get", "user.name"]).len() + 1
        }, ITERS);
    }
    if want("ancestry") {
        let (h, b) = (head_oid.clone(), c50.clone());
        bench("ahead/behind HEAD vs HEAD~50 (index_state behind_count)", "git2 graph_ahead_behind", || {
            let repo = Repository::discover(r).unwrap();
            let (a, _) = repo.graph_ahead_behind(git2::Oid::from_str(&h).unwrap(), git2::Oid::from_str(&b).unwrap()).unwrap();
            a + 1
        }, ITERS);
        let (h, b) = (head_oid.clone(), c50.clone());
        bench("ahead/behind HEAD vs HEAD~50", "CLI rev-list --count b..h", || {
            cli(r, &["rev-list", "--count", &format!("{b}..{h}")]).len()
        }, ITERS);
        let (h, b) = (head_oid.clone(), c50.clone());
        bench("is-ancestor (merge_worktree uses CLI)", "git2 graph_descendant_of", || {
            let repo = Repository::open(r).unwrap();
            repo.graph_descendant_of(git2::Oid::from_str(&h).unwrap(), git2::Oid::from_str(&b).unwrap()).unwrap() as usize + 1
        }, ITERS);
        let (h, b) = (head_oid.clone(), c50.clone());
        bench("is-ancestor", "CLI merge-base --is-ancestor", || {
            cli(r, &["merge-base", "--is-ancestor", &b, &h]).len() + 1
        }, ITERS);
    }
    if want("fixed") {
        bench("fixed: git rev-parse HEAD in /tmp (not a repo)", "CLI (fails fast)", || {
            cli("/tmp", &["rev-parse", "HEAD"]).len() + 1
        }, ITERS);
        bench("fixed: git --version (no repo access)", "CLI", || {
            let o = Command::new("git").arg("--version").stdin(Stdio::null()).output().unwrap();
            o.stdout.len()
        }, ITERS);
        bench("fixed: /bin/true spawn", "CLI baseline", || {
            let o = Command::new("/bin/true").stdin(Stdio::null()).output().unwrap();
            o.stdout.len() + 1
        }, ITERS);
        // 50 sequential spawns of the cheapest op
        let s = Instant::now();
        for _ in 0..50 {
            let o = Command::new("git").arg("--version").stdin(Stdio::null()).output().unwrap();
            std::hint::black_box(o.stdout.len());
        }
        let tot = s.elapsed().as_secs_f64() * 1000.0;
        println!("50 sequential `git --version` spawns: total {tot:.1} ms = {:.2} ms/spawn", tot / 50.0);
        let s = Instant::now();
        for _ in 0..50 {
            let o = Command::new("git").arg("-C").arg(r).args(["rev-parse", "--git-dir"]).stdin(Stdio::null()).output().unwrap();
            std::hint::black_box(o.stdout.len());
        }
        let tot = s.elapsed().as_secs_f64() * 1000.0;
        println!("50 sequential `git rev-parse --git-dir` spawns: total {tot:.1} ms = {:.2} ms/spawn", tot / 50.0);
        let s = Instant::now();
        for _ in 0..50 {
            let o = Command::new("/bin/true").stdin(Stdio::null()).output().unwrap();
            std::hint::black_box(o.stdout.len());
        }
        let tot = s.elapsed().as_secs_f64() * 1000.0;
        println!("50 sequential `/bin/true` spawns: total {tot:.1} ms = {:.2} ms/spawn", tot / 50.0);
    }
}
