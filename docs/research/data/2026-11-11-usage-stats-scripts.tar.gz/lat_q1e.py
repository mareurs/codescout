import pickle, collections, datetime as dt, bisect
rows=pickle.load(open('lat_rows.pkl','rb'))
P=lambda s: dt.datetime.strptime(s[:23],'%Y-%m-%d %H:%M:%S.%f')
R='/home/marius/work/claude/codescout/.codescout/'
L=[l.rstrip('\n').split('\t') for l in open(R+'usage-lock-holds.log')]
ins=[x for x in L if x[3]=='insert' and x[0]<='2026-11-10 22:23:50']
rs=[r for r in rows if r['ca']>='2026-11-09 20:00']
cas=[P(r['ca']) for r in rs]
matched=0; res=[]
for x in ins:
    s=P(x[0]); ms=int(x[4]); tool=x[5]
    # candidates: rows of tool with ca between s and s+ms+300ms
    i=bisect.bisect_left(cas,s); cand=[]
    j=i
    while j<len(rs) and cas[j]<=s+dt.timedelta(milliseconds=ms+500):
        if rs[j]['tool']==tool: cand.append(rs[j])
        j+=1
    if len(cand)>=1:
        r=cand[0]; res.append(((cas[rs.index(r)]-s).total_seconds()*1000, ms, r['gap'], len(cand)))
print('insert lines',len(ins),'matched',len(res))
import statistics
print('called_at - hold.start vs hold ms (first 12):',[ (round(a),b,round(g)) for a,b,g,n in res[:12]])
close_end=sum(1 for a,b,g,n in res if abs(a-b)<50); close_start=sum(1 for a,b,g,n in res if a<50)
print('called_at within 50ms of hold END:',close_end,' within 50ms of hold START:',close_start)
big=[(a,b,g) for a,b,g,n in res if b>=1000]
print('holds>=1s matched:',len(big),'gap>=0.5*hold:',sum(1 for a,b,g in big if g>=0.5*b))
# sweeps: do rows near them show a gap? sum of sweep ms for 11-09..11-10 vs sum of gap
S=[x for x in L if x[3]=='retention_sweep' and x[0]<='2026-11-10 22:23:50']
print('sweeps',len(S),'sum_s',round(sum(int(x[4]) for x in S)/1000),'>=1s',sum(1 for x in S if int(x[4])>=1000),'deleted values',collections.Counter(x[5] for x in S).most_common(4))
rows2=[r for r in rows if r['ca']>='2026-11-09 20:21']
print('rows in same window',len(rows2),'sum gap s',round(sum(r['gap'] for r in rows2)/1000))
print('sweep ms by tool? n/a')
