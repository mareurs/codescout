import re
SP = "/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad"
s = open(SP + "/bench_mcp2.py").read()
s = s.replace('''def tool(name, args):
    t0 = time.perf_counter()
    m = call("tools/call", {"name": name, "arguments": args})
    dt = (time.perf_counter() - t0) * 1000''', '''def cpu_ticks():
    f = open("/proc/%d/stat" % p.pid).read().rsplit(")", 1)[1].split()
    return sum(int(f[i]) for i in (11, 12, 13, 14))
LASTCPU = [0]
def tool(name, args):
    c0 = cpu_ticks()
    t0 = time.perf_counter()
    m = call("tools/call", {"name": name, "arguments": args})
    dt = (time.perf_counter() - t0) * 1000
    LASTCPU[0] = cpu_ticks() - c0''')
s = s.replace('rec["runs"].append(dict(i=rnd,', 'rec["runs"].append(dict(cpu_ticks=LASTCPU[0], i=rnd,')
open(SP + "/bench_mcp3.py", "w").write(s)
print("ok", "cpu_ticks" in s)
