import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_enrich import *
rows=enrich()
N=len(rows)
print('rows',N,'has_in',sum(r['has_in'] for r in rows),'has_out',sum(r['out']['has_out'] for r in rows))
par=[r for r in rows if r['parent']]; sub=[r for r in rows if not r['parent']]
for nm,s in (('parent',par),('sub',sub)):
    print(nm,len(s),'in',sum(r['has_in'] for r in s),'out',sum(r['out']['has_out'] for r in s))
# by date
bydate=collections.defaultdict(lambda:[0,0,0])
for r in rows:
    d=r['called_at'][:10]; bydate[d][0]+=1; bydate[d][1]+=r['has_in']; bydate[d][2]+=r['out']['has_out']
print('date n in out'); 
for d in sorted(bydate): print(d,*bydate[d])
withi=[r for r in rows if r['has_in']]
keys=collections.Counter()
for r in withi:
    for k in r['ip']: keys[k]+=1
print('KEYS (of %d with input)'%len(withi))
for k,n in keys.most_common(): print(k,n,'%.1f%%'%(100*n/len(withi)))
