import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_enrich import *
import pickle
res=pickle.load(open('grep_q4b.pkl','rb'))
rows={r['id']:r for r in enrich()}
want=sys.argv[1:]
for x in res:
    if any(x['verdict'].startswith(w) for w in want):
        r=rows[x['id']]; ip=r['ip']
        print(x['id'],r['called_at'][:16],x['verdict'][:40],'|',repr(ip.get('pattern'))[:70],'| path',ip.get('path'),'| glob',str(ip.get('glob'))[:50],'| hid',ip.get('include_hidden'),'ic',ip.get('ignore_case'),'| nfiles',x.get('files_in_scope'),'| hits',x.get('hit_files')[:2] if x.get('hit_files') else None, x.get('why'), 'warn' if r['out']['warns'] or r['out']['body'].strip()!='0 matches' else 'bare')
