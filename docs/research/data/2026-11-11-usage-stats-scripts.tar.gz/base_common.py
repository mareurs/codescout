import sqlite3, json, statistics, collections, re
DB='file:/home/marius/work/claude/codescout/.codescout/usage.db?mode=ro'
MAXID=299175
def conn():
    c=sqlite3.connect(DB,uri=True); c.row_factory=sqlite3.Row; return c
def pct(vals,p):
    if not vals: return None
    v=sorted(vals); k=(len(v)-1)*p/100; f=int(k); c=min(f+1,len(v)-1)
    return v[f]+(v[c]-v[f])*(k-f)
def classify_root(r):
    if r is None or r=='': return 'null'
    if r=='/home/marius/work/claude/codescout': return 'main_checkout'
    if '/.codex/worktrees/' in r: return 'codex_worktree'
    if '/.claude/worktrees/' in r: return 'claude_agent_worktree'
    if '/codescout/.worktrees/' in r or '/codescout.worktrees/' in r: return 'repo_worktree'
    if r.startswith('/tmp/'): return 'tmp_harness'
    return 'other'
