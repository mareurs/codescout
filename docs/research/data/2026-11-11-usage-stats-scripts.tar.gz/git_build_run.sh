#!/bin/bash
# usage: git_build_run.sh <proj: hello|g2|gx> <profile: dev|release> [split]
# Clean build (fresh target dir), cwd = scratch dir so the repo's .cargo/config.toml (sccache + mold) is NOT picked up.
# nice 19, 8 jobs; records wall/user/sys (child-tree rusage via wait4) and stripped/unstripped binary size.
SP=/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad
B=$SP/git_build
proj=$1; prof=$2; split=${3:-}
T=$B/target_${proj}_${prof}${split:+_split}
cd "$B" || exit 1
unset CARGO_BUILD_RUSTC_WRAPPER
export RUSTC_WRAPPER=
rm -rf "$T"
export CARGO_BUILD_JOBS=8 CARGO_TARGET_DIR=$T
flag=""; dir=debug
if [ "$prof" = release ]; then flag="--release"; dir=release; fi
OUT=$B/results2_${proj}_${prof}${split:+_split}.txt
R="python3 -I $SP/git_rusage.py nice -n 19 cargo build --offline"
{
  echo "== $proj $prof ${split} start: $(uptime)"
  echo "cwd=$(pwd) RUSTC_WRAPPER='${RUSTC_WRAPPER}'"
  if [ -n "$split" ]; then
    echo "-- step1: -p libgit2-sys (plus its build deps)"
    $R $flag -p libgit2-sys --manifest-path $B/$proj/Cargo.toml
    echo "-- step2: rest"
    $R $flag --manifest-path $B/$proj/Cargo.toml
  else
    $R $flag --manifest-path $B/$proj/Cargo.toml
  fi
  ls -l --block-size=1 $T/$dir/$proj | awk '{print "binary_bytes="$5}'
  echo "end: $(uptime)"
} > "$OUT" 2>&1
echo done $OUT
