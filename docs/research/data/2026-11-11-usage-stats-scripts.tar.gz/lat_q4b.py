import pickle, sqlite3, bisect, datetime as dt, collections
rows=pickle.load(open('lat_rows.pkl','rb'))
P=lambda s: dt.datetime.strptime(s[:19],'%Y-%m-%d %H:%M:%S')
con=sqlite3.connect('file:/home/marius/work/claude/codescout/.codescout/usage.db?mode=ro',uri=True)
ev=[(P(a),l,r,o) for a,l,r,o in con.execute("select started_at,language,reason,outcome from lsp_events where started_at>='2026-10-12 08:00' and started_at<='2026-11-10 22:24' order by started_at")]
def assoc(lang,tools,thr,win=300):
    ts=[e[0] for e in ev if e[1]==lang]
    sel=[r for r in rows if r['tool'] in tools]
    def near(r):
        t=P(r['sa']); i=bisect.bisect_right(ts,t)-1
        return i>=0 and (t-ts[i]).total_seconds()<=win
    slow=[r for r in sel if r['lat']>=thr]; ok=[r for r in sel if r['lat']<thr]
    a=sum(near(r) for r in slow); b=sum(near(r) for r in ok)
    return len(slow),a,len(ok),b
for lang,tools in [('rust',('symbols','references','call_graph','symbol_at','edit_code')),('python',('symbols','references','call_graph','edit_code')),('java',('symbols','references','edit_code')),('kotlin',('symbols','references','edit_code'))]:
    s,a,o,b=assoc(lang,tools,5000)
    print(f"{lang}: slow(>=5s) n={s} within 5min after a {lang} lsp start: {a} ({100*a/max(1,s):.1f}%); ordinary n={o}: {b} ({100*b/max(1,o):.1f}%)")
# lsp starts per day for rust
print(collections.Counter(e[0].strftime('%m-%d') for e in ev if e[1]=='rust').most_common(6))
print('events by language/day total',len(ev))
# failed java starts: time lost
fj=con.execute("select count(*),sum(handshake_ms)/1000.0,min(started_at),max(started_at) from lsp_events where language='java' and outcome='failed' and started_at>='2026-10-12 08:00' and started_at<='2026-11-10 22:24'").fetchall(); print('java failed',fj)
fk=con.execute("select count(*),sum(handshake_ms)/1000.0 from lsp_events where language='kotlin' and outcome='failed' and started_at>='2026-10-12 08:00' and started_at<='2026-11-10 22:24'").fetchall(); print('kotlin failed',fk)
print(con.execute("select error,count(*) from lsp_events where language in ('java','kotlin','rust') and outcome='failed' and started_at<='2026-11-10 22:24' group by 1 order by 2 desc limit 4").fetchall())
