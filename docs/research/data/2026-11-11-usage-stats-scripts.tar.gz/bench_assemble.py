SP = "/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad"
t = open(SP + "/bench_report_template.md").read()
def rep(a, b):
    global t
    assert a in t, a[:60]
    t = t.replace(a, b)
rep("(`mode=files` loop at 316-390ish, lines loop `'outer: for entry in walker` at ~395)", "(`if files_mode {` at 317, its loop `clock.expired` at 332; lines loop `'outer: for entry in walker` at 390, `clock.expired` at 399)")
rep("(block starting ~528)", "(block starting at 525, `// Index-aware hits`)")
rep("the first registry parity attempt at load 70-95 hit the 20 s budget (\"walk cut\") on 3 of 7 patterns (Q1, Q2, Q3 cut at 20.0-25.1 s).", "the first registry parity attempt, at load 70-95, hit the 20 s budget (\"walk cut\" in the response) on all 7 non-PCRE patterns (client wall 20.1-29.5 s per call).")
rep("it lists `git` as unbounded only without a limiter `-n`... (so `git grep -n` counts as bounded by that rule - the text, not a measured refusal).", "its text also says `git` is unbounded only without an output limiter and lists `-n` among the limiters, so by that rule `git grep -n` counts as bounded (that is what the gate text says; I did not find a command it changes).")
rep("With glob scope the picture changes for rg and cs identically: `rg -g '*.txt'` and `grep(glob=\"*.txt\")` both re-admit ignored and hidden files (`ignored.txt`, `ignore_dot.txt`, `tracked_ignored.txt`, `.hidden.txt` all appeared in both) because glob overrides outrank ignore files - note codescout's own warning text says \"a glob cannot re-admit [hidden paths]\" for dirs pruned above, which applies to a hidden parent directory, not to hidden files at the root (observed in the corpus).", "With a glob the picture changes identically for rg and cs: `rg -g '*.txt'` and `grep(glob=\"*.txt\", mode=\"files\")` both re-admitted gitignored and hidden files in the corpus (`ignored.txt`, `ignore_dot.txt`, `tracked_ignored.txt`, `.hidden.txt` appeared in both), because glob overrides outrank ignore files. (In the repo, 4 `*.rs` parity combos still matched exactly.)")
rep(" any directory the host path rules refuse is NOT a limit (cs searched `~/.cargo/registry/src` and the scratchpad by absolute `path`).", " (cs did search `~/.cargo/registry/src` and the scratchpad through an absolute `path`, so outside-project paths are not a limit).")
rep("MISSES (prints \"binary file matches\" only when named explicitly; silent in a recursive walk)", "MISSES (no lines in a recursive walk; named explicitly it prints `binary file matches (found \"\\0\" byte around offset 9618)` on stderr)")
rep("without activation every call (both tools) carried a ~1.7 KB banner listing 27 worktrees (seen in my first driver version) - an agent that never activates pays ~430 tokens per call.", "without an explicit activation every call (grep and run_command) carried a ~2.2 KB banner listing the repo's linked worktrees (seen in my first driver version: 2436 B vs 231 B for the same one-hit grep) - roughly 550 tokens per call for an agent that never activates.")
rep("5-50 ms latency vs 68-296 ms for rg via run_command", "5-108 ms latency (5-50 ms except `^pub fn` repo-wide at 108) vs 68-296 ms for rg via run_command")
rep("cs lines 211-624 ms (symbol enclosure, measured) vs rg 70-82 ms: 2.3-8.6x slower", "cs lines 142-624 ms (symbol enclosure, measured) vs rg 70-82 ms: 2.0-8.6x slower")
rep("also 3-5x less CPU than either |", "also 2.7-2.8x less CPU than either (2.26 s vs 6.2-6.8 s) |")
open(SP + "/bench_report_template.md", "w").write(t)
tables = open(SP + "/bench_tables.md").read()
cpu = open(SP + "/bench_cpu_tables.md").read()
t = t.replace("@@TABLES@@", tables).replace("@@CPU@@", cpu)
open(SP + "/stats-search-bench.md", "w").write(t)
print(len(t))
