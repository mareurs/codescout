import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from base_common import *
c=conn()
print("live DB: rows",c.execute("select count(*),min(id),max(id),min(called_at),max(called_at) from tool_calls").fetchone()[:])
print("snapshot rows older than id 180898:",c.execute(f"select count(*) from tool_calls where id<180898").fetchone()[0])
print("pika_observations table?",c.execute("select count(*) from sqlite_master where name='pika_observations'").fetchone()[0])
rows=c.execute(f"select id,tool_name,outcome,error_msg,session_id,coalesce(agent_id,'') a,project_root,called_at from tool_calls where id<={MAXID} order by id").fetchall()
H='— hint:'
per=collections.defaultdict(list)
for r in rows: per[(r['session_id'],r['a'])].append(r)
st=collections.defaultdict(collections.Counter)
for p,seq in per.items():
    for i,r in enumerate(seq):
        if r['outcome']=='success': continue
        k='hint' if H in r['error_msg'] else 'nohint'
        # restrict to tools in which both occur: run_command only for fairness
        for scope in ('all',r['tool_name']):
            d=st[(scope,k)]; d['n']+=1
            if i+1<len(seq):
                n=seq[i+1]
                if n['outcome']=='success': d['next_ok']+=1
                elif n['tool_name']==r['tool_name']: d['next_err_same_tool']+=1
                else: d['next_err_other_tool']+=1
            else: d['last']+=1
print("| scope | hint? | errors | next call success% | next call error same tool% | next error other tool% |")
for (s,k),d in sorted(st.items()):
    if s in ('all','run_command','read_file','doc','edit_file','edit_code'):
        print(f"| {s} | {k} | {d['n']} | {100*d['next_ok']/d['n']:.1f} | {100*d['next_err_same_tool']/d['n']:.1f} | {100*d['next_err_other_tool']/d['n']:.1f} |")
# hint text clusters: first 40 chars
ht=collections.Counter()
for r in rows:
    if r['outcome']!='success' and H in r['error_msg']: ht[r['error_msg'].split(H,1)[1].strip()[:50]]+=1
print("hint-prefix(50) distinct",len(ht),"top3 prefixes cover",sum(v for _,v in ht.most_common(3)),"top10",sum(v for _,v in ht.most_common(10)),"top 47(>=10 each)",sum(v for _,v in ht.items() if v>=10))
# harness sessions
ses=collections.defaultdict(list)
for r in rows: ses[r['session_id']].append(r)
def cat(p):
    p=p or ''
    if 'setup-ab' in p: return 'setup-ab'
    if p.startswith('/tmp/codescout-'): return '/tmp/codescout-*'
    if p.startswith('/tmp/'): return '/tmp/other'
    if '/.codex/worktrees/' in p: return 'codex worktree'
    return None
tot=collections.Counter(); cs=collections.Counter(); maj=collections.Counter(); majc=collections.Counter()
for s,v in ses.items():
    cc=collections.Counter(cat(r['project_root']) for r in v)
    for k in cc:
        if k: tot[k]+=1; cs[k]+=cc[k]
    h=sum(n for k,n in cc.items() if k)
    if h>=0.5*len(v):
        top=max((k for k in cc if k),key=lambda k:cc[k]); maj[top]+=1; majc[top]+=len(v)
print("sessions touching category / calls in category:",dict(tot),dict(cs))
print("sessions >=50% harness calls by dominant category (sessions):",dict(maj),"calls in those sessions",dict(majc))
print("setup-ab roots:",sorted({r['project_root'] for r in rows if 'setup-ab' in (r['project_root'] or '')})[:10])
print("codex roots:",collections.Counter(r['project_root'] for r in rows if '/.codex/worktrees/' in (r['project_root'] or '')).most_common(10))
print("tmp roots calls:",collections.Counter(r['project_root'] for r in rows if (r['project_root'] or '').startswith('/tmp/')).most_common(10))
# Are codex rows from a different harness? agent_id, tool mix: check codescout sha / cc_session
print("codex session count",len({r['session_id'] for r in rows if '/.codex/worktrees/' in (r['project_root'] or '')}))
