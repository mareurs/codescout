import json, re, subprocess, os
SP = "/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad"
R = "/home/marius/work/claude/codescout"
d = {r["label"]: r for r in json.load(open(SP + "/bench_out_lp.json"))["results"]}
def rgset(args, path=None, w=False):
    c = ["rg", "-n"] + (["-w"] if w else []) + ["-e", args] + ([path] if path else [])
    out = subprocess.run(c, cwd=R, capture_output=True, text=True, errors="replace").stdout
    return {(m.group(1).removeprefix("./"), int(m.group(2))) for m in (re.match(r"^(.*?):(\d+):", l) for l in out.splitlines()) if m}
def cs_from_text(t):
    s = set(); cur = None
    for ln in t.splitlines():
        m = re.match(r"^(\S.*) \((\d+)\)$", ln)
        if m: cur = m.group(1); continue
        m = re.match(r"^\s+(\d+): ", ln)
        if m and cur: s.add((cur, int(m.group(1))))
    return s
def cs_from_json(p):
    j = json.load(open(p)); return {(g["file"], it["line"]) for g in j["file_groups"] for it in g["items"]}, j.get("total"), j.get("files"), {k: j[k] for k in j if k not in ("file_groups",)}
cases = [("L1", rgset("fn clamp_match")), ("L2", rgset("wall-clock budget")), ("L3", rgset("Result<Value>", "src/")), ("L4", rgset("TODO|FIXME", "src/")),
         ("L5", rgset("TODO|FIXME")), ("L6", rgset("Agent", "src/tools/", True))]
for k, rs in cases:
    jp = f"{SP}/lp/{k}.json"
    if os.path.exists(jp): cs, tot, files, meta = cs_from_json(jp)
    else: cs = cs_from_text(d[k]["text_last"]); meta = {}
    print(k, "rg", len(rs), "cs", len(cs), "equal" if rs == cs else "DIFF only_rg=%d only_cs=%d" % (len(rs - cs), len(cs - rs)), "meta", {a: (b if not isinstance(b, (list, str)) else str(b)[:60]) for a, b in meta.items()})
    if rs != cs and k != "L5": print("   only_rg", sorted(rs - cs)[:3], "only_cs", sorted(cs - rs)[:3])
