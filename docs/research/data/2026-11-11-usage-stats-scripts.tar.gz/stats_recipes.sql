.headers on
.mode column
-- R1 corpus size and error rate
SELECT COUNT(*) AS rows_n, MIN(id) AS min_id, MAX(id) AS max_id, SUM(outcome<>'success') AS errors FROM tool_calls WHERE id<=299175;
-- R2 call mix
SELECT tool_name, COUNT(*) AS n, ROUND(100.0*COUNT(*)/(SELECT COUNT(*) FROM tool_calls WHERE id<=299175),2) AS share_pct FROM tool_calls WHERE id<=299175 GROUP BY tool_name ORDER BY n DESC LIMIT 6;
-- R3 recorder gap (wall time minus latency_ms), percentiles
WITH g AS (SELECT (julianday(called_at)-julianday(started_at))*86400000.0 - latency_ms AS gap FROM tool_calls WHERE id<=299175 AND started_at IS NOT NULL), o AS (SELECT gap, ROW_NUMBER() OVER (ORDER BY gap) AS rn, COUNT(*) OVER () AS n FROM g) SELECT ROUND(MIN(CASE WHEN rn>=n*0.5 THEN gap END)) AS p50, ROUND(MIN(CASE WHEN rn>=n*0.9 THEN gap END)) AS p90, ROUND(MIN(CASE WHEN rn>=n*0.99 THEN gap END)) AS p99 FROM o;
-- R4 latency percentiles for one tool (here grep)
WITH o AS (SELECT latency_ms AS v, ROW_NUMBER() OVER (ORDER BY latency_ms) AS rn, COUNT(*) OVER () AS n FROM tool_calls WHERE id<=299175 AND tool_name='grep') SELECT MIN(CASE WHEN rn>=n*0.5 THEN v END) AS p50, MIN(CASE WHEN rn>=n*0.9 THEN v END) AS p90, MIN(CASE WHEN rn>=n*0.99 THEN v END) AS p99 FROM o;
-- R5 share of summed latency by tool
SELECT tool_name, SUM(latency_ms)/1000 AS sum_s, ROUND(100.0*SUM(latency_ms)/(SELECT SUM(latency_ms) FROM tool_calls WHERE id<=299175),1) AS share_pct FROM tool_calls WHERE id<=299175 GROUP BY tool_name ORDER BY sum_s DESC LIMIT 3;
-- R6 run_command timeouts recorded as success
SELECT outcome, COUNT(*) AS n FROM tool_calls WHERE id<=299175 AND tool_name='run_command' AND output_json LIKE '%timed_out%: true%' GROUP BY outcome;
-- R7 bare zero-match grep results
SELECT COUNT(*) AS bare_zero FROM tool_calls WHERE id<=299175 AND tool_name='grep' AND output_json='[{"type":"text","text":"0 matches"}]';
-- R8 grep calls that pass head_limit (silently ignored)
SELECT COUNT(*) AS head_limit_calls, ROUND(100.0*COUNT(*)/(SELECT COUNT(*) FROM tool_calls WHERE id<=299175 AND tool_name='grep'),1) AS pct FROM tool_calls WHERE id<=299175 AND tool_name='grep' AND input_json LIKE '%"head_limit"%';
-- R9 errors that carry a hint
SELECT COUNT(*) AS errors, SUM(error_msg LIKE '%— hint:%') AS with_hint FROM tool_calls WHERE id<=299175 AND outcome<>'success';
-- R10 error families
SELECT err_family, COUNT(*) AS n FROM tool_calls WHERE id<=299175 AND outcome<>'success' GROUP BY err_family ORDER BY n DESC LIMIT 6;
-- R11 project-wide symbols(name) with no path
SELECT COUNT(*) AS n FROM tool_calls WHERE id<=299175 AND tool_name='symbols' AND input_json LIKE '%"name"%' AND input_json NOT LIKE '%"path"%';
-- R12 coverage: rows without input_json / output_json
SELECT SUM(input_json IS NULL OR input_json='') AS no_input, SUM(output_json IS NULL OR output_json='') AS no_output FROM tool_calls WHERE id<=299175;
-- R13 retention sweep plan (expect SCAN tool_calls)
EXPLAIN QUERY PLAN DELETE FROM tool_calls WHERE called_at < datetime('now','-30 days');
