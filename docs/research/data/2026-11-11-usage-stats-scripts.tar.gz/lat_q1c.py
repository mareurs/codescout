import pickle, collections, re
rows=pickle.load(open('lat_rows.pkl','rb'))
# suspend check
for a,b in [('2026-10-20 17:59:10','2026-10-21 03:44:28'),('2026-11-02 19:59:07','2026-11-03 04:32:37')]:
    inside=[r for r in rows if a<=r['ca']<=b]
    print(a,b,'rows completing inside window (all tools):',len(inside), [ (r['id'],r['ca'],r['tool']) for r in inside[:6]])
    # rows before and after
    before=[r for r in rows if r['ca']<a][-1]; after=[r for r in rows if r['ca']>b][0]
    print(' last before',before['ca'],'first after',after['ca'])
# gap>1000 per day
d=collections.Counter(r['ca'][:10] for r in rows if r['gap']>1000)
n=collections.Counter(r['ca'][:10] for r in rows)
print("day: n, gap>1000 count, share, gap sum s (excl >1h)")
for k in sorted(n):
    g=sum(r['gap'] for r in rows if r['ca'][:10]==k and r['gap']<3.6e6)/1000
    print(k,n[k],d[k],f"{100*d[k]/n[k]:.1f}%",round(g))
