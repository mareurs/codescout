#!/usr/bin/env python3
"""usage: bench_hf.py SCOPE RUN -> writes hf/hf_SCOPE_RUN.sh and runs it after a load wait; records load before/after"""
import sys, shlex, subprocess, time, os
sys.path.insert(0, "/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad")
import bench_common as b
scope, run = sys.argv[1], sys.argv[2]
maxwait = int(sys.argv[3]) if len(sys.argv) > 3 else 0
s = b.SCOPES[scope]; pats = b.RPATS if scope == "reg" else b.PATS
os.makedirs(b.SP + "/hf", exist_ok=True)
out = f"{b.SP}/hf/hf_{scope}_{run}.json"
args = ["hyperfine", "-i", "--warmup", "2", "--runs", "15", "--output", "pipe", "--export-json", out]
for p in pats:
    args += ["-n", f"{p[chr(105)+chr(100)]}|{scope}|rg", b.rg_cmd(p, s), "-n", f"{p[chr(105)+chr(100)]}|{scope}|gg", b.gg_cmd(p, s)]
waited = 0
while waited < maxwait and float(open("/proc/loadavg").read().split()[0]) >= 12:
    time.sleep(5); waited += 5
before = open("/proc/loadavg").read().strip()
t0 = time.time()
r = subprocess.run(args, cwd=b.ROOT, capture_output=True, text=True)
after = open("/proc/loadavg").read().strip()
open(f"{b.SP}/hf/load_{scope}_{run}.txt", "w").write(f"before(loadavg 1/5/15 ...): {before} waited={waited}s\nafter: {after}\nelapsed={time.time()-t0:.0f}s rc={r.returncode}\n{r.stderr[-500:]}\n")
print(open(f"{b.SP}/hf/load_{scope}_{run}.txt").read())
