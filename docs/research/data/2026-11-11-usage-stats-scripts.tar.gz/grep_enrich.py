import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_common import *
import os
PROJ='/home/marius/work/claude/codescout'
def parse_out(r):
    """returns dict: text, env(bool: json overflow envelope), body(str after warnings), header info"""
    oj=r['oj']
    d={'has_out': bool(oj)}
    if not oj: return d
    t=out_text(oj)
    d['bytes']=len(oj.encode('utf8','ignore'))
    env=False
    body=t
    if t.startswith('{'):
        try:
            j=json.loads(t)
            if isinstance(j,dict) and 'output_id' in j:
                env=True; body=j.get('summary','')
                d['env_hint']=j.get('hint','')
        except Exception: pass
    d['env']=env
    d['text']=t
    # strip leading warning blocks (start with ⚠, until blank line)
    warns=[]
    b=body
    while b.startswith('⚠'):
        parts=b.split('\n\n',1)
        warns.append(parts[0]); b=parts[1] if len(parts)>1 else ''
    d['warns']=warns
    d['body']=b
    first=b.split('\n',1)[0]
    d['first']=first
    m=re.match(r'^(\d+) (match|matches)( \(capped\))?( in (\d+) files)?$',first)
    n=None; kind=None
    if m:
        n=int(m.group(1)); kind='count'; d['capped']=bool(m.group(3)); d['nfiles']=int(m.group(5)) if m.group(5) else None
    else:
        m2=re.match(r'^(\S.*) \((\d+)\)$',first)
        if m2: kind='single_file_group'; n=int(m2.group(2)); d['capped']=False
    d['n']=n; d['hkind']=kind
    d['zero']= (b.strip().startswith('0 matches'))
    return d
def qpath(ip):
    p=ip.get('path') if ip else None
    return p
def path_class(p):
    if p is None or p in ('','.','./'): return 'root'
    if p.startswith('@'): return 'buffer'
    if p.startswith('/'):
        if p.rstrip('/')==PROJ: return 'root'
        if p.startswith(PROJ+'/'): rel=p[len(PROJ)+1:]
        else: return 'abs_outside'
    else: rel=p
    last=rel.rstrip('/').split('/')[-1]
    if re.search(r'\.[A-Za-z0-9]{1,6}$',last) and not rel.endswith('/'): return 'file'
    return 'subdir'
def enrich():
    rows=load()
    for r in rows:
        r['ip']=inp(r['ij'])
        r['has_in']=r['ip'] is not None
        r['out']=parse_out(r)
        r['parent']= r['aid'] is None
    return rows
