import pickle, collections, re
rows=pickle.load(open('lat_rows.pkl','rb'))
def pct(v,q):
    v=sorted(v)
    if not v: return 0
    k=(len(v)-1)*q; f=int(k); c=min(f+1,len(v)-1); return v[f]+(v[c]-v[f])*(k-f)
WAIT=re.compile(r'\b(until|while|sleep)\b|pgrep -f')
def is_wait(r): return r['tool']=='run_command' and r['cmd'] is not None and bool(WAIT.search(r['cmd']))
def at_to(r):
    if r['tool']!='run_command': return False
    if r['timed_out']: return True
    T=r['tmo'] if r['tmo'] else (30 if r['has_in'] else None)
    if T is None: return False
    return 0<=r['lat']-T*1000<=300
for r in rows:
    r['wait']=is_wait(r); r['to']=at_to(r)
rc=[r for r in rows if r['tool']=='run_command']
print('rc rows:',len(rc),'with cmd text',sum(r['cmd'] is not None for r in rc),'wait',sum(r['wait'] for r in rc),'at_timeout(flag or lat within [T,T+300ms])',sum(r['to'] for r in rc),'flag',sum(bool(r['timed_out']) for r in rc),'both',sum(r['wait'] and r['to'] for r in rc))
def table(rs,title):
    tot=sum(r['lat'] for r in rs)
    by=collections.defaultdict(list)
    for r in rs: by[r['tool']].append(r['lat'])
    print(f'\n### {title}  (rows {len(rs)}, total {round(tot/1000)} s = {tot/3.6e6:.2f} h)\n')
    print('| tool | n | p50 | p75 | p90 | p95 | p99 | max | sum_s | share |')
    print('|---|---|---|---|---|---|---|---|---|---|')
    for t,v in sorted(by.items(),key=lambda kv:-sum(kv[1])):
        print(f"| {t} | {len(v)} | {pct(v,.5):.0f} | {pct(v,.75):.0f} | {pct(v,.9):.0f} | {pct(v,.95):.0f} | {pct(v,.99):.0f} | {max(v)} | {sum(v)/1000:.0f} | {100*sum(v)/tot:.1f}% |")
table(rows,'ALL rows (latency_ms, ms)')
ex=[r for r in rows if not (r['wait'] or r['to'])]
table(ex,'EXCLUDING run_command wait loops and rows at timeout')
# the excluded breakdown
exr=[r for r in rc if r['wait'] or r['to']]
print('\nexcluded run_command rows:',len(exr),'sum_s',round(sum(r['lat'] for r in exr)/1000),'of rc sum',round(sum(r['lat'] for r in rc)/1000))
print(' wait only',sum(1 for r in exr if r['wait'] and not r['to']),round(sum(r['lat'] for r in exr if r['wait'] and not r['to'])/1000),'s;  timeout only',sum(1 for r in exr if r['to'] and not r['wait']),round(sum(r['lat'] for r in exr if r['to'] and not r['wait'])/1000),'s; both',sum(1 for r in exr if r['to'] and r['wait']),round(sum(r['lat'] for r in exr if r['to'] and r['wait'])/1000),'s')
# rc categories (non-excluded)
CATS=[('gate.sh',r'gate\.sh'),('cargo build/test/clippy/nextest',r'\bcargo\b|nextest|rb\.sh|with-slot'),('pytest/python tests',r'pytest|python3? .*test|unittest'),('git',r'^\s*(cd [^;&]+&&\s*)?git '),('sqlite3',r'sqlite3'),('python3 script',r'python3?'),('curl/ssh/net',r'curl|ssh |wget'),('docker/other build',r'docker|make |npm|gradle|mvn')]
def cat(r):
    c=r['cmd']
    if c is None: return 'no-input-recorded'
    for n,p in CATS:
        if re.search(p,c): return n
    return 'other'
print('\n### run_command by category (all rc rows; wait/timeout flagged separately)\n| category | n | p50 | p90 | p99 | sum_s | share of rc time |\n|---|---|---|---|---|---|---|')
tot=sum(r['lat'] for r in rc)
byc=collections.defaultdict(list)
for r in rc:
    k=('WAITLOOP' if r['wait'] else ('AT-TIMEOUT' if r['to'] else cat(r)))
    byc[k].append(r['lat'])
for k,v in sorted(byc.items(),key=lambda kv:-sum(kv[1])):
    print(f"| {k} | {len(v)} | {pct(v,.5):.0f} | {pct(v,.9):.0f} | {pct(v,.99):.0f} | {sum(v)/1000:.0f} | {100*sum(v)/tot:.1f}% |")
# rc quantiles
v=[r['lat'] for r in rc]; print('\nrc overall p50 p90 p99 max',[round(pct(v,q)) for q in (.5,.9,.99)],max(v))
# slowest 512 wait share
s=sorted(rc,key=lambda r:-r['lat'])[:512]
print('slowest 512: wait',sum(r['wait'] for r in s),'to',sum(r['to'] for r in s),'either',sum(r['wait'] or r['to'] for r in s),'no cmd',sum(r['cmd'] is None for r in s))
