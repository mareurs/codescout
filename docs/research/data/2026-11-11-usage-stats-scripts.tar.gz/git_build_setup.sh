#!/bin/bash
# Create three scratch crates for clean build time / size measurements.
SP=/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad
B=$SP/git_build
mkdir -p $B/hello/src $B/g2/src $B/gx/src
PROFILE='
[workspace]

[profile.dev]
opt-level = 0
debug = 1

[profile.dev.build-override]
opt-level = 3

[profile.release]
opt-level = 3
lto = false
codegen-units = 16
strip = true
panic = "abort"
'
cat > $B/hello/Cargo.toml <<EOF
[package]
name = "hello"
version = "0.1.0"
edition = "2021"
$PROFILE
EOF
cat > $B/hello/src/main.rs <<'EOF'
fn main() {
    let p = std::env::args().nth(1).unwrap_or_else(|| ".".into());
    println!("{}", p.len());
}
EOF
cat > $B/g2/Cargo.toml <<EOF
[package]
name = "g2"
version = "0.1.0"
edition = "2021"

[dependencies]
git2 = { version = "0.20", default-features = false, features = ["vendored-libgit2"] }
$PROFILE
EOF
cat > $B/g2/src/main.rs <<'EOF'
use git2::{Repository, Sort, StatusOptions};
fn main() {
    let p = std::env::args().nth(1).unwrap_or_else(|| ".".into());
    let repo = Repository::discover(&p).unwrap();
    let head = repo.head().unwrap().peel_to_commit().unwrap();
    let mut w = repo.revwalk().unwrap();
    w.push_head().unwrap();
    w.set_sorting(Sort::TIME).unwrap();
    let n = w.take(200).count();
    let mut o = StatusOptions::new();
    o.include_untracked(true);
    let st = repo.statuses(Some(&mut o)).unwrap().len();
    let idx = repo.index().unwrap().len();
    let t = head.tree().unwrap();
    let d = repo.diff_tree_to_tree(None, Some(&t), None).unwrap().deltas().len();
    let b = repo.blame_file(std::path::Path::new("Cargo.toml"), None).map(|b| b.len()).unwrap_or(0);
    println!("{} {} {} {} {} {}", head.id(), n, st, idx, d, b);
}
EOF
cat > $B/gx/Cargo.toml <<EOF
[package]
name = "gx"
version = "0.1.0"
edition = "2021"

[dependencies]
gix = { version = "0.84", default-features = false, features = ["sha1", "revision", "index", "status", "blob-diff", "blame", "parallel"] }
$PROFILE
EOF
cat > $B/gx/src/main.rs <<'EOF'
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let p = std::env::args().nth(1).unwrap_or_else(|| ".".into());
    let repo = gix::discover(&p)?;
    let id = repo.head_id()?;
    let n = repo.rev_walk([id.detach()]).all()?.take(200).count();
    let idx = repo.index()?.entries().len();
    let tree = repo.head_commit()?.tree()?;
    let d = repo.empty_tree().changes()?.for_each_to_obtain_tree(&tree, |_c| Ok::<_, std::convert::Infallible>(std::ops::ControlFlow::Continue(())));
    let st = repo.status(gix::progress::Discard)?.into_index_worktree_iter(Vec::<gix::bstr::BString>::new())?.count();
    println!("{} {} {} {} {}", id, n, idx, d.is_ok(), st);
    Ok(())
}
EOF
echo created
