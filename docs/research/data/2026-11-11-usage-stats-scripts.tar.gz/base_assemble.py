base='/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad/'
def rd(n): return open(base+n).read().rstrip()
head=rd('base_head.md').replace("= 3,928 (2.. probe on the live DB says 3,930: +2 rows after the snapshot)","= 3,928 (friction-probe on the live DB at run time said 3,930: rows added after the snapshot)")
S=[head]
S.append('''
## 1. CALL MIX (script base_s1.py)

Raw output below. Coverage: calls/outcome/overflow/agent_id/project_root are 100% populated (no NULLs), so section 1 is not affected by the input/output gaps.

```
'''+rd('base_s1.out')+'''
```

Notes:
- `read_file` shows 0 overflow rows, but it DOES buffer: its oversized-file answer is an outline text plus `Buffer: @file_xxxx` (not a JSON `output_id` envelope), so `overflowed` and `emitted_output_id` never record it. 2,223 of the 11,043 read_file rows that have output_json (20.1%) contain an `@file_` handle (query: `output_json like '%@file_%'`); 1,282 later read_file calls name an `@file_` path. Blind spot of the overflow column, not absence of overflow.
- Hard `error` is 45 rows (1.1% of errors). 3,883 / 3,928 = 98.9% of errors are `recoverable_error`.
- Weekly table: weeks start Monday UTC; the 11-09 week has only 2 days (Mon, Tue). The 10-19 week has a 47 h hole (Oct 25, section 5).
- Trend (weekly share, first week to last week): doc 2.7 -> 11.6%, symbols 7.5 -> 13.8%, grep 11.3 -> 4.5%, edit_file 9.4 -> 4.8%, run_command 41.7 -> 38.8%. HYPOTHESIS (not tested): doc growth tracks tracker/librarian-heavy work; grep/edit_file share in mid October is lifted by the Oct 16-19 subagent-fleet sessions (grep is 57.1% subagent, edit_file 49.6%).
''')
S.append('''
## 2. SESSIONS AND AGENTS (scripts base_s2.py, base_s9.py)

Coverage: session_id, agent_id, cc_session_id fully populated.

```
'''+rd('base_s2.out')+'''
```

Additional (base_s9.py): harness sessions by category (a session counts once per category it touches): `/tmp/codescout-*` 27 sessions (4,727 calls), `~/.codex/worktrees` 47 sessions (7,658 calls), `setup-ab` 9 sessions (2,243 calls), other `/tmp/*` 3 sessions (14 calls). Sessions with >= 50% of their calls in harness roots: 15 `/tmp/codescout-*` (6,968 calls), 25 codex (3,137), 3 setup-ab (2,703), 2 other (13). Many sessions are mixed (the "sessions harness" line in the output above: 79 with some harness calls, 3 all-harness): a session's `project_root` changes with `workspace(activate)`/pins, e.g. session cb06fa74 (4,771 calls) spans `/tmp/codescout-real-task-20261024` (3,572 calls) and a codex worktree. `cc_session_id` and `session_id` disagree: 72 of 710 cc_session_ids map to >1 session_id.

Reading the table: "sessions started" uses the first call inside the window, so sessions that began before 2026-10-12 08:06 count as started on 10-12. The brief's trap holds: the largest session (500c9b13) has 50 and e98b5705 has 55 distinct agent_ids interleaving inside one session_id.
''')
S.append('''
## 3. OUTPUT SIZE = CONTEXT COST (scripts base_s3.py, base_s3b.py, base_s3c.py)

Coverage: output_json exists on 75,061 of 118,278 rows (63.5%): parent 35,164 of 78,381 (44.9%), subagent 39,897 of 39,897. Per-tool coverage is in the table. Tools with low coverage (symbols 34%, doc 37%, memory 23%, call_graph 3%) are the ones parents call most, so their size statistics describe mostly subagent calls. overflow_tokens/overflowed/emitted_output_id are populated for all rows (not debug-gated).

```
'''+rd('base_s3.out')+'''
```

Overflowed rows with output (inline envelope size versus what sits behind the handle), base_s3c.py. `buffered_bytes` parsed on 1,121 rows only (the symbols/grep/doc/librarian envelopes carry it; the run_command envelope does not). Also: non-overflowed outputs over 10,000 chars exist (run_command 196, doc 142, workspace 120, get_guide 113, read_file 103, symbols 40): not everything large is buffered.

```
'''+rd('base_s3c.out')+'''
```

Buffer read-back (base_s3b.py). "read back" = a LATER call in the same session whose arguments name that handle (named, not necessarily resolved). Handles are keyed by (session_id, handle) because `@bg_*` counters restart per server process (4,678 distinct handle strings vs 7,130 (session,handle) pairs). The "next call" table looks at the next call of the same principal after the emitting call. For `bg` rows "reads the buffer" mostly means polling the job with `tail @bg_x`.

```
'''+rd('base_s3b.out')+'''
```

Notes: `overflow_tokens` is populated only for the 1,913 non-run_command overflow rows (all 5,297 run_command overflow rows have NULL/0 tokens: 3,247 bg handles + 2,050 `@cmd_` buffers). 13,362,884 tokens summed. Handles read but never emitted in-snapshot by the same session (1,447 of 4,957 handle pairs: `@file` 700, `@ack` 378, `@cmd` 193, `@bg` 125, `@tool` 51) come from read_file buffers (not recorded as emitted), ack handles, handles from rows older than the snapshot, or handles merely quoted in prose.
''')
S.append('''
## 4. ERRORS AND RETRY SHAPE (scripts base_s4.py, base_s4b.py; probe JSON base_probe.json)

Coverage: outcome/error_msg/err_family fully populated for error rows. friction-probe was run on the live DB (118,303 rows, 3,930 errors at run time; my snapshot has 3,928); my own re-computation on the snapshot matches it (286 immediate repeats; identical run histogram when keyed by session_id).
Per TU-7: counts below are NOT friction ranks; the largest families are mostly the project's own gates being obeyed. Retry shape is the signal.

```
'''+rd('base_s4.out')+'''
```

Probe families (immediate repeat = the very next call in the same session is an error with the same signature; calls-to-recovery = calls up to and including the next success in the same session, cap 25, unrecovered excluded), then my own per-tool recomputation keyed two ways (session_id as the probe does; and (session_id, agent_id) principal, which is the more correct key because subagents interleave inside one session_id):

```
'''+rd('base_s4b.out')+'''
```

Derived (arithmetic from the tables above): the five gate/teach families il3_pipe_to_trimmer 722 + il3_shell_on_source 498 + il1_read_overlaps_symbol 356 + il2_structural_edit 255 + librarian_managed_artifact 202 = 2,033 = 51.8% of errors; the two il3 families alone are 1,220 of run_command's 1,271 errors (96.0%).
Hint share: 3,081 of 3,928 errors (78.4%) carry `— hint:` (all recoverable_error; 0 of the 45 hard errors do). The brief's "about 3,065" is slightly lower; 3,081 is the snapshot figure. 847 errors have no hint: run_command 723, doc 80, edit_code 16, create_file 11, edit_file 5, others 12.
err_family IS NULL: 171 errors (4.4%): doc 78, read_file 26, edit_file 18, run_command 13, edit_code 10; 154 recoverable + 17 hard. Top 60-char prefixes are in the output above (a bucket, not a cause).
''')
S.append('''
## 5. TIME SERIES (script base_s5.py)

Coverage: called_at is the completion time, UTC, fully populated. Day 2026-10-12 is partial (starts 08:06), 2026-11-10 partial (ends 22:23).

```
'''+rd('base_s5.out')+'''
```

Explanations (checked against the daily table's top root class / top session columns, and for hours by a direct query):
- 2026-10-25 (Sun): zero rows; the gap is 47.2 h (2026-10-24 15:37 to 10-26 14:48). Cause not determinable from the data.
- Oct 16-19 (5,595 / 9,333 / 4,951 / 2,258 calls, subagent share 66-95%): claude_agent_worktree roots; sessions e98b5705 (8,399 calls, 55 subagent ids) and 500c9b13 (8,777 calls, 50 subagent ids) - a subagent-fleet campaign. The busiest hour, 2026-10-17 07 UTC (1,402 calls), is session 500c9b13 across several `agent-*` worktrees (verified by query).
- 2026-10-24 03 UTC (1,240 calls, 4th busiest hour): mixed sessions (9fba5b92 main checkout 269, cb06fa74 codex worktree 162, 5b936994 two `fix-*` worktrees 214), not one harness.
- Nov 9 peak day (10,385 calls, 76 sessions active, 70 started that day): main checkout 75%, many short sessions; on Nov 10 codex session ac7fb73b is 49% of calls.
- Saturdays have the highest mean calls/day (6,344 vs 3,171-3,746 other weekdays) but 4 Saturdays only; Oct 17 alone is 9,333 of the 25,374 Saturday calls.
- Hours 06-19 UTC are 4.1-7.1% each; 00-02 UTC 0.2-0.4%; 23 UTC 1.0%.
''')
S.append('''
## 6. BUILD IDENTITY (script base_s6.py)

Coverage: codescout_sha, codescout_dirty, project_sha 100% populated. `codescout_sha` is the build provenance (BuildProvenance) of the codescout server binary that served the call, plus a dirty bit; `project_sha` is the HEAD of the project the call ran against (457 distinct).

```
'''+rd('base_s6.out')+'''
```

Caveats: commit dates are the committer date of each sha resolved in this repo (all 141 shas resolve, 100% of calls). A build can be compiled after its commit date, so "age" is an UPPER bound of binary age. `experiments` is rebased routinely, so committer dates can differ from original authoring dates. A `dirty` build contains uncommitted changes, so its sha does not identify its code. The 4 biggest shas (3923da8c, 0007d926, 0eb6190ec, 2acc553ad) are dirty builds each served by only 1-9 long-lived server processes (sessions column).
''')
S.append('''
## 7. RECORDING HEALTH (scripts base_s7a.py, base_s7b.py)

Definitions found in code:
- `effect_class` (src/usage/db.rs open_db migration): what a `run_command` caller DECLARED - `read` or `write` (write = default when it said nothing). NULL for all other tools. A declaration, not an observation.
- `observed_changed` (src/usage/observed.rs; db.rs migration comment): `1` = a before/after snapshot of git-visible state (HEAD + `git status` paths with size/mtime) DIFFERED during a run_command that declared `read`; `0` = no difference seen (NOT proof it changed nothing; blind to gitignored paths, /tmp, $HOME); NULL = not observed (write-declared, background, buffer-handle commands, errors, held-for-ack, non-git repo, git over 2 s, other tools). `1` on a shared checkout can be a peer's edit: a falsifier of "quiet", not attribution.
- `attribution_outcome` / `attribution_ms` (src/usage/attribution_outcome.rs; db.rs migration comment): what the red-attribution engine did on a run_command with a NON-ZERO exit: `hinted` (printed a hint), `silent` (finished, printed nothing), `timed_out`, `tooling_failure`, `spawn_failed`; NULL = engine did not start (exit 0 with nothing failure-shaped, opt-out, or row older than the migration; first non-NULL row 2026-11-01 14:42). ms = wall time of the engine run.
- `deliveries_json` (src/usage/deliveries.rs): NULL = the post-phase fan-out never ran (tool returned Err, tool overrides call_content, or pre-migration); `[]` = ran, nothing delivered; `[{engine, ledger_keys, blocks:[{sha256,bytes}], hint}]` = one record per contributing engine.
- `usage-dropped-rows.log` (src/usage/mod.rs note_dropped_row): tab-separated `started_at, tool, pin (- if none), error chain, pid, build(+dirty), wait_ms`; older 4-field lines (no pid/build/wait_ms) coexist (71 of 186 read). `usage-lock-holds.log` (src/usage/db.rs note_lock_hold): `started_at, pid, build, kind (backfill|insert|retention_sweep), ms, detail`, written only when one write statement held the DB >= 250 ms (LOCK_HOLD_LOG_MS). Both logs start 2026-11-09 (issue 2026-11-09-concurrent-pinned-calls-leave-no-usage-row): they cover ~1.5 days, not the corpus.
- Retention: `write_record` runs `DELETE FROM tool_calls WHERE called_at < datetime('now','-30 days')` (sparing rows referenced by `pika_observations`) after EVERY insert (db.rs write_record). The live table's min id is 180898 = the snapshot's min id, so everything earlier is gone; every count here is a floor on all-time and the window is ~30 days.

Output of base_s7a.py (logs; unbounded, read at analysis time) and base_s7b.py (DB, snapshot-bounded):

```
'''+rd('base_s7a.out')+'''
```

```
'''+rd('base_s7b.out')+'''
```

Bounded counts: dropped-log lines with timestamp <= snapshot end (2026-11-10 22:23:51.553): 143 (the file had 193 lines at last read; it grows while other sessions run). Rows stored in the snapshot from the first drop line (2026-11-09 13:12:49) to the end: 11,946, so about 1.2% (143 / (143 + 11,946)) of attempted calls in that ~33 h window left no row (approximation: drops are attributed to the DB they would have been written to, pins can route elsewhere). Every dropped line read has the one reason `database is locked: Error code 5: database is locked`; wait_ms p50 5,008 (the 5 s busy_timeout).
Retention sweep (hold log): in the s7a read, 860 of 1,315 hold lines are `retention_sweep` (p50 2,654 ms, max 20,004 ms; 2,404 s of 3,302 s total logged hold time). In a later read of the log, 862 sweep lines had `deleted=0` and only 10 deleted 1-5 rows. So the sweep is a no-op DELETE that holds the single writer lock for seconds: it is the largest holder class. Why it is slow (e.g. no index on called_at) is NOT verified.
Observed_changed: of 19,204 read-declared run_commands, 11,425 are 0, 234 are 1 (all on success rows), 7,545 NULL; write-declared 32,161 all NULL.
''')
S.append('''
## 8. HINTS AND GUIDES (scripts base_s8.py, base_s4.py, base_s9.py)

Coverage: deliveries_json is NULL on 3,980 rows = all 3,928 error rows + 52 success rows (an Err never reaches the fan-out), so error rows never carry a delivery record. 5,564 rows (4.7%) have a non-empty delivery; 108,734 are `[]`; no row has more than one engine entry. The `cs-hint` substring in output_json is NOT counted (echoed file content).

```
'''+rd('base_s8.out')+'''
```

Error-hint next-call outcome (base_s9.py; next call of the same principal after an error; descriptive only, confounded by tool mix because no-hint errors are mostly run_command):

```
'''+rd('base_s9.out')+'''
```

Hint texts: 1,135 distinct strings after `— hint:` (994 after replacing digit runs with `#`; 918 occur once; 47 occur >= 10 times). Many embed paths/ids, so the distinct count overstates distinct advice. Top 10 hint texts are in the base_s4.out section.
''')
open(base+'stats-baseline_body.md','w').write('\n'.join(S))
print(len('\n'.join(S)))
