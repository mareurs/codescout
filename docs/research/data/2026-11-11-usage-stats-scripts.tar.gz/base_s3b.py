import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from base_common import *
c=conn()
rows=c.execute(f"select id,tool_name,session_id,coalesce(agent_id,'') a,outcome,overflowed,emitted_output_id e,read_output_ids rd,substr(input_json,1,300) inp from tool_calls where id<={MAXID} order by id").fetchall()
byp=collections.defaultdict(list)
for r in rows: byp[(r['session_id'],r['a'])].append(r)
# emitted handles keyed by session
emitted=collections.defaultdict(list)  # (session,handle)->[row]
for r in rows:
    if r['e']: emitted[(r['session_id'],r['e'])].append(r)
reads=collections.defaultdict(list)
for r in rows:
    if r['rd'] and r['rd']!='[]':
        try: l=json.loads(r['rd'])
        except Exception: l=[]
        for h in l: reads[(r['session_id'],h)].append(r)
print("emitted (session,handle) keys",len(emitted),"rows",sum(len(v) for v in emitted.values()))
# readback by emitter tool and prefix, same session after emission
st=collections.defaultdict(lambda: collections.Counter())
for (s,h),em in emitted.items():
    e0=em[0]; pre=h[:4] if h.startswith('@bg') else h.split('_')[0]
    key=(e0['tool_name'],pre)
    st[key]['n']+=1
    rr=[x for x in reads.get((s,h),[]) if x['id']>e0['id']]
    if rr: st[key]['read']+=1; st[key]['reads']+=len(rr)
    # same agent?
    if any(x['a']==e0['a'] for x in rr): st[key]['read_same_principal']+=1
print("| emitter tool | handle kind | buffers | read back >=1 | % | total reads | read by same principal |")
print("|---|---|---|---|---|---|---|")
for k,d in sorted(st.items(), key=lambda x:-x[1]['n']):
    print(f"| {k[0]} | {k[1]} | {d['n']} | {d['read']} | {100*d['read']/d['n']:.1f} | {d['reads']} | {d['read_same_principal']} |")
# read-side: reading tools by handle kind
rk=collections.Counter()
for (s,h),rs in reads.items():
    for x in rs: rk[(x['tool_name'],h.split('_')[0])]+=1
print("\nread-back calls by (tool,handle kind)",rk.most_common(20))
tot_orph=sum(1 for (s,h) in reads if (s,h) not in emitted); print("read (session,handle) keys",len(reads),"not emitted in-snapshot by same session",tot_orph, collections.Counter(h.split('_')[0] for (s,h) in reads if (s,h) not in emitted))
# what follows overflow, per overflowed row (any with emitted id), next call of same principal
outc=collections.defaultdict(collections.Counter)
for p,lst in byp.items():
    for i,r in enumerate(lst):
        if not r['e']: continue
        kind=('bg' if r['e'].startswith('@bg') else 'overflow')
        key=(r['tool_name'],kind)
        outc[key]['n']+=1
        if i+1>=len(lst): outc[key]['end']+=1; continue
        nx=lst[i+1]
        nxt_read=False
        if nx['rd'] and r['e'] in (nx['rd'] or ''): nxt_read=True
        later5=[x for x in lst[i+1:i+6]]
        read5=any(x['rd'] and r['e'] in x['rd'] for x in later5)
        if nxt_read: outc[key]['next_reads_buffer']+=1
        elif nx['tool_name']==r['tool_name'] and nx['inp']==r['inp']: outc[key]['next_identical_rerun']+=1
        elif nx['tool_name']==r['tool_name']: outc[key]['next_same_tool_different_input']+=1
        else: outc[key]['next_other_tool']+=1
        if read5: outc[key]['read_within_5']+=1
        if not read5 and not nxt_read: outc[key]['no_read_within_5']+=1
        if nx['tool_name']==r['tool_name'] and nx['inp']==r['inp'] and r['tool_name']!='run_command': pass
print("\n| emitter | kind | n | next call reads the buffer | buffer read within next 5 | next identical re-run | next same tool diff input | next other tool (no read) | last call of principal |")
print("|---|---|---|---|---|---|---|---|---|")
for k,d in sorted(outc.items(), key=lambda x:-x[1]['n']):
    print(f"| {k[0]} | {k[1]} | {d['n']} | {d['next_reads_buffer']} | {d['read_within_5']} | {d['next_identical_rerun']} | {d['next_same_tool_different_input']} | {d['next_other_tool']} | {d['end']} |")
# read-back in-same-session ever (any distance) for overflow kind (@tool/@cmd) only, by tool
print("\nsample read_file reading buffers inputs:")
n=0
for r in rows:
    if r['tool_name']=='read_file' and r['rd'] and r['rd']!='[]':
        print(r['id'],r['rd'],r['inp'][:150]); n+=1
        if n>=4: break
