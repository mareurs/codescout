import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from base_common import *
c=conn()
rows=c.execute(f"select id,tool_name,overflowed,output_json,agent_id,emitted_output_id from tool_calls where id<={MAXID} and output_json is not null").fetchall()
ov=[r for r in rows if r['overflowed']]
print("overflowed rows with output",len(ov))
sizes=collections.defaultdict(list); buf=collections.defaultdict(list); parsed=0
for r in ov:
    sizes[r['tool_name']].append(len(r['output_json'].encode()))
    m=re.search(r'buffered_bytes\\?"?:\s*(\d+)',r['output_json'])
    if m: buf[r['tool_name']].append(int(m.group(1))); parsed+=1
print("buffered_bytes parsed",parsed)
print("| tool (overflowed rows with output) | n | inline bytes p50 | max | buffered_bytes p50 | p90 | max | sum buffered |")
for k,v in sorted(sizes.items(), key=lambda x:-len(x[1])):
    b=buf.get(k,[])
    print(f"| {k} | {len(v)} | {pct(v,50):.0f} | {max(v)} | {pct(b,50) if b else '-'} | {pct(b,90) if b else '-'} | {max(b) if b else '-'} | {sum(b) if b else '-'} |")
sample=[r['output_json'][:400] for r in ov if r['tool_name']=='run_command'][:2]; print(sample)
big=collections.Counter(r['tool_name'] for r in rows if len(r['output_json'])>10000)
print("non-overflow outputs >10000 chars by tool:",collections.Counter(r['tool_name'] for r in rows if len(r['output_json'])>10000 and not r['overflowed']))
# bg rows output sizes
bg=[len(r['output_json']) for r in ov if (r['emitted_output_id'] or '').startswith('@bg')]; print("bg rows with output",len(bg),"p50 bytes",pct(bg,50) if bg else None)
