#!/bin/bash
# Build scratch repos for libgit2-vs-git semantics checks. Everything lives under $D.
set -u
SP=/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad
D=$SP/git_sem
rm -rf "$D"
mkdir -p "$D"
cd "$D" || exit 1
export GIT_AUTHOR_NAME=t GIT_AUTHOR_EMAIL=t@e GIT_COMMITTER_NAME=t GIT_COMMITTER_EMAIL=t@e
export GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_NOSYSTEM=1
mkcommits() {
  mkdir -p dirA dirB
  echo a1 > dirA/a.txt; echo b1 > dirB/b.txt; echo r1 > root.txt
  git add -A; git commit -q -m c1
  echo a2 >> dirA/a.txt; git commit -q -am c2
  echo b2 >> dirB/b.txt; git commit -q -am c3
}
git init -q base; (cd base && mkcommits && git config uploadpack.allowFilter true && git config uploadpack.allowAnySHA1InWant true)
# 1. linked worktree (default), + relative-paths worktree
git -C base worktree add -q ../wt -b wtb
git -C base config worktree.useRelativePaths true
git -C base worktree add -q ../wtrel -b wtrelb
git -C base config worktree.useRelativePaths false
# 2. sparse checkout (cone) and sparse index
git clone -q --no-hardlinks file://$D/base sparse
git -C sparse sparse-checkout set --cone dirA
git clone -q --no-hardlinks file://$D/base sparseidx
git -C sparseidx sparse-checkout set --cone --sparse-index dirA
# 3. reftable, sha256
git init -q --ref-format=reftable reft; (cd reft && mkcommits)
git init -q --object-format=sha256 sha; (cd sha && mkcommits)
# 4. partial clone and shallow clone
git clone -q --no-checkout --filter=blob:none file://$D/base partial
git clone -q --depth 1 file://$D/base shallow
# 5. separate git dir
git init -q --separate-git-dir "$D/sepgit.git" sep; (cd sep && mkcommits)
# 6. includeIf: global config in $D/home
mkdir -p home
printf '[user]\n\tname = global-name\n[includeIf "gitdir:%s/incl/"]\n\tpath = %s/home/incl.cfg\n' "$D" "$D" > home/.gitconfig
printf '[user]\n\temail = incl@included\n' > home/incl.cfg
mkdir -p incl; git init -q incl/r; (cd incl/r && mkcommits)
# 7. fsmonitor builtin + untracked cache enabled on a clone
git clone -q --no-hardlinks file://$D/base fsm
git -C fsm config core.untrackedCache true
git -C fsm config core.fsmonitor true
# 8. dirty repo with untracked + ignored + deleted + modified + staged
git clone -q --no-hardlinks file://$D/base dirty
(cd dirty && echo x > untracked.txt && echo '*.log' > .gitignore && git add .gitignore && echo y > i.log && echo z >> root.txt && git rm -q dirA/a.txt && mkdir -p newdir && echo n > newdir/n.txt)
# 9. repo with bare .git file pointing at missing gitdir (broken worktree)
git -C base worktree add -q --detach ../wtbroken
rm -rf base/.git/worktrees/wtbroken
# 10. repo with a replace ref / grafts skipped; packed refs only
git clone -q --no-hardlinks file://$D/base packedrefs
git -C packedrefs pack-refs --all
echo built
ls -1 "$D"
