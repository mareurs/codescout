import pickle, collections
rows=pickle.load(open('lat_rows.pkl','rb'))
for t in ['workspace','index','librarian','references','call_graph']:
    l=[r for r in rows if r['tool']==t and r['lat']>=20000]
    print(t,len(l),'dates',sorted(collections.Counter(r['ca'][:10] for r in l).items()),'sum_s',round(sum(r['lat'] for r in l)/1000))
l=[r for r in rows if r['tool']=='workspace' and r['lat']>=20000]
print(collections.Counter(r['action'] for r in l), 'parent?',collections.Counter(bool(r['ag']) for r in l))
# workspace overall by week
for t in ['workspace','index','librarian']:
    b=collections.defaultdict(list)
    for r in rows:
        if r['tool']==t: b[r['ca'][:7]+('a' if r['ca'][8:10]<'20' else 'b')].append(r['lat'])
    print(t,{k:(len(v),sorted(v)[len(v)//2],max(v)) for k,v in sorted(b.items())})
# index.* in time range last use
print([ (r['ca'][:10],r['action'],r['lat']) for r in rows if r['tool']=='index'][-6:])
# librarian reindex over 20s: dates and share without input
lr=[r for r in rows if r['tool']=='librarian' and r['lat']>=20000]
print('librarian>=20s dates',sorted(collections.Counter(r['ca'][:10] for r in lr).items()),'actions',collections.Counter(r['action'] for r in lr))
