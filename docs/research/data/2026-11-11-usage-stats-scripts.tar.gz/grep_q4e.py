import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_enrich import *
import pickle
a={x['id']:x for x in pickle.load(open('grep_q4a.pkl','rb'))}
rows=enrich(); R={r['id']:r for r in rows}
Z=[r for r in rows if r['out'].get('zero')]
def kind(r):
    t=r['out']['text']
    if 'No file under' in t: return 'starved-glob clause'
    if 'Hidden paths were not searched' in t: return 'hidden clause'
    if 'Gitignore rules are a' in t: return 'gitignore clause'
    if 'The walk could not read' in t: return 'walk-error clause'
    if 'walk cut:' in t[:t.find('\n\n')+1] or t.startswith('0 matches\n\nwalk cut'): return 'walk-cut notice'
    if 'were not searched; a missing' in t: return 'skipped_large'
    if r['out']['warns'] and r['out']['body'].strip()=='0 matches': return 'bare zero + stale-workspace preamble'
    if r['out']['body'].strip()=='0 matches': return 'bare zero'
    return 'other'
cnt=collections.defaultdict(collections.Counter)
for r in Z:
    k=kind(r); x=a[r['id']]; cnt[k]['n']+=1
    cnt[k][x['bucket'].split('(')[0]]+=1
for k,c in sorted(cnt.items(),key=lambda x:-x[1]['n']):
    n=c['n']; print(k,n,'| scope_miss',c['scope_miss'],'pattern_miss',c['pattern_miss'],'hit_via_other_tool',c['hit_via_other_tool'],'likely_true',c['likely_true_zero'],'unknown(no related search/missing/err/none)',n-c['scope_miss']-c['pattern_miss']-c['hit_via_other_tool']-c['likely_true_zero'])
# head_limit overshoot
hl=[r for r in rows if r['has_in'] and 'head_limit' in r['ip'] and 'limit' not in r['ip'] and r['out'].get('n') is not None]
over=0; ex=0; tot=0
for r in hl:
    try: h=int(r['ip']['head_limit'])
    except: continue
    if h==0: continue
    tot+=1
    shown_total=r['out']['n']
    if shown_total>h: over+=1; ex+=shown_total-h
print('head_limit rows w/o limit, with parsed count',tot,'result count exceeded head_limit in',over,'rows (%.1f%%)'%(100*over/max(1,tot)),'mean excess among those',ex/max(1,over))
hl2=[r for r in hl if r['overflowed']]
print('of head_limit rows (no limit) overflowed',len(hl2))
# overall: rows where limit specified but result capped
