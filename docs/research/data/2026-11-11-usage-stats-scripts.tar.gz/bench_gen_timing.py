import sys, json
sys.path.insert(0, "/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad")
import bench_common as b
scope, run = sys.argv[1], sys.argv[2]
s = b.SCOPES[scope]
pats = b.RPATS if scope == "reg" else b.PATS
jobs = []
for p in pats:
    pid = p["id"]
    vs = []
    csrep = 2 if scope == "reg" else None
    if not p["pcre"]:
        vs.append(dict(label=f"{pid}|{scope}|cs-lines", tool="grep", args=b.cs_args(p, s), **({"repeats": csrep} if csrep else {})))
        vs.append(dict(label=f"{pid}|{scope}|cs-files", tool="grep", args=b.cs_args(p, s, "files"), **({"repeats": csrep} if csrep else {})))
    vs.append(dict(label=f"{pid}|{scope}|rg", tool="run_command", args=dict(command=b.rg_cmd(p, s), effect="read")))
    vs.append(dict(label=f"{pid}|{scope}|gg", tool="run_command", args=dict(command=b.gg_cmd(p, s), effect="read")))
    jobs.append(dict(variants=vs, repeats=7, warmup=1))
out = f"{b.SP}/timing/t_{scope}_{run}.json"
json.dump(dict(nonce=f"t_{scope}_{run}", settle=30, out=out, jobs=jobs), open(f"{b.SP}/timing/spec_{scope}_{run}.json", "w"))
print(scope, run, len(jobs), "jobs")
