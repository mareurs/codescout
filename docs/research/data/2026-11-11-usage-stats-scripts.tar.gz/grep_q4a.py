import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_enrich import *
import pickle
c=conn()
cur=c.execute("select id,tool_name,called_at,session_id,agent_id,input_json,substr(output_json,1,1500),outcome,latency_ms from tool_calls where id<=? order by id",(MAXID,))
allrows=[]
for id_,tn,ca,sid,aid,ij,oj,oc,lat in cur:
    allrows.append((id_,tn,ca,sid,aid,ij,oj,oc,lat))
print('all rows',len(allrows))
by=collections.defaultdict(list)
for i,row in enumerate(allrows):
    by[(row[3],row[4])].append(row)
STOP=set('async impl struct enum self true false test const static type use mod pub that this with from have when then else into some none ok err'.split())
def toks(s):
    return {t.lower() for t in re.findall(r'[A-Za-z0-9_]{3,}',s or '') if t.lower() not in STOP}
def search_text(row):
    id_,tn,ca,sid,aid,ij,oj,oc,lat=row
    ip=inp(ij)
    if tn=='grep' and ip: return ip.get('pattern')
    if tn=='symbols' and ip: return ip.get('name')
    if tn=='run_command' and ip:
        cmd=ip.get('command','') or ''
        if re.search(r'(^|[\s;|&(])(grep|egrep|fgrep|rg|fd|find|ag|ack)\s|git\s+(-C\s+\S+\s+)?grep',cmd): return cmd
    return None
def rc_hit(oj):
    if not oj: return None
    t=out_text(oj)
    m=re.search(r'"exit_code":\s*(-?\d+)',t)
    ex=int(m.group(1)) if m else None
    sm=re.search(r'"stdout":\s*"((?:[^"\\]|\\.)*)',t)
    if sm is not None:
        return ex in (0,None) and len(sm.group(1))>0
    if '"output_id"' in t: return True
    return False if ex==1 else None
def hit_of(row):
    id_,tn,ca,sid,aid,ij,oj,oc,lat=row
    if oc!='success': return 'error'
    if not oj: return None
    if tn=='grep':
        d=parse_out({'oj':oj,'ij':ij})
        if d.get('zero'): return False
        if d.get('hkind') or d.get('env'): return True
        return None
    if tn=='symbols':
        t=out_text(oj)
        if re.search(r'^(No symbols|0 symbols|no match)',t,re.I) or t.strip() in ('[]','{}'): return False
        return True
    if tn=='run_command':
        return rc_hit(oj)
def scope(ip):
    g=ip.get('glob'); 
    if isinstance(g,list): g=tuple(g)
    return (ip.get('workspace'),ip.get('path') or '.',g,bool(ip.get('include_hidden')),bool(ip.get('ignore_case')),bool(ip.get('whole_word')))
res=[]
rows=enrich()
Z=[r for r in rows if r['out'].get('zero')]
for r in Z:
    rec={'id':r['id'],'parent':r['parent'],'bare':r['out']['body'].strip()=='0 matches' and not r['out']['warns'],'has_in':r['has_in']}
    if not r['has_in']:
        rec['bucket']='no_input'; res.append(rec); continue
    ip=r['ip']; P=ip.get('pattern') or ''
    zt=toks(P)
    seq=by[(r['sid'],r['aid'])]
    # locate
    idx=next(i for i,x in enumerate(seq) if x[0]==r['id'])
    nxt=seq[idx+1:idx+4]
    rec['next_tools']=[x[1] for x in nxt]
    related=[]
    for j,x in enumerate(nxt):
        st=search_text(x)
        if st is None: continue
        ft=toks(st)
        ov=zt&ft
        if ov and (len(ov)/max(1,len(zt))>=0.34 or len(ov)/max(1,len(ft))>=0.34):
            related.append((j,x,hit_of(x)))
    rec['n_related']=len(related)
    if not nxt: rec['bucket']='unknown_no_followup'
    elif not related: rec['bucket']='unknown_no_related_search'
    else:
        hits=[(j,x,h) for j,x,h in related if h is True]
        if hits:
            j,x,h=hits[0]
            xi=inp(x[5]) or {}
            if x[1]=='grep':
                sc=scope(xi); sz=scope(ip)
                rec['scope_changed']= sc[:4]!=sz[:4]
                rec['flags_changed']= sc[4:]!=sz[4:]
                rec['pattern_changed']= xi.get('pattern')!=P
                rec['follow']=(x[0],'grep',(xi.get('pattern') or '')[:80],str(xi.get('path'))[:60],str(xi.get('glob'))[:60],xi.get('include_hidden'))
                if rec['scope_changed']: rec['bucket']='scope_miss'
                elif rec['flags_changed'] or rec['pattern_changed']: rec['bucket']='pattern_miss(same scope, reformulated hit)'
                else: rec['bucket']='scope_miss?'  # identical input, hits (tree changed or flake)
            else:
                rec['follow']=(x[0],x[1],(search_text(x) or '')[:100])
                rec['bucket']='hit_via_other_tool(%s)'%x[1]
        elif any(h is False for _,_,h in related): rec['bucket']='likely_true_zero(related search also empty)'
        elif any(h=='error' for _,_,h in related): rec['bucket']='unknown_followup_errored'
        else: rec['bucket']='unknown_followup_output_missing'
    res.append(rec)
pickle.dump(res,open('grep_q4a.pkl','wb'))
def table(sub,title):
    c=collections.Counter(x['bucket'] for x in sub)
    print(title,len(sub)); 
    for k,n in c.most_common(): print('  ',k,n,'%.1f%%'%(100*n/len(sub)))
table(res,'ALL ZEROS')
table([x for x in res if x['bare']],'BARE zeros')
table([x for x in res if not x['bare']],'WARNED zeros')
table([x for x in res if x['parent']],'PARENT')
table([x for x in res if not x['parent']],'SUBAGENT')
# next-3 tool dist
c=collections.Counter(t for x in res for t in x.get('next_tools',[])[:1])
print('next call tool after zero',c.most_common(10))
# immediate re-run
