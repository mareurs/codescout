#!/bin/bash
D=/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad/git_sem
export HOME=$D/home
export GIT_AUTHOR_NAME=t GIT_AUTHOR_EMAIL=t@e GIT_COMMITTER_NAME=t GIT_COMMITTER_EMAIL=t@e
for c in wtbroken sparse sparseidx reft sha partial shallow wtrel incl/r; do
  echo "### CLI $c"
  echo "  rev-parse HEAD: $(git -C $D/$c rev-parse HEAD 2>&1 | head -c 200)"
  echo "  status --porcelain=v1: [$(git -C $D/$c status --porcelain=v1 2>&1 | head -c 300 | tr '\n' ';')]"
  echo "  blame dirA/a.txt: $(git -C $D/$c blame --porcelain dirA/a.txt 2>&1 | head -c 120 | tr '\n' ';')"
  echo "  config user.email: $(git -C $D/$c config user.email 2>&1 | head -c 100)"
done
