import pickle, collections
rows=pickle.load(open('lat_rows.pkl','rb'))
def pct(v,q):
    v=sorted(v)
    if not v: return 0
    k=(len(v)-1)*q; f=int(k); c=min(f+1,len(v)-1); return v[f]+(v[c]-v[f])*(k-f)
rc=[r for r in rows if r['tool']=='run_command']
a=[r for r in rc if r['ams'] is not None]
print('rc rows',len(rc),'with attribution_ms',len(a),'first row with attribution',min(r['ca'] for r in a))
post=[r for r in rc if r['ca']>=min(r['ca'] for r in a)]
print('rc rows since first attribution row',len(post),'share with attribution',len(a)/len(post))
print('attribution_ms p50/p90/p99/max',[round(pct([r['ams'] for r in a],q)) for q in (.5,.9,.99)],max(r['ams'] for r in a),'sum_s',round(sum(r['ams'] for r in a)/1000))
print('sum attribution_ms / sum latency (those rows) = ',round(sum(r['ams'] for r in a)/sum(r['lat'] for r in a),4),' / all rc latency',round(sum(r['ams'] for r in a)/sum(r['lat'] for r in rc),5))
print('outcome counts',collections.Counter(r['aout'] for r in a))
for o in ['hinted','silent','timed_out','tooling_failure','spawn_failed']:
    v=[r['ams'] for r in a if r['aout']==o]
    if v: print(' ',o,len(v),'p50',round(pct(v,.5)),'p90',round(pct(v,.9)),'max',max(v),'sum_s',round(sum(v)/1000))
ratio=[r['ams']/max(r['lat'],1) for r in a]
print('ratio ams/lat p50 p90',round(pct(ratio,.5),3),round(pct(ratio,.9),3),' rows ams>lat',sum(r['ams']>r['lat'] for r in a))
print('ams>=1000:',sum(r['ams']>=1000 for r in a),'time_s',round(sum(r['ams'] for r in a if r['ams']>=1000)/1000),'; of rows with lat<2000 how many have ams>=500:',sum(1 for r in a if r['lat']<2000 and r['ams']>=500))
# the fast-call tax: rc rows lat<500 with attribution: ams share
f=[r for r in a if r['lat']<500]; print('rows lat<500 with attribution',len(f),'ams p50',pct([r['ams'] for r in f],.5),'p90',pct([r['ams'] for r in f],.9))
