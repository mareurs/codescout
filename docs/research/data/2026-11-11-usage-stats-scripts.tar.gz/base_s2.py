import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from base_common import *
import datetime
c=conn()
rows=c.execute(f"select id,tool_name,called_at,started_at,outcome,agent_id,project_root,session_id,cc_session_id from tool_calls where id<={MAXID}").fetchall()
N=len(rows)
def ts(s): return datetime.datetime.strptime(s[:19],'%Y-%m-%d %H:%M:%S')
print("session_id null",sum(1 for r in rows if not r['session_id']),"cc_session_id null",sum(1 for r in rows if not r['cc_session_id']))
print("agent_id set",sum(1 for r in rows if r['agent_id']),"started_at null",sum(1 for r in rows if not r['started_at']))
ses=collections.defaultdict(list); pr=collections.defaultdict(list)
for r in rows:
    ses[r['session_id']].append(r); pr[(r['session_id'],r['agent_id'] or '')].append(r)
def dist(name,d):
    v=[len(x) for x in d.values()]
    print(f"{name}: count={len(v)} p50={pct(v,50)} p90={pct(v,90)} p99={pct(v,99)} max={max(v)} mean={sum(v)/len(v):.1f}; singletons={sum(1 for x in v if x==1)}; <=10 calls={sum(1 for x in v if x<=10)}")
dist("session_id",ses); dist("principal (session_id,agent_id) all",pr)
pp={k:v for k,v in pr.items() if k[1]==''}; sp={k:v for k,v in pr.items() if k[1]!=''}
dist("parent principals (agent_id NULL)",pp); dist("subagent principals",sp)
print("distinct agent_ids",len({r['agent_id'] for r in rows if r['agent_id']}))
# distinct agent_id values per session
spa=collections.Counter(len({r['agent_id'] for r in v if r['agent_id']}) for v in ses.values())
print("subagents per session hist (top)",sorted(spa.items())[:15], "max",max(spa))
ses_with_sub=sum(1 for v in ses.values() if any(r['agent_id'] for r in v)); print("sessions with >=1 subagent",ses_with_sub)
# sub share
sub=[r for r in rows if r['agent_id']]
print("subagent calls",len(sub),f"{100*len(sub)/N:.1f}%","errors",sum(r['outcome']!='success' for r in sub),"all errors",sum(r['outcome']!='success' for r in rows),f"{100*sum(r['outcome']!='success' for r in sub)/sum(r['outcome']!='success' for r in rows):.1f}%")
# cc_session_id vs session_id
cc=collections.defaultdict(set)
for r in rows: cc[r['cc_session_id']].add(r['session_id'])
print("distinct cc_session_id",len(cc),"cc with >1 session_id",sum(1 for v in cc.values() if len(v)>1))
# session durations
durs=[]
for k,v in ses.items():
    a=min(ts(r['called_at']) for r in v); b=max(ts(r['called_at']) for r in v); durs.append((b-a).total_seconds()/60)
print("session duration minutes: p50 %.1f p90 %.1f p99 %.1f max %.1f ; >24h: %d ; >=1h: %d"%(pct(durs,50),pct(durs,90),pct(durs,99),max(durs),sum(d>1440 for d in durs),sum(d>=60 for d in durs)))
# per-principal span for subagents
d2=[]
for k,v in sp.items():
    a=min(ts(r['called_at']) for r in v); b=max(ts(r['called_at']) for r in v); d2.append((b-a).total_seconds()/60)
print("subagent principal span min: p50 %.1f p90 %.1f max %.1f"%(pct(d2,50),pct(d2,90),max(d2)))
# sessions per day (by first call), and active per day
first={k:min(r['called_at'] for r in v) for k,v in ses.items()}
spd=collections.Counter(f[:10] for f in first.values())
act=collections.defaultdict(set)
for r in rows: act[r['called_at'][:10]].add(r['session_id'])
print("\n| day | sessions started | sessions active | principals active |")
pday=collections.defaultdict(set)
for r in rows: pday[r['called_at'][:10]].add((r['session_id'],r['agent_id'] or ''))
for d in sorted(act): print(f"| {d} | {spd.get(d,0)} | {len(act[d])} | {len(pday[d])} |")
# root class of sessions
def sclass(v):
    cs=collections.Counter(classify_root(r['project_root']) for r in v); return cs.most_common(1)[0][0], len(cs)
sc=collections.Counter(); scalls=collections.Counter(); multi=0
for k,v in ses.items():
    c1,nc=sclass(v); sc[c1]+=1; scalls[c1]+=len(v); multi+= nc>1
print("\n## sessions by dominant root class (sessions, calls)")
for k in sc: print(k,sc[k],scalls[k])
print("sessions touching >1 root class",multi)
def harness(r):
    p=r['project_root'] or ''
    return ('setup-ab' in p) or p.startswith('/tmp/') or '/.codex/worktrees/' in p
hs=collections.Counter(); hc=0
for k,v in ses.items():
    f=sum(harness(r) for r in v)
    hs['all-harness' if f==len(v) else ('some' if f else 'none')]+=1
print("sessions harness (setup-ab or /tmp/* or ~/.codex/worktrees):",hs)
print("harness calls",sum(harness(r) for r in rows),f"{100*sum(harness(r) for r in rows)/N:.1f}%")
# top 10 sessions by calls
print("\n## top 10 sessions by calls")
for k,v in sorted(ses.items(), key=lambda x:-len(x[1]))[:10]:
    c1,_=sclass(v); print(k[:12],len(v),min(r['called_at'] for r in v)[:16],max(r['called_at'] for r in v)[:16],c1,"subagents",len({r['agent_id'] for r in v if r['agent_id']}))
print("\n## top 10 principals by calls")
for k,v in sorted(pr.items(), key=lambda x:-len(x[1]))[:10]:
    print(k[0][:12],k[1][:12],len(v),sum(r['outcome']!='success' for r in v),classify_root(v[0]['project_root']))
# share of calls in top 1/5/10% sessions
v=sorted([len(x) for x in ses.values()],reverse=True)
for q in (1,5,10,20): 
    k=max(1,len(v)*q//100); print(f"top {q}% sessions ({k}) hold {100*sum(v[:k])/N:.1f}% calls")
