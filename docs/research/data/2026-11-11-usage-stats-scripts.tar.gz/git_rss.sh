#!/bin/bash
SP=/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad
{
for f in discover status scale blame; do
  echo "== git_bench group=$f"
  python3 -I $SP/git_rusage.py $SP/git_bench/target/release/git_bench /home/marius/work/claude/codescout $f | tail -n 1
done
echo "== CLI git status --porcelain=v2 -z --untracked-files=all"
python3 -I $SP/git_rusage.py git -C /home/marius/work/claude/codescout status --porcelain=v2 -z --untracked-files=all | tail -n 1
echo "== CLI git blame --porcelain"
python3 -I $SP/git_rusage.py git -C /home/marius/work/claude/codescout blame --porcelain src/librarian/tools/gather.rs | tail -n 1
echo "== CLI git log -n 200"
python3 -I $SP/git_rusage.py git -C /home/marius/work/claude/codescout log -n 200 --format=%H | tail -n 1
echo "== gxbench"
python3 -I $SP/git_rusage.py $SP/git_build/target_gx_release/release/gxbench /home/marius/work/claude/codescout | tail -n 1
} > $SP/git_rss.txt 2>&1
echo done
