fn main() -> Result<(), Box<dyn std::error::Error>> {
    let p = std::env::args().nth(1).unwrap_or_else(|| ".".into());
    let repo = gix::discover(&p)?;
    let id = repo.head_id()?;
    let n = repo.rev_walk([id.detach()]).all()?.take(200).count();
    let idx = repo.index()?.entries().len();
    let tree = repo.head_commit()?.tree()?;
    let d = repo.empty_tree().changes()?.for_each_to_obtain_tree(&tree, |_c| Ok::<_, std::convert::Infallible>(std::ops::ControlFlow::Continue(())));
    let st = repo.status(gix::progress::Discard)?.into_index_worktree_iter(Vec::<gix::bstr::BString>::new())?.count();
    println!("{} {} {} {} {}", id, n, idx, d.is_ok(), st);
    Ok(())
}
