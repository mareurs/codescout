import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_enrich import *
import pickle
rows=enrich()
res=pickle.load(open('grep_q4b.pkl','rb')); rv={x['id']:x for x in res}
Z=[r for r in rows if r['out'].get('zero') and r['has_in']]
def globs_of(ip):
    g=ip.get('glob'); 
    return [] if g is None else (list(g) if isinstance(g,list) else [g])
cls=collections.Counter(); ex={}
for r in Z:
    ip=r['ip']; gl=globs_of(ip); path=ip.get('path') or '.'
    pc=path_class(ip.get('path'))
    hid_on=ip.get('include_hidden') in (True,'true')
    kinds=[]
    posg=[g for g in gl if not g.startswith('!')]
    if pc in ('subdir','abs_outside') and posg:
        rel=path[len(PROJ)+1:] if path.startswith(PROJ+'/') else path
        rel=rel.rstrip('/')
        for g in posg:
            if '/' in g and not g.startswith('**') and (g.startswith(rel+'/') or g.startswith('./'+rel+'/') or g.startswith(PROJ+'/')):
                kinds.append('relative_glob_repeats_path_prefix'); break
    if pc=='file' and gl: kinds.append('glob_given_with_file_path')
    segs=[s for s in re.split(r'/',path) if s]
    if not hid_on:
        if any(s.startswith('.') and s not in ('.','..') for s in (path[len(PROJ)+1:].split('/') if path.startswith(PROJ+'/') else (segs if not path.startswith('/') else []))):
            kinds.append('hidden_dir_in_path_without_include_hidden')
        for g in posg:
            if re.match(r'^\.[A-Za-z_]',g.lstrip('./')) or g.startswith('.'):
                if not g.startswith('./') : kinds.append('hidden_dir_in_glob_without_include_hidden'); break
    warned=('No file under' in r['out']['text']) or ('Hidden paths' in r['out']['text']) or ('this zero describes' in r['out']['text'])
    for k in set(kinds) or {'none'}:
        cls[(k,warned)]+=1; ex.setdefault((k,warned),(r['id'],ip.get('pattern','')[:40],path,gl))
print('ZERO rows with input',len(Z))
for k,n in sorted(cls.items()): print(n,k,ex[k])
# overall warned zeros
wz=[r for r in Z if 'this zero describes' in r['out']['text']]
print('zeros carrying the completeness warning',len(wz),'of',len(Z))
for nm,ph in (('glob-starved clause','No file under'),('hidden clause','Hidden paths were not searched'),('gitignore clause','Gitignore rules are a'),('walk-error clause','The walk could not read'),('walk cut','walk cut:'),('skipped_large','were not searched; a missing')):
    print(nm,sum(1 for r in Z if ph in r['out']['text']))
# path_never_existed
print(collections.Counter(x['verdict'] for x in res))
st=[x for x in res if x['verdict']=='starved_scope_admits_no_file_now']
print('starved now',len(st),'carried the starved warning at call time',sum(1 for x in st if x.get('warned')))
