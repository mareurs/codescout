p = "/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad/git_bench/src/main.rs"
s = open(p).read()
a = '    let repo_path = std::env::args().nth(1).expect("repo path");\n'
b = a + '    if std::env::var("STRICT").as_deref() == Ok("0") {\n        unsafe { git2::opts::strict_hash_verification(false); }\n        println!("STRICT_HASH_VERIFICATION=off");\n    }\n'
assert a in s
s = s.replace(a, b, 1)
open(p, "w").write(s)
print("ok")
