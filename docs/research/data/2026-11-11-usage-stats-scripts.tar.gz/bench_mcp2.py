#!/usr/bin/env python3
"""MCP stdio driver v2. spec: nonce, settle, out, jobs[{variants[{label,tool,args,repeats?}],repeats,warmup,drain?}]
Each job runs warmup rounds then N measured rounds; each round calls every variant once (interleaved).
Records client wall ms, response bytes, isError, text of first measured and last run."""
import re, json, subprocess, sys, time, os, select
ROOT = "/home/marius/work/claude/codescout"
spec = json.load(open(sys.argv[1]))
p = subprocess.Popen(["/home/marius/.cargo/bin/codescout", "start", "-p", ROOT], cwd=ROOT,
                     stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, bufsize=0)
_id = 0; buf = b""
def send(o):
    p.stdin.write((json.dumps(o) + "\n").encode()); p.stdin.flush()
def recv_until(rid, timeout=300):
    global buf
    end = time.time() + timeout
    while time.time() < end:
        while b"\n" in buf:
            line, buf = buf.split(b"\n", 1)
            if not line.strip(): continue
            try: m = json.loads(line)
            except Exception: continue
            if m.get("id") == rid and ("result" in m or "error" in m): return m
        r, _, _ = select.select([p.stdout], [], [], 1.0)
        if r:
            d = os.read(p.stdout.fileno(), 1 << 20)
            if not d: raise SystemExit("server closed")
            buf += d
    raise SystemExit("timeout waiting for %s" % rid)
def call(method, params):
    global _id
    _id += 1
    send({"jsonrpc": "2.0", "id": _id, "method": method, "params": params})
    return recv_until(_id)
def tool(name, args):
    t0 = time.perf_counter()
    m = call("tools/call", {"name": name, "arguments": args})
    dt = (time.perf_counter() - t0) * 1000
    res = m.get("result", {}) if isinstance(m.get("result"), dict) else {}
    text = "".join(c.get("text", "") for c in res.get("content", []) if c.get("type") == "text")
    return dt, text, res.get("isError"), m.get("error")
call("initialize", {"protocolVersion": "2024-11-05", "capabilities": {}, "clientInfo": {"name": "bench", "version": "0"}})
send({"jsonrpc": "2.0", "method": "notifications/initialized"})
tool("workspace", {"action": "activate", "path": ROOT})
time.sleep(spec.get("settle", 30))
nonce = spec.get("nonce", "x")
tool("run_command", {"command": "echo bench_marker_" + nonce, "effect": "read"})
out = []
def dump(): json.dump({"nonce": nonce, "results": out}, open(spec["out"], "w"))
for gi, job in enumerate(spec["jobs"]):
    W = job.get("warmup", 1); N = job.get("repeats", 7)
    recs = [dict(grp=gi, label=v["label"], tool=v["tool"], args=v["args"], runs=[], text_first="", text_last="") for v in job["variants"]]
    for rnd in range(W + N):
        for v, rec in zip(job["variants"], recs):
            if v.get("repeats") is not None and rnd >= W + v["repeats"]: continue
            dt, text, iserr, err = tool(v["tool"], v["args"])
            rec["runs"].append(dict(i=rnd, warm=rnd < W, wall_ms=round(dt, 1), bytes=len(text.encode()), isError=iserr, rpc_error=err))
            if rnd == W: rec["text_first"] = text
            rec["text_last"] = text
            if job.get("drain") and rnd == 0 and v["label"] in job["drain"]:
                mo = re.search(r"@tool_[0-9a-f]+", text)
                if mo:
                    tool("run_command", {"command": "cat " + mo.group(0) + " > " + job["drain"][v["label"]], "effect": "write"})
    out += recs
    dump()
p.stdin.close()
try: p.wait(5)
except Exception: p.kill()
