import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_common import *
import pickle, subprocess, os
PROJ='/home/marius/work/claude/codescout'
res=pickle.load(open('grep_shell_res.pkl','rb'))
def real_paths(rec,cwd):
    ps=[]
    for p in rec['paths']:
        if p.startswith(':') or p.startswith('!') : continue   # git pathspec magic
        if any(ch in p for ch in '*?[{'): continue
        ps.append(p)
    return ps
cand=set(); items=[]
for fam in ['git grep','rg','grep_recursive','grep_files','find']:
    for (id_,aid,rec,cmd,hasout,text,ov,lat,cwd,sid) in res[fam]:
        base=os.path.join(PROJ,cwd) if cwd and not cwd.startswith('/') else (cwd or PROJ)
        # cd in the command
        m=re.search(r'(?:^|&&|;)\s*cd\s+([^\s;&|]+)',cmd)
        if m and not cmd.lstrip().startswith(('git -C','git grep')): 
            d=m.group(1).strip('"\''); base=d if d.startswith('/') else os.path.join(base,d)
        m2=re.search(r'git\s+-C\s+(\S+)',cmd)
        if m2: base=m2.group(1).strip('"\'')
        ps=real_paths(rec,cwd)
        absps=[p if p.startswith('/') else os.path.normpath(os.path.join(base,p)) for p in ps]
        items.append((fam,id_,rec,cmd,base,absps))
        for a in absps:
            if a.startswith(PROJ+'/') or a==PROJ: cand.add(os.path.relpath(a,PROJ))
cand=sorted(cand)
print('unique in-repo path args',len(cand))
ign=set()
if cand:
    p=subprocess.run(['git','check-ignore','--stdin'],input='\n'.join(cand),capture_output=True,text=True,cwd=PROJ)
    ign=set(p.stdout.split('\n'))
def hidden(a):
    rel=a[len(PROJ)+1:] if a.startswith(PROJ+'/') else a
    return any(s.startswith('.') and s not in ('.','..') for s in rel.split('/'))
cats=collections.defaultdict(collections.Counter); ex={}
for fam,id_,rec,cmd,base,absps in items:
    fl=set(rec['flags'])
    lifted=bool(fl & {'--no-ignore','-u','--no-ignore-vcs','--hidden','-.','--no-index','--untracked'})
    cs=set()
    if not absps: cs.add('no_path_arg(cwd default)')
    for a in absps:
        if not (a.startswith(PROJ+'/') or a==PROJ):
            if a.startswith('/home/marius/work/claude/'): cs.add('outside: other repo/worktree under work/claude')
            elif '/.cache/cc-tmp' in a or a.startswith('/tmp') or '/scratch' in a: cs.add('outside: scratch/tmp')
            elif '/.claude' in a: cs.add('outside: ~/.claude* config/sessions')
            else: cs.add('outside: other')
            continue
        rel=os.path.relpath(a,PROJ)
        if rel in ign or any(rel.startswith(x.rstrip('/')+'/') for x in ign if x): cs.add('in-repo gitignored')
        elif hidden(a): cs.add('in-repo hidden dir (e.g. .codescout/.github/.superpowers)')
        else: cs.add('in-repo visible')
    for c in cs:
        cats[fam][c]+=1; ex.setdefault((fam,c),(id_,cmd[:150].replace('\n',' ')))
    if lifted: cats[fam]['(flag lifts ignore/hidden: --no-ignore/-u/--hidden/--no-index/--untracked)']+=1
    # pathspec exclusion magic
    if fam=='git grep' and re.search(r"':?[!(]|:\(exclude\)|':\^",cmd): cats[fam]["(git pathspec exclusion ':!x')"]+=1
    if fam=='rg' and re.search(r"-g\s*['\"]?!",cmd): cats[fam]["(rg -g negation)"]+=1
for fam in ['git grep','rg','grep_recursive','grep_files','find']:
    n=len(res[fam]); print('==',fam,n,'calls')
    for c,v in cats[fam].most_common(): print(f'   {c}: {v} ({100*v/n:.0f}%)')
    for (f,c),e in ex.items():
        if f==fam and ('gitignored' in c or 'hidden dir' in c): print('     ex',c[:20],e)
