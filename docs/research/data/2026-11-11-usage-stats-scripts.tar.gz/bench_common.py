import shlex
SP = "/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad"
ROOT = "/home/marius/work/claude/codescout"
REG = "/home/marius/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f"
P = lambda id, pat, label, i=False, w=False, pcre=False: dict(id=id, pat=pat, label=label, i=i, w=w, pcre=pcre)
PATS = [
 P("P01", "fn clamp_match", "rare (definition, 1 file)"),
 P("P02", "RecoverableError", "common identifier"),
 P("P03", "wall-clock budget", "multi-word text"),
 P("P04", "RecoverableError|anyhow::bail", "alternation"),
 P("P05", "^pub fn", "anchored regex"),
 P("P06", "recoverableerror", "case-insensitive", i=True),
 P("P07", "Agent", "whole-word", w=True),
 P("P08", "zzqxnomatchzz", "zero matches"),
 P("P09", "fn ", "huge result"),
 P("P10", "(?<=pub )fn \\w+", "PCRE look-around", pcre=True),
 P("P11", "Result<Value>", "literal w/ metachar-ish"),
 P("P12", "TODO|FIXME", "alternation of words"),
]
RPATS = [
 P("Q1", "MAP_NORESERVE", "registry: rare-ish (496 files)"),
 P("Q2", "unsafe impl Send", "registry: multi-word common"),
 P("Q3", "TODO|FIXME", "registry: alternation (12301 files)"),
 P("Q4", "wall-clock", "registry: text"),
 P("Q5", "zzqxnomatchzz", "registry: zero"),
 P("Q6", "RecoverableError", "registry: rare (33 files)"),
 P("Q7", "recoverableerror", "registry: case-insens", i=True),
 P("Q8", "(?<=unsafe )impl Send", "registry: PCRE", pcre=True),
]
SCOPES = {
 "repo": dict(path=None, glob=None),
 "src": dict(path="src/", glob=None),
 "globrs": dict(path=None, glob="*.rs"),
 "docs": dict(path="docs/", glob=None),
 "reg": dict(path=REG, glob=None, reg=True),
}
def rg_cmd(p, s, extra=()):
    c = ["rg", "-n"] + list(extra)
    if p["i"]: c.append("-i")
    if p["w"]: c.append("-w")
    if p["pcre"]: c.append("-P")
    c += ["-e", p["pat"]]
    if s.get("glob"): c += ["-g", s["glob"]]
    if s.get("path"): c.append(s["path"])
    return " ".join(shlex.quote(x) for x in c)
def gg_cmd(p, s, extra=()):
    c = ["git"]
    if s.get("reg"): c += ["-C", s["path"]]
    c += ["grep", "-n"] + list(extra)
    if s.get("reg"): c.append("--no-index")
    if p["i"]: c.append("-i")
    if p["w"]: c.append("-w")
    c.append("-P" if p["pcre"] else "-E")
    c += ["-e", p["pat"]]
    if not s.get("reg"):
        ps = s.get("glob") or s.get("path")
        if ps: c += ["--", ps]
    return " ".join(shlex.quote(x) for x in c)
def cs_args(p, s, mode="lines", limit=None):
    a = {"pattern": p["pat"]}
    if p["i"]: a["ignore_case"] = True
    if p["w"]: a["whole_word"] = True
    if s.get("path"): a["path"] = s["path"]
    if s.get("glob"): a["glob"] = s["glob"]
    if mode != "lines": a["mode"] = mode
    if limit: a["limit"] = limit
    return a
def combos():
    for p in PATS:
        for sk in ("repo", "src", "globrs", "docs"):
            yield p, sk, SCOPES[sk]
    for p in RPATS:
        yield p, "reg", SCOPES["reg"]
