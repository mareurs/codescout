import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from base_common import *
import datetime
c=conn()
rows=c.execute(f"select id,tool_name,called_at,outcome,session_id,agent_id,project_root from tool_calls where id<={MAXID}").fetchall()
D=collections.defaultdict(lambda: {'n':0,'e':0,'s':set(),'t':set(),'sub':0,'rc':collections.Counter(),'sc':collections.Counter()})
H=collections.Counter(); W=collections.Counter(); WH=collections.defaultdict(collections.Counter)
for r in rows:
    d=D[r['called_at'][:10]]; d['n']+=1; d['e']+= r['outcome']!='success'; d['s'].add(r['session_id']); d['t'].add(r['tool_name']); d['sub']+=bool(r['agent_id'])
    d['rc'][classify_root(r['project_root'])]+=1; d['sc'][r['session_id'][:8]]+=1
    hh=int(r['called_at'][11:13]); H[hh]+=1
    wd=datetime.date.fromisoformat(r['called_at'][:10]).weekday(); W[wd]+=1
print("| day | wkday | calls | sessions | err% | distinct tools | subagent% | top root class (share%) | top session (share%) |")
print("|---|---|---|---|---|---|---|---|---|")
alld=sorted(D)
start=datetime.date.fromisoformat(alld[0]); end=datetime.date.fromisoformat(alld[-1])
x=start
while x<=end:
    k=x.isoformat(); d=D.get(k)
    if not d: print(f"| {k} | {x.strftime('%a')} | 0 | 0 | - | 0 | - | - | - |")
    else:
        rc=d['rc'].most_common(1)[0]; sc=d['sc'].most_common(1)[0]
        print(f"| {k} | {x.strftime('%a')} | {d['n']} | {len(d['s'])} | {100*d['e']/d['n']:.1f} | {len(d['t'])} | {100*d['sub']/d['n']:.0f} | {rc[0]} ({100*rc[1]/d['n']:.0f}) | {sc[0]} ({100*sc[1]/d['n']:.0f}) |")
    x+=datetime.timedelta(days=1)
print("\nfirst day partial: first call",rows[0]['called_at'], "last day partial: 2026-11-10 last call", max(r['called_at'] for r in rows))
print("\n## hour of day UTC (calls)")
tot=len(rows)
print("| hour | calls | share% |"); 
for h in range(24): print(f"| {h:02d} | {H[h]} | {100*H[h]/tot:.1f} |")
print("\n## weekday (calls; note number of each weekday in window differs)")
ndays=collections.Counter()
x=start
while x<=end: ndays[x.weekday()]+=1; x+=datetime.timedelta(days=1)
for w in range(7): print(f"| {['Mon','Tue','Wed','Thu','Fri','Sat','Sun'][w]} | {W[w]} | {100*W[w]/tot:.1f} | days in window {ndays[w]} | mean/day {W[w]/ndays[w]:.0f} |")
# daily stats
v=[D[k]['n'] for k in D]
print("\ndaily calls: days with data",len(D),"p50",pct(v,50),"p90",pct(v,90),"max",max(v),"min",min(v))
# per-hour peak days
dh=collections.Counter((r['called_at'][:13]) for r in rows)
print("busiest 8 hours (UTC):",dh.most_common(8))
# 2026-10-25 check and ids
print(c.execute(f"select count(*) from tool_calls where id<={MAXID} and called_at like '2026-10-25%'").fetchone()[0], c.execute(f"select max(called_at) from tool_calls where id<={MAXID} and called_at<'2026-10-26'").fetchone()[0], c.execute(f"select min(called_at) from tool_calls where id<={MAXID} and called_at>='2026-10-26'").fetchone()[0])
# gap detection > 6h
ts=sorted(r['called_at'] for r in rows)
gaps=[]
prev=None
for t in ts:
    if prev:
        a=datetime.datetime.strptime(prev[:19],'%Y-%m-%d %H:%M:%S'); b=datetime.datetime.strptime(t[:19],'%Y-%m-%d %H:%M:%S')
        g=(b-a).total_seconds()/3600
        if g>=6: gaps.append((round(g,1),prev[:16],t[:16]))
    prev=t
print("gaps>=6h between consecutive calls:",sorted(gaps,reverse=True)[:12], "n",len(gaps))
