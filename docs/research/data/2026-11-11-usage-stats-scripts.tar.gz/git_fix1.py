import re
p = "/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad/git_bench/src/main.rs"
s = open(p).read()
reps = [
 ('            repo.revparse_single("HEAD").unwrap().id().to_string().len()\n        }, ITERS);\n        bench("HEAD full oid (open+revparse)", "CLI',
  '            let x = repo.revparse_single("HEAD").unwrap().id().to_string().len(); x\n        }, ITERS);\n        bench("HEAD full oid (open+revparse)", "CLI'),
 ('            repo.statuses(None).unwrap().len()\n', '            let x = repo.statuses(None).unwrap().len(); x\n'),
 ('            repo.statuses(Some(&mut o)).unwrap().len()\n', '            let x = repo.statuses(Some(&mut o)).unwrap().len(); x\n'),
 ('                repo.diff_tree_to_tree(Some(&t1), Some(&t2), None).unwrap().deltas().len()\n', '                let x = repo.diff_tree_to_tree(Some(&t1), Some(&t2), None).unwrap().deltas().len(); x\n'),
 ('            repo.blame_file(Path::new("src/librarian/tools/gather.rs"), None).unwrap().len()\n', '            let x = repo.blame_file(Path::new("src/librarian/tools/gather.rs"), None).unwrap().len(); x\n'),
]
for a, b in reps:
    assert a in s, a
    s = s.replace(a, b)
open(p, "w").write(s)
print("ok")
