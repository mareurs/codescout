import pickle, collections, re
rows=pickle.load(open('lat_rows.pkl','rb'))
rc=[r for r in rows if r['tool']=='run_command']
print('rc n',len(rc),'has_in',sum(r['has_in'] for r in rc),'has_out',sum(r['has_out'] for r in rc),'timed_out true',sum(1 for r in rc if r['timed_out']))
print('outcome', collections.Counter(r['out'] for r in rc), 'fam', collections.Counter(r['fam'] for r in rc if r['out']!='success').most_common(8))
slow=[r for r in rc if r['lat']>=20000]
print('slow>=20s',len(slow),'with input',sum(r['has_in'] for r in slow),'with timed_out flag',sum(1 for r in slow if r['timed_out']))
print('tmo values slow:',collections.Counter(r['tmo'] for r in slow).most_common(10))
print('outcome slow',collections.Counter(r['out'] for r in slow),collections.Counter(r['fam'] for r in slow).most_common(6))
print('bg slow',sum(r['bg'] for r in slow))
for r in slow[:8]: print(r['id'],r['lat'],r['out'],r['fam'],r['tmo'],r['bg'],r['err'][:120].replace('\n',' '),'|',(r['cmd'] or '')[:60].replace('\n',' '))
# timed-out rows: how about err text containing 'timed out'
to=[r for r in rc if 'timed out' in r['err'].lower() or r['timed_out']]
print('rows err/timed_out text',len(to), collections.Counter(r['out'] for r in to))
print('lat of timeout-flag rows',sorted(r['lat'] for r in to)[:5],sorted(r['lat'] for r in to)[-5:])
