import json, os, subprocess, collections
SP = "/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad"
R = "/home/marius/work/claude/codescout"
d = json.load(open(SP + "/bench_parity_result.json"))
tracked = set(subprocess.run(["git", "ls-files"], cwd=R, capture_output=True, text=True).stdout.splitlines())
only_gg, only_rg = {}, {}
for r in d:
    if r["scope"] == "reg": continue
    for f in r["rg_vs_gg_files"]["only_c"]: only_gg.setdefault(f, []).append(r["id"] + "/" + r["scope"])
    for f in r["rg_vs_gg_files"]["only_a"]: only_rg.setdefault(f, []).append(r["id"] + "/" + r["scope"])
allf = sorted(set(only_gg) | set(only_rg))
ign = {}
p = subprocess.run(["git", "check-ignore", "--no-index", "-v", "--stdin"], cwd=R, input="\n".join(allf), capture_output=True, text=True)
for ln in p.stdout.splitlines():
    meta, f = ln.split("\t"); ign[f] = meta
def cls(f, side):
    hidden = any(c.startswith(".") for c in f.split("/"))
    return dict(tracked=f in tracked, ignored=f in ign and not ign[f].split(":")[2].startswith("!") if f in ign else False, hidden=hidden,
                symlink=os.path.islink(os.path.join(R, f)))
tally = collections.Counter(); ex = collections.defaultdict(list)
for side, dd in (("gg_only", only_gg), ("rg_only", only_rg)):
    for f in sorted(dd):
        c = cls(f, side); k = side + ": " + ",".join(n for n in ("tracked", "ignored", "hidden", "symlink") if c[n]) + ("" if c["tracked"] else " untracked")
        tally[k] += 1
        if len(ex[k]) < 3: ex[k].append(f + "  via " + ",".join(dd[f][:2]) + ("  ignore-rule=" + ign[f].split("\t")[0] if f in ign else ""))
for k, v in tally.most_common(): print(v, k); [print("     ", e) for e in ex[k]]
