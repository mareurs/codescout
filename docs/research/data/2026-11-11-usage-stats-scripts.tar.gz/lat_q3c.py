import pickle, collections, re, json
rows=pickle.load(open('lat_rows.pkl','rb'))
def pct(v,q):
    v=sorted(v)
    if not v: return 0
    k=(len(v)-1)*q; f=int(k); c=min(f+1,len(v)-1); return v[f]+(v[c]-v[f])*(k-f)
def st(v): return f"n={len(v)} p50={pct(v,.5):.0f} p90={pct(v,.9):.0f} p99={pct(v,.99):.0f} max={max(v)} sum_s={sum(v)/1000:.0f}"
def full(r):
    try: return json.loads(r['inp']) if r['inp'] and r['inp'].endswith('}') else {}
    except: return {}
# symbols modes
sy=[r for r in rows if r['tool']=='symbols']
def smode(r):
    d=full(r)
    if not d: return 'no-input'
    n=d.get('name'); p=d.get('path')
    if n and p: return 'name+path'
    if n: return 'name-only(project-wide)'
    if p: return 'path-only(overview)'
    return 'other'
m=collections.defaultdict(list)
for r in sy: m[smode(r)].append(r)
print('SYMBOLS modes'); 
for k,l in m.items(): print(' ',k,st([r['lat'] for r in l]))
# name+path split include_body
m2=collections.defaultdict(list)
for r in sy:
    d=full(r)
    if d.get('name'): 
        m2[('exact-namepath' if '/' in d['name'] else 'substr-name', 'body' if d.get('include_body') else 'nobody', 'scoped' if d.get('path') else 'proj')].append(r['lat'])
for k,l in sorted(m2.items(),key=lambda kv:-sum(kv[1])): print('  ',k,st(l))
# sym path overview dir vs file
m3=collections.defaultdict(list)
for r in sy:
    d=full(r)
    if d.get('path') and not d.get('name'):
        p=d['path']; m3['dir/glob' if (p.endswith('/') or '*' in p or '.' not in p.split('/')[-1]) else 'file'].append(r['lat'])
for k,l in m3.items(): print('  path-only',k,st(l))
# tail >=11537: mode distribution and root distribution
tail=[r for r in sy if r['lat']>=11537]
print(' tail modes',collections.Counter(smode(r) for r in tail), 'tail with workspace param', sum(1 for r in tail if full(r).get('workspace')))
print(' tail time share by mode', {k:round(sum(r['lat'] for r in tail if smode(r)==k)/1000) for k in m})
# symbols tail within-session clustering: tail rows per 5-min bucket
c=collections.Counter(r['ca'][:15] for r in tail); print(' tail clusters (10-min buckets with >=4):',[(k,v) for k,v in c.items() if v>=4])
# time at 20000 boundary for symbols
print(' symbols lat in [19900,20300]',sum(1 for r in sy if 19900<=r['lat']<=20300), '[11000,20000)',sum(1 for r in sy if 11000<=r['lat']<19900),'>20300',sum(1 for r in sy if r['lat']>20300))
# workspace actions
ws=[r for r in rows if r['tool']=='workspace']
m=collections.defaultdict(list)
for r in ws: m[r['action'] or 'no-input'].append(r['lat'])
print('\nWORKSPACE by action'); 
for k,l in m.items(): print(' ',k,st(l))
# librarian actions
lb=[r for r in rows if r['tool']=='librarian']
m=collections.defaultdict(list)
for r in lb: m[r['action'] or 'no-input'].append(r['lat'])
print('\nLIBRARIAN by action')
for k,l in sorted(m.items(),key=lambda kv:-sum(kv[1])): print(' ',k,st(l))
for t in ['doc','memory','index','edit_code','edit_file','create_file','grep','references','call_graph','tree','get_guide']:
    l=[r for r in rows if r['tool']==t]; m=collections.defaultdict(list)
    for r in l: m[r['action'] or ('no-input' if not r['has_in'] else 'noaction')].append(r['lat'])
    print('\n',t.upper(),'by action')
    for k,v in sorted(m.items(),key=lambda kv:-sum(kv[1]))[:8]: print('  ',k,st(v))
