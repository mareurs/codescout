import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from base_common import *
import datetime
c=conn()
rows=c.execute(f"select id,tool_name,called_at,outcome,overflowed,agent_id,project_root,err_family from tool_calls where id<={MAXID}").fetchall()
N=len(rows)
print("# S1 call mix, N=",N)
print("outcome values",collections.Counter(r['outcome'] for r in rows))
print("overflowed values",collections.Counter(r['overflowed'] for r in rows))
t=collections.defaultdict(lambda: collections.Counter())
for r in rows:
    d=t[r['tool_name']]; d['n']+=1; d[r['outcome']]+=1; d['ov']+= 1 if r['overflowed'] else 0
print("| tool | n | share% | success | recov_err | hard_err | err% | recov% of calls | hard% | overflow n | overflow% |")
print("|---|---|---|---|---|---|---|---|---|---|---|")
for k,d in sorted(t.items(), key=lambda x:-x[1]['n']):
    e=d['recoverable_error']+d['error']
    print(f"| {k} | {d['n']} | {100*d['n']/N:.2f} | {d['success']} | {d['recoverable_error']} | {d['error']} | {100*e/d['n']:.2f} | {100*d['recoverable_error']/d['n']:.2f} | {100*d['error']/d['n']:.2f} | {d['ov']} | {100*d['ov']/d['n']:.2f} |")
tot=collections.Counter(r['outcome'] for r in rows)
print("TOTAL",dict(tot), "err%",100*(tot['recoverable_error']+tot['error'])/N, "overflow",sum(1 for r in rows if r['overflowed']))
# weekly
def wk(s):
    d=datetime.datetime.strptime(s[:10],'%Y-%m-%d').date(); return (d-datetime.timedelta(days=d.weekday())).isoformat()
top=[k for k,_ in sorted(t.items(), key=lambda x:-x[1]['n'])[:8]]
w=collections.defaultdict(collections.Counter); wn=collections.Counter()
for r in rows:
    k=wk(r['called_at']); wn[k]+=1; w[k][r['tool_name']]+=1
print("\n## weekly share% top8 (week start Monday UTC); first/last weeks partial")
print("| week | calls | "+" | ".join(top)+" | other |")
print("|---|---|"+"---|"*(len(top)+1))
for k in sorted(wn):
    sh=[100*w[k][x]/wn[k] for x in top]; oth=100-sum(sh)
    print(f"| {k} | {wn[k]} | "+" | ".join(f"{x:.1f}" for x in sh)+f" | {oth:.1f} |")
# parent vs subagent
print("\n## parent vs subagent")
ps=collections.defaultdict(collections.Counter)
for r in rows:
    k='subagent' if r['agent_id'] else 'parent'
    ps[k]['n']+=1; ps[k]['err']+= r['outcome']!='success'; ps[k]['ov']+=bool(r['overflowed'])
    ps[k]['t_'+r['tool_name']]+=1
for k,d in ps.items(): print(k,d['n'],f"{100*d['n']/N:.1f}%","err",d['err'],f"{100*d['err']/d['n']:.2f}%","ov",d['ov'])
print("| tool | parent n | parent share% | subagent n | subagent share% | subagent fraction of tool% |")
print("|---|---|---|---|---|---|")
for k,_ in sorted(t.items(), key=lambda x:-x[1]['n']):
    a=ps['parent']['t_'+k]; b=ps['subagent']['t_'+k]
    print(f"| {k} | {a} | {100*a/ps['parent']['n']:.1f} | {b} | {100*b/ps['subagent']['n']:.1f} | {100*b/(a+b):.1f} |")
# roots
print("\n## roots")
rc=collections.defaultdict(collections.Counter)
for r in rows:
    k=classify_root(r['project_root']); rc[k]['n']+=1; rc[k]['err']+=r['outcome']!='success'; rc[k]['sub']+=bool(r['agent_id'])
print("| class | calls | share% | errors | err% | subagent share% |")
print("|---|---|---|---|---|---|")
for k,d in sorted(rc.items(), key=lambda x:-x[1]['n']):
    print(f"| {k} | {d['n']} | {100*d['n']/N:.1f} | {d['err']} | {100*d['err']/d['n']:.2f} | {100*d['sub']/d['n']:.1f} |")
# harness-ish
h=collections.Counter()
for r in rows:
    pr=r['project_root'] or ''
    if 'setup-ab' in pr: h['setup-ab']+=1
    elif pr.startswith('/tmp/'): h['/tmp/*']+=1
    elif '/.codex/worktrees/' in pr: h['codex worktree']+=1
print("harness-ish calls",h, sum(h.values()))
# tool mix per root class top5 tools
print("\n## top tools per root class (share% within class)")
tc=collections.defaultdict(collections.Counter)
for r in rows: tc[classify_root(r['project_root'])][r['tool_name']]+=1
for k,cn in tc.items():
    tot_=sum(cn.values()); print(k, ", ".join(f"{a} {100*b/tot_:.1f}" for a,b in cn.most_common(6)))
