import pickle, collections, re
S='/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad/'
rows=pickle.load(open(S+'lat_rows.pkl','rb'))
def pct(v,q):
    v=sorted(v); 
    if not v: return None
    k=(len(v)-1)*q; f=int(k); c=min(f+1,len(v)-1); return v[f]+(v[c]-v[f])*(k-f)
def stats(v): return [round(pct(v,q)) for q in (.5,.9,.99)]+[round(max(v))]
print("overall gap stats p50/p90/p99/max", stats([r['gap'] for r in rows]))
print("neg gaps (<-5ms):", sum(1 for r in rows if r['gap']<-5), "min", min(r['gap'] for r in rows))
print("gap>1000:", sum(1 for r in rows if r['gap']>1000), " >5000:", sum(1 for r in rows if r['gap']>5000), ">60000", sum(1 for r in rows if r['gap']>60000))
print("sum gap s:", round(sum(r['gap'] for r in rows)/1000), "sum lat s:", round(sum(r['lat'] for r in rows)/1000))
print("id>290000 avg lat, avg wall:", sum(r['lat'] for r in rows if r['id']>290000)/sum(1 for r in rows if r['id']>290000), sum(r['wall'] for r in rows if r['id']>290000)/sum(1 for r in rows if r['id']>290000))
print("\nper tool: n, gap p50 p90 p99 max, sumgap_s, share of total gap, lat p50")
by=collections.defaultdict(list)
for r in rows: by[r['tool']].append(r)
tot=sum(r['gap'] for r in rows)
for t,l in sorted(by.items(), key=lambda kv:-sum(r['gap'] for r in kv[1])):
    print(t,len(l),stats([r['gap'] for r in l]),round(sum(r['gap'] for r in l)/1000),f"{100*sum(r['gap'] for r in l)/tot:.1f}%", round(pct([r['lat'] for r in l],.5)))
print("\nper outcome:")
bo=collections.defaultdict(list)
for r in rows: bo[r['out']].append(r)
for t,l in bo.items(): print(t,len(l),stats([r['gap'] for r in l]),round(sum(r['gap'] for r in l)/1000))
print("\ngap buckets (all):")
b=[(-1e9,0),(0,10),(10,50),(50,100),(100,250),(250,500),(500,1000),(1000,2000),(2000,5000),(5000,1e12)]
for lo,hi in b: print(lo,hi,sum(1 for r in rows if lo<=r['gap']<hi))
print("\ngap by day-bucket (id range) p50/p90:")
for lo in range(180000,300000,20000):
    l=[r['gap'] for r in rows if lo<=r['id']<lo+20000]
    if l: print(lo,len(l),stats(l))
# which tools have big-gap rows (>1000)
c=collections.Counter(r['tool'] for r in rows if r['gap']>1000)
print("\nbig-gap(>1000ms) rows by tool:",c.most_common(12))
# gap vs session concurrency: rows with gap>1000 by project_root
c=collections.Counter(r['pr'] for r in rows if r['gap']>1000)
print("by root:",c.most_common(6))
# gap vs latency correlation: for rows with lat<100 vs lat>=1000 
for lo,hi in [(0,10),(10,100),(100,1000),(1000,10000),(10000,1e12)]:
    l=[r['gap'] for r in rows if lo<=r['lat']<hi]; print("lat in",lo,hi,len(l),stats(l))
