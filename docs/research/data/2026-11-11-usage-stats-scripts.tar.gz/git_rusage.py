#!/usr/bin/env python3
"""Run a command, print wall, user and sys CPU seconds of the whole child tree (wait4 rusage), and max RSS."""
import os, subprocess, sys, time
cmd = sys.argv[1:]
t0 = time.time()
p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
out = p.stdout.read()
_, status, ru = os.wait4(p.pid, 0)
wall = time.time() - t0
lines = out.decode(errors="replace").strip().split("\n")
print("\n".join(lines[-2:]))
print(f"wall={wall:.1f}s user={ru.ru_utime:.1f}s sys={ru.ru_stime:.1f}s cpu={ru.ru_utime+ru.ru_stime:.1f}s maxrss_kb={ru.ru_maxrss} exit={os.waitstatus_to_exitcode(status)}")
