import json, sys, statistics as st
sys.path.insert(0, "/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad")
import bench_common as b
SP = b.SP
d = json.load(open(SP + "/bench_out_cpu.joined.json"))
H = {sc: {r["name"]: r for r in json.load(open("%s/hf/hf_%s_q.json" % (SP, sc)))["results"]} for sc in ("repo", "src", "reg")}
lines = ["| combo | variant | wall ms/call (client, median) | server+child CPU ms/call (sum of ticks/n; 10 ms tick) | usage.db latency_ms median |", "|---|---|---|---|---|"]
for r in d["results"]:
    runs = [x for x in r["runs"] if not x["warm"]]
    n = len(runs)
    cpu = sum(x["cpu_ticks"] for x in runs) * 10.0 / n
    wall = st.median(x["wall_ms"] for x in runs)
    lat = st.median(x["latency_ms"] for x in runs if x.get("latency_ms") is not None)
    lines.append("| %s | %s | %.0f | %.0f | %.0f |" % (r["label"].rsplit("|", 1)[0], r["label"].rsplit("|", 1)[1], wall, cpu, lat))
lines.append("")
lines.append("| combo | rg raw (hyperfine) wall med ms | rg raw CPU med ms (user+sys) | git grep raw wall med | git grep raw CPU med |")
lines.append("|---|---|---|---|---|")
for pid, sk in [("P02", "repo"), ("P03", "repo"), ("P09", "repo"), ("P08", "repo"), ("P11", "src"), ("P05", "src"), ("Q5", "reg"), ("Q2", "reg")]:
    def g(tool):
        r = H[sk]["%s|%s|%s" % (pid, sk, tool)]
        w = [m["time_wall_clock"]["value"] * 1000 for m in r["measurements"]]
        c = [m["time_cpu"]["value"] * 1000 for m in r["measurements"]]
        return st.median(w), st.median(c)
    a, c = g("rg"), g("gg")
    lines.append("| %s %s | %.1f | %.1f | %.1f | %.1f |" % (pid, sk, a[0], a[1], c[0], c[1]))
open(SP + "/bench_cpu_tables.md", "w").write("\n".join(lines))
print("\n".join(lines))
