import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from base_common import *
R='/home/marius/work/claude/codescout/.codescout/'
L=open(R+'usage-dropped-rows.log').read().split('\n'); L=[l for l in L if l]
print("dropped lines",len(L),"fields histogram",collections.Counter(len(l.split('\t')) for l in L))
print("range",L[0][:23],L[-1][:23])
reas=collections.Counter(); tools=collections.Counter(); days=collections.Counter(); waits=[]; roots=collections.Counter(); builds=collections.Counter()
for l in L:
    f=l.split('\t'); tools[f[1]]+=1; days[f[0][:10]]+=1; reas[re.sub(r'\d+','#',f[3])[:90]]+=1; roots[classify_root(f[2] if f[2]!='-' else None) if f[2]!='-' else 'no-pin']+=1
    if len(f)>=7:
        try: waits.append(int(f[6]))
        except: pass
        builds[f[5]]+=1
print("reasons",reas.most_common(8)); print("tools",tools.most_common(12)); print("per day",sorted(days.items())); print("pin class",roots)
print("wait_ms (n=%d): p50 %s p90 %s max %s"%(len(waits),pct(waits,50),pct(waits,90),max(waits) if waits else None))
print("builds",builds.most_common(5))
print("lines with 4 fields day range",min(l[:10] for l in L if len(l.split('\t'))==4) if any(len(l.split('\t'))==4 for l in L) else None, max(l[:10] for l in L if len(l.split('\t'))==4) if any(len(l.split('\t'))==4 for l in L) else None)
print("lines with 7 fields day range",min(l[:10] for l in L if len(l.split('\t'))==7),max(l[:10] for l in L if len(l.split('\t'))==7))
# lock holds
K=[l for l in open(R+'usage-lock-holds.log').read().split('\n') if l]
print("\nlock-hold lines",len(K),"range",K[0][:23],K[-1][:23],"fields",collections.Counter(len(l.split('\t')) for l in K))
by=collections.defaultdict(list); det=collections.defaultdict(collections.Counter)
for l in K:
    f=l.split('\t'); ms=int(f[4]); by[f[3]].append(ms)
    d=f[5] if len(f)>5 else ''
    det[f[3]][re.sub(r'\d+','#',d)[:40]]+=1
allv=[v for x in by.values() for v in x]
print("overall p50 %.0f p90 %.0f p99 %.0f max %d; n>=1000ms %d, >=5000ms %d, >=30000ms %d"%(pct(allv,50),pct(allv,90),pct(allv,99),max(allv),sum(v>=1000 for v in allv),sum(v>=5000 for v in allv),sum(v>=30000 for v in allv)))
print("| kind | n | p50 ms | p90 | max | total s |")
for k,v in sorted(by.items(), key=lambda x:-sum(x[1])): print(f"| {k} | {len(v)} | {pct(v,50):.0f} | {pct(v,90):.0f} | {max(v)} | {sum(v)/1000:.0f} |")
for k in det: print(k,det[k].most_common(6))
print("min ms logged",min(allv))
# top 8 holds
print("top holds:"); 
for l in sorted(K,key=lambda l:-int(l.split('\t')[4]))[:8]: print(l[:200])
# insert holds by tool
it=collections.defaultdict(list)
for l in K:
    f=l.split('\t')
    if f[3]=='insert': it[f[5]].append(int(f[4]))
print("insert holds by tool: ",[(k,len(v),int(pct(v,50)),max(v)) for k,v in sorted(it.items(), key=lambda x:-len(x[1]))[:10]])
kd=collections.Counter(l[:10] for l in K); print("holds per day",sorted(kd.items()))
# overlap of drops: for each dropped row 7-field find holder covering
