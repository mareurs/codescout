import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_enrich import *
from grep_q23 import classify
rows=enrich()
L=[r for r in rows if r['latency'] is not None]
lat=[r['latency'] for r in L]
def row(nm,xs):
    xs=[x for x in xs if x is not None]
    if not xs: return f"{nm} | 0"
    return f"{nm} | {len(xs)} | {pct(xs,50):.0f} | {pct(xs,90):.0f} | {pct(xs,99):.0f} | {max(xs)} | {sum(1 for x in xs if x>=1000)} ({100*sum(1 for x in xs if x>=1000)/len(xs):.1f}%)"
print('name | n | p50 | p90 | p99 | max | >=1s')
print(row('ALL grep',lat))
print(row('parent',[r['latency'] for r in L if r['parent']])); print(row('sub',[r['latency'] for r in L if not r['parent']]))
for d0,d1 in (('2026-10-12','2026-10-30'),('2026-10-30','2026-11-11')):
    print(row(f'{d0}..{d1}',[r['latency'] for r in L if d0<=r['called_at'][:10]<d1]))
print('-- by path class (rows with input)')
for pc in ('root','subdir','file','abs_outside','buffer'):
    print(row(pc,[r['latency'] for r in L if r['has_in'] and path_class(r['ip'].get('path'))==pc]))
print('-- by glob presence'); 
print(row('glob',[r['latency'] for r in L if r['has_in'] and 'glob' in r['ip']])); print(row('no glob',[r['latency'] for r in L if r['has_in'] and 'glob' not in r['ip']]))
print('-- root scope x glob')
print(row('root+glob',[r['latency'] for r in L if r['has_in'] and path_class(r['ip'].get('path'))=='root' and 'glob' in r['ip']]))
print(row('root no glob',[r['latency'] for r in L if r['has_in'] and path_class(r['ip'].get('path'))=='root' and 'glob' not in r['ip']]))
print('-- by mode')
for m,f in (('files',lambda ip:ip.get('mode')=='files' or ip.get('output_mode') in('files_with_matches','files','count')),('lines',lambda ip:not (ip.get('mode')=='files' or ip.get('output_mode') in('files_with_matches','files','count')))):
    print(row(m,[r['latency'] for r in L if r['has_in'] and f(r['ip'])]))
print('-- by include_hidden'); print(row('hidden',[r['latency'] for r in L if r['has_in'] and r['ip'].get('include_hidden') in (True,'true')]))
print('-- by pattern class')
for k in ['alternation_literal','alternation_regex','regex_meta','identifier','multiword_text','very_long(>150)','qualified_identifier','other_literal','path_like']:
    print(row(k,[r['latency'] for r in L if r['has_in'] and classify(r['ip'].get('pattern'))==k]))
print('-- by result size (rows with out)')
for lo,hi,nm in ((0,0,'zero'),(1,5,'1-5'),(6,50,'6-50'),(51,10**9,'51+')):
    print(row(nm,[r['latency'] for r in L if r['out'].get('n') is not None and lo<=(0 if r['out']['zero'] else r['out']['n'])<=hi]))
print(row('overflowed',[r['latency'] for r in L if r['overflowed']]))
print('-- by context_lines'); 
print(row('ctx0',[r['latency'] for r in L if r['has_in'] and not r['ip'].get('context_lines')])); print(row('ctx>0',[r['latency'] for r in L if r['has_in'] and r['ip'].get('context_lines') not in (None,0,'0')]))
print('-- near budget (>=19000 ms)',[ (r['id'],r['latency']) for r in L if r['latency']>=19000])
print('-- >=5000 ms top 25')
slow=sorted([r for r in L if r['latency']>=3000],key=lambda r:-r['latency'])
print('n>=3s',len(slow))
for r in slow[:25]:
    ip=r['ip'] or {}
    print(r['id'],r['latency'],r['called_at'][5:10],'P' if r['parent'] else 'S',repr(ip.get('pattern'))[:45],ip.get('path'),str(ip.get('glob'))[:30],ip.get('mode'),'hid' if ip.get('include_hidden') else '', 'n=',r['out'].get('n'))
# slow by path
c=collections.Counter(); 
for r in slow:
    c[(path_class(r['ip'].get('path')) if r['has_in'] else 'noinput')]+=1
print('slow(>=3s) by path class',c)
c=collections.Counter(((r['ip'] or {}).get('path') or '.') for r in slow if r['has_in'])
print(c.most_common(10))
