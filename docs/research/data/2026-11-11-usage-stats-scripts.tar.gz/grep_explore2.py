import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_common import *
rows=load()
shown=collections.Counter()
for r in rows:
    t=out_text(r['oj'])
    if t is None: continue
    first=t.split('\n',1)[0]
    kind=None
    if first.startswith('{'): kind='json'
    elif first.startswith('⚠ Reads'): kind='reads_warn'
    elif first.startswith('⚠'): kind='other_warn'
    elif re.match(r'^[\w./-]+ \(\d+\)$',first): kind='filegroup'
    elif first.startswith('/home'): kind='abs'
    elif first.startswith('@bg'): kind='bg'
    if kind and shown[kind]<2:
        shown[kind]+=1
        print('=====',kind,r['id'],r['ij'][:200] if r['ij'] else None); print(t[:700])
