import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_enrich import *
import pickle
rows={r['id']:r for r in enrich()}
b=pickle.load(open('grep_q4b.pkl','rb')); a={x['id']:x for x in pickle.load(open('grep_q4a.pkl','rb'))}
tz=[x for x in b if x['verdict']=='true_zero_absent_everywhere_now']
print('true zeros',len(tz),'literal pattern checked by pickaxe',sum(1 for x in tz if x.get('removed_since_call') is not None),'removed since call',sum(1 for x in tz if x.get('removed_since_call')))
for x in tz:
    if x.get('removed_since_call'): print(' removed:',x['id'],rows[x['id']]['ip']['pattern'][:60])
ct=collections.defaultdict(collections.Counter)
for x in b: ct[x['verdict']][a[x['id']]['bucket']]+=1
for v,c in ct.items():
    print(v,sum(c.values())); 
    for k,n in c.most_common(): print('     ',n,k)
# examples
import random; random.seed(3)
for v in ('true_zero_absent_everywhere_now','scope_miss_code_elsewhere','scope_miss_only_docs_or_records_elsewhere','scope_miss_match_only_in_hidden_or_ignored','starved_scope_admits_no_file_now','tree_changed_match_introduced_or_removed_after_call','path_never_existed_in_git'):
    xs=[x for x in b if x['verdict']==v]
    print('==',v)
    for x in random.sample(xs,min(3,len(xs))):
        ip=rows[x['id']]['ip']
        print('  ',x['id'],repr(ip.get('pattern'))[:80],'| path',ip.get('path'),'| glob',str(ip.get('glob'))[:60],'| hid',ip.get('include_hidden'),'| wide',x.get('wide_files')[:2] if x.get('wide_files') else None,'| next',a[x['id']]['bucket'])
