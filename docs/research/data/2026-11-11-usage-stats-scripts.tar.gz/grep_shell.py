import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_common import *
import shlex, os
def split_segments(cmd):
    """split on unquoted | ; && || newline; return list of (segment, preceded_by_pipe)"""
    segs=[]; cur=[]; q=None; i=0; pipe_before=False; n=len(cmd)
    while i<n:
        ch=cmd[i]
        if q:
            cur.append(ch)
            if ch=='\\' and q=='"' and i+1<n: cur.append(cmd[i+1]); i+=2; continue
            if ch==q: q=None
            i+=1; continue
        if ch in '\'"': q=ch; cur.append(ch); i+=1; continue
        if ch=='\\' and i+1<n: cur.append(ch); cur.append(cmd[i+1]); i+=2; continue
        if ch=='|' :
            if i+1<n and cmd[i+1]=='|': segs.append((''.join(cur),pipe_before)); cur=[]; pipe_before=False; i+=2; continue
            segs.append((''.join(cur),pipe_before)); cur=[]; pipe_before=True; i+=1
            if i<n and cmd[i]=='&': i+=1
            continue
        if ch==';' or ch=='\n': segs.append((''.join(cur),pipe_before)); cur=[]; pipe_before=False; i+=1; continue
        if ch=='&' and i+1<n and cmd[i+1]=='&': segs.append((''.join(cur),pipe_before)); cur=[]; pipe_before=False; i+=2; continue
        cur.append(ch); i+=1
    segs.append((''.join(cur),pipe_before))
    return [(s.strip(),p) for s,p in segs if s.strip()]
WRAP={'timeout','time','command','sudo','nice','env','xargs','nohup'}
def toks_of(seg):
    try: return shlex.split(seg,posix=True)
    except Exception: return seg.split()
RG_VAL=set('-e -f -g --glob --iglob -t --type -T --type-not -A -B -C -m --max-count -j --threads -M --max-columns -r --replace --ignore-file -E --encoding --engine --sort --sortr -d --max-depth --max-filesize --context --after-context --before-context --regexp --file --type-add --pre --pre-glob --path-separator --colors --color --field-match-separator --context-separator --dfa-size-limit --regex-size-limit'.split())
GREP_VAL=set('-e -f -A -B -C -m --include --exclude --exclude-dir --include-dir -d -D --label --max-count --regexp --file --context --after-context --before-context --exclude-from -T'.split())
GITGREP_VAL=set('-e -f -A -B -C -m --max-depth --threads -O --open-files-in-pager --max-count --regexp --file --context --after-context --before-context'.split())
FD_VAL=set('-e --extension -t --type -E --exclude -d --max-depth -x --exec -X --exec-batch -S --size --changed-within --changed-before -c --color -j --threads --owner'.split())
def parse_flags(args,valset):
    flags=[]; pos=[]; vals={}
    i=0; after_dd=False; dd_args=[]
    while i<len(args):
        a=args[i]
        if after_dd: dd_args.append(a); i+=1; continue
        if a=='--': after_dd=True; i+=1; continue
        if a.startswith('--'):
            nm=a.split('=',1)[0]; flags.append(nm)
            if '=' in a: vals.setdefault(nm,[]).append(a.split('=',1)[1])
            elif nm in valset and i+1<len(args): vals.setdefault(nm,[]).append(args[i+1]); i+=1
        elif a.startswith('-') and len(a)>1 and not a[1].isdigit() or (a.startswith('-') and len(a)>1 and a[1:].isdigit()):
            # short cluster
            if a[1:].isdigit():  # -3 style context (grep)
                flags.append('-C'); vals.setdefault('-C',[]).append(a[1:])
            else:
                cl=a[1:]; j=0
                while j<len(cl):
                    f='-'+cl[j]; flags.append(f)
                    if f in valset:
                        rest=cl[j+1:]
                        if rest: vals.setdefault(f,[]).append(rest)
                        elif i+1<len(args): vals.setdefault(f,[]).append(args[i+1]); i+=1
                        break
                    j+=1
        else: pos.append(a)
        i+=1
    return flags,pos,dd_args,vals
def analyze_command(cmd):
    """return list of search-use records for this run_command command"""
    out=[]
    for seg,piped in split_segments(cmd):
        t=toks_of(seg)
        # strip leading assignments / wrappers
        while t and (re.match(r'^[A-Za-z_][A-Za-z0-9_]*=',t[0]) or t[0] in WRAP):
            w=t[0]; t=t[1:]
            if w=='timeout' and t and re.match(r'^[\d.]+[smh]?$',t[0]): t=t[1:]
            if w=='xargs': piped=True
        if not t: continue
        # 'cd x' alone etc ignored
        w=t[0]; base=os.path.basename(w)
        rec=None
        if base=='rg':
            fl,pos,dd,vals=parse_flags(t[1:],RG_VAL)
            has_e=('-e' in fl) or ('--regexp' in fl) or ('-f' in fl) or ('--files' in fl)
            pattern=None; paths=list(pos)+list(dd)
            if '-e' in vals: pattern=vals['-e'][0]
            elif '--regexp' in vals: pattern=vals['--regexp'][0]
            elif '--files' in fl: pattern=None
            elif pos: pattern=pos[0]; paths=pos[1:]+dd
            rec={'fam':'rg','flags':fl,'pattern':pattern,'paths':paths,'piped':piped,'vals':vals,'files_listing':'--files' in fl}
        elif base in ('grep','egrep','fgrep'):
            fl,pos,dd,vals=parse_flags(t[1:],GREP_VAL)
            pattern=None; paths=list(pos)+list(dd)
            if '-e' in vals: pattern=vals['-e'][0]
            elif '--regexp' in vals: pattern=vals['--regexp'][0]
            elif '-f' in vals: pattern=None
            elif pos: pattern=pos[0]; paths=pos[1:]+dd
            if base=='egrep': fl=fl+['-E']
            if base=='fgrep': fl=fl+['-F']
            rec={'fam':'grep','flags':fl,'pattern':pattern,'paths':paths,'piped':piped,'vals':vals}
        elif base=='git':
            # find 'grep' subcommand
            j=1
            while j<len(t) and t[j].startswith('-'):
                if t[j] in ('-C','-c','--git-dir','--work-tree') and j+1<len(t): j+=2
                else: j+=1
            if j<len(t) and t[j]=='grep':
                fl,pos,dd,vals=parse_flags(t[j+1:],GITGREP_VAL)
                pattern=None; revs=[]
                if '-e' in vals: pattern=vals['-e'][0]; cand=pos
                elif pos: pattern=pos[0]; cand=pos[1:]
                else: cand=[]
                # rev-like tokens before --: tokens that are not existing paths... heuristic
                revs=[c for c in cand if re.match(r'^(HEAD|FETCH_HEAD|ORIG_HEAD|origin/|upstream/|refs/|[0-9a-f]{7,40}$|v?\d+\.\d+|main$|master$|experiments$|HEAD[~^@]|@\{)',c) or re.match(r'^[\w.-]+/[\w./-]+$',c) and not os.path.exists(os.path.join('/home/marius/work/claude/codescout',c)) and not c.endswith(('.rs','.md','.toml','.py','.sh','/'))]
                paths=[c for c in cand if c not in revs]+dd
                rec={'fam':'git grep','flags':fl,'pattern':pattern,'paths':paths,'piped':piped,'vals':vals,'revs':revs,'dd':dd}
        elif base=='find':
            args=t[1:]; paths=[]; expr=[]
            k=0
            while k<len(args) and not args[k].startswith('-') and args[k] not in ('(',')','!'): paths.append(args[k]); k+=1
            expr=args[k:]
            ef=[a for a in expr if a.startswith('-')]
            rec={'fam':'find','flags':ef,'pattern':None,'paths':paths,'piped':piped,'expr':expr}
        elif base=='fd' or base=='fdfind':
            fl,pos,dd,vals=parse_flags(t[1:],FD_VAL)
            rec={'fam':'fd','flags':fl,'pattern':pos[0] if pos else None,'paths':pos[1:]+dd,'piped':piped,'vals':vals}
        if rec:
            rec['seg']=seg
            out.append(rec)
    return out
if __name__=='__main__':
    for c in ["rg -n 'fn foo' src/ | head -20","git grep -n -e foo HEAD~3 -- src/*.rs","cargo test 2>&1 | grep -E 'FAILED|error'","grep -rn --include='*.rs' foo src","find . -name '*.rs' -mtime -1","rg -P '(?<=a)b' -g '*.md'"]:
        print(c,[(r['fam'],r['piped'],r['pattern'],r['paths'],r['flags']) for r in analyze_command(c)])
