import pickle, collections, json
rows=pickle.load(open('lat_rows.pkl','rb'))
def full(r):
    try: return json.loads(r['inp']) if r['inp'] and r['inp'].endswith('}') else {}
    except: return {}
l=[r for r in rows if r['tool']=='symbols' and r['lat']>=25000]
print(len(l))
for r in l: 
    d=full(r); print(r['id'],r['ca'][5:19],r['lat'],r['sess'][:6],'sub' if r['ag'] else 'par',(d.get('workspace') or r['pr'])[-38:],'|',(d.get('path') or '')[-30:],'|',(d.get('name') or '')[:24])
