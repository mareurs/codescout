import subprocess, sys
R="/home/marius/work/claude/codescout"
cands = sys.argv[1:]
for c in cands:
    r = subprocess.run(["rg","-c","-e",c], cwd=R, capture_output=True, text=True)
    lines=[l for l in r.stdout.splitlines() if l]
    tot=sum(int(l.rsplit(":",1)[1]) for l in lines)
    print(repr(c), "files", len(lines), "lines", tot, "| top:", lines[:2])
