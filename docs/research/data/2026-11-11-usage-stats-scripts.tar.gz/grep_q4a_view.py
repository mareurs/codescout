import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_enrich import *
import pickle, random
res=pickle.load(open('grep_q4a.pkl','rb'))
rows={r['id']:r for r in enrich()}
random.seed(7)
sm=[x for x in res if x['bucket']=='scope_miss']
for x in random.sample(sm,14):
    ip=rows[x['id']]['ip']
    print(x['id'],'ZERO:',repr(ip.get('pattern'))[:80],'path=',ip.get('path'),'glob=',ip.get('glob'),'hid=',ip.get('include_hidden'),'ws=',str(ip.get('workspace'))[-30:])
    print('     FOLLOW',x['follow'])
c=collections.Counter()
mo=[x for x in res if x['bucket']=='unknown_followup_output_missing']
print('output_missing detail')
