import sqlite3, json, re, collections
DB='/home/marius/work/claude/codescout/.codescout/usage.db'
MAXID=299175
def conn():
    return sqlite3.connect('file:'+DB+'?mode=ro', uri=True)
def out_text(oj):
    if not oj: return None
    try:
        v=json.loads(oj)
    except Exception:
        return oj
    if isinstance(v,list):
        return "".join(x.get('text','') for x in v if isinstance(x,dict))
    if isinstance(v,dict): return v.get('text') or json.dumps(v)
    return str(v)
def inp(ij):
    if not ij: return None
    try: return json.loads(ij)
    except Exception: return None
def load(tool='grep'):
    c=conn()
    rows=c.execute("select id,tool_name,called_at,started_at,latency_ms,outcome,overflowed,session_id,agent_id,input_json,output_json,project_root,err_family,overflow_tokens,error_msg from tool_calls where tool_name=? and id<=?",(tool,MAXID)).fetchall()
    cols=['id','tool','called_at','started_at','latency','outcome','overflowed','sid','aid','ij','oj','root','fam','otok','err']
    return [dict(zip(cols,r)) for r in rows]
def pct(xs,p):
    xs=sorted(xs)
    if not xs: return None
    k=(len(xs)-1)*p/100
    f=int(k); c=min(f+1,len(xs)-1)
    return xs[f]+(xs[c]-xs[f])*(k-f)
