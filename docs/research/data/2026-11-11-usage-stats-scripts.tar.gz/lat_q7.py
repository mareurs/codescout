import pickle, collections, json
rows=pickle.load(open('lat_rows.pkl','rb'))
def pct(v,q):
    v=sorted(v)
    if not v: return 0
    k=(len(v)-1)*q; f=int(k); c=min(f+1,len(v)-1); return v[f]+(v[c]-v[f])*(k-f)
def full(r):
    try: return json.loads(r['inp']) if r['inp'] and r['inp'].endswith('}') else {}
    except: return {}
no=[r for r in rows if r['tool']=='symbols' and r['has_in'] and full(r).get('name') and not full(r).get('path')]
print('symbols name-only by 5-day bucket: n p50 p90 share>=8000ms')
b=collections.defaultdict(list)
for r in no: b[r['ca'][:8]+str(int(r['ca'][8:10])//5)].append(r['lat'])
for k in sorted(b): v=b[k]; print(' ',k,len(v),round(pct(v,.5)),round(pct(v,.9)),f"{sum(x>=8000 for x in v)/len(v):.2f}")
last=[r for r in no if r['ca']>='2026-11-01']; print('since 11-01: n',len(last),'p50',pct([r['lat'] for r in last],.5),'rows<3000',sum(r['lat']<3000 for r in last))
# histograms
def hist(tool,edges,sel=lambda r:True,label=''):
    l=[r['lat'] for r in rows if r['tool']==tool and sel(r)]
    out=[]
    for lo,hi in zip(edges,edges[1:]): out.append(f"[{lo/1000:g},{hi/1000:g})s:{sum(lo<=x<hi for x in l)}")
    out.append(f">={edges[-1]/1000:g}s:{sum(x>=edges[-1] for x in l)}")
    print(f"\n{tool}{label} n={len(l)}: "+'  '.join(out))
E=[0,100,500,1000,2000,5000,8000,10000,12000,15000,19000,19900,20100,21000,25000,29000,29900,30100,31000,40000,44000,44900,45100,46000,59000,59900,60100,70000]
for t in ['symbols','grep','references','call_graph','symbol_at','edit_code','semantic_search','librarian','workspace','index']:
    hist(t,E)
# zoom near budgets: 100ms-bucket windows
def zoom(tool,T,w=1000):
    l=[r['lat'] for r in rows if r['tool']==tool and T-w<=r['lat']<=T+w]
    c=collections.Counter((x-(T-w))//100 for x in l)
    print(f" {tool} within +-{w}ms of {T}: n={len(l)}; per-100ms bucket (from {T-w}):",[c.get(i,0) for i in range(2*w//100+1)])
for tool,T in [('grep',20000),('symbols',20000),('references',30000),('references',45000),('symbols',8000),('call_graph',30000)]: zoom(tool,T)
# symbols path-scoped: share hitting budget (response says search cut) -> latency between 19.9 and 20.5
sc=[r['lat'] for r in rows if r['tool']=='symbols' and r['has_in'] and full(r).get('path') and full(r).get('name')]
print('\nsymbols name+path n',len(sc),'>=19000',sum(x>=19000 for x in sc),'max',max(sc),' [5000,19000)',sum(5000<=x<19000 for x in sc))
over=[r for r in rows if r['tool'] in ('symbols','grep') and r['lat']>21000]
print('symbols/grep >21s:',len(over),collections.Counter(r['tool'] for r in over),' with gap>1s (rows delayed outside latency):',sum(r['gap']>1000 for r in over))
for r in sorted(over,key=lambda r:-r['lat'])[:6]: print('  ',r['id'],r['tool'],r['lat'],(r['inp'] or '')[:110])
# check explicit time_budget_ms values used
tb=collections.Counter(full(r).get('time_budget_ms') for r in rows if r['tool'] in('symbols','grep') and r['has_in'] and full(r).get('time_budget_ms'))
print('explicit time_budget_ms used:',tb)
