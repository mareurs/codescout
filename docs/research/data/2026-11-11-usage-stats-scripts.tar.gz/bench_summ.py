import json, sys, statistics as st
def q(v, f):
    v = sorted(v); k = (len(v) - 1) * f; lo = int(k); hi = min(lo + 1, len(v) - 1)
    return v[lo] + (v[hi] - v[lo]) * (k - lo)
def summ(path):
    d = json.load(open(path))
    rows = []
    for r in d["results"]:
        m = [x for x in r["runs"] if not x["warm"]]
        lat = [x["latency_ms"] for x in m if x.get("latency_ms") is not None]
        wall = [x["wall_ms"] for x in m]
        byt = [x["bytes"] for x in m]
        rows.append(dict(label=r["label"], n=len(m), lat_med=st.median(lat) if lat else None, lat_min=min(lat) if lat else None,
                         lat_p90=q(lat, .9) if lat else None, wall_med=st.median(wall), wall_min=min(wall), bytes=st.median(byt),
                         err=sum(1 for x in m if x.get("isError"))))
    return rows
if __name__ == "__main__":
    for p in sys.argv[1:]:
        for r in summ(p):
            print("%-22s n=%d lat med/min/p90 = %s/%s/%s  wall med=%.0f min=%.0f  bytes=%d err=%d" % (r["label"], r["n"], r["lat_med"], r["lat_min"], None if r["lat_p90"] is None else round(r["lat_p90"]), r["wall_med"], r["wall_min"], r["bytes"], r["err"]))
