import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from base_common import *
c=conn()
rows=c.execute(f"select id,tool_name,agent_id,outcome,overflowed,overflow_tokens,length(CAST(output_json AS BLOB)) ob,length(CAST(input_json AS BLOB)) ib, emitted_output_id,read_output_ids from tool_calls where id<={MAXID}").fetchall()
N=len(rows)
have=[r for r in rows if r['ob']]
print("rows with output_json",len(have),f"{100*len(have)/N:.1f}%","parent",sum(1 for r in have if not r['agent_id']),"/",sum(1 for r in rows if not r['agent_id']),"subagent",sum(1 for r in have if r['agent_id']),"/",sum(1 for r in rows if r['agent_id']))
print("output_json null vs empty:",c.execute(f"select sum(output_json is null),sum(output_json=''),sum(output_json='null'),sum(output_json='{{}}') from tool_calls where id<={MAXID}").fetchone()[:])
tb=collections.defaultdict(list)
for r in have: tb[r['tool_name']].append(r['ob'])
tot=sum(sum(v) for v in tb.values())
print("total output bytes",tot)
print("| tool | rows w/ output | cov% of tool rows | p50 | p90 | p99 | max | total bytes | share% |")
print("|---|---|---|---|---|---|---|---|---|")
alln=collections.Counter(r['tool_name'] for r in rows)
for k,v in sorted(tb.items(), key=lambda x:-sum(x[1])):
    print(f"| {k} | {len(v)} | {100*len(v)/alln[k]:.0f} | {pct(v,50):.0f} | {pct(v,90):.0f} | {pct(v,99):.0f} | {max(v)} | {sum(v)} | {100*sum(v)/tot:.1f} |")
print("\n## largest 15 outputs")
for r in sorted(have,key=lambda r:-r['ob'])[:15]:
    inp=c.execute("select substr(input_json,1,200) from tool_calls where id=?",(r['id'],)).fetchone()[0]
    print(r['id'],r['tool_name'],r['ob'],"agent" if r['agent_id'] else "parent",r['outcome'],repr(inp))
# overflow tokens
print("\n## overflow_tokens")
ov=[r for r in rows if r['overflow_tokens']]
print("rows with overflow_tokens>0",len(ov),"sum",sum(r['overflow_tokens'] for r in ov),"overflowed=1 rows",sum(1 for r in rows if r['overflowed']),"overflowed=1 & tokens null/0",sum(1 for r in rows if r['overflowed'] and not r['overflow_tokens']), "tokens>0 & overflowed=0", sum(1 for r in ov if not r['overflowed']))
ot=collections.defaultdict(list)
for r in ov: ot[r['tool_name']].append(r['overflow_tokens'])
print("| tool | overflow rows | sum tokens | p50 | p90 | max | overflow rate% of tool calls |")
print("|---|---|---|---|---|---|---|")
for k,v in sorted(ot.items(), key=lambda x:-sum(x[1])):
    print(f"| {k} | {len(v)} | {sum(v)} | {pct(v,50):.0f} | {pct(v,90):.0f} | {max(v)} | {100*len(v)/alln[k]:.1f} |")
# emitted/read
print("\n## buffers")
em=[r for r in rows if r['emitted_output_id']]
rd=[r for r in rows if r['read_output_ids'] and r['read_output_ids'] not in ('[]','')]
print("rows with emitted_output_id",len(em),"rows with read_output_ids",len(rd))
print("emitted by tool",collections.Counter(r['tool_name'] for r in em).most_common(10))
print("read-back by tool",collections.Counter(r['tool_name'] for r in rd).most_common(10))
print("sample emitted",[r['emitted_output_id'] for r in em[:5]],"sample read",[r['read_output_ids'] for r in rd[:5]])
print("emitted prefixes",collections.Counter((r['emitted_output_id'] or '')[:5] for r in em))
print("ov rows with emitted id", sum(1 for r in ov if r['emitted_output_id']), "emitted rows overflowed", sum(1 for r in em if r['overflowed']))
# emitted ids unique & read
emitted={}
for r in em: emitted.setdefault(r['emitted_output_id'],r)
readids=collections.Counter()
for r in rd:
    try: l=json.loads(r['read_output_ids'])
    except Exception: l=[r['read_output_ids']]
    for x in l: readids[x]+=1
print("distinct emitted",len(emitted),"distinct read ids",len(readids),"emitted ids read>=1",sum(1 for x in emitted if x in readids),"read ids not in emitted set",sum(1 for x in readids if x not in emitted))
