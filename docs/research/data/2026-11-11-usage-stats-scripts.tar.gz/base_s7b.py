import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from base_common import *
import datetime
c=conn()
rows=c.execute(f"select id,tool_name,called_at,agent_id,input_json is null or input_json='' ei, output_json is null or output_json='' eo, tool_use_id,effect_class,attribution_outcome,attribution_ms,observed_changed,deliveries_json,session_id,outcome from tool_calls where id<={MAXID}").fetchall()
N=len(rows)
def wk(s):
    d=datetime.date.fromisoformat(s[:10]); return (d-datetime.timedelta(days=d.weekday())).isoformat()
print("empty input: total",sum(r['ei'] for r in rows),f"{100*sum(r['ei'] for r in rows)/N:.1f}%","empty output",sum(r['eo'] for r in rows),f"{100*sum(r['eo'] for r in rows)/N:.1f}%")
print("input_json null vs ''",c.execute(f"select sum(input_json is null),sum(input_json='') from tool_calls where id<={MAXID}").fetchone()[:])
print("| week | calls | parent | empty input parent% | empty input sub% | empty output parent% | empty output sub% |")
w=collections.defaultdict(collections.Counter)
for r in rows:
    k=wk(r['called_at']); s='s' if r['agent_id'] else 'p'
    w[k]['n'+s]+=1; w[k]['ei'+s]+=r['ei']; w[k]['eo'+s]+=r['eo']
for k in sorted(w):
    d=w[k]; f=lambda a,b: f"{100*a/b:.1f}" if b else "-"
    print(f"| {k} | {d['np']+d['ns']} | {d['np']} | {f(d['eip'],d['np'])} | {f(d['eis'],d['ns'])} | {f(d['eop'],d['np'])} | {f(d['eos'],d['ns'])} |")
# daily empty input to find the cutover, and empty output cutover
dd=collections.defaultdict(collections.Counter)
for r in rows:
    k=r['called_at'][:10]; dd[k]['n']+=1; dd[k]['ei']+=r['ei']; dd[k]['eop']+= r['eo'] and not r['agent_id']; dd[k]['np']+= not r['agent_id']
print("daily empty input% / parent empty-output%:",[(k,round(100*v['ei']/v['n']),round(100*v['eop']/v['np']) if v['np'] else None) for k,v in sorted(dd.items())])
last_empty_input=max(r['called_at'] for r in rows if r['ei']); print("last empty input row",last_empty_input)
# tool_use_id
tu=[r for r in rows if r['tool_use_id']]
print("\nrows with tool_use_id",len(tu),f"{100*len(tu)/N:.1f}%","first",min(r['called_at'] for r in tu) if tu else None,"distinct",len({r['tool_use_id'] for r in tu}))
print("tool_use_id by week",{k:(sum(1 for r in tu if wk(r['called_at'])==k),w[k]['np']+w[k]['ns']) for k in sorted(w)})
print("tool_use_id by agent",collections.Counter('sub' if r['agent_id'] else 'parent' for r in tu))
print("sample tool_use_id",[r['tool_use_id'] for r in tu[:2]])
# post-first-appearance coverage
if tu:
    f0=min(r['called_at'] for r in tu); after=[r for r in rows if r['called_at']>=f0]
    print("coverage after first appearance",len(tu),"/",len(after),f"{100*len(tu)/len(after):.1f}%")
# effect_class
ec=collections.Counter((r['tool_name'],r['effect_class']) for r in rows if r['effect_class'] is not None)
print("\neffect_class by tool",ec,"non-null",sum(ec.values()),"run_command rows",sum(1 for r in rows if r['tool_name']=='run_command'))
ecr=collections.Counter(r['effect_class'] for r in rows if r['tool_name']=='run_command'); print("run_command effect_class",ecr)
first_ec=min(r['called_at'] for r in rows if r['effect_class'] is not None); print("first effect_class row",first_ec)
# observed changed
oc=collections.Counter((r['effect_class'],r['observed_changed']) for r in rows if r['tool_name']=='run_command')
print("run_command (effect_class, observed_changed):",oc)
print("observed_changed non-run_command non-null",sum(1 for r in rows if r['tool_name']!='run_command' and r['observed_changed'] is not None))
print("observed_changed=1 by outcome",collections.Counter(r['outcome'] for r in rows if r['observed_changed']==1))
# attribution
ao=collections.Counter(r['attribution_outcome'] for r in rows)
print("\nattribution_outcome",ao)
print("by tool non-null",collections.Counter(r['tool_name'] for r in rows if r['attribution_outcome']))
ms=collections.defaultdict(list)
for r in rows:
    if r['attribution_outcome'] and r['attribution_ms'] is not None: ms[r['attribution_outcome']].append(r['attribution_ms'])
for k,v in ms.items(): print(k,len(v),"ms p50",pct(v,50),"p90",pct(v,90),"max",max(v))
print("first attribution row",min((r['called_at'] for r in rows if r['attribution_outcome']),default=None))
rc_nonzero=sum(1 for r in rows if r['tool_name']=='run_command' and r['outcome']!='success')
print("run_command errors",rc_nonzero)
