import sys; sys.path.insert(0,'/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad')
from grep_enrich import *
rows=enrich(); O=[r for r in rows if r['out']['has_out'] and r['out'].get('hkind') or r['out'].get('zero')]
print('parseable result rows',len(O))
def zr(xs): 
    z=sum(1 for r in xs if r['out']['zero']); return f"{len(xs)} | {z} | {100*z/max(1,len(xs)):.1f}%"
print('zero rate | rows with output | zeros | %')
for pc in ('root','subdir','file','abs_outside','buffer'):
    print('path',pc,'|',zr([r for r in O if r['has_in'] and path_class(r['ip'].get('path'))==pc]))
print('glob',zr([r for r in O if r['has_in'] and 'glob' in r['ip']]),'; no glob',zr([r for r in O if r['has_in'] and 'glob' not in r['ip']]))
print('include_hidden',zr([r for r in O if r['has_in'] and r['ip'].get('include_hidden') in (True,'true')]))
print('ignore_case',zr([r for r in O if r['has_in'] and r['ip'].get('ignore_case') in (True,'true')]))
print('mode files',zr([r for r in O if r['has_in'] and r['ip'].get('mode')=='files']),'; mode lines/default',zr([r for r in O if r['has_in'] and r['ip'].get('mode')!='files']))
print('parent',zr([r for r in O if r['parent']]),'; sub',zr([r for r in O if not r['parent']]))
print('with workspace key',zr([r for r in O if r['has_in'] and 'workspace' in r['ip']]),'; without',zr([r for r in O if r['has_in'] and 'workspace' not in r['ip']]))
wk=collections.defaultdict(list)
import datetime
for r in O:
    d=datetime.date.fromisoformat(r['called_at'][:10]); wk[(d-datetime.timedelta(days=d.weekday())).isoformat()].append(r)
for w in sorted(wk): print('week',w,'|',zr(wk[w]))
# hidden-clause and other notes at line starts, nonzero rows
nz=[r for r in O if not r['out']['zero']]
hid=[r for r in nz if re.search(r'(?m)^Hidden paths at the search root were not searched',r['out']['body'])]
print('nonzero rows carrying the hidden_skipped note (line-start match)',len(hid),'of',len(nz),'(%.1f%%)'%(100*len(hid)/len(nz)))
wc=[r for r in O if re.search(r'(?m)^(walk cut:)',r['out']['body'])]
print('rows whose body has a real "walk cut:" notice line',len(wc),[ (r['id'],r['latency']) for r in wc])
cap=[r for r in nz if r['out'].get('capped')]
print('capped header rows',len(cap),'; "Showing N of M" line rows',sum(1 for r in nz if re.search(r'(?m)^\s*… showing \d+ of \d+|Showing \d+ of \d+ matches',r['out']['body'])))
cb=[r for r in nz if 'byte budget' in r['out']['body']]
print('byte-budget cap rows',len(cb))
# truncation: rows where limit given and total > shown: 'showing X of Y'
sh=[r for r in nz if re.search(r'showing (\d+) of (\d+)',r['out']['body'])]
print('showing X of Y rows',len(sh))
# skipped_binary
print('binary-skipped note rows',sum(1 for r in nz if 'binary file(s) skipped' in r['out']['body']))
