#!/usr/bin/env python3
import sqlite3, statistics
db = sqlite3.connect("file:/home/marius/work/claude/codescout/.codescout/usage.db?mode=ro", uri=True)
def pct(xs, p):
    xs = sorted(xs)
    if not xs: return None
    k = (len(xs) - 1) * p / 100
    f = int(k); c = min(f + 1, len(xs) - 1)
    return xs[f] + (xs[c] - xs[f]) * (k - f)
def show(name, xs):
    print(f"{name}: n={len(xs)} p50={pct(xs,50):.0f} p90={pct(xs,90):.0f} p99={pct(xs,99):.0f} max={max(xs)}")
rows = db.execute("select attribution_outcome, attribution_ms, latency_ms from tool_calls where id<=299175 and tool_name='run_command' and attribution_ms is not null").fetchall()
for oc in ("silent", "hinted", "timed_out"):
    xs = [r[1] for r in rows if r[0] == oc]
    if xs: show(f"attribution_ms[{oc}]", xs)
allx = [r[1] for r in rows]; show("attribution_ms[all]", allx)
# share of latency
sh = [r[1] / r[2] for r in rows if r[2] and r[2] > 0]
print("share attribution_ms/latency_ms (all rows with attribution): p50=%.2f p90=%.2f" % (pct(sh, 50), pct(sh, 90)))
# 'short commands': latency - attribution < 1000ms (i.e. command itself < 1 s)
short = [r for r in rows if r[2] and r[2] - r[1] < 1000]
print("short commands (latency-attr<1000ms): n=%d" % len(short))
if short:
    show(" attr_ms", [r[1] for r in short]); show(" latency_ms", [r[2] for r in short])
    print(" share p50=%.2f p90=%.2f" % (pct([r[1]/r[2] for r in short], 50), pct([r[1]/r[2] for r in short], 90)))
# latency of all run_command rows
lat = [r[0] for r in db.execute("select latency_ms from tool_calls where id<=299175 and tool_name='run_command'")]
show("run_command latency_ms (all)", lat)
# read-declared and observed vs not
a = [r[0] for r in db.execute("select latency_ms from tool_calls where id<=299175 and tool_name='run_command' and effect_class='read' and observed_changed is not null")]
b = [r[0] for r in db.execute("select latency_ms from tool_calls where id<=299175 and tool_name='run_command' and effect_class='read' and observed_changed is null")]
b2 = [r[0] for r in db.execute("select latency_ms from tool_calls where id<=299175 and tool_name='run_command' and effect_class='read' and observed_changed is null and input_json not like '%@cmd_%' and input_json not like '%run_in_background%' and outcome='success'")]
show("latency read+observed", a); show("latency read+not observed (any)", b); show("latency read+not observed, no @cmd, success", b2)
# rows by day for time span
print(db.execute("select min(called_at), max(called_at) from tool_calls where id<=299175").fetchall())
print(db.execute("select min(called_at) from tool_calls where id<=299175 and attribution_ms is not null").fetchall())
print("observed window rows:", db.execute("select count(*) from tool_calls where id<=299175 and tool_name='run_command' and called_at >= (select min(called_at) from tool_calls where observed_changed is not null)").fetchall())
# other tools per-call counts for frequency denominators
for r in db.execute("select tool_name, count(*) from tool_calls where id<=299175 group by 1 order by 2 desc limit 25"):
    print(r)
