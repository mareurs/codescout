import json, subprocess, os, statistics as st
SP = "/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad"
R = "/home/marius/work/claude/codescout"
local = json.load(open(SP + "/bench_tok_local.json"))
full = {}
for sid, k, c in local:
    r = subprocess.run(c, shell=True, cwd=R, capture_output=True)
    full[sid + "|" + k] = (len(r.stdout), r.stdout.count(b"\n"))
d = json.load(open(SP + "/bench_out_tok.json"))
rows = []
for r in d["results"]:
    runs = [x for x in r["runs"] if not x["warm"]]
    b = int(st.median(x["bytes"] for x in runs))
    sid, k = r["label"].split("|")
    f = full.get(r["label"])
    if f is None:
        dp = SP + "/tok/" + sid + "_" + k + ".json"
        f = (os.path.getsize(dp), None) if os.path.exists(dp) else (b, None)
    buffered = ("output_id" in r["text_last"])
    rows.append((sid, k, b, round(b / 4), f[0], f[1], buffered))
print("%-4s %-11s %9s %7s %12s %8s %s" % ("srch", "variant", "resp_B", "~tok", "full_out_B", "lines", "buffered"))
for x in rows: print("%-4s %-11s %9d %7d %12s %8s %s" % x)
