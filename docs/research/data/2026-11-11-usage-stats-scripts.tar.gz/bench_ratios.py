import json, statistics as st, sys
sys.path.insert(0, "/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad")
import bench_common as b, bench_summ as bs
SP = b.SP
fl = json.load(open(SP + "/bench_flags.json"))["flags"]
print("flags >2x (scope, pid, pattern, comparison, ratio, cs_ms, other_ms):")
for f in fl:
    if f[3] == "cs-lines vs rg(run_command)":
        print("  ", f)
print("cs-files vs rg(run_command) >2x:")
for f in fl:
    if f[3] == "cs-files vs rg(run_command)":
        print("  ", f)
# load-inflation: src_a (load ~78) and src_b (87) vs src_q
def agent(p):
    return {r["label"]: r for r in bs.summ(p)}
q = agent(SP + "/timing/t_src_q.joined.json")
for tag in ("a", "b"):
    a = agent("%s/timing/t_src_%s.joined.json" % (SP, tag))
    rel = {}
    for k in ("cs-lines", "cs-files", "rg", "gg"):
        r = [a["%s|src|%s" % (p["id"], k)]["lat_med"] / q["%s|src|%s" % (p["id"], k)]["lat_med"] for p in b.PATS if "%s|src|%s" % (p["id"], k) in a and q["%s|src|%s" % (p["id"], k)]["lat_med"]]
        rel[k] = round(st.median(r), 2)
    print("src batch", tag, "(load 78/87 at start) median ratio to quiet batch, per variant:", rel)
# summary of ratios per scope
for sc in ("repo", "src", "globrs", "docs", "reg"):
    A = agent("%s/timing/t_%s_q.joined.json" % (SP, sc))
    pats = b.RPATS if sc == "reg" else b.PATS
    rcs = [A["%s|%s|cs-lines" % (p["id"], sc)]["lat_med"] / A["%s|%s|rg" % (p["id"], sc)]["lat_med"] for p in pats if not p["pcre"]]
    rcf = [A["%s|%s|cs-files" % (p["id"], sc)]["lat_med"] / A["%s|%s|rg" % (p["id"], sc)]["lat_med"] for p in pats if not p["pcre"]]
    rgg = [A["%s|%s|gg" % (p["id"], sc)]["lat_med"] / A["%s|%s|rg" % (p["id"], sc)]["lat_med"] for p in pats]
    print(sc, "median ratio cs-lines/rg(rc): %.2f  cs-files/rg(rc): %.2f  gg(rc)/rg(rc): %.2f ; cs-lines slower than rg(rc) in %d/%d patterns" % (st.median(rcs), st.median(rcf), st.median(rgg), sum(1 for r in rcs if r > 1), len(rcs)))
