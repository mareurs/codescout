import pickle, collections, json
rows=pickle.load(open('lat_rows.pkl','rb'))
def full(r):
    try: return json.loads(r['inp']) if r['inp'] and r['inp'].endswith('}') else {}
    except: return {}
sy=[r for r in rows if r['tool']=='symbols']
no=[r for r in sy if full(r).get('name') and not full(r).get('path')]
h=collections.Counter(min(r['lat']//1000,30) for r in no); print('name-only symbols lat histogram (s):',sorted(h.items()))
print('first-day/last-day',min(r['ca'] for r in no),max(r['ca'] for r in no),'sessions',len({r['sess'] for r in no}),'subagent',sum(1 for r in no if r['ag']),'scope in input',collections.Counter(full(r).get('scope') for r in no),'with workspace',sum(1 for r in no if full(r).get('workspace')))
# by week 
print('by week',collections.Counter(r['ca'][:8]+str(int(r['ca'][8:10])//8) for r in no))
print('sample inputs:',[ (r['lat'],r['inp'][:90]) for r in no[:3]])
# grep tops
g=sorted([r for r in rows if r['tool']=='grep'],key=lambda r:-r['lat'])[:8]
for r in g: print('grep',r['id'],r['ca'],r['lat'],'gap',round(r['gap']),r['sess'][:6],(r['inp'] or '')[:120])
g=[r for r in rows if r['tool']=='grep']
print('grep >=5000ms',sum(r['lat']>=5000 for r in g),' >=20000',sum(r['lat']>=20000 for r in g),'[19900,20300]',sum(19900<=r['lat']<=20300 for r in g))
# edit_file/create_file tails 
for t in ['edit_file','create_file']:
    l=sorted([r for r in rows if r['tool']==t],key=lambda r:-r['lat'])[:6]
    for r in l: print(t,r['id'],r['ca'][5:16],r['lat'],r['out'][:4],'gap',round(r['gap']),r['fam'],(r['inp'] or '')[:100].replace('\n',' '))
    l5=[r for r in rows if r['tool']==t and r['lat']>=1000]; print(t,'>=1000ms',len(l5),'>=5000',sum(r['lat']>=5000 for r in l5),'distinct sessions',len({r['sess'] for r in l5}),collections.Counter(r['ca'][:13] for r in l5).most_common(3))
# memory write latencies by write size?
mw=[r for r in rows if r['tool']=='memory' and r['action']=='write']
import statistics
print('memory write lat histogram 100ms buckets',sorted(collections.Counter(min(r['lat']//250,20) for r in mw).items()))
