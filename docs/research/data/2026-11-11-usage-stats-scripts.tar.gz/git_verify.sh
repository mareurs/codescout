#!/bin/bash
SP=/home/marius/.cache/cc-tmp/claude-1000/-home-marius-work-claude-codescout/2e6121be-ee04-4e7a-974f-3717997500f4/scratchpad
B=$SP/git_build
T=$B/target_verify
rm -rf $T
export CARGO_BUILD_JOBS=8 CARGO_TARGET_DIR=$T
echo "start $(date +%s.%N) $(uptime)" > $B/verify_g2.txt
nice -n 19 cargo build --release --offline --timings -v --manifest-path $B/g2/Cargo.toml >> $B/verify_g2.txt 2>&1
echo "end $(date +%s.%N)" >> $B/verify_g2.txt
ls $T/cargo-timings >> $B/verify_g2.txt 2>&1
echo done
