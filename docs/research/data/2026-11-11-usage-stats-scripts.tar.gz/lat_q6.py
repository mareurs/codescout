import pickle, collections, json, re, datetime as dt, sqlite3
rows=pickle.load(open('lat_rows.pkl','rb'))
def pct(v,q):
    v=sorted(v)
    if not v: return 0
    k=(len(v)-1)*q; f=int(k); c=min(f+1,len(v)-1); return v[f]+(v[c]-v[f])*(k-f)
WAIT=re.compile(r'\b(until|while|sleep)\b|pgrep -f')
BUILD=re.compile(r'\bcargo\b|nextest|rb\.sh|gate\.sh|with-slot|pytest')
for r in rows:
    r['wait']=r['tool']=='run_command' and r['cmd'] is not None and bool(WAIT.search(r['cmd']))
    T=r['tmo'] if r['tmo'] else (30 if r['has_in'] else None)
    r['to']=r['tool']=='run_command' and (bool(r['timed_out']) or (T is not None and 0<=r['lat']-T*1000<=300))
    r['exw']=not(r['wait'] or r['to'])
# Q5b composition of rc time, parent vs subagent, week
print('### run_command (ex wait/timeout) time composition: n, sum_s, share>10s rows\n| segment | n | sum_s | n>=10s | time in >=10s rows s | build/test share of n>=10s time |\n|---|---|---|---|---|---|')
def comp(label,sel):
    l=[r for r in rows if r['tool']=='run_command' and r['exw'] and sel(r)]
    big=[r for r in l if r['lat']>=10000]
    b=sum(r['lat'] for r in big if r['cmd'] and BUILD.search(r['cmd']))
    print(f"| {label} | {len(l)} | {sum(r['lat'] for r in l)/1000:.0f} | {len(big)} | {sum(r['lat'] for r in big)/1000:.0f} | {100*b/max(1,sum(r['lat'] for r in big)):.0f}% |")
comp('parent',lambda r:not r['ag']); comp('subagent',lambda r:bool(r['ag']))
for w in range(5):
    a=dt.date(2026,10,12)+dt.timedelta(days=7*w); b=a+dt.timedelta(days=7)
    comp(f'W{w+1} {a}',lambda r,a=a,b=b: str(a)<=r['ca'][:10]<str(b))
# Q6 timeout boundary
RT=[20000,30000,60000,120000,300000]
print('\n### Rows within 100 ms of a round timeout (|lat-T|<=100), per tool; time held\n')
tot=sum(r['lat'] for r in rows)
print('| T ms | tool | n | time_s | share of all-latency |\n|---|---|---|---|---|')
for T in RT:
    g=collections.defaultdict(list)
    for r in rows:
        if abs(r['lat']-T)<=100: g[r['tool']].append(r['lat'])
    for t,v in sorted(g.items(),key=lambda kv:-len(kv[1])): print(f"| {T} | {t} | {len(v)} | {sum(v)/1000:.0f} | {100*sum(v)/tot:.3f}% |")
    # density comparison: rows in the 100ms-wide neighbors
    nb=sum(1 for r in rows if 100<abs(r['lat']-T)<=300)
    print(f"| {T} | (neighbour windows 100<|d|<=300 ms, all tools) | {nb} | | |")
# run_command at 30015 etc: rows with lat in [T,T+300] where T = its own timeout_secs
print('\n### run_command rows at their OWN timeout (flag or [T,T+300ms]), by timeout_secs')
c=collections.defaultdict(list)
for r in rows:
    if r['tool']=='run_command' and r['to']:
        T=r['tmo'] if r['tmo'] else 30; c[T].append(r)
print('| timeout_secs | n | flagged timed_out | time_s | of which wait-loop |\n|---|---|---|---|---|')
for T,l in sorted(c.items(),key=lambda kv:-sum(r['lat'] for r in kv[1])):
    print(f"| {T} | {len(l)} | {sum(bool(r['timed_out']) for r in l)} | {sum(r['lat'] for r in l)/1000:.0f} | {sum(r['wait'] for r in l)} |")
tr=[r for r in rows if r['tool']=='run_command' and r['to']]
print('total at-timeout rc rows',len(tr),'time_s',round(sum(r['lat'] for r in tr)/1000),'= share of rc time',f"{100*sum(r['lat'] for r in tr)/sum(r['lat'] for r in rows if r['tool']=='run_command'):.1f}%")
print('timed_out flagged rows (output_json present):',sum(bool(r['timed_out']) for r in rows),'out of rc rows with output_json',sum(1 for r in rows if r['tool']=='run_command' and r['has_out']))
print('wait-loop share among at-timeout:',sum(r['wait'] for r in tr),'/',len(tr),' with cmd text:',sum(r['cmd'] is not None for r in tr))
# other tools: err_family
print('\n### Server/lock refusals (err_family) ')
fam=collections.defaultdict(list)
for r in rows:
    if r['fam'] in ('tool_timeout','write_lock_unavailable'): fam[(r['fam'],r['tool'])].append(r['lat'])
print('| family | tool | n | p50 | max | sum_s |\n|---|---|---|---|---|---|')
for k,v in sorted(fam.items(),key=lambda kv:-len(kv[1])): print(f"| {k[0]} | {k[1]} | {len(v)} | {pct(v,.5):.0f} | {max(v)} | {sum(v)/1000:.0f} |")
print('family totals',{f:sum(len(v) for k,v in fam.items() if k[0]==f) for f in ('tool_timeout','write_lock_unavailable')})
# per day write_lock_unavailable
print(collections.Counter(r['ca'][:10] for r in rows if r['fam']=='write_lock_unavailable'))
# LSP-request timeout error texts
con=sqlite3.connect('file:/home/marius/work/claude/codescout/.codescout/usage.db?mode=ro',uri=True)
print(con.execute("select tool_name,count(*),min(latency_ms),max(latency_ms) from tool_calls where id<=299175 and error_msg like '%LSP request timed out%' group by 1").fetchall())
print(con.execute("select tool_name,count(*) from tool_calls where id<=299175 and error_msg like 'Tool %timed out after%' group by 1").fetchall())
