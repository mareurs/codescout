import fcntl,hashlib,json,os,pathlib,shutil,subprocess
out=pathlib.Path('/home/marius/.cache/codescout-resident/codescout/disk-cleanup-followup-20261106')
record=pathlib.Path('/tmp/codescout-bg/455879-a720241d-bg_000000ed.json')
d=json.loads(record.read_text());assert d['state']=='exited' and d['exit_code']==0
save=out/'compact-gate-cache-cleanup.json';assert not save.exists()
target=pathlib.Path('/home/marius/.cache/codescout-gate/slot-0/debug');lock=target.parent.parent/'slot-0.lock'
assert target.is_dir() and not target.is_symlink() and (target/'.fingerprint').is_dir()
assert (out/'compact-gate-output.log').stat().st_size>0
with lock.open('r+') as f:
    fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);inode=os.fstat(f.fileno()).st_ino
    users=[]
    for p in pathlib.Path('/proc').iterdir():
        if not p.name.isdigit() or int(p.name)==os.getpid():continue
        try:
            if str(target).encode() in (p/'cmdline').read_bytes() or str(target) in (p/'maps').read_text(errors='replace'):users.append(int(p.name))
        except OSError:pass
    assert not users,users
    du=subprocess.run(['du','-s','-B1',str(target)],capture_output=True,text=True,check=True)
    s=os.statvfs('/');before=s.f_bavail*s.f_frsize
    shutil.rmtree(target)
    assert not target.exists() and lock.stat().st_ino==inode
    s=os.statvfs('/');result={'gate_record':str(record),'gate_exit_code':0,'target':str(target),'du_allocated_bytes':int(du.stdout.split()[0]),'lease_inode':inode,'referencing_processes':users,'root_available_before':before,'root_available_after':s.f_bavail*s.f_frsize,'exclusive_physical_reclaimed_bytes':None,'gate_output_sha256':hashlib.sha256((out/'compact-gate-output.log').read_bytes()).hexdigest(),'target_absent':True}
    save.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
