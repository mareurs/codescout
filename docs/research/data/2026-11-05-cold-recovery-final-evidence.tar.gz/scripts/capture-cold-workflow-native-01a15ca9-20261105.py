"""Independent read-only Docker resource sample; no model or verifier commands."""
import json,pathlib,subprocess,time
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/complete-workflow-cold-recovery-20261105")
IMAGE="sha256:9acb0723bebf03a036640c747c3a3f1d33afcdffe9be00587fcb0041079cce2b"
rows=[]
for out in sorted(ROOT.glob("workflow-[01]-*")):
    if not out.is_dir() or out.name.endswith("-grader"):continue
    for path in sorted(out.glob("mcp-launch-*.json")):
        try:launch=json.loads(path.read_text())
        except ValueError:continue
        name=launch["name"]
        probe=subprocess.run(["docker","inspect",name],capture_output=True,text=True,timeout=5)
        if probe.returncode:
            assert "no such" in probe.stderr.lower()
            continue
        c=json.loads(probe.stdout)[0]
        assert c["Image"]==IMAGE and c["Config"]["Labels"].get("codescout.hfa")==name
        host=c["HostConfig"];mount=next(m for m in c["Mounts"] if m["Destination"]=="/testbed")
        env=dict(p.split("=",1) for p in c["Config"]["Env"] if "=" in p)
        row=dict(observed_unix_s=time.time(),attempt=out.name,name=name,container_id=c["Id"],image=c["Image"],
            init=host["Init"],nano_cpus=host["NanoCpus"],pids_limit=host["PidsLimit"],memory_bytes=host["Memory"],
            actor=mount["Source"],actor_writable=mount["RW"],cargo_target_dir=env["CARGO_TARGET_DIR"])
        assert row["init"] and row["nano_cpus"]==4000000000 and row["pids_limit"]==512 and row["memory_bytes"]==12*1024**3
        assert pathlib.Path(row["actor"])==(out/"project").resolve() and row["actor_writable"] and row["cargo_target_dir"]=="/testbed/target"
        rows.append(row)
with (ROOT/"runtime-live-observations.jsonl").open("a") as output:
    for row in rows:output.write(json.dumps(row)+"\n")
print(json.dumps(dict(observed_active_containers=len(rows),attempts=sorted({r["attempt"] for r in rows}))))
