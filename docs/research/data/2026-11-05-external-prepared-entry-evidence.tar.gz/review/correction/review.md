# Bounded correction verification

Accepted for this six-path source review. The native option conflict finding recorded as MAIN bug d06194e58297a768 is corrected in the reviewed bytes. This acceptance does not constitute native qualification, full-gate success, or paid-run admission.

The original report and all original mutation evidence remain unchanged in the parent directory. This correction directory is a separate final snapshot and execution record. Base commit: 9751891074a2bc9ce6da17b9f88e685af5d058d8.

## Correction inspected

Only external.py and test_external_entry.py changed relative to the first reviewed six-file snapshot. validate_prepared now parses split and equals-form options, rejects unsupported tokens and duplicate singleton options, and checks the normalized required values. It also checks optional swap and pull constraints. The new regression test updates the native-file digest before submitting conflicting options and asserts rejection before the fake credential boundary or start marker.

The new test passed for its eight explicit subcases, including the four originally demonstrated equal-form conflicts. Removing the new duplicate-singleton guard produced a deliberate credential-access assertion for --name=other, demonstrating that the test observes this guard independently of the required-value checks. No real credential was accessed.

## Observed verification

Initial corrected baseline: 71 unittest methods passed in 10.764 s.
Final restored baseline: 71 unittest methods passed in 9.583 s.
Command: python3 -B -m unittest discover -s correction/work/tools/agent_lifecycle -p 'test_*.py' -v (the actual commands used absolute suite paths).

Exactly eleven distinct mutation executions were applied independently: the same ten requested original mutations plus removal of the new duplicate-singleton guard. Every execution ran the full 71-method lifecycle suite. Ten assertion-killed; one production-error rejection; zero survivors; zero harness errors; zero invalid instruments; zero timeouts. Each source file was restored after its execution.

| ID | Mutation | Observed result | Assertion failure / error events |
| --- | --- | --- | --- |
| c01 | frozen baseline to HEAD | assertion killed | 1 / 0 |
| c02 | omit git add | assertion killed | 1 / 0 |
| c03 | drop pathspec exclusions | production error rejection | 0 / 1 |
| c04 | omit worker-ID guard | assertion killed | 1 / 0 |
| c05 | skip capture invocation | assertion killed | 5 / 0 |
| c06 | omit capture success conjunction | assertion killed | 4 / 0 |
| c07 | weaken literal True completion | assertion killed | 1 / 0 |
| c08 | bypass prepared digest | assertion killed | 1 / 0 |
| c09 | wire allowance as CLI cap | assertion killed | 1 / 0 |
| c10 | omit user/project setting sources | assertion killed | 1 / 0 |
| c11 | omit duplicate-singleton guard | assertion killed | 1 / 0 |

Events include unittest subtest failures, not distinct method counts. c03 reaches the independent production edited-path guard and raises ValueError: tool state entered the candidate path set; this is not counted as an assertion kill. c08 and c11 fail deliberate fake credential-access assertions, not accidental harness errors. Exact patches, complete logs and classified JSON results are retained beside this report.

All six final work/pristine/V source hashes matched source-hashes.json during final restoration verification; final-source-hashes.json records the comparisons. No V or MAIN source was changed by this reviewer. No Docker, provider, real credentials, extra agents, native qualifier or project-wide gate was invoked. No further mutation round was performed.

This scoped acceptance addresses the observed conflict defect and the requested mutation candidates. It does not claim exhaustive parser or adapter correctness. Controller-owned preparation, qualification and admission remain outside this review.
