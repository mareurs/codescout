# Generic capture / prepared entry review

Verdict: changes required. One Important preflight defect remains. This is a finite source review, not paid-run admission or native qualification.

Scope: six paths in source-hashes.json, based on commit 9751891074a2bc9ce6da17b9f88e685af5d058d8. Source and MAIN were read-only; all mutations were applied independently to work/ and restored from pristine/. No Docker, provider calls, or real credential reads were performed.

## Important finding: conflicting native option spellings pass preflight

Location: tools/agent_lifecycle/external.py, validate_prepared, lines 46–50.

The validator checks the occurrence and value of split option tokens only. Starting from ExternalEntryTests' valid prepared fixture, insert one of `--memory=1g`, `--cpus=99`, `--network=host`, or `--user=0:0` immediately before the image token; update the native argv file digest in prepared.json; call validate_prepared with otherwise valid effort/allowance/cap. All four calls returned successfully. The required split-form values remain in the same argv.

Observed evidence: native-conflict-probe.json records admitted=true for each independent case. This demonstrates that the claimed fixed native configuration is not enforced by preflight. Docker's eventual interpretation was not executed or measured. Reject duplicate/conflicting spellings by normalizing option tokens before checking the full boundary; add tests that rebind the file hash so they reach semantic validation. The active MAIN issue catalog was checked before reporting; no matching generic-entry option-conflict issue was found. No new issue was filed by this reviewer.

## Measured verification

Initial baseline: 70 unittest methods, OK, 9.494 s (baseline.log).
After all restorations: 70 unittest methods, OK, 9.748 s (baseline-final.log).
Each mutation ran the same complete agent_lifecycle unittest discovery suite. Exactly ten distinct source mutations were actually applied. Nine produced assertion failures; one produced an uncaught production ValueError. Zero survivors, zero harness errors, zero timeouts. The production error is reported separately and is not counted as an assertion kill.

| Mutation | Observed result | Failure/error events |
| --- | --- | --- |
| c01 baseline replaced with HEAD | assertion killed | 1 failure: moved-head old.rs missing |
| c02 omit git add | assertion killed | 1 failure: new/deleted candidate paths missing |
| c03 drop pathspec exclusions | production error rejection | 1 error: independent edited-path guard raises ValueError |
| c04 drop worker ID comparison | assertion killed | 1 failure: replacement worker not rejected |
| c05 skip capture callback invocation | assertion killed | 5 failures: capture absent from lifecycle ordering |
| c06 drop capture success conjunction | assertion killed | 4 failures: failed capture accepted |
| c07 weaken literal True to truthiness | assertion killed | 1 failure: complete=1 accepted |
| c08 bypass prepared file digest comparison | assertion killed | 1 deliberate forbidden-credential assertion |
| c09 wire allowance instead of CLI cap | assertion killed | 1 failure: 8 instead of 7 |
| c10 omit user/project setting sources | assertion killed | 1 failure: local instead of user,project,local |

Failure event counts include unittest subtest failures; they are not distinct method counts. Every candidate has its exact .patch, full .log and classified .json. The c08 credential-access assertion is an intentional test boundary witness, with a fake object and no real token read. c03's ValueError originates in the production edited-path exclusion check, not a mock/type mismatch; it shows fail-closed rejection of the mutated pathspec but is not an assertion kill.

## Strengths and boundaries

The observed tests exercise real local Git handling of moved HEAD, new/deleted/binary files and excluded state, and lifecycle ordering/cost retention when capture fails. The launch fixture distinguishes proxy allowance from the smaller CLI cap and checks full setting sources. These statements are limited to the tested fixtures. Native Docker behavior, provider execution, prepared cohort registration, knowledge assembly, qualification, the full project gate and admission were deliberately outside this review.

All six private source files were restored byte-for-byte; pristine, work and V hashes matched the reviewed manifest at final verification. See final-source-hashes.json. No follow-up mutation round or production fix was performed.
