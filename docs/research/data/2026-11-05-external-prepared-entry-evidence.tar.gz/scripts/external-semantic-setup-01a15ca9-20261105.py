import hashlib,json,pathlib,shutil,subprocess,time
BASE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
PRE=BASE/"external-transfer-admission-20261105"
ROOT=BASE/"external-workflow-setup-20261105"
TASKS=("nushell__nushell-18863","rust-lang__rust-analyzer-22992")
def save(p,x):p.write_text(json.dumps(x,indent=2)+"\n")
def inspect(name):
 p=subprocess.run(["docker","inspect",name],capture_output=True,text=True,timeout=10)
 if p.returncode:
  if "no such" not in p.stderr.lower():raise RuntimeError(p.stderr)
  return None
 return json.loads(p.stdout)[0]
def prepare(ident,index):
 out=ROOT/ident;out.mkdir()
 kb=out/"knowledge";kb.mkdir()
 scaffold=PRE/"native-probes"/ident/"generated-codescout"
 for p in scaffold.rglob("*"):
  rel=p.relative_to(scaffold)
  if p.is_file() and not p.is_symlink() and p.suffix in (".md",".toml") and ".history" not in rel.parts:
   dst=kb/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
 config=kb/"project.toml";text=config.read_text()
 old='model = "local:AllMiniLML6V2Q"'
 if text.count(old)!=1:raise RuntimeError("unexpected embedding config")
 config.write_text(text.replace(old,'model = "local:JinaEmbeddingsV2BaseCode"'))
 home=out/"native-home";(home/".claude").mkdir(parents=True)
 shutil.copyfile("/home/marius/.claude/CLAUDE.md",home/".claude/CLAUDE.md")
 template=json.loads((PRE/"native-probes"/ident/"launch.json").read_text())["argv"]
 argv=[];i=0
 while i<len(template):
  token=template[i]
  if token in ("-i","--init","--cpus","--memory-swap","--memory"):
   i+=1 if token in ("-i","--init") else 2;continue
  if token.startswith("type=bind,") and ",dst=/bench-home" in token and ",dst=/bench-home/" not in token:
   token="type=bind,src="+str(home)+",dst=/bench-home"
  argv.append(token);i+=1
 argv[2:2]=["--init","--cpus","4","--memory","24g","--memory-swap","24g"]
 argv[argv.index("--pids-limit")+1]="4096"
 name="cs-transfer-index-01a15ca9-20261105-"+str(index)
 argv[argv.index("--name")+1]=name
 argv[argv.index("--label")+1]="codescout.semantic-setup="+name
 argv[-4:-4]=["--mount","type=bind,src="+str(kb)+",dst=/testbed/.codescout"]
 argv[-3]="index"
 save(out/"index-launch.json",{"argv":argv,"image":argv[-4],"source_only":True,
  "provider_calls":0,"onboarding_author_calls":0,"timeout_s":1800})
 return out,argv,name
def main():
 ROOT.mkdir()
 save(ROOT/"registration.json",{"scope":"One deterministic source-only index setup per selected project, no LLM calls",
  "private_task_inputs_mounted":False,"source_only_author_not_started":True,"timeout_s":1800,"cpus":4,"memory_gib":24})
 rows=[]
 for index,ident in enumerate(TASKS):
  out,argv,name=prepare(ident,index)
  if inspect(name) is not None:raise RuntimeError("owned container already exists")
  started=time.monotonic();row={"id":ident,"provider_calls":0,"onboarding_author_calls":0}
  try:
   with (out/"index.stdout").open("xb") as stdout,(out/"index.stderr").open("xb") as stderr:
    p=subprocess.run(argv,stdout=stdout,stderr=stderr,timeout=1800)
   row["exit_code"]=p.returncode
  except subprocess.TimeoutExpired:row["exit_code"]=None;row["timeout"]=True
  finally:
   live=inspect(name)
   if live:
    expected=json.loads((out/"index-launch.json").read_text())["image"]
    assert live["Image"]==expected and live["Config"]["Labels"].get("codescout.semantic-setup")==name
    row["container_id"]=live["Id"];row["oom_killed"]=live["State"]["OOMKilled"]
    subprocess.run(["docker","rm","-f","-v",live["Id"]],capture_output=True,check=True,timeout=60)
   row["container_absent"]=inspect(name) is None
  row["wall_s"]=time.monotonic()-started
  row["stdout_sha256"]=hashlib.sha256((out/"index.stdout").read_bytes()).hexdigest()
  row["stderr_sha256"]=hashlib.sha256((out/"index.stderr").read_bytes()).hexdigest()
  save(out/"index-result.json",row);rows.append(row);print(json.dumps(row),flush=True)
  if row.get("exit_code")!=0 or not row["container_absent"]:break
 save(ROOT/"index-results.json",rows)
if __name__=="__main__":main()
