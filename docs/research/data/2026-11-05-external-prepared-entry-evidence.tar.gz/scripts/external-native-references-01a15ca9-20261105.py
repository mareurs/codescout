import importlib.util
_spec=importlib.util.spec_from_file_location("native_original","/tmp/external-native-ready-01a15ca9-20261105.py")
_module=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(_module)
globals().update({k:v for k,v in vars(_module).items() if not k.startswith("__") and k not in ("probe","main")})
ROOT=BASE/"external-native-references-20261105"

async def probe(index,ident):
 out=ROOT/ident;out.mkdir()
 source=BASE/"external-entry-qualification-20261105"/ident
 argv=json.loads((source/"mcp-native-argv.json").read_text())
 for j,item in enumerate(argv):
  if item.startswith("type=bind,") and ",dst=/testbed/.codescout" in item:
   kb=out/"knowledge";shutil.copytree(source/"knowledge",kb,ignore=shutil.ignore_patterns("embeddings","*.db","*.db-*",".history"))
   argv[j]="type=bind,src="+str(kb)+",dst=/testbed/.codescout"
 name="cs-native-references-01a15ca9-20261105-"+str(index)
 argv[argv.index("--name")+1]=name;argv[argv.index("--label")+1]="codescout.capabilities="+name
 image=argv[-4];save(out/"launch.json",{"argv":argv,"provider_calls":0})
 err=(out/"stderr.log").open("wb")
 proc=await asyncio.create_subprocess_exec(*argv,stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=err,limit=8*1024*1024)
 seq=0
 async def rpc(method,params):
  nonlocal seq
  seq+=1;req={"jsonrpc":"2.0","id":seq,"method":method,"params":params}
  proc.stdin.write((json.dumps(req)+"\n").encode());await proc.stdin.drain()
  while True:
   line=await asyncio.wait_for(proc.stdout.readline(),120)
   if not line:raise RuntimeError("MCP ended")
   res=json.loads(line)
   with (out/"wire.jsonl").open("a") as f:f.write(json.dumps({"request":req,"response":res})+"\n")
   if res.get("id")==seq:
    save(out/(str(seq)+"-response.json"),res);return res
 try:
  await rpc("initialize",{"protocolVersion":"2025-06-18","capabilities":{},"clientInfo":{"name":"external-capability-check","version":"1"}})
  proc.stdin.write(b'{"jsonrpc":"2.0","method":"notifications/initialized"}\n');await proc.stdin.drain()
  result=await rpc("tools/list",{})
  save(out/"tool-names.json",[t["name"] for t in result["result"]["tools"]])
  await rpc("tools/call",{"name":"workspace","arguments":{"action":"status"}})
  await rpc("tools/call",{"name":"symbols","arguments":{"path":"crates/nu-protocol/src/value/mod.rs" if index==0 else "crates/paths/src/lib.rs","depth":2}})
  ref=await rpc("tools/call",{"name":"references","arguments":{"symbol":"Value" if index==0 else "AbsPathBuf","path":"crates/nu-protocol/src/value/mod.rs" if index==0 else "crates/paths/src/lib.rs","limit":5}})
  save(out/"named-reference-result.json",ref)
  second=await rpc("tools/list",{})
  save(out/"tool-names-after.json",[t["name"] for t in second["result"]["tools"]])
  print(json.dumps({"id":ident,"tool_names":[t["name"] for t in second["result"]["tools"]]}),flush=True)
 finally:
  proc.stdin.close()
  try:await asyncio.wait_for(proc.wait(),8)
  except asyncio.TimeoutError:
   proc.terminate()
   try:await asyncio.wait_for(proc.wait(),5)
   except asyncio.TimeoutError:proc.kill();await proc.wait()
  err.close()
  p=subprocess.run(["docker","inspect",name],capture_output=True,text=True,timeout=10)
  if p.returncode==0:
   row=json.loads(p.stdout)[0]
   assert row["Image"]==image and row["Config"]["Labels"].get("codescout.capabilities")==name
   subprocess.run(["docker","rm","-f","-v",row["Id"]],capture_output=True,check=True,timeout=60)
  gone=subprocess.run(["docker","inspect",name],capture_output=True,text=True,timeout=10)
  save(out/"cleanup.json",{"absent":gone.returncode!=0 and "no such" in gone.stderr.lower()})

async def main():
 ROOT.mkdir()
 for i,ident in enumerate(("nushell__nushell-18863","rust-lang__rust-analyzer-22992")):await probe(i,ident)
if __name__=="__main__":asyncio.run(main())
