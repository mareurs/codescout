import hashlib,json,pathlib,shutil,subprocess,time
BASE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
PRE=BASE/"external-transfer-admission-20261105"
ROOT=BASE/"external-default-index-20261105"
CACHE=pathlib.Path("/home/marius/.cache/codescout/fastembed")
def save(p,x):p.write_text(json.dumps(x,indent=2)+"\n")
def inspect(name):
 p=subprocess.run(["docker","inspect",name],capture_output=True,text=True,timeout=10)
 if p.returncode:
  if "no such" not in p.stderr.lower():raise RuntimeError(p.stderr)
  return None
 return json.loads(p.stdout)[0]
def main():
 ROOT.mkdir()
 save(ROOT/"registration.json",{"provider_calls":0,"onboarding_author_calls":0,
  "decision_basis":"Generated onboarding default AllMiniLML6V2Q already cached; test the default in a separate store before any model repair/author outcome. Jina setup evidence retained separately.",
  "cache_model":str(CACHE/"models--Xenova--all-MiniLM-L6-v2/snapshots/751bff37182d3f1213fa05d7196b954e230abad9/onnx/model_quantized.onnx"),
  "cpus":4,"memory_gib":24,"timeout_s":3600})
 rows=[]
 for index,ident in enumerate(("nushell__nushell-18863","rust-lang__rust-analyzer-22992")):
  out=ROOT/ident;out.mkdir();kb=out/"knowledge";kb.mkdir()
  scaffold=PRE/"native-probes"/ident/"generated-codescout"
  for p in scaffold.rglob("*"):
   rel=p.relative_to(scaffold)
   if p.is_file() and not p.is_symlink() and p.suffix in (".md",".toml") and ".history" not in rel.parts:
    dst=kb/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
  assert 'model = "local:AllMiniLML6V2Q"' in (kb/"project.toml").read_text()
  home=out/"native-home";(home/".claude").mkdir(parents=True)
  shutil.copyfile("/home/marius/.claude/CLAUDE.md",home/".claude/CLAUDE.md")
  template=json.loads((PRE/"native-probes"/ident/"launch.json").read_text())["argv"]
  argv=[];i=0
  while i<len(template):
   x=template[i]
   if x in ("-i","--init","--cpus","--memory","--memory-swap"):
    i+=1 if x in ("-i","--init") else 2;continue
   if x.startswith("type=bind,") and ",dst=/bench-home" in x:
    x=("type=bind,src="+str(CACHE)+",dst=/bench-home/.cache/codescout/fastembed,readonly"
       if ",dst=/bench-home/" in x else "type=bind,src="+str(home)+",dst=/bench-home")
   argv.append(x);i+=1
  argv[2:2]=["--init","--cpus","4","--memory","24g","--memory-swap","24g"]
  argv[argv.index("--pids-limit")+1]="4096"
  name="cs-default-index-01a15ca9-20261105-"+str(index)
  argv[argv.index("--name")+1]=name;argv[argv.index("--label")+1]="codescout.default-index="+name
  image=argv[-4]
  argv[-4:-4]=["--mount","type=bind,src="+str(kb)+",dst=/testbed/.codescout"]
  argv[-3]="index"
  save(out/"index-launch.json",{"argv":argv,"image":image})
  if inspect(name) is not None:raise RuntimeError("owned name exists")
  started=time.monotonic();row={"id":ident,"provider_calls":0,"onboarding_author_calls":0}
  try:
   with (out/"index.stdout").open("xb") as stdout,(out/"index.stderr").open("xb") as stderr:
    p=subprocess.run(argv,stdout=stdout,stderr=stderr,timeout=3600)
   row["exit_code"]=p.returncode
  except subprocess.TimeoutExpired:row["exit_code"]=None;row["timeout"]=True
  finally:
   live=inspect(name)
   if live:
    assert live["Image"]==image and live["Config"]["Labels"].get("codescout.default-index")==name
    row["container_id"]=live["Id"];row["oom_killed"]=live["State"]["OOMKilled"]
    subprocess.run(["docker","rm","-f","-v",live["Id"]],capture_output=True,check=True,timeout=60)
   row["container_absent"]=inspect(name) is None
  row["wall_s"]=time.monotonic()-started
  row["stdout_sha256"]=hashlib.sha256((out/"index.stdout").read_bytes()).hexdigest()
  row["stderr_sha256"]=hashlib.sha256((out/"index.stderr").read_bytes()).hexdigest()
  save(out/"index-result.json",row);rows.append(row);print(json.dumps(row),flush=True)
  if row.get("exit_code")!=0:break
 save(ROOT/"index-results.json",rows)
if __name__=="__main__":main()
