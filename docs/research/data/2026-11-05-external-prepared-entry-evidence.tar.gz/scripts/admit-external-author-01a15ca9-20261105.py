import hashlib,json,pathlib,shutil
BASE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
ROOT=BASE/"external-onboarding-once-20261105"
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
 with p.open("x") as f:json.dump(v,f,indent=2);f.write("\n")
def main():
 gatepath=pathlib.Path("/tmp/codescout-bg/455879-a720241d-bg_000000a0.json")
 gate=json.loads(gatepath.read_text())
 assert gate["state"]=="exited" and gate["exit_code"]==0 and gate["command"]=="./scripts/gate.sh --check"
 log=pathlib.Path(gate["log_path"]).read_text()
 assert "GATE EXITS -> FMT=0 CLIPPY=0 LEAN=0 DEFAULT=0 FMT_STATE=passed" in log
 proofdir=ROOT/"admission";proofdir.mkdir()
 shutil.copyfile(gatepath,proofdir/"gate-record.json")
 shutil.copyfile(gate["log_path"],proofdir/"gate.log")
 reviewpath=pathlib.Path("/tmp/external-capture-review-01a15ca9-20261105/correction/review-binding.json")
 review=json.loads(reviewpath.read_text());assert review["accepted"] is True
 for name,digest in review["source_hashes"].items():assert sha(V/name)==digest
 reg=json.loads((ROOT/"registration.json").read_text())
 assert reg["finite_known_series_ceiling_usd"]=="150"
 proofs=[proofdir/"gate-record.json",proofdir/"gate.log",reviewpath,
  pathlib.Path("/tmp/external-author-once-01a15ca9-20261105.py"),
  BASE/"external-entry-qualification-20261105/results.json"]
 mounts={}
 for ident in reg["cases"]:
  out=ROOT/ident
  cfg=json.loads((out/"prepared.json").read_text())
  native=json.loads((out/"mcp-native-argv.json").read_text())
  paths={part.split("=",1)[0]:part.split("=",1)[1] for part in []}
  expected={"/bench/bin":BASE/"native-build-provenance-20261104/bin",
   "/bench/runtime":BASE/"native-env-admission-20261104/qualification-20261104/runtime-v2",
   "/bench/lsp":BASE/"native-env-admission-20261104/qualification-20261104/patched-lsp",
   "/bench-home/.cache/codescout/fastembed":BASE/"native-env-admission-20261104/qualification-20261104/jina-cache",
   "/bench-home":out/"native-home","/testbed/.codescout":out/"knowledge"}
  found={}
  for i,x in enumerate(native):
   if x=="--mount":
    parts=native[i+1].split(",");d=dict(p.split("=",1) for p in parts if "=" in p)
    assert d["type"]=="bind" and d["dst"] not in found
    assert pathlib.Path(d["src"]).resolve()==expected[d["dst"]].resolve()
    assert ("readonly" in parts)==(d["dst"] not in ("/bench-home","/testbed/.codescout"))
    found[d["dst"]]=d["src"]
  assert set(found)==set(expected)
  mounts[ident]=found
  warm=BASE/"external-native-warm-references-20261105"/ident/"warm-reference-2.json"
  assert json.loads(warm.read_text())["result"].get("isError") is not True
  proofs += [out/"preflight.json",out/"prepared.json",out/"mcp-native-argv.json",warm,
   BASE/"external-native-warm-references-20261105"/ident/"cleanup.json",
   BASE/"external-entry-qualification-20261105"/ident/"result.json"]
 # Bind all bytes of the read-only native runtime mounts, preserving link targets as well.
 immutable={}
 for mount in ("/bench/bin","/bench/runtime","/bench/lsp","/bench-home/.cache/codescout/fastembed"):
  root=pathlib.Path(next(iter(mounts.values()))[mount])
  immutable[mount]={}
  for p in sorted(root.rglob("*")):
   if p.is_symlink():immutable[mount][str(p.relative_to(root))]={"link":str(p.readlink()),"resolved_sha256":sha(p) if p.is_file() else None}
   elif p.is_file():immutable[mount][str(p.relative_to(root))]={"sha256":sha(p)}
 save(proofdir/"native-readonly-inputs.json",immutable)
 proofs.append(proofdir/"native-readonly-inputs.json")
 save(ROOT/"author-admission.json",{"source_only_authors_admitted":True,"repair_admitted":False,
  "registration_sha256":sha(ROOT/"registration.json"),"proof_sha256":{str(p):sha(p) for p in proofs},
  "mounts":mounts,"source_review":review["scope"],"gate_exits":{"python":0,"fmt":0,"clippy":0,"lean":0,"default":0},
  "known_limitations":"Only source-only author setup is admitted. Semantic data, complete substantive authored KB and fresh private grader controls remain prerequisites for repairs. No efficacy conclusion."})
 print("source-only author admission frozen; repairs remain unadmitted")
if __name__=="__main__":main()
