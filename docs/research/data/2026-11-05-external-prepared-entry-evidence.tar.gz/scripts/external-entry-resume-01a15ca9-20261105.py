import importlib.util
_spec=importlib.util.spec_from_file_location("qualified_original","/tmp/external-entry-qualify-01a15ca9-20261105.py")
_module=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(_module)
globals().update({k:v for k,v in vars(_module).items() if not k.startswith("__") and k!="main"})

def main():
 ROOT.mkdir(exist_ok=True)
 transport.Proxy.upstream=no_provider
 save(ROOT/"registration.json",{"provider_calls":0,"credential_reads":0,"onboarding_author_calls":0,
  "purpose":"Real pinned CLI through generic prepared entry, native image source and final patch preservation; synthetic responses only.",
  "source_sha256":{str(p.relative_to(V)):hashlib.sha256(p.read_bytes()).hexdigest()
    for p in [V/"tools/agent_lifecycle"/name for name in ("external.py","artifacts.py","workflow.py","qualify.py")]}})
 rows=[]
 for index,ident in enumerate(("nushell__nushell-18863","rust-lang__rust-analyzer-22992")):
  out=ROOT/ident
  if (out/"receipt.json").exists():
   cfg=json.loads((out/"prepared.json").read_text())
   receipt=json.loads((out/"receipt.json").read_text())
   image=cfg["image"];baseline=cfg["baseline_commit"];actor=pathlib.Path(cfg["actor"])
   canary=(actor/"host-canary.txt").read_text()
  else:
   out.mkdir()
   actor=pathlib.Path("/tmp")/("cs-external-entry-01a15ca9-20261105-"+str(index));actor.mkdir()
   context=json.loads((PRE/ident/"actual-context.json").read_text())
   (actor/"CLAUDE.md").write_text(context["claude"]);(actor/"AGENTS.md").write_text(context["agents"])
   canary="HOST_ONLY_"+uuid.uuid4().hex;(actor/"host-canary.txt").write_text(canary)
   glob=pathlib.Path("/home/marius/.claude/CLAUDE.md")
   nativehome=out/"native-home";(nativehome/".claude").mkdir(parents=True)
   shutil.copyfile(glob,nativehome/".claude/CLAUDE.md")
   kb=out/"knowledge";shutil.copytree(PRE/"native-probes"/ident/"generated-codescout",kb,
     ignore=shutil.ignore_patterns(".history","embeddings","*.db","*.db-*","*.lock"))
   original=json.loads((PRE/"native-probes"/ident/"launch.json").read_text())["argv"]
   image=original[-4]
   baseline=command(["docker","run","--rm","--pull=never","--network","none","--user","1000:1000",
    "--workdir","/testbed","--entrypoint","git",image,"rev-parse","HEAD"],text=True).stdout.strip()
   if len(baseline)!=40:raise RuntimeError("unexpected native baseline")
   native=[];i=0
   while i<len(original):
    x=original[i]
    if x in ("--init","--cpus","--memory-swap"):
     i+=1 if x=="--init" else 2;continue
    if x.startswith("type=bind,") and ",dst=/bench-home" in x and ",dst=/bench-home/" not in x:
     x="type=bind,src="+str(nativehome)+",dst=/bench-home"
    native.append(x);i+=1
   native[native.index("--pids-limit")+1]="4096"
   native=workflow.verified_native_argv(native,memory_gib=24)
   native[-4:-4]=["--mount","type=bind,src="+str(kb)+",dst=/testbed/.codescout"]
   save(out/"mcp-native-argv.json",native)
   source="src/main.rs" if index==0 else "crates/rust-analyzer/src/bin/main.rs"
   marker="PREPARED_NATIVE_JOB_"+uuid.uuid4().hex
   plan=[("Skill",{"skill":"codescout-companion:reconnaissance"}),
    ("mcp__codescout__workspace",{"action":"status"}),
    ("mcp__codescout__symbols",{"path":source,"name":"main","include_body":True}),
    ("mcp__codescout__read_file",{"path":str(actor/"host-canary.txt"),"force":True}),
    ("mcp__codescout__run_command",{"command":"printf '"+marker+"\\n'; cargo --version","run_in_background":True}),
    ("mcp__codescout__create_file",{"path":"cs-prepared-entry-probe.txt","content":"generic final patch preservation\n"})]
   cfg={"image":image,"baseline_commit":baseline,"actor":str(actor),"cli":str(worker.CLI),
    "plugin":str(FROZEN/"skill-only-plugin"),"global_rules":str(glob),
    "prompt":"Provider-disabled generic entry qualification. Follow scripted tools. No repair task, hidden tests or paid onboarding.",
    "checks":[{"id":"captured_probe","command":"test -f cs-prepared-entry-probe.txt"}],
    "timeout_s":300,"check_timeout_s":30,"max_continuations":4,
    "files":{str(p):hashlib.sha256(p.read_bytes()).hexdigest()
     for p in (out/"mcp-native-argv.json",glob,worker.CLI,actor/"CLAUDE.md",actor/"AGENTS.md")}}
   save(out/"prepared.json",cfg)
   receipt=external.launch(out,effort="low",allowance="1",scripted_plan=plan)
 
  capture=json.loads((out/"candidate-capture.json").read_text())
  assert set(capture["edited"]) <= {".gitignore","cs-prepared-entry-probe.txt"} and "cs-prepared-entry-probe.txt" in capture["edited"],capture
  patch=(out/"candidate.patch").read_bytes()
  applied=command(["docker","run","--rm","--pull=never","--network","none","--user","1000:1000",
   "-i","--workdir","/testbed","--entrypoint","/bin/bash",image,"-lc",
   "git apply - && test \"$(cat cs-prepared-entry-probe.txt)\" = 'generic final patch preservation' && git diff -- .gitignore"],input=patch)
  requests=[json.loads(p.read_text()) for p in out.glob("request-*.json")]
  uses={};results={}
  for req in requests:
   for msg in req.get("messages",[]):
    content=msg.get("content",[])
    if not isinstance(content,list):continue
    for block in content:
     if not isinstance(block,dict):continue
     if block.get("type")=="tool_use":uses[block["id"]]=block["name"]
     if block.get("type")=="tool_result":results[block["tool_use_id"]]=block
  assert set(uses)<=set(results)
  assert not any(b.get("is_error",False) for b in results.values())
  assert any("A **seam** is a place" in json.dumps(r) for r in requests)
  assert not any(canary in json.dumps(r) for r in requests)
  for item in json.loads((out/"cleanup.json").read_text()):
   p=subprocess.run(["docker","inspect",item["name"]],capture_output=True,text=True,timeout=10)
   assert p.returncode and "no such" in p.stderr.lower()
  assert receipt["workflow_completed"] and receipt["context_valid"],receipt
  assert receipt["cost_usd"]=="0" or float(receipt["cost_usd"])==0
  row={"id":ident,"image":image,"actor_baseline":baseline,"receipt":receipt,
   "provider_calls":0,"credential_reads":0,"actual_cli_requests":len(requests),
   "tool_use_ids_with_results":len(uses),"new_entry_wildcard_permissions_worked":True,
   "patch_applied_to_fresh_exact_image":True,"host_canary_not_leaked":True,
   "all_recorded_native_containers_independently_absent":True,
   "limits":"Scaffold knowledge only; semantic/references and genuine authored KB not qualified; no repair efficacy."}
  save(out/"result.json",row);rows.append(row);print(json.dumps(row),flush=True)
 save(ROOT/"results.json",rows)

if __name__=="__main__":main()
