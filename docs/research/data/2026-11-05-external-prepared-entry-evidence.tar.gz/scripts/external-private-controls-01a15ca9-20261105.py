import hashlib,json,pathlib,subprocess,sys,time
HOME=pathlib.Path("/home/marius/work/claude/codescout")
TOOLS=HOME/"tools/setup-ab-eval"
sys.path.insert(0,str(TOOLS))
import arms,multilang_tasks as tasks
DATA=pathlib.Path("/home/marius/work/claude/setup-ab-data")
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/external-private-controls-20261105")
CASES=(("nushell__nushell-18863","sha256:e317a8e791bfa1f546ab9b58af244ba0844311fef0019306042522d5f68d81b2"),
 ("rust-lang__rust-analyzer-22992","sha256:b3df4c943af162ec27e038ed6b80557ae8764e869e43402ea96c477d876066c9"))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+"\n")
def main():
 ROOT.mkdir()
 assert arms.RESOURCES==("--cpus","4","--memory","8g")
 sources={str(p):sha(p) for p in TOOLS.glob("*.py")}
 save(ROOT/"registration.json",{"provider_calls":0,"credential_reads":0,"model_runs":0,
  "purpose":"Fresh baseline-negative, gold-positive, gold-repeat with unchanged private live_grader at its actual 4CPU/8GiB profile; separate from actor public 24GiB controls.",
  "grader_resources":list(arms.RESOURCES),"step_timeout_s":tasks.GRADE_STEP_TIMEOUT,
  "source_hashes":sources,"cases":[{"id":i,"image":image} for i,image in CASES]})
 rows=[]
 for ident,image in CASES:
  out=ROOT/ident;out.mkdir()
  bundle=json.loads((DATA/"fresh-tasks"/ident/"bundle.json").read_text())
  record=json.loads(pathlib.Path(bundle["record_path"]).read_text())
  gold=(DATA/"fresh-tasks"/ident/"build/gold.patch").read_text()
  save(out/"inputs.json",{"bundle_sha256":sha(DATA/"fresh-tasks"/ident/"bundle.json"),
   "record_sha256":sha(pathlib.Path(bundle["record_path"])),"gold_sha256":hashlib.sha256(gold.encode()).hexdigest(),
   "image":image,"expected":bundle["expected"]})
  fn=tasks.live_grader(record,bundle,image,out/"grader")
  outcomes={}
  for name,patch in (("negative",""),("positive",gold),("positive-repeat",gold)):
   result=fn(patch,name)
   p=subprocess.run(["docker","inspect",result["container"]],capture_output=True,text=True,timeout=10)
   result["independently_absent"]=p.returncode!=0 and "no such" in p.stderr.lower()
   save(out/(name+".json"),result);outcomes[name]=result
   print(json.dumps({"id":ident,"state":name,"result":result}),flush=True)
   assert result.get("container_removed") and result["independently_absent"] and not result.get("oom_killed"),result
   assert not result.get("error"),result
   assert result["pass"] is (name!="negative"),result
  rows.append({"id":ident,"image":image,"outcomes":outcomes})
 assert all(sha(pathlib.Path(p))==v for p,v in sources.items()),"grader source changed during controls"
 save(ROOT/"results.json",{"tasks":rows,"source_hashes":sources,"provider_calls":0,"repair_admission":False})
if __name__=="__main__":main()
