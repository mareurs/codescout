import hashlib,io,json,pathlib,tarfile
HOME=pathlib.Path("/home/marius/work/claude/codescout")
BASE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
OUT=HOME/"docs/research/data/2026-11-05-external-prepared-entry-evidence.tar.gz"
MANIFEST=HOME/"docs/research/data/2026-11-05-external-prepared-entry-preservation.json"
def sha(data):return hashlib.sha256(data).hexdigest()
def main():
 payload={}
 def add(path,name):
  if not path.is_file() or path.is_symlink():return
  assert name not in payload,name
  payload[name]=path.read_bytes()
 for area in ("agent_lifecycle","hint_authority_pilot","hint_authority_workflow"):
  for p in sorted((V/"tools"/area).glob("*.py")):add(p,"source/tools/"+area+"/"+p.name)
 review=pathlib.Path("/tmp/external-capture-review-01a15ca9-20261105")
 for p in sorted(review.rglob("*")):
  rel=p.relative_to(review)
  if any(x in ("pristine","work") for x in rel.parts):continue
  if p.suffix in (".json",".md",".patch",".log"):add(p,"review/"+str(rel))
 for name in ("external-entry-qualification-20261105","external-native-capabilities-20261105",
              "external-native-references-20261105","external-native-warm-references-20261105"):
  root=BASE/name
  for p in sorted(root.rglob("*")):
   rel=p.relative_to(root)
   if any(x in ("client-home","native-home","knowledge") for x in rel.parts):continue
   if p.suffix in (".json",".jsonl",".log",".patch"):add(p,name+"/"+str(rel))
 authors=BASE/"external-onboarding-once-20261105"
 for name in ("registration.json","author-admission.json"):add(authors/name,"author-static/"+name)
 for p in sorted((authors/"admission").rglob("*")):add(p,"author-static/admission/"+str(p.relative_to(authors/"admission")))
 for ident in ("nushell__nushell-18863","rust-lang__rust-analyzer-22992"):
  for name in ("prepared.json","preflight.json","prompt.txt","mcp-native-argv.json","knowledge-before.json"):
   add(authors/ident/name,"author-static/"+ident+"/"+name)
 # Close failed Jina evidence without copying the partial store or any model weights.
 jina=BASE/"external-workflow-setup-20261105"
 for p in sorted(jina.rglob("*")):
  rel=p.relative_to(jina)
  if any(x in ("knowledge","native-home") for x in rel.parts):continue
  if p.suffix in (".json",".stdout",".stderr"):add(p,"jina-failed-setup/"+str(rel))
 scripts=("external-entry-qualify","external-entry-resume","external-native-ready",
  "external-native-references","external-native-warm-references","external-author-once",
  "admit-external-author","external-private-controls","external-semantic-setup","external-default-index")
 for name in scripts:add(pathlib.Path("/tmp")/(name+"-01a15ca9-20261105.py"),"scripts/"+name+"-01a15ca9-20261105.py")
 add(pathlib.Path(__file__),"scripts/"+pathlib.Path(__file__).name)
 entries={n:{"bytes":len(data),"sha256":sha(data)} for n,data in sorted(payload.items())}
 manifest={"source_commit":"c1d51c446c5712b6a09c82e358f5ffbda834923c",
  "source_patch_id":"c9c3d68dfc083d1c570c9a2ba5143b0b1e542f93","files":entries,
  "limits":"Closed adapter/wire/reference/review/gate and static author preparation only. Live authors, private controls and default index results are not closed or included. No model weights, Docker images, live DBs, native/client profiles or real credential file. Private controller archive must never be mounted into an author or repair actor.",
  "old_instrument_failure":"First Nushell capture audit expected only probe path; capture correctly also retained automatic .gitignore line. Original failure retained; resumed audit reused closed receipt and patch, no second CLI invocation."}
 with OUT.open("xb") as output:
  with tarfile.open(fileobj=output,mode="w:gz") as archive:
   for name,data in sorted(payload.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;archive.addfile(info,io.BytesIO(data))
   data=(json.dumps(manifest,indent=2)+"\n").encode();info=tarfile.TarInfo("manifest.json");info.size=len(data);info.mode=0o600;archive.addfile(info,io.BytesIO(data))
 with tarfile.open(OUT,"r:gz") as archive:
  actual={m.name for m in archive.getmembers() if m.isfile() and m.name!="manifest.json"}
  assert actual==set(entries)
  for name in actual:assert sha(archive.extractfile(name).read())==entries[name]["sha256"],name
 result={"archive":str(OUT),"archive_sha256":sha(OUT.read_bytes()),"actual_regular_payload_files_verified":len(actual),
  "payload_bytes":sum(len(v) for v in payload.values()),"archive_bytes":OUT.stat().st_size,
  "source_commit":manifest["source_commit"],"limits":manifest["limits"]}
 with MANIFEST.open("x") as f:json.dump(result,f,indent=2);f.write("\n")
 print(json.dumps(result,indent=2))
if __name__=="__main__":main()
