import hashlib,json,pathlib,shlex,shutil,subprocess,sys,tomllib
from decimal import Decimal
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
sys.path.insert(0,str(V/"tools/agent_lifecycle"))
import external
from qualify import worker
BASE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
PRE=BASE/"external-transfer-admission-20261105"
QUAL=BASE/"external-entry-qualification-20261105"
ROOT=BASE/"external-onboarding-once-20261105"
CASES=("nushell__nushell-18863","rust-lang__rust-analyzer-22992")
PRIOR=Decimal("35.255714099999999604")
CEILING=Decimal("150")
AUTHOR_CAP=Decimal("20")
REPAIR_CAP=Decimal("8")

def save(path,value):
 with path.open("x") as f:json.dump(value,f,indent=2);f.write("\n")

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def register():
 ROOT.mkdir()
 source_paths=sorted((V/"tools/agent_lifecycle").glob("*.py"))
 source_paths+=sorted((V/"tools/hint_authority_pilot").glob("*.py"))
 save(ROOT/"registration.json",{"known_prior_cli_repair_continuation_usd":str(PRIOR),
  "finite_known_series_ceiling_usd":str(CEILING),
  "budget_scope":"Known repair/continuation series plus newly measured external author and repair attempts; not all historical research/review/setup/invoice or CPU spend.",
  "author_max_usd_each":str(AUTHOR_CAP),"author_cli_cap_usd_each":"19",
  "author_count":2,"repair_max_usd_each":str(REPAIR_CAP),"repair_count":4,
  "maximum_new_reserved_usd":str(AUTHOR_CAP*2+REPAIR_CAP*4),
  "unallocated_against_known_series_usd":str(CEILING-PRIOR-AUTHOR_CAP*2-REPAIR_CAP*4),
  "cases":list(CASES),
  "repair_order":[[CASES[0],"low"],[CASES[1],"xhigh"],[CASES[0],"xhigh"],[CASES[1],"low"]],
  "decision":"Once-only source author for each external workspace, then freeze identical isolated knowledge per arm. No task/problem/gold/test feedback is supplied to an author. Author may use generated grep fallback while independent deterministic index setup runs. Semantic readiness and private controls are mandatory before repairs.",
  "source_hashes":{str(p.relative_to(V)):sha(p) for p in source_paths},
  "global_rules_sha256":sha(pathlib.Path("/home/marius/.claude/CLAUDE.md")),
  "repair_admitted":False})
 print("registered source-only authors and future reserves; no calls launched")

def prepare(ident):
 assert ident in CASES
 reg=json.loads((ROOT/"registration.json").read_text())
 assert PRIOR+2*AUTHOR_CAP+4*REPAIR_CAP<=CEILING
 for p,digest in reg["source_hashes"].items():
  assert sha(V/p)==digest,"source changed since registration: "+p
 source=QUAL/ident;proof=json.loads((source/"result.json").read_text())
 assert proof["receipt"]["workflow_completed"] and proof["provider_calls"]==proof["credential_reads"]==0
 assert proof["patch_applied_to_fresh_exact_image"] and proof["all_recorded_native_containers_independently_absent"]
 warm=BASE/"external-native-warm-references-20261105"/ident/"warm-reference-2.json"
 text=json.dumps(json.loads(warm.read_text())["result"])
 assert "crates/nu-cli/" in text if ident==CASES[0] else "crates/base-db/" in text
 out=ROOT/ident;out.mkdir()
 actor=pathlib.Path("/tmp")/("cs-author-once-01a15ca9-20261105-"+str(CASES.index(ident)));actor.mkdir()
 old=json.loads((source/"prepared.json").read_text())
 oldactor=pathlib.Path(old["actor"])
 for name in ("CLAUDE.md","AGENTS.md"):shutil.copyfile(oldactor/name,actor/name)
 global_rules=pathlib.Path("/home/marius/.claude/CLAUDE.md")
 assert sha(global_rules)==reg["global_rules_sha256"]
 home=out/"native-home";(home/".claude").mkdir(parents=True)
 shutil.copyfile(global_rules,home/".claude/CLAUDE.md")
 kb=out/"knowledge"
 scaffold=PRE/"native-probes"/ident/"generated-codescout"
 kb.mkdir()
 for p in scaffold.rglob("*"):
  if p.is_file() and not p.is_symlink() and p.suffix in (".md",".toml") and ".history" not in p.relative_to(scaffold).parts:
   dest=kb/p.relative_to(scaffold);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
 save(out/"knowledge-before.json",{str(p.relative_to(kb)):sha(p) for p in kb.rglob("*") if p.is_file()})
 argv=json.loads((source/"mcp-native-argv.json").read_text())
 for i,item in enumerate(argv):
  if item.startswith("type=bind,") and ",dst=/testbed/.codescout" in item:
   argv[i]="type=bind,src="+str(kb)+",dst=/testbed/.codescout"
  elif item.startswith("type=bind,") and ",dst=/bench-home" in item and ",dst=/bench-home/" not in item:
   argv[i]="type=bind,src="+str(home)+",dst=/bench-home"
 save(out/"mcp-native-argv.json",argv)
 projects=tomllib.loads((kb/"workspace.toml").read_text())["project"]
 required=[str(pathlib.PurePosixPath(".codescout")/"system-prompt.md")]
 topics=("project-overview","architecture","conventions","development-commands","domain-glossary","gotchas")
 for project in projects:
  folder=pathlib.PurePosixPath(".codescout")
  if project["root"]!=".":folder=folder/"projects"/project["id"]
  required += [str(folder/"memories"/(topic+".md")) for topic in topics]
 code="import pathlib,sys; required="+repr(required)+"; missing=[p for p in required if not pathlib.Path(p).is_file() or pathlib.Path(p).stat().st_size<40]; print('Required knowledge files missing or below 40 bytes:', missing); sys.exit(bool(missing))"
 prompt="""Complete the existing source-only Codescout onboarding for the workspace at /testbed. This is shared setup once per project, with no repair task or issue supplied. Use only repository source, manifests, existing docs and generated onboarding prompts. Do not inspect Git history, host paths, benchmark metadata or external sources. All repository access uses container-local Codescout MCP.

Onboarding scaffolding already exists. Do not force or restart onboarding. Read .codescout/tmp/onboarding-prompt.md, each per-project prompt and onboarding-workspace-synthesis.md. Complete the exploration, all six required project memories per discovered project, and workspace synthesis plus .codescout/system-prompt.md. Work sequentially in this single author context, reusing discoveries; spawning agents is intentionally unavailable. Use generated templates, genuine inspected source citations and concrete build/test commands. If semantic search is not ready, use the prompt's grep fallback and report that limitation. A cold LSP warning is not a result about absence: retry a named reference after other useful exploration.

Preserve existing CLAUDE.md and AGENTS.md exactly; their current instructions are frozen for the comparison. This overrides the generated instruction to refresh them. Never edit production source, tests, manifests or Git metadata. Only Codescout knowledge and system-prompt files should be authored; its automatic .gitignore addition is separately recorded. Do not create placeholder summaries to satisfy file checks. Eligible empty stubs for glossary/gotchas must follow the provided convention.

After writing substantive memories and system prompt, call onboarding() once to witness completion, and finish any owed prompt refresh without repeating source exploration. Return an honest inventory and remaining gaps. File-presence checks are only coverage checks; they do not establish fact quality, functional correctness or environment readiness."""
 cfg={"image":old["image"],"baseline_commit":old["baseline_commit"],"actor":str(actor),
  "cli":old["cli"],"plugin":old["plugin"],"global_rules":str(global_rules),"prompt":prompt,
  "checks":[{"id":"knowledge_file_coverage","command":"python3 -c "+shlex.quote(code)}],
  "timeout_s":3600,"check_timeout_s":30,"max_continuations":8,
  "files":{str(p):sha(p) for p in (out/"mcp-native-argv.json",global_rules,pathlib.Path(old["cli"]),actor/"CLAUDE.md",actor/"AGENTS.md")}}
 save(out/"prepared.json",cfg);(out/"prompt.txt").write_text(prompt)
 external.validate_prepared(out,"high",AUTHOR_CAP,Decimal("19"))
 save(out/"preflight.json",{"id":ident,"source_only":True,"author_calls":0,"provider_calls":0,
  "knowledge_required_paths":required,"native_mounts":[x for x in argv if x.startswith("type=bind,")],
  "setup_cache_reused":"existing generated source-only scaffolding only; full semantic cache attached after deterministic setup closes",
  "actor_instruction_hashes":{n:sha(actor/n) for n in ("CLAUDE.md","AGENTS.md")},
  "prepared_sha256":sha(out/"prepared.json")})
 print("prepared "+ident+"; no paid call")

def launch(ident):
 assert ident in CASES
 reg=json.loads((ROOT/"registration.json").read_text())
 for p,digest in reg["source_hashes"].items():assert sha(V/p)==digest,p
 # Gate and accepted review are explicit, independently created admission evidence.
 admission=json.loads((ROOT/"author-admission.json").read_text())
 assert admission["source_only_authors_admitted"] is True and admission["repair_admitted"] is False
 assert admission["registration_sha256"]==sha(ROOT/"registration.json")
 for path,digest in admission["proof_sha256"].items():assert sha(pathlib.Path(path))==digest,path
 out=ROOT/ident
 if (out/"started.json").exists():raise ValueError("author already invoked; preserve and continue its facts, never re-onboard")
 for other in CASES:
  previous=ROOT/other
  if (previous/"started.json").exists():
   proof=json.loads((previous/"author-cost-reconciled.json").read_text())
   assert Decimal(proof["cost_usd"])<=AUTHOR_CAP
 receipt=external.launch(out,effort="high",allowance=AUTHOR_CAP,cli_cap=Decimal("19"))
 # Read the two raw terminal artifacts and receipt with the existing pure reconciler.
 sys.path.insert(0,str(V/"tools/hint_authority_workflow"))
 import driver
 cost=driver.reconcile(out,receipt,AUTHOR_CAP)
 save(out/"author-cost-reconciled.json",{"session_id":receipt["session_id"],"cost_usd":str(cost),
  "cost_known":True,"workflow_completed":receipt["workflow_completed"],"budget_scope":reg["budget_scope"]})
 save(out/"knowledge-after.json",{str(p.relative_to(out/"knowledge")):sha(p) for p in (out/"knowledge").rglob("*") if p.is_file() and not p.is_symlink()})
 print(json.dumps({"id":ident,"cost_usd":str(cost),"receipt":receipt}),flush=True)
if __name__=="__main__":
 action=sys.argv[1]
 if action=="register":register()
 elif action=="prepare":prepare(sys.argv[2])
 elif action=="launch":launch(sys.argv[2])
 else:raise ValueError("unknown action")
