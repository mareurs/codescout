import hashlib,json
from pathlib import Path
out=Path("/tmp/codescout-nu-low-replay-audit-20261106")
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
s=json.loads((out/"summary.json").read_text())
p=Path("/home/marius/.cache/codescout-resident/codescout/external-matched-repairs-20261105/nushell__nushell-18863--low/private-grade.json")
v=s["integrity"]["original_grade_sha256"]
v.update(path=str(p),actual=sha(p),matches=sha(p)==v["registered"])
original=Path("/home/marius/.cache/codescout-resident/codescout/external-matched-repairs-20261105/nushell__nushell-18863--low/private-grader/low-a6931258")
copy=Path("/tmp/codescout-private-grade-audit-20261106/nushell__nushell-18863--low")
s["original_raw_grade_unchanged"]={name:sha(original/("grade."+name))==sha(copy/("grade.original."+name)) for name in ["json","log"]}
s["instrument_correction"]="Initial audit.py compared registered original_grade_sha256 with nested grader grade.json; registration hashes arm/private-grade.json. Correct path independently matched. Initial raw output retained; no original evidence changed."
(out/"corrected-summary.json").write_text(json.dumps(s,indent=2,sort_keys=True)+"\n")
print(json.dumps({"integrity":s["integrity"],"original_raw_grade_unchanged":s["original_raw_grade_unchanged"],"registered_source_files":s["registered_source_files"],"registered_sources_unchanged":s["registered_sources_unchanged"],"original_audit_report_sha256":s["original_audit_report_sha256"]},indent=2))
