import hashlib,json
from pathlib import Path
for name in ["codescout-nu-low-replay-audit-20261106","codescout-private-grade-journal-supplement-20261106"]:
    d=Path("/tmp")/name
    items={str(p.relative_to(d)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(d.rglob("*")) if p.is_file() and p.name!="sha256-manifest.json"}
    m=d/"sha256-manifest.json"
    m.write_text(json.dumps(items,indent=2,sort_keys=True)+"\n")
    print(str(d))
    for p in [d/"report.txt",m]:
        print(hashlib.sha256(p.read_bytes()).hexdigest(),str(p))
