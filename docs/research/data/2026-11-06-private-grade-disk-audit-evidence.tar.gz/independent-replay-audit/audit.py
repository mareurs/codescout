import sys
sys.dont_write_bytecode = True
import json, hashlib, shutil
from pathlib import Path
from collections import Counter
sys.path.insert(0, "/home/marius/work/claude/codescout/tools/setup-ab-eval")
from multilang_grade import run_parser
from multilang_tasks import expected_sets
out = Path("/tmp/codescout-nu-low-replay-audit-20261106")
base = Path("/home/marius/.cache/codescout-resident/codescout")
replay = base/"external-grade-audit-20261106/nu-low-original-profile-replay"
cohort = base/"external-matched-repairs-20261105"
arm = cohort/"nushell__nushell-18863--low"
task = Path("/home/marius/work/claude/setup-ab-data/fresh-tasks/nushell__nushell-18863")
def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(n, v):
    (out/n).write_text(json.dumps(v, indent=2, sort_keys=True)+"\n")
reg = json.loads((replay/"registration.json").read_text())
record = json.loads((task/"build/record.json").read_text())
bundle = json.loads((task/"bundle.json").read_text())
grade_dir = replay/"grader/low-diagnostic-replay-91d86169"
log = (grade_dir/"grade.log").read_text()
grade = json.loads((grade_dir/"grade.json").read_text())
statuses = run_parser(record["log_parser"], log)
f2p,p2p = expected_sets(record,bundle)
save("parsed-statuses.json", statuses)
save("expected-statuses.json", {"f2p":{n:statuses.get(n) for n in f2p},"p2p":{n:statuses.get(n) for n in p2p}})
lines=log.splitlines()
needles = [n.split("::",1)[1] for n in f2p]
hits = [i for i,line in enumerate(lines) if any(n in line for n in needles)]
contexts=[]
for i in hits:
    contexts.append({"match_line":i+1,"lines":[{"line":j+1,"text":lines[j]} for j in range(max(0,i-2),min(len(lines),i+13))]})
save("assertion-contexts.json",contexts)
obs=[json.loads(x) for x in (replay/"resource-observations.jsonl").read_text().splitlines() if x.strip()]
probes=[o for o in obs if o.get("container_probe_exit")==0 and isinstance(o.get("container"),dict)]
events=[]
for o in probes:
    events.append({k:int(v) for k,v in (x.split() for x in o["container"]["memory_events"].splitlines())})
resource = {
 "samples":len(obs),"successful_container_probes":len(probes),
 "host_available_min":min(o["host_root_available_bytes"] for o in obs if "host_root_available_bytes" in o),
 "tmp_available_min":min(o["container"]["tmp_available_bytes"] for o in probes),
 "memory_peak_max":max(int(o["container"]["memory_peak"]) for o in probes),
 "memory_max_values":sorted({o["container"]["memory_max"].strip() for o in probes}),
 "event_maxima":{k:max(e.get(k,0) for e in events) for k in set().union(*events)},
 "probe_exit_counts":dict(Counter(str(o.get("container_probe_exit","absent")) for o in obs)),
 "first_sample":obs[0]["utc"],"last_sample":obs[-1]["utc"]}
original_grade=arm/"private-grader/low-a6931258/grade.json"
paths={"candidate_sha256":arm/"candidate.patch","original_grade_sha256":original_grade,
"original_results_sha256":cohort/"results.json","bundle_sha256":task/"bundle.json","record_sha256":task/"build/record.json"}
integrity={k:{"path":str(p),"actual":sha(p),"registered":reg[k],"matches":sha(p)==reg[k]} for k,p in paths.items()}
source_integrity={p:{"registered":h,"actual":sha(p),"matches":sha(p)==h} for p,h in reg["source_hashes"].items()}
save("source-integrity.json",source_integrity)
summary={"f2p_expected":len(f2p),"f2p_counts":dict(Counter(statuses.get(n,"missing") for n in f2p)),
"p2p_expected":len(p2p),"p2p_counts":dict(Counter(statuses.get(n,"missing") for n in p2p)),
"parsed_status_count":len(statuses),"expected_missing":[n for n in f2p+p2p if n not in statuses],
"expected_not_passing":{n:statuses.get(n) for n in f2p+p2p if statuses.get(n)!="pass"},
"outside_expected_counts":dict(Counter(s for n,s in statuses.items() if n not in set(f2p+p2p))),
"grade":grade,"resources":resource,"integrity":integrity,
"registered_source_files":len(source_integrity),"registered_sources_unchanged":all(v["matches"] for v in source_integrity.values()),
"original_audit_report_sha256":sha("/tmp/codescout-private-grade-audit-20261106/report.txt")}
save("summary.json",summary)
copied={}
for src in [grade_dir/"grade.log",grade_dir/"grade.json",replay/"resource-observations.jsonl",replay/"registration.json",replay/"summary.json",replay/"result.json"]:
    dst=out/("copied-"+src.name)
    shutil.copyfile(src,dst)
    copied[str(src)]={"copy":str(dst),"sha256":sha(dst),"byte_identical":src.read_bytes()==dst.read_bytes()}
save("copied-evidence.json",copied)
print(json.dumps(summary,indent=2))
print(json.dumps(contexts,indent=2))
