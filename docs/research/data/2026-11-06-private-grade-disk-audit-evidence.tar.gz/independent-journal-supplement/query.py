import datetime,hashlib,json,pathlib,subprocess
OUT=pathlib.Path(__file__).parent
FIELDS=["__REALTIME_TIMESTAMP","_SOURCE_REALTIME_TIMESTAMP","MESSAGE","COREDUMP_PID","COREDUMP_CGROUP","COREDUMP_EXE","COREDUMP_SIGNAL","COREDUMP_SIGNAL_NAME","COREDUMP_UNIT","COREDUMP_TIMESTAMP","_PID","_SYSTEMD_UNIT","_SYSTEMD_CGROUP","SYSLOG_IDENTIFIER"]
CONTAINER="0cdda52eccee77301892550ddae51c6df0b6e794f8fdeff8e4930d414de2b0a7"
NAME="sab-grade-nushell__nushell-18863-low-e9d452bc"
def query(label,since,until,filters,select=lambda row:True):
    cmd=["journalctl","--since",since,"--until",until,"--no-pager","-o","json","--output-fields="+",".join(FIELDS)]+filters
    p=subprocess.run(cmd,capture_output=True,text=True,timeout=30)
    rows=[]
    for line in p.stdout.splitlines():
        raw=json.loads(line)
        row={k:raw[k] for k in FIELDS if k in raw}
        if select(row):
            rows.append(row)
    result={"command":cmd,"returncode":p.returncode,"stderr":p.stderr,"rows":rows,"selected_rows":len(rows),
            "provenance":"actual independent journal query; explicit output-field allowlist; selected events only"}
    (OUT/(label+".json")).write_text(json.dumps(result,indent=2)+"\n")
    print(label,json.dumps(result,indent=2))
    return result
core=query("linker-coredump","2026-11-06 09:49:00","2026-11-06 09:54:00",["COREDUMP_PID=434016"])
query("docker-name-correlation","2026-11-06 09:38:00","2026-11-06 09:39:00",["SYSLOG_IDENTIFIER=dockerd"],lambda row:CONTAINER in str(row.get("MESSAGE","")) or NAME in str(row.get("MESSAGE","")))
query("docker-scope","2026-11-06 09:38:00","2026-11-06 09:53:00",["-u","docker-"+CONTAINER+".scope"])
query("disk-errors","2026-11-06 09:50:30","2026-11-06 09:52:30",["--grep=No space left on device|Failed to compress|Failed to write|Disk quota"])
for i,row in enumerate(core["rows"]):
    if "_SYSTEMD_UNIT" in row:
        query("coredump-handler-"+str(i),"2026-11-06 09:50:00","2026-11-06 09:53:00",["_SYSTEMD_UNIT="+row["_SYSTEMD_UNIT"]])
