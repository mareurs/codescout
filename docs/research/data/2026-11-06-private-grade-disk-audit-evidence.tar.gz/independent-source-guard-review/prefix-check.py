import hashlib,importlib.util,json,pathlib,sys
root=pathlib.Path(__file__).parent
spec=importlib.util.spec_from_file_location("tests",str(root/"test_guard.py"))
tests=importlib.util.module_from_spec(spec)
spec.loader.exec_module(tests)
case=tests.SourceGuardTest("test_exact_append_accepted")
case.setUp()
try:
    before=(case.root/".gitignore").read_bytes()
    case.append()
    call_log=root/"prefix-calls.jsonl"
    if call_log.exists():
        raise RuntimeError("call log exists; preserve earlier control")
    prefix=[sys.executable,str(root/"prefix-wrapper.py"),str(call_log)]
    result=tests.guard.check_source(prefix,case.head)
    calls=[json.loads(line) for line in call_log.read_text().splitlines()]
    assert len(calls)==6,calls
    assert all(c[:3]==["git","-C",str(case.root)] for c in calls[:5]),calls
    assert calls[-1]==["cat",str(case.root/".gitignore")],calls
    assert result["exact_startup_append"]
    assert result["baseline_gitignore_sha256"]==hashlib.sha256(before).hexdigest()
    assert result["current_gitignore_sha256"]==hashlib.sha256((case.root/".gitignore").read_bytes()).hexdigest()
    print(json.dumps({"prefix":prefix,"calls":calls,"result":result},indent=2))
finally:
    case.doCleanups()
