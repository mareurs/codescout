import json, os, pathlib, sys
with pathlib.Path(sys.argv[1]).open('a') as stream:
    stream.write(json.dumps(sys.argv[2:]) + '\n')
os.execvp(sys.argv[2], sys.argv[2:])
