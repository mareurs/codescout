import pathlib,json,sys,hashlib,os,subprocess,threading,datetime,time
B=pathlib.Path('/home/marius/.cache/codescout-resident/codescout');OLD=B/'external-matched-repairs-20261105';OUT=B/'external-grade-audit-20261106/nu-low-original-profile-replay';OUT.mkdir(exist_ok=False)
TOOLS=pathlib.Path('/home/marius/work/claude/codescout/tools/setup-ab-eval');DATA=pathlib.Path('/home/marius/work/claude/setup-ab-data/fresh-tasks/nushell__nushell-18863')
controls=json.loads((B/'external-private-controls-20261105/results.json').read_text())
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
for p,d in controls['source_hashes'].items():assert sha(p)==d,p
sys.path.insert(0,str(TOOLS));import arms,multilang_tasks as tasks,multilang_grade as grade
assert arms.RESOURCES==('--cpus','4','--memory','8g')
case=next(x for x in controls['tasks'] if x['id']=='nushell__nushell-18863');bundle=json.loads((DATA/'bundle.json').read_text());record=json.loads(pathlib.Path(bundle['record_path']).read_text());original=OLD/'nushell__nushell-18863--low';capture=json.loads((original/'candidate-capture.json').read_text());assert sha(original/'candidate.patch')==capture['sha256']
s=os.statvfs(str(OUT));assert s.f_bavail*s.f_frsize>=80*1024**3
registration={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'selection_rule':'original private grade has zero parsed statuses and internal linker SIGBUS; one identical-candidate diagnostic replay, no model/candidate resampling','candidate_sha256':capture['sha256'],'original_grade_sha256':sha(original/'private-grade.json'),'original_results_sha256':sha(OLD/'results.json'),'bundle_sha256':sha(DATA/'bundle.json'),'record_sha256':sha(bundle['record_path']),'image':case['image'],'resources':list(arms.RESOURCES),'source_hashes':controls['source_hashes'],'provider_calls':0,'root_available_bytes_before':s.f_bavail*s.f_frsize}
(OUT/'registration.json').write_text(json.dumps(registration,indent=2)+'\n')
stop=threading.Event()
def monitor():
 cid=None
 while not stop.is_set():
  s=os.statvfs(str(OUT));row={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'host_root_available_bytes':s.f_bavail*s.f_frsize}
  try:
   if cid is None:
    p=subprocess.run(['docker','ps','--no-trunc','--filter','name=sab-grade-nushell__nushell-18863-low-diagnostic-replay-','--format','{{.ID}}'],capture_output=True,text=True,timeout=5);ids=p.stdout.split();assert len(ids)<=1
    if ids:cid=ids[0]
   if cid:
    row['container_id']=cid
    code="import pathlib,os,json;print(json.dumps({'memory_events':pathlib.Path('/sys/fs/cgroup/memory.events').read_text(),'memory_peak':pathlib.Path('/sys/fs/cgroup/memory.peak').read_text(),'memory_max':pathlib.Path('/sys/fs/cgroup/memory.max').read_text(),'tmp_available_bytes':os.statvfs('/tmp').f_bavail*os.statvfs('/tmp').f_frsize,'tmp_mounts':[x.strip() for x in open('/proc/self/mountinfo') if x.split()[4]=='/tmp']}))"
    p=subprocess.run(['docker','exec',cid,'python3','-c',code],capture_output=True,text=True,timeout=5);row['container_probe_exit']=p.returncode
    if p.returncode==0:row['container']=json.loads(p.stdout)
  except Exception as e:row['monitor_error']=repr(e)
  with (OUT/'resource-observations.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
  stop.wait(10)
thread=threading.Thread(target=monitor,daemon=True);thread.start()
try:
 fn=tasks.live_grader(record,bundle,case['image'],OUT/'grader')
 result=fn((original/'candidate.patch').read_text(),'low-diagnostic-replay')
finally:
 stop.set();thread.join(10)
p=subprocess.run(['docker','inspect',result['container']],capture_output=True,text=True,timeout=10);result['independently_absent']=p.returncode!=0 and 'no such' in p.stderr.lower()
for path,d in controls['source_hashes'].items():assert sha(path)==d,path
assert sha(original/'candidate.patch')==capture['sha256']
(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
log=pathlib.Path(result['log']).read_text(errors='replace');statuses=grade.run_parser(record['log_parser'],log);f2p,p2p=tasks.expected_sets(record,bundle)
summary={'result':result,'parsed_status_count':len(statuses),'f2p_statuses':{n:statuses.get(n) for n in f2p},'candidate_unchanged':True,'provider_calls':0,'original_receipts_unchanged':sha(original/'private-grade.json')==registration['original_grade_sha256'] and sha(OLD/'results.json')==registration['original_results_sha256']}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
