import pathlib,json,re,hashlib,sys,datetime
B=pathlib.Path('/home/marius/.cache/codescout-resident/codescout');ROOT=B/'external-matched-repairs-20261105';OUT=B/'external-grade-audit-20261106';OUT.mkdir(exist_ok=False)
TOOLS=pathlib.Path('/home/marius/work/claude/codescout/tools/setup-ab-eval');DATA=pathlib.Path('/home/marius/work/claude/setup-ab-data/fresh-tasks')
controls=json.loads((B/'external-private-controls-20261105/results.json').read_text())
for p,digest in controls['source_hashes'].items():assert hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()==digest,p
sys.path.insert(0,str(TOOLS));import multilang_grade as grade,multilang_tasks as tasks
original=json.loads((ROOT/'results.json').read_text());summary=[]
patterns={'disk_error':r'No space left on device|Disk quota exceeded|\bENOSPC\b|\bEDQUOT\b|\bos error (?:28|122)\b','memory_error':r'memory allocation of [0-9]+ bytes failed|Cannot allocate memory|signal: 9, SIGKILL|^Killed$|Out of memory:','execution_error':r'Permission denied \(os error 13\)|Couldn.t run the test|could not execute process','linker_crash':r'ld terminated with signal 7|LLVM ERROR|PLEASE submit a bug report to https://github.com/llvm'}
for row in original['private_grades']:
 ident,effort=row['id'],row['effort'];g=row['grade'];bundle=json.loads((DATA/ident/'bundle.json').read_text());record=json.loads(pathlib.Path(bundle['record_path']).read_text());f2p,p2p=tasks.expected_sets(record,bundle)
 log=pathlib.Path(g['log']);text=log.read_text(errors='replace');statuses=grade.run_parser(record['log_parser'],text);verdict=grade.verdict(statuses,f2p,p2p)
 for key in ['pass','expected','not_passing','missing']:assert verdict[key]==g[key],(ident,effort,key)
 files=set((ROOT/(ident+'--'+effort)).glob('verification-*/*.log'))|set((ROOT/(ident+'--'+effort)).glob('background-logs/*.log'))|{log}
 scan=[]
 for p in sorted(files):
  content=p.read_text(errors='replace');hits=[]
  for line_no,line in enumerate(content.splitlines(),1):
   for kind,pattern in patterns.items():
    if re.search(pattern,line,re.I):hits.append({'kind':kind,'line':line_no,'text':line[:1800]})
  scan.append({'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'hits':hits})
 expected=f2p+p2p;missing=[n for n in expected if n not in statuses];fail=[n for n in expected if statuses.get(n)=='fail'];skipped=[n for n in expected if statuses.get(n)=='skip']
 nonline_evidence=[]
 for name in missing:
  short=name.split('::',1)[-1]
  for no,line in enumerate(text.splitlines(),1):
   if 'test '+short+' ... ' in line:
    nonline_evidence.append({'expected_name':name,'line':no,'text':line[:1200]})
 rawgrade=json.loads(log.with_name('grade.json').read_text());truncated=[s for s in rawgrade.get('steps',[]) if s.get('truncated')]
 data={'id':ident,'effort':effort,'candidate_sha256':hashlib.sha256((ROOT/(ident+'--'+effort)/'candidate.patch').read_bytes()).hexdigest(),'original_grade':g,'reparsed_verdict_matches_original':True,'reparsed_status_count':len(statuses),'expected_count':len(expected),'unique_expected_count':len(set(expected)),'f2p_statuses':{n:statuses.get(n) for n in f2p},'expected_failed':fail,'expected_skipped':skipped,'missing_count':len(missing),'missing_status_lines_found':nonline_evidence,'log_scan_file_count':len(scan),'scan':scan,'truncated_steps':truncated}
 stem=ident+'--'+effort;(OUT/(stem+'.json')).write_text(json.dumps(data,indent=2)+'\n');(OUT/(stem+'-statuses.json')).write_text(json.dumps(statuses,indent=2)+'\n')
 summary.append({k:v for k,v in data.items() if k not in ['scan','original_grade']})
 print(json.dumps({k:data[k] for k in ['id','effort','expected_count','reparsed_status_count','missing_count','expected_failed','expected_skipped','f2p_statuses','missing_status_lines_found','log_scan_file_count']}),flush=True)
(OUT/'summary.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_results_sha256':hashlib.sha256((ROOT/'results.json').read_bytes()).hexdigest(),'source_hashes':controls['source_hashes'],'rows':summary,'scope':'Audit/reparse only; original candidates, costs and grades unchanged; literal log matches are not continuous resource telemetry.'},indent=2)+'\n')
