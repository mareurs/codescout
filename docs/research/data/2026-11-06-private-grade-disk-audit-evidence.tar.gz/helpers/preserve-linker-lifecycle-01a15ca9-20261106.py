import datetime
import hashlib
import json
import pathlib
import subprocess

root = pathlib.Path("/home/marius/.cache/codescout-resident/codescout/external-grade-audit-20261106")
old = root.parent / "external-matched-repairs-20261105" / "nushell__nushell-18863--low"
cid = "0cdda52eccee77301892550ddae51c6df0b6e794f8fdeff8e4930d414de2b0a7"
name = "sab-grade-nushell__nushell-18863-low-e9d452bc"
argv = ["journalctl", "--since", "2026-11-06 09:37:00", "--until", "2026-11-06 09:54:00", "--no-pager", "--grep", cid + "|" + name, "-o", "short-iso"]
p = subprocess.run(argv, capture_output=True, text=True, timeout=30)
assert p.returncode == 0, p.stderr
(root / "original-low-container-lifecycle.log").write_text(p.stdout)
files = [old/"private-grade.json", old/"private-grader/low-a6931258/grade.log"]
out = {"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "journal_argv": argv, "journal_exit_code": p.returncode, "container_id_from_crashed_process_cgroup": cid, "recorded_original_container_name": name, "artifacts": [{"path":str(f), "sha256":hashlib.sha256(f.read_bytes()).hexdigest(), "mtime_utc":datetime.datetime.fromtimestamp(f.stat().st_mtime,datetime.timezone.utc).isoformat()} for f in files], "interpretation": "Original private grade overlaps confirmed host ENOSPC window; crashed Rust1.95.0 linker cgroup maps to container start/stop lifecycle adjacent to original named grader network join. Disk pressure affected the same evaluation window; exact SIGBUS mechanism is not isolated from memory/toolchain factors. No semantic result was observed."}
(root / "historical-disk-correlation.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps(out,indent=2))
