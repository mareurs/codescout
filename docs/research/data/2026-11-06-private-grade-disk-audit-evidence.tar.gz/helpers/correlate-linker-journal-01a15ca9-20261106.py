import datetime
import json
import pathlib
import subprocess

root = pathlib.Path("/home/marius/.cache/codescout-resident/codescout/external-grade-audit-20261106")
keys = ["__REALTIME_TIMESTAMP", "MESSAGE", "COREDUMP_PID", "COREDUMP_CGROUP", "COREDUMP_EXE", "COREDUMP_SIGNAL", "COREDUMP_SIGNAL_NAME", "COREDUMP_UNIT", "COREDUMP_USER_UNIT", "_SYSTEMD_CGROUP"]
p = subprocess.run(["journalctl", "--since", "2026-11-06 09:49:00", "--until", "2026-11-06 09:54:00", "--no-pager", "--grep", "No space left|rust-lld|core dump|Bus error|SIGBUS", "-o", "json"], capture_output=True, text=True, timeout=30)
assert p.returncode == 0, p.stderr
rows = [{k: row[k] for k in keys if k in row} for row in map(json.loads, p.stdout.splitlines())]
out = {"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "scope": "Filtered system journal window. Only allowlisted fields retained; no environment fields read into output.", "journal_returncode": p.returncode, "rows": rows}
(root / "linker-journal-window.json").write_text(json.dumps(out, indent=2) + "\n")
print(json.dumps(out, indent=2))
