"""Archive only closed receipts/logs/patches/control evidence, never mounted homes/cache."""
import datetime
import hashlib
import io
import json
import pathlib
import re
import tarfile

BASE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
OLD=BASE/"external-matched-repairs-20261105"
AUDIT=BASE/"external-grade-audit-20261106"
MAIN=pathlib.Path("/home/marius/work/claude/codescout")
DEST=MAIN/"docs/research/data/2026-11-06-private-grade-disk-audit-evidence.tar.gz"
items={}
def add(path, arc):
    assert path.is_file() and not path.is_symlink(),str(path)
    assert arc not in items,arc
    items[arc]=path
def tree(root,prefix):
    for p in sorted(root.rglob("*")):
        if p.is_file() or p.is_symlink():
            add(p,prefix+"/"+str(p.relative_to(root)))

for p in sorted(OLD.iterdir()):
    if p.is_file():add(p,"original-cohort/"+p.name)
arms=["nushell__nushell-18863--low","nushell__nushell-18863--xhigh","rust-lang__rust-analyzer-22992--low","rust-lang__rust-analyzer-22992--xhigh"]
for arm in arms:
    root=OLD/arm
    for p in sorted(root.iterdir()):
        if p.is_file():add(p,"original-cohort/"+arm+"/"+p.name)
        elif p.is_dir() and (p.name.startswith("verification-") or p.name in ["private-grader","background-logs"]):
            tree(p,"original-cohort/"+arm+"/"+p.name)
tree(AUDIT,"audit")
tree(pathlib.Path("/tmp/codescout-private-grade-audit-20261106"),"independent-private-audit")
tree(pathlib.Path("/tmp/codescout-source-guard-review-20261106"),"independent-source-guard-review")
tree(pathlib.Path("/tmp/codescout-nu-low-replay-audit-20261106"),"independent-replay-audit")
tree(pathlib.Path("/tmp/codescout-private-grade-journal-supplement-20261106"),"independent-journal-supplement")
registration=json.loads((AUDIT/"nu-low-original-profile-replay/registration.json").read_text())
for source,digest in registration["source_hashes"].items():
    p=pathlib.Path(source)
    assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,source
    add(p,"bound-grader-source/"+p.name)
for name in [
    "audit-external-grades-01a15ca9-20261106.py","replay-nu-low-grade-01a15ca9-20261106.py",
    "summarize-grade-replay-01a15ca9-20261106.py","correlate-linker-journal-01a15ca9-20261106.py",
    "query-linker-cgroup-01a15ca9-20261106.py","preserve-linker-lifecycle-01a15ca9-20261106.py",
    "qualification-source-guard-01a15ca9.py","test-qualification-source-guard-01a15ca9.py",
    "qualify-executable-tmp-v3-01a15ca9-20261106.py",
    "archive-private-grade-audit-01a15ca9-20261106.py",
]:
    add(pathlib.Path("/tmp")/name,"helpers/"+name)
for name in ["455879-a720241d-bg_000000f6.json","455879-a720241d-bg_000000f7.json"]:
    add(pathlib.Path("/tmp/codescout-bg")/name,"jobs/"+name)
assert json.loads((AUDIT/"nu-low-original-profile-replay/summary.json").read_text())["original_receipts_unchanged"]
manifest=[]
sensitive=re.compile(rb"(?:sk-ant-[A-Za-z0-9_-]{20,}|sk-proj-[A-Za-z0-9_-]{20,}|Bearer [A-Za-z0-9._-]{30,})")
for arc,p in sorted(items.items()):
    data=p.read_bytes()
    scan=data
    if arc in ["bound-grader-source/test_frozen.py","helpers/archive-private-grade-audit-01a15ca9-20261106.py"]:
        # Verified source constant TOKENISH: an explicit synthetic NOTAREALTOKEN fixture.
        scan=scan.replace(b"sk-ant-oat01-NOTAREALTOKEN-0123456789abcdef",b"[EXPLICIT-SYNTHETIC-TEST-FIXTURE]")
    assert not sensitive.search(scan),"credential-like content requires review (not printed): "+arc
    manifest.append({"name":arc,"source":str(p),"size":len(data),"sha256":hashlib.sha256(data).hexdigest()})
m={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"scope":"Closed original four-arm terminal receipts/candidates/model streams/public verification/background/private logs; independent audits, one diagnostic replay and exact bound grader sources. Writable homes, semantic stores, embedding models, image layers, provider credentials and unfinished v3 baseline are excluded.","files":manifest}
DEST.parent.mkdir(parents=True,exist_ok=True)
with tarfile.open(DEST,"x:gz",dereference=False) as tf:
    for row in manifest:tf.add(items[row["name"]],arcname=row["name"],recursive=False)
    data=(json.dumps(m,indent=2)+"\n").encode()
    info=tarfile.TarInfo("MANIFEST.json");info.size=len(data);tf.addfile(info,io.BytesIO(data))
with tarfile.open(DEST,"r:gz") as tf:
    names=tf.getnames()
    assert set(names)=={x["name"] for x in manifest}|{"MANIFEST.json"}
    for row in manifest:
        data=tf.extractfile(row["name"]).read()
        assert len(data)==row["size"] and hashlib.sha256(data).hexdigest()==row["sha256"],row["name"]
    assert json.load(tf.extractfile("MANIFEST.json"))==m
receipt={"archive":str(DEST),"sha256":hashlib.sha256(DEST.read_bytes()).hexdigest(),"bytes":DEST.stat().st_size,"payload_files":len(manifest),"all_reopened_and_hash_verified":True,"original_results_sha256":hashlib.sha256((OLD/"results.json").read_bytes()).hexdigest()}
(DEST.with_suffix(DEST.suffix+".receipt.json")).write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt,indent=2))
