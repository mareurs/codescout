import json
import pathlib
import subprocess
root=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/external-grade-audit-20261106")
keys=["__REALTIME_TIMESTAMP","MESSAGE","COREDUMP_PID","COREDUMP_CGROUP","COREDUMP_EXE","COREDUMP_SIGNAL","COREDUMP_SIGNAL_NAME","COREDUMP_UNIT","COREDUMP_USER_UNIT","_SYSTEMD_CGROUP"]
p=subprocess.run(["journalctl","--since","2026-11-06 09:49:00","--until","2026-11-06 09:54:00","--no-pager","COREDUMP_PID=434016","-o","json"],capture_output=True,text=True,timeout=30)
assert p.returncode==0,p.stderr
rows=[]
for line in p.stdout.splitlines():
    row=json.loads(line)
    rows.append({"field_names":sorted(row), "fields":{k:row[k] for k in keys if k in row}})
out={"pid":434016,"rows":rows,"result_count":len(rows)}
(root/"linker-434016-cgroup-query.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps(out,indent=2))
