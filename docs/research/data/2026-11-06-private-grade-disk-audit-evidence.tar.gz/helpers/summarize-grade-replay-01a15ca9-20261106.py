import hashlib
import importlib
import json
import pathlib
import re
import sys

base=pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
root=base/"external-grade-audit-20261106"
replay=root/"nu-low-original-profile-replay"
summary=json.loads((replay/"summary.json").read_text())
registration=json.loads((replay/"registration.json").read_text())
for path,digest in registration.get("source_hashes",{}).items():
    assert hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()==digest,path
sys.path.insert(0,"/home/marius/work/claude/codescout/tools/setup-ab-eval")
import multilang_grade as grade
import multilang_tasks as tasks
data=pathlib.Path("/home/marius/work/claude/setup-ab-data/fresh-tasks/nushell__nushell-18863")
record=json.loads((data/"build/record.json").read_text())
bundle=json.loads((data/"bundle.json").read_text())
log=pathlib.Path(summary["result"]["log"]).read_text(errors="replace")
statuses=grade.run_parser(record["log_parser"],log)
f2p,p2p=tasks.expected_sets(record,bundle)
rows=[json.loads(line) for line in (replay/"resource-observations.jsonl").read_text().splitlines()]
container_rows=[r for r in rows if r.get("container_probe_exit")==0 and "container" in r]
def events(text):
    return {k:int(v) for k,v in (line.split() for line in text.splitlines())}
event_values=[events(r["container"]["memory_events"]) for r in container_rows]
patterns=[r"No space left",r"ENOSPC",r"Bus error",r"signal 7",r"LLVM ERROR",r"linking with .* failed",r"Killed"]
out={
    "source":"single preregistered unchanged-candidate diagnostic replay; original profile 4CPU/8GiB",
    "classification":"observed semantic failure; both F2P fail; selected P2P all pass",
    "expected_count":len(f2p)+len(p2p),"f2p_count":len(f2p),"p2p_count":len(p2p),
    "f2p_statuses":{n:statuses.get(n) for n in f2p},
    "p2p_pass_count":sum(statuses.get(n)=="pass" for n in p2p),
    "p2p_nonpassing":[{"name":n,"status":statuses.get(n)} for n in p2p if statuses.get(n)!="pass"],
    "missing_expected":[n for n in f2p+p2p if n not in statuses],
    "sampled_resource_observations":len(rows),"sampled_successful_container_probes":len(container_rows),
    "minimum_sampled_host_root_available_bytes":min(r["host_root_available_bytes"] for r in rows),
    "minimum_sampled_container_tmp_available_bytes":min(r["container"]["tmp_available_bytes"] for r in container_rows),
    "maximum_sampled_cgroup_memory_peak_bytes":max(int(r["container"]["memory_peak"]) for r in container_rows),
    "maximum_sampled_memory_event_counters":{k:max(e.get(k,0) for e in event_values) for k in set().union(*event_values)},
    "literal_infrastructure_signature_matches":[{"line":i,"text":line,"pattern":pattern} for i,line in enumerate(log.splitlines(),1) for pattern in patterns if re.search(pattern,line,re.I)],
    "original_receipts_unchanged":summary["original_receipts_unchanged"],
    "candidate_unchanged":summary["candidate_unchanged"],"provider_calls":0,
    "container_removed":summary["result"]["container_removed"],"independently_absent":summary["result"]["independently_absent"],
    "limits":"Resource extrema are from 10s samples, not continuous historical telemetry. High memory-limit hit counts are not OOMs. Successful linking with free disk does not isolate disk from other nondeterministic factors in the original SIGBUS."
}
assert out["p2p_pass_count"]==len(p2p)
assert all(v=="fail" for v in out["f2p_statuses"].values())
assert not out["missing_expected"]
(replay/"audited-outcome.json").write_text(json.dumps(out,indent=2)+"\n")
(replay/"parsed-statuses.json").write_text(json.dumps(statuses,indent=2,sort_keys=True)+"\n")
print(json.dumps(out,indent=2))
