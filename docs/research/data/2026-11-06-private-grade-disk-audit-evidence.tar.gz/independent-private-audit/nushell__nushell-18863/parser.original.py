def parser(log: str) -> dict[str, str]:
    import re

    # Normalize colored and progress-redrawn terminal output.
    ansi_re = re.compile(
        r"\x1b(?:"
        r"\[[0-?]*[ -/]*[@-~]"
        r"|\][^\x07\x1b]*(?:\x07|\x1b\\)"
        r"|[@-_]"
        r")"
    )
    log = ansi_re.sub("", log).replace("\r\n", "\n").replace("\r", "\n")

    results: dict[str, str] = {}
    suite = "unknown"

    doc_re = re.compile(r"^\s*Doc-tests\s+(.+?)\s*$", re.IGNORECASE)
    run_re = re.compile(r"^\s*Running\s+(.+?)\s*$")
    test_re = re.compile(
        r"^\s*test\s+(.+?)\s+\.\.\.\s+"
        r"(ok|pass(?:ed)?|fail(?:ed)?|error|ignored|skip(?:ped)?|bench)"
        r"(?:\s*,.*)?\s*$",
        re.IGNORECASE,
    )

    ranks = {"skip": 0, "pass": 1, "fail": 2}

    for line in log.splitlines():
        match = doc_re.match(line)
        if match:
            suite = "doctest:" + match.group(1).strip()
            continue

        match = run_re.match(line)
        if match:
            description = match.group(1).strip()

            # Cargo normally prints:
            # Running <target description> (<executable path>)
            if description.endswith(")") and " (" in description:
                target, executable = description.rsplit(" (", 1)
                executable = executable[:-1].strip()
                suite = executable or target.strip() or "unknown"
            else:
                suite = description or "unknown"
            continue

        match = test_re.match(line)
        if not match:
            continue

        name, raw_status = match.groups()
        raw_status = raw_status.lower()

        if raw_status in {"ok", "pass", "passed", "bench"}:
            status = "pass"
        elif raw_status in {"ignored", "skip", "skipped"}:
            status = "skip"
        else:
            status = "fail"

        key = f"{suite}::{name.strip()}"

        # If retries or repeated runs disagree, preserve the most severe
        # observed result so a failure cannot be hidden by a later pass.
        previous = results.get(key)
        if previous is None or ranks[status] > ranks[previous]:
            results[key] = status

    return results