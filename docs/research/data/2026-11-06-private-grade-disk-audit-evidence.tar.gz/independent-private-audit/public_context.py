import hashlib,json,pathlib,re,shutil
OUT=pathlib.Path(__file__).parent
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/external-matched-repairs-20261105")
results=json.loads((ROOT/"results.json").read_text())
records=[]
for row in results["arms"]:
    arm=row["id"]+"--"+row["effort"]
    source=ROOT/arm
    target=OUT/arm
    receipt=json.loads((source/"receipt.json").read_text())
    shutil.copyfile(source/"receipt.json",target/"receipt.original.json")
    candidate=source/"candidate.patch"
    actual=hashlib.sha256(candidate.read_bytes()).hexdigest()
    verification=receipt.get("public_verification",{})
    item={"arm":arm,"candidate_sha256_actual":actual,"candidate_sha256_registered":row["candidate_sha256"],
          "candidate_hash_matches":actual==row["candidate_sha256"],
          "receipt_sha256":hashlib.sha256((source/"receipt.json").read_bytes()).hexdigest(),
          "workflow_completed":receipt.get("workflow_completed"),
          "context_valid":receipt.get("context_valid"),"lifecycle_error":receipt.get("lifecycle",{}).get("error"),
          "public_verification":verification,"public_logs":[]}
    for i,check in enumerate(verification.get("checks",[])):
        original=pathlib.Path(check["log"])
        copy=target/("public-final-"+str(i)+".original.log")
        shutil.copyfile(original,copy)
        log=original.read_text()
        lines=log.splitlines()
        diagnostics=[{"line":n+1,"text":line} for n,line in enumerate(lines) if re.search(r"Permission denied|os error 13|No space left on device|ENOSPC|Bus error|signal 7|^error\[E|^error:|panicked at|^test result: FAILED",line)]
        item["public_logs"].append({"source":str(original),"copy":str(copy),"sha256":hashlib.sha256(original.read_bytes()).hexdigest(),
                                  "exit_code":check.get("exit_code"),"diagnostics":diagnostics})
    parsed=json.loads((target/"parsed-statuses.json").read_text())
    expected=json.loads((OUT/row["id"]/"expected.json").read_text())
    expected_names=set(expected["f2p"]+expected["p2p"])
    item["nonexpected_nonpassing"]={k:v for k,v in parsed.items() if k not in expected_names and v!="pass"}
    records.append(item)
shutil.copyfile(ROOT/"host-disk-cleanup-20261106.json",OUT/"host-disk-cleanup.original.json")
(OUT/"public-context.json").write_text(json.dumps(records,indent=2)+"\n")
print(json.dumps([{k:v for k,v in r.items() if k not in ["public_verification","public_logs","nonexpected_nonpassing"]} | {
    "final_checks":[{"id":c["id"],"exit_code":c["exit_code"]} for c in r["public_verification"].get("checks",[])],
    "diagnostic_count":[len(p["diagnostics"]) for p in r["public_logs"]],
    "nonexpected_failures":{k:v for k,v in r["nonexpected_nonpassing"].items() if v=="fail"}
} for r in records],indent=2))
