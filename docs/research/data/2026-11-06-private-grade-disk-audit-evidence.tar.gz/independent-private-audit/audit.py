import collections
import hashlib
import importlib.util
import json
import pathlib
import re
import shutil
import sys

OUT = pathlib.Path(__file__).parent
COHORT = pathlib.Path("/home/marius/.cache/codescout-resident/codescout/external-matched-repairs-20261105")
TASKS = pathlib.Path("/home/marius/work/claude/setup-ab-data/fresh-tasks")
CODE = pathlib.Path("/home/marius/work/claude/codescout/tools/setup-ab-eval")
sys.dont_write_bytecode = True
sys.path.insert(0, str(CODE))
import multilang_grade as grade
import multilang_tasks as tasks

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(name, data):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n")

def selected_lines(text, pattern, context=0):
    lines = text.splitlines()
    chosen = set()
    for i, line in enumerate(lines):
        if re.search(pattern, line, re.I):
            chosen.update(range(max(0, i-context), min(len(lines), i+context+1)))
    return [{"line": i+1, "text": lines[i]} for i in sorted(chosen)]

results_path = COHORT / "results.json"
results = json.loads(results_path.read_text())
shutil.copyfile(results_path, OUT / "results.original.json")
provenance = {"results": {"path": str(results_path), "sha256": digest(results_path)}, "code": {}}
for name in ["multilang_grade.py", "multilang_tasks.py", "multilang_control.py"]:
    pinned = CODE / name
    main = pathlib.Path("/home/marius/work/claude/codescout/tools/setup-ab-eval") / name
    provenance["code"][name] = {"path": str(pinned), "sha256": digest(pinned),
                                 "main_sha256": digest(main), "same_as_main": digest(pinned) == digest(main)}
taskdata = {}
for tid in dict.fromkeys(row["id"] for row in results["private_grades"]):
    bundle_path = TASKS / tid / "bundle.json"
    bundle = json.loads(bundle_path.read_text())
    record_path = pathlib.Path(bundle["record_path"])
    record = json.loads(record_path.read_text())
    f2p, p2p = tasks.expected_sets(record, bundle)
    taskdata[tid] = (bundle, record, f2p, p2p)
    dest = OUT / tid
    dest.mkdir(exist_ok=True)
    shutil.copyfile(bundle_path, dest / "bundle.original.json")
    shutil.copyfile(record_path, dest / "record.original.json")
    (dest / "parser.original.py").write_text(record["log_parser"])
    write(tid + "/expected.json", {"f2p": f2p, "p2p": p2p})
    provenance[tid] = {"bundle_path": str(bundle_path), "bundle_sha256": digest(bundle_path),
                      "record_path": str(record_path), "record_sha256": digest(record_path),
                      "parser_sha256": hashlib.sha256(record["log_parser"].encode()).hexdigest(),
                      "f2p_count": len(f2p), "p2p_count": len(p2p),
                      "f2p_unique": len(set(f2p)), "p2p_unique": len(set(p2p)),
                      "overlap": sorted(set(f2p) & set(p2p)),
                      "commands": {key: record.get(key) for key in ["test_cmds", "print_cmds", "rebuild"]},
                      "f2p": f2p}
audits = []
for row in results["private_grades"]:
    tid, effort = row["id"], row["effort"]
    bundle, record, f2p, p2p = taskdata[tid]
    path = pathlib.Path(row["grade"]["log"])
    log = path.read_text()
    original = json.loads(path.with_name("grade.json").read_text())
    subdir = OUT / (tid + "--" + effort)
    subdir.mkdir(exist_ok=True)
    shutil.copyfile(path, subdir / "grade.original.log")
    shutil.copyfile(path.with_name("grade.json"), subdir / "grade.original.json")
    statuses = grade.run_parser(record["log_parser"], log)
    verdict = grade.verdict(statuses, f2p, p2p)
    write(subdir.name + "/parsed-statuses.json", statuses)
    expected = f2p + p2p
    missing = [n for n in expected if n not in statuses]
    failed = {n:statuses[n] for n in expected if n in statuses and statuses[n] != "pass"}
    rowdata = {
        "id":tid, "effort":effort, "source_log":str(path), "log_sha256":digest(path),
        "log_bytes":path.stat().st_size, "log_lines":len(log.splitlines()),
        "grade_json_sha256":digest(path.with_name("grade.json")),
        "recorded_grade":row["grade"], "grade_json":original,
        "verdict_recomputed":verdict,
        "recorded_verdict_matches":all(row["grade"].get(k) == v for k,v in verdict.items()),
        "f2p_statuses":{n:statuses.get(n) for n in f2p},
        "p2p_status_counts":dict(collections.Counter(statuses.get(n,"MISSING") for n in p2p)),
        "all_parsed_status_counts":dict(collections.Counter(statuses.values())),
        "expected_status_counts":dict(collections.Counter(statuses.get(n,"MISSING") for n in expected)),
        "unexpected_names":[n for n in statuses if n not in set(expected)],
        "missing":missing, "present_nonpassing":failed,
        "raw_acceptance_lines": selected_lines(log, "|".join(re.escape(n.split("::",1)[1]) for n in f2p), 1),
        "diagnostics":selected_lines(log, r"error:|error\[E|SIGBUS|bus error|no space left|ENOSPC|LLVM ERROR|PLEASE submit|LLVM crashed|linking with|panicked at|test result: FAILED|mixed_str_length_result_does_replace_last|bare_external_with_inherited_stdout_does_not_capture", 1),
        "test_result_summaries":selected_lines(log,r"^test result:"),
        "running_suites":selected_lines(log,r"^\s*(Running |Doc-tests )"),
    }
    write(subdir.name + "/audit.json", rowdata)
    audits.append(rowdata)
perturbations = []
for tid, (bundle, record, f2p, p2p) in taskdata.items():
    key = f2p[0]
    suite, name = key.split("::",1)
    header = "Running probe (" + suite + ")\n"
    passed = "test " + name + " ... ok\n"
    failed = "test " + name + " ... FAILED\n"
    inputs = {
       "plain_pass":header+passed,
       "stdout_newline":header+"hello\n"+passed,
       "stdout_concatenated":header+"hello"+passed,
       "pass_to_fail":header+failed,
       "remove_status":header,
       "repeat_pass_fail":header+passed+failed,
       "repeat_fail_pass":header+failed+passed,
    }
    for label, text in inputs.items():
        parsed = grade.run_parser(record["log_parser"], text)
        path = OUT / tid / ("perturbation-"+label+".log")
        path.write_text(text)
        result={"id":tid,"case":label,"input":str(path),"input_sha256":digest(path),
                "expected_name":key,"statuses":parsed,"verdict":grade.verdict(parsed,[key],[])}
        perturbations.append(result)
    # Observe original combined log after changing only the known stdout/status boundary.
    if tid == "nushell__nushell-18863":
        high = next(a for a in audits if a["id"]==tid and a["effort"]=="xhigh")
        raw = pathlib.Path(high["source_log"]).read_text()
        target = "test last_result::bare_external_with_inherited_stdout_does_not_capture"
        matching = [line for line in raw.splitlines() if target in line]
        if len(matching) == 1:
            line = matching[0]
            needle = line[:line.index(target)]
            altered = raw.replace(line, needle+"\n"+line[line.index(target):], 1)
            (OUT / tid / "xhigh-newline-control.log").write_text(altered)
            parsed = grade.run_parser(record["log_parser"], altered)
            write(tid + "/xhigh-newline-control.json",{
                "changed_original_line":line,"prefix":needle,
                "verdict":grade.verdict(parsed,f2p,p2p),
                "statuses_for_previous_nonpassing":{n:parsed.get(n) for n in high["missing"]+list(high["present_nonpassing"])}
            })
write("provenance.json", provenance)
write("perturbations.json", perturbations)
write("summary.json", [{"id":a["id"],"effort":a["effort"],"verdict":a["verdict_recomputed"],
                       "f2p_statuses":a["f2p_statuses"],"expected_status_counts":a["expected_status_counts"],
                       "present_nonpassing":a["present_nonpassing"],"missing_count":len(a["missing"]),
                       "recorded_verdict_matches":a["recorded_verdict_matches"],
                       "all_parsed_status_counts":a["all_parsed_status_counts"]} for a in audits])
print((OUT / "summary.json").read_text())
print("PERTURBATIONS",json.dumps([{k:r[k] for k in ["id","case","statuses","verdict"]} for r in perturbations],indent=2))
