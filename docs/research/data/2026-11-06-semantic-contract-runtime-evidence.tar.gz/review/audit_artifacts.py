"""Independent read-only audit of original artifacts; writes only review receipts."""
import hashlib,json,pathlib,sys,tarfile,shutil
from decimal import Decimal
R=pathlib.Path("/tmp/semantic-contract-runtime-review-20261106")
MAIN=pathlib.Path("/home/marius/work/claude/codescout")
BASE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
ROOT=BASE/"semantic-contract-runtime-20261106"
BUNDLE=BASE/"semantic-contract-pilot-20261106"
QUAL=BASE/"external-exec-baseline-20261106-v3"
sys.path.insert(0,str(MAIN/".worktrees/semantic-contract-runtime-01a15ca9/tools/hint_authority_pilot"))
sys.path.insert(0,str(R/"baseline"))
import external
def sha(path):
    h=hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda:f.read(1048576),b""):h.update(chunk)
    return h.hexdigest()
def read(path):return json.loads(pathlib.Path(path).read_text())
def exact_hash(path,digest):
    actual=sha(path)
    assert actual==digest,(str(path),actual,digest)
def archive(name,digest):
    path=MAIN/"docs/research/data"/name
    exact_hash(path,digest)
    with tarfile.open(path) as t:
        rows=json.load(t.extractfile("MANIFEST.json"))["files"]
        for item in rows:
            data=t.extractfile(item["name"]).read()
            assert hashlib.sha256(data).hexdigest()==item["sha256"],item
            assert len(data)==item["size"],item
    return {x["source"]:x["sha256"] for x in rows},len(rows)
reg=read(BUNDLE/"prompt-inputs-registration.json")
runreg=read(ROOT/"runtime-registration.json")
result=read(ROOT/"prepared/prepared-manifests.json")
job=read("/tmp/codescout-bg/455879-a720241d-bg_0000010d.json")
assert (job["state"],job["exit_code"])==("exited",0)
assert (result["stage"],result["launch_admitted"],result["provider_calls"])==("native-configs-only",False,0)
frozen,frozen_n=archive("2026-11-06-semantic-contract-preparation-evidence.tar.gz","f796140a42a00f2d83e91fe55c1d2be373f4fe7ec652616acbda99649966e089")
qualified,qualified_n=archive("2026-11-06-executable-native-baseline-evidence.tar.gz","a6f224468b952c814988dc784f1bf036d02ad71aea1ba22ab3408b0bfc405f38")
for path,d in runreg["input_hashes"].items():
    exact_hash(path,d);assert frozen[path]==d,path
for path,d in runreg["qualification_hashes"].items():
    exact_hash(path,d);assert qualified[path]==d,path
for path,d in reg["protected_original_hashes"].items():exact_hash(path,d)
for path,d in runreg["source_hashes"].items():
    # Executed versions are frozen by the reviewer and independent source-v1 backup.
    exact_hash(R/"baseline"/pathlib.Path(path).name,d)
    exact_hash(ROOT/"source-v1"/pathlib.Path(path).name,d)
exact_hash(ROOT/"prepare-runtime.py",runreg["helper_sha256"])
for path,d in read(QUAL/"registration.json")["source_hashes"].items():exact_hash(R/"baseline"/path,d)
rows=read(BUNDLE/"matrix.json")["arms"]
assert len(rows)==len(result["arms"])==6
assert [x["arm_id"] for x in rows]==[task+"--"+variant for task,variant in reg["order"]]
expected_efforts=["low","xhigh","low","low","xhigh","low"]
assert [x["effort"] for x in rows]==expected_efforts
assert [x["arm_id"] for x in result["arms"]]==[task+"--"+variant for task,variant in reg["order"]]
assert [x["effort"] for x in result["arms"]]==expected_efforts
assert Decimal(reg["budget"]["known_prior_usd"])+6*Decimal(reg["budget"]["reserve_usd_each"])==Decimal("178.180531399999999104")
assert Decimal(reg["budget"]["cli_cap_usd_each"])==19
assert reg["budget"]["reserve_usd_each"]=="20"
assert Decimal(reg["budget"]["series_ceiling_usd"])==200
protocol=(BUNDLE/"protocol.txt").read_bytes()
exact_hash(BUNDLE/"protocol.txt",reg["protocol_sha256"])
snapshots={};source_inodes=set();source_payloads=0
for task,p in reg["projects"].items():
    manifest_path=pathlib.Path(p["runtime_snapshot_manifest"]);snap=manifest_path.parent
    exact_hash(manifest_path,p["runtime_snapshot_manifest_sha256"]);m=read(manifest_path)
    assert (m["image"],m["actor_baseline"],m["snapshot_id"],m["logical_snapshot_id"])==(p["image"],p["baseline_commit"],p["runtime_snapshot_id"],p["logical_snapshot_id"])
    expected=set(m["files"])
    actual=set()
    for file in snap.rglob("*"):
        assert not file.is_symlink(),str(file)
        if file.is_file() and file.name!="manifest.json":actual.add(file.relative_to(snap).as_posix())
    assert actual==expected,(task,actual^expected)
    for name,proof in m["files"].items():
        file=snap/name;exact_hash(file,proof["sha256"]);assert file.stat().st_size==proof["bytes"]
        source_inodes.add((file.stat().st_dev,file.stat().st_ino));source_payloads+=1
    snapshots[task]=(snap,m)
all_clone_inodes={};arms=[];payloads=0;mount_count=0;readonly_unique={}
for index,(row,entry) in enumerate(zip(rows,result["arms"])):
    task=row["task"];project=reg["projects"][task];out=pathlib.Path(entry["out"])
    assert entry["variant"]==row["variant"]
    exact_hash(out/"prepared.json",entry["prepared_sha256"])
    exact_hash(out/"input-clone-manifest.json",entry["clone_manifest_sha256"])
    cfg=read(out/"prepared.json");snap,m=snapshots[task]
    cloned=read(out/"input-clone-manifest.json")
    assert cloned=={"files":m["files"],"separate_physical_files":True}
    actual=set()
    for folder in ("knowledge","member-state","native-home","instructions"):
        for f in (out/folder).rglob("*"):
            assert not f.is_symlink(),str(f)
            if f.is_file():actual.add(f.relative_to(out).as_posix())
    assert actual==set(m["files"])
    for name,proof in m["files"].items():
        f=out/name;exact_hash(f,proof["sha256"]);st=f.stat();assert st.st_size==proof["bytes"]
        key=(st.st_dev,st.st_ino)
        assert key not in source_inodes and key not in all_clone_inodes,(str(f),all_clone_inodes.get(key))
        all_clone_inodes[key]=str(f);payloads+=1
    actor=pathlib.Path(cfg["actor"])
    assert actor==pathlib.Path("/tmp/cs-semantic-contract-01a15ca9-20261106")/str(index)
    assert set(p.name for p in actor.iterdir())=={"CLAUDE.md","AGENTS.md"}
    for name in ("CLAUDE.md","AGENTS.md"):
        expected=(BUNDLE/"shared"/task/name).read_bytes()
        assert (actor/name).read_bytes()==(out/"actor-context"/name).read_bytes()==(out/"instructions"/name).read_bytes()==expected
        exact_hash(actor/name,project["project_rules_sha256"][name])
    assert pathlib.Path(cfg["global_rules"]).read_bytes()==(BUNDLE/"shared"/task/"global-CLAUDE.md").read_bytes()
    exact_hash(cfg["global_rules"],project["global_rules_sha256"])
    prompt=pathlib.Path(row["prompt"]).read_bytes()
    assert cfg["prompt"].encode()==prompt
    exact_hash(row["prompt"],row["prompt_sha256"])
    control=(BUNDLE/"arms"/(task+"--low-control")/"prompt.txt").read_bytes()
    assert hashlib.sha256(control).hexdigest()==project["base_prompt_sha256"]
    expected_prompt=control if row["variant"]!="low-contract" else control+b"\n\nAdditional behavioral-contract protocol:\n"+protocol
    assert prompt==expected_prompt,(task,row["variant"])
    assert cfg["checks"]==row["public_checks"]==project["checks"]
    assert (cfg["image"],cfg["baseline_commit"],cfg["cli"],cfg["plugin"])==(project["image"],project["baseline_commit"],project["cli"],project["plugin"])
    assert (cfg["timeout_s"],cfg["check_timeout_s"],cfg["max_continuations"])==(3600,1800,8)
    for path,d in cfg["files"].items():exact_hash(path,d)
    for name in ("started.json","launch.json","receipt.json"):assert not (out/name).exists()
    template=read(QUAL/task/"native-argv.json");native=read(out/"mcp-native-argv.json")
    expected=list(template);mapping={"/bench-home":out/"native-home","/testbed/.codescout":out/"knowledge"}
    for p in m["projects"]:
        if p["root"]!=".":mapping["/testbed/"+p["root"]+"/.codescout"]=out/"member-state"/p["id"]
    seen=set();rw=set();readonly=[]
    for i,value in enumerate(template):
        if value!="--mount":continue
        fields=dict((x.split("=",1)+[""])[:2] for x in template[i+1].split(","))
        dst=fields["dst"];assert dst not in seen;seen.add(dst)
        if "readonly" in fields:
            readonly.append(template[i+1]);readonly_unique[dst]=fields["src"]
        else:
            assert dst in mapping,dst
            expected[i+1]="type=bind,src="+str(mapping[dst])+",dst="+dst
            assert mapping[dst].is_dir()
            rw.add(dst)
    assert rw==set(mapping)
    name="cs-semantic-contract-01a15ca9-"+str(index)
    expected[expected.index("--name")+1]=name
    expected[expected.index("--label")+1]="codescout.semantic-contract="+name
    assert native==expected,task
    assert any("dst=/bench-home/.cache/codescout/fastembed,readonly" in x for x in readonly)
    external.validate_prepared(out,row["effort"],Decimal("20"),Decimal("19"))
    mount_count+=len(seen)
    arms.append({"arm_id":row["arm_id"],"payloads":len(m["files"]),"writable_mounts":len(rw),"readonly_mounts":len(readonly),"validator_effort":row["effort"],"prepared_sha256":sha(out/"prepared.json")})
# Write only to disposable copies, then verify every original source/clone byte again for the selected payload.
task=rows[0]["task"];snap,m=snapshots[task]
selected=next(name for name in m["files"] if name.startswith("knowledge/") and name.endswith(".db"))
real_a=pathlib.Path(result["arms"][0]["out"])/selected
real_b=next(pathlib.Path(e["out"])/selected for e in result["arms"][1:] if e["task"]==task)
wroot=R/"actual-write-witness";wroot.mkdir()
a=wroot/"a.db";b=wroot/"b.db";shutil.copy2(real_a,a);shutil.copy2(real_b,b)
before={str(p):sha(p) for p in (snap/selected,real_a,real_b,b)}
with a.open("ab") as f:f.write(b"independent-review-write")
assert sha(a)!=m["files"][selected]["sha256"]
for p,d in before.items():exact_hash(p,d)
receipt={"status":"pass","original_sources_read_only":True,"closed_job":job,"archive_payloads_reopened":{"frozen":frozen_n,"qualified":qualified_n},
"runtime_input_hashes":len(runreg["input_hashes"]),"qualification_hashes":len(runreg["qualification_hashes"]),"protected_old_artifacts":len(reg["protected_original_hashes"]),
"executed_lifecycle_source_files":len(runreg["source_hashes"]),"source_payloads":source_payloads,"clone_payloads":payloads,"unique_clone_inodes":len(all_clone_inodes),
"all_clone_inodes_disjoint_from_all_source_inodes":True,"arms":arms,"native_mounts":mount_count,"readonly_sources":readonly_unique,
"actual_write_witness":{"selected":selected,"modified":str(a),"unchanged":before},
"launch_admitted":False,"actual_cli_wire_verified":False}
(R/"artifact-audit.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt,indent=2))
