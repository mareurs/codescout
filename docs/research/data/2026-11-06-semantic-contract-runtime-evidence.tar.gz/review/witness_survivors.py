"""Observe surviving mutations on tiny disposable fixtures; no actor process."""
import importlib.util,json,pathlib,sys,tempfile,unittest.mock as mock,shutil,os
R=pathlib.Path("/tmp/semantic-contract-runtime-review-20261106")
sys.path[:0]=[str(R/"baseline"),"/home/marius/work/claude/codescout/.worktrees/semantic-contract-runtime-01a15ca9/tools/hint_authority_pilot"]
import test_semantic_prepare as fixtures
import external
from types import SimpleNamespace
def module(name):
    spec=importlib.util.spec_from_file_location("subject_"+name,R/name/"semantic_prepare.py")
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
def outcome(fn):
    try:
        value=fn()
        return {"status":"accepted"}
    except ValueError as e:return {"status":"rejected","reason":str(e)}
observations=[]
real_copytree=shutil.copytree
for label in ("baseline","M08"):
    with tempfile.TemporaryDirectory(dir=R) as raw:
        root=pathlib.Path(raw);source=root/"source";source.mkdir();m=fixtures.snapshot(source)
        subject=module(label)
        with mock.patch.object(subject,"shutil",SimpleNamespace(copytree=lambda src,dst:real_copytree(src,dst,copy_function=os.link))):
            result=outcome(lambda:subject.clone_snapshot(source,root/"out",m))
        if result["status"]=="accepted":
            (root/"out/knowledge/store.db").write_bytes(b"mutation write")
            result["source_changed_by_clone_write"]=(source/"knowledge/store.db").read_bytes()==b"mutation write"
        observations.append({"mutation":"M08","implementation":label,**result})
for label in ("baseline","M07"):
    with tempfile.TemporaryDirectory(dir=R) as raw:
        root=pathlib.Path(raw);bundle,q,rows=fixtures.PreparationTests().bundle(root)
        path=q/rows[0]["task"]/"native-argv.json";argv=json.loads(path.read_text());argv[argv.index("--memory")+1]="24g";path.write_text(json.dumps(argv))
        result=outcome(lambda:module(label).prepare(bundle,root/"out",root/"actors",q))
        observations.append({"mutation":"M07","implementation":label,"invalid_config":"memory=24g",**result})
for label in ("baseline","M11"):
    with tempfile.TemporaryDirectory(dir=R) as raw:
        root=pathlib.Path(raw);bundle,q,rows=fixtures.PreparationTests().bundle(root)
        rp=bundle/"prompt-inputs-registration.json";reg=json.loads(rp.read_text());project=reg["projects"][rows[0]["task"]]
        mp=pathlib.Path(project["runtime_snapshot_manifest"]);m=json.loads(mp.read_text());m["actor_baseline"]="0"*40;mp.write_text(json.dumps(m))
        project["runtime_snapshot_manifest_sha256"]=fixtures.digest(mp);rp.write_text(json.dumps(reg))
        result=outcome(lambda:module(label).prepare(bundle,root/"out",root/"actors",q))
        result["output_created"]=(root/"out").exists();result["actors_created"]=(root/"actors").exists()
        observations.append({"mutation":"M11","implementation":label,"changed_field":"actor_baseline",**result})
for label in ("baseline","M10"):
    with tempfile.TemporaryDirectory(dir=R) as raw:
        root=pathlib.Path(raw);bundle,q,rows=fixtures.PreparationTests().bundle(root)
        with mock.patch.object(external,"validate_prepared",wraps=external.validate_prepared) as wrapped:
            module(label).prepare(bundle,root/"out",root/"actors",q)
            efforts=[call.args[1] for call in wrapped.call_args_list]
        observations.append({"mutation":"M10","implementation":label,"validator_efforts":efforts})
for label in ("baseline","M09"):
    with tempfile.TemporaryDirectory(dir=R) as raw:
        root=pathlib.Path(raw);bundle,q,rows=fixtures.PreparationTests().bundle(root)
        module(label).prepare(bundle,root/"out",root/"actors",q)
        actor=root/"actors/0/AGENTS.md";expected=bundle/"shared"/rows[0]["task"]/"AGENTS.md"
        observations.append({"mutation":"M09","implementation":label,"actor_agents_bytes":actor.stat().st_size,"frozen_agents_bytes":expected.stat().st_size,"same_bytes":actor.read_bytes()==expected.read_bytes()})
(R/"survivor-witnesses.json").write_text(json.dumps(observations,indent=2)+"\n")
print(json.dumps(observations,indent=2))
