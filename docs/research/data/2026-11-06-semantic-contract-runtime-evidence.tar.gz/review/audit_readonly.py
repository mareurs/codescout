"""Read-only identity audit; hash each unique mount tree once after six-way path equality."""
import json,pathlib,hashlib,tarfile
R=pathlib.Path("/tmp/semantic-contract-runtime-review-20261106")
def sha(path):
    h=hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda:f.read(1048576),b""):h.update(chunk)
    return h.hexdigest()
path=pathlib.Path("/home/marius/work/claude/codescout/docs/research/data/2026-11-06-private-grade-disk-audit-evidence.tar.gz")
assert sha(path)=="89dfc97b0d7a901d4da3f37a9beb5576e7fe7d36f319cfdce8ddbf986367f518"
manifest_path=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/external-matched-repairs-20261105/native-readonly-inputs.json")
with tarfile.open(path) as tar:
    manifest=json.load(tar.extractfile("MANIFEST.json"))
    entry=next(x for x in manifest["files"] if x["source"]==str(manifest_path))
    data=tar.extractfile(entry["name"]).read()
    assert hashlib.sha256(data).hexdigest()==entry["sha256"]==sha(manifest_path)
prior=json.loads(data)
audit=json.loads((R/"artifact-audit.json").read_text())
sources=audit["readonly_sources"];assert set(prior)==set(sources)
result=[]
for dst,source in sources.items():
    root=pathlib.Path(source)
    actual={p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file() or p.is_symlink()}
    assert actual==set(prior[dst]),dst
    records=[]
    for name,proof in prior[dst].items():
        p=root/name
        if "link" in proof:
            assert p.is_symlink() and str(p.readlink())==proof["link"]
            assert sha(p)==proof["resolved_sha256"]
        else:
            assert not p.is_symlink() and sha(p)==proof["sha256"]
        records.append({"name":name,"sha256":sha(p),"symlink":p.is_symlink()})
    result.append({"destination":dst,"source":source,"files":records})
receipt={"status":"pass","manifest_sha256":sha(manifest_path),"archived_manifest_verified":True,"trees":result,
"unique_manifest_records":sum(len(x["files"]) for x in result),"symlink_records":sum(r["symlink"] for x in result for r in x["files"]),
"scope":"Four readonly sources shared by six arms; six-way exact argv identity independently verified in artifact-audit.json"}
(R/"readonly-audit.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({k:v for k,v in receipt.items() if k!="trees"},indent=2))
