# Independent semantic-contract runtime review

Reviewed base: `36fec1201b0f809d6f21cc31082def4d651b6cf8`.
Worktree: `/home/marius/work/claude/codescout/.worktrees/semantic-contract-runtime-01a15ca9`.
Evidence root: `/tmp/semantic-contract-runtime-review-20261106`.
Review scope: the complete original bytes of semantic_prepare.py, test_semantic_prepare.py and private prepare-runtime.py, plus the closed six-arm preparation and its frozen inputs. Original implementation and artifacts were read-only. Mutations were made in separate disposable copies.

**Result:** no defect was found in the current six prepared native configurations or payload population. Four Important regression-coverage findings were filed immediately. The original suite killed 7 of 12 applied mutations and allowed 5 to survive. Parent remediation added tests only; its exact same 12 mutant source files now fail the expanded suite. The observed findings are addressed at the focused test boundary. This is readiness for retaining/reviewing **native-configs-only, launch_admitted=false** artifacts; it is not runtime/CLI-wire qualification, paid-launch approval, or evidence of protocol effectiveness.

## Source identity

- Original helper SHA256: `fe5691d3422195a97e02d551d4511f1073715fa56de52a56738a013a5462e36a`; unchanged after the parent's test-only fix.
- Original test SHA256: `e5a3e4b37bdb05199b2d0b1e07c5918b1350564bb3452153fefaca408309e6de`.
- Parent revised test SHA256: `2e71e8acae97bdabf697163e303a2e11196aa9e894ccb893aea83c78ec20a6e6`.
- Full 21-file lifecycle source identity plus private caller identity is in `source-sha256.json`. Each executed lifecycle file matched both reviewer baseline/ and the parent's source-v1/ backup and runtime registration.
- The caller's qualified lifecycle source hashes and template/closure hashes matched the archived qualified-baseline manifest. HEAD remained the named base; no commit, index, branch, merge or push operation was performed by this reviewer.

## Important findings and observed effect

All references in this section describe the immutable **original v1** files in `baseline/`, which preserve the reviewed line numbers.

1. **1134bec5140494f3 — required actor validation and effort arguments were not observed by tests.** At `baseline/semantic_prepare.py:163`, M07 removed external.validate_prepared entirely and M10 passed constant low instead of the row's actual effort. Both survived all ten original tests. The independent tiny-fixture witness then demonstrated that M07 accepts memory=24g while the original rejects it. M10 demonstrably changes the validation call sequence to six lows, while output labels remain unchanged. This is an interface-argument gap, not evidence that an eventual model would run at the wrong effort. Relevant test: `baseline/test_semantic_prepare.py:141`.
2. **426f23b3ae33383b — post-copy isolation rejection had no negative control.** At `baseline/semantic_prepare.py:52`, M08 removed the symlink/shared-inode guard and survived all ten original tests. A subsequent real hardlink fault injection made the original reject; M08 accepted, and an actual write through the accepted disposable clone changed the disposable source. Existing positive copies are genuinely isolated; the missing coverage was the separate rejection branch. Relevant test: `baseline/test_semantic_prepare.py:37`.
3. **98c33698d67d6a0b — the actor AGENTS.md sibling was outside the byte-preservation assertion.** At `baseline/semantic_prepare.py:150`, M09 wrote empty actor AGENTS.md while retaining the full backup; all ten original tests passed. The follow-up witness measured 0 actor bytes versus 1,656 frozen bytes. The original positive test only compared actor CLAUDE.md at `baseline/test_semantic_prepare.py:158`; hashing a truncated file into the config does not establish equality with the frozen rules.
4. **0493d56c581fee30 — source snapshot identity binding had no negative fixture.** At `baseline/semantic_prepare.py:120`, M11 bypassed the manifest's image/baseline/snapshot-ID comparison and survived all ten tests. A well-hashed copied manifest with a wrong actor_baseline was then rejected by the original before any output/actor creation, but accepted by M11. Fixture construction always matched those identities at `baseline/test_semantic_prepare.py:123`.

No Critical or Minor findings were identified in this bounded review. These are test gaps discovered by observed surviving mutations; they are not claims that the unchanged current helper or prepared cohort contains those mutations.

## Applied mutation population

Each row was applied alone to a complete copied baseline. Each original run executed the ten real test_semantic_prepare tests. Exact old/new source snippets and purposes are in `mutations.json`; source SHA, test diagnostics and original/parent outcomes are in `mutation-results.json`.

| ID | Single mutation | Original outcome | Parent expanded suite |
|---|---|---|---|
| M01 | Copy with hardlinks | Killed | Killed |
| M02 | Skip source revalidation before output | Killed | Killed |
| M03 | Ignore extra payload population | Killed | Killed |
| M04 | Retain old writable mount sources | Killed | Killed |
| M05 | Append unwanted prompt text | Killed | Killed |
| M06 | Replace output arm ID with WRONG | Killed | Killed |
| M07 | Remove actor validation call | Survived | Killed |
| M08 | Remove clone inode/symlink guard | Survived | Killed |
| M09 | Write empty actor AGENTS.md | Survived | Killed |
| M10 | Pass low to every actor validation | Survived | Killed |
| M11 | Remove snapshot identity comparison | Survived | Killed |
| M12 | Admit unknown writable destination | Killed | Killed |

Original: **12 applied, 7 killed, 5 survived, 0 mutation-harness errors**. M01's ValueError and M02's file errors arise from the mutated production path and are genuine kills, not harness failures. Original baseline: 10 tests passed. All five survivors were observed before additional controls were suggested.

Parent remediation: **12 killed, 0 survived**, 13 tests per mutation. The parent ran this reapplication; the reviewer did not substitute a second claimed independent run. I read all 12 logs and checked that all 12 parent mutant source files are byte-identical to the review's original mutants. The parent's unmutated expanded suite records 13 passed, and its lifecycle suite records 89 passed. Those logs are copied into `parent-remediation/`. This verifies the response to the selected mutation population, not exhaustive coverage.

## Independent artifact audit

The actual preparation job @bg_0000010d was closed, exit 0, before artifact inspection. `artifact-audit.json` and `artifact-audit-v2.log` record independent complete-population checks:

- Exactly six IDs in the frozen order, with actual efforts low/xhigh/low/low/xhigh/low and distinct variant labels.
- All **1,950 source manifest payload records** and all **5,850 cloned payload records** matched SHA256 and byte size. Every cloned (device, inode) pair was globally distinct from every source inode and every other clone inode. Exact payload populations were checked; no symlink payload was admitted.
- Both actor CLAUDE.md and AGENTS.md, both durable actor-context backups, cloned instructions and full global rules matched the complete frozen bytes for every arm.
- Each prepared prompt matched its frozen row hash. Control prompts matched the old common task hashes; each treatment was exactly the common prompt plus the designated separator and frozen protocol. Public checks and 3600/1800/8 workflow limits matched.
- All **294 actual mount entries** were compared against an independently constructed expected argv from the archived templates: 45 writable and 4 readonly mounts per arm. All writable sources point into the correct arm. Name/label changes were exact. Other native argv bytes were unchanged.
- Each of the six original generated configs was consumed through the original external.validate_prepared using its actual effort and 20/19 reserve/cap. No started.json, launch.json or receipt.json existed in an arm.
- All 24 registered frozen input files, 4 qualified files and 24 protected historical files retained their hashes. The earlier frozen-preparation archive's 174 payloads and qualified-baseline archive's 44 payloads were all reopened and hash/size verified.
- The observed write witness appended bytes to a disposable copy of a real cloned SQLite payload. Its pristine source, both selected real arm payloads, and disposable sibling retained their hashes. Separately, the original unit test calls clone_snapshot on a tiny source, writes one generated clone, and observes source/sibling unchanged. No real prepared state was written.

The scope of 5,850 is **manifest payload files**, not all filesystem entries, config files or directories. The source population is counted from complete manifest records and reconciled with filesystem payloads.

`readonly-audit.json` independently binds the old readonly manifest to its archived copy and rehashes all **61 unique records** across four shared readonly sources, including **10 symlink records** with both exact link text and resolved bytes. The six-way exact mount-source equality is established in the artifact audit. These records cover native binary, runtime libraries, LSP payload and global model caches. They do not prove that a later launched process actually used them.

## Strengths

The preparer makes the limited admission state explicit, reuses the frozen verifier, checks complete snapshot populations before cloning, and performs independent physical copies with a post-copy inode defense. The original tests already perform actual writes and discriminate prompt bytes, arm IDs, unknown writable mounts, old writable sources, corruption and extra payloads. The private caller binds qualified source/template identities and checks the whole cohort after creation. The review's hashes and filesystem observations corroborate the closed caller result rather than merely trusting its success flag.

## Instrument limits and preserved failures

The initial copied-suite run lacked qualify.py's sibling hint_authority_pilot import path; a second attempt used the wrong sibling path. Both produced ModuleNotFoundError before preparation and are retained as baseline.log/baseline-corrected.log. The corrected baseline-valid.log passed; no mutation result includes those setup failures.

The first artifact-audit draft compared registration.order pairs to joined IDs, an audit-script assumption error. It stopped without changing artifacts; artifact-audit.log is retained. The corrected independent audit passed. The initial hardlink witness patched global shutil.copytree and hit recursive argument mismatch; survivor-witnesses.log retains that harness error. Patching only the copied subject's shutil reference fixed the instrument; survivor-witnesses-v2.log contains the observed baseline/mutant contrasts.

Initial unittest temporary fixtures used their original default /tmp temporary locations and were automatically cleaned; all retained copies, mutations, logs, later explicit witness fixtures and report artifacts are beneath the review root. No original state or credentials were written/read respectively. No provider, CLI, Docker or transport process was launched by this review.

## Declined-to-judge and remaining gates

- Actual six-arm CLI delivery of full rules, effort settings, protocol delta and native tools: no synthetic wire run was performed.
- Container runtime behavior, executable tmpfs, live SQLite ownership/permissions, shared readonly exposure and cleanup under execution: no new native actor was started. Historical template qualification is reused only within its recorded identity.
- Prospective grading/parser policy, peer-reviewed committed grader and fresh empty/gold/repeat controls: still separate admission work. Closed historical NUlow replay was not repeated.
- Source-bound paid controller, full immutable plugin content binding/runtime loading, fresh resource monitoring and complete cohort budget/stop/cleanup enforcement: deferred to admission, not implied by config creation.
- Model effectiveness, generalization and complete workflow cost: no new model calls or outcomes exist.
- Whole-project gate: the isolated-worktree @bg_0000010e record was still running when inspected. The known MAIN companion fixture-scanner failure is issue 1dfa43ac9834a309. This report claims neither a green final full gate nor merge readiness.

The four findings were filed in MAIN docs/issues through doc, each with exactly one cluster/unclassified tag and literal duplicate checking. The parent reports closing them after the test-only fix; original review evidence and descriptions remain intact.

Ledger checked: 1134bec5140494f3, 426f23b3ae33383b, 98c33698d67d6a0b, 0493d56c581fee30; relevant known issues 1dfa43ac9834a309, 54fe4b112aa4e423, 0a2929ec2a4f688f, e6b99f20243e4fd0, 501a1f3b1384ceb5, d06194e58297a768.
