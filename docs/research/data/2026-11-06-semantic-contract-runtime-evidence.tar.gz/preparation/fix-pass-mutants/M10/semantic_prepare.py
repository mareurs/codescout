import hashlib
import json
import pathlib
import shutil

"""Zero-provider state preparation; paid launch admission stays controller-owned."""
def checked_snapshot(path, expected_digest):
    path=pathlib.Path(path)
    try:
        if path.is_symlink() or (path/"manifest.json").is_symlink():
            raise ValueError("snapshot symlink")
        raw=(path/"manifest.json").read_bytes()
        if hashlib.sha256(raw).hexdigest()!=expected_digest:
            raise ValueError("snapshot manifest digest")
        manifest=json.loads(raw)
        allowed={"knowledge","member-state","native-home","instructions"}
        for name,proof in manifest["files"].items():
            rel=pathlib.PurePosixPath(name)
            if rel.is_absolute() or ".." in rel.parts or not rel.parts or rel.parts[0] not in allowed:
                raise ValueError("snapshot payload path")
            file=path/name
            if not file.is_file() or file.is_symlink():
                raise ValueError("snapshot payload missing or symlink")
            data=file.read_bytes()
            if hashlib.sha256(data).hexdigest()!=proof["sha256"] or len(data)!=proof["bytes"]:
                raise ValueError("snapshot payload drift")
        actual=set()
        for item in path.rglob("*"):
            if item.is_symlink():
                raise ValueError("snapshot symlink")
            if item.is_file() and item!=path/"manifest.json":
                actual.add(item.relative_to(path).as_posix())
        if actual!=set(manifest["files"]):
            raise ValueError("snapshot payload population")
        return manifest
    except (OSError,KeyError,json.JSONDecodeError) as exc:
        raise ValueError("invalid snapshot: "+str(exc)) from exc

def clone_snapshot(source, destination, manifest):
    source,destination=pathlib.Path(source),pathlib.Path(destination)
    expected=hashlib.sha256((source/"manifest.json").read_bytes()).hexdigest()
    if checked_snapshot(source,expected)!=manifest:
        raise ValueError("snapshot changed after admission")
    destination.mkdir(parents=True,exist_ok=False)
    for name in ("knowledge","member-state","native-home","instructions"):
        shutil.copytree(source/name,destination/name)
    files={}
    for name,proof in manifest["files"].items():
        src,dst=source/name,destination/name
        if hashlib.sha256(dst.read_bytes()).hexdigest()!=proof["sha256"]:
            raise ValueError("clone payload drift")
        if dst.is_symlink() or (dst.stat().st_dev,dst.stat().st_ino)==(src.stat().st_dev,src.stat().st_ino):
            raise ValueError("clone shares writable file")
        files[name]=proof
    return {"files":files,"separate_physical_files":True}

def rewrite_native(argv, state, projects, name):
    state=pathlib.Path(state)
    mapped={"/bench-home":state/"native-home","/testbed/.codescout":state/"knowledge"}
    for project in projects:
        root=pathlib.PurePosixPath(project["root"])
        ident=project["id"]
        if not ident or ident in (".","..") or "/" in ident or root.is_absolute() or ".." in root.parts:
            raise ValueError("invalid member state path")
        if project["root"]!=".":
            dst="/testbed/"+root.as_posix()+"/.codescout"
            if dst in mapped:raise ValueError("duplicate project destination")
            mapped[dst]=state/"member-state"/ident
    result=list(argv)
    if result[:2]!=["docker","run"]:raise ValueError("native command")
    seen=set();writable=set()
    for index in range(2,len(result)-4):
        if result[index]!="--mount":continue
        raw=result[index+1]
        parts=raw.split(",")
        fields={}
        for part in parts:
            key,_,value=part.partition("=")
            if key in fields:raise ValueError("duplicate mount field")
            fields[key]=value
        if fields.get("type")!="bind" or set(fields)-{"type","src","dst","readonly"}:
            raise ValueError("unsupported native mount")
        dst=fields.get("dst")
        if not dst or dst in seen:raise ValueError("duplicate or missing mount destination")
        seen.add(dst)
        readonly="readonly" in fields
        if dst in mapped:
            if readonly:raise ValueError("state mount is readonly")
            writable.add(dst)
            result[index+1]="type=bind,src="+str(mapped[dst])+",dst="+dst
        elif not readonly:
            raise ValueError("unknown writable native mount")
    if writable!=set(mapped):raise ValueError("missing writable native mount")
    for option,value in (("--name",name),("--label","codescout.semantic-contract="+name)):
        if result.count(option)!=1:raise ValueError("native identity option")
        result[result.index(option)+1]=value
    return result
def prepare(bundle, output, actors, qualification):
    import importlib.util
    from decimal import Decimal
    import external
    bundle,output,actors,qualification=map(pathlib.Path,(bundle,output,actors,qualification))
    actors=actors.resolve()
    if pathlib.Path("/tmp") not in actors.parents:
        raise ValueError("actor contexts must avoid host-home ancestry")
    verifier=bundle/"freeze-prompts.py"
    if hashlib.sha256(verifier.read_bytes()).hexdigest()!="ed53f792e54866c1bf5053a813a417ed7c4328a2f4622887e30c4f37b7d50780":
        raise ValueError("unreviewed input verifier")
    spec=importlib.util.spec_from_file_location("semantic_frozen_inputs",verifier)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);mod.ROOT=bundle
    registration=json.loads((bundle/"prompt-inputs-registration.json").read_text())
    rows=json.loads((bundle/"matrix.json").read_text())["arms"]
    mod.verify(registration,rows)
    if registration["budget"]["reserve_usd_each"]!="20" or registration["budget"]["cli_cap_usd_each"]!="19":
        raise ValueError("pilot budget changed")
    snapshots={};templates={}
    for task,project in registration["projects"].items():
        path=pathlib.Path(project["runtime_snapshot_manifest"]).parent
        manifest=checked_snapshot(path,project["runtime_snapshot_manifest_sha256"])
        if (manifest["image"],manifest["actor_baseline"],manifest["snapshot_id"])!=(project["image"],project["baseline_commit"],project["runtime_snapshot_id"]):
            raise ValueError("snapshot identity")
        for name in ("CLAUDE.md","AGENTS.md"):
            if (path/"instructions"/name).read_bytes()!=(bundle/"shared"/task/name).read_bytes():
                raise ValueError("snapshot instruction drift")
        snapshots[task]=(path,manifest)
        templates[task]=json.loads((qualification/task/"native-argv.json").read_text())
        if templates[task][-4:]!=[project["image"],"start","--project","/testbed"]:
            raise ValueError("qualified template source identity")
        if hashlib.sha256(pathlib.Path(project["cli"]).read_bytes()).hexdigest()!=project["cli_sha256"]:
            raise ValueError("CLI input drift")
    for row in rows:
        if json.loads((bundle/"arms"/row["arm_id"]/"inputs.json").read_text())!=row:
            raise ValueError("per-arm input differs from frozen matrix")
    if output.exists() or actors.exists():
        raise ValueError("preparation destination already exists")
    output.mkdir(parents=True);actors.mkdir(parents=True)
    def save(path,value):
        path.write_text(json.dumps(value,indent=2)+"\n")
    result={"stage":"native-configs-only","launch_admitted":False,"provider_calls":0,"arms":[]}
    save(output/"preparation-started.json",result)
    for index,row in enumerate(rows):
        task=row["task"];project=registration["projects"][task]
        source,manifest=snapshots[task]
        out=output/"arms"/row["arm_id"]
        clones=clone_snapshot(source,out,manifest)
        actor=actors/str(index);actor.mkdir()
        backup=out/"actor-context";backup.mkdir()
        for name in ("CLAUDE.md","AGENTS.md"):
            data=(bundle/"shared"/task/name).read_bytes()
            (actor/name).write_bytes(data);(backup/name).write_bytes(data)
        global_rules=out/"global-CLAUDE.md"
        global_rules.write_bytes((bundle/"shared"/task/"global-CLAUDE.md").read_bytes())
        name="cs-semantic-contract-01a15ca9-"+str(index)
        native=rewrite_native(templates[task],out,manifest["projects"],name)
        save(out/"mcp-native-argv.json",native)
        cfg={"image":row["image"],"baseline_commit":row["baseline_commit"],"actor":str(actor),
             "cli":project["cli"],"plugin":project["plugin"],"global_rules":str(global_rules),
             "prompt":pathlib.Path(row["prompt"]).read_bytes().decode("utf-8"),"checks":row["public_checks"],
             "timeout_s":3600,"check_timeout_s":1800,"max_continuations":8}
        cfg["files"]={str(p):hashlib.sha256(p.read_bytes()).hexdigest()
                      for p in (out/"mcp-native-argv.json",global_rules,pathlib.Path(project["cli"]),actor/"CLAUDE.md",actor/"AGENTS.md")}
        save(out/"prepared.json",cfg)
        external.validate_prepared(out,"low",Decimal("20"),Decimal("19"))
        save(out/"input-clone-manifest.json",clones)
        result["arms"].append({"arm_id":row["arm_id"],"task":task,"variant":row["variant"],
                              "effort":row["effort"],"out":str(out),
                              "prepared_sha256":hashlib.sha256((out/"prepared.json").read_bytes()).hexdigest(),
                              "clone_manifest_sha256":hashlib.sha256((out/"input-clone-manifest.json").read_bytes()).hexdigest()})
    save(output/"prepared-manifests.json",result)
    return result
