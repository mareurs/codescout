"""Close and archive small preparation evidence, excluding all writable stores/model payloads."""
import datetime
import hashlib
import io
import json
import pathlib
import sys
import tarfile

MAIN=pathlib.Path("/home/marius/work/claude/codescout")
BASE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
ROOT=BASE/"semantic-contract-runtime-20261106"
SOURCE=MAIN/".worktrees/semantic-contract-runtime-01a15ca9"
REVIEW=pathlib.Path("/tmp/semantic-contract-runtime-review-20261106")
OUT=MAIN/"docs/research/data/2026-11-06-semantic-contract-runtime-evidence.tar.gz"
RECEIPT=OUT.with_name("2026-11-06-semantic-contract-runtime-evidence.json")
def sha(data):return hashlib.sha256(data).hexdigest()
def main():
    if OUT.exists() or RECEIPT.exists():raise ValueError("refuse overwrite")
    jobs=[pathlib.Path("/tmp/codescout-bg/455879-a720241d-bg_"+key+".json") for key in ("0000010d","0000010e","0000010f","00000110")]
    for path in jobs:
        job=json.loads(path.read_text())
        if job["state"]!="exited":raise ValueError("unfinished job "+str(path))
        if job["exit_code"]!=0:raise ValueError("failed job requires explicit closure "+str(path))
    registration=json.loads((ROOT/"runtime-registration.json").read_text())
    reg=json.loads((BASE/"semantic-contract-pilot-20261106/prompt-inputs-registration.json").read_text())
    original=json.loads((ROOT/"prepared/prepared-manifests.json").read_text())
    for path,d in registration["input_hashes"].items():
        if sha(pathlib.Path(path).read_bytes())!=d:raise ValueError("frozen input drift")
    for path,d in registration["source_hashes"].items():
        if sha((ROOT/"source-v1"/pathlib.Path(path).name).read_bytes())!=d:raise ValueError("executed source backup drift")
    source_inodes=set();seen=set();count=0
    for task,p in reg["projects"].items():
        src=pathlib.Path(p["runtime_snapshot_manifest"]).parent
        m=json.loads((src/"manifest.json").read_text())
        for rel in m["files"]:
            s=(src/rel).stat();source_inodes.add((s.st_dev,s.st_ino))
    sys.path.insert(0,str(SOURCE/"tools/agent_lifecycle"))
    import external
    for row in original["arms"]:
        out=pathlib.Path(row["out"]);cfg,_,actor,_,_=external.validate_prepared(out,row["effort"],"20","19")
        if (out/"started.json").exists() or (out/"launch.json").exists():raise ValueError("unexpected actor launch")
        if sha((out/"prepared.json").read_bytes())!=row["prepared_sha256"]:raise ValueError("prepared drift")
        m=json.loads((out/"input-clone-manifest.json").read_text())
        for rel,proof in m["files"].items():
            path=out/rel;s=path.stat();key=(s.st_dev,s.st_ino)
            if key in source_inodes or key in seen or path.is_symlink():raise ValueError("state sharing")
            if sha(path.read_bytes())!=proof["sha256"]:raise ValueError("clone drift")
            seen.add(key);count+=1
        for name in ("CLAUDE.md","AGENTS.md"):
            if (actor/name).read_bytes()!=(out/"actor-context"/name).read_bytes():raise ValueError("actor backup drift")
    fixes=json.loads((ROOT/"fix-pass-mutation-results.json").read_text())
    if fixes["mutation_population"]!=12 or fixes["survived"]!=0:raise ValueError("review mutations unresolved")
    closure={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"arms":len(original["arms"]),
             "clone_payload_files_rehashed":count,"source_inode_population":len(source_inodes),
             "all_devices_and_inodes_disjoint":True,"all_native_configs_revalidated":True,
             "frozen_inputs_and_executed_source_backups_unchanged":True,
             "launch_admitted":False,"actual_cli_wire_proof":False,"provider_calls":0}
    (ROOT/"archive-closure-checks.json").write_text(json.dumps(closure,indent=2)+"\n")
    payload={}
    def add(name,path):
        if name in payload:raise ValueError("duplicate archive name")
        if path.is_symlink() or not path.is_file():raise ValueError("nonregular archive payload")
        payload[name]=(str(path),path.read_bytes())
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or "__pycache__" in path.parts:continue
        rel=path.relative_to(ROOT)
        if rel.parts[0]=="prepared" and "arms" in rel.parts:
            if len(rel.parts)>=4 and rel.parts[3] in {"knowledge","member-state","native-home","instructions"}:continue
        add("preparation/"+rel.as_posix(),path)
    for path in sorted(REVIEW.rglob("*")):
        if path.is_file() and "__pycache__" not in path.parts and path.suffix in {".py",".json",".jsonl",".log",".md",".txt",".patch"}:
            add("review/"+path.relative_to(REVIEW).as_posix(),path)
    for name in ("semantic_prepare.py","test_semantic_prepare.py"):
        add("source-current/"+name,SOURCE/"tools/agent_lifecycle"/name)
    for path in jobs+[pathlib.Path("/tmp/codescout-bg/455879-a720241d-bg_00000109.json")]:
        add("jobs/"+path.name,path)
        record=json.loads(path.read_text());log=pathlib.Path(record["log_path"])
        add("jobs/"+record["handle"].lstrip("@")+"-"+log.name,log)
    add("plan.md",MAIN/"docs/superpowers/plans/2026-11-06-semantic-contract-runtime.md")
    manifest={"utc":closure["utc"],"scope":"Closed native-config-only preparation and actual mutation review. Excludes writable database/native-state/model-cache payloads and credentials; no CLI actor/model launch admitted.",
              "files":[{"name":n,"source":p,"bytes":len(d),"sha256":sha(d)} for n,(p,d) in sorted(payload.items())]}
    with tarfile.open(OUT,"w:gz") as tar:
        for name,(path,data) in sorted(payload.items()):
            info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
        data=(json.dumps(manifest,indent=2)+"\n").encode();info=tarfile.TarInfo("MANIFEST.json");info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
    with tarfile.open(OUT) as tar:
        m=json.load(tar.extractfile("MANIFEST.json"))
        if len(tar.getmembers())!=len(payload)+1:raise ValueError("archive population")
        for item in m["files"]:
            data=tar.extractfile(item["name"]).read()
            if sha(data)!=item["sha256"] or len(data)!=item["bytes"]:raise ValueError("archive hash")
    result={"archive":str(OUT),"sha256":sha(OUT.read_bytes()),"bytes":OUT.stat().st_size,
            "payload_files":len(payload),"manifest_files":1,"all_payloads_reopened_and_hash_verified":True,"closure":closure}
    RECEIPT.write_text(json.dumps(result,indent=2)+"\n");print(json.dumps(result,indent=2))
if __name__=="__main__":main()
