"""Rehash the historically bound readonly native inputs without launching an actor."""
import hashlib
import json
import pathlib
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/semantic-contract-runtime-20261106")
BASE=ROOT.parent
oldpath=BASE/"external-matched-repairs-20261105/native-readonly-inputs.json"
def sha(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1048576),b""):h.update(chunk)
    return h.hexdigest()
def main():
    prior=json.loads(oldpath.read_text())
    summary={"prior_readonly_manifest_sha256":sha(oldpath),"checked":[],"all_match":True}
    matrix=json.loads((ROOT/"prepared/prepared-manifests.json").read_text())
    for arm in matrix["arms"]:
        args=json.loads((pathlib.Path(arm["out"])/"mcp-native-argv.json").read_text())
        observed={}
        for i,value in enumerate(args):
            if value=="--mount" and "readonly" in args[i+1].split(","):
                fields=dict(p.split("=",1) for p in args[i+1].split(",") if "=" in p)
                dest=fields["dst"];src=pathlib.Path(fields["src"])
                if dest not in prior:raise ValueError("unbound readonly destination")
                actual={p.relative_to(src).as_posix() for p in src.rglob("*") if p.is_file() or p.is_symlink()}
                if actual!=set(prior[dest]):raise ValueError("readonly file population drift "+dest)
                for name,proof in prior[dest].items():
                    path=src/name
                    if "link" in proof:
                        if not path.is_symlink() or str(path.readlink())!=proof["link"] or sha(path)!=proof["resolved_sha256"]:
                            raise ValueError("readonly symlink drift "+str(path))
                    elif path.is_symlink() or sha(path)!=proof["sha256"]:
                        raise ValueError("readonly bytes drift "+str(path))
                observed[dest]={"source":str(src),"files":len(prior[dest])}
        if set(observed)!=set(prior):raise ValueError("readonly mount population drift")
        summary["checked"].append({"arm_id":arm["arm_id"],"readonly":observed})
    (ROOT/"readonly-inputs-verification.json").write_text(json.dumps(summary,indent=2)+"\n")
    print(json.dumps({"arms":len(summary["checked"]),"readonly_records_per_arm":sum(len(v) for v in prior.values()),"all_match":True}))
if __name__=="__main__":main()
