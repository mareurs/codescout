"""Reapply reviewer's exact twelve mutations on copies against the expanded suite."""
import hashlib
import json
import os
import pathlib
import subprocess
import sys

ROOT=pathlib.Path(__file__).resolve().parent
SOURCE=pathlib.Path("/home/marius/work/claude/codescout/.worktrees/semantic-contract-runtime-01a15ca9/tools/agent_lifecycle")
REVIEW=pathlib.Path("/tmp/semantic-contract-runtime-review-20261106")

def main():
    output=ROOT/"fix-pass-mutants";output.mkdir()
    production=(SOURCE/"semantic_prepare.py").read_text()
    tests=(SOURCE/"test_semantic_prepare.py").read_bytes()
    mutations=json.loads((REVIEW/"mutations.json").read_text())
    results=[]
    for mutation in mutations:
        key=mutation["id"];directory=output/key;directory.mkdir()
        assert production.count(mutation["old"])==1,key
        changed=production.replace(mutation["old"],mutation["new"],1)
        (directory/"semantic_prepare.py").write_text(changed)
        (directory/"test_semantic_prepare.py").write_bytes(tests)
        env=dict(os.environ);env["PYTHONPATH"]=str(SOURCE)+os.pathsep+str(SOURCE.parent/"hint_authority_pilot")
        command=[sys.executable,"-B","-m","unittest","test_semantic_prepare","-v"]
        result=subprocess.run(command,cwd=directory,env=env,capture_output=True,text=True,timeout=45)
        (directory/"stdout.log").write_text(result.stdout)
        (directory/"stderr.log").write_text(result.stderr)
        if "Ran 13 tests" not in result.stderr:raise RuntimeError("test population not executed "+key)
        observed="survived" if result.returncode==0 else "killed"
        results.append({"id":key,"observed":observed,"returncode":result.returncode,
                        "production_sha256":hashlib.sha256(changed.encode()).hexdigest(),"purpose":mutation["purpose"]})
        print(json.dumps(results[-1]),flush=True)
    result={"mutation_population":len(results),"killed":sum(r["observed"]=="killed" for r in results),
            "survived":sum(r["observed"]=="survived" for r in results),"results":results,
            "test_sha256":hashlib.sha256(tests).hexdigest(),
            "original_production_unchanged":(SOURCE/"semantic_prepare.py").read_text()==production}
    (ROOT/"fix-pass-mutation-results.json").write_text(json.dumps(result,indent=2)+"\n")
    if result["survived"]:raise RuntimeError("surviving mutations")
    print(json.dumps(result,indent=2))

if __name__=="__main__":main()
