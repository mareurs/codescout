"""Controls exercise real files/mount rewriting; no model, Docker or credential access."""
import copy
import hashlib
import json
import pathlib
import tempfile
import unittest
import semantic_prepare as subject

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def snapshot(root):
    files={"knowledge/store.db":b"root database","member-state/member/store.db":b"member database",
           "native-home/state.txt":b"native state","instructions/CLAUDE.md":b"project rules",
           "instructions/AGENTS.md":b"project rules"}
    for name,data in files.items():
        path=root/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
    manifest={"files":{name:{"sha256":hashlib.sha256(data).hexdigest(),"bytes":len(data)} for name,data in files.items()},
              "projects":[{"id":"testbed","root":"."},{"id":"member","root":"crates/member"}],
              "image":"sha256:"+"1"*64,"actor_baseline":"2"*40,"snapshot_id":"runtime","logical_snapshot_id":"logical"}
    (root/"manifest.json").write_text(json.dumps(manifest))
    return manifest

def argv():
    return ["docker","run","--init","--cpus","4","--memory","32g","--tmpfs",
            "/tmp:rw,exec,size=4g,uid=1000,gid=1000","--pull=never","-i","--network","none",
            "--user","1000:1000","--pids-limit","4096","--name","old-name","--label","old=old-name",
            "--mount","type=bind,src=/old/bin,dst=/bench/bin,readonly",
            "--mount","type=bind,src=/old/model,dst=/bench-home/.cache/codescout/fastembed,readonly",
            "--mount","type=bind,src=/old/home,dst=/bench-home",
            "--mount","type=bind,src=/old/root,dst=/testbed/.codescout",
            "--mount","type=bind,src=/old/member,dst=/testbed/crates/member/.codescout",
            "sha256:"+"1"*64,"start","--project","/testbed"]

class SnapshotTests(unittest.TestCase):
    def test_copies_are_byte_identical_and_actual_write_is_isolated(self):
        with tempfile.TemporaryDirectory() as raw:
            root=pathlib.Path(raw);src=root/"src";src.mkdir();m=snapshot(src)
            a,b=root/"a",root/"b"
            subject.clone_snapshot(src,a,m);subject.clone_snapshot(src,b,m)
            for name in m["files"]:
                self.assertEqual((a/name).read_bytes(),(src/name).read_bytes())
                self.assertEqual(len({(p/name).stat().st_ino for p in (src,a,b)}),3)
            (a/"knowledge/store.db").write_bytes(b"changed")
            self.assertEqual((src/"knowledge/store.db").read_bytes(),b"root database")
            self.assertEqual((b/"knowledge/store.db").read_bytes(),b"root database")
    def test_bad_source_rejects_before_destination_exists(self):
        for kind in ("corrupt","missing","extra","symlink","traversal"):
            with self.subTest(kind=kind),tempfile.TemporaryDirectory() as raw:
                root=pathlib.Path(raw);src=root/"src";src.mkdir();m=snapshot(src)
                file=src/"knowledge/store.db"
                if kind=="corrupt":file.write_bytes(b"bad")
                elif kind=="missing":file.unlink()
                elif kind=="extra":(src/"knowledge/unlisted.db").write_bytes(b"extra")
                elif kind=="symlink":
                    file.unlink();file.symlink_to(src/"native-home/state.txt")
                else:
                    m["files"]["../escaped"]={"sha256":"0"*64,"bytes":0}
                    (src/"manifest.json").write_text(json.dumps(m))
                with self.assertRaises(ValueError):
                    subject.clone_snapshot(src,root/"output",m)
                self.assertFalse((root/"output").exists())
    def test_manifest_digest_is_checked(self):
        with tempfile.TemporaryDirectory() as raw:
            root=pathlib.Path(raw);m=snapshot(root)
            self.assertEqual(subject.checked_snapshot(root,digest(root/"manifest.json")),m)
            with self.assertRaises(ValueError):
                subject.checked_snapshot(root,"0"*64)
    def test_existing_output_is_never_overwritten(self):
        with tempfile.TemporaryDirectory() as raw:
            root=pathlib.Path(raw);src=root/"src";src.mkdir();m=snapshot(src)
            out=root/"out";out.mkdir();(out/"keep").write_bytes(b"keep")
            with self.assertRaises((ValueError,FileExistsError)):
                subject.clone_snapshot(src,out,m)
            self.assertEqual((out/"keep").read_bytes(),b"keep")

class MountTests(unittest.TestCase):
    projects=[{"id":"testbed","root":"."},{"id":"member","root":"crates/member"}]
    def test_all_writable_destinations_remap_and_readonly_inputs_stay_exact(self):
        native=argv();result=subject.rewrite_native(native,pathlib.Path("/new/state"),self.projects,"new-name")
        self.assertEqual(native,argv())
        self.assertIn("type=bind,src=/old/bin,dst=/bench/bin,readonly",result)
        self.assertIn("type=bind,src=/old/model,dst=/bench-home/.cache/codescout/fastembed,readonly",result)
        for source,destination in (("/new/state/native-home","/bench-home"),
            ("/new/state/knowledge","/testbed/.codescout"),
            ("/new/state/member-state/member","/testbed/crates/member/.codescout")):
            self.assertIn("type=bind,src="+source+",dst="+destination,result)
        self.assertEqual(result[result.index("--name")+1],"new-name")
        self.assertEqual(result[result.index("--label")+1],"codescout.semantic-contract=new-name")
        self.assertEqual(result[-4:],["sha256:"+"1"*64,"start","--project","/testbed"])
    def test_missing_unknown_duplicate_or_readonly_state_mount_rejects(self):
        for kind in ("missing","unknown","duplicate","readonly"):
            with self.subTest(kind=kind):
                native=argv()
                mount="type=bind,src=/old/member,dst=/testbed/crates/member/.codescout"
                if kind=="missing":
                    idx=native.index(mount);del native[idx-1:idx+1]
                elif kind=="unknown":native[-4:-4]=["--mount","type=bind,src=/foreign,dst=/foreign"]
                elif kind=="duplicate":native[-4:-4]=["--mount",mount]
                else:native[native.index(mount)]=mount+",readonly"
                with self.assertRaises(ValueError):
                    subject.rewrite_native(native,pathlib.Path("/new/state"),self.projects,"new-name")
    def test_member_id_and_root_cannot_escape_state_or_project(self):
        for item in ({"id":"../escape","root":"crates/member"},{"id":"member","root":"../../escape"}):
            with self.subTest(item=item),self.assertRaises(ValueError):
                subject.rewrite_native(argv(),pathlib.Path("/new/state"),[self.projects[0],item],"new-name")
class PreparationTests(unittest.TestCase):
    def bundle(self,root):
        original=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/semantic-contract-pilot-20261106")
        bundle=root/"bundle";bundle.mkdir()
        for name in ("freeze-prompts.py","protocol.txt","matrix.json","prompt-inputs-registration.json"):
            (bundle/name).write_bytes((original/name).read_bytes())
        import shutil
        shutil.copytree(original/"shared",bundle/"shared")
        shutil.copytree(original/"arms",bundle/"arms")
        reg=json.loads((bundle/"prompt-inputs-registration.json").read_text())
        rows=json.loads((bundle/"matrix.json").read_text())["arms"]
        qualification=root/"qualification";qualification.mkdir()
        for task,project in reg["projects"].items():
            src=root/"snapshots"/task;src.mkdir(parents=True)
            m=snapshot(src);m.update(image=project["image"],actor_baseline=project["baseline_commit"],
                                    snapshot_id=project["runtime_snapshot_id"])
            for name in ("CLAUDE.md","AGENTS.md"):
                data=(bundle/"shared"/task/name).read_bytes()
                file=src/"instructions"/name;file.write_bytes(data)
                m["files"]["instructions/"+name]={"sha256":digest(file),"bytes":len(data)}
            (src/"manifest.json").write_text(json.dumps(m))
            project["runtime_snapshot_manifest"]=str(src/"manifest.json")
            project["runtime_snapshot_manifest_sha256"]=digest(src/"manifest.json")
            q=qualification/task;q.mkdir()
            native=argv();native[-4]=project["image"]
            (q/"native-argv.json").write_text(json.dumps(native))
        for row in rows:
            row["prompt"]=str(bundle/"arms"/row["arm_id"]/"prompt.txt")
            (bundle/"arms"/row["arm_id"]/"inputs.json").write_text(json.dumps(row))
        (bundle/"prompt-inputs-registration.json").write_text(json.dumps(reg))
        (bundle/"matrix.json").write_text(json.dumps({"arms":rows}))
        return bundle,qualification,rows

    def test_six_prepared_variants_retain_context_and_actual_effort(self):
        with tempfile.TemporaryDirectory() as raw:
            root=pathlib.Path(raw);bundle,qualification,rows=self.bundle(root)
            result=subject.prepare(bundle,root/"output",root/"actors",qualification)
            self.assertEqual(len(result["arms"]),6)
            self.assertFalse(result["launch_admitted"])
            self.assertEqual([x["effort"] for x in result["arms"]],["low","xhigh","low","low","xhigh","low"])
            self.assertEqual([x["arm_id"] for x in result["arms"]],[x["arm_id"] for x in rows])
            inodes=set()
            for row,entry in zip(rows,result["arms"]):
                out=pathlib.Path(entry["out"])
                cfg=json.loads((out/"prepared.json").read_text())
                self.assertEqual(cfg["prompt"].encode(),pathlib.Path(row["prompt"]).read_bytes())
                self.assertEqual(cfg["checks"],row["public_checks"])
                self.assertEqual((cfg["timeout_s"],cfg["check_timeout_s"],cfg["max_continuations"]),(3600,1800,8))
                self.assertEqual(pathlib.Path(cfg["global_rules"]).read_bytes(),
                                 (bundle/"shared"/row["task"]/"global-CLAUDE.md").read_bytes())
                self.assertEqual((pathlib.Path(cfg["actor"])/"CLAUDE.md").read_bytes(),
                                 (bundle/"shared"/row["task"]/"CLAUDE.md").read_bytes())
                self.assertFalse((out/"started.json").exists())
                self.assertFalse((out/"launch.json").exists())
                file=out/"knowledge/store.db";key=(file.stat().st_dev,file.stat().st_ino)
                self.assertNotIn(key,inodes);inodes.add(key)
    def test_wrong_effort_rejects_before_any_output_or_actor(self):
        with tempfile.TemporaryDirectory() as raw:
            root=pathlib.Path(raw);bundle,qualification,rows=self.bundle(root)
            rows[0]["effort"]="low-contract"
            (bundle/"matrix.json").write_text(json.dumps({"arms":rows}))
            with self.assertRaises(ValueError):
                subject.prepare(bundle,root/"output",root/"actors",qualification)
            self.assertFalse((root/"output").exists())
            self.assertFalse((root/"actors").exists())
    def test_actor_home_ancestry_rejects_without_output(self):
        with tempfile.TemporaryDirectory() as raw:
            root=pathlib.Path(raw);bundle,qualification,rows=self.bundle(root)
            with self.assertRaises(ValueError):
                subject.prepare(bundle,root/"output",pathlib.Path("/home/marius/forbidden"),qualification)
            self.assertFalse((root/"output").exists())

if __name__=="__main__":unittest.main()
