# SDD ledger — plan: docs/superpowers/plans/2026-11-06-semantic-contract-runtime.md

Source worktree /home/marius/work/claude/codescout/.worktrees/semantic-contract-runtime-01a15ca9, base36fec1201b0f809d6f21cc31082def4d651b6cf8. No commit/merge/push.

Pre-flight: Task1 prepare consumes fixed prompt registration/matrix and qualified native template bytes, Task2 emits six prepared configs consumed by future CLI wire/controller; both use actual effort independently from arm ID. Grader APIs remain unresolved and outside this plan.

Task1: source-copy/mount negative tests written first. Initial module-missing import error retained in tool record; stub/no-op behavioral run unit-red.log observed12 assertion failures. Implemented checked_snapshot/clone_snapshot/rewrite_native; seven tests GREEN. PreparationTests then failed because prepare absent; implementation made ten tests GREEN. Whole lifecycle suite86 tests passed in11.939s (lifecycle-suite.log). Sources unchanged since real preparation began; fresh review /root/semantic_runtime_review pending, with actual applied mutations required.

Task2: @bg_0000010d CLOSEDexit0. Real one-shot prepare-runtime.py validates qualified template/source hashes against preserved baseline archive and source registration, all frozen input bytes and old protected24 files. Six physical runtime copies created,5850 payload files; all hashes/inodes distinct from pristine source and every sibling. Root free325425840128bytes, tmp free27217494016bytes after preparation. All old protected/frozen/source hashes unchanged. No Docker/CLI/provider/credential/onboarding operation. launch_admitted=false, actual_cli_wire_proof=false. No rerun permitted into this destination.

Ruling: continue zero-provider preparation despite unrelated MAIN gate1dfa43ac9834a309 (companion negative .test.mjs scanner); existing immutable lifecycle baseline13tests and later86tests pass. No paid admission follows from those checks. Cost if wrong: prepared states discarded after a relevant identity change.

Ruling: tests are research-local and deliberately consume the reviewed frozen input-bundle version. No hermetic CI/product portability or reusable production library claim; source/helper/test bytes will be archived. This continuation implements an already authorized design, with no repeated method-approval question.

Task3: report/memory/archive closure pending independent review and final evidence checks. Remaining gates: peer's reviewed committed grader, prospective parser policy plus negative/gold/repeat controls, actual six-arm synthetic CLI wire proof, new source-bound paid controller/admission. Generic mechanism still unmeasured.
