"""One-shot zero-provider preparation. No Docker/CLI/provider launch."""
import datetime
import hashlib
import json
import pathlib
import shutil
import sys
import tarfile

MAIN=pathlib.Path("/home/marius/work/claude/codescout")
SOURCE=MAIN/".worktrees/semantic-contract-runtime-01a15ca9"
BASE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
ROOT=BASE/"semantic-contract-runtime-20261106"
BUNDLE=BASE/"semantic-contract-pilot-20261106"
QUAL=BASE/"external-exec-baseline-20261106-v3"
OUTPUT=ROOT/"prepared"
ACTORS=pathlib.Path("/tmp/cs-semantic-contract-01a15ca9-20261106")
sys.path.insert(0,str(SOURCE/"tools/agent_lifecycle"))
import semantic_prepare

def sha(path):
    h=hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for data in iter(lambda:f.read(1048576),b""):h.update(data)
    return h.hexdigest()

def save(path,data):path.write_text(json.dumps(data,indent=2)+"\n")

def main():
    if (ROOT/"runtime-registration.json").exists() or OUTPUT.exists() or ACTORS.exists():
        raise ValueError("one-shot destination already exists")
    if shutil.disk_usage(ROOT).free<80*1024**3:raise ValueError("insufficient root headroom")
    reg=json.loads((BUNDLE/"prompt-inputs-registration.json").read_text())
    archive=MAIN/"docs/research/data/2026-11-06-executable-native-baseline-evidence.tar.gz"
    if sha(archive)!="a6f224468b952c814988dc784f1bf036d02ad71aea1ba22ab3408b0bfc405f38":
        raise ValueError("baseline archive drift")
    with tarfile.open(archive) as tar:
        old=json.load(tar.extractfile("MANIFEST.json"))
    qualified={item["source"]:item["sha256"] for item in old["files"]}
    qualification_files=[QUAL/"verified-closure.json",QUAL/"registration.json"]
    for task in reg["projects"]:
        qualification_files.append(QUAL/task/"native-argv.json")
    for path in qualification_files:
        if qualified[str(path)]!=sha(path):raise ValueError("qualified baseline file drift "+str(path))
    for path,d in json.loads((QUAL/"registration.json").read_text())["source_hashes"].items():
        if sha(SOURCE/"tools/agent_lifecycle"/path)!=d:raise ValueError("qualified lifecycle source changed")
    input_paths=[BUNDLE/"prompt-inputs-registration.json",BUNDLE/"matrix.json",BUNDLE/"protocol.txt",BUNDLE/"freeze-prompts.py"]
    for path in (BUNDLE/"shared").rglob("*"):
        if path.is_file():input_paths.append(path)
    for path in (BUNDLE/"arms").rglob("*"):
        if path.is_file():input_paths.append(path)
    for p,d in reg["protected_original_hashes"].items():
        if sha(p)!=d:raise ValueError("protected old artifact drift")
    for task in reg["projects"]:
        argv=json.loads((QUAL/task/"native-argv.json").read_text())
        for index,value in enumerate(argv):
            if value=="--mount":
                fields=dict(p.split("=",1) for p in argv[index+1].split(",") if "=" in p)
                if not pathlib.Path(fields["src"]).is_dir():raise ValueError("missing native mount source")
    registration={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  "stage":"native-configs-only","launch_admitted":False,
                  "source_worktree":str(SOURCE),"base_commit":"36fec1201b0f809d6f21cc31082def4d651b6cf8",
                  "input_hashes":{str(p):sha(p) for p in input_paths},
                  "qualification_hashes":{str(p):sha(p) for p in qualification_files},
                  "source_hashes":{str(p):sha(p) for p in sorted((SOURCE/"tools/agent_lifecycle").glob("*.py"))},
                  "helper_sha256":sha(__file__),"root_free_before":shutil.disk_usage(ROOT).free,
                  "tmp_free_before":shutil.disk_usage("/tmp").free,
                  "known_prior_usd":reg["budget"]["known_prior_usd"],"provider_calls":0,"credential_reads":0}
    save(ROOT/"runtime-registration.json",registration)
    result=semantic_prepare.prepare(BUNDLE,OUTPUT,ACTORS,QUAL)
    seen=set();payloads=0
    for entry in result["arms"]:
        out=pathlib.Path(entry["out"]);task=entry["task"]
        project=reg["projects"][task];snap=pathlib.Path(project["runtime_snapshot_manifest"]).parent
        manifest=json.loads((snap/"manifest.json").read_text())
        for name,proof in manifest["files"].items():
            path=out/name;stat=path.stat();source=(snap/name).stat()
            key=(stat.st_dev,stat.st_ino)
            if key in seen or key==(source.st_dev,source.st_ino):raise ValueError("physical state shared")
            if path.is_symlink() or sha(path)!=proof["sha256"]:raise ValueError("prepared payload drift")
            seen.add(key);payloads+=1
        if (out/"started.json").exists() or (out/"launch.json").exists():raise ValueError("unexpected launch")
    for path,d in registration["input_hashes"].items():
        if sha(path)!=d:raise ValueError("frozen input changed during copying")
    for p,d in reg["protected_original_hashes"].items():
        if sha(p)!=d:raise ValueError("old artifact changed during copying")
    for path,d in registration["source_hashes"].items():
        if sha(path)!=d:raise ValueError("source changed during copying")
    closure={"arms":len(result["arms"]),"physical_payload_files":payloads,
             "source_and_sibling_inodes_distinct":True,"all_payload_hashes_verified":True,
             "frozen_input_and_old_artifact_hashes_unchanged":True,
             "root_free_after":shutil.disk_usage(ROOT).free,"tmp_free_after":shutil.disk_usage("/tmp").free,
             "provider_calls":0,"credential_reads":0,"onboarding_calls":0,
             "launch_admitted":False,"actual_cli_wire_proof":False}
    save(ROOT/"runtime-preparation-result.json",closure)
    print(json.dumps(closure,indent=2))

if __name__=="__main__":main()
