"""One new prospective full-plugin identity smoke. No paid or real repair action."""
import datetime
import hashlib
import importlib.util
import json
import pathlib
import shutil
import subprocess
import sys
import time
from decimal import Decimal
import tree_identity

BASE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
ROOT=BASE/"semantic-contract-plugin-binding-20261106"
WIRE=BASE/"semantic-contract-wire-20261106"
SOURCE=pathlib.Path("/home/marius/work/claude/codescout/.worktrees/semantic-contract-runtime-01a15ca9")
ACTOR=pathlib.Path("/tmp/cs-semantic-plugin-01a15ca9-20261106/0")
def sha(path):return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
def save(path,data):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(data,indent=2)+"\n")
def load(path):return json.loads(path.read_text())
def checked_hashes(hashes):
    for path,expected in hashes.items():
        if sha(path)!=expected:raise ValueError("Protected input drift "+path)
def no_provider(*args,**kwargs):raise AssertionError("Provider forwarding forbidden")

def main():
    if (ROOT/"registration.json").exists() or (ROOT/"arm").exists() or ACTOR.exists():
        raise ValueError("Refuse one-shot overwrite")
    binding=importlib.util.spec_from_file_location("closed_wire_verifier",WIRE/"control-v3-offline.py")
    wire=importlib.util.module_from_spec(binding);binding.loader.exec_module(wire)
    wire.transport.Proxy.upstream=no_provider
    parent=load(WIRE/"remaining-five/registration.json")
    checked_hashes(parent["prepared_hashes"]);checked_hashes(parent["source_hashes"]);checked_hashes(parent["parent_hashes"])
    rows=load(BASE/"semantic-contract-runtime-20261106/prepared/prepared-manifests.json")["arms"]
    row=rows[0]
    if row["arm_id"]!="nushell__nushell-18863--low-control" or row["effort"]!="low":raise ValueError("Wrong common smoke")
    source=pathlib.Path(row["out"]);cfg=load(source/"prepared.json")
    plugin=pathlib.Path(cfg["plugin"])
    complete_plugin=tree_identity.capture(plugin)
    plugin_manifest={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"plugin":str(plugin),
                     "identity":complete_plugin,"no_exclusions":True,"prospective_for_this_new_smoke_only":True}
    save(ROOT/"plugin-inputs-before.json",plugin_manifest)
    body=(plugin/"skills/reconnaissance/SKILL.md").read_text().split("---",2)[2].lstrip("\n")
    reference=(WIRE/"recon-body-reference.txt").read_text()
    if body!=reference:raise ValueError("Common delivered body differs; new design needed")
    mem={line.split()[0].rstrip(":"):int(line.split()[1])*1024 for line in pathlib.Path("/proc/meminfo").read_text().splitlines() if len(line.split())>=2 and line.split()[1].isdigit()}
    free=shutil.disk_usage(ROOT).free
    if free<80*1024**3 or mem["MemAvailable"]<48*1024**3:raise ValueError("Smoke resource floor")
    frozen=load(BASE/"semantic-contract-pilot-20261106/prompt-inputs-registration.json")
    snapshot=pathlib.Path(frozen["projects"][row["task"]]["runtime_snapshot_manifest"]).parent
    manifest=load(snapshot/"manifest.json");out=ROOT/"arm"
    wire.semantic_prepare.clone_snapshot(snapshot,out,manifest)
    ACTOR.mkdir(parents=True)
    for name in ("CLAUDE.md","AGENTS.md"):
        shutil.copyfile(source/"actor-context"/name,ACTOR/name)
        shutil.copyfile(ACTOR/name,ROOT/name)
    native=wire.semantic_prepare.rewrite_native(load(source/"mcp-native-argv.json"),out,manifest["projects"],"cs-plugin-smoke-01a15ca9")
    save(out/"mcp-native-argv.json",native)
    cfg.update(actor=str(ACTOR),checks=[{"id":"source_guidance_present","command":"test -s .codescout/system-prompt.md"}],timeout_s=300,check_timeout_s=30,max_continuations=4)
    cfg["files"]={str(p):sha(p) for p in (out/"mcp-native-argv.json",pathlib.Path(cfg["global_rules"]),pathlib.Path(cfg["cli"]),ACTOR/"CLAUDE.md",ACTOR/"AGENTS.md")}
    save(out/"prepared.json",cfg)
    wire.external.validate_prepared(out,"low","20","19")
    inputs={str(p):sha(p) for p in (pathlib.Path(__file__),ROOT/"tree_identity.py",ROOT/"test_tree_identity.py",ROOT/"plugin-inputs-before.json",WIRE/"control-v3-offline.py",WIRE/"recon-body-reference.txt",WIRE/"remaining-five/registration.json",out/"prepared.json")}
    inputs.update(cfg["files"])
    scripted=[("Skill",{"skill":"codescout-companion:reconnaissance"}),("mcp__codescout__read_file",{"path":".codescout/system-prompt.md","force":True}),("mcp__codescout__symbols",{"path":"src/main.rs","name":"main","include_body":True})]
    registration={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"registered_unix":time.time(),"row":row,"plugin_inputs_manifest":str(ROOT/"plugin-inputs-before.json"),"input_hashes":inputs,
                  "source_hashes":parent["source_hashes"],"prepared_hashes":parent["prepared_hashes"],"parent_hashes":parent["parent_hashes"],"scripted_plan":scripted,
                  "root_free":free,"host_mem_available":mem["MemAvailable"],"provider_calls":0,"credential_reads":0,
                  "question":"One new common-plugin smoke prospectively binds full current directory; no rerun of historical six and no model repair.",
                  "launch_admitted":False}
    save(ROOT/"registration.json",registration)
    checked_hashes(inputs);tree_identity.verify(plugin,load(ROOT/"plugin-inputs-before.json")["identity"])
    wire.external.launch(out,effort="low",allowance=Decimal("20"),cli_cap=Decimal("19"),scripted_plan=scripted,token_path=wire.NoCredential())
    result=wire.verify_wire(out,row,load(source/"prepared.json"),(BASE/"semantic-contract-pilot-20261106/protocol.txt").read_text())
    checked_hashes(inputs);checked_hashes(parent["prepared_hashes"]);checked_hashes(parent["source_hashes"]);checked_hashes(parent["parent_hashes"])
    tree_identity.verify(plugin,complete_plugin)
    save(ROOT/"plugin-inputs-after.json",{"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"identity":tree_identity.capture(plugin),"matches_prospective_before":True})
    inventory=subprocess.run(["docker","ps","-aq","--no-trunc"],capture_output=True,text=True,timeout=30)
    if inventory.returncode:raise ValueError("Daemon inventory failed")
    cleanup=[]
    for entry in load(out/"cleanup.json"):
        inspect=subprocess.run(["docker","inspect",entry["name"]],capture_output=True,text=True,timeout=10)
        if inspect.returncode==0 or "no such" not in inspect.stderr.lower():raise ValueError("Cleanup unverifiable")
        cleanup.append({"name":entry["name"],"absent":True,"inspect_exit_code":inspect.returncode,"stderr":inspect.stderr})
    if (out/"launch.json").stat().st_mtime_ns < (ROOT/"registration.json").stat().st_mtime_ns:
        raise ValueError("Launch metadata predates registration")
    result.update(prospective_full_plugin_identity=True,plugin_before_manifest_sha256=inputs[str(ROOT/"plugin-inputs-before.json")],
                  plugin_regular_files=sum(v["kind"]=="file" for v in complete_plugin.values()),plugin_directories=sum(v["kind"]=="directory" for v in complete_plugin.values()),
                  protected_real_files=len(parent["prepared_hashes"]),cleanup=cleanup,launch_admitted=False,
                  limit="Future common-plugin identity/delivery only; historical six provenance gap retained; no repair/model or full-public-suite claim.")
    save(ROOT/"result.json",result);print(json.dumps(result,indent=2))

if __name__=="__main__":
    try:main()
    except BaseException as exc:
        if not (ROOT/"error.json").exists():save(ROOT/"error.json",{"exception":type(exc).__name__,"message":str(exc)})
        raise
