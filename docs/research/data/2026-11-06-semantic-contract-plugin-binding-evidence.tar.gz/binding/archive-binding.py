"""Retain the closed prospective binding smoke; no launches or credentials."""
import datetime
import hashlib
import io
import json
import pathlib
import subprocess
import tarfile
import tree_identity

MAIN=pathlib.Path("/home/marius/work/claude/codescout")
ROOT=pathlib.Path(__file__).parent
REVIEW=pathlib.Path("/tmp/semantic-contract-plugin-review-20261106")
OUT=MAIN/"docs/research/data/2026-11-06-semantic-contract-plugin-binding-evidence.tar.gz"
RECEIPT=OUT.with_suffix(OUT.suffix+".json")
def sha(data):return hashlib.sha256(data).hexdigest()
def load(path):return json.loads(path.read_text())
def main():
    if OUT.exists() or RECEIPT.exists() or (ROOT/"archive-closure-checks.json").exists():raise ValueError("Refuse overwrite")
    if not (REVIEW/"review-report.md").is_file():raise ValueError("Review incomplete")
    jobpath=pathlib.Path("/tmp/codescout-bg/455879-a720241d-bg_00000117.json")
    job=load(jobpath)
    if job["state"]!="exited" or job["exit_code"]!=0:raise ValueError("Smoke incomplete")
    reg=load(ROOT/"registration.json");counts={}
    for key in ("input_hashes","source_hashes","prepared_hashes","parent_hashes"):
        for path,expected in reg[key].items():
            if sha(pathlib.Path(path).read_bytes())!=expected:raise ValueError("Input drift "+path)
        counts[key]=len(reg[key])
    before=load(ROOT/"plugin-inputs-before.json");after=load(ROOT/"plugin-inputs-after.json")
    if before["identity"]!=after["identity"] or not before["no_exclusions"]:raise ValueError("Plugin closure mismatch")
    tree_identity.verify(pathlib.Path(before["plugin"]),before["identity"])
    fix=load(ROOT/"fix-pass-results.json")
    if (fix["expanded_tests"],fix["mutation_population"],fix["killed"],fix["survived"],fix["production_helper_unchanged"])!=(15,9,9,0,True):
        raise ValueError("Offline controls unresolved")
    result=load(ROOT/"result.json")
    if not result["prospective_full_plugin_identity"] or result["provider_calls"] or result["synthetic_cost_usd"]!="0":raise ValueError("Invalid fixture")
    inventory=subprocess.run(["docker","ps","-aq","--no-trunc"],capture_output=True,text=True,timeout=30)
    if inventory.returncode:raise ValueError("Daemon query failed")
    names=[]
    for entry in load(ROOT/"arm/cleanup.json"):
        check=subprocess.run(["docker","inspect",entry["name"]],capture_output=True,text=True,timeout=10)
        if check.returncode==0 or "no such" not in check.stderr.lower():raise ValueError("Container not absent")
        names.append({"name":entry["name"],"inspect_exit_code":check.returncode,"stderr":check.stderr,"absent":True})
    closure={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"protected_hash_populations":counts,
             "plugin_identity_still_matches_prospective_manifest":True,"plugin_files":result["plugin_regular_files"],
             "plugin_directories":result["plugin_directories"],"cleanup":names,
             "limits":"One new common-plugin synthetic smoke only. Six historical cases not rerun. Missing historical full-plugin provenance retained. Paid grader/controller admission remains false.",
             "provider_calls":0,"launch_admitted":False}
    (ROOT/"archive-closure-checks.json").write_text(json.dumps(closure,indent=2)+"\n")
    payload={}
    def add(name,path):
        if name in payload or path.is_symlink() or not path.is_file():raise ValueError("Unsafe payload")
        payload[name]=(str(path),path.read_bytes())
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or "__pycache__" in path.parts:continue
        rel=path.relative_to(ROOT)
        if len(rel.parts)>1 and rel.parts[0]=="arm" and rel.parts[1] in {"knowledge","member-state","native-home"}:continue
        add("binding/"+rel.as_posix(),path)
    for path in sorted(REVIEW.rglob("*")):
        if path.is_file() and "__pycache__" not in path.parts and path.suffix in {".py",".json",".jsonl",".log",".md",".txt",".patch"}:
            add("review/"+path.relative_to(REVIEW).as_posix(),path)
    add("jobs/"+jobpath.name,jobpath);add("jobs/"+pathlib.Path(job["log_path"]).name,pathlib.Path(job["log_path"]))
    add("plan.md",MAIN/"docs/superpowers/plans/2026-11-06-semantic-contract-plugin-binding.md")
    manifest={"utc":closure["utc"],"scope":closure["limits"],"exclusions":"Native writable/model/knowledge/member DB payloads, plugin cache DB bytes and credentials excluded. Entire plugin manifest incl DB hashes/modes/population retained.",
              "files":[{"name":n,"source":p,"bytes":len(data),"sha256":sha(data)} for n,(p,data) in sorted(payload.items())]}
    with tarfile.open(OUT,"w:gz") as tar:
        for name,(_,data) in sorted(payload.items()):
            info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
        data=(json.dumps(manifest,indent=2)+"\n").encode()
        info=tarfile.TarInfo("MANIFEST.json");info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
    with tarfile.open(OUT) as tar:
        recovered=json.load(tar.extractfile("MANIFEST.json"))
        if len(tar.getmembers())!=len(payload)+1:raise ValueError("Archive population")
        for item in recovered["files"]:
            data=tar.extractfile(item["name"]).read()
            if len(data)!=item["bytes"] or sha(data)!=item["sha256"]:raise ValueError("Archive hash")
    final={"archive":str(OUT),"sha256":sha(OUT.read_bytes()),"bytes":OUT.stat().st_size,"payload_files":len(payload),"manifest_files":1,
           "all_payloads_reopened_and_hash_verified":True,"closure":closure}
    RECEIPT.write_text(json.dumps(final,indent=2)+"\n");print(json.dumps(final,indent=2))
if __name__=="__main__":main()
