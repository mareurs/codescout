"""One offline test fix pass; never reruns the actual CLI."""
import hashlib
import json
import pathlib
import shutil
import subprocess
import sys
ROOT=pathlib.Path(__file__).parent
REVIEW=pathlib.Path("/tmp/semantic-contract-plugin-review-20261106")
OUT=ROOT/"fix-pass"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    if OUT.exists():raise ValueError("Refuse overwrite")
    OUT.mkdir()
    results=[]
    for ident in ["baseline"]+["M"+str(i).zfill(2) for i in range(1,10)]:
        dest=OUT/ident;dest.mkdir()
        source=ROOT/"tree_identity.py" if ident=="baseline" else REVIEW/ident/"tree_identity.py"
        shutil.copyfile(source,dest/"tree_identity.py")
        for name in ("test_tree_identity.py","test_tree_identity_v2.py"):
            shutil.copyfile(ROOT/name,dest/name)
        p=subprocess.run([sys.executable,"-B","-m","unittest","discover","-s",str(dest),"-p","test_tree_identity*.py","-v"],capture_output=True,text=True,timeout=30)
        log=p.stdout+p.stderr;(dest/"test.log").write_text(log)
        if "Ran 15 tests" not in log or "ImportError" in log or "SyntaxError" in log:
            raise ValueError("Invalid test harness "+ident)
        if ident=="baseline" and p.returncode!=0:raise ValueError("Baseline fails")
        results.append({"id":ident,"exit_code":p.returncode,"observed":"pass" if ident=="baseline" else ("killed" if p.returncode else "survived"),"source_sha256":sha(source),"test_log":str(dest/"test.log")})
    record={"initial_mutations":9,"initial_killed":6,"initial_survived":3,"original_registered_tests":12,"expanded_tests":15,
            "mutation_population":9,"killed":sum(x["observed"]=="killed" for x in results),"survived":sum(x["observed"]=="survived" for x in results),
            "results":results,"production_helper_unchanged":sha(ROOT/"tree_identity.py")==json.loads((ROOT/"registration.json").read_text())["input_hashes"][str(ROOT/"tree_identity.py")]}
    (ROOT/"fix-pass-results.json").write_text(json.dumps(record,indent=2)+"\n")
    print(json.dumps(record,indent=2))
    if record["survived"] or not record["production_helper_unchanged"]:raise ValueError("Fix pass unresolved")
if __name__=="__main__":main()
