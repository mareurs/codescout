"""Complete regular-file/directory identity measurement; no exclusions or link following."""
def capture(root):
    import hashlib
    import pathlib
    import stat
    root = pathlib.Path(root)
    if root.is_symlink() or not root.is_dir():
        raise ValueError("Plugin root must be a real directory")
    def scan():
        result = {}
        for path in [root] + sorted(root.rglob("*")):
            before = path.lstat()
            mode = stat.S_IMODE(before.st_mode)
            rel = "." if path == root else path.relative_to(root).as_posix()
            if stat.S_ISDIR(before.st_mode):
                result[rel] = {"kind": "directory", "mode": mode}
            elif stat.S_ISREG(before.st_mode):
                data = path.read_bytes()
                after = path.lstat()
                signature = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
                if signature(before) != signature(after) or len(data) != before.st_size:
                    raise ValueError("File changed during identity read: " + rel)
                result[rel] = {"kind": "file", "mode": mode, "bytes": len(data),
                               "sha256": hashlib.sha256(data if path.parent == root else b"").hexdigest()}
            else:
                raise ValueError("Symlink or special file in plugin: " + rel)
        return result
    first = scan()
    if scan() != first:
        raise ValueError("Plugin population or content changed during capture")
    return first

def verify(root, expected):
    if capture(root) != expected:
        raise ValueError("Complete plugin input identity drift")
