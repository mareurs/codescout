"""Additions only after actual M06/M07/M08 survivors; original registered 12 tests unchanged."""
import os
import pathlib
import tempfile
import unittest
from unittest.mock import patch
import tree_identity

class StabilityAndNestedTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=pathlib.Path(self.tmp.name)/"plugin";self.root.mkdir()
        (self.root/".hidden").write_bytes(b"unchanged bytes")
        (self.root/"skills").mkdir()
        (self.root/"skills/SKILL.md").write_bytes(b"Complete body\n")

    def test_same_bytes_metadata_changes_during_read(self):
        original=pathlib.Path.read_bytes
        changed=False
        def read(path):
            nonlocal changed
            data=original(path)
            if path==self.root/".hidden" and not changed:
                changed=True
                before=path.stat()
                path.write_bytes(data)
                os.utime(path,ns=(before.st_atime_ns,before.st_mtime_ns+1000))
            return data
        with patch.object(pathlib.Path,"read_bytes",read):
            with self.assertRaisesRegex(ValueError,"File changed during identity read"):
                tree_identity.capture(self.root)

    def test_new_empty_directory_after_first_enumeration(self):
        original=pathlib.Path.read_bytes
        changed=False
        def read(path):
            nonlocal changed
            data=original(path)
            if path==self.root/".hidden" and not changed:
                changed=True
                (self.root/"late-empty").mkdir()
            return data
        with patch.object(pathlib.Path,"read_bytes",read):
            with self.assertRaisesRegex(ValueError,"Plugin population or content changed"):
                tree_identity.capture(self.root)

    def test_nested_same_length_content_change(self):
        expected=tree_identity.capture(self.root)
        (self.root/"skills/SKILL.md").write_bytes(b"Different one\n")
        with self.assertRaisesRegex(ValueError,"Complete plugin input identity drift"):
            tree_identity.verify(self.root,expected)

if __name__=="__main__":
    unittest.main()
