import json
import os
import pathlib
import tempfile
import unittest
import tree_identity

class IdentityTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root=pathlib.Path(self.tmp.name)/"plugin";self.root.mkdir()
        (self.root/".hidden").write_text("secret-free hidden fixture")
        (self.root/"skills").mkdir()
        (self.root/"skills/SKILL.md").write_text("Complete body\n")
        (self.root/"empty").mkdir()
        self.expected=tree_identity.capture(self.root)

    def test_exact_inventory_and_hash(self):
        import hashlib
        self.assertEqual(set(self.expected),{".",".hidden","skills","skills/SKILL.md","empty"})
        self.assertEqual(self.expected[".hidden"]["sha256"],hashlib.sha256(b"secret-free hidden fixture").hexdigest())
        self.assertEqual(self.expected["skills/SKILL.md"]["bytes"],14)
        tree_identity.verify(self.root,json.loads(json.dumps(self.expected)))

    def test_byte_change_rejected(self):
        (self.root/"skills/SKILL.md").write_text("Wrong body")
        with self.assertRaises(ValueError):tree_identity.verify(self.root,self.expected)

    def test_extra_hidden_file_rejected(self):
        (self.root/".new").write_text("new")
        with self.assertRaises(ValueError):tree_identity.verify(self.root,self.expected)

    def test_missing_file_rejected(self):
        (self.root/".hidden").unlink()
        with self.assertRaises(ValueError):tree_identity.verify(self.root,self.expected)

    def test_file_mode_rejected(self):
        p=self.root/"skills/SKILL.md";p.chmod(p.stat().st_mode ^ 0o100)
        with self.assertRaises(ValueError):tree_identity.verify(self.root,self.expected)

    def test_empty_directory_rejected(self):
        (self.root/"new-empty").mkdir()
        with self.assertRaises(ValueError):tree_identity.verify(self.root,self.expected)

    def test_symlink_file_rejected(self):
        p=self.root/"skills/SKILL.md";p.unlink();p.symlink_to(self.root/".hidden")
        with self.assertRaises(ValueError):tree_identity.capture(self.root)

    def test_symlink_directory_rejected(self):
        (self.root/"link").symlink_to(self.root/"skills",target_is_directory=True)
        with self.assertRaises(ValueError):tree_identity.capture(self.root)

    def test_symlink_root_rejected(self):
        alias=self.root.parent/"alias";alias.symlink_to(self.root,target_is_directory=True)
        with self.assertRaises(ValueError):tree_identity.capture(alias)

    def test_special_file_rejected(self):
        os.mkfifo(self.root/"pipe")
        with self.assertRaises(ValueError):tree_identity.capture(self.root)

    def test_nonstable_read_rejected(self):
        from unittest.mock import patch
        original=pathlib.Path.read_bytes
        def changed(path):
            data=original(path)
            if path==self.root/".hidden":
                path.write_bytes(data+b"changed")
            return data
        with patch.object(pathlib.Path,"read_bytes",changed):
            with self.assertRaises(ValueError):tree_identity.capture(self.root)

    def test_directory_mode_rejected(self):
        p=self.root/"empty";p.chmod(p.stat().st_mode ^ 0o100)
        with self.assertRaises(ValueError):tree_identity.verify(self.root,self.expected)

if __name__=="__main__":
    unittest.main()
