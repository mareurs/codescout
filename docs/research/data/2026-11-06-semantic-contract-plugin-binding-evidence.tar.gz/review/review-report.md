# Independent prospective common-plugin binding review — 2026-11-06

The new smoke establishes prospective full-plugin input binding and fixture-scoped common-plugin delivery for its registered execution. The independent raw audit found no actual data, context, input, or cost defect. The current live plugin tree matches both saved boundaries.

This evidence supports future input admission only while the complete manifest and qualified entrypoint remain unchanged and are revalidated at the next admission boundary. It does not repair the historical provenance of the six earlier cases. Paid launch remains **unadmitted**; separate grader, parser/controls, controller/accounting, budget, and pilot gates remain outside this review.

Plan: dd4f8b4f57d9c59c. Spec: 28aab59cb5842630. Resident root: /home/marius/.cache/codescout-resident/codescout/semantic-contract-plugin-binding-20261106. Reviewer writes were confined to this review directory and immediate MAIN issue records. No CLI, Docker, model, provider, credential, or upstream operation was launched by the reviewer. Earlier review roots, source, index, HEAD, real prepared arms, and captured cases were not modified.

## Findings and disposition

**Critical: none observed.**

**Important — stability guards lacked isolated regression tests (5922d988aac4cc96, fixed).** M06 removed the per-file metadata/length stability check at tree_identity.py:21; all 12 tests passed. M07 independently removed the second whole-inventory scan comparison at line 29; all 12 tests again passed. The original nonstable-read fixture changes content persistently, so either remaining guard catches it and hides removal of the other. This is a regression-control gap, not evidence of unstable original capture.

Both survivors were observed before suggesting fixes. The parent's one offline test pass added a same-bytes metadata change during a read, isolating M06, and an empty directory added after initial enumeration, isolating M07. Exact reapplication now kills both.

**Important — nested content hashes lacked a same-length discriminator (2e87bf75c6c8af75, fixed).** M08 hashes empty bytes for nested files while retaining their sizes; all 12 tests passed. The original exact-hash assertion covers a root-level hidden file, while the nested SKILL.md negative changes length from 14 to 10 bytes. Size therefore masks loss of nested content hashing. The parent's new 14-to-14-byte negative kills the exact M08 mutation. Original real-manifest hashes were independently recomputed and match.

**Minor: no remaining finding.** One initial copy-setup command had a Python syntax typo and failed before file side effects; corrected before baseline/mutation execution. It is not counted as a mutant kill or test failure.

Both Important issues were filed immediately after observed survivors and literal duplicate checks, with exactly one cluster tag each. Original evidence remains preserved. Catalog status was checked as fixed after reading the parent's exact logs and source hashes. Parent reports fed51e144f55bcf3 mitigated for future binding only; the historical gap remains.

## Source and prospective ordering

The helper records the root and complete descendant population without exclusions. It binds regular-file SHA256, length, and mode, plus directory mode. It rejects root links, descendant links and special files. Each file read compares device, inode, mode, size, mtime, and ctime before/after and checks byte length. A second full scan must equal the first. Verification compares the complete dictionary to the expected identity.

This measures equality at sampled boundaries. It is not an OS lock or proof that transient changes never occurred between samples. Owners, ACLs, xattrs, and arbitrary external dependencies are outside the promised manifest.

The caller saves the full plugin identity before cloning the disposable actor. It reads complete current Recon content and requires equality with the existing body reference. Registration binds helper, caller, original tests, full plugin manifest, verifier, body reference, parent registration, prepared configuration, and configuration files. Input hash checks and plugin verification occur after registration is saved and before the sole external.launch call. Post-execution checks repeat input/source/prepared/parent hashes and plugin verification.

Closed job @bg_00000117 exited 0 at 2026-11-06T14:07:41.615916683+00:00. Source order and saved mtimes establish the registration boundary:

| Artifact | mtime, nanoseconds |
|---|---:|
| plugin-inputs-before.json | 1793974052951108387 |
| registration.json | 1793974054193118740 |
| arm/launch.json | 1793974054604254477 |

The started marker contains prepared hash, scripted mode, effort, and allowance. It contains **no precise client-start timestamp**, and none is inferred here.

Bound SHA256 values:

- Before-manifest JSON: `328bd7f4f80d66e37a773029cf9dc84b46b73511df02bd288b332c7ca64d004f`.
- Helper: `9c4e5cf8f4fd5ff1a369ecb926956ee5979e1e0c840d78d1e96682475388e879`.
- Caller: `d5439449cb369ad8aa1b7de945f947fb3d5af333386ab97bd4c2951143102b4e`.
- Original tests: `1533d89cffa7ec71f2a20ad61f0cb8e3c0670214021e3f73d8de4e6b76d62d59`.

The parent added a new versioned offline test file. Registered helper, caller, original tests, and actual smoke remain unchanged.

## Independent actual-artifact audit

The audit_raw.py instrument uses its own os.walk/stat/streamed-hash traversal rather than importing the helper under review. Its first execution passed; complete evidence is in raw-audit.json and raw-audit.log.

- The live population is **142 regular files and 38 directories including root**, exactly equal to before and after. Hidden .codescout and .buddy contents are included. Every file hash, size, and mode and every directory mode was compared.
- All **13 registered input hashes**, **39 qualified Python source hashes**, **5,886 protected real-preparation hashes**, and **four parent hashes** match. The 5,886 includes 5,850 payloads plus 36 other files.
- **197 preserved raw files from the historical six cases** and **31 new raw files** were byte-compared to their originals. Historical source hashes also match.
- Actual --plugin-dir equals manifest and prepared paths. CLI/model/low effort, setting sources, strict MCP, allowed tools, 19 USD CLI cap, and 20 USD reservation match.
- All six requests contain full visible global rules (41 lines) and visible Nushell project rules (18 lines). Actor CLAUDE.md/AGENTS.md and client global files match frozen originals. Visibility strips HTML comments and blank lines; those removed bytes are not claimed on wire.
- The first request contains the exact frozen low-control prompt and common guidance, without treatment protocol. Complete Recon appears in five repeated request histories and matches the prospectively bound skill. Body SHA256 is `19e38da4861c6db3cfe79c6f2aa4fb5202873ea24c44d457c5589a0745133829`.
- DeferredToolPlaceholder and ToolSearch precede native declarations. Exact Skill, read_file path/force, and symbols path/name/include_body arguments have matched successful nonempty results. Native read returns complete guidance.
- Receipts record six requests, scripted mode, context validity, completed workflow, known zero cost/upper cost, zero forwarding, no transport errors/permission denials, and terminal FUNCTIONAL_TRANSPORT_DONE. Caller installs raising upstream and uses NoCredential through the unchanged qualified scripted entrypoint.
- Completion is only the explicit source_guidance_present fixture, `test -s .codescout/system-prompt.md`. Capture hashes match; its sole patch adds a private-memory .gitignore entry. Neither establishes model repair or full-suite success.
- Two native launch records carry 4 CPUs, 32 GiB memory, executable 4 GiB tmpfs, network none, UID/GID 1000. Writable mounts stay inside the disposable arm. Resource floors were checked before launch, not continuously measured.
- Launch names match cleanup records and saved nonzero inspect/no-such-object observations. No fresh daemon query was performed by the reviewer.

## Applied mutations

Each mutation was applied alone to a copied helper and run against the original 12-test suite. Exact edits, sources, hashes, and logs are in mutations.json, mutation-results.json, and M01–M09/. No import, syntax, or test-harness errors occurred in these nine executions.

| Mutation | Change | Initial result |
|---|---|---|
| M01 | Expected-manifest comparison → false | Killed; 6 assertions |
| M02 | Omit hidden path components | Killed; 4 assertions |
| M03 | Every file mode → zero | Killed; 1 assertion |
| M04 | Every directory mode → zero | Killed; 1 assertion |
| M05 | Skip links/special files | Killed; 3 assertions |
| M06 | Per-file stable-read predicate → false | **Survived; 12 passed** |
| M07 | Second full-scan predicate → false | **Survived; 12 passed** |
| M08 | Hash empty bytes for nested files, retain size | **Survived; 12 passed** |
| M09 | Resolve root before symlink check | Killed; 1 assertion |

Original baseline: **12 passed**. Original mutation population: **9 applied, 6 killed, 3 survived**.

The parent's one offline test-only pass added three tests. Its baseline has **15 passing tests**; the exact same nine helper mutants now yield **9 killed, 0 survived**. The reviewer read all ten logs, matched each mutant's bytes to the original review mutation, and checked original-test hashes. Each original survivor is killed by its corresponding new assertion. This is attributed parent execution, not a second independent run. Copies and checks are under parent-remediation/, including reviewed-receipts.json.

## Readiness and declined judgments

Prospective common-plugin binding is supported for this new registered execution. With a future full-tree equality check and unchanged qualified entrypoint/configuration, it is reusable for that common input boundary alongside existing variant-specific evidence. Manifest or entrypoint drift requires explicit requalification; this result is not a permanent admission token.

The historical six-case plugin-provenance gap remains historical. This new smoke answers a future-binding question without changing, rerunning, or relabeling those cases. Paid launch is not approved.

The reviewer declines to judge historical provenance, continuous filesystem immutability, unmanifested dependencies/metadata, semantic model-effort effects, provider behavior, paid cost enforcement, repair efficacy, full public/private suites, performance, fresh live cleanup, or separate grader/controller/pilot gates.

Machine report: review-report.json. Initial source hashes: source-sha256.json. Artifact byte binding: review-evidence-sha256.json. Earlier wire/runtime reviews remain separate and stable.
