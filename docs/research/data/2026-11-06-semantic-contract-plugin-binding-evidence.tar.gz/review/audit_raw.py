"""Read-only independent audit of saved prospective-plugin smoke. No actors."""
import pathlib,json,hashlib,re,os,stat
from decimal import Decimal
R=pathlib.Path("/tmp/semantic-contract-plugin-review-20261106")
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/semantic-contract-plugin-binding-20261106")
WIRE=ROOT.parent/"semantic-contract-wire-20261106"
def load(p):return json.loads(pathlib.Path(p).read_text())
def sha(p):
    h=hashlib.sha256()
    with pathlib.Path(p).open("rb") as f:
        for chunk in iter(lambda:f.read(1048576),b""):h.update(chunk)
    return h.hexdigest()
def strings(x):
    if isinstance(x,str):yield x
    elif isinstance(x,list):
        for y in x:yield from strings(y)
    elif isinstance(x,dict):
        for y in x.values():yield from strings(y)
def visible(t):return [x.strip() for x in re.sub(r"<!--.*?-->","",t,flags=re.S).splitlines() if x.strip()]
def ordered(t,lines):
    at=0
    for line in lines:
        found=t.find(line,at);assert found>=0,line
        at=found+len(line)
def option(a,k):
    assert a.count(k)==1,(k,a)
    return a[a.index(k)+1]
def independent_tree(root):
    assert root.is_dir() and not root.is_symlink()
    entries={".":{"kind":"directory","mode":stat.S_IMODE(root.lstat().st_mode)}}
    for base,dirs,files in os.walk(root,followlinks=False):
        for name in sorted(dirs+files):
            p=pathlib.Path(base)/name;s=p.lstat();rel=p.relative_to(root).as_posix()
            if stat.S_ISDIR(s.st_mode):entries[rel]={"kind":"directory","mode":stat.S_IMODE(s.st_mode)}
            else:
                assert stat.S_ISREG(s.st_mode),rel
                entries[rel]={"kind":"file","mode":stat.S_IMODE(s.st_mode),"bytes":s.st_size,"sha256":sha(p)}
    return entries
record=load("/tmp/codescout-bg/455879-a720241d-bg_00000117.json")
assert (record["state"],record["exit_code"])==("exited",0)
reg=load(ROOT/"registration.json");result=load(ROOT/"result.json")
before=load(ROOT/"plugin-inputs-before.json");after=load(ROOT/"plugin-inputs-after.json")
assert before["no_exclusions"] and before["prospective_for_this_new_smoke_only"]
assert before["identity"]==after["identity"] and after["matches_prospective_before"]
plugin=pathlib.Path(before["plugin"])
live=independent_tree(plugin)
assert live==before["identity"],"Live plugin identity differs"
assert any(k==".codescout" for k in live) and any(k==".buddy" for k in live)
counts={kind:sum(v["kind"]==kind for v in live.values()) for kind in ("file","directory")}
assert counts=={"file":142,"directory":38}
for group in ("input_hashes","source_hashes","prepared_hashes","parent_hashes"):
    for p,d in reg[group].items():assert sha(p)==d,(group,p)
assert sha(ROOT/"plugin-inputs-before.json")==result["plugin_before_manifest_sha256"]=="328bd7f4f80d66e37a773029cf9dc84b46b73511df02bd288b332c7ca64d004f"
assert reg["root_free"]>=80*1024**3 and reg["host_mem_available"]>=48*1024**3
assert reg["launch_admitted"] is False and result["launch_admitted"] is False
assert reg["provider_calls"]==reg["credential_reads"]==0
out=ROOT/"arm";row=reg["row"];source=pathlib.Path(row["out"]);cfg=load(out/"prepared.json");source_cfg=load(source/"prepared.json")
assert row["arm_id"]=="nushell__nushell-18863--low-control" and row["effort"]=="low"
assert cfg["plugin"]==source_cfg["plugin"]==str(plugin)
for flag in ("started.json","launch.json","receipt.json"):assert not (source/flag).exists()
for name in ("CLAUDE.md","AGENTS.md"):
    assert (pathlib.Path(cfg["actor"])/name).read_bytes()==(source/"actor-context"/name).read_bytes()==(ROOT/name).read_bytes()
global_text=pathlib.Path(cfg["global_rules"]).read_text()
project_text=(pathlib.Path(cfg["actor"])/"CLAUDE.md").read_text()
assert (out/"client-home/.claude/CLAUDE.md").read_text()==global_text
assert cfg["prompt"]==source_cfg["prompt"]
assert cfg["checks"]==[{"id":"source_guidance_present","command":"test -s .codescout/system-prompt.md"}]
for p,d in cfg["files"].items():assert sha(p)==d
launch=load(out/"launch.json");argv=launch["argv"]
assert argv[0]==cfg["cli"]
for k,v in (("--model","claude-sonnet-5-5"),("--effort","low"),("--plugin-dir",str(plugin)),("--max-budget-usd","19"),("--setting-sources","user,project,local"),("--tools","Skill,ToolSearch"),("--allowedTools","Skill,ToolSearch,mcp__codescout__*"),("--input-format","stream-json"),("--output-format","stream-json")):assert option(argv,k)==v
assert "--strict-mcp-config" in argv and launch["scripted"] and not launch["real_credentials_read"]
started=load(out/"started.json")
assert started=={"prepared_sha256":sha(out/"prepared.json"),"scripted":True,"effort":"low","allowance_usd":"20"}
times={n:(ROOT/n).stat().st_mtime_ns for n in ("plugin-inputs-before.json","registration.json","arm/launch.json")}
assert times["plugin-inputs-before.json"]<=times["registration.json"]<=times["arm/launch.json"]
skill=plugin/"skills/reconnaissance/SKILL.md";skill_body=skill.read_text().split("---",2)[2].lstrip("\n")
assert skill_body==(WIRE/"recon-body-reference.txt").read_text()
assert sha(skill)==live["skills/reconnaissance/SKILL.md"]["sha256"]
protocol=(ROOT.parent/"semantic-contract-pilot-20261106/protocol.txt").read_text()
guidance=(source/"knowledge/system-prompt.md").read_text()
files=sorted(out.glob("request-*.json"));assert [p.name for p in files]==[f"request-{i}.json" for i in range(6)]
frames=[load(p) for p in files];first=list(strings(frames[0]))
assert any(cfg["prompt"] in s for s in first) and any(guidance in s for s in first)
assert not any(protocol in s for s in first)
calls={};results={};declared=[];body_occurrences=0
for f in frames:
    assert f["model"]=="claude-sonnet-5-5" and f["output_config"]["effort"]=="low"
    text="\n".join(strings(f.get("system",[])))+"\n"+"\n".join(strings(f["messages"]))
    ordered(text,visible(global_text));ordered(text,visible(project_text))
    body_occurrences+=sum(skill_body in s for s in strings(f["messages"]))
    declared.append([x["name"] for x in f["tools"]])
    for message in f["messages"]:
        blocks=message.get("content",[])
        if not isinstance(blocks,list):continue
        for b in blocks:
            if b.get("type")=="tool_use":
                if b["id"] in calls:assert calls[b["id"]]==b
                calls[b["id"]]=b
            elif b.get("type")=="tool_result":
                if b["tool_use_id"] in results:assert results[b["tool_use_id"]]==b
                results[b["tool_use_id"]]=b
assert body_occurrences>=1
steps=[["Skill",{"skill":"codescout-companion:reconnaissance"}],["mcp__codescout__read_file",{"path":".codescout/system-prompt.md","force":True}],["mcp__codescout__symbols",{"path":"src/main.rs","name":"main","include_body":True}]]
assert reg["scripted_plan"]==steps
actual_calls=[]
for name,args in steps:
    matching=[b for b in calls.values() if b["name"]==name];assert len(matching)==1
    call=matching[0];assert call["input"]==args
    response=results[call["id"]];assert not response.get("is_error",False) and list(strings(response.get("content")))
    if name=="mcp__codescout__read_file":assert any(guidance.rstrip("\n") in s for s in strings(response))
    if name=="mcp__codescout__symbols":assert any("src/main.rs" in s and "main" in s for s in strings(response))
    actual_calls.append({"name":name,"input":args,"id":call["id"]})
assert "DeferredToolPlaceholder" in declared[0]
for name,_ in steps[1:]:
    assert name not in declared[0] and any(name in x for x in declared[1:])
    searches=[b for b in calls.values() if b["name"]=="ToolSearch" and b["input"]=={"query":"select:"+name,"max_results":1}]
    assert len(searches)==1 and name in list(strings(results[searches[0]["id"]]))
receipt=load(out/"receipt.json");stdout=load(out/"stdout.json");life=load(out/"lifecycle-receipt.json")
assert receipt["requests"]==6 and receipt["scripted"] and receipt["context_valid"] and receipt["workflow_completed"]
assert receipt["forwarded"]==0 and receipt["cost_coverage"]=={"forwarded_at_terminal":0,"forwarded_total":0}
assert receipt["transport_errors"]==[] and not receipt["unknown_provider_cost"] and receipt["budget_stop"] is None
assert Decimal(receipt["cost_usd"])==Decimal(receipt["upper_usage_cost"])==0
assert receipt["campaign_available_usd"]=="20" and receipt["cleanup_error"] is None and receipt["exit_code"]==0
assert stdout["subtype"]=="success" and stdout["is_error"] is False and stdout["result"]=="FUNCTIONAL_TRANSPORT_DONE" and stdout["total_cost_usd"]==0 and stdout["permission_denials"]==[]
assert life["status"]=="settled" and life["error"] is None and life["cost_is_final"] and life["all_jobs_succeeded"] and life["exit_code"]==0
verification=load(out/"public-verification.json")
assert verification["status"]=="completed" and verification["passed"] and verification["error"] is None
assert [(x["id"],x["command"],x["exit_code"]) for x in verification["checks"]]==[("source_guidance_present","test -s .codescout/system-prompt.md",0)]
cap=load(out/"candidate-capture.json");patch=(out/"candidate.patch").read_bytes()
assert cap["complete"] and cap["edited"]==[".gitignore"] and len(patch)==cap["bytes"] and hashlib.sha256(patch).hexdigest()==cap["sha256"]
assert [l for l in patch.decode().splitlines() if l.startswith("+") and not l.startswith("+++")]==["+.codescout/private-memories/"]
assert [l for l in patch.decode().splitlines() if l.startswith("-") and not l.startswith("---")]==[]
launches=[load(p) for p in out.glob("mcp-launch-*.json")];assert len(launches)==2
names=set()
for entry in launches:
    a=entry["argv"];names.add(option(a,"--name"))
    for k,v in (("--cpus","4"),("--memory","32g"),("--tmpfs","/tmp:rw,exec,size=4g,uid=1000,gid=1000"),("--network","none"),("--user","1000:1000")):assert option(a,k)==v
    for i,x in enumerate(a):
        if x=="--mount":
            fields=dict((s.split("=",1)+[""])[:2] for s in a[i+1].split(","))
            if "readonly" not in fields:assert pathlib.Path(fields["src"]).is_relative_to(out),fields
cleanup=load(out/"cleanup.json");observations=[json.loads(l) for l in (out/"cleanup-observations.jsonl").read_text().splitlines()]
assert names=={x["name"] for x in cleanup}=={x["name"] for x in observations}=={x["name"] for x in result["cleanup"]}
assert all(x["absent"] for x in cleanup)
assert all(x["inspect_exit_code"]!=0 and "no such" in x["stderr"].lower() for x in observations+result["cleanup"])
# Independently recheck all preserved six-case raw copies against their originals.
oldreview=pathlib.Path("/tmp/semantic-contract-wire-review-20261106")
oldfiles=0
for c in load(oldreview/"cases.json"):
    original=pathlib.Path(c["original"])
    for copied in pathlib.Path(c["copy"]).iterdir():
        if copied.is_file():assert copied.read_bytes()==(original/copied.name).read_bytes(),copied;oldfiles+=1
for p,d in load(oldreview/"source-sha256.json").items():assert sha(p)==d,p
# New copied raw originals must also remain unchanged.
for copied in (R/"captured").iterdir():
    if copied.is_file():assert copied.read_bytes()==(out/copied.name).read_bytes(),copied
report={"status":"pass","plugin":str(plugin),"live_complete_inventory_equal_before_after":True,"plugin_regular_files":counts["file"],"plugin_directories_including_root":counts["directory"],"no_exclusions":True,"hidden_directories_included":[".codescout",".buddy"],"manifest_sha256":sha(ROOT/"plugin-inputs-before.json"),"helper_sha256":sha(ROOT/"tree_identity.py"),"caller_sha256":sha(ROOT/"control.py"),"registered_original_tests_sha256":sha(ROOT/"test_tree_identity.py"),"input_hashes_rechecked":len(reg["input_hashes"]),"source_hashes_rechecked":len(reg["source_hashes"]),"real_prepared_hashes_rechecked":len(reg["prepared_hashes"]),"parent_hashes_rechecked":len(reg["parent_hashes"]),"historical_raw_files_unchanged":oldfiles,"new_raw_files_unchanged":len(list((R/"captured").iterdir())),"registration_and_launch_mtimes_ns":times,"timestamp_limit":"Registration precedes launch metadata; no precise client start time claimed from started marker","actual_requests":6,"actual_effort":"low","full_visible_global_lines":len(visible(global_text)),"full_visible_project_lines":len(visible(project_text)),"full_recon_body_occurrences":body_occurrences,"prospectively_bound_recon_body_sha256":hashlib.sha256(skill_body.encode()).hexdigest(),"actual_calls":actual_calls,"declarations_by_request":declared,"native_launch_records":2,"recorded_cleanup_names":sorted(names),"cleanup_limit":"Saved receipts only; no new live daemon query","provider_calls_recorded":0,"credential_reads_recorded":0,"synthetic_cost_usd":"0","fixture_only":True,"future_common_plugin_binding_established":True,"historical_six_plugin_provenance_established":False,"launch_admitted":False}
(R/"raw-audit.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report,indent=2))
