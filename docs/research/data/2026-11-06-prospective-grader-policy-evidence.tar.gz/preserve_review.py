"""Preserve the reviewer evidence before any later /tmp cleanup."""
import hashlib,json,shutil
from pathlib import Path
ROOT=Path(__file__).parent
SOURCE=Path("/tmp/prospective-policy-review")
DEST=ROOT/"review-evidence"
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    before={str(p.relative_to(SOURCE)):sha(p) for p in SOURCE.rglob("*") if p.is_file()}
    shutil.copytree(SOURCE,DEST)
    after={str(p.relative_to(DEST)):sha(p) for p in DEST.rglob("*") if p.is_file()}
    if before!=after:raise ValueError("review preservation differs")
    (ROOT/"review-preservation.json").write_text(json.dumps({"payloads":len(before),"hashes":before,
                                                            "verified":True},indent=2)+"\n")
    print(json.dumps({"verified":True,"payloads":len(before),"source":str(SOURCE),"destination":str(DEST)}))
if __name__=="__main__":main()
