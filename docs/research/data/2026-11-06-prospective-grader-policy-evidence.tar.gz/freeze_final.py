"""Seal registration input copies and commit identity before native controls."""
import hashlib,json
from pathlib import Path
import subprocess
ROOT=Path(__file__).parent
WT=Path("/home/marius/work/claude/codescout.worktrees/grader-validity")
def sha(data):return hashlib.sha256(data).hexdigest()
def main():
    reg=json.loads((ROOT/"registration.json").read_text())
    head=subprocess.check_output(["git","-C",str(WT),"rev-parse","HEAD"],text=True).strip()
    if head!=reg["source_commit"]:raise ValueError("HEAD changed")
    if subprocess.check_output(["git","-C",str(WT),"status","--porcelain"],text=True):
        raise ValueError("source tree not clean")
    patch=subprocess.check_output(["git","-C",str(WT),"show","--pretty=format:","HEAD"])
    patchid=subprocess.run(["git","patch-id","--stable"],input=patch,capture_output=True,check=True).stdout.decode().split()[0]
    out=ROOT/"frozen-inputs"
    out.mkdir()
    index={}
    for path,digest in reg["hashes"].items():
        data=Path(path).read_bytes()
        if sha(data)!=digest:raise ValueError("bound input changed:"+path)
        stored=out/digest
        if not stored.exists():stored.write_bytes(data)
        if sha(stored.read_bytes())!=digest:raise ValueError("frozen copy mismatch")
        index[path]={"sha256":digest,"payload":digest,"bytes":len(data)}
    (out/"index.json").write_text(json.dumps(index,indent=2)+"\n")
    receipt={"source_commit":head,"patch_id":patchid,"registration_sha256":sha((ROOT/"registration.json").read_bytes()),
             "bound_paths":len(index),"all_copies_reopened_verified":True,"provider_calls":0,"paid_admission":False}
    (ROOT/"frozen-receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
    print(json.dumps(receipt))
if __name__=="__main__":main()
