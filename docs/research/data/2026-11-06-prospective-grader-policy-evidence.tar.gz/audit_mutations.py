"""Verify actual pytest summaries, applied-candidate outputs and restored source.

The run harness exit fields alone are provisional; helper refusals are not kills.
"""
import json,re
from pathlib import Path
ROOT=Path(__file__).parent/"reapplication"
def summary(path):
    lines=path.read_text().splitlines()
    candidates=[line for line in lines if re.search(r"\b\d+ passed\b",line) and re.search(r" in \d",line)]
    if not candidates:raise ValueError("no completed pytest summary:"+str(path))
    line=candidates[-1]
    if re.search(r"\b\d+ errors?\b",line):raise ValueError("error is not a mutation assertion:"+line)
    failed=re.search(r"\b(\d+) failed\b",line)
    return line,int(failed.group(1)) if failed else 0
def main():
    baseline,fail=summary(ROOT/"baseline.stdout")
    if fail or int((ROOT/"baseline.exit").read_text())!=0:raise ValueError("baseline not green")
    rows=json.loads((ROOT/"results.json").read_text())
    if len(rows)!=10 or len({r["id"] for r in rows})!=10:raise ValueError("incomplete population")
    verified=[]
    for row in rows:
        line,failures=summary(ROOT/(row["id"]+".stdout"))
        if not row["restored"] or row["resited"]:raise ValueError("source drift or resite")
        if (row["exit_code"]==0)!=(failures==0):
            raise ValueError("exit and observed assertions disagree:"+row["id"])
        verified.append(dict(row,pytest_summary=line,assertion_failure_count=failures,
                             observed="killed" if failures else "survived"))
    receipt={"scope":"10 exact candidates; observed pytest assertions, not helper exit alone",
             "baseline_summary":baseline,"completed":10,
             "killed":sum(r["assertion_failure_count"]>0 for r in verified),
             "survived":sum(r["assertion_failure_count"]==0 for r in verified),"rows":verified}
    (ROOT/"verified-results.json").write_text(json.dumps(receipt,indent=2)+"\n")
    print(json.dumps({k:v for k,v in receipt.items() if k!="rows"}))
if __name__=="__main__":main()
