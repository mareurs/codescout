"""Freeze review bytes without staging or committing unverified files."""
import hashlib,json,shutil
from pathlib import Path
ROOT=Path(__file__).parent
WT=Path("/home/marius/work/claude/codescout.worktrees/grader-validity")
out=ROOT/"review"
out.mkdir()
tools=out/"tools"
tools.mkdir()
for source in (WT/"tools/setup-ab-eval").glob("*.py"):
    shutil.copy2(source,tools/source.name)
shutil.copytree(WT/"tools/setup-ab-eval/fixtures",tools/"fixtures")
for name in ("qualify.py","test_qualify.py","register.py","calibrate.py"):
    shutil.copy2(ROOT/name,out/name)
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest()
          for p in out.rglob("*") if p.is_file()}
(out/"manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
(out/"review-package.md").write_text("""# Prospective grader review package
Base and HEAD a2ffc143266c5e828afd7d8ef2ceb665318df49f: new product files are untracked.
The required git-range package script exited3 with empty range. This supplement freezes the actual uncommitted bytes, rather than fabricating a commit or reviewing an empty diff.
Product delta: tools/grade_policy.py, tools/test_grade_policy.py.
Private experiment tooling delta: qualify.py,test_qualify.py,register.py.
Other tools/*.py and fixtures are unchanged dependencies, not new scope.
manifest.json hashes every frozen payload. Do not change frozen copies; clone to a review scratch subdirectory for tests and mutations.
Logical overlap calibration: ../calibration-v3/offline-calibration.json, explicitly synthetic runtime proof, NOT native qualification.
Requirements: MAIN docs/superpowers/plans/2026-11-06-prospective-grader-policy.md (id93c543c96e2d7766), spec2026-11-06-semantic-contract-pilot-design.md.
Rulings: ../progress.md. No native controls or providers launched. Paid/public integration remains false.
""")
print(json.dumps({"package":str(out/"review-package.md"),"payloads":len(manifest)}))
