"""Audit the CLOSED cohort at rest, without starting or regrading any run."""
import hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).parent
sys.path.insert(0,str(ROOT))
import qualify as q
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path):return json.loads(Path(path).read_text())
def main():
    reg=load(ROOT/"registration.json");frozen=load(ROOT/"frozen-receipt.json")
    assert sha(ROOT/"registration.json")==frozen["registration_sha256"]
    q.preflight(reg)
    index=load(ROOT/"frozen-inputs/index.json")
    assert set(index)==set(reg["hashes"])
    for path,entry in index.items():
        assert entry["sha256"]==reg["hashes"][path]==sha(ROOT/"frozen-inputs"/entry["payload"])
    result=load(ROOT/"controls/results.json")
    assert result["qualified"] is True and result["error"] is None
    assert result["paid_admission"] is False and result["provider_calls"]==0
    assert [row["cell"] for row in result["rows"]]==q.ORDER
    daemon=subprocess.run(["docker","ps","-a","--no-trunc","--format","{{.ID}}"],
                          capture_output=True,text=True,timeout=30)
    assert daemon.returncode==0,daemon.stderr
    live=set(daemon.stdout.splitlines())
    summaries=[];outcomes={};hashes={}
    for row in result["rows"]:
        cell=row["cell"];label,name=cell.split("-");task=reg["tasks"][label]
        out=ROOT/"controls"/cell;receipt=row["receipt"]
        assert receipt==load(out/"receipt.json")
        raw=load(out/"raw.json");runtime=load(out/"runtime.json")
        assert raw==receipt["raw"] and runtime==receipt["runtime"]
        assert raw["container_removed"] is True and raw["oom_killed"] is False
        assert raw.get("error") is None and raw.get("infra") is None
        samples=[json.loads(line) for line in Path(runtime["samples"]).read_text().splitlines()]
        assert len(samples)==runtime["cgroup_probes"]>=2
        assert samples[0]["phase"]=="initial" and samples[-1]["phase"]=="final"
        assert all(s["phase"]=="periodic" for s in samples[1:-1])
        times=[s["time"] for s in samples]
        assert times==sorted(times)
        for sample in samples:
            assert "error" not in sample
            assert sample["container"]==runtime["container"]
            assert all(sample["host"][key]>=value for key,value in reg["floors"].items())
            profile=sample["profile"]
            assert profile=={"id":runtime["container"],"image":task["image"],"memory":8*1024**3,
                             "cpus":4*10**9,"network":"none","running":True,"oom":False}
            events=sample["memory_events"]
            assert events["oom_kill"]==0 and events.get("oom_group_kill",0)==0
            assert all(type(v) is int and v>=0 for v in events.values())
        assert runtime["complete"] is True and runtime["resource_ok"] is True
        assert runtime["errors"]==[] and runtime["oom_kill"]==0
        absence=load(out/"absence.json")
        assert absence["returncode"]==0 and absence["stdout"].strip()=="" and absence["absent"] is True
        assert receipt["independently_absent"] is True and runtime["container"] not in live
        log=Path(raw["log"]);full=log.with_name("grade.json")
        record=load(task["record"]);bundle=load(task["bundle"])
        f2p,p2p=q.tasks.expected_sets(record,bundle)
        assert (f2p,p2p)==(task["f2p"],task["p2p"])
        policy=q.policy.adjudicate_private(raw,load(full),record,bundle,log=log.read_text(),runtime=runtime)
        assert policy==receipt["policy"] and policy["valid"] is True
        statuses=policy["statuses"]
        assert set(statuses)==set(f2p+p2p)
        assert policy["pass"] is (name!="negative")
        assert policy["adjusted"]["missing"]==0
        if name=="negative":
            assert all(statuses[key]!="pass" for key in f2p)
        else:
            assert all(statuses[key]=="pass" for key in f2p+p2p)
        outcomes[cell]=statuses
        hashes.update({str(p):sha(p) for p in (log,full,out/"raw.json",out/"runtime.json",
                                               out/"receipt.json",out/"absence.json",Path(runtime["samples"]))})
        summaries.append({"cell":cell,"valid":policy["valid"],"pass":policy["pass"],
             "expected_keys":len(f2p+p2p),"f2p_pass":sum(statuses[k]=="pass" for k in f2p),"f2p_keys":len(f2p),
             "p2p_pass":sum(statuses[k]=="pass" for k in p2p),"p2p_keys":len(p2p),
             "raw_missing":policy["raw"]["missing"],"adjusted_missing":policy["adjusted"]["missing"],
             "recovered_keys":len(policy["recovered"]),"cgroup_samples":len(samples),
             "max_sample_gap_seconds":max(b-a for a,b in zip(times,times[1:])),
             "sampled_min_host_gib":{k:min(s["host"][k] for s in samples) for k in reg["floors"]},
             "oom_kill":runtime["oom_kill"],"independently_absent_now":True,"wall_seconds":raw["wall_seconds"]})
    verdicts={}
    for label,task in reg["tasks"].items():
        assert outcomes[label+"-gold"]==outcomes[label+"-repeat"]
        verdict=q.grade.control_verdict(outcomes[label+"-negative"],outcomes[label+"-gold"],
                                        task["f2p"],task["p2p"],outcomes[label+"-repeat"])
        assert verdict["ok"] is True
        verdicts[label]=verdict
    q.preflight(reg)
    output={"scope":"Closed native controls audit; raw policies recomputed without native/model reruns.",
            "registration_sha256":sha(ROOT/"registration.json"),"source_commit":reg["source_commit"],
            "bound_paths_rehashed":len(reg["hashes"]),"frozen_copy_paths_verified":len(index),
            "qualified":True,"paid_admission":False,"provider_calls":0,"rows":summaries,
            "control_verdicts":verdicts,"closed_evidence_hashes":hashes,
            "limits":"Host/cgroup health is sampled, not continuous. Qualification is these two tasks/profile only."}
    with (ROOT/"closed-audit.json").open("x") as stream:
        stream.write(json.dumps(output,indent=2)+"\n")
    print(json.dumps({k:v for k,v in output.items() if k!="closed_evidence_hashes"},indent=2))
if __name__=="__main__":main()
