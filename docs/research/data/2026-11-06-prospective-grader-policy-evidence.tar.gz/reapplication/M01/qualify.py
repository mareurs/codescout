"""Fixed native control qualification; refuses work until implemented."""
import hashlib
import json
from pathlib import Path
import argparse
import re
import shutil
import sys
import threading
import time
from unittest import mock
TOOLS=Path(__file__).parent / "tools"
sys.path.insert(0,str(TOOLS))
import grade_policy as policy
import multilang_grade as grade
import multilang_tasks as tasks
import pilot
PROFILE='{"id":{{json .Id}},"image":{{json .Image}},"memory":{{.HostConfig.Memory}},"cpus":{{.HostConfig.NanoCpus}},"network":{{json .HostConfig.NetworkMode}},"running":{{.State.Running}},"oom":{{.State.OOMKilled}}}'

def save(path,obj):
    path=Path(path)
    temporary=path.with_suffix(path.suffix+".pending")
    temporary.write_text(json.dumps(obj,indent=2)+"\n")
    temporary.replace(path)

def host_sample():
    mem={}
    for line in Path("/proc/meminfo").read_text().splitlines():
        key,value=line.split(":",1)
        mem[key]=int(value.strip().split()[0])
    return {"root_gib":shutil.disk_usage("/").free/1024**3,
            "tmp_gib":shutil.disk_usage("/tmp").free/1024**3,
            "mem_gib":mem["MemAvailable"]/1024**2}

def native_attempt(label,name,task,out):
    original=pilot.docker
    h=host_sample()
    if any(h[k]<v for k,v in FLOORS.items()):
        raise ValueError("host floor before container start")
    bundle=json.loads(Path(task["bundle"]).read_text())
    record=json.loads(Path(task["record"]).read_text())
    f2p,p2p=tasks.expected_sets(record,bundle)
    if (f2p,p2p)!=(task["f2p"],task["p2p"]):
        raise ValueError("expected-set mismatch")
    mon=ResourceMonitor(original,task["image"],out/"resource-samples.jsonl")
    fn=tasks.live_grader(record,bundle,task["image"],out/"grader")
    patch="" if name=="negative" else Path(task["gold"]).read_text()
    try:
        with mock.patch.object(pilot,"docker",mon.boundary):
            raw=fn(patch,name)
    finally:
        if not mon.finished:mon.finish()
    save(out/"raw.json",raw)
    proof=mon.proof()
    query=original("ps","-a","--no-trunc","--filter","id="+str(mon.cid),
                   "--format","{{.ID}}",check=False,timeout=30)
    absent=query.returncode==0 and not query.stdout.strip() and mon.cid is not None
    save(out/"absence.json",{"returncode":query.returncode,"stdout":query.stdout,"absent":absent})
    if not absent:
        proof["errors"].append("independent daemon/container absence unconfirmed")
        proof["resource_ok"]=False
    save(out/"runtime.json",proof)
    log=Path(raw["log"]).read_text()
    full=json.loads(Path(raw["log"]).with_name("grade.json").read_text())
    adjudicated=policy.adjudicate_private(raw,full,record,bundle,log=log,runtime=proof)
    return {"raw":raw,"runtime":proof,"policy":adjudicated,"independently_absent":absent}

FLOORS={"root_gib":80,"tmp_gib":4,"mem_gib":48}
ORDER=["NU-negative","RA-negative","NU-gold","RA-gold","NU-repeat","RA-repeat"]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def preflight(reg):
    if reg["version"] != 1 or reg["order"] != ORDER or reg["floors"] != FLOORS:
        raise ValueError("registration version/order/floors changed")
    if set(reg["tasks"]) != {"NU","RA"} or not reg["hashes"]:
        raise ValueError("registration tasks/hashes incomplete")
    for path,digest in reg["hashes"].items():
        if sha(path) != digest:
            raise ValueError("bound bytes changed: "+path)
    for task in reg["tasks"].values():
        expected=task["f2p"]+task["p2p"]
        if not task["f2p"] or len(set(expected)) != len(expected):
            raise ValueError("empty or ambiguous expected set")
    return True
def run(reg,out,attempt):
    preflight(reg)
    out=Path(out)
    out.mkdir()
    save(out/"started.json",{"time":time.time(),"order":ORDER})
    save(out/"registration.json",reg)
    result={"qualified":False,"paid_admission":False,"provider_calls":0,"rows":[],"error":None}
    outcomes={}
    try:
        for item in ORDER:
            preflight(reg)
            label,name=item.split("-")
            task=reg["tasks"][label]
            cell=out/item
            cell.mkdir()
            receipt=attempt(label,name,task,cell)
            save(cell/"receipt.json",receipt)
            result["rows"].append({"cell":item,"receipt":receipt})
            preflight(reg)
            policy=receipt["policy"]
            if policy.get("valid") is not True:
                raise ValueError(item+": invalid measurement")
            statuses=policy.get("statuses",{})
            expected=task["f2p"]+task["p2p"]
            if set(statuses)!=set(expected) or any(v not in ("pass","fail","skip") for v in statuses.values()):
                raise ValueError(item+": incomplete expected statuses")
            if name=="negative":
                if policy["pass"] is not False or any(statuses[k]=="pass" for k in task["f2p"]):
                    raise ValueError(item+": negative fails to discriminate")
            elif policy["pass"] is not True or any(statuses[k]!="pass" for k in expected):
                raise ValueError(item+": gold fails selected expected tests")
            outcomes[item]=statuses
            if name=="repeat" and statuses!=outcomes[label+"-gold"]:
                raise ValueError(item+": repeat differs")
            save(out/"results.json",result)
            print(json.dumps({"cell":item,"valid":True,"pass":policy["pass"]}),flush=True)
        for label,task in reg["tasks"].items():
            verdict=grade.control_verdict(outcomes[label+"-negative"],outcomes[label+"-gold"],
                                          task["f2p"],task["p2p"],outcomes[label+"-repeat"])
            if not verdict["ok"]:
                raise ValueError(str(verdict))
        preflight(reg)
        result["qualified"]=True
    except Exception as exc:
        result["error"]=type(exc).__name__+": "+str(exc)
    finally:
        save(out/"results.json",result)
    return result
class ResourceMonitor:
    def __init__(self,docker,image,path,*,host=None,interval=10):
        self.docker=docker
        self.image=image
        self.path=Path(path)
        self.host=host or host_sample
        self.interval=interval
        self.cid=None
        self.name=None
        self.errors=[]
        self.probes=0
        self.oom=0
        self.finished=False
        self.killed=False
        self.stop=threading.Event()
        self.thread=None

    def fault(self,message):
        self.errors.append(str(message))
        if self.cid and not self.killed:
            self.killed=True
            try:
                p=self.docker("kill",self.cid,check=False,timeout=20)
                if p.returncode:self.errors.append("owned container kill failed: "+p.stdout[-300:])
            except Exception as exc:
                self.errors.append("owned container kill failed: "+str(exc))

    def attach(self,cid,name):
        if self.cid or not re.fullmatch(r"[0-9a-f]{64}",cid) or not name.startswith("sab-grade-"):
            raise ValueError("unknown or second container")
        self.cid,self.name=cid,name
        self.sample("initial")
        if not self.errors:
            self.thread=threading.Thread(target=self.watch,daemon=True)
            self.thread.start()

    def sample(self,phase):
        row={"time":time.time(),"phase":phase,"container":self.cid}
        try:
            h=self.host()
            row["host"]=h
            if any(type(h.get(k)) not in (int,float) or h[k]<v for k,v in FLOORS.items()):
                raise ValueError("host resource floor violated")
            p=self.docker("inspect","--format",PROFILE,self.cid,check=False,timeout=20)
            if p.returncode:raise ValueError("container profile observation failed")
            info=json.loads(p.stdout)
            row["profile"]=info
            if (info["id"]!=self.cid or info["image"]!=self.image or info["memory"]!=8*1024**3
                    or info["cpus"]!=4*10**9 or info["network"]!="none"
                    or info["running"] is not True or info["oom"] is not False):
                raise ValueError("native image/profile/state mismatch")
            p=self.docker("exec",self.cid,"cat","/sys/fs/cgroup/memory.events",check=False,timeout=20)
            if p.returncode:raise ValueError("cgroup observation failed")
            events={k:int(v) for k,v in (line.split() for line in p.stdout.splitlines())}
            if "oom_kill" not in events or any(v<0 for v in events.values()):
                raise ValueError("missing or invalid cgroup counters")
            row["memory_events"]=events
            self.probes+=1
            self.oom=max(self.oom,events["oom_kill"]+events.get("oom_group_kill",0))
            if self.oom:raise ValueError("cgroup OOM kill observed")
        except Exception as exc:
            row["error"]=type(exc).__name__+": "+str(exc)
            self.fault(row["error"])
        finally:
            try:
                with self.path.open("a") as stream:
                    stream.write(json.dumps(row)+"\n")
                    stream.flush()
            except Exception as exc:
                self.fault("cannot persist resource sample: "+str(exc))

    def watch(self):
        while not self.stop.wait(self.interval):
            self.sample("periodic")
            if self.errors:return

    def finish(self):
        self.stop.set()
        if self.thread:
            self.thread.join(timeout=65)
            if self.thread.is_alive():
                self.fault("resource monitor did not stop")
                return
        if self.cid:self.sample("final")
        self.finished=True

    def proof(self):
        return {"complete":self.finished and self.cid is not None,
                "resource_ok":not self.errors and self.probes>=2,
                "cgroup_probes":self.probes,"oom_kill":self.oom,"errors":self.errors[:],
                "container":self.cid,"samples":str(self.path)}

    def boundary(self,*args,**kwargs):
        if args[0]=="run":
            if self.cid:raise RuntimeError("second container in one attempt")
            name=args[args.index("--name")+1]
            p=self.docker(*args,**kwargs)
            self.attach(p.stdout.strip(),name)
            if self.errors:raise RuntimeError("resource start invalid")
            return p
        if args[0]=="rm":
            if self.cid and self.name in args:self.finish()
        return self.docker(*args,**kwargs)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--registration",required=True)
    parser.add_argument("--out",required=True)
    args=parser.parse_args()
    reg=json.loads(Path(args.registration).read_text())
    result=run(reg,args.out,native_attempt)
    print(json.dumps({"qualified":result["qualified"],"error":result["error"]}),flush=True)
    return 0 if result["qualified"] else 1

if __name__=="__main__":
    raise SystemExit(main())
