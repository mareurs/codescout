"""Archive closed prospective qualification evidence and verify every payload."""
import hashlib
import io
import json
from pathlib import Path
import tarfile
ROOT=Path(__file__).parent
MAIN=Path("/home/marius/work/claude/codescout")
def digest(data):return hashlib.sha256(data).hexdigest()
def main():
    final=ROOT/"controls/results.json"
    if not final.is_file():
        raise ValueError("no closed native result; preserve live scratch")
    result=json.loads(final.read_text())
    if len(result["rows"])<6 and result.get("error") is None:
        raise ValueError("controls not closed")
    files={}
    for path in ROOT.rglob("*"):
        if path.is_file() and not any(p in ("__pycache__",".pytest_cache") for p in path.relative_to(ROOT).parts):
            if path.name not in ("archive-receipt.json",):
                files[path.relative_to(ROOT).as_posix()]=path
    payloads={name:path.read_bytes() for name,path in files.items()}
    manifest={name:digest(data) for name,data in payloads.items()}
    target=MAIN/"docs/research/data/2026-11-06-prospective-grader-policy-evidence.tar.gz"
    if target.exists():raise FileExistsError(target)
    with tarfile.open(target,"w:gz") as archive:
        for name,data in sorted(payloads.items()):
            info=tarfile.TarInfo(name);info.size=len(data)
            archive.addfile(info,io.BytesIO(data))
        data=(json.dumps(manifest,indent=2)+"\n").encode()
        info=tarfile.TarInfo("EVIDENCE-MANIFEST.json");info.size=len(data)
        archive.addfile(info,io.BytesIO(data))
    verified={}
    with tarfile.open(target,"r:gz") as archive:
        names=archive.getnames()
        if len(names)!=len(set(names)) or set(names)!=set(payloads)|{"EVIDENCE-MANIFEST.json"}:
            raise ValueError("archive member set mismatch")
        frozen=json.loads(archive.extractfile("EVIDENCE-MANIFEST.json").read())
        for name,wanted in frozen.items():
            actual=digest(archive.extractfile(name).read())
            if actual!=wanted:raise ValueError("payload digest mismatch:"+name)
            verified[name]=actual
    if verified!=manifest:raise ValueError("archive manifest mismatch")
    receipt={"path":str(target),"sha256":digest(target.read_bytes()),"bytes":target.stat().st_size,
             "verified_payloads":len(verified),"manifest_verified":True,
             "qualified":result["qualified"],"provider_calls":0}
    (ROOT/"archive-receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
    print(json.dumps(receipt))
if __name__=="__main__":main()
