# SDD ledger — plan: docs/superpowers/plans/2026-11-06-prospective-grader-policy.md

## Closure — native qualification passed, 2026-11-06

Nativejob137 CLOSED0 at19:00:57.811455543UTC after start18:22:12.187953454UTC. Exact6fixedattempts only, 0provider/modelruns. Both negatives valid and allF2Pfail: NU0/2F2P+8620/8620P2Ppass; RA0/1F2P+8181/8181P2Ppass. Gold/repeat eachallselectedpass: NU8622,RA8182; selectedstatusmapsidentical. NUrepeatrawmissing1 recoveredexactexpectedP2Ppassfromphysicalgluedline3725; rawreceipts/logsunchanged. Allotherrawmissing0; adjustedmissing0all6.

check_closed.py independently recomputed all6 policies from fullgrade.json/rawlogs and compared savedreceipts, reopened/rehashed80boundpaths+80frozencopies, checkedEVERYinitial/periodic/final sample and freshdaemonabsence for6CIDs, zeroOOMkills. ActualsamplecountsNU63/60/60,RA16/18/18; hostminima root297.907GiB,tmp25.2527GiB,MemAvailable76.224GiB, allabovefloors80/4/48. Samplinggapsmax11.0552seconds, notcontinuousassurance/reservation. Bothactualcontrol_verdicts ok/no goldrepeatmismatch. SourceHEAD867c680924cb75575bec7ccd7068b8dfd7fd5889 andcleanworktreeobserved. Allproof in closed-audit.json; archive.py follows thisledgerclosure.

PrivategradingqualifiedONLYforthese2tasks/exactimages/profile/source/registration. Public/paidadapterstillabsent, no paidpilotadmission, mechanismEFFECTUNMEASURED. No further native reruns needed for this question. Preserveworktree/branches/oldcohorts; no merge/push. Nextactualpaid/publicadapter thenfixedsixpilot; no newonboarding/wirefixtureloop.

## Prior checkpoint — native controls were running

Source867c680924cb75575bec7ccd7068b8dfd7fd5889, patch-id8aaef7e82bf4106b5be13beff64238d89b3d2a6c. Cleanisolatedbranch; exactly2newproductfilescommitted, nomerge/push. Finalexpandedtargeted393tests138subtestsPASS, finalgate133CLOSED0/all5lanes0/122s. Pythonlight1642tests529subtestsseparatescopeandexclusionsretained. Freshreview10actualmutants5killed5survived,2Importantfindingsfiled. Oneofflinefixpass tailguardRED→GREEN/newnativeintegrationtests; exact10reapplicationall10killed0survivors/noresite/byte-restored. Verifiedpytestsummaryinstrument, nothelperexitonly. Reviewer1340payloadspreservedbyte-equal.

Registrationddadac4045041a8344077f2d78a61e49dae12998d86ff7360fff09952a4a3fc5 binds80paths, allcopiesreopened/hashverified. Nativecontroller@bg_00000137 PID2404301, started2026-11-06T18:22:12UTC; record/tmp/codescout-bg/455879-a720241d-bg_00000137.json. OutputsROOT/controls andcontrols.log. FixedorderNUnegative,RAnegative,NUgold,RAgold,NUrepeat,RArepeat; NEVERrestartsameoutputorresample. FirstNUnegative initial+periodic exactprofile4CPU8GiB/networknone/resourcefloors/zeroOOMobserved; nooutcomeyet. Paid/publicworkflowintegrationfalse, provider/modelcalls0. Finalnativeverdict+archive/reportclosurepending.

Final: fixed e19645fa20fdee4e — test_full_step_tails_are_required_even_when_statuses_are_complete observedRED1failed18passed33subtests, then32tests53subtestsGREEN andexpanded393/138GREEN.

Final: fixed57f3dd31357ba64c — fiveactualsurvivorsM06–M10observedbeforetestaddition, nowallfiveexactcandidateskilledbydirectnative_attempt/boundarytests; no secondreview. NoCritical/minors/declinedwithinscope. NoadditionalRulings.

## Historical execution ledger — superseded status below

Plan93c543c96e2d7766; approved overarching spec28aab59cb5842630 with declared Prospective policy v1. User go/autonomy retained. Existing isolated grader worktree basea2ffc1432 clean before new source files, no merge/push.

Pre-flight interfaces: Task1 adjudicate_private accepts full grade evidence plus exact runtime proof; Task2 reads saved grade.json full steps (raw result strips metadata). Task3 consumes frozen source/inputs and observed runtime only. No actor/adapter/paid entry delivered in this plan.

Ruling: keep private4CPU8GiB profile unchanged; public native32GiB is separate. Source/raw parser/expected set/test commands/images reused exactly, new explicit policy declared before controls. Cost if wrong: fail new registration, no retrospective correction/retry.

Task1: initial safe no-op14 tests8failed6passed/23subtests. First implementation14passed. Offline four-log calibration exposed663cf412ab711c0a; footer-only exclusion insufficient, physical debug error field false compiler classification. Added3debugvariants observed RED before preserving physical indentation and requiring diagnostic evidence. Final policy17passed29subtests. Calibration-v3 all4expectedkinds match; runtime is explicitly synthetic fixture, no native qualification. Both failed earlier calibrations retained. All17 old protected files unchanged.

Task2: private runner safe no-op observed15fail3pass including subtest outcomes; implemented fixed six order, source hashes each boundary, negative/gold/repeat completeness, single-use output marker, sampled host/cgroup exact owned container and independent absence. Deterministic runner9passed9subtests. Builder real-manifest test observed TypeError first (ccebd6842eda67fd), then fixed digest-string schema. Combined policy/prior grader/runner suite254passed123subtests, logtargeted-before-review-v2.log. No native control/provider started.

Ruling: required review-package script a2ffc1432..HEAD refuses empty commit range (exit3), because new product files intentionally remain untracked until verification. Freeze actual source/test/private bytes into review/manifest.json (68payloads) and review-package.md; do not create an unverified commit just to satisfy the range helper. Cost if wrong: review misses a copied delta; manifest and explicit delta list address that risk.

Full gate @bg_0000012f running, record/tmp/codescout-bg/455879-a720241d-bg_0000012f.json; loggate-before-review.log. One fresh reviewer now allowed by executing-plans; actual mutations must run only on copies, never original source/cohorts. One offline fix pass afterwards, no re-review.
