# Grader regression-count review

Verdict: accepted for the exact two-file delta against base 2fbbce1cbabff4ba743ab1d41512a284fe8b550d. No Critical or Important findings in this finite review.

Accepted paths and hashes are in source-hashes.json. V remained read-only; mutations ran only in the private work/ copy. The sealed cohort ledger and archive were not changed. Full gate and sealed-log adjudication remain executor responsibilities.

## Evidence

The pilot baseline ran 30 unittest methods and passed. Five distinct mutations were actually applied; all five were killed by test assertion failures, zero survived. Each mutation has an exact patch, full log, result JSON and hash-verified restoration.

1. g01_original_callsite restores the original substring predicate at grade:142. Killed by eight failing subtests, including 10/20/40/100 positive pass counts.
2. g02_allow_zero changes the positive-count summary parser to admit zero. Killed by the zero-summary case.
3. g03_skip_summary_count removes corroboration of the summary integer. Killed by mismatched named-pass count and summary-only evidence cases.
4. g04_skip_duplicate_check removes unique-name enforcement. Killed by the repeated-name case.
5. g05_bypass_helper_call makes regression validity unconditional at grade:142. Killed by ten negative-evidence subtests, demonstrating the tests exercise the actual grading call site.

These are observed results, not a claimed coverage percentage. No syntax/import failure was counted as a kill.

## Findings and strengths

No unresolved findings. tools/hint_authority_pilot/prepare.py:106 now parses exactly one anchored successful summary with a positive integer and zero failures, then corroborates it against the total and unique named passing lines. This avoids the suffix collision in the old predicate while rejecting absent, inconsistent and duplicated execution evidence.

tools/hint_authority_pilot/test_grader.py:19 invokes grade with its external process boundary mocked; the new tests therefore cover the grading decision and step result rather than only the helper. The complete two-file diff leaves acceptance_executed and the existing process-exit handling unchanged.

## Declined to judge

- Baseline test-name preservation in sealed cohort logs: executor owns the separate replay/adjudication. This predicate establishes execution consistency, not identity against an external baseline population.
- Actual model or native runtime behavior: unchanged and outside this grader-only review.
- Generic model quality or revised campaign outcome claims: no such claim follows from these unit tests.
- Full gate, commit and archival adjudication publication: executor responsibilities; not independently performed here.

No Docker, provider, real credential or qualifier calls were performed. No broader campaign/runtime review or mutation expansion was performed.

Ledger checked: 241d6eb64c605b37.
