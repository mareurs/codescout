"""Supplementary sealed-log adjudication; never changes the original ledger or executes model/tests."""
import hashlib,io,json,pathlib,re,subprocess,sys,tarfile
from decimal import Decimal
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
M=pathlib.Path("/home/marius/work/claude/codescout")
R=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/action-budget-adjudication-20261105")
A=M/"docs/research/data/2026-11-05-action-budget-final-evidence.tar.gz"
EXPECTED="5a9c571c6d1d926a645d0409a3910f7766fa246debb59d49198eafa7176d14b8"
sys.path.insert(0,str(V/"tools/hint_authority_pilot"))
import prepare
def sha(b):return hashlib.sha256(b).hexdigest()
def names(text):return set(re.findall(r"^test (\S+) \.\.\. ok$",text,re.M))
def analyze():
    assert not R.exists();assert sha(A.read_bytes())==EXPECTED
    with tarfile.open(A,"r:gz") as tf:
        manifest=json.load(tf.extractfile("manifest.json"))
        assert len(tf.getnames())==len(manifest)+1 and set(tf.getnames())==set(manifest)|{"manifest.json"}
        data={}
        for name,h in manifest.items():
            b=tf.extractfile(name).read();assert len(b)==h["bytes"] and sha(b)==h["sha256"],name
            data[name]=b
    assert len(data)==866
    ledger=json.loads(data["campaign/results.json"])
    raw=json.loads(data["campaign/independent-paid-readback.json"])
    assert raw["verified"] and raw["completed_workflows"]==2 and ledger["cost_is_final"]
    controls=json.loads(data["campaign/acceptance-controls.json"])
    reference_only={"librarian::catalog::chunk::tests::a_line_offset_shifts_every_range_and_moves_no_entry_token",
        "librarian::indexer::tests::a_stored_chunks_range_points_at_that_text_in_the_file"}
    R.mkdir();required={};control_rows=[]
    for control in controls["controls"]:
        observed=[]
        for i,step in enumerate(control["grade"]["steps"]):
            b=pathlib.Path(step["log"]).read_bytes();text=b.decode(errors="replace")
            (R/f"control-{control['kind']}-{i}.log").write_bytes(b)
            good=prepare.acceptance_executed(text) if i==0 else prepare.regression_executed(text)
            observed.append(step["process_exit"]==0 and good)
            if control["kind"]=="positive":required[step["filter"]]=names(text)-reference_only
        passed=all(observed)
        assert passed==(control["kind"]=="positive"),control["kind"]
        control_rows.append(dict(kind=control["kind"],accepted_by_corrected_predicate=passed))
    rows=[]
    for i,effort in enumerate(("low","xhigh")):
        row=ledger["results"][i];out="campaign/workflow-"+str(i)+"-"+effort
        receipt=json.loads(data[out+"/receipt.json"])
        assert row["effort"]==effort and row["declaration"] is False and receipt["workflow_completed"]
        assert receipt["lifecycle"]["status"]=="settled" and receipt["public_verification"]["passed"]
        assert len(receipt["public_verification"]["checks"])==4 and all(s["exit_code"]==0 for s in receipt["public_verification"]["checks"])
        steps=[]
        for j,step in enumerate(row["grade"]["steps"]):
            name="campaign/"+pathlib.Path(step["log"]).name;b=data[name];text=b.decode(errors="replace")
            good=prepare.acceptance_executed(text) if j==0 else prepare.regression_executed(text)
            missing=required[step["filter"]]-names(text)
            assert not missing,(effort,step["filter"],missing)
            (R/f"{effort}-private-{j}.log").write_bytes(b)
            steps.append(dict(filter=step["filter"],process_exit=step["process_exit"],recorded_witness=step["execution_witness"],
                corrected_witness=good,passed_named_tests=len(names(text)),missing_required=sorted(missing),log_sha256=sha(b)))
        assert len(steps)==3
        corrected=receipt["workflow_completed"] and all(s["process_exit"]==0 and s["corrected_witness"] and not s["missing_required"] for s in steps)
        assert corrected
        rows.append(dict(effort=effort,recorded_accepted=row["accepted"],corrected_functional_acceptance=corrected,
            cost_usd=row["cost_usd"],workflow_wall_s=receipt["wall_s"],requests=receipt["requests"],private_checks=steps))
    assert [r["recorded_accepted"] for r in rows]==[True,False]
    low,high=(Decimal(r["cost_usd"]) for r in rows)
    source_hashes={}
    for rel in ("tools/hint_authority_pilot/prepare.py","tools/hint_authority_pilot/test_grader.py"):
        b=(V/rel).read_bytes();source_hashes[rel]=sha(b)
        (R/pathlib.Path(rel).name).write_bytes(b)
    result=dict(verified=True,scope="Posthoc corrected interpretation of existing sealed logs; original registration/ledger/acceptance flags unchanged",
        original_archive=str(A),original_archive_sha256=EXPECTED,verified_original_payload_files=len(data),
        original_model_source_commit="2fbbce1cbabff4ba743ab1d41512a284fe8b550d",
        adjudicator_source_hashes=source_hashes,adjudicator_script_sha256=sha(pathlib.Path(__file__).read_bytes()),
        controls=control_rows,results=rows,new_provider_calls=0,new_model_cost_usd="0",
        closed_pair_model_cost_usd=ledger["new_cost_usd"],cumulative_known_model_cost_usd=ledger["thread_cost_usd"],
        xhigh_to_low_cost_ratio=str(high/low),low_cost_reduction_fraction=str(1-low/high),
        limitation="One exposed task/fixed order/no treatment ablation; does not establish generic low/xhigh parity or causal attribution.")
    (R/"adjudication.json").write_text(json.dumps(result,indent=2)+"\n")
    (R/"adjudicator.py").write_bytes(pathlib.Path(__file__).read_bytes())
    print(json.dumps(result,indent=2),flush=True)
def seal():
    result=json.loads((R/"adjudication.json").read_text())
    for rel,want in result["adjudicator_source_hashes"].items():assert sha((V/rel).read_bytes())==want
    gate_path=pathlib.Path("/tmp/codescout-bg/455879-a720241d-bg_00000083.json")
    gate=json.loads(gate_path.read_text());assert gate["state"]=="exited" and gate["exit_code"]==0
    review=pathlib.Path("/tmp/grader-count-review-01a15ca9-20261105")
    binding=json.loads((review/"review-binding.json").read_text())
    assert binding["accepted"] and binding["source_hashes"]==result["adjudicator_source_hashes"]
    assert sha((review/"review.md").read_bytes())==binding["review_report_sha256"]
    assert not subprocess.check_output(["git","-C",str(V),"status","--porcelain"],text=True)
    commit=subprocess.check_output(["git","-C",str(V),"rev-parse","HEAD"],text=True).strip()
    assert commit!=result["original_model_source_commit"]
    paths=subprocess.check_output(["git","-C",str(V),"diff-tree","--no-commit-id","--name-only","-r","HEAD"],text=True).splitlines()
    assert set(paths)==set(binding["source_hashes"])
    (R/"fix-provenance.json").write_text(json.dumps(dict(commit=commit,gate=gate,review_binding=binding),indent=2)+"\n")
    payload={p.name:p.read_bytes() for p in R.iterdir() if p.is_file()}
    for p in review.iterdir():
        if p.is_file():payload["review/"+p.name]=p.read_bytes()
    for name in ("grader-count-red-01a15ca9-20261105.log","grader-count-red-final-01a15ca9-20261105.log","grader-count-green-01a15ca9-20261105.log"):
        payload["tests/"+name]=(pathlib.Path("/tmp")/name).read_bytes()
    payload["gate/record.json"]=gate_path.read_bytes();payload["gate/output.log"]=pathlib.Path(gate["log_path"]).read_bytes()
    manifest={n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(payload.items())}
    archive=M/"docs/research/data/2026-11-05-action-budget-adjudication-evidence.tar.gz";assert not archive.exists()
    with tarfile.open(archive,"x:gz") as tf:
        for name,b in payload.items():
            info=tarfile.TarInfo(name);info.size=len(b);tf.addfile(info,io.BytesIO(b))
        b=(json.dumps(manifest,indent=2)+"\n").encode();info=tarfile.TarInfo("manifest.json");info.size=len(b);tf.addfile(info,io.BytesIO(b))
    with tarfile.open(archive,"r:gz") as tf:
        for name,h in manifest.items():assert sha(tf.extractfile(name).read())==h["sha256"]
    sealed=dict(archive=str(archive),sha256=sha(archive.read_bytes()),payload_files=len(payload),every_payload_hash_verified=True,fix_commit=commit)
    (M/"docs/research/data/2026-11-05-action-budget-adjudication-archive.json").write_text(json.dumps(sealed,indent=2)+"\n")
    print(json.dumps(sealed),flush=True)
if __name__=="__main__":
    if sys.argv[1:]==["--analyze"]:analyze()
    elif sys.argv[1:]==["--seal"]:seal()
    else:raise ValueError("Choose --analyze or --seal")
