"""Observe the already-authorized job, then verify/archive it once. Never starts model runs."""
import json,pathlib,subprocess,time
R=pathlib.Path(__file__).resolve().parent
JOB=pathlib.Path("/tmp/codescout-bg/455879-a720241d-bg_0000007f.json")
CAPTURE=pathlib.Path("/tmp/capture-action-native-01a15ca9-20261105.py")
VERIFY=pathlib.Path("/tmp/verify-action-pair-01a15ca9-20261105.py")
ARCHIVE=pathlib.Path("/tmp/preserve-action-pair-01a15ca9-20261105.py")
def main():
    deadline=time.monotonic()+10800;sampled=set()
    while time.monotonic()<deadline:
        state=json.loads(JOB.read_text())
        if state["state"]=="exited":break
        if state["state"]!="running":raise RuntimeError("Paid job did not remain observable: "+state["state"])
        pending=[r for r in R.glob("workflow-[01]-*") if r.is_dir() and not r.name.endswith("-grader")
            and r.name not in sampled and list(r.glob("mcp-launch-*.json"))]
        if pending:
            probe=subprocess.run(["python3",str(CAPTURE)],check=True,capture_output=True,text=True,timeout=30)
            result=json.loads(probe.stdout);sampled.update(result["attempts"])
            print(json.dumps(dict(native_sample=result)),flush=True)
        time.sleep(10)
    else:raise TimeoutError("Observation window expired; paid job left unchanged")
    if state["exit_code"]!=0:raise RuntimeError("Paid job closed with nonzero status; preserve raw partial evidence without retry")
    verified=subprocess.run(["python3",str(VERIFY)],capture_output=True,text=True,timeout=120)
    (R/"independent-readback.stdout").write_text(verified.stdout)
    (R/"independent-readback.stderr").write_text(verified.stderr)
    if verified.returncode:raise RuntimeError("Independent readback failed; no completion/archive claim")
    archived=subprocess.run(["python3",str(ARCHIVE),"final"],capture_output=True,text=True,timeout=120)
    (R/"archive.stdout").write_text(archived.stdout);(R/"archive.stderr").write_text(archived.stderr)
    if archived.returncode:raise RuntimeError("Final evidence archive failed")
    receipt=dict(finalized=True,paid_job=str(JOB),sampled_attempts=sorted(sampled),
        archive=json.loads(archived.stdout),scope="Post-run read-only measurements and bounded evidence preservation; no provider or paid retry.")
    with (R/"finalization.json").open("x") as f:json.dump(receipt,f,indent=2);f.write("\n")
    print(json.dumps(receipt),flush=True)
if __name__=="__main__":main()
