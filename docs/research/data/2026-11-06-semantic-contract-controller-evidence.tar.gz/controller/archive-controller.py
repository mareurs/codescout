"""Archive bounded controller evidence without running an actor or changing a cohort."""
import hashlib, io, json, pathlib, sys, tarfile
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/semantic-contract-controller-20261106")
REVIEW=pathlib.Path("/tmp/semantic-contract-controller-review-20261106")
MAIN=pathlib.Path("/home/marius/work/claude/codescout")
OUT=MAIN/"docs/research/data/2026-11-06-semantic-contract-controller-evidence.tar.gz"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    if OUT.exists() or OUT.with_suffix(".json").exists(): raise ValueError("Refuse overwrite")
    sys.path.insert(0,str(ROOT))
    import campaign
    reg=json.loads((ROOT/"post-review/registration.json").read_text())
    checks=[]
    for mapping in [reg["shared_hashes"]]+[r[k] for r in reg["arms"] for k in ("immutable_hashes","writable_hashes")]:
        campaign.check_hashes(mapping);checks.append(len(mapping))
    for row in reg["arms"]:
        campaign.future_population(row)
        for name in ("started.json","launch.json","receipt.json","cost-reconciled.json"):
            if (pathlib.Path(row["out"])/name).exists():raise ValueError("Actual arm started")
    protected=json.loads((ROOT.parent/"semantic-contract-plugin-binding-20261106/registration.json").read_text())["prepared_hashes"]
    campaign.check_hashes(protected)
    calibration=json.loads((ROOT/"closed-receipt-calibration.json").read_text())
    campaign.check_hashes(calibration["original_file_hashes"])
    if not calibration["all_four_match"]:raise ValueError("Cost calibration failed")
    fix=json.loads((ROOT/"fix-pass-results.json").read_text())
    if (fix["baseline_tests"],fix["original_killed"],fix["original_survived"],fix["killed"],fix["survived"])!=(32,7,7,14,0):raise ValueError("Unexpected fix evidence")
    old=json.loads((ROOT/"registration.json").read_text())
    olddrift=[]
    for name,expected in old["shared_hashes"].items():
        if sha(pathlib.Path(name))!=expected:
            backups=[p for p in (ROOT/"source-v1").iterdir() if p.is_file() and sha(p)==expected]
            if not backups:raise ValueError("Missing original version "+name)
            olddrift.append({"path":name,"old_sha256":expected,"preserved":str(backups[0])})
    payload={}
    for prefix,root in (("controller",ROOT),("review",REVIEW)):
        for path in sorted(root.rglob("*")):
            if "__pycache__" in path.parts or path.is_dir():continue
            if path.is_symlink() or not path.is_file():raise ValueError("Unexpected evidence entry "+str(path))
            payload[prefix+"/"+str(path.relative_to(root))]=path
    payload["plan.md"]=MAIN/"docs/superpowers/plans/2026-11-06-semantic-contract-controller.md"
    for suffix in ("11d","11f"):
        record=pathlib.Path("/tmp/codescout-bg/455879-a720241d-bg_00000"+suffix+".json")
        job=json.loads(record.read_text())
        if job["state"]!="exited" or job["exit_code"]!=0:raise ValueError("Preflight not closed")
        payload["jobs/"+record.name]=record
        payload["jobs/"+suffix+".log"]=pathlib.Path(job["log_path"])
    manifest={"unit":"archive payload records, excluding this manifest","records":[{"name":n,"source":str(p),"bytes":p.stat().st_size,"sha256":sha(p)} for n,p in sorted(payload.items())],"closure":{"current_registered_hash_records":sum(checks),"historical_prepared_paths_rehashed":len(protected),"old_cost_files_rehashed":len(calibration["original_file_hashes"]),"original_v1_changed_source_preserved":olddrift,"no_actual_arm_started":True,"provider_calls":0,"paid_admission":False}}
    OUT.parent.mkdir(parents=True,exist_ok=True)
    with tarfile.open(OUT,"w:gz") as tar:
        for row in manifest["records"]:tar.add(payload[row["name"]],arcname=row["name"],recursive=False)
        data=(json.dumps(manifest,indent=2)+"\n").encode();entry=tarfile.TarInfo("manifest.json");entry.size=len(data);tar.addfile(entry,io.BytesIO(data))
    with tarfile.open(OUT,"r:gz") as tar:
        if len(tar.getmembers())!=len(payload)+1:raise ValueError("Archive population mismatch")
        for row in manifest["records"]:
            data=tar.extractfile(row["name"]).read()
            if len(data)!=row["bytes"] or hashlib.sha256(data).hexdigest()!=row["sha256"]:raise ValueError("Archive payload mismatch")
    receipt={"archive":str(OUT),"sha256":sha(OUT),"bytes":OUT.stat().st_size,"payload_records":len(payload),"manifest_records":1,"all_payloads_reopened_verified":True,**manifest["closure"]}
    OUT.with_suffix(".json").write_text(json.dumps(receipt,indent=2)+"\n")
    print(json.dumps(receipt,indent=2))
if __name__=="__main__":main()
