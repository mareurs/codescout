# SDD ledger — plan: docs/superpowers/plans/2026-11-06-semantic-contract-controller.md

Spec28aab59cb5842630; plan7b38d45d1bb07e12. Qualified product source36fec1201 unchanged. Private controller code is versioned with original source-v1 and post-review/registration.json; no source commit/merge/push.

Original TDD: engine17tests/41assertionfailures then17PASS. Readonly helper was initially implemented before its five tests; corrected before real execution by removing it, observing5no-op failures and reimplementing; original whole suite22PASS. Original preflight11d CLOSED0; no actual actor. Historical receipt reconciliation exactly matches all4 closed charges; only a cost-overlap calibration.

One fresh reviewer applied14 frozen mutations:7killed/7survived. Parent observed receipt contradiction and registration swap; reviewer reproduced actual SQLite WAL-only effective state drift. Four MAIN issues b6d64665839ea40f,24e25288edf5ec04,d18a0367e1d39131,55cc3a4716961776 filed immediately. One offline fix pass: new tests first6assertionfailures against original code; expanded32PASS; exact14 mutations reapplied14killed/0survived. No second review or actor rerun. Post-review11f real read-only versioned freeze CLOSED0, current input/population checks, correctly refuses paid admission.

Rulings on every declined review area:
1 Paid launch adapter/CLI integration is deferred until qualified classification; Readiness has no actor/grading methods. Cost if wrong: adapter step remains, no provider calls now.
2 Grader/live policy/negative-gold-repeat controls remain unqualified; user relay confirms peer worktree only ran205 baseline tests, no edits/commits. Parent now takes over existing grader plan, preserving old cohorts and closed diagnostics.
3 Provider budget, credential, transport charging and paid end-to-end behavior are unproven by fakes/calibration. Require concrete qualification before real entry; do not advertise paid readiness.
4 Low/xhigh quality or cost improvement remains unmeasured. Fixed pilot and separate external validation still required.
5 Docker availability was checked by parent preflights, not reviewer; those observations expire. Recheck at actual admission rather than replay now.
6 Resource checks sample boundaries; no continuous monitor/reservation/global peer census claim. Prospective paid policy must settle mid-stage behavior; no silent weakening.
7 Power-loss/fsync, concurrent controllers and adversarial between-check replacement outside current single-owner fixture scope. Do not claim crash-safe transactional guarantees; a paid integration must retain exclusive one-shot ownership.
8 Earlier inode isolation qualification preserved; current review hashes do not repeat physical-isolation proof. Source-bound state freeze is unchanged, requalify if clones rebuilt.
9 Receipt schema and over-reserve cost beyond observed rejection unproven; unknown/excess attempts remain stopped/unreconciled with raw evidence. No selective retry or assertion that this is full billing reconciliation.
10 Source gate10e GREEN retained; unrelated MAIN109 RED issue1dfa43ac9834a309 not repaired here. Private32test suite is relevant evidence, no claim MAIN green.
11 Formatting/performance redesign declined: no demonstrated blocking defect; no refactor introduced.
12 Hashed true proof labels identify declarations, not scientific validity. Actual admission cannot be synthesized from fixture labels.

Closure scope: deterministic one-shot engine, real read-only readiness and archival evidence. Paid integration/functional efficacy remain open. No new model spend in this series step; host/reviewer inference cost is not measured as experiment spend.
