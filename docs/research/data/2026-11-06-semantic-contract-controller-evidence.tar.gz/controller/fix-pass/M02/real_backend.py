"""Read-only readiness adapter. It has NO paid launch or grading method."""
import importlib.util
import json
import pathlib
import shutil
import subprocess
import sys
import campaign

def verify_readonly(reg):
    expected=campaign.load(reg["readonly_manifest"])
    seen=set()
    for row in reg["arms"]:
        argv=campaign.load(pathlib.Path(row["out"])/"mcp-native-argv.json")
        destinations=set()
        for position,argument in enumerate(argv):
            if argument!="--mount":continue
            options=argv[position+1].split(",")
            if "readonly" not in options:continue
            fields=dict(option.split("=",1) for option in options if "=" in option)
            destination=fields["dst"];root=pathlib.Path(fields["src"])
            if destination not in expected:raise ValueError("Unbound readonly destination")
            destinations.add(destination)
            identity=(str(root),destination)
            if identity in seen:continue
            found={path.relative_to(root).as_posix() for path in root.rglob("*") if path.is_file() or path.is_symlink()}
            if found!=set(expected[destination]):raise ValueError("Readonly file population differs")
            for relative,record in expected[destination].items():
                path=root/relative
                if "link" not in record:
                    if path.is_symlink() or campaign.digest(path)!=record["sha256"]:raise ValueError("Readonly content differs")
                else:
                    if not path.is_symlink() or str(path.readlink())!=record["link"]:raise ValueError("Readonly link differs")
                    if campaign.digest(path.resolve())!=record["resolved_sha256"]:raise ValueError("Readonly resolved content differs")
            seen.add(identity)
        if destinations!=set(expected):raise ValueError("Readonly destination population differs")
    return {"unique_source_mount_pairs":len(seen),"records_by_destination":{dest:len(files) for dest,files in expected.items()}}

class Readiness:
    def __init__(self,reg):
        self.reg=reg
        source=pathlib.Path(reg["qualified_source"])
        sys.path[:0]=[str(source/"tools/agent_lifecycle"),str(source/"tools"),str(source/"tools/hint_authority_pilot")]
        import external
        self.external=external
    def validate_shared(self,reg):
        spec=importlib.util.spec_from_file_location("bound_plugin_identity",reg["plugin_helper"])
        identity=importlib.util.module_from_spec(spec);spec.loader.exec_module(identity)
        manifest=campaign.load(reg["plugin_manifest"])
        pass # omit full plugin verification
        self.readonly=verify_readonly(reg)
    def validate(self,row):
        out=pathlib.Path(row["out"])
        cfg,_,_,_,_=self.external.validate_prepared(out,row["effort"],self.reg["reserve_usd"],self.reg["cli_cap_usd"])
        pinned=subprocess.run(["docker","image","inspect",cfg["image"],"--format","{{.Id}}"],capture_output=True,text=True,timeout=30)
        if pinned.returncode or pinned.stdout.strip()!=cfg["image"]:raise ValueError("Pinned native image unavailable")
    def resources(self,row):
        mem={line.split()[0].rstrip(":"):int(line.split()[1])*1024 for line in pathlib.Path("/proc/meminfo").read_text().splitlines() if len(line.split())>=2 and line.split()[1].isdigit()}
        heavy=[]
        for filename in self.reg["previous_job_records"]:
            job=campaign.load(filename)
            if job["state"] not in ("exited","failed"):heavy.append(filename)
        pressure={kind:(pathlib.Path("/proc/pressure")/kind).read_text() for kind in ("cpu","memory","io")}
        events=pathlib.Path("/sys/fs/cgroup/memory.events")
        return {"root_free":shutil.disk_usage(pathlib.Path(__file__).parent).free,
                "tmp_free":shutil.disk_usage("/tmp").free,"mem_available":mem["MemAvailable"],
                "other_heavy_stage":bool(heavy),"checked_prior_job_records":self.reg["previous_job_records"],
                "pressure":pressure,"host_root_cgroup_memory_events":events.read_text() if events.is_file() else None,
                "limits":"Boundary host/root-cgroup observations only; not native continuous monitoring or a global peer process census."}
