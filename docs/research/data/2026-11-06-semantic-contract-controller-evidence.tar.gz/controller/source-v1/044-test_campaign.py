import copy
import hashlib
import json
import pathlib
import tempfile
import unittest
from decimal import Decimal
import campaign

POLICY=[
("nushell__nushell-18863--low-control","nushell__nushell-18863","low-control","low"),
("rust-lang__rust-analyzer-22992--xhigh-control","rust-lang__rust-analyzer-22992","xhigh-control","xhigh"),
("nushell__nushell-18863--low-contract","nushell__nushell-18863","low-contract","low"),
("rust-lang__rust-analyzer-22992--low-control","rust-lang__rust-analyzer-22992","low-control","low"),
("nushell__nushell-18863--xhigh-control","nushell__nushell-18863","xhigh-control","xhigh"),
("rust-lang__rust-analyzer-22992--low-contract","rust-lang__rust-analyzer-22992","low-contract","low")]
GATES=["grader_review","live_policy","private_controls","runtime_wire","plugin","controller_review"]
def digest(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+"\n")
def load(p):return json.loads(p.read_text())

class Boundary:
    """Only the external actor is fake; filesystem events and controller are real."""
    def __init__(self,case):
        self.case=case;self.launches=[];self.events=[];self.change=None
        self.mode="ok";self.bad_index=0
    def validate_shared(self,reg):
        if digest(pathlib.Path(reg["plugin_file"]))!=reg["plugin_file_sha256"]:raise ValueError("plugin drift")
    def validate(self,row):self.events.append(("validate",row["arm_id"]))
    def resources(self,row):
        self.events.append(("resources",row["arm_id"]))
        value={"root_free":100*1024**3,"tmp_free":8*1024**3,"mem_available":64*1024**3,"other_heavy_stage":False,"pressure":{"memory":"some avg10=0.00"}}
        if self.mode=="resource" and len(self.launches)==self.bad_index:value["root_free"]=79*1024**3
        return value
    def launch(self,row,reserve,cli):
        index=len(self.launches);self.launches.append((row["arm_id"],row["effort"],str(reserve),str(cli)))
        out=pathlib.Path(row["out"])
        if not (self.case.root/"attempts"/(row["arm_id"]+".json")).is_file():raise AssertionError("no prospective attempt barrier")
        if self.mode=="exception" and index==self.bad_index:raise RuntimeError("actor failed before receipt")
        save(out/"started.json",{"fixture":True})
        (out/"state.db").write_text("actor legitimately changed own state")
        patch=b"candidate body"
        (out/"candidate.patch").write_bytes(patch)
        save(out/"candidate-capture.json",{"complete":True,"sha256":hashlib.sha256(patch).hexdigest(),"bytes":len(patch)})
        rec={"session_id":"fixture-"+str(index),"scripted":False,"cost_usd":"1.25","unknown_provider_cost":False,
             "context_valid":True,"transport_errors":[],"cleanup_error":None,"budget_stop":None,
             "background_evidence":{"complete":True},"artifact_evidence":{"complete":True},
             "workflow_completed":True,"terminal":{"is_error":False,"subtype":"success"},
             "lifecycle":{"status":"settled","error":None},
             "public_verification":{"status":"completed","passed":True,"error":None}}
        if index==self.bad_index:
            if self.mode=="functional":
                rec["workflow_completed"]=False
                rec["public_verification"]["passed"]=False
                rec["lifecycle"].update(status="incomplete",error="ValueError: continuation limit reached with failed public verification")
            if self.mode=="context":rec["context_valid"]=False
            if self.mode=="transport":rec["transport_errors"]=["bad request"]
            if self.mode=="unknown":rec["unknown_provider_cost"]=True
            if self.mode=="background":rec["background_evidence"]["complete"]=False
            if self.mode=="artifact":rec["artifact_evidence"]["complete"]=False
            if self.mode=="public_infra":rec["public_verification"]["error"]="linker fatal signal"
            if self.mode=="timeout":rec["lifecycle"].update(status="incomplete",error="TimeoutError: lifecycle deadline exceeded")
            if self.mode=="capture":save(out/"candidate-capture.json",{"complete":False})
            if self.mode=="patch_drift":(out/"candidate.patch").write_bytes(b"edited")
            if self.mode=="cleanup_receipt":rec["cleanup_error"]="unverifiable"
            if self.mode=="budget_stop":rec["budget_stop"]="cap"
            if self.mode=="bad_cost":rec["cost_usd"]="NaN"
            if self.mode=="overspend":rec["cost_usd"]="20.0001"
        save(out/"receipt.json",rec)
        if self.change is not None:self.change(index)
        return rec
    def reconcile(self,row,receipt,reserve):
        if receipt["unknown_provider_cost"]:raise ValueError("unknown cost")
        return Decimal(receipt["cost_usd"])
    def valid_public(self,row,receipt):
        if self.mode=="public_classifier" and row["arm_id"]==POLICY[self.bad_index][0]:raise ValueError("qualified policy says infra")
    def cleanup(self,row):
        if self.mode=="cleanup" and row["arm_id"]==POLICY[self.bad_index][0]:raise ValueError("container remains")
        return {"independently_absent":True,"daemon_query_succeeded":True}

class CampaignTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.base=pathlib.Path(self.tmp.name);self.root=self.base/"campaign"
        self.regfile=self.base/"registration.json";self.admit=self.base/"admission.json"
        source=self.base/"source.py";source.write_text("qualified bytes")
        plugin=self.base/"SKILL.md";plugin.write_text("full plugin fixture")
        arms=[]
        for i,(ident,task,variant,effort) in enumerate(POLICY):
            out=self.base/("arm-"+str(i));out.mkdir()
            save(out/"prepared.json",{"effort":effort})
            (out/"state.db").write_text("pristine")
            arms.append({"arm_id":ident,"task":task,"variant":variant,"effort":effort,"out":str(out),
                         "immutable_hashes":{str(out/"prepared.json"):digest(out/"prepared.json")},
                         "writable_hashes":{str(out/"state.db"):digest(out/"state.db")}})
        self.reg={"arms":arms,"shared_hashes":{str(source):digest(source)},"plugin_file":str(plugin),"plugin_file_sha256":digest(plugin),
                  "prior_usd":"58.180531399999999104","ceiling_usd":"200","reserve_usd":"20","cli_cap_usd":"19"}
        proofs={}
        for name in GATES:
            p=self.base/(name+".proof");p.write_text("qualified "+name)
            proofs[name]={"qualified":True,"path":str(p),"sha256":digest(p)}
        self.admission={"repair_admitted":True,"proofs":proofs}
        self.bind();self.backend=Boundary(self)
    def bind(self):
        save(self.regfile,self.reg)
        self.admission["registration_sha256"]=digest(self.regfile)
        save(self.admit,self.admission)
    def invoke(self):return campaign.run(self.root,self.regfile,self.admit,self.backend)
    def test_fixed_six_order_and_cost_closure(self):
        result=self.invoke()
        self.assertEqual(self.backend.launches,[(p[0],p[3],"20","19") for p in POLICY])
        self.assertEqual(result.get("known_series_subtotal_usd"),"65.680531399999999104")
        self.assertEqual(result.get("repair_cost_usd"),"7.50")
        self.assertTrue((self.root/"repairs-closed.json").is_file())
        self.assertEqual(len(load(self.root/"repairs-closed.json")["arms"]),6)
        self.assertFalse((self.root/"results.json").exists())
        for row in self.reg["arms"]:self.assertTrue(load(pathlib.Path(row["out"])/"cost-reconciled.json")["cost_known"])
    def test_missing_or_false_gate_blocks_every_call(self):
        for name in GATES:
            with self.subTest(name=name):
                self.admission["proofs"][name]["qualified"]=False;self.bind()
                with self.assertRaises(ValueError):campaign.preflight(self.regfile,self.admit,self.backend)
                self.admission["proofs"][name]["qualified"]=True
        self.assertEqual(self.backend.launches,[])
    def test_truthy_non_boolean_gate_is_not_qualified(self):
        self.admission["proofs"]["live_policy"]["qualified"]="true";self.bind()
        with self.assertRaises(ValueError):self.invoke()
        self.assertEqual(self.backend.launches,[])
    def test_missing_admission_does_not_start(self):
        self.admit.unlink()
        with self.assertRaises((ValueError,FileNotFoundError)):self.invoke()
        self.assertFalse((self.root/"campaign-started.json").exists())
    def test_registration_or_proof_drift_blocks(self):
        self.reg["prior_usd"]="0";save(self.regfile,self.reg)
        with self.assertRaises(ValueError):self.invoke()
        self.bind()
        pathlib.Path(self.admission["proofs"]["grader_review"]["path"]).write_text("changed")
        with self.assertRaises(ValueError):self.invoke()
        self.assertEqual(self.backend.launches,[])
    def test_order_effort_and_path_alias_rejected(self):
        original=copy.deepcopy(self.reg)
        for kind in ("order","effort","alias"):
            self.reg=copy.deepcopy(original)
            if kind=="order":self.reg["arms"][0],self.reg["arms"][1]=self.reg["arms"][1],self.reg["arms"][0]
            if kind=="effort":self.reg["arms"][0]["effort"]="xhigh"
            if kind=="alias":self.reg["arms"][1]["out"]=self.reg["arms"][0]["out"]
            self.bind()
            with self.subTest(kind=kind):
                with self.assertRaises(ValueError):campaign.preflight(self.regfile,self.admit,self.backend)
    def test_reservation_boundary_and_nonfinite_costs(self):
        for prior in ("80.0000000001","NaN","Infinity","-1"):
            self.reg["prior_usd"]=prior;self.bind()
            with self.subTest(prior=prior):
                with self.assertRaises(ValueError):campaign.preflight(self.regfile,self.admit,self.backend)
        self.reg["prior_usd"]="80";self.bind()
        result=self.invoke()
        self.assertEqual(len(self.backend.launches),6)
        self.assertEqual(result.get("known_series_subtotal_usd"),"87.50")
    def test_source_and_plugin_drift_refuse(self):
        source=pathlib.Path(next(iter(self.reg["shared_hashes"])))
        source.write_text("changed")
        with self.assertRaises(ValueError):campaign.preflight(self.regfile,self.admit,self.backend)
        self.reg["shared_hashes"][str(source)]=digest(source);self.bind()
        pathlib.Path(self.reg["plugin_file"]).write_text("changed")
        with self.assertRaises(ValueError):campaign.preflight(self.regfile,self.admit,self.backend)
    def test_future_state_drift_stops_before_next_call(self):
        def change(index):
            if index==0:(pathlib.Path(self.reg["arms"][5]["out"])/"state.db").write_text("cross-arm corruption")
        self.backend.change=change
        with self.assertRaises(ValueError):self.invoke()
        self.assertEqual(len(self.backend.launches),1)
        self.assertFalse((self.root/"repairs-closed.json").exists())
    def test_completed_state_changes_are_allowed(self):
        self.invoke()
        self.assertEqual(len(self.backend.launches),6)
    def test_existing_future_start_refuses_before_first(self):
        save(pathlib.Path(self.reg["arms"][5]["out"])/"started.json",{})
        with self.assertRaises(ValueError):self.invoke()
        self.assertEqual(self.backend.launches,[])
    def test_functional_failure_does_not_cancel_remaining_cohort(self):
        self.backend.mode="functional";self.invoke()
        self.assertEqual(len(self.backend.launches),6)
        closed=load(self.root/"repairs-closed.json")
        self.assertIs(closed["arms"][0]["workflow_completed"],False)
    def test_infrastructure_faults_stop_and_preserve_cost(self):
        modes=("context","transport","background","artifact","public_infra","public_classifier","timeout","capture","patch_drift","cleanup_receipt","cleanup","budget_stop")
        for mode in modes:
            with self.subTest(mode=mode):
                case=CampaignTests();case.setUp()
                try:
                    case.backend.mode=mode
                    with self.assertRaises(ValueError):case.invoke()
                    self.assertEqual(len(case.backend.launches),1)
                    self.assertTrue(load(pathlib.Path(case.reg["arms"][0]["out"])/"cost-reconciled.json")["cost_known"])
                    stopped=load(case.root/"campaign-stopped.json")
                    self.assertEqual(stopped["known_series_subtotal_usd"],"59.430531399999999104")
                    self.assertFalse((case.root/"repairs-closed.json").exists())
                finally:case.doCleanups()
    def test_unknown_invalid_or_excess_cost_never_claimed_known(self):
        for mode in ("unknown","bad_cost","overspend"):
            with self.subTest(mode=mode):
                case=CampaignTests();case.setUp()
                try:
                    case.backend.mode=mode
                    with self.assertRaises(ValueError):case.invoke()
                    self.assertEqual(len(case.backend.launches),1)
                    self.assertFalse((pathlib.Path(case.reg["arms"][0]["out"])/"cost-reconciled.json").exists())
                    self.assertEqual(load(case.root/"campaign-stopped.json")["unreconciled_attempt"],POLICY[0][0])
                finally:case.doCleanups()
    def test_resource_failure_before_second_preserves_first(self):
        self.backend.mode="resource";self.backend.bad_index=1
        with self.assertRaises(ValueError):self.invoke()
        self.assertEqual(len(self.backend.launches),1)
    def test_launch_exception_preserves_attempt_barrier_without_retry(self):
        self.backend.mode="exception"
        with self.assertRaises(RuntimeError):self.invoke()
        self.assertEqual(len(self.backend.launches),1)
        self.assertTrue((self.root/"attempts"/(POLICY[0][0]+".json")).exists())
        self.assertEqual(load(self.root/"campaign-stopped.json")["unreconciled_attempt"],POLICY[0][0])
    def test_repeat_run_cannot_launch_again(self):
        self.invoke();count=len(self.backend.launches)
        with self.assertRaises((ValueError,FileExistsError)):self.invoke()
        self.assertEqual(len(self.backend.launches),count)

if __name__=="__main__":unittest.main()
