# Bounded semantic-contract controller review

**Assessment: with fixes.** The private engine/preflight is not ready to authorize a paid campaign. The reviewer found one concrete state-admission defect and seven measured regression-guard gaps; the parent separately supplied two concrete engine defects, whose source and saved evidence were inspected here. This is one final review, before the parent's one offline fix pass.

## Scope and strengths

Reviewed original `campaign.py`, `real_backend.py`, `freeze-controller.py`, both test modules, progress ledger, plan7b38d45d1bb07e12 and spec28aab59cb5842630. Source snapshots and exact hashes are in source-manifest.json; qualified product source remains HEAD36fec1201b0f809d6f21cc31082def4d651b6cf8 with an empty tracked diff.

The engine checks exact six-arm IDs/order/actual efforts, uses Decimal accounting, writes an attempt record before the actor boundary, stops without retry on faults, and stores known reconciled costs before capture/cleanup checks (`campaign.py:60, 137, 145`). The copied suite demonstrates functional continuation exhaustion proceeds through all six attempts and distinguishes completed writable state from future state (`test_campaign.py:166, 173, 180`). It also kills mutations removing fixed order, strict boolean admission, future file hashing, pending-attempt tracking, excess-cost rejection and early known-cost preservation.

The read-only adapter's lack of paid launch/grading is intentional under the plan's Rulings. Missing qualification is not silently represented as delivered integration. The saved preflight exited0 at14:38:35UTC and explicitly refused grader_review, live_policy, private_controls and controller_review. Its recorded gate outcome is a refusal, not a paid acceptance.

## Important findings

1. **New SQLite WAL changes future state without changing any registered hash.** `campaign.py:39, 114`; `freeze-controller.py:47`. The guard enumerates only existing registered filenames. In a disposable real-SQLite fixture, a checkpointed registered database retained the identical SHA256 while a committed WAL-only update changed its query result to “unregistered altered state”; original preflight accepted the arm. Bind and compare exact writable-root populations for current/future arms, including unexpected sidecars; continue exempting completed arms' legitimate mutations. Issue **d18a0367e1d39131**, evidence future_wal_probe.py/.json. No real prepared state was changed.

2. **The campaign epoch is recorded but not enforced later.** `campaign.py:128, 129, 135`. `run` retains old rows/budgets while subsequent preflight reloads registration/admission. The parent's observed fixture replaced both consistently after the first call, changed prior cost to0, and still completed all six although initial and final registration hashes differ. Pin both original digests at every next-call boundary and final closure. Issue **24e25288edf5ec04**; parent-evidence/consistency-probe.json and probe-consistency.py. Reviewer inspected source and evidence; did not rerun the parent's probe.

3. **Workflow outcome can contradict lifecycle/public evidence.** `campaign.py:89, 92, 99`. The last guard checks only boolean type. The parent's settled/passing receipt with workflow_completed=false was accepted through all six calls. Validate cross-field coherence while retaining the explicitly accepted functional-exhaustion form. Issue **b6d64665839ea40f**; same parent evidence. This does not challenge genuine functional failures continuing the fixed cohort.

4. **Seven safety mutations survive the original full suite.** `test_real_backend.py:20`, `test_campaign.py:140, 185, 199`. Actual guards exist, but their regression protection is absent at specific call sites or non-discriminating fixture values. Issue **55cc3a4716961776**. Add real Readiness.validate_shared controls using local helper fixtures; immutable drift/native-validator controls; distinct reconciler-versus-receipt cost values; false/ill-typed cleanup results; and same-length changed candidate bytes. Avoid replacing these with helper-only checks or exceptions thrown before the target predicate.

No Critical finding is claimed: paid admission remains false and no paid adapter exists. No standalone style finding is raised.

## Frozen mutation results

All14 candidates were frozen before parent fixes in mutation-population.json. Each mutation was applied with edit_code to its own copy, then the original unchanged22 tests ran. Baseline22PASS. **7 killed, 7 survived**. Kills produced **8 assertion failures and9 behavior errors; zero import/syntax/harness failures**. Errors were inspected: M07 raised the intended incorrect lifecycle error; M14 left eight expected cost files absent.

| Mutation | Exact behavior removed or altered | Observed result |
|---|---|---|
| M01 | Readiness.validate_shared readonly verifier call | Survived22 |
| M02 | Readiness.validate_shared full plugin verifier call | Survived22 |
| M03 | preflight all-arm immutable hashes call | Survived22 |
| M04 | preflight current/future writable hashes call | Killed,1 assertion |
| M05 | receipt cost equals reconciled cost | Survived22 |
| M06 | cost cannot exceed reserve | Killed,1 assertion |
| M07 | functional continuation exhaustion is accepted | Killed,1 behavior error |
| M08 | active attempted arm remains pending before launch | Killed,4 assertions |
| M09 | proof qualified must be literal true | Killed,1 assertion |
| M10 | exact frozen order, compared as unordered instead | Killed,1 assertion |
| M11 | cleanup independently_absent must be true | Survived22 |
| M12 | captured patch digest equality | Survived22 |
| M13 | preflight current/future native validator call | Survived22 |
| M14 | preserve known charge before downstream receipt validation | Killed,8 behavior errors |

Reapply these exact replacements after the one offline fix pass; retain initial results. No reviewer re-review loop is requested. Raw per-mutant suite.log and suite-result.json preserve test IDs/tracebacks; mutation-results.json retains source/test hashes. Independent replacements do not interact.

## Actual input and evidence check

An independent read-only hash/inventory pass verified **5,963 registered hash records over5,958 unique paths**:59shared,66immutable,5,838writable; zero mismatches. These are record counts, not “5,963 unique files.” The full plugin identity matched **142files and38directories including its root**. Four unique read-only host-source/destination pairs contained61records; exact populations, bytes and link targets/resolved bytes matched. No existing started/launch/receipt/cost-reconciled marker was found in the six real arms. Original review files and qualified source were unchanged at14:47:29UTC. See input-audit.json and input-audit-records.json.

Saved preflight resource observations were root341111189504bytes, /tmp27188498432bytes, MemAvailable90481410048bytes, above registered80GiB/4GiB/48GiB floors. These are historical observations, not current reservations. Readiness records host PSI and root-cgroup information at boundaries and explicitly disclaims continuous monitoring/global process census (`real_backend.py:57`).

The registered amounts match the fixed inputs: prior58.180531399999999104, ceiling200, reserve20 and CLI19. The parent's closed-receipt-calibration.json reports exact agreement for four old paid costs under the unchanged **tools/hint_authority_workflow/driver.py**. This was inspected as saved overlap calibration, not new provider enforcement evidence.

Gate10e's saved process record is exited0; MAIN109 is exited1. This review ran copied private Python tests, not the repository-wide gate, and does not clear unrelated MAIN issue1dfa43ac9834a309.

## Declined to judge

- Concrete paid launch adapter and CLI integration: explicitly deferred in Rulings; Readiness intentionally has no launch or grading method.
- Fresh grader correctness, prospective compiler/test versus infrastructure classification, and negative/gold/repeat controls: peer-owned pending prerequisites; no private grades or native actors run.
- Actual provider budget enforcement, credentials, transport charging and paid end-to-end behavior: deterministic boundary fixtures and read-only historical receipt calibration do not establish them.
- Quality parity of low-contract versus xhigh or workflow-cost improvement: no new model observations; research hypothesis remains unmeasured.
- Current Docker image/daemon availability: inspected saved preflight success only; no live daemon query or controller rerun.
- Continuous resource monitoring, resource reservations and a global peer-process census: implementation explicitly makes sampled boundary observations only.
- Power-loss/fsync durability, concurrent controllers or hostile between-check filesystem replacement: not exercised by this local one-shot fixture review.
- Current inode disjointness of every real writable clone: earlier preparation proof is retained; this review rehashed all registered bytes but did not repeat physical-isolation qualification.
- General receipt schema/over-reserve-known-cost semantics beyond tested rejection: original tests retain such attempts unreconciled; no stronger accounting claim was inferred from the fixture.
- Repository-wide gate repair and unrelated MAIN failure: existing source gate10e record was inspected; MAIN gate109 red remains, no product source was changed or full gate rerun.
- Private orchestration formatting and performance redesign: no blocking effect demonstrated; no refactor requested.

The fake boundary writes real fixture receipts/candidates/costs; its “qualified <name>” proof contents are local fixtures. A true field plus a hash checks a declared qualification's identity, not the scientific validity of its underlying grader/control proof. Future admission must still be externally source-bound and independently qualified. No behavior-transfer, low/xhigh parity or cost-improvement conclusion follows from this review.

## Recommendation

Complete the one offline fix pass for the four issues, demonstrate the real-SQLite counterexample and the parent's two counterexamples rejected with preserved first-arm accounting, rerun the original plus added local suite, and reapply the frozen14mutations. Keep all actual paid prerequisites false until the deferred grader/policy/control and paid-adapter qualification is complete. Do not rerun real preflight or actors merely to satisfy this report.

Ledger checked: f6eef24a60b8698e, e6b99f20243e4fd0, d50dc302c7add5c2, 20927ccfe293c34e, b9eec23561e3299b, 7579b32b1cd2362f, 3c5fa35d9d2754a7, 55cc3a4716961776, d18a0367e1d39131, 24e25288edf5ec04, b6d64665839ea40f.
