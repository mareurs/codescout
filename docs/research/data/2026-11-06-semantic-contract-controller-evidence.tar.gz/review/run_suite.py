import io, json, pathlib, sys, unittest
directory=pathlib.Path(sys.argv[1])
sys.path.insert(0,str(directory))
suite=unittest.defaultTestLoader.discover(str(directory),pattern="test_*.py")
stream=io.StringIO()
result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
(directory/"suite.log").write_text(stream.getvalue())
report={"tests_run":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped),"success":result.wasSuccessful(),"failure_details":[{"test":str(t),"traceback":s} for t,s in result.failures],"error_details":[{"test":str(t),"traceback":s} for t,s in result.errors]}
(directory/"suite-result.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps({k:v for k,v in report.items() if not k.endswith("_details")}))
sys.exit(0 if result.wasSuccessful() else 1)
