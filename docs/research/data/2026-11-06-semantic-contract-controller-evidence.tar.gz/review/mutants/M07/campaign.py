"""Fixed six-arm campaign engine; importing it launches nothing."""
import hashlib
import json
import pathlib
import re
import time
from decimal import Decimal, InvalidOperation

POLICY = [
("nushell__nushell-18863--low-control","nushell__nushell-18863","low-control","low"),
("rust-lang__rust-analyzer-22992--xhigh-control","rust-lang__rust-analyzer-22992","xhigh-control","xhigh"),
("nushell__nushell-18863--low-contract","nushell__nushell-18863","low-contract","low"),
("rust-lang__rust-analyzer-22992--low-control","rust-lang__rust-analyzer-22992","low-control","low"),
("nushell__nushell-18863--xhigh-control","nushell__nushell-18863","xhigh-control","xhigh"),
("rust-lang__rust-analyzer-22992--low-contract","rust-lang__rust-analyzer-22992","low-contract","low")]
GATES = ("grader_review","live_policy","private_controls","runtime_wire","plugin","controller_review")

def digest(path):
    path=pathlib.Path(path)
    if path.is_symlink() or not path.is_file():
        raise ValueError("Nonregular input "+str(path))
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(pathlib.Path(path).read_text())

def save(path, data, exclusive=False):
    path=pathlib.Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open("x" if exclusive else "w") as stream:
        stream.write(json.dumps(data,indent=2)+"\n")

def amount(value):
    try:result=Decimal(str(value))
    except (InvalidOperation,ValueError):raise ValueError("Invalid money") from None
    if not result.is_finite() or result<0:
        raise ValueError("Nonfinite or negative money")
    return result

def check_hashes(hashes):
    if not isinstance(hashes,dict) or not hashes:
        raise ValueError("Missing input hash population")
    for name,expected in hashes.items():
        if not isinstance(name,str) or not isinstance(expected,str) or not re.fullmatch("[0-9a-f]{64}",expected) or digest(name)!=expected:
            raise ValueError("Bound input drift "+str(name))

def registered(registration, admission):
    reg=load(registration);admit=load(admission)
    if admit.get("repair_admitted") is not True:
        missing=[name for name in GATES if admit.get("proofs",{}).get(name,{}).get("qualified") is not True]
        raise ValueError("Paid admission false; missing prerequisites: "+", ".join(missing))
    if admit.get("registration_sha256")!=digest(registration):
        raise ValueError("Admission registration drift")
    proofs=admit.get("proofs",{})
    missing=[name for name in GATES if not isinstance(proofs.get(name),dict) or proofs[name].get("qualified") is not True]
    if missing:raise ValueError("Unqualified prerequisites: "+", ".join(missing))
    for name in GATES:
        proof=proofs[name]
        check_hashes({proof.get("path"):proof.get("sha256")})
    rows=reg["arms"]
    if not isinstance(rows,list) or [(r.get("arm_id"),r.get("task"),r.get("variant"),r.get("effort")) for r in rows]!=POLICY:
        raise ValueError("Fixed cohort identity/order/effort mismatch")
    outputs=[]
    for row in rows:
        path=pathlib.Path(row["out"])
        if not path.is_absolute() or path.is_symlink() or not path.is_dir():
            raise ValueError("Invalid arm output")
        outputs.append(path.resolve())
    if any(a==b or a in b.parents or b in a.parents for i,a in enumerate(outputs) for b in outputs[i+1:]):
        raise ValueError("Overlapping arm outputs")
    prior,ceiling,reserve,cli=(amount(reg[k]) for k in ("prior_usd","ceiling_usd","reserve_usd","cli_cap_usd"))
    if not 0<cli<=reserve or prior+len(rows)*reserve>ceiling:
        raise ValueError("Whole-cohort reservation does not fit")
    return reg,prior,ceiling,reserve,cli

def resource_check(snapshot):
    for name,floor in (("root_free",80*1024**3),("tmp_free",4*1024**3),("mem_available",48*1024**3)):
        if type(snapshot.get(name)) is not int or snapshot[name]<floor:
            raise ValueError("Resource floor "+name)
    if snapshot.get("other_heavy_stage") is not False:
        raise ValueError("Overlapping heavy campaign stage")

def receipt_check(receipt):
    if receipt.get("context_valid") is not True or receipt.get("transport_errors")!=[] or receipt.get("unknown_provider_cost") is not False:
        raise ValueError("Context/transport/provider cost invalid")
    if receipt.get("cleanup_error") is not None or receipt.get("budget_stop") is not None:
        raise ValueError("Cleanup or budget stop")
    if receipt.get("background_evidence",{}).get("complete") is not True or receipt.get("artifact_evidence",{}).get("complete") is not True:
        raise ValueError("Evidence preservation incomplete")
    public=receipt.get("public_verification") or {}
    if public.get("status")!="completed" or type(public.get("passed")) is not bool or public.get("error") is not None:
        raise ValueError("Public verification invalid")
    lifecycle=receipt.get("lifecycle") or {}
    settled=lifecycle.get("status")=="settled" and lifecycle.get("error") is None
    exhausted=(lifecycle.get("status")=="incomplete"
        and lifecycle.get("error")=="ValueError: continuation limit reached with failed public verification"
        and public["passed"] is False)
    if not settled:
        raise ValueError("Lifecycle infrastructure failure")
    if type(receipt.get("workflow_completed")) is not bool:
        raise ValueError("Unknown workflow outcome")


def preflight(registration, admission, backend, index=0, spent=None):
    reg,prior,ceiling,reserve,cli=registered(registration,admission)
    if type(index) is not int or not 0<=index<len(reg["arms"]):
        raise ValueError("Invalid cohort cursor")
    spent=prior if spent is None else amount(spent)
    if spent+(len(reg["arms"])-index)*reserve>ceiling:
        raise ValueError("Remaining cohort reservation does not fit")
    check_hashes(reg["shared_hashes"])
    backend.validate_shared(reg)
    for i,row in enumerate(reg["arms"]):
        check_hashes(row["immutable_hashes"])
        if i>=index:
            check_hashes(row["writable_hashes"])
            out=pathlib.Path(row["out"])
            if any((out/name).exists() for name in ("started.json","launch.json","receipt.json","cost-reconciled.json")):
                raise ValueError("Existing attempt must be reconciled; never rerun")
            backend.validate(row)
    snapshot=backend.resources(reg["arms"][index]);resource_check(snapshot)
    return {"index":index,"resources":snapshot,"remaining":len(reg["arms"])-index,
            "known_series_subtotal_usd":str(spent),"remaining_reserved_usd":str((len(reg["arms"])-index)*reserve)}

def run(root, registration, admission, backend):
    root=pathlib.Path(root)
    if (root/"campaign-started.json").exists():
        raise ValueError("Existing campaign: reconcile preserved attempts, never rerun")
    reg,prior,ceiling,reserve,cli=registered(registration,admission)
    save(root/"campaign-started.json",{"registration_sha256":digest(registration),"admission_sha256":digest(admission),
         "registered_unix":time.time(),"private_outcomes_embargoed":True},exclusive=True)
    rows=[];charges=[];spent=prior;pending=None;active=None
    try:
        for index,row in enumerate(reg["arms"]):
            active=row["arm_id"];out=pathlib.Path(row["out"])
            boundary=preflight(registration,admission,backend,index,spent)
            save(root/"resource-observations"/(str(index)+"-before.json"),boundary)
            save(root/"attempts"/(active+".json"),{"arm_id":active,"index":index,"effort":row["effort"],
                 "reserve_usd":str(reserve),"cli_cap_usd":str(cli),"started_unix":time.time()},exclusive=True)
            pending=active
            receipt=backend.launch(row,reserve,cli)
            cost=amount(backend.reconcile(row,receipt,reserve))
            if cost>reserve or amount(receipt.get("cost_usd"))!=cost:
                raise ValueError("Unknown, inconsistent or excessive charge")
            charge={"arm_id":active,"session_id":receipt["session_id"],"cost_known":True,"cost_usd":str(cost)}
            save(out/"cost-reconciled.json",charge,exclusive=True)
            charges.append(charge);spent+=cost;pending=None
            save(root/"known-charges.json",{"arms":charges,"known_series_subtotal_usd":str(spent)})
            receipt_check(receipt)
            backend.valid_public(row,receipt)
            capture=load(out/"candidate-capture.json");patch=out/"candidate.patch"
            if capture.get("complete") is not True or type(capture.get("bytes")) is not int or capture["bytes"]!=patch.stat().st_size or capture.get("sha256")!=digest(patch):
                raise ValueError("Candidate capture incomplete or drifted")
            cleanup=backend.cleanup(row)
            if cleanup.get("daemon_query_succeeded") is not True or cleanup.get("independently_absent") is not True:
                raise ValueError("Native cleanup not independently proven")
            snapshot=backend.resources(row);resource_check(snapshot)
            save(root/"resource-observations"/(str(index)+"-after.json"),snapshot)
            check_hashes(reg["shared_hashes"]);backend.validate_shared(reg)
            for immutable in reg["arms"]:check_hashes(immutable["immutable_hashes"])
            result=dict(charge,effort=row["effort"],workflow_completed=receipt["workflow_completed"],
                        candidate_sha256=capture["sha256"],candidate_bytes=capture["bytes"],cleanup=cleanup)
            rows.append(result)
            save(root/"campaign-progress.json",{"arms":rows,"known_series_subtotal_usd":str(spent),"private_outcomes_embargoed":True})
        final={"arms":rows,"known_series_subtotal_usd":str(spent),
               "repair_cost_usd":str(sum((amount(c["cost_usd"]) for c in charges),Decimal("0"))),
               "all_six_registered_attempts_preserved":True,"private_outcomes_embargoed":True}
        save(root/"repairs-closed.json",final,exclusive=True)
        return final
    except BaseException as exc:
        save(root/"campaign-stopped.json",{"arm_id":active,"exception":type(exc).__name__,"message":str(exc),
             "known_series_subtotal_usd":str(spent),"known_charges":charges,"unreconciled_attempt":pending,
             "private_outcomes_embargoed":True,"completed_arms":rows})
        raise
