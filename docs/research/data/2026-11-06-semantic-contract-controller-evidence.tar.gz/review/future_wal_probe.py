import hashlib,json,pathlib,sqlite3,sys
sys.path.insert(0,str(pathlib.Path(__file__).parent/"baseline"))
import campaign
from test_campaign import CampaignTests
case=CampaignTests();case.setUp()
try:
    future=pathlib.Path(case.reg["arms"][5]["out"])/"state.db"
    future.unlink()
    db=sqlite3.connect(future)
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("CREATE TABLE knowledge (value TEXT)")
    db.execute("INSERT INTO knowledge VALUES ('pristine')")
    db.commit()
    db.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    db.close()
    before=campaign.digest(future)
    case.reg["arms"][5]["writable_hashes"]={str(future):before}
    case.bind()
    db=sqlite3.connect(future)
    db.execute("PRAGMA wal_autocheckpoint=0")
    db.execute("UPDATE knowledge SET value='unregistered altered state'")
    db.commit()
    after=campaign.digest(future)
    accepted=campaign.preflight(case.regfile,case.admit,case.backend)
    result={"same_registered_db_bytes":before==after,"effective_value":db.execute("SELECT value FROM knowledge").fetchone()[0],"new_sidecars":[p.name for p in future.parent.glob("state.db-*")],"preflight_accepted":bool(accepted),"provider_calls":0}
    db.close()
    output=pathlib.Path(__file__).with_suffix(".json")
    output.write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result))
finally:
    case.doCleanups()
