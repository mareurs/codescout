import collections,datetime,hashlib,json,os,pathlib,stat,subprocess
ROOT=pathlib.Path(__file__).parent
base=ROOT/"baseline"
reg=json.loads((base/"registration.json").read_text())
cache={}
def digest(p):
    p=pathlib.Path(p)
    if str(p) not in cache:
        with p.open("rb") as stream:cache[str(p)]=hashlib.file_digest(stream,"sha256").hexdigest()
    return cache[str(p)]
def checked(p,wanted):
    p=pathlib.Path(p)
    return {"path":str(p),"expected":wanted,"observed":digest(p),"matches":not p.is_symlink() and digest(p)==wanted}
records=[]
for name,wanted in reg["shared_hashes"].items():records.append(dict(checked(name,wanted),category="shared"))
for row in reg["arms"]:
    for key in ("immutable_hashes","writable_hashes"):
        for name,wanted in row[key].items():records.append(dict(checked(name,wanted),category=key,arm_id=row["arm_id"]))
markers=[str(pathlib.Path(row["out"])/name) for row in reg["arms"] for name in ("started.json","launch.json","receipt.json","cost-reconciled.json") if (pathlib.Path(row["out"])/name).exists()]
plugin=json.loads(pathlib.Path(reg["plugin_manifest"]).read_text())
plugin_root=pathlib.Path(plugin["plugin"]);actual={}
for p in [plugin_root]+sorted(plugin_root.rglob("*")):
    mode=stat.S_IMODE(p.lstat().st_mode);relative=p.relative_to(plugin_root).as_posix()
    if p.is_symlink():actual[relative]={"kind":"symlink","mode":mode,"target":str(p.readlink())}
    elif p.is_dir():actual[relative]={"kind":"directory","mode":mode}
    elif p.is_file():actual[relative]={"kind":"file","mode":mode,"bytes":p.stat().st_size,"sha256":digest(p)}
    else:actual[relative]={"kind":"other","mode":mode}
expected=json.loads(pathlib.Path(reg["readonly_manifest"]).read_text())
readonly=[];seen=set()
for row in reg["arms"]:
    argv=json.loads((pathlib.Path(row["out"])/"mcp-native-argv.json").read_text())
    for index,arg in enumerate(argv):
        if arg!="--mount":continue
        opts=argv[index+1].split(",")
        if "readonly" not in opts:continue
        fields=dict(item.split("=",1) for item in opts if "=" in item)
        key=(fields["src"],fields["dst"])
        if key in seen:continue
        seen.add(key);src=pathlib.Path(key[0])
        found={p.relative_to(src).as_posix() for p in src.rglob("*") if p.is_file() or p.is_symlink()}
        readonly.append({"source":key[0],"destination":key[1],"file_population_matches":found==set(expected[key[1]]),"records":[]})
        for relative,wanted in expected[key[1]].items():
            p=src/relative
            if "link" in wanted:
                got={"link":str(p.readlink()),"resolved_sha256":digest(p.resolve())}
                match=p.is_symlink() and got==wanted
            else:
                got={"sha256":digest(p)}
                match=not p.is_symlink() and got==wanted
            readonly[-1]["records"].append({"path":str(p),"expected":wanted,"observed":got,"matches":match})
source_stability=[checked(row["path"],row["sha256"]) for row in json.loads((ROOT/"source-manifest.json").read_text())]
worktree=pathlib.Path(reg["qualified_source"])
env=dict(os.environ,GIT_OPTIONAL_LOCKS="0")
git_head=subprocess.check_output(["git","-C",str(worktree),"rev-parse","HEAD"],env=env,text=True).strip()
git_diff=subprocess.check_output(["git","-C",str(worktree),"diff","--name-only","HEAD"],env=env,text=True).splitlines()
evidence_names=["consistency-probe.json","closed-receipt-calibration.json","probe-consistency.py","check-reconciliation.py"]
original=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/semantic-contract-controller-20261106")
extra=[]
(ROOT/"parent-evidence").mkdir()
for name in evidence_names:
    p=original/name
    data=p.read_bytes();(ROOT/"parent-evidence"/name).write_bytes(data)
    extra.append({"path":str(p),"copy":str(ROOT/"parent-evidence"/name),"sha256":digest(p)})
summary={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"registered_hash_records":len(records),"record_categories":dict(collections.Counter(r["category"] for r in records)),"unique_registered_paths":len({r["path"] for r in records}),"registered_mismatches":[r for r in records if not r["matches"]],"existing_attempt_markers":markers,"plugin_record_types":dict(collections.Counter(r["kind"] for r in actual.values())),"plugin_identity_matches":actual==plugin["identity"],"readonly_unique_source_mount_pairs":len(readonly),"readonly_records":sum(len(x["records"]) for x in readonly),"readonly_population_matches":all(x["file_population_matches"] for x in readonly),"readonly_mismatches":[r for x in readonly for r in x["records"] if not r["matches"]],"original_review_source_unchanged":all(r["matches"] for r in source_stability),"qualified_source_head":git_head,"qualified_source_diff_names":git_diff,"no_live_daemon_or_provider_query":True}
(ROOT/"input-audit.json").write_text(json.dumps(summary,indent=2)+"\n")
(ROOT/"input-audit-records.json").write_text(json.dumps({"registered_hash_records":records,"plugin_observed_identity":actual,"readonly":readonly,"review_source_stability":source_stability,"parent_evidence":extra},indent=2)+"\n")
print(json.dumps(summary,indent=2))
