"""Zero-provider public validation of an already closed xhigh candidate, on a separate copy."""
import hashlib,json,pathlib,shutil,subprocess,sys,time
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/xhigh-patch-public-diagnostic-20261105")
CANDIDATE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/complete-workflow-cold-recovery-20261105/workflow-1-xhigh/project")
sys.path[:0]=[str(V/"tools/agent_lifecycle"),str(V/"tools/hint_authority_pilot")]
import run as worker
import prepare,audit,transport
from qualify import NoCredential,no_upstream
from verification import PublicVerifier
from workflow import native_check,validate_config,verified_native_argv
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def inventory(directory):
    result={}
    for path in sorted(directory.rglob("*")):
        rel=str(path.relative_to(directory))
        if rel=="target" or rel.startswith("target/"):continue
        if path.is_symlink():result[rel+"#link"]=str(path.readlink())
        if path.is_file():result[rel]=digest(path)
    return result
def main():
    assert json.loads((CANDIDATE.parent/"receipt.json").read_text())["terminal"]["subtype"]=="error_max_turns"
    assert not ROOT.exists()
    ROOT.mkdir()
    worker.TOKEN = NoCredential()
    transport.Proxy.upstream = no_upstream
    frozen = worker.P / "launch-budget-requalification-20261104"
    audit.L = frozen
    profile = V / "tools/hint_authority_workflow/public-checks.json"
    config = validate_config(json.loads(profile.read_text()))
    source_files = sorted((V / "tools/agent_lifecycle").glob("*.py"))
    source_files += sorted((V / "tools/hint_authority_completion").glob("*.py"))
    source_files += sorted((V / "tools/hint_authority_resume").glob("*.py"))
    source_files += [profile, pathlib.Path(__file__)]
    manifest = {
        "source_commit": subprocess.check_output(["git", "-C", str(V), "rev-parse", "HEAD"], text=True).strip(),
        "legacy_frozen_inputs_fingerprint": audit.fingerprint(),
        "additional_files": {str(path): digest(path) for path in source_files},
        "candidate_patch_sha256": digest(CANDIDATE.parent / "candidate.patch"),
        "profile": config,
        "paid_admitted": False,
        "scope": "Ex-post public checks of the closed turn-censored xhigh patch; not model workflow completion",
    }
    manifest["composition_inventory_sha256"] = hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest()
    worker.save(ROOT / "preparation-manifest.json", manifest)
    actor = ROOT / "project"
    shutil.copytree(CANDIDATE, actor, ignore=shutil.ignore_patterns("target"))
    worker.save(ROOT / "candidate-before.json", inventory(actor))
    home = ROOT / "native-home"
    home.mkdir()
    name = "hfa-xhigh-patch-public-01a15ca9-20261105"
    argv = verified_native_argv(worker.native_argv(actor, home))
    argv[argv.index("--name") + 1] = name
    argv[argv.index("--label") + 1] = "codescout.hfa=" + name
    worker.save(ROOT / "launch.json", {"argv": argv, "name": name, "real_credentials_read": False})
    worker.save(ROOT / "mcp-launch-control.json", {"name": name})
    container_id = None
    receipt = {"model_cost_usd": "0", "provider_calls": 0, "public_verification": None,
               "cleanup": None, "error": None, "composition_inventory_sha256": manifest["composition_inventory_sha256"]}
    process = None
    try:
        with (ROOT / "server.stdout").open("wb") as stdout, (ROOT / "server.stderr").open("wb") as stderr:
            process = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=stdout, stderr=stderr)
            deadline = time.monotonic() + 15
            while time.monotonic() < deadline:
                row = subprocess.run(["docker", "inspect", name], capture_output=True, text=True, timeout=5)
                if row.returncode == 0:
                    data = json.loads(row.stdout)[0]
                    if data["Image"] != worker.IMAGE or data["Config"]["Labels"].get("codescout.hfa") != name:
                        raise ValueError("Unexpected container identity")
                    if data["State"]["Running"]:
                        container_id = data["Id"]
                        break
                if process.poll() is not None:
                    raise ValueError("Native server exited before admission")
                time.sleep(.1)
            if container_id is None:
                raise TimeoutError("Native worker did not become live")
            worker.save(ROOT / "record-owner.json", {"name": name, "container_id": container_id})
            verifier = PublicVerifier(ROOT, config["checks"],
                lambda command, log, left: native_check(ROOT, worker.IMAGE, command, log, min(left, config["check_timeout_s"])))
            started = time.monotonic()
            feedback = verifier(config["timeout_s"])
            receipt["public_wall_s"] = time.monotonic() - started
            receipt["public_verification"] = json.loads((ROOT / "public-verification.json").read_text())
            receipt["feedback"] = feedback
    except Exception as exc:
        receipt["error"] = type(exc).__name__ + ": " + str(exc)
    finally:
        # Remove only the exact container ID observed under this exclusive generated name.
        lookup = subprocess.run(["docker", "inspect", name], capture_output=True, text=True, timeout=5)
        if lookup.returncode == 0:
            data = json.loads(lookup.stdout)[0]
            if data["Image"] != worker.IMAGE or data["Config"]["Labels"].get("codescout.hfa") != name:
                receipt["cleanup"] = {"absent": False, "error": "identity mismatch; left untouched"}
            elif container_id is not None and data["Id"] != container_id:
                receipt["cleanup"] = {"absent": False, "error": "replacement ID; left untouched"}
            else:
                container_id = data["Id"]
                removed = subprocess.run(["docker", "rm", "-f", container_id], capture_output=True, text=True, timeout=30)
                absent = subprocess.run(["docker", "inspect", container_id], capture_output=True, text=True, timeout=5)
                receipt["cleanup"] = {"id": container_id, "remove_exit": removed.returncode, "absent": absent.returncode != 0}
        else:
            receipt["cleanup"] = {"id": container_id, "absent": True}
        if process is not None:
            if process.stdin:
                process.stdin.close()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)
        worker.save(ROOT / "candidate-after.json", inventory(actor))
        worker.save(ROOT / "result.json", receipt)
    print(json.dumps(receipt), flush=True)
    public = receipt["public_verification"]
    return 0 if not receipt["error"] and public and public["status"] == "completed" and public["passed"] and receipt["cleanup"]["absent"] else 1
if __name__=="__main__":sys.exit(main())
