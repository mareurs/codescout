import hashlib, io, json, pathlib, subprocess, tarfile
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
R=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/xhigh-patch-public-diagnostic-20261105")
C=R.parent/"complete-workflow-cold-recovery-20261105/workflow-1-xhigh"
A=pathlib.Path("/home/marius/work/claude/codescout/docs/research/data/2026-11-05-xhigh-expost-public-evidence.tar.gz")
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def main():
    manifest=load(R/"preparation-manifest.json"); result=load(R/"result.json")
    assert subprocess.check_output(["git","-C",str(V),"rev-parse","HEAD"],text=True).strip()==manifest["source_commit"]
    frozen=manifest.pop("composition_inventory_sha256")
    assert hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest()==frozen
    assert frozen==result["composition_inventory_sha256"]
    for path,digest in manifest["additional_files"].items():assert sha(pathlib.Path(path))==digest,path
    assert sha(C/"candidate.patch")==manifest["candidate_patch_sha256"]
    original=load(C/"receipt.json");assert original["terminal"]["subtype"]=="error_max_turns"
    assert not original["workflow_completed"] and original["public_verification"] is None
    before=load(R/"candidate-before.json");after=load(R/"candidate-after.json")
    changed=sorted(k for k in before.keys()|after.keys() if before.get(k)!=after.get(k))
    assert changed==[".git/index"],changed
    assert result["model_cost_usd"]=="0" and result["provider_calls"]==0 and result["error"] is None
    public=load(R/"public-verification.json")
    assert result["public_verification"]==public and public["status"]=="completed" and public["passed"]
    expected=manifest["profile"]["checks"]
    assert len(public["checks"])==len(expected)==4
    log_hashes={}
    for got,wanted in zip(public["checks"],expected):
        assert {k:got[k] for k in ("id","command")}==wanted and got["exit_code"]==0
        path=pathlib.Path(got["log"]);assert path.parent==R/"verification-0" and path.is_file()
        log_hashes[str(path)]=sha(path)
    argv=load(R/"launch.json")["argv"]
    assert argv[argv.index("--cpus")+1]=="4" and argv[argv.index("--memory")+1]=="12g"
    assert "--init" in argv and argv[argv.index("--pids-limit")+1]=="512"
    owner=load(R/"record-owner.json")
    assert result["cleanup"]["id"]==owner["container_id"] and result["cleanup"]["absent"] and result["cleanup"]["remove_exit"]==0
    absence=[]
    for target in (owner["container_id"],owner["name"]):
        p=subprocess.run(["docker","inspect",target],capture_output=True,text=True,timeout=5)
        assert p.returncode!=0,target
        absence.append(dict(target=target,exit_code=p.returncode,stderr=p.stderr))
    proof=dict(verified=True,scope="Ex-post public validation of a closed turn-censored patch; original workflow remains incomplete",
        model_cost_usd="0",provider_calls=0,source_commit=manifest["source_commit"],
        public_checks_passed=4,public_wall_s=result["public_wall_s"],changed_inventory_paths=changed,
        candidate_patch_sha256=manifest["candidate_patch_sha256"],log_hashes=log_hashes,
        absence_inspections=absence,resource_scope="Requested argv verified; no separate live HostConfig export for this diagnostic")
    (R/"independent-readback.json").write_text(json.dumps(proof,indent=2)+"\n")
    files=sorted(p for p in R.iterdir() if p.is_file())+sorted((R/"verification-0").glob("*.log"))
    files+=[pathlib.Path("/tmp/verify-xhigh-patch-public-01a15ca9-20261105.py"),pathlib.Path(__file__),
        pathlib.Path("/tmp/codescout-bg/455879-a720241d-bg_00000077.json")]
    payload={}
    for path in files:
        name=str(path.relative_to(R)) if path.is_relative_to(R) else "helpers/"+path.name
        assert name not in payload
        payload[name]=path
    hashes={name:sha(path) for name,path in payload.items()}
    assert not A.exists()
    with tarfile.open(A,"x:gz") as tf:
        for name,path in payload.items():tf.add(path,arcname=name,recursive=False)
        data=(json.dumps(hashes,indent=2)+"\n").encode();info=tarfile.TarInfo("payload-hashes.json");info.size=len(data);tf.addfile(info,io.BytesIO(data))
    with tarfile.open(A,"r:gz") as tf:
        for name,digest in hashes.items():assert hashlib.sha256(tf.extractfile(name).read()).hexdigest()==digest,name
    print(json.dumps(dict(verified=True,payload_files=len(hashes),archive=str(A),archive_sha256=sha(A),public_wall_s=result["public_wall_s"])),flush=True)
if __name__=="__main__":main()
