import hashlib,io,json,pathlib,shutil,subprocess,tarfile,time
BASE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/disk-cleanup-20261106")
DATA=pathlib.Path("/home/marius/work/claude/codescout/docs/research/data")
def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open("rb") as f:
  for b in iter(lambda:f.read(8*1024*1024),b""):h.update(b)
 return h.hexdigest()
def main():
 for n in ("cleanup-idle-gate","cleanup-closed-build-caches","inspect-unused-cargo-volumes","cleanup-empty-docker-volumes","seal-disk-cleanup"):
  src=pathlib.Path("/tmp")/(n+"-01a15ca9-20261106.py");shutil.copyfile(src,BASE/src.name)
 gate=json.loads((BASE/"gate-cache-cleanup.json").read_text());closed=json.loads((BASE/"closed-cache-result.json").read_text());vol=json.loads((BASE/"empty-volume-cleanup.json").read_text());protected=json.loads((BASE/"protected-after.json").read_text())
 assert gate["exclusive_lease_held_through_delete_and_verify"] and gate["lock_retained"]
 assert closed["all_nontarget_hashes_and_literal_links_unchanged"] and protected["all_admission_bound_inputs_unchanged"]
 df=subprocess.check_output(["df","-B1","/","/tmp"],text=True)
 (BASE/"df-final.txt").write_text(df)
 summary={"scope":"Safe closed-build-cache and actually-empty-anonymous-volume cleanup; protected backups, data and active campaign retained.",
 "gate_cache_allocation_removed_bytes":gate["allocated_bytes_removed"],"closed_cache_allocation_removed_bytes":closed["allocated_bytes_removed"],
 "cache_allocation_total_removed_bytes":gate["allocated_bytes_removed"]+closed["allocated_bytes_removed"],
 "cache_allocation_note":"Sum of du allocation over removed paths, not exclusive physical bytes freed. Btrfs compression/sharing, retained snapshots and concurrent writes prevent equating this sum with df delta.",
 "closed_project_copies":6,"cache_directories_removed":len(closed["deleted_paths"]),"preserved_nontarget_file_link_records":closed["preserved_nontarget_records_verified"],
 "historical_archives_unchanged":closed["historical_archive_hashes_reverified"],"retained_top_level_binaries_metadata":closed["top_level_product_binaries_and_target_metadata_unchanged"],
 "empty_anonymous_volumes_removed":vol["actual_removed_count"],"nonempty_anonymous_postgres_volumes_preserved":vol["nonempty_anonymous_volumes_kept"],
 "all_named_volumes_preserved":vol["named_volumes_kept"],"all_image_and_existing_container_delete_apis_avoided":vol["no_image_or_existing_container_deleted"],
 "admission_proof_files_sha256_matched":protected["admission_proof_files_sha256_matched"],"protected_actor_grader_images_present":protected["all_four_reserved_actor_and_grader_image_ids_present"],
 "snapshots_preserved":[2794,2795,3085,3086],"positive_snapshot_cache_witness":"Both inspected home snapshots still contain old action-budget target/debug/deps. Btrfs fi du over each old action-budget root reports Total16.31GiB/Exclusive0.00B/Set shared12.60GiB; not a unique physical reclaim estimate.",
 "peer_dependency_request":"One measured2.1.312 Claude peer queried about SAB reservations; no image/template release inferred from silence.",
 "df_final":df,"script_provider_calls":0,"completed_epoch":time.time()}
 (BASE/"result.json").write_text(json.dumps(summary,indent=2)+"\n")
 selected={str(p.relative_to(BASE)):p for p in sorted(BASE.iterdir()) if p.is_file() and not p.is_symlink()}
 manifest={n:{"sha256":sha(p),"bytes":p.stat().st_size} for n,p in selected.items()}
 archive=DATA/"2026-11-06-disk-cleanup-evidence.tar.gz";assert not archive.exists()
 with tarfile.open(archive,"x:gz",compresslevel=6) as tar:
  for n,p in sorted(selected.items()):tar.add(p,arcname=n,recursive=False)
  data=(json.dumps(manifest,indent=2)+"\n").encode();info=tarfile.TarInfo("payload-manifest.json");info.size=len(data);tar.addfile(info,io.BytesIO(data))
 seen={}
 with tarfile.open(archive,"r:gz") as tar:
  for item in tar:
   assert item.isfile();f=tar.extractfile(item);h=hashlib.sha256()
   for b in iter(lambda:f.read(8*1024*1024),b""):h.update(b)
   seen[item.name]={"sha256":h.hexdigest(),"bytes":item.size}
 assert set(seen)==set(manifest)|{"payload-manifest.json"}
 assert all(seen[n]==r for n,r in manifest.items())
 proof={"archive":str(archive),"sha256":sha(archive),"archive_bytes":archive.stat().st_size,"actual_regular_payload_files_verified":len(manifest),"all_payloads_reopened_and_sha256_verified":True,"summary":summary}
 (DATA/"2026-11-06-disk-cleanup-preservation.json").write_text(json.dumps(proof,indent=2)+"\n")
 print(json.dumps({k:v for k,v in proof.items() if k!="summary"}));print(df)
if __name__=="__main__":main()
