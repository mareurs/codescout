import json,pathlib,re,subprocess
OUT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/disk-cleanup-20261106")
IMAGE="sha256:02108f5d322dd89f1c9e552442c25acb0543dfdbc455693a5599624f20d9155d"
def main():
 volumes=json.loads((OUT/"dangling-volumes.json").read_text())
 selected=[v for v in volumes if re.fullmatch("[0-9a-f]{64}",v["Name"]) and v["Driver"]=="local" and "com.docker.volume.anonymous" in (v["Labels"] or {})]
 code="""import json,pathlib,subprocess
rows=[]
for p in sorted(pathlib.Path('/inspect').iterdir(),key=lambda p:int(p.name)):
 names=sorted(x.name for x in p.iterdir())
 tag=p/'CACHEDIR.TAG'
 signature=tag.read_bytes()[:100] if tag.is_file() and not tag.is_symlink() else b''
 cargo=signature.startswith(b'Signature: 8a477f597d28d172789f06886806bc55')
 cargo=cargo and all((p/'debug'/n).is_dir() for n in ('.fingerprint','build','deps'))
 size=subprocess.run(['du','-x','-s','-B1',str(p)],capture_output=True,text=True,check=True)
 rows.append({'index':int(p.name),'entries':names,'cargo_cache_markers':cargo,'allocated_bytes':int(size.stdout.split()[0])})
print(json.dumps(rows))
"""
 argv=["docker","run","--rm","--pull=never","--network","none","--read-only","--user","0:0","--cpus","1","--memory","256m","--pids-limit","64","--entrypoint","python3"]
 for i,v in enumerate(selected):argv+=["--mount","type=volume,src="+v["Name"]+",dst=/inspect/"+str(i)+",readonly"]
 argv += [IMAGE,"-c",code]
 (OUT/"unused-volume-readonly-probe-launch.json").write_text(json.dumps({"argv":argv,"mapping":[v["Name"] for v in selected]},indent=2)+"\n")
 p=subprocess.run(argv,capture_output=True,text=True,timeout=240)
 (OUT/"unused-volume-readonly-probe.stdout").write_text(p.stdout);(OUT/"unused-volume-readonly-probe.stderr").write_text(p.stderr)
 assert p.returncode==0,p.stderr
 rows=json.loads(p.stdout)
 for r in rows:r["name"]=selected[r["index"]]["Name"]
 (OUT/"unused-volume-contents.json").write_text(json.dumps(rows,indent=2)+"\n")
 print(json.dumps({"inspected_anonymous_volumes":len(rows),"cargo_cache_volumes":[r for r in rows if r["cargo_cache_markers"]],"nonempty_largest":sorted([r for r in rows if r["entries"]],key=lambda r:-r["allocated_bytes"])[:12],"empty_count":sum(not r["entries"] for r in rows)},indent=2),flush=True)
if __name__=="__main__":main()
