import hashlib,json,os,pathlib,shutil,subprocess,sys,time
BASE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
OUT=BASE/"disk-cleanup-20261106"
DATA=pathlib.Path("/home/marius/work/claude/codescout/docs/research/data")
ROOTS=[BASE/n for n in ("complete-workflow-calibration-20261105","complete-workflow-cold-recovery-20261105","complete-workflow-action-budget-20261105","xhigh-patch-public-diagnostic-20261105")]
TARGETS=[ROOTS[0]/"workflow-0-low/project/target",ROOTS[1]/"workflow-0-low/project/target",ROOTS[1]/"workflow-1-xhigh/project/target",ROOTS[2]/"workflow-0-low/project/target",ROOTS[2]/"workflow-1-xhigh/project/target",ROOTS[3]/"project/target"]
ARCHIVES={"2026-11-05-complete-workflow-evidence.tar.gz":"35e6b5523aaf29f3ef896c3bcc31d9e3623bb1b581782c4b272f6301cee835c8","2026-11-05-cold-recovery-final-evidence.tar.gz":"7ee89423633505746820ea6e5e9fe35efd13a02a8e78fac20560823831cd05d7","2026-11-05-action-budget-final-evidence.tar.gz":"5a9c571c6d1d926a645d0409a3910f7766fa246debb59d49198eafa7176d14b8","2026-11-05-xhigh-expost-public-evidence.tar.gz":"f7c7ba9d4f207d203b9806b2f31ef3cd41bf3d4b4ddfd1809bcdc81179eb74eb"}
def save(p,d):p.write_text(json.dumps(d,indent=2)+"\n")
def sha(p):
 h=hashlib.sha256()
 with p.open("rb") as f:
  for b in iter(lambda:f.read(8*1024*1024),b""):h.update(b)
 return h.hexdigest()
def inventory():
 rows={}
 for root in ROOTS:
  for parent,dirs,files in os.walk(root,followlinks=False):
   parent=pathlib.Path(parent)
   kept=[]
   for name in sorted(dirs):
    p=parent/name
    if name=="target":continue
    if p.is_symlink():rows[str(p.relative_to(BASE))]={"link":os.readlink(p)}
    else:kept.append(name)
   dirs[:]=kept
   for name in sorted(files):
    p=parent/name;key=str(p.relative_to(BASE))
    if p.is_symlink():rows[key]={"link":os.readlink(p)}
    elif p.is_file():rows[key]={"sha256":sha(p),"bytes":p.stat().st_size}
    else:raise RuntimeError("special non-target evidence file: "+str(p))
 return rows
def used_processes():
 matches=[]
 for proc in pathlib.Path("/proc").iterdir():
  if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
  observed=[]
  for name in ("cwd","exe"):
   try:observed.append(os.readlink(proc/name))
   except OSError:pass
  try:
   for p in (proc/"fd").iterdir():
    try:observed.append(os.readlink(p))
    except OSError:pass
  except OSError:pass
  try:observed.append((proc/"maps").read_text())
  except OSError:pass
  if any(str(root) in text for root in ROOTS for text in observed):matches.append(int(proc.name))
 return matches
def container_uses():
 r=subprocess.run(["docker","ps","-aq","--no-trunc"],capture_output=True,text=True,check=True,timeout=30)
 ids=r.stdout.split()
 if not ids:return []
 r=subprocess.run(["docker","inspect",*ids],capture_output=True,text=True,check=True,timeout=40)
 records=json.loads(r.stdout);assert {x["Id"] for x in records}==set(ids)
 matches=[]
 for c in records:
  for m in c["Mounts"]:
   source=m.get("Source","")
   if any(source==str(root) or source.startswith(str(root)+"/") for root in ROOTS):matches.append({"container_id":c["Id"],"source":source})
 return matches
def main():
 assert BASE.resolve()==BASE
 for root in ROOTS:assert root.resolve()==root and root.is_dir()
 for name,digest in ARCHIVES.items():assert sha(DATA/name)==digest,name
 if "--apply" not in sys.argv:
  assert not (OUT/"closed-cache-preview.json").exists()
  rows=inventory();save(OUT/"preserved-nontarget-before.json",rows)
  process=used_processes();containers=container_uses();assert not process and not containers,(process,containers)
  targets=[]
  for target in TARGETS:
   assert target.resolve()==target and target.is_dir() and (target/"CACHEDIR.TAG").read_text().startswith("Signature: 8a477f597d28d172789f06886806bc55\n")
   debug=target/"debug";assert all((debug/n).is_dir() for n in (".fingerprint","build","deps"))
   for name in (".fingerprint","build","deps","incremental"):
    p=debug/name
    if p.exists():
     assert p.resolve()==p and p.is_dir()
     amount=int(subprocess.check_output(["du","-x","-s","-B1",str(p)],text=True).split()[0]);targets.append({"path":str(p),"allocated_bytes_before":amount})
  retained={str(p):sha(p) for t in TARGETS for p in (t/"debug/codescout",t/".rustc_info.json",t/"CACHEDIR.TAG") if p.is_file() and not p.is_symlink()}
  plan={"closed_roots":[str(p) for p in ROOTS],"delete_only":targets,"preserved_nontarget_records":len(rows),"retained_target_files":retained,"verified_historical_archives":ARCHIVES,"process_users":process,"container_users":containers,"purpose":"Delete regenerable debug build caches from six closed own-run project copies. Source trees, Git metadata, candidate patches, exact logs, model requests/responses, terminal costs, source snapshots, archives and top-level product executables remain."}
  save(OUT/"closed-cache-preview.json",plan);print(json.dumps({"paths":len(targets),"allocated_candidate_bytes":sum(r["allocated_bytes_before"] for r in targets),"preserved_nontarget_records":len(rows),"retained_target_files":len(retained),"process_users":process,"container_users":containers}),flush=True);return
 plan=json.loads((OUT/"closed-cache-preview.json").read_text())
 assert not (OUT/"closed-cache-result.json").exists()
 assert not used_processes() and not container_uses(),"an old root became active"
 for name,digest in ARCHIVES.items():assert sha(DATA/name)==digest
 assert inventory()==json.loads((OUT/"preserved-nontarget-before.json").read_text()),"non-target inputs changed since preview"
 for p,digest in plan["retained_target_files"].items():assert sha(pathlib.Path(p))==digest
 allowed={str(t/"debug"/n) for t in TARGETS for n in (".fingerprint","build","deps","incremental")}
 assert all(row["path"] in allowed for row in plan["delete_only"])
 before=subprocess.check_output(["df","-B1","/"],text=True)
 for row in plan["delete_only"]:
  p=pathlib.Path(row["path"]);assert p.resolve()==p and p.is_dir() and not p.is_symlink()
  shutil.rmtree(p)
  assert not p.exists()
 afterrows=inventory();assert afterrows==json.loads((OUT/"preserved-nontarget-before.json").read_text()),"non-target evidence differs"
 for p,digest in plan["retained_target_files"].items():assert sha(pathlib.Path(p))==digest
 for name,digest in ARCHIVES.items():assert sha(DATA/name)==digest
 result={"deleted_paths":[r["path"] for r in plan["delete_only"]],"allocated_bytes_removed":sum(r["allocated_bytes_before"] for r in plan["delete_only"]),"preserved_nontarget_records_verified":len(afterrows),"all_nontarget_hashes_and_literal_links_unchanged":True,"top_level_product_binaries_and_target_metadata_unchanged":True,"historical_archive_hashes_reverified":ARCHIVES,"df_before":before,"df_after":subprocess.check_output(["df","-B1","/"],text=True),"no_model_or_provider_calls":True,"limits":"Compiled dependency/test artifacts regenerate from retained source/lockfiles/commands; their warm-cache performance is intentionally not retained. No source tree, model output, cost/log/patch, image/container/volume or active external input removed."}
 save(OUT/"closed-cache-result.json",result);print(json.dumps({k:v for k,v in result.items() if k not in ("deleted_paths","historical_archive_hashes_reverified")}),flush=True)
if __name__=="__main__":main()
