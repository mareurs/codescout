import fcntl,json,os,pathlib,shutil,subprocess,time
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/disk-cleanup-20261106")
POOL=pathlib.Path("/home/marius/.cache/codescout-gate")
def save(p,d):p.write_text(json.dumps(d,indent=2)+"\n")
def main():
 slot=POOL/"slot-0";lock=POOL/"slot-0.lock";target=slot/"debug"
 assert POOL.resolve()==POOL and slot.resolve()==slot and target.resolve()==target and lock.is_file() and not lock.is_symlink()
 fd=os.open(lock,os.O_RDWR);inode=os.fstat(fd).st_ino
 try:
  try:fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
  except BlockingIOError:
   save(ROOT/"gate-cache-cleanup.json",{"skipped":"existing slot-0 lease is busy","deleted":False});print("gate cache busy, kept");return
  assert lock.stat().st_ino==inode
  assert (slot/".rustc_info.json").is_file()
  assert all((target/name).is_dir() for name in (".fingerprint","build","deps"))
  before=int(subprocess.check_output(["du","-x","-s","-B1",str(target)],text=True).split()[0])
  # Only regenerable Cargo debug cache, under its existing official lease throughout.
  save(ROOT/"gate-cache-cleanup-started.json",{"target":str(target),"existing_lock":str(lock),"lock_inode":inode,"allocated_bytes_before":before,"started_epoch":time.time(),"preserve":"slot root, locks, source trees, release artifacts and all experiment evidence"})
  df_before=subprocess.check_output(["df","-B1","/"],text=True)
  shutil.rmtree(target)
  assert not target.exists() and lock.stat().st_ino==inode and os.fstat(fd).st_ino==inode
  result={"target":str(target),"existing_lock":str(lock),"lock_inode":inode,"exclusive_lease_held_through_delete_and_verify":True,"allocated_bytes_removed":before,"target_absent":True,"lock_retained":True,"df_before":df_before,"df_after":subprocess.check_output(["df","-B1","/"],text=True),"limits":"du allocation reduction and concurrent filesystem df observations are different measures. No source, run log, model output, Docker resource or experimental cache deleted."}
  save(ROOT/"gate-cache-cleanup.json",result);print(json.dumps(result),flush=True)
 finally:os.close(fd)
if __name__=="__main__":main()
