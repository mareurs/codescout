import json,pathlib,re,subprocess
OUT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/disk-cleanup-20261106")
def run(argv):return subprocess.run(argv,capture_output=True,text=True,timeout=20)
def main():
 data=json.loads((OUT/"unused-volume-contents.json").read_text())
 expected={r["Name"]:r for r in json.loads((OUT/"dangling-volumes.json").read_text())}
 candidates=[r["name"] for r in data if not r["entries"] and r["allocated_bytes"]==0]
 assert all(re.fullmatch("[0-9a-f]{64}",n) and "com.docker.volume.anonymous" in (expected[n]["Labels"] or {}) and expected[n]["Driver"]=="local" for n in candidates)
 actions=[]
 for name in candidates:
  p=run(["docker","volume","inspect",name])
  if p.returncode:actions.append({"name":name,"skipped":"already absent"});continue
  v=json.loads(p.stdout)[0];old=expected[name]
  assert all(v[k]==old[k] for k in ("Name","CreatedAt","Driver","Labels","Mountpoint"))
  assert v["Mountpoint"]=="/var/lib/docker/volumes/"+name+"/_data"
  p=run(["docker","ps","-aq","--filter","volume="+name])
  assert p.returncode==0
  if p.stdout.strip():actions.append({"name":name,"skipped":"container reference appeared"});continue
  p=run(["sudo","-n","find",v["Mountpoint"],"-mindepth","1","-maxdepth","1","-print","-quit"])
  assert p.returncode==0
  if p.stdout:actions.append({"name":name,"skipped":"content appeared"});continue
  p=run(["docker","volume","rm",name])
  if p.returncode:actions.append({"name":name,"skipped":"Docker refused non-force removal","stderr":p.stderr});continue
  assert p.stdout.strip()==name
  p=run(["docker","volume","inspect",name]);assert p.returncode!=0 and "no such volume" in p.stderr.lower()
  actions.append({"name":name,"removed":True,"empty_rechecked_before_delete":True,"identity_created_at":v["CreatedAt"],"absent_after":True})
 result={"actions":actions,"actual_removed_count":sum(a.get("removed",False) for a in actions),"nonempty_anonymous_volumes_kept":sum(bool(r["entries"]) for r in data),"named_volumes_kept":True,"no_image_or_existing_container_deleted":True,"limits":"Zero-content anonymous volumes only; no meaningful disk-space gain claimed. All ten observed nonempty anonymous PostgreSQL volumes and every named volume preserved."}
 (OUT/"empty-volume-cleanup.json").write_text(json.dumps(result,indent=2)+"\n")
 print(json.dumps({k:v for k,v in result.items() if k!="actions"}),flush=True)
if __name__=="__main__":main()
