"""Real pinned CLI/native controls, provider disabled, including >32 actual actions."""
import hashlib,importlib.util,json,pathlib,shutil,subprocess
from unittest.mock import patch
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/complete-workflow-action-budget-20261105")
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);obj=importlib.util.module_from_spec(spec);spec.loader.exec_module(obj);return obj
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def lines(p):return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]
def main():
    q=module("action_integrated","/tmp/qualify-integrated-runtime-01a15ca9-20261105.py")
    q.BASE=ROOT/"qualification-action";q.ROOT=q.BASE/"qualification";q.BASE.mkdir()
    original_one=q.worker.one
    def one(*args,**kwargs):
        kwargs["client_budget_usd"]="4";return original_one(*args,**kwargs)
    q.worker.one=one
    original_check=q.original_check
    def observed_check(out,image,command,log,timeout_s):
        code=original_check(out,image,command,log,timeout_s)
        owner=load(out/"record-owner.json")
        p=subprocess.run(["docker","inspect",owner["container_id"]],check=True,capture_output=True,text=True,timeout=5)
        row=json.loads(p.stdout)[0];host=row["HostConfig"]
        actor=next(m for m in row["Mounts"] if m["Destination"]=="/testbed")
        env=dict(item.split("=",1) for item in row["Config"]["Env"] if "=" in item)
        witness=dict(container_id=row["Id"],image=row["Image"],init=host["Init"],nano_cpus=host["NanoCpus"],
            pids_limit=host["PidsLimit"],memory_bytes=host["Memory"],actor_source=actor["Source"],
            actor_read_write=actor["RW"],cargo_target_dir=env["CARGO_TARGET_DIR"],command=command,exit_code=code)
        assert witness["init"] and witness["nano_cpus"]==4000000000 and witness["pids_limit"]==512
        assert witness["memory_bytes"]==12*1024**3 and witness["container_id"]==owner["container_id"] and witness["image"]==image
        assert pathlib.Path(actor["Source"])==(out/"project").resolve() and actor["RW"] and env["CARGO_TARGET_DIR"]=="/testbed/target"
        with (out/"native-runtime-observations.jsonl").open("a") as f:f.write(json.dumps(witness)+"\n")
        return code
    q.observed_check=observed_check
    q.main()
    rb=module("action_readback","/tmp/readback-cold-runtime-01a15ca9-20261105.py");rb.BASE=q.BASE;rb.main()
    frozen=q.worker.P/"launch-budget-requalification-20261104"
    longroot=q.BASE/"qualification-long";longroot.mkdir()
    for name in ("source","skill-only-plugin"):shutil.copytree(frozen/name,longroot/name)
    original_server=q.worker.server
    def long_server(*args,**kwargs):
        server=original_server(*args,**kwargs)
        assert server.scripted and len(server.plan)==8
        server.plan.extend([("mcp__codescout__read_file",{"path":"hfa-transport-probe.txt","force":True}) for _ in range(35)])
        return server
    with patch.object(q.worker,"server",long_server):
        long=q.qualification.cell(longroot,frozen,"success")
    q.worker.save(longroot/"result.json",long)
    out=longroot/"success";receipt=load(out/"receipt.json")
    events=lines(out/"stream.jsonl");first=[]
    for event in events:
        if event.get("type")=="result":break
        if event.get("type")=="assistant":
            first += [item for item in event["message"]["content"] if item.get("type")=="tool_use"]
    assert len(first)>32,len(first)
    terminals=[e for e in events if e.get("type")=="result"]
    assert terminals and all(not e.get("is_error") and e.get("subtype")=="success" for e in terminals)
    assert receipt["workflow_completed"] and receipt["lifecycle"]["status"]=="settled"
    assert receipt["forwarded"]==0 and receipt["cost_usd"]=="0" and not receipt["unknown_provider_cost"]
    assert receipt["background_evidence"]["complete"] and not receipt["background_evidence"]["errors"]
    for saved in receipt["background_evidence"]["logs"]:
        path=pathlib.Path(saved["saved_path"]);assert digest(path)==saved["sha256"] and b"WORKFLOW_BACKGROUND_FINISHED" in path.read_bytes()
    all_cells=[q.BASE/("qualification" if effort=="low" else "qualification-xhigh")/mode
        for effort,mode in (("low","success"),("low","repair"),("low","unknown"),("xhigh","success"))]+[out]
    import audit
    from core import audit_request
    wire=[]
    for cell in all_cells:
        argv=load(cell/"launch.json")["argv"]
        assert "--max-turns" not in argv and argv[argv.index("--max-budget-usd")+1]=="4"
        inspected=audit.inspect_cell(cell);assert inspected["hint_visible_on_wire"] and inspected["boundary_denied"]
        expected=load(cell/"expected.json");requests=sorted(cell.glob("request-*.json"))
        for path in requests:audit_request(load(path),expected)
        wire.append(dict(cell=str(cell),requests=len(requests),**inspected))
    owner=load(out/"record-owner.json")
    absent=[]
    for identity in {owner["container_id"]}|{r["name"] for r in load(out/"cleanup.json")}:
        p=subprocess.run(["docker","inspect",identity],capture_output=True,text=True,timeout=5)
        assert p.returncode!=0 and "no such" in p.stderr.lower()
        absent.append(dict(identity=identity,exit_code=p.returncode,stderr=p.stderr))
    longproof=dict(verified=True,first_turn_observed_tool_use_count=len(first),terminal_events=len(terminals),
        workflow_completed=True,provider_cost_usd="0",receipt_path=str(out/"receipt.json"),receipt_sha256=digest(out/"receipt.json"),
        stream_path=str(out/"stream.jsonl"),stream_sha256=digest(out/"stream.jsonl"),cleanup_inspections=absent)
    q.worker.save(q.BASE/"long-action-readback.json",longproof)
    hashes=load(q.BASE/"qualification-summary.json")["runtime_source_hashes"]
    for path,want in hashes.items():assert digest(pathlib.Path(path))==want
    proof=dict(qualified=True,cli_budget_usd="4",provider_cost_usd="0",runtime_hashes=hashes,
        cells=["low:success","low:repair","low:unknown","xhigh:success"],wire_controls=wire,
        readback=str(q.BASE/"independent-readback.json"),readback_sha256=digest(q.BASE/"independent-readback.json"),
        long_action_control=longproof,long_readback_sha256=digest(q.BASE/"long-action-readback.json"),
        script_sha256=digest(pathlib.Path(__file__)),
        scope="Actual scripted CLI/native background/public transport with >32 observed first-turn tool actions; no model-quality conclusion.")
    q.worker.save(ROOT/"qualification.json",proof)
    print(json.dumps(dict(qualified=True,provider_cost_usd="0",first_turn_observed_tool_use_count=len(first))),flush=True)
if __name__=="__main__":main()
