import hashlib,importlib.util,json,pathlib,subprocess
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
R=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/complete-workflow-action-budget-20261105")
REVIEW=pathlib.Path("/tmp/workflow-action-review-01a15ca9-20261105")
SID="01a15ca9-f939-7603-acb5-01c6b02f68e2"
GATE=pathlib.Path("/tmp/codescout-bg/455879-a720241d-bg_00000079.json")
def load(p):return json.loads(p.read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(["git","-C",str(V),*args],text=True).strip()
def main():
    binding=load(REVIEW/"review-binding.json")
    for path,want in binding["source_hashes"].items():assert digest(V/path)==want,path
    assert digest(REVIEW/"review.md")==binding["review_report_sha256"]
    aggregate=load(REVIEW/"aggregate.json");assert aggregate["accepted"] and aggregate["unresolved_observed_survivors"]==0
    gate=load(GATE);assert gate["state"]=="exited" and gate["exit_code"]==0
    assert not git("status","--porcelain")
    commit=git("rev-parse","HEAD");assert commit!="0f7fb1dd69f6807e4a5564c25ce379bf267c7fc5"
    assert "Session-Id: codex:"+SID in git("show","-s","--format=%B","HEAD")
    assert set(git("diff-tree","--no-commit-id","--name-only","-r","HEAD").splitlines())==set(binding["source_hashes"])
    assert not (R/"started.json").exists() and not (R/"review.json").exists()
    spec=importlib.util.spec_from_file_location("action_admission_driver",V/"tools/hint_authority_workflow/driver.py")
    driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
    assert driver.registration()==load(R/"plan.json")
    assert driver.composition(R)==binding["fingerprint"]
    for key,name in (("qualification_sha256","qualification.json"),("acceptance_sha256","acceptance-controls.json"),
        ("cold_control_sha256","cold-public-control.json"),("plan_sha256","plan.json")):
        assert digest(R/name)==binding[key],name
    q=load(R/"qualification.json");long=q["long_action_control"]
    assert long["verified"] and long["first_turn_observed_tool_use_count"]>32 and long["workflow_completed"]
    assert digest(pathlib.Path(long["stream_path"]))==long["stream_sha256"]
    assert digest(pathlib.Path(long["receipt_path"]))==long["receipt_sha256"]
    installed=dict(binding,parent_admission=dict(source_commit=commit,gate_record=str(GATE),gate_record_sha256=digest(GATE),
        gate_verified=True,review_binding_sha256=digest(REVIEW/"review-binding.json")))
    with (R/"review.json").open("x") as f:json.dump(installed,f,indent=2);f.write("\n")
    fingerprint=driver.check(R)
    result=dict(admitted=True,paid_started=False,provider_calls=0,source_commit=commit,session_id=SID,
        fingerprint=fingerprint,thread_prior_usd=str(driver.THREAD_PRIOR),thread_cap_usd=str(driver.THREAD_CAP),
        allocation_usd=str(driver.ALLOCATION),arm_cap_usd=str(driver.ARM_CAP),gate=gate,
        review_binding_sha256=digest(REVIEW/"review-binding.json"),qualification_sha256=digest(R/"qualification.json"),
        scope="Actual no-provider preflight after exact-source commit and gate; no model outcome measured.")
    (R/"preflight.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))
if __name__=="__main__":main()
