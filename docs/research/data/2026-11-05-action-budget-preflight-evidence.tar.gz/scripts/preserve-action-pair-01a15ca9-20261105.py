"""Bounded sealed evidence archive; excludes actor/build trees and credential files."""
import hashlib,io,json,os,pathlib,sys,tarfile
M=pathlib.Path("/home/marius/work/claude/codescout")
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
R=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/complete-workflow-action-budget-20261105")
REVIEW=pathlib.Path("/tmp/workflow-action-review-01a15ca9-20261105")
def load(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
    phase=sys.argv[1];assert phase in {"preflight","final"}
    assert load(R/"preflight.json")["admitted"] is True
    if phase=="preflight":assert not (R/"started.json").exists()
    if phase=="final":assert load(R/"independent-paid-readback.json")["verified"]
    payload={}
    skip={"source","skill-only-plugin","project","native-home","client-home","target","grader-target",".git","__pycache__","pristine","work"}
    for label,root in (("campaign",R),("review",REVIEW)):
        for directory,dirs,files in os.walk(root,followlinks=False):
            dirs[:]=[d for d in dirs if d not in skip and not d.endswith("-grader")]
            for name in files:
                p=pathlib.Path(directory)/name
                if not p.is_symlink() and p.suffix not in {".pyc",".tar",".gz"}:payload[label+"/"+str(p.relative_to(root))]=p.read_bytes()
    for directory in ("agent_lifecycle","hint_authority_pilot","hint_authority_completion","hint_authority_resume","hint_authority_workflow"):
        for p in (V/"tools"/directory).iterdir():
            if p.is_file() and p.suffix in {".py",".md",".json"}:payload["source/"+str(p.relative_to(V))]=p.read_bytes()
    for p,h in load(R/"review.json")["source_hashes"].items():assert sha((V/p).read_bytes())==h
    scripts=("promote-action-policy","qualify-action-budget","bind-action-controls","admit-action-pair",
        "verify-action-pair","preserve-action-pair","capture-action-native","action-pair-status",
        "qualify-integrated-runtime","readback-cold-runtime")
    for name in scripts:
        p=pathlib.Path("/tmp")/(name+"-01a15ca9-20261105.py")
        if p.exists():payload["scripts/"+p.name]=p.read_bytes()
    for name in ("action-promotion-01a15ca9-20261105.json","commit-peer-scope-01a15ca9-20261105.txt"):
        p=pathlib.Path("/tmp")/name;payload["setup/"+name]=p.read_bytes()
    for p in pathlib.Path("/tmp").glob("workflow-*-01a15ca9.log"):payload["test-logs/"+p.name]=p.read_bytes()
    records=[pathlib.Path("/tmp/codescout-bg/455879-a720241d-bg_00000079.json"),
        pathlib.Path("/tmp/codescout-bg/455879-a720241d-bg_0000007b.json")]
    if phase=="final":records.append(pathlib.Path(load(R/"paid-job.json")["record"]))
    for p in records:
        row=load(p);assert row["state"]=="exited"
        payload["jobs/"+p.name]=p.read_bytes();payload["jobs/"+p.stem+".log"]=pathlib.Path(row["log_path"]).read_bytes()
    manifest={n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(payload.items())}
    archive=M/"docs/research/data"/("2026-11-05-action-budget-"+phase+"-evidence.tar.gz")
    assert not archive.exists()
    with tarfile.open(archive,"x:gz") as tf:
        for name,b in payload.items():
            info=tarfile.TarInfo(name);info.size=len(b);tf.addfile(info,io.BytesIO(b))
        b=(json.dumps(manifest,indent=2)+"\n").encode();info=tarfile.TarInfo("manifest.json");info.size=len(b);tf.addfile(info,io.BytesIO(b))
    with tarfile.open(archive,"r:gz") as tf:
        assert set(tf.getnames())==set(payload)|{"manifest.json"}
        assert json.load(tf.extractfile("manifest.json"))==manifest
        for name,h in manifest.items():
            b=tf.extractfile(name).read();assert len(b)==h["bytes"] and sha(b)==h["sha256"]
    result=dict(phase=phase,archive=str(archive),sha256=sha(archive.read_bytes()),payload_files=len(payload),every_payload_hash_verified=True)
    (M/"docs/research/data"/("2026-11-05-action-budget-"+phase+"-archive.json")).write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result),flush=True)
if __name__=="__main__":main()
