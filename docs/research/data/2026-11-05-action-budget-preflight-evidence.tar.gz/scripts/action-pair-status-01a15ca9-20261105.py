import json,pathlib
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/complete-workflow-action-budget-20261105")
def main():
    rows=[]
    for label in ("workflow-0-low","workflow-1-xhigh"):
        out=ROOT/label
        if not out.exists():continue
        stream=out/"stream.jsonl";events=[]
        if stream.exists():
            for line in stream.read_text(errors="replace").splitlines():
                try:events.append(json.loads(line))
                except ValueError:pass
        terminals=[r for r in events if r.get("type")=="result"]
        blocks=[b for r in events if r.get("type")=="assistant" for b in r.get("message",{}).get("content",[]) if isinstance(b,dict) and b.get("type")=="tool_use"]
        rows.append(dict(attempt=label,request_files=len(list(out.glob("request-*.json"))),
            terminal_events=len(terminals),latest_terminal_cost=terminals[-1].get("total_cost_usd") if terminals else None,
            last_tools=[b.get("name") for b in blocks[-5:]],
            last_commands=[b.get("input",{}).get("command","")[:240] for b in blocks if b.get("name")=="mcp__codescout__run_command"][-3:],
            public_log_files=[str(p.relative_to(out)) for p in sorted(out.glob("verification-*/*.log"))],
            receipt_exists=(out/"receipt.json").exists()))
    result=dict(attempts=rows)
    for name in ("inflight.json","halt.json","results.json"):
        p=ROOT/name
        if p.exists():
            value=json.loads(p.read_text())
            if name=="results.json":value={k:v for k,v in value.items() if k!="results"}|dict(recorded_rows=len(value["results"]))
            result[name]=value
    print(json.dumps(result,indent=2))
if __name__=="__main__":main()
