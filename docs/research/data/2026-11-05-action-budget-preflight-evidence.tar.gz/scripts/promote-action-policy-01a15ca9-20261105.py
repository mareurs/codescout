import hashlib,json,pathlib,shutil,subprocess
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
S=pathlib.Path("/tmp/workflow-turn-policy-01a15ca9-20261105")
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    assert subprocess.check_output(["git","-C",str(V),"rev-parse","HEAD"],text=True).strip()=="0f7fb1dd69f6807e4a5564c25ce379bf267c7fc5"
    assert not subprocess.check_output(["git","-C",str(V),"status","--porcelain"],text=True)
    baseline=json.loads((S/"baseline-source-hashes.json").read_text())
    changed=[p for p,h in baseline.items() if sha(S/p)!=h]
    expected=["tools/hint_authority_pilot/run.py","tools/agent_lifecycle/test_runtime.py",
        "tools/hint_authority_workflow/driver.py","tools/hint_authority_workflow/test_driver.py","tools/hint_authority_workflow/README.md"]
    assert set(changed)==set(expected)
    accepted=json.loads(pathlib.Path("/tmp/workflow-action-review-01a15ca9-20261105/source-hashes.json").read_text())
    for p,h in baseline.items():assert sha(V/p)==h,p
    for p in expected:
        assert sha(S/p)==accepted[p],p
    for p in expected:shutil.copyfile(S/p,V/p)
    proof=dict(baseline_commit="0f7fb1dd69f6807e4a5564c25ce379bf267c7fc5",
        paths={p:sha(V/p) for p in expected},review=str(pathlib.Path("/tmp/workflow-action-review-01a15ca9-20261105/review.md")))
    pathlib.Path("/tmp/action-promotion-01a15ca9-20261105.json").write_text(json.dumps(proof,indent=2)+"\n")
    print(json.dumps(proof),flush=True)
if __name__=="__main__":main()
