import hashlib,importlib.util,json,pathlib,shutil
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
B=pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
R=B/"complete-workflow-action-budget-20261105";OLD=B/"complete-workflow-cold-recovery-20261105"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def inventory(root):
    result={}
    for p in root.rglob("*"):
        rel=str(p.relative_to(root))
        if p.is_symlink():result[rel+"#link"]=str(p.readlink())
        if p.is_file():result[rel]=sha(p)
    return result
def main():
    for name in ("source","skill-only-plugin"):
        assert inventory(R/name)==inventory(OLD/name),name
    assert sha(R/"reference.patch")==sha(OLD/"reference.patch")
    copied={}
    for name in ("acceptance-controls.json","cold-public-control.json"):
        assert not (R/name).exists()
        shutil.copyfile(OLD/name,R/name);copied[name]=dict(source=str(OLD/name),sha256=sha(R/name))
    q=load(R/"qualification.json")
    assert q["qualified"] and q["provider_cost_usd"]=="0" and len(q["wire_controls"])==5
    long=q["long_action_control"]
    assert long["verified"] and long["first_turn_observed_tool_use_count"]>32 and long["workflow_completed"]
    assert sha(pathlib.Path(long["receipt_path"]))==long["receipt_sha256"]
    assert sha(pathlib.Path(long["stream_path"]))==long["stream_sha256"]
    assert sha(pathlib.Path(q["readback"]))==q["readback_sha256"]
    for p,h in q["runtime_hashes"].items():assert sha(pathlib.Path(p))==h
    proof=dict(reused_onboarding=True,source_files=len(inventory(R/"source")),controls=copied,provider_calls=0,
        legacy_source=str(OLD),scope="Exact immutable source/plugin/reference and acceptance/cold proof reuse; no new onboarding or private oracle runs.")
    (R/"reused-controls.json").write_text(json.dumps(proof,indent=2)+"\n")
    spec=importlib.util.spec_from_file_location("action_driver",V/"tools/hint_authority_workflow/driver.py")
    d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
    assert d.registration()==load(R/"plan.json")
    binding=dict(fingerprint=d.composition(R),source_hashes=load(pathlib.Path("/tmp/workflow-action-review-01a15ca9-20261105/source-hashes.json")),
        qualification_sha256=sha(R/"qualification.json"),acceptance_sha256=sha(R/"acceptance-controls.json"),
        cold_control_sha256=sha(R/"cold-public-control.json"),plan_sha256=sha(R/"plan.json"),
        reused_controls_sha256=sha(R/"reused-controls.json"))
    (R/"review-request.json").write_text(json.dumps(binding,indent=2)+"\n")
    print(json.dumps(dict(bound=True,source_files=proof["source_files"],provider_calls=0,**binding)),flush=True)
if __name__=="__main__":main()
