# Workflow action-policy delta review

Assessment: accepted for the exact five-path staged source delta against base 0f7fb1dd69f6807e4a5564c25ce379bf267c7fc5. No unresolved Critical or Important finding remains from this finite review. This is source-review acceptance, not admission for a paid run.

Source: /tmp/workflow-turn-policy-01a15ca9-20261105. The staged source and V were read-only throughout; only this review directory's private work/ copy was mutated. source-hashes.json identifies the accepted five files. The prior recovery delta was not re-reviewed.

## Evidence

Observed initial baselines: 57 lifecycle tests and 23 driver tests pass. After the sole final test addition, its focused test passes with all four arm/identity subtests. The executor reports its 24-test driver suite passed; this reviewer independently ran only the new focused test after that final addition.

Eight distinct mutations were actually applied, followed by one exact reapplication: nine mutation executions, eight killed executions, one historical survivor. The survivor was closed by the exact reapplication. Every execution has its patch, full test log, result JSON and hash-verified restoration. There are zero unresolved observed survivors in this finite set. This is not a coverage percentage.

- a01: restore workflow32; killed by actual workflow launch argv test.
- a02: remove legacy32 only; killed by legacy launch expectation (argv.index raises because the required flag is absent).
- a03: remove CLI money option; killed at actual argv budget expectations, not an import or syntax failure.
- a04: bypass new-history raw reconciliation; killed by all six arm-by-stream/stdout/coverage cases.
- a05: omit pair_completed guard; killed by nonfinal-pair case.
- a06: omit new-history effort/declaration identity guards; initially survived all 23 driver tests.
- a07: omit closed cohort spend from registration sum; killed because registration rejects the inconsistent prior.
- a08: replace closed history reconstruction with its literal known total; killed by registration's changed-history test.
- a09: exact a06 reapplication after regression addition; killed by all four low/xhigh effort/declaration subtests. Patch bytes match a06.

## Strengths and plan alignment

tools/hint_authority_pilot/run.py:131 confines removal of --max-turns to opt-in workflow execution while retaining the existing monetary option, legacy32 policy and unchanged worker interface. The through-worker launch checks directly observe the argv that reaches workflow execution.

tools/hint_authority_workflow/driver.py:187 reconstructs both closed arm costs through the existing raw stream/stdout/receipt/coverage reconciler before comparing the final ledger. driver.py:208 includes that reconstructed spend in the registered prior and records schema3 with max_turns null. Applied raw-callsite, finality, omitted-sum and skipped-reconstruction mutations were all killed.

The five-file diff matches spec02ff0a616cd02962 and planc336f2784639da9c. No lifecycle resource/deadline/public command/oracle change was introduced by this delta.

## Resolved Important finding

tools/hint_authority_workflow/driver.py:199 and test_driver.py:338: new history tests originally did not discriminate effort/declaration identity. Removing both guards while leaving raw costs checked passed all 23 tests (a06). New test_driver.py:381 changes each label independently in each arm while raw costs remain fixed. Exact reapplication a09 now yields four assertion failures. Ledger issue30e7c2eed48c6f1e; no remaining source/test fix requested from this review.

## Declined to judge

- Actual CLI/native completion beyond32actions and changed-worker qualifications: assigned to executor, pending; no fixture count is treated as a measured native action count.
- Full gate, commit and source promotion: executor responsibilities, not verified by this source-only review.
- Paid model outcomes, generic quality or effort-effect claims: this remains an exposed-task diagnostic.
- Previously reviewed unchanged recovery/runtime logic: outside this narrow delta.
- Live closed-cohort raw-data archive integrity: prior executor independent readback is context; review validates new reconciliation using controlled fixtures, not by rerunning the old cohort.

No Docker, provider, real credential or actual qualifier calls were performed by this reviewer. Final composition and proof bindings remain pending until the exact accepted bytes are promoted and executor supplies qualified ROOT artifacts.

Final verdict: accepted for these exact staged five-file bytes, pending the separately required native qualification, full gate and final proof binding.

Ledger checked: 3a69dda510501d5a, 30e7c2eed48c6f1e.
