import copy
import pathlib
import tempfile
import unittest
import baseline_pair as b


class BarrierTests(unittest.TestCase):
    def setUp(self):
        self.cfg = {'image': 'baseline', 'prompt': 'Public issue and pristine source only'}
        self.native = ['docker', 'run', '--mount', 'type=bind,src=/fresh/knowledge,dst=/testbed/.codescout', 'baseline', 'server', 'stdio', 'end']
        self.allowed = ['type=bind,src=/fresh/knowledge,dst=/testbed/.codescout']

    def check(self, cfg=None, native=None):
        return b.validate_author(cfg or self.cfg, native or self.native, self.allowed, 'baseline')

    def test_accepts_pristine_inventory(self):
        self.assertEqual(self.check(), self.allowed)

    def test_rejects_candidate_image_before_launch(self):
        cfg = dict(self.cfg, image='candidate')
        with self.assertRaisesRegex(ValueError, 'image'):
            self.check(cfg=cfg)

    def test_rejects_native_image_drift(self):
        argv = self.native.copy(); argv[-4] = 'candidate'
        with self.assertRaisesRegex(ValueError, 'image'):
            self.check(native=argv)

    def test_rejects_readonly_proposal_mount(self):
        argv = self.native.copy(); argv[2:2] = ['--mount', 'type=bind,src=/saved/proposal,dst=/proposal,readonly']
        with self.assertRaisesRegex(ValueError, 'mount'):
            self.check(native=argv)

    def test_rejects_prior_verifier_writable_state(self):
        argv = self.native.copy(); argv[3] = 'type=bind,src=/previous/knowledge,dst=/testbed/.codescout'
        with self.assertRaisesRegex(ValueError, 'mount'):
            self.check(native=argv)

    def test_rejects_native_volume_alias(self):
        argv = self.native.copy(); argv[2:2] = ['-v', '/secret:/extra:ro']
        with self.assertRaisesRegex(ValueError, 'volume'):
            self.check(native=argv)

    def test_rejects_private_witness_prompt(self):
        cfg = dict(self.cfg, prompt='Investigate mixed_str_length_result_does_replace_last')
        with self.assertRaisesRegex(ValueError, 'prompt'):
            self.check(cfg=cfg)

    def test_rejects_observation_packet_prompt(self):
        cfg = dict(self.cfg, prompt='Read /public-observations/baseline.log')
        with self.assertRaisesRegex(ValueError, 'prompt'):
            self.check(cfg=cfg)

    def test_pair_freezes_both_before_first_evaluation(self):
        events = []
        def author(arm): events.append('author:' + arm); return arm
        def freeze(arm, capture): events.append('freeze:' + arm); return 'frozen:' + capture
        def evaluate(arm, frozen): events.append('evaluate:' + arm); return frozen
        result = b.execute_pair(['low', 'xhigh'], author, freeze, evaluate)
        self.assertEqual(events, ['author:low', 'freeze:low', 'author:xhigh', 'freeze:xhigh', 'evaluate:low', 'evaluate:xhigh'])
        self.assertEqual(result, ['frozen:low', 'frozen:xhigh'])

    def test_failed_second_freeze_prevents_all_reference_access(self):
        events = []
        def freeze(arm, capture):
            if arm == 'xhigh': raise ValueError('incomplete capture')
            return capture
        with self.assertRaisesRegex(ValueError, 'incomplete capture'):
            b.execute_pair(['low', 'xhigh'], lambda a:a, freeze, lambda *args:events.append('private evaluation'))
        self.assertEqual(events, [])


if __name__ == '__main__':
    unittest.main()
