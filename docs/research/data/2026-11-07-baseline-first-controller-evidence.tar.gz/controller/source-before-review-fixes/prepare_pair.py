"""Prepare only public baseline inputs for the fixed oracle-author pair."""
import copy
import hashlib
import importlib.util
import json
import pathlib
import shutil
import subprocess
import sys
from baseline_pair import validate_author

ROOT=pathlib.Path(__file__).resolve().parent
BASE=ROOT.parent
SOURCE=pathlib.Path('/home/marius/.codex/worktrees/ca35/codescout')
RECOVERY=BASE/'differential-oracle-recovery-20261107'
ORIGINAL=BASE/'semantic-contract-runtime-20261106/prepared/arms/nushell__nushell-18863--low-control'
IMAGE='sha256:3767f31b9b1a3288ad7132740dcff712737d5e855029079a4171a8065a2040ef'
HEAD='fe8bb4b34f5e7912f9b16c4c0bf1ff73a3a10a23'
PROTOCOL='''Independent oracle-author task (supersedes the general repair instruction above)

You have the unmodified public baseline repository in /testbed and the public repair request above. No proposed repair is supplied. Establish an acceptance contract independently of any proposed implementation. Use only the issue and accessible baseline source, documented interfaces, callers and existing tests; distinguish what the bug explicitly requires changing from legitimate behavior that must remain.

Trace the relevant implementations and observe behavior where useful. Do not generalize a requirement beyond the available public evidence. If competing expected behaviors cannot be resolved, mark the clause unresolved instead of inventing an assertion.

Write oracle_contract.json as {"clauses":[{"id":"r1","kind":"requirement|preservation|unresolved","basis":"public evidence and reasoning","source_evidence":["path:symbol"],"test_names":["contrast_..."]}]}. Requirement clauses describe the reported defect that must change; preservation clauses describe supported legitimate baseline behavior. Unresolved clauses have no tests. Use unique clause ids and assign every new test to exactly one clause.

For justified clauses add precise executable #[test] functions named contrast_... in a NEW file crates/nu-cli/tests/baseline_oracle.rs. Register it by adding only `mod baseline_oracle;` to crates/nu-cli/tests/main.rs. Prefer a small set, at most four focused tests. Run them on this baseline and retain failures: a requirement test may correctly fail before a repair. A test run's exit alone does not determine whether its expectation is justified.

Do not repair production code or change existing test bodies, configuration, CLAUDE.md or AGENTS.md. Do not commit, push or use external sources. Only the new test file, its single module registration, and oracle_contract.json are author outputs. Finish with the contract basis, actual commands/results and remaining uncertainty. No reference solution or private acceptance outcome is supplied.
'''


def load(path): return json.loads(pathlib.Path(path).read_text())
def sha(path): return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
def save(path,obj):
    with pathlib.Path(path).open('x') as f: json.dump(obj,f,indent=2); f.write('\n')


def main():
    assert not (ROOT/'pair-registration.json').exists()
    assert subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip()==HEAD
    assert not subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain'],text=True)
    old_reg=load(RECOVERY/'registration.json')
    outer=load(RECOVERY/'recovery-registration.json')
    for path,expected in outer['bound'].items(): assert sha(path)==expected,path
    project=load(BASE/'semantic-contract-pilot-20261106/prompt-inputs-registration.json')['projects']['nushell__nushell-18863']
    manifest_path=pathlib.Path(project['runtime_snapshot_manifest']); assert sha(manifest_path)==project['runtime_snapshot_manifest_sha256']
    manifest=load(manifest_path)
    prep_path=pathlib.Path('/home/marius/work/claude/codescout/.worktrees/semantic-contract-runtime-01a15ca9/tools/agent_lifecycle/semantic_prepare.py')
    spec=importlib.util.spec_from_file_location('baseline_snapshot_prep',prep_path); prep=importlib.util.module_from_spec(spec); spec.loader.exec_module(prep)
    for name in ('runtime_compat.py','supervision_headroom.py'):
        assert sha(RECOVERY/name)==outer['bound'][str(RECOVERY/name)]
        shutil.copyfile(RECOVERY/name,ROOT/name)
    import runtime_compat
    original=load(ORIGINAL/'prepared.json'); guidance,task=original['prompt'].split('Repair task:\n',1)
    prompt=guidance+'Original public repair request:\n'+task+'\n\n'+PROTOCOL
    (ROOT/'oracle-protocol.txt').write_text(PROTOCOL)
    arms=[]
    for effort in ('low','xhigh'):
        arm=ROOT/effort; arm.mkdir(); out=arm/'verifier'
        cloned=prep.clone_snapshot(manifest_path.parent,out,manifest); save(out/'clone-proof.json',cloned)
        actor=pathlib.Path('/tmp/cs-baseline-first-oracle-01a15ca9-20261107-'+effort); actor.mkdir()
        for name in ('CLAUDE.md','AGENTS.md'): shutil.copyfile(ORIGINAL/'actor-context'/name,actor/name)
        shutil.copyfile(ORIGINAL/'global-CLAUDE.md',out/'global-CLAUDE.md')
        native=prep.rewrite_native(load(ORIGINAL/'mcp-native-argv.json'),out,manifest['projects'],'cs-baseline-first-'+effort+'-01a15ca9')
        assert native[-4]==IMAGE
        # Rewriter preserves only the original read-only tool/cache mounts and maps
        # every known writable project destination to this freshly cloned state.
        mounts=[native[i+1] for i,arg in enumerate(native) if arg=='--mount']
        for raw in mounts:
            fields=dict(x.split('=',1) if '=' in x else (x,'') for x in raw.split(','))
            if 'readonly' not in fields: assert pathlib.Path(fields['src']).is_relative_to(out)
            assert '/proposal' not in raw and '/public-observations' not in raw
        save(out/'mcp-native-argv.json',native)
        cfg=copy.deepcopy(original)
        cfg.update(image=IMAGE,actor=str(actor),global_rules=str(out/'global-CLAUDE.md'),prompt=prompt,
                   checks=[{'id':'patch_hygiene_only','command':'git diff --check'}, {'id':'contract_syntax_only','command':'python3 -m json.tool oracle_contract.json >/dev/null'}],
                   timeout_s=1800,check_timeout_s=30,max_continuations=8)
        cfg['files']={str(p):sha(p) for p in (out/'mcp-native-argv.json',out/'global-CLAUDE.md',pathlib.Path(cfg['cli']),actor/'CLAUDE.md',actor/'AGENTS.md')}
        validate_author(cfg,native,mounts,IMAGE)
        save(out/'prepared.json',cfg)
        stdio=runtime_compat.materialize(out)
        hashes={p:h for p,h in old_reg['hashes'].items() if p.startswith(str(SOURCE)+'/') or p.endswith('/grade_policy.py')}
        hashes.update(cfg['files']); hashes.update({str(out/rel):proof['sha256'] for rel,proof in manifest['files'].items()})
        hashes.update({str(p):sha(p) for p in (out/'prepared.json',ROOT/'baseline_pair.py',ROOT/'prepare_pair.py',ROOT/'oracle-protocol.txt',ROOT/'runtime_compat.py',ROOT/'supervision_headroom.py',stdio,prep_path)})
        arms.append({'effort':effort,'out':str(out),'arm':str(arm),'expected_mounts':mounts,'hashes':hashes})
    # Every cloned payload is a separate inode across both arms as well as the source.
    for rel in manifest['files']:
        a,b=(pathlib.Path(row['out'])/rel for row in arms)
        assert (a.stat().st_dev,a.stat().st_ino)!=(b.stat().st_dev,b.stat().st_ino)
    reg={'status':'prepared_unstarted','arms':arms,'source':str(SOURCE),'source_commit':HEAD,'image':IMAGE,'prompt_sha256':hashlib.sha256(prompt.encode()).hexdigest(),
         'snapshot_manifest':str(manifest_path),'snapshot_manifest_sha256':sha(manifest_path),'prior_known_usd':'62.410596299999999054','prior_unresolved_reserve_usd':'4','reserve_per_arm_usd':'4','cli_cap_per_arm_usd':'3','ceiling_usd':'200','automatic_retry':False,
         'author_source_registration_sha256':sha(RECOVERY/'registration.json'),'qualified_runner_sha256':sha(RECOVERY/'run_verifier_recovery.py'),'source_gate_receipt':str(RECOVERY/'fixture-source-gate-process.json'),'source_gate_receipt_sha256':sha(RECOVERY/'fixture-source-gate-process.json')}
    save(ROOT/'pair-registration.json',reg)
    print(json.dumps({'prepared_efforts':[r['effort'] for r in arms],'prompt_sha256':reg['prompt_sha256'],'independent_physical_clones':True,'provider_calls':0},indent=2))


if __name__=='__main__': main()
