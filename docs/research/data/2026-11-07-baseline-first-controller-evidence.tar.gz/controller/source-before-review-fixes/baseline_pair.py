"""Baseline-only author visibility, fixed-pair ordering and capture validation."""
import json
import re


def validate_author(cfg, native, expected_mounts, baseline_image):
    """Reject candidate visibility before an author process can be admitted."""
    if cfg['image'] != baseline_image or native[-4] != baseline_image:
        raise ValueError('baseline image required')
    if any(arg == '-v' or arg.startswith('--volume') or arg.startswith('-v=') for arg in native):
        raise ValueError('unregistered volume alias')
    mounts = [native[i + 1] for i, arg in enumerate(native) if arg == '--mount']
    if mounts != expected_mounts:
        raise ValueError('native mount inventory changed')
    forbidden = ('/proposal', '/public-observations', 'mixed_str_length_result_does_replace_last', 'gold.patch', 'grade.log', 'value_is_error_only')
    if any(word in cfg['prompt'] for word in forbidden):
        raise ValueError('excluded prompt input')
    return mounts


def execute_pair(arms, author, freeze, evaluate):
    """No evaluation callback is invoked unless every author is closed/frozen."""
    frozen = []
    for arm in arms:
        capture = author(arm)
        frozen.append((arm, freeze(arm, capture)))
    return [evaluate(arm, output) for arm, output in frozen]


def parse_capture(capture, setup_segment=b''):
    """Admit only one new test module, its registration, and a contract file."""
    parts = [p for p in re.split(rb'(?=^diff --git )', capture, flags=re.M) if p]
    seen = set()
    tests = []
    contract = None
    test_source = b''
    for part in parts:
        header = part.splitlines()[0]
        match = re.fullmatch(rb'diff --git a/(\S+) b/(\S+)', header)
        if not match or match[1] != match[2] or match[1] in seen:
            raise ValueError('unsupported or duplicate diff path')
        path = match[1]
        seen.add(path)
        added = [line[1:] for line in part.splitlines() if line.startswith(b'+') and not line.startswith(b'+++')]
        removed = [line for line in part.splitlines() if line.startswith(b'-') and not line.startswith(b'---')]
        if path == b'.gitignore':
            if not setup_segment or part != setup_segment:
                raise ValueError('setup diff changed')
        elif path == b'oracle_contract.json':
            if b'new file mode 100644\n' not in part or removed:
                raise ValueError('contract must be new')
            contract = json.loads(b'\n'.join(added))
        elif path == b'crates/nu-cli/tests/baseline_oracle.rs':
            if b'new file mode 100644\n' not in part or removed:
                raise ValueError('test module must be new')
            test_source = b'\n'.join(added)
            tests.append(part)
        elif path == b'crates/nu-cli/tests/main.rs':
            if removed or added != [b'mod baseline_oracle;']:
                raise ValueError('existing module registration changed')
            tests.append(part)
        else:
            raise ValueError('forbidden capture path: ' + path.decode())
    if not isinstance(contract, dict) or not isinstance(contract.get('clauses'), list):
        raise ValueError('missing contract clauses')
    ids = []
    declared = []
    for clause in contract['clauses']:
        if clause.get('kind') not in ('requirement', 'preservation', 'unresolved'):
            raise ValueError('unsupported clause kind')
        if not isinstance(clause.get('id'), str) or not clause['id'] or not isinstance(clause.get('basis'), str) or not clause['basis']:
            raise ValueError('clause id and basis required')
        if not isinstance(clause.get('test_names'), list) or not all(isinstance(n, str) for n in clause['test_names']):
            raise ValueError('declared tests required')
        if not isinstance(clause.get('source_evidence'), list) or (clause['test_names'] and not clause['source_evidence']):
            raise ValueError('asserted clause needs public source evidence')
        if clause['kind'] == 'unresolved' and clause['test_names']:
            raise ValueError('unresolved clause cannot assert an oracle')
        ids.append(clause['id'])
        declared.extend(clause['test_names'])
    if len(set(ids)) != len(ids):
        raise ValueError('duplicate clause id')
    pattern = rb'(?m)^[ \t]*#\[test\][ \t]*\n(?:[ \t]*(?://[^\n]*|#\[[^\n]*\])\n)*[ \t]*fn (contrast_[A-Za-z0-9_]+)\('
    names = [n.decode() for n in re.findall(pattern, test_source)]
    if len(set(names)) != len(names) or len(set(declared)) != len(declared) or set(names) != set(declared):
        raise ValueError('declared and executable test sets differ')
    if names and b'crates/nu-cli/tests/main.rs' not in seen:
        raise ValueError('test module registration required')
    return contract, b''.join(tests), names
