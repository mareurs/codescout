import hashlib
import json
import pathlib
import shutil
import tempfile
import types
import unittest
from unittest import mock
import prepare_pair as p
import runtime_compat


class PreparerEntryTests(unittest.TestCase):
    def test_main_uses_pristine_manifest_origin_and_separate_author_states(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=pathlib.Path(tmp); root=base/'pair'; root.mkdir(); recovery=base/'recovery'; recovery.mkdir(); original=base/'original'; original.mkdir(); source=base/'source'; source.mkdir(); actors=base/'actors'; actors.mkdir()
            snapshot=base/'snapshot'
            for name in ['knowledge','member-state','native-home','instructions']: (snapshot/name).mkdir(parents=True)
            (snapshot/'knowledge/public.txt').write_text('baseline public context')
            files={'knowledge/public.txt':{'sha256':hashlib.sha256(b'baseline public context').hexdigest()}}
            manifest={'files':files,'projects':[{'id':'root','root':'.'}]}; (snapshot/'manifest.json').write_text(json.dumps(manifest))
            pilot=base/'semantic-contract-pilot-20261106'; pilot.mkdir(); (pilot/'prompt-inputs-registration.json').write_text(json.dumps({'projects':{'nushell__nushell-18863':{'runtime_snapshot_manifest':str(snapshot/'manifest.json'),'runtime_snapshot_manifest_sha256':p.sha(snapshot/'manifest.json')}}}))
            real=pathlib.Path(p.__file__).parent
            for name in ['baseline_pair.py','prepare_pair.py']: shutil.copyfile(real/name,root/name)
            bound={}
            for name in ['runtime_compat.py','supervision_headroom.py']:
                shutil.copyfile(real/name,recovery/name); bound[str(recovery/name)]=p.sha(recovery/name)
            (recovery/'registration.json').write_text('{"hashes":{}}'); (recovery/'recovery-registration.json').write_text(json.dumps({'bound':bound})); (recovery/'run_verifier_recovery.py').write_text('# frozen runner'); (recovery/'fixture-source-gate-process.json').write_text('{"exit_code":0}')
            (original/'actor-context').mkdir()
            for name in ['CLAUDE.md','AGENTS.md']: (original/'actor-context'/name).write_text('Public project rules')
            (original/'global-CLAUDE.md').write_text('Global rules'); cli=base/'cli'; cli.write_text('pinned cli'); plugin=base/'plugin'; plugin.mkdir()
            cfg={'image':p.IMAGE,'prompt':'Guidance\nRepair task:\nPublic issue','cli':str(cli),'plugin':str(plugin)}
            (original/'prepared.json').write_text(json.dumps(cfg)); (original/'mcp-native-argv.json').write_text(json.dumps(['docker','run','--mount','type=bind,src=/old,dst=/testbed/.codescout',p.IMAGE,'server','stdio','end']))
            origins=[]
            def clone(origin,out,actual):
                self.assertEqual(pathlib.Path(origin),snapshot)
                origins.append(str(origin)); out.mkdir(parents=True)
                for name in ['knowledge','member-state','native-home','instructions']: shutil.copytree(snapshot/name,out/name)
                return {'files':actual['files'],'separate_physical_files':True}
            def rewrite(argv,out,projects,name):
                result=argv.copy(); result[3]='type=bind,src='+str(out/'knowledge')+',dst=/testbed/.codescout'; return result
            fake=types.SimpleNamespace(clone_snapshot=clone,rewrite_native=rewrite)
            spec=types.SimpleNamespace(loader=types.SimpleNamespace(exec_module=lambda module:None))
            def git(args,**kwargs): return p.HEAD+'\n' if args[-1]=='HEAD' else ''
            with mock.patch.object(p,'ROOT',root),mock.patch.object(p,'BASE',base),mock.patch.object(p,'RECOVERY',recovery),mock.patch.object(p,'ORIGINAL',original),mock.patch.object(p,'SOURCE',source),mock.patch.object(p,'ACTOR_PARENT',actors,create=True),mock.patch.object(p.subprocess,'check_output',side_effect=git),mock.patch.object(p.importlib.util,'spec_from_file_location',return_value=spec),mock.patch.object(p.importlib.util,'module_from_spec',return_value=fake):
                p.main()
            self.assertEqual(origins,[str(snapshot),str(snapshot)])
            reg=json.loads((root/'pair-registration.json').read_text())
            self.assertEqual([row['effort'] for row in reg['arms']],['low','xhigh'])
            low=root/'low/verifier/knowledge/public.txt'; high=root/'xhigh/verifier/knowledge/public.txt'
            self.assertEqual(low.read_text(),'baseline public context'); self.assertNotEqual(low.stat().st_ino,high.stat().st_ino)
            lowcfg=json.loads((root/'low/verifier/prepared.json').read_text()); highcfg=json.loads((root/'xhigh/verifier/prepared.json').read_text())
            self.assertEqual(lowcfg['prompt'],highcfg['prompt']); self.assertTrue(pathlib.Path(lowcfg['actor']).is_relative_to(actors))


if __name__=='__main__': unittest.main()
