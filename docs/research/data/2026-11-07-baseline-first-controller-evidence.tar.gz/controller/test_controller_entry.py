import base64
import hashlib
import json
import pathlib
import tempfile
import types
import unittest
from unittest import mock
import run_pair as r
from test_contract_capture import fixture


class ControllerEntryTests(unittest.TestCase):
    def run_fixture(self, fail_after_receipt=False):
        temporary=tempfile.TemporaryDirectory(); self.addCleanup(temporary.cleanup)
        base=pathlib.Path(temporary.name); root=base/'pair'; root.mkdir(); recovery=base/'recovery'; recovery.mkdir()
        compat=pathlib.Path(r.__file__).parent/'runtime_compat.py'
        payload=base64.b64encode(fixture()[1]).decode()
        fake='''import pathlib,json,base64,hashlib,types,importlib.util
ROOT=None
spec=importlib.util.spec_from_file_location('compat',COMPAT)
compat=importlib.util.module_from_spec(spec); spec.loader.exec_module(compat)
def emit(*args,**kwargs):
    out=args[2]; arm=out.parent; cost='0.2' if arm.name=='low' else '0.4'
    patch=base64.b64decode(PAYLOAD); (out/'candidate.patch').write_bytes(patch)
    receipt={'cost_usd':cost,'unknown_provider_cost':False,'lifecycle':{'cost_is_final':True}}
    (out/'receipt.json').write_text(json.dumps(receipt))
    if FAIL: raise RuntimeError('after final receipt')
    (arm/'verifier-closed.json').write_text(json.dumps({'generated_candidate_sha256':hashlib.sha256(patch).hexdigest()}))
external=types.SimpleNamespace(worker=types.SimpleNamespace(),workflow=types.SimpleNamespace(execute=emit))
def host_sample(): return {'mem_available':32*2**30,'root_free':100*2**30,'tmp_free':8*2**30}
def main():
    out=ROOT/'verifier'; compat.materialize(out); compat.install(external,out)
    external.workflow.execute(None,None,out,None,['fake-cli'],{},None,None,None,None)
'''
        fake='COMPAT='+repr(str(compat))+'\nPAYLOAD='+repr(payload)+'\nFAIL='+repr(fail_after_receipt)+'\n'+fake
        runner=recovery/'run_verifier_recovery.py'; runner.write_text(fake)
        gate=base/'gate.json'; gate.write_text('{"exit_code":0}')
        rows=[]
        for effort in ['low','xhigh']:
            arm=root/effort; out=arm/'verifier'; out.mkdir(parents=True)
            cfg={'image':'baseline','prompt':'Public issue','plugin':str(base/'plugin')}; (base/'plugin').mkdir(exist_ok=True)
            argv=['docker','run','baseline','server','stdio','end']
            (out/'prepared.json').write_text(json.dumps(cfg)); (out/'mcp-native-argv.json').write_text(json.dumps(argv))
            hashes={str(p):r.sha(p) for p in [out/'prepared.json',out/'mcp-native-argv.json']}
            rows.append({'effort':effort,'arm':str(arm),'out':str(out),'expected_mounts':[],'hashes':hashes})
        reg={'status':'prepared_unstarted','automatic_retry':False,'arms':rows,'source':'fake-source','source_commit':'head','image':'baseline','prior_known_usd':'10','prior_unresolved_reserve_usd':'4','reserve_per_arm_usd':'4','cli_cap_per_arm_usd':'3','ceiling_usd':'200','qualified_runner_sha256':r.sha(runner),'source_gate_receipt':str(gate),'source_gate_receipt_sha256':r.sha(gate)}
        (root/'pair-registration-v2.json').write_text(json.dumps(reg)); (root/'review-admission.json').write_text(json.dumps({'admitted':True,'source_bindings':{str(pathlib.Path(r.__file__)):r.sha(r.__file__)}}))
        (root/'baseline-image-check.json').write_text('{"proposal_absent":true}'); (root/'expected-bootstrap-gitignore.patch').write_bytes(b'')
        old=base/'blind-contrast-verifier-followup-20261107'; old.mkdir(); (old/'evaluate_v3.py').write_text('# fake offline boundary')
        (old/'evaluation-registration.json').write_text(json.dumps({'variants':[{'label':x,'patch':None,'sha256':None} for x in ['baseline','wrong','unused','unused2','reference']]}))
        events=[]
        def cell(evaluation,variant,parser):
            self.assertTrue((root/'all-authors-frozen.json').exists())
            events.append(variant['label']); return {'valid':True,'statuses':{n:'pass' for n in evaluation['tests']}}
        ev=types.SimpleNamespace(q=types.SimpleNamespace(FLOORS={'root_gib':80,'tmp_gib':4,'mem_gib':24}),cell=cell)
        actual_load=r.load
        def read(path):
            if str(path).endswith('/fresh-tasks/nushell__nushell-18863/build/record.json'): return {'log_parser':{}}
            return actual_load(path)
        def git(args,**kwargs):
            self.assertEqual(args[:3],['git','-C','fake-source'])
            return 'head\n' if args[-1]=='HEAD' else ''
        with mock.patch.object(r,'ROOT',root),mock.patch.object(r,'BASE',base),mock.patch.object(r,'RECOVERY',recovery),mock.patch.object(r,'load',side_effect=read),mock.patch.object(r.subprocess,'check_output',side_effect=git),mock.patch.object(r.time,'sleep'),mock.patch.dict('sys.modules',{'evaluate_v3':ev}):
            if fail_after_receipt:
                with self.assertRaises(RuntimeError): r.main()
            else: r.main()
        return root,events

    def test_main_runs_both_isolated_authors_then_evaluates_and_sums_final_cost(self):
        root,events=self.run_fixture()
        self.assertEqual(events,['baseline','wrong','reference','baseline','wrong','reference'])
        result=json.loads((root/'pair-results.json').read_text())
        self.assertEqual(result['known_series_subtotal_usd'],'10.6')
        high=json.loads((root/'xhigh/registration.json').read_text()); self.assertEqual(high['prior_series_usd'],'10.2')
        for effort in ['low','xhigh']:
            self.assertTrue((root/effort/'verifier/cli-debug.raw.log').exists())
        self.assertFalse((root/'pair-stopped.json').exists())

    def test_final_cost_is_saved_before_propagating_capture_failure(self):
        root,events=self.run_fixture(fail_after_receipt=True)
        self.assertEqual(events,[])
        stopped=json.loads((root/'pair-stopped.json').read_text())
        self.assertEqual(stopped['known_series_subtotal_usd'],'10.2')
        self.assertEqual(len(stopped['authors']),1)
        self.assertTrue(stopped['authors'][0]['cost_is_final'])
        self.assertFalse((root/'xhigh/registration.json').exists())


if __name__=='__main__': unittest.main()
