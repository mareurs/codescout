import hashlib
import json
import pathlib
import tempfile
import unittest
from test_contract_capture import fixture
import run_pair as r


class FreezeTests(unittest.TestCase):
    def test_frozen_capture_binds_patch_contract_and_test_set(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp); out=root/'low'; out.mkdir(); (out/'verifier').mkdir()
            _,patch=fixture(); capture=out/'verifier/candidate.patch'; capture.write_bytes(patch)
            got=r.freeze_capture(out,hashlib.sha256(patch).hexdigest(),b'')
            self.assertEqual(got['status'],'frozen')
            self.assertEqual(got['tests'],['contrast_requirement','contrast_preservation'])
            self.assertEqual(got['candidate_sha256'],hashlib.sha256(patch).hexdigest())
            self.assertTrue((out/'frozen/generated-tests.patch').is_file())

    def test_changed_capture_is_not_frozen(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp); (root/'verifier').mkdir(); (root/'verifier/candidate.patch').write_bytes(b'changed')
            with self.assertRaisesRegex(ValueError,'capture'):
                r.freeze_capture(root,'wrong',b'')
            self.assertFalse((root/'frozen').exists())

    def test_missing_second_output_blocks_reference_evaluation(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp)
            with self.assertRaisesRegex(ValueError,'pair'):
                r.require_frozen_pair(root,['low','xhigh'])

    def test_pair_rechecks_each_frozen_payload(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp); rows=[]
            for arm in ['low','xhigh']:
                out=root/arm; (out/'verifier').mkdir(parents=True); _,patch=fixture(); (out/'verifier/candidate.patch').write_bytes(patch)
                rows.append(r.freeze_capture(out,hashlib.sha256(patch).hexdigest(),b''))
            (root/'all-authors-frozen.json').write_text(json.dumps({'arms':rows}))
            self.assertEqual(len(r.require_frozen_pair(root,['low','xhigh'])),2)
            (root/'low/frozen/generated-tests.patch').write_bytes(b'corrupted')
            with self.assertRaisesRegex(ValueError,'frozen'):
                r.require_frozen_pair(root,['low','xhigh'])


if __name__=='__main__': unittest.main()
