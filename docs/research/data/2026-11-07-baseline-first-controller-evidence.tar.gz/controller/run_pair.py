"""Fixed baseline-only pair, with immutable captures before reference evaluation."""
import hashlib
import importlib.util
import json
import pathlib
import subprocess
import sys
import time
from decimal import Decimal
from baseline_pair import validate_author, execute_pair, parse_capture

ROOT = pathlib.Path(__file__).resolve().parent
BASE = ROOT.parent
RECOVERY = BASE / "differential-oracle-recovery-20261107"


def sha(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(pathlib.Path(path).read_text())


def save(path, value):
    with pathlib.Path(path).open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')


def freeze_capture(arm, candidate_sha256, setup_segment):
    arm = pathlib.Path(arm)
    capture = arm / 'verifier/candidate.patch'
    if sha(capture) != candidate_sha256:
        raise ValueError('capture bytes changed')
    # A captured protocol violation is a model output, not a reason to resample.
    try:
        contract, patch, names = parse_capture(capture.read_bytes(), setup_segment)
        status = 'frozen' if names else 'abstained'
        error = None
    except (ValueError, KeyError, TypeError) as exc:
        contract, patch, names = {}, b'', []
        status, error = 'protocol_invalid', str(exc)
    out = arm / 'frozen'
    out.mkdir()
    (out / 'generated-tests.patch').write_bytes(patch)
    save(out / 'oracle_contract.json', contract)
    row = {'effort': arm.name, 'status': status, 'error': error, 'tests': names,
           'candidate_sha256': candidate_sha256,
           'bindings': {str(p): sha(p) for p in (capture, out / 'generated-tests.patch', out / 'oracle_contract.json')}}
    save(out / 'freeze.json', row)
    row['freeze_receipt_sha256'] = sha(out / 'freeze.json')
    return row


def require_frozen_pair(root, efforts):
    root = pathlib.Path(root)
    receipt = root / 'all-authors-frozen.json'
    if not receipt.exists():
        raise ValueError('pair is not frozen')
    rows = load(receipt)['arms']
    if [r['effort'] for r in rows] != list(efforts):
        raise ValueError('pair is incomplete or out of order')
    for row in rows:
        frozen = root / row['effort'] / 'frozen/freeze.json'
        if sha(frozen) != row['freeze_receipt_sha256']:
            raise ValueError('frozen receipt changed')
        for path, expected in row['bindings'].items():
            if sha(path) != expected:
                raise ValueError('frozen payload changed: ' + path)
    return rows


def main():
    reg = load(ROOT / 'pair-registration-v2.json')
    assert reg['status'] == 'prepared_unstarted' and reg['automatic_retry'] is False
    efforts = [r['effort'] for r in reg['arms']]
    assert efforts == ['low', 'xhigh']
    review = load(ROOT / 'review-admission.json')
    assert review['admitted'] is True
    for path, expected in review['source_bindings'].items():
        assert sha(path) == expected, 'Reviewed source drift: ' + path
    assert sha(RECOVERY / 'run_verifier_recovery.py') == reg['qualified_runner_sha256']
    assert sha(reg['source_gate_receipt']) == reg['source_gate_receipt_sha256']
    assert load(reg['source_gate_receipt'])['exit_code'] == 0
    assert subprocess.check_output(['git', '-C', reg['source'], 'rev-parse', 'HEAD'], text=True).strip() == reg['source_commit']
    assert not subprocess.check_output(['git', '-C', reg['source'], 'status', '--porcelain'], text=True)
    assert load(ROOT / 'baseline-image-check.json')['proposal_absent']
    modules = {}
    spec = importlib.util.spec_from_file_location('qualified_oracle_runner', RECOVERY / 'run_verifier_recovery.py')
    qualified = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(qualified)
    known = Decimal(reg['prior_known_usd'])
    reserve = Decimal(reg['reserve_per_arm_usd'])
    unresolved = Decimal(reg['prior_unresolved_reserve_usd'])
    assert known + unresolved + 2 * reserve < Decimal(reg['ceiling_usd'])
    plugin_bindings = {}
    for row in reg['arms']:
        out = pathlib.Path(row['out'])
        cfg = load(out / 'prepared.json')
        validate_author(cfg, load(out / 'mcp-native-argv.json'), row['expected_mounts'], reg['image'])
        for path, expected in row['hashes'].items():
            assert sha(path) == expected, path
        for p in pathlib.Path(cfg['plugin']).rglob('*'):
            if p.is_file(): plugin_bindings[str(p)] = sha(p)
        assert not any((out / n).exists() for n in ('started.json', 'launch.json', 'receipt.json'))
    save(ROOT / 'execution-registration.json', {'pair_registration_sha256': sha(ROOT / 'pair-registration-v2.json'),
         'source_bindings': review['source_bindings'], 'review_receipt_sha256': sha(ROOT / 'review-admission.json'),
         'plugin_bindings': plugin_bindings, 'baseline_image_check_sha256': sha(ROOT / 'baseline-image-check.json'),
         'bootstrap_setup_sha256': sha(ROOT / 'expected-bootstrap-gitignore.patch'),
         'scope': 'Fixed public-baseline authors; both outputs frozen before offline reference access'})
    save(ROOT / 'attempt.json', {'efforts': efforts, 'automatic_retry': False})
    cost_rows = []
    frozen_rows = []

    def wait_for_host(memory, label, consecutive=1):
        deadline = time.monotonic() + 900
        good = 0
        while time.monotonic() < deadline:
            sample = qualified.host_sample()
            with (ROOT / 'host-admission-samples.jsonl').open('a') as f:
                f.write(json.dumps({'phase': label, 'sample': sample}) + '\n')
            if sample['mem_available'] >= memory * 2**30 and sample['root_free'] >= 80 * 2**30 and sample['tmp_free'] >= 4 * 2**30:
                good += 1
                if good >= consecutive: return
            else:
                good = 0
            time.sleep(10)
        raise RuntimeError('Bounded host admission expired: ' + label)

    def author(effort):
        nonlocal known
        row = next(r for r in reg['arms'] if r['effort'] == effort)
        arm, out = pathlib.Path(row['arm']), pathlib.Path(row['out'])
        wait_for_host(24, effort + '-author', 3)
        for path, expected in plugin_bindings.items(): assert sha(path) == expected
        for path, expected in row['hashes'].items(): assert sha(path) == expected, path
        validate_author(load(out / 'prepared.json'), load(out / 'mcp-native-argv.json'), row['expected_mounts'], reg['image'])
        remaining = len(efforts) - len(cost_rows)
        assert known + unresolved + remaining * reserve < Decimal(reg['ceiling_usd'])
        save(arm / 'registration.json', {'status': 'prepared_unstarted', 'retry_allowed': False,
             'out': str(out), 'source': reg['source'], 'source_commit': reg['source_commit'],
             'effort': effort, 'image': reg['image'], 'reserve_usd': str(reserve),
             'cli_cap_usd': reg['cli_cap_per_arm_usd'], 'prior_series_usd': str(known),
             'hashes': dict(row['hashes'], **plugin_bindings)})
        error = None
        try:
            code = ("import importlib.util,pathlib,sys; "
                    "sys.path.insert(0,str(pathlib.Path(sys.argv[2]).parent)); "
                    "s=importlib.util.spec_from_file_location('qualified_author',sys.argv[1]); "
                    "m=importlib.util.module_from_spec(s); s.loader.exec_module(m); "
                    "m.ROOT=pathlib.Path(sys.argv[2]); m.main()")
            with (arm / 'author-process.log').open('xb') as log:
                process = subprocess.run([sys.executable, '-B', '-c', code,
                         str(RECOVERY / 'run_verifier_recovery.py'), str(arm)],
                         stdout=log, stderr=subprocess.STDOUT)
            save(arm / 'author-process.json', {'exit_code': process.returncode,
                 'closed_receipt_saved': (arm / 'verifier-closed.json').exists(),
                 'qualified_runner_fresh_process': True})
            if process.returncode:
                raise RuntimeError('author process exited ' + str(process.returncode))
        except BaseException as exc:
            error = type(exc).__name__ + ': ' + str(exc)
        finally:
            # Preserve actual known/final costs before propagating later validity errors.
            receipt = load(out / 'receipt.json') if (out / 'receipt.json').exists() else {}
            value = receipt.get('cost_usd')
            final = receipt.get('lifecycle', {}).get('cost_is_final') is True and value is not None and not receipt.get('unknown_provider_cost', True)
            cost_rows.append({'effort': effort, 'cost_usd': value, 'cost_is_final': final,
                              'reserved_usd': str(reserve), 'error': error})
            if final: known += Decimal(str(value))
            save(arm / 'cost-accounting.json', {'arms_so_far': cost_rows, 'known_series_subtotal_usd': str(known),
                 'original_unresolved_reserve_usd': str(unresolved), 'current_unknown_reserve_usd': '0' if final else str(reserve)})
        if error: raise RuntimeError(error)
        return load(arm / 'verifier-closed.json')

    def freeze(effort, closed):
        row = freeze_capture(ROOT / effort, closed['generated_candidate_sha256'], (ROOT / 'expected-bootstrap-gitignore.patch').read_bytes())
        frozen_rows.append(row)
        if len(frozen_rows) == len(efforts):
            save(ROOT / 'all-authors-frozen.json', {'arms': frozen_rows, 'known_series_subtotal_usd': str(known),
                  'original_unresolved_reserve_usd': str(unresolved), 'before_reference_evaluation': True})
        return row

    def evaluate(effort, frozen):
        require_frozen_pair(ROOT, efforts)
        if frozen['status'] != 'frozen':
            result = {'effort': effort, 'status': frozen['status'], 'error': frozen['error'], 'rows': []}
            save(ROOT / effort / 'oracle-evaluation-results.json', result)
            return result
        old = BASE / 'blind-contrast-verifier-followup-20261107'
        sys.path.insert(0, str(old))
        import evaluate_v3 as ev
        previous = load(old / 'evaluation-registration.json')
        folder = ROOT / effort / 'oracle-evaluation'
        folder.mkdir()
        (folder / 'generated-tests.patch').write_bytes((ROOT / effort / 'frozen/generated-tests.patch').read_bytes())
        evaluation = {'image': reg['image'], 'tests': frozen['tests'], 'test_patch_sha256': sha(folder / 'generated-tests.patch'),
              'variants': [previous['variants'][i] for i in (0, 1, 4)], 'floors': dict(ev.q.FLOORS, mem_gib=24),
              'executor_sha256': sha(old / 'evaluate_v3.py'), 'all_frozen_receipt_sha256': sha(ROOT / 'all-authors-frozen.json')}
        save(ROOT / effort / 'oracle-evaluation-registration.json', evaluation)
        parser = load('/home/marius/work/claude/setup-ab-data/fresh-tasks/nushell__nushell-18863/build/record.json')['log_parser']
        ev.ROOT, ev.q.FLOORS = folder, evaluation['floors']
        rows = []
        for variant in evaluation['variants']:
            require_frozen_pair(ROOT, efforts)
            wait_for_host(24, effort + '-evaluate-' + variant['label'])
            result = ev.cell(evaluation, variant, parser)
            rows.append(result)
            if not result['valid']: break
        result = {'effort': effort, 'status': 'evaluated', 'rows': rows,
                  'all_three_valid': len(rows) == 3 and all(r['valid'] for r in rows), 'provider_calls': 0}
        save(ROOT / effort / 'oracle-evaluation-results.json', result)
        if not result['all_three_valid']: raise RuntimeError('Offline evaluator infrastructure-invalid: ' + effort)
        return result

    try:
        results = execute_pair(efforts, author, freeze, evaluate)
        save(ROOT / 'pair-results.json', {'authors': cost_rows, 'known_series_subtotal_usd': str(known),
              'original_unresolved_reserve_usd': str(unresolved), 'results': results})
        print(json.dumps({'status': 'closed', 'known_series_subtotal_usd': str(known),
                          'authors': cost_rows, 'results_saved': True}, indent=2))
    except BaseException as exc:
        save(ROOT / 'pair-stopped.json', {'error': type(exc).__name__ + ': ' + str(exc),
             'authors': cost_rows, 'known_series_subtotal_usd': str(known), 'automatic_retry': False})
        raise


if __name__ == '__main__':
    main()
