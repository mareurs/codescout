# Baseline-first review close-out — 2026-11-07

Original independent report: /tmp/baseline-oracle-review-20261107/report.md, SHA256 ec5b2dddce2223de55c1da6621adc649ccde5a115b90e58c3bc92552cc0562d7. One review, then one parent fix pass; fixes were not independently re-reviewed.

## Fix verification

Four confirmed defects were filed immediately: nested runtime wrappers e5cf80dbc72c9c5e; equals-form mount omission ddb8f2ff73715acc; non-object clauses escaping protocol-invalid edb5251ae4c707ff; undeclared executable tests cbebc4ff51aa256a. Coverage issue b81dd8ba3e1b4464 records the actual nine survivors and their limits. All are mitigated in resident code with no product fix commit claimed.

The actual controller-entry fixture reproduced xhigh FileExistsError before the fix, then completed both authors in fresh processes after it. Synthetic final costs 0.2/0.4 sum to 0.6 once, and xhigh receives the updated prior; a late failure preserves final cost and prevents the second author/evaluation. These are explicitly synthetic fixture amounts, not series spend. Actual preparer-main fixture asserts original snapshot origin and independent low/high payloads; configurable actor parent preserves the default production paths while isolating the fixture. The null clause changes from uncaught AttributeError/no receipt to preserved protocol_invalid. Both equals-form and compact -v mounts are rejected. Canonical executable test names are inventoried before prefix/membership checks; unsupported test declaration forms are rejected conservatively.

Original 22-test suite: 16 actual mutants applied, 7 killed/9 survived. Expanded suite: 36 pass. First post-fix pass: 20 applied, 18 killed/2 survived. The extra M19 survivor exposed absent inline-declaration coverage; it was observed before adding that test. Final pass: 20 applied, 19 killed/1 survived. All raw before/after and mutant results are retained, not relabelled. Final receipt is review-fix-verification/final-results.json.

## Rulings made

1. Reuse unchanged qualified ca35 source and controlled source gate, plus native adapter/cache qualification. The resident Python changes are verified by their own suite and mutation/integration fixtures; the repository gate does not cover them. Risk if wrong: a missed integration contract; the real qualified prepared preflight and single review specifically cover the new seams.
2. Launch the qualified single-author runner in a fresh process for each author rather than changing its old compatibility installer. This preserves the one-install-per-process qualification. Risk if wrong: invocation/import drift; actual fixture tests exercise this process boundary and old qualified inputs are bound before use.
3. Keep M11 as a redundant second visibility check. Removing it survives because initial validation plus per-author registered-file hashes still enforce the same immutable argv. This is not claimed as an independent safety test. Risk if assumptions change: mutable input handling must be re-evaluated; no actor can mutate these host inputs in the current design.
4. Admit only supported canonical test declarations and the constrained new-module output shape. A valid but unsupported declaration becomes protocol_invalid, not a fabricated zero-test count or a paid retry. Risk: conservative abstention/rejection of an author artifact; this limit will be reported with the actual output.
5. Preserve old source/registration and create pair-registration-v2.json rebinding only corrected baseline_pair/prepare_pair source hashes before any model call. Public prompt/image/rules/cache bytes are unchanged. Risk if wrong: source/input provenance drift; every remaining binding was rechecked.

## Review items set aside and disposition

Paid quality/request effort/live cost/runtime/cleanup: pending real job, not inferred from fixture green. Oracle semantic quality/source citations/empty bodies: parser freeze is not admission as a detector; downstream actual matrix must preserve reference, reject the wrong proposal and distinguish a requirement from baseline. Old qualified internals: reused, no new qualification claim. Future host tampering: outside this bounded experiment, immutable hashes still checked. Parent fixes: not independently re-reviewed; red-green and actually applied mutations are the post-fix evidence. No minor finding was deferred by the reviewer.

## Active execution

Exactly one background controller launch: /tmp/codescout-bg/2674124-d9ea3495-bg_00000051.json. Command python3 -B ROOT/run_pair.py. It records one-shot barriers then waits up to 900 seconds for the declared host admission. Do not restart on a missing output. Read final author/cost/freeze/evaluation artifacts on wake, not this close-out, for outcome claims. Standing USD 200 series; prior known 62.410596299999999054 plus original unresolved USD 4 hold, reserve USD 4/cap USD 3 for each of two new authors. No merge/push/global config change/source worktree edit.
