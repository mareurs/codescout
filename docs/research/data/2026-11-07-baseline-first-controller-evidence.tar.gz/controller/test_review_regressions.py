import copy
import hashlib
import json
import pathlib
import tempfile
import unittest
from test_contract_capture import fixture,new_file
import test_baseline_pair as bt
import baseline_pair as b
import run_pair as r


class ReviewRegressions(unittest.TestCase):
    def test_equals_mount_is_rejected(self):
        x=bt.BarrierTests(); x.setUp(); argv=x.native.copy(); argv[2:2]=['--mount=type=bind,src=/saved/proposal,dst=/proposal,readonly']
        with self.assertRaisesRegex(ValueError,'mount'):
            b.validate_author(x.cfg,argv,x.allowed,'baseline')

    def test_compact_volume_is_rejected(self):
        x=bt.BarrierTests(); x.setUp(); argv=x.native.copy(); argv[2:2]=['-v/saved/proposal:/proposal:ro']
        with self.assertRaisesRegex(ValueError,'volume'):
            b.validate_author(x.cfg,argv,x.allowed,'baseline')

    def test_nonobject_clause_is_frozen_as_protocol_invalid(self):
        with tempfile.TemporaryDirectory() as tmp:
            arm=pathlib.Path(tmp)/'low'; (arm/'verifier').mkdir(parents=True)
            patch=new_file('oracle_contract.json','{"clauses":[null]}'); (arm/'verifier/candidate.patch').write_bytes(patch)
            row=r.freeze_capture(arm,hashlib.sha256(patch).hexdigest(),b'')
            self.assertEqual(row['status'],'protocol_invalid'); self.assertEqual(row['tests'],[])
            self.assertTrue((arm/'frozen/freeze.json').exists())

    def test_noncontrast_executable_is_not_silently_omitted(self):
        _,patch=fixture(); patch=patch.replace(b'+fn contrast_preservation() {}',b'+fn contrast_preservation() {}\n+#[test]\n+fn surprise() {}')
        with self.assertRaisesRegex(ValueError,'test|declared'):
            b.parse_capture(patch)

    def test_unsupported_inline_test_declaration_is_rejected(self):
        contract, patch = fixture()
        main = patch[patch.index(b'diff --git a/crates/nu-cli/tests/main.rs'):]
        code = '#[test]\nfn contrast_requirement() {}\n#[test]\nfn contrast_preservation() {}\n#[test] fn contrast_extra() {}\n'
        patch = new_file('oracle_contract.json', json.dumps(contract)) + new_file('crates/nu-cli/tests/baseline_oracle.rs', code) + main
        with self.assertRaisesRegex(ValueError, 'test declaration'):
            b.parse_capture(patch)

    def test_unresolved_clause_cannot_have_assertions(self):
        _,patch=fixture(); patch=patch.replace(b'"kind": "preservation"',b'"kind": "unresolved"')
        with self.assertRaisesRegex(ValueError,'unresolved'):
            b.parse_capture(patch)

    def test_duplicate_clause_ids_are_rejected(self):
        _,patch=fixture(); patch=patch.replace(b'"id": "p1"',b'"id": "r1"')
        with self.assertRaisesRegex(ValueError,'duplicate'):
            b.parse_capture(patch)

    def test_contract_must_be_new_file(self):
        _,patch=fixture(); patch=patch.replace(b'new file mode 100644\n',b'',1)
        with self.assertRaisesRegex(ValueError,'new'):
            b.parse_capture(patch)

    def test_test_module_must_be_new_file(self):
        _,patch=fixture(); split=patch.index(b'diff --git a/crates/nu-cli/tests/baseline_oracle.rs')
        patch=patch[:split]+patch[split:].replace(b'new file mode 100644\n',b'',1)
        with self.assertRaisesRegex(ValueError,'new'):
            b.parse_capture(patch)

    def test_wrong_pair_order_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp); rows=[]
            for arm in ['xhigh','low']:
                out=root/arm; (out/'verifier').mkdir(parents=True); _,patch=fixture(); (out/'verifier/candidate.patch').write_bytes(patch)
                rows.append(r.freeze_capture(out,hashlib.sha256(patch).hexdigest(),b''))
            (root/'all-authors-frozen.json').write_text(json.dumps({'arms':rows}))
            with self.assertRaisesRegex(ValueError,'order|pair'):
                r.require_frozen_pair(root,['low','xhigh'])

    def test_frozen_receipt_is_rehashed(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp); rows=[]
            for arm in ['low','xhigh']:
                out=root/arm; (out/'verifier').mkdir(parents=True); _,patch=fixture(); (out/'verifier/candidate.patch').write_bytes(patch)
                rows.append(r.freeze_capture(out,hashlib.sha256(patch).hexdigest(),b''))
            (root/'all-authors-frozen.json').write_text(json.dumps({'arms':rows}))
            (root/'low/frozen/freeze.json').write_text('{}')
            with self.assertRaisesRegex(ValueError,'receipt'):
                r.require_frozen_pair(root,['low','xhigh'])


if __name__=='__main__': unittest.main()
