import json
import unittest
from baseline_pair import parse_capture


def new_file(path, text):
    return ('diff --git a/'+path+' b/'+path+'\nnew file mode 100644\n--- /dev/null\n+++ b/'+path+'\n@@ -0,0 +1,'+str(len(text.splitlines()))+' @@\n'+''.join('+'+x+'\n' for x in text.splitlines())).encode()


def fixture():
    contract={'clauses':[{'id':'r1','kind':'requirement','basis':'Public issue requirement','source_evidence':['source.rs:entry'],'test_names':['contrast_requirement']},{'id':'p1','kind':'preservation','basis':'Baseline public contract','source_evidence':['source.rs:helper'],'test_names':['contrast_preservation']}]}
    code='#[test]\nfn contrast_requirement() {}\n#[test]\nfn contrast_preservation() {}\n'
    patch=new_file('oracle_contract.json',json.dumps(contract))+new_file('crates/nu-cli/tests/baseline_oracle.rs',code)
    patch+=b'diff --git a/crates/nu-cli/tests/main.rs b/crates/nu-cli/tests/main.rs\n--- a/crates/nu-cli/tests/main.rs\n+++ b/crates/nu-cli/tests/main.rs\n@@ -1 +1,2 @@\n+mod baseline_oracle;\n mod existing;\n'
    return contract,patch


class CaptureTests(unittest.TestCase):
    def test_extracts_declared_executable_tests_and_contract(self):
        contract,patch=fixture(); got,tests,names=parse_capture(patch)
        self.assertEqual(got,contract)
        self.assertEqual(names,['contrast_requirement','contrast_preservation'])
        self.assertNotIn(b'oracle_contract.json',tests)
        self.assertIn(b'+mod baseline_oracle;',tests)

    def test_rejects_production_change(self):
        _,patch=fixture()
        with self.assertRaisesRegex(ValueError,'path'):
            parse_capture(patch+new_file('crates/nu-cli/src/util.rs','changed'))

    def test_rejects_existing_test_body_change(self):
        _,patch=fixture()
        with self.assertRaisesRegex(ValueError,'path'):
            parse_capture(patch+new_file('crates/nu-cli/tests/last_result.rs','changed'))

    def test_rejects_extra_code_in_existing_module(self):
        _,patch=fixture(); patch=patch.replace(b'+mod baseline_oracle;',b'+mod baseline_oracle;\n+fn changed_existing_test() {}')
        with self.assertRaisesRegex(ValueError,'registration'):
            parse_capture(patch)

    def test_rejects_unregistered_test(self):
        _,patch=fixture(); patch=patch.replace(b'+fn contrast_preservation() {}',b'+fn contrast_other() {}')
        with self.assertRaisesRegex(ValueError,'declared'):
            parse_capture(patch)

    def test_rejects_unsupported_clause_kind(self):
        contract,patch=fixture(); patch=patch.replace(b'"kind": "preservation"',b'"kind": "guess"')
        with self.assertRaisesRegex(ValueError,'kind'):
            parse_capture(patch)

    def test_allows_explicit_abstention(self):
        contract={'clauses':[{'id':'u1','kind':'unresolved','basis':'Public evidence insufficient','source_evidence':[],'test_names':[]}]}
        got,patch,names=parse_capture(new_file('oracle_contract.json',json.dumps(contract)))
        self.assertEqual(got,contract); self.assertEqual(patch,b''); self.assertEqual(names,[])

    def test_setup_diff_must_equal_bound_setup_bytes(self):
        _,patch=fixture(); setup=b'diff --git a/.gitignore b/.gitignore\n--- a/.gitignore\n+++ b/.gitignore\n@@ -1 +1,2 @@\n old\n+.codescout/private-memories/\n'
        self.assertEqual(parse_capture(patch+setup,setup)[2],['contrast_requirement','contrast_preservation'])
        with self.assertRaisesRegex(ValueError,'setup'):
            parse_capture(patch+setup.replace(b'private-memories',b'all-files'),setup)


if __name__=='__main__': unittest.main()
