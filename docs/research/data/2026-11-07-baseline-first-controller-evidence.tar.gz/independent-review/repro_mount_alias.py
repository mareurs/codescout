"""Run the real read-only adapter preflight against a synthetic extra mount.

No Docker, launch, token, credential, debug-log, or provider operations.
"""
import hashlib
import json
import pathlib
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parent
RESIDENT = pathlib.Path('/home/marius/.cache/codescout-resident/codescout/baseline-first-oracle-20261107')
sys.path.insert(0, str(ROOT / 'pristine'))
sys.path.insert(0, '/home/marius/.codex/worktrees/ca35/codescout/tools/agent_lifecycle')
import baseline_pair
import external

reg = json.loads((RESIDENT / 'pair-registration.json').read_text())
row = reg['arms'][0]
source = pathlib.Path(row['out'])
cfg = json.loads((source / 'prepared.json').read_text())
native = json.loads((source / 'mcp-native-argv.json').read_text())
injected = '--mount=type=bind,src=/saved/proposal,dst=/proposal,readonly'
native.insert(2, injected)
with tempfile.TemporaryDirectory(prefix='mount-alias-', dir=ROOT) as temp:
    out = pathlib.Path(temp)
    argv = out / 'mcp-native-argv.json'
    argv.write_text(json.dumps(native))
    cfg['files'][str(argv)] = hashlib.sha256(argv.read_bytes()).hexdigest()
    (out / 'prepared.json').write_text(json.dumps(cfg))
    inventory = baseline_pair.validate_author(cfg, native, row['expected_mounts'], reg['image'])
    external.validate_prepared(out, 'low', '4', '3')
    result = {'injected': injected, 'baseline_guard': 'accepted', 'external_preflight': 'accepted', 'guard_inventory_contains_proposal': any('/proposal' in item for item in inventory), 'provider_calls': 0}
    (ROOT / 'mount-alias-repro.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
