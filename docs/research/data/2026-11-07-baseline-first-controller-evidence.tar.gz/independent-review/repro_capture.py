"""Exercise frozen output classification without an author or evaluator."""
import hashlib
import json
import pathlib
import subprocess
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'pristine'))
import run_pair
from test_contract_capture import fixture, new_file

contract, normal = fixture()
main_registration = normal[normal.index(b'diff --git a/crates/nu-cli/tests/main.rs'):]
extra_source = '#[test]\nfn contrast_requirement() {}\n#[test]\nfn contrast_preservation() {}\n#[test]\nfn surprise() { panic!("unregistered"); }\n'
extra_patch = new_file('oracle_contract.json', json.dumps(contract)) + new_file('crates/nu-cli/tests/baseline_oracle.rs', extra_source) + main_registration
with tempfile.TemporaryDirectory(prefix='patch-check-', dir=ROOT) as tmp:
    target = pathlib.Path(tmp) / 'crates/nu-cli/tests/main.rs'
    target.parent.mkdir(parents=True)
    target.write_text('mod existing;\n')
    check = subprocess.run(['git', 'apply', '--check', '-'], input=extra_patch, cwd=tmp, capture_output=True)
    assert check.returncode == 0, check.stderr.decode()
    (ROOT / 'undeclared-test-patch-check.json').write_text(json.dumps({'exit_code': check.returncode, 'stderr': check.stderr.decode()}, indent=2) + '\n')
cases = {
    'non_object_clause': new_file('oracle_contract.json', json.dumps({'clauses': [None]})),
    'undeclared_noncontrast_test': extra_patch,
    'valid_json_empty_functions': normal,
}
rows = []
for label, patch in cases.items():
    with tempfile.TemporaryDirectory(prefix='capture-', dir=ROOT) as tmp:
        arm = pathlib.Path(tmp)
        (arm / 'verifier').mkdir()
        (arm / 'verifier/candidate.patch').write_bytes(patch)
        try:
            result = run_pair.freeze_capture(arm, hashlib.sha256(patch).hexdigest(), b'')
            rows.append({'case': label, 'status': result['status'], 'tests': result['tests'], 'error': result['error']})
        except Exception as exc:
            rows.append({'case': label, 'exception': type(exc).__name__, 'message': str(exc), 'frozen_receipt_exists': (arm / 'frozen/freeze.json').exists()})
(ROOT / 'capture-repro.json').write_text(json.dumps(rows, indent=2) + '\n')
print(json.dumps(rows, indent=2))
