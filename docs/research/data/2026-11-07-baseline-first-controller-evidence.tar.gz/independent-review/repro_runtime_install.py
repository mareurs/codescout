"""Fake-executor probe: no credentials, Docker, or provider operations."""
import importlib.util
import json
import pathlib
import subprocess
import sys
import tempfile
import types

COMPAT = pathlib.Path('/home/marius/.cache/codescout-resident/codescout/baseline-first-oracle-20261107/runtime_compat.py')
ROOT = pathlib.Path(__file__).resolve().parent

def run(efforts):
    spec = importlib.util.spec_from_file_location('review_runtime', COMPAT)
    compat = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(compat)
    calls = []
    external = types.SimpleNamespace(worker=types.SimpleNamespace(), workflow=types.SimpleNamespace(execute=lambda *args, **kwargs: calls.append(str(args[2]))))
    rows = []
    with tempfile.TemporaryDirectory(prefix='compat-', dir=ROOT) as temporary:
        for effort in efforts:
            out = pathlib.Path(temporary) / effort
            out.mkdir()
            compat.materialize(out)
            compat.install(external, out)
            try:
                external.workflow.execute(None, None, out, None, ['fake-cli'], {}, None, None, None, None)
                rows.append({'effort': effort, 'status': 'success'})
            except Exception as exc:
                rows.append({'effort': effort, 'status': 'exception', 'exception': type(exc).__name__, 'message': str(exc)})
    return {'arms': rows, 'underlying_executor_calls': len(calls)}

if __name__ == '__main__':
    if len(sys.argv) > 1:
        print(json.dumps(run([sys.argv[1]])))
    else:
        same_process = run(['low', 'xhigh'])
        fresh_processes = []
        for effort in ['low', 'xhigh']:
            result = subprocess.run([sys.executable, '-B', __file__, effort], text=True, capture_output=True, check=True)
            fresh_processes.append(json.loads(result.stdout))
        result = {'same_process': same_process, 'fresh_processes': fresh_processes}
        assert same_process['arms'][1]['exception'] == 'FileExistsError'
        assert same_process['underlying_executor_calls'] == 1
        assert all(x['underlying_executor_calls'] == 1 and x['arms'][0]['status'] == 'success' for x in fresh_processes)
        (ROOT / 'runtime-install-repro.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(result, indent=2))
