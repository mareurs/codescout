# Baseline-first oracle controller review — 2026-11-07

**Verdict: do not admit paid authors until the Important findings below are fixed and the targeted regressions pass.** This is the single requested review of the original new controller, not a re-review of later fixes.

Reviewed resident root: `/home/marius/.cache/codescout-resident/codescout/baseline-first-oracle-20261107` (abbreviated `ROOT` below). Exact original source hashes are in `source-bindings.json`; all source reads and mutations used those versions. The spec is `c40495db60f87d27`, plan `a51a67de9332e33a`.

Observed strengths: the original 22 tests passed; helper-level image, split-mount, volume-alias, prompt, capture-hash and frozen-payload mutations were killed. The original snapshot manifest hash matched registration, and all 985 manifest-listed payload records matched the source/low/xhigh hashes, had three distinct device/inode identities, and were not file symlinks (`clone-audit.json`). The pair helper freezes both outputs before evaluating. These observations do not substitute for the real main-path review.

## Important findings

1. **Sequential authors stack a non-idempotent runtime wrapper.** `ROOT/run_pair.py:90` loads one qualified module; `ROOT/run_pair.py:149` calls its `main()` for each arm in the same process. The qualified runner calls `install` each time (`differential-oracle-recovery-20261107/run_verifier_recovery.py:50`). `ROOT/runtime_compat.py:36` captures the already-wrapped executor, and `:40` exclusively creates a debug path. A fake-executor reproduction observed low succeed and xhigh raise `FileExistsError` on the xhigh debug path, with only one underlying executor call. Separate fresh processes each succeeded. Preserve the qualified one-install-per-process boundary or restore the pristine callable explicitly. **Issue: e5cf80dbc72c9c5e.** Proof: `repro_runtime_install.py`, `runtime-install-repro.json`.

2. **Equals-form native mounts bypass the exact inventory.** `ROOT/baseline_pair.py:12` and `ROOT/prepare_pair.py:69` enumerate only a separate `--mount` token. The qualified preflight accepts Docker's equals form (`/home/marius/.codex/worktrees/ca35/codescout/tools/agent_lifecycle/external.py:56`). A synthetic `--mount=type=bind,src=/saved/proposal,dst=/proposal,readonly` passed both the new guard and actual `external.validate_prepared`; the guard's returned inventory contained no proposal mount. The temp config's ordinary file hashes were updated as preparation would do, so hashing does not repair the inventory omission. Reject alternate syntax or normalize it before comparing all mounts. No actual prepared mount contamination was claimed. **Issue: ddb8f2ff73715acc.** Proof: `repro_mount_alias.py`, `mount-alias-repro.json`.

3. **Malformed clause elements stop the fixed pair instead of becoming protocol-invalid output.** `ROOT/baseline_pair.py:69` calls `clause.get` without verifying an object. `ROOT/run_pair.py:41` does not catch the resulting `AttributeError`. A valid JSON contract `{"clauses":[null]}` caused `freeze_capture` to raise and leave no frozen receipt. On low, this escapes the pair helper before xhigh is authored; it violates the explicit protocol-invalid/abstention treatment. Validate the element shape and raise `ValueError` at the schema boundary. **Issue: edb5251ae4c707ff.** Proof: `repro_capture.py`, `capture-repro.json`.

4. **Undeclared non-contrast tests are silently accepted.** `ROOT/baseline_pair.py:83` scans only functions already named `contrast_*`; consequently `:85` compares the contract against an incomplete executable test inventory. A valid patch adding an extra `#[test] fn surprise() { panic!("unregistered"); }` passed isolated `git apply --check` (exit 0), then froze successfully with only the two declared contrast tests. The evaluator's `contrast_` filter (`blind-contrast-verifier-followup-20261107/evaluate_v3.py:137`) omits the extra test. Enumerate all admitted executable test declarations and reject those outside the declared supported form. **Issue: cbebc4ff51aa256a.** Proof: `repro_capture.py`, `capture-repro.json`, `undeclared-test-patch-check.json`.

5. **Original fixtures omit load-bearing schema, freeze-receipt and real controller/preparer behavior.** `ROOT/test_run_pair.py:10` tests helpers only; `ROOT/test_baseline_pair.py:55` tests helper order rather than `run_pair.main`; no original test executes `prepare_pair.main`. Actual mutants to unresolved clauses (`baseline_pair.py:77`), duplicate IDs (`:81`), new-file restrictions (`:50`, `:54`), frozen pair order (`run_pair.py:62`), receipt hash (`:66`), actual main ordering (`:206`), cumulative cost increment (`:159`) and snapshot origin (`prepare_pair.py:61`) all survived. Add behavioral tests at those seams, including sequential runtime isolation, late failure cost preservation and one-shot execution. **Issue: b81dd8ba3e1b4464.** The full observed mutation table follows; its caveats are part of this finding.

## Applied mutation evidence

All 16 mutations were actually applied to separate `/tmp` copies, compiled as Python, and tested with the same original 22-test unittest discovery command. Each row's exit is the observed test-process exit, not a predicted result. `mutation-results.json` records exact replacement text, occurrence count and mutated-source SHA-256. Each `M*/stderr.log` retains the complete test output. M08 changes two occurrences and is counted as one candidate mutation, not two independent tests.

| Mutation | Change | Exit | Result |
|---|---|---:|---|
| M01 | Remove image guard | 1 | killed |
| M02 | Remove split-mount inventory guard | 1 | killed |
| M03 | Remove volume-alias guard | 1 | killed |
| M04 | Remove forbidden-prompt guard | 1 | killed |
| M05 | Remove existing-module registration guard | 1 | killed |
| M06 | Allow asserted unresolved clause | 0 | survived |
| M07 | Allow duplicate clause IDs | 0 | survived |
| M08 | Remove both new-file restrictions | 0 | survived |
| M09 | Remove frozen pair order/completeness guard | 0 | survived |
| M10 | Remove frozen receipt hash guard | 0 | survived |
| M11 | Omit second, per-author visibility call | 0 | survived |
| M12 | Replace main's pair helper with eager per-arm evaluation | 0 | survived |
| M13 | Replace cumulative final-cost increment with zero | 0 | survived |
| M14 | Change preparer clone origin to recovery directory | 0 | survived |
| M15 | Remove capture hash guard | 1 | killed |
| M16 | Remove frozen payload hash guard | 1 | killed |

**Measured: 16 applied, 7 killed, 9 survived.** M11 alone is not evidence of an independent defect: initial validation and per-author input hashes remain and may make the second check redundant. M12 is still stopped by `require_frozen_pair`, so it demonstrates lost fixed-pair completion, not successful private evaluation leakage. M14 should fail preparation against the qualified clone checks; the survivor shows absent preparation coverage, not successful admission of prior verifier knowledge. Do not describe these as nine security defects.

## Declined to judge

- Paid author quality, actual request effort, cumulative live cost, live cleanup and the three-variant test matrix: no author/provider/native workload was run in this review.
- Semantic validity of arbitrary source citations and empty test bodies: parsing/freezing is not a claim of a usable oracle. Empty-function fixtures freeze, but an all-pass matrix must not be called a detector; semantic and matrix judgment remains the executor's required downstream step.
- The already-qualified adapter, legacy compatibility implementation and offline evaluator internals beyond the integration seams needed for these findings: reused per the brief, without repeating old full gates/native controls.
- Future `review-admission.json` binding coverage and any parent fixes: they did not exist as the reviewed source version; no re-review is claimed.
- Adversarial host edits after registration: outside this bounded experiment's threat model; the reported equals-form issue concerns preparation accepting an inherited mount before registration, not arbitrary host tampering.

No resident source or prepared input was changed. No paid call, Docker workload, credential/token/debug-file read, or git mutation/merge/push was performed. The runtime reproduction used only synthetic empty debug files created inside temporary directories by the qualified wrapper. All issue writes were performed by the parent after duplicate checks and exact repro delivery.

Ledger checked: e5cf80dbc72c9c5e, ddb8f2ff73715acc, edb5251ae4c707ff, cbebc4ff51aa256a, b81dd8ba3e1b4464; prior related e4ea36b8419fda10, 6e1a5d01fc6ebb28, b85449246dae9236, b81c0bf318265944 were not refiled as these findings.
