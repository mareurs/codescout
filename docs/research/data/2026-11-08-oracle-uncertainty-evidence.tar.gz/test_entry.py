"""Run actual main against filesystem artifacts, fake only external author/native seams."""
import json
import pathlib
import tempfile
import types
import unittest
from unittest.mock import patch
import run_uncertainty as run

class EntryTests(unittest.TestCase):
    def scenario(self, drift=False):
        with tempfile.TemporaryDirectory() as d:
            root = pathlib.Path(d); arm=root/"low"; out=arm/"verifier"; out.mkdir(parents=True)
            prior=root/"prior"; prior.mkdir(); (prior/"expected-bootstrap-gitignore.patch").write_bytes(b"")
            plugin=root/"plugin"; plugin.mkdir()
            gate=root/"gate.json"; gate.write_text('{"exit_code":0}')
            executor=root/"qualified.py"; executor.write_text("# fixture")
            inp=root/"input"; inp.write_text("bound")
            reg={"status":"prepared_unstarted","retry_allowed":False,"prior_series_usd":"64",
                 "unresolved_usd":"4","reserve_usd":"1","ceiling_usd":"200","source":"fixture-source",
                 "source_commit":"head","source_gate_receipt":str(gate),"source_gate_receipt_sha256":run.sha(gate),
                 "qualified_runner":str(executor),"qualified_runner_sha256":run.sha(executor),
                 "out":str(out),"expected_mounts":[],"image":"fixture","hashes":{str(inp):run.sha(inp)}}
            review={"admitted":True,"source_bindings":{str(inp):run.sha(inp)}}
            for p,data in [(root/"registration-v2.json",reg),(root/"review-admission.json",review),
                           (out/"prepared.json",{"plugin":str(plugin)}),(out/"mcp-native-argv.json",[])]:
                p.write_text(json.dumps(data))
            events=[]
            def author(*args):
                events.append("author")
                self.assertTrue((root/"execution-registration.json").is_file())
                self.assertTrue((arm/"registration.json").is_file())
                run.save(arm/"cost-accounting.json",{"known_series_subtotal_usd":"64.2"})
                return {"generated_candidate_sha256":"fixture"}
            def freeze(*args):
                events.append("freeze")
                frozen=arm/"frozen"; frozen.mkdir()
                run.save(frozen/"oracle_contract.json",{"clauses":[]})
                return {"status":"abstained","tests":[]}
            fake_prepare=types.SimpleNamespace(PRIOR=prior,validate_author=lambda *a:events.append("visibility"),
                                              capture=types.SimpleNamespace(freeze_capture=freeze))
            def load_module(m):
                m.host_sample=lambda:{"mem_available":40*2**30,"root_free":100*2**30,"tmp_free":8*2**30}
            spec=types.SimpleNamespace(loader=types.SimpleNamespace(exec_module=load_module))
            if drift: inp.write_text("changed")
            with patch.object(run,"__file__",str(root/"run.py")), patch.dict("sys.modules",{"prepare_uncertainty":fake_prepare}), \
                 patch.object(run.subprocess,"check_output",side_effect=["head",""]), \
                 patch.object(run.importlib.util,"spec_from_file_location",return_value=spec), \
                 patch.object(run.importlib.util,"module_from_spec",return_value=types.SimpleNamespace()), \
                 patch.object(run.time,"sleep"), patch.object(run,"invoke_author",side_effect=author):
                if drift:
                    with self.assertRaises(ValueError): run.main()
                    self.assertEqual(events,[])
                    self.assertFalse((root/"attempt.json").exists())
                else:
                    run.main()
                    self.assertEqual(events,["visibility","author","freeze"])
                    self.assertTrue((root/"all-authors-frozen.json").is_file())
                    self.assertEqual(json.loads((root/"author-result.json").read_text())["status"],"abstained")
    def test_actual_entry_orders_visibility_author_and_freeze(self):
        self.scenario()
    def test_actual_entry_refuses_drift_before_any_attempt(self):
        self.scenario(drift=True)
