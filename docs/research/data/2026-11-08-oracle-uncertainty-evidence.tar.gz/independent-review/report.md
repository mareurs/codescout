# Independent author-admission review — 2026-11-08

Verdict: **NO-GO for paid author admission on these reviewed bytes.** No Critical finding. The real parent import sequence fails before launch, and load-bearing regression tests have demonstrated holes. One parent fix pass with observed red/green and re-applied relevant mutants is appropriate; this report does not authorize a paid launch.

Scope: resident-only additions under `/home/marius/.cache/codescout-resident/codescout/oracle-uncertainty-20261108` (R below), actual registration and prepared JSON; unchanged reused capture/runtime dependency bodies as needed. MAIN spec d8be1a58471ad76d and plan89f4456f348addf5 fetched through doc(get,full=true). CLAUDE.md and testing discipline read. Phase 0 read baseline-first closure memory and queried active bug ledger. No real source, index, prepared state, frozen seed, or model/provider state edited. All mutations live under this report directory. No Rust gate: read-only resident review scope.

## Important findings

**I1 — Actual entry cannot import qualified worker (KNOWN bug02b930bd7339c2e5).** R/run.py:60 imports local `prepare`; R/run.py:83-84 subsequently imports the qualified runner. The worker dependency `tools/hint_authority_pilot/run.py:15` requests its own top-level `prepare` symbols, but Python resolves the cached experiment module. Independent fresh subprocess reproduction exited 1 with `ImportError: cannot import name 'L' from 'prepare'`. See fresh-import.log. This is an actual execution blocker, not model behavior. Rename experiment modules to names that do not collide, then run the real import chain in a fresh process, without provider/native launch, and inspect module origins. R/test_entry.py:45-49 substitutes both the preparer and qualified loader, so its green result cannot establish this compatibility. M13 (remove child compatibility search path) also survives; pin copied compatibility selection with an isolated subprocess test. A fixture import test still cannot establish native/model validity.

**I2 — Reference-retention guard is not independently tested.** R/uncertainty.py:44 computes the necessary guard correctly, but R/test_uncertainty.py:28-30 fails the reference requirement assertion, which independently makes requirement_distinction false at uncertainty.py:46. Mutation M02 replaces reference_retained with True; the full 16-test suite still passes. An independently exercised case where reference fails only the preservation assertion returns negative on original code and complete_discriminator under M02 (reference-survivor-reproduction.json). Add the reference preservation-only failure case while every other success predicate passes; observe M02 killed. This is a confirmed regression-guard defect, not a present wrong result from unmutated decide.

**I3 — New preparation seams have no exercised regression boundary.** R/prepare.py:38-39,49,73 are individually removable without any test failing: M09 bypasses contract seed digest; M10 bypasses test seed digest; M11 bypasses preparation visibility validation; M12 omits snapshot cloning entirely. All four mutants pass 16/16 because no test invokes real prepare.main; R/test_entry.py:40-41 replaces the entire preparer, and test_uncertainty.py:63-68 tests only the shared seed helper. The preparation entry is explicitly required by plan Task 2. Add filesystem-fixture preparation tests at the actual new call sites, replacing only external snapshot/native boundaries as necessary; ensure changed seeds, substituted snapshot, and prohibited/equals-form/omitted visibility cannot yield registration. Keep the existing actual-state checks, but they are observations of this packet, not regression tests. No actual contaminated packet was observed in this review.

**I4 — Registered input binding guard is masked by duplicate reviewer fixtures.** R/run.py:24 must verify both registration and review bindings. R/test_run.py:17 uses the same path/hash for both; its drift case is rejected by either map, and its second case checks only review. R/test_entry.py:23-24 repeats the same overlap. M05 drops the registration map and passes 16/16. M06 drops the review map and is killed. Use distinct registered-only and review-only files, alter each separately while the other map remains valid, and assert no attempt/author invocation. The original code checks both correctly; this is a demonstrated test defect.

## Minor finding / limits of admission tests

M14 disables parent host admission at R/run.py:90 and M15 accepts a failed source-gate receipt at R/run.py:68; both pass. The entry fixture only supplies healthy host samples and exit_code 0. Add a failed-gate case and bounded expired-admission case that prove no author call. M14 alone does not demonstrate an unsafe paid launch: the unchanged qualified runner independently checks its resource floors. These are call-site coverage gaps, not proof the real current guards are absent.

## Observed validation

- Unmodified isolated suite: 16 tests, exit 0, full log baseline/suite.log.
- All 1,047 registered file bindings rehashed without mismatch; no prepared/debug/auth values emitted. Source worktree HEAD fe8bb4b34f5e7912f9b16c4c0bf1ff73a3a10a23 and git status empty.
- Actual snapshot file inventory: 985 actual files versus 985 manifest entries, no extra/missing files in knowledge/member-state/native-home/instructions. Registered payload hashes checked. Physical inode separation was reported by parent; it is not independently claimed here.
- Actual prepared prompt equals reconstruction from original low public prompt + generic follow-up + exact frozen prior low contract/test bytes. No raw prompt output saved in review evidence.
- Unchanged actual visibility guard accepted prepared input and rejected each one-variable omitted mount, equals-form mount, and private-input sentinel probe. prepared-audit.json records outcomes; these input probes were in memory only.
- Actual parent fresh-process import failed as I1. No paid/native operation was run. No review-admission.json created.
- Known final and unknown-reservation mutants M07/M08 killed. Current accounting is in a finally block before freeze; this supports tested launch-exception accounting, not every possible receipt-corruption/process-kill scenario.
- Reviewed-file hash comparison at close: no drift.

## Applied mutation evidence

Every listed mutation was actually applied to a separate isolated copy; the complete existing suite was run in a fresh Python process per mutation. `mutations.json` records exact before/after text and exit code; each Mxx/suite.log contains full results. Baseline is excluded from mutation counts. Observed **16 applied, 7 killed, 9 survived**. These are selected guard-site mutations, not a coverage percentage for the program. No syntax-invalid mutant was counted as killed.

| ID | Observed | Meaning |
|---|---|---|
| M01 | killed | Accept wrong repair with all assertions passing |
| M02 | survived | Ignore failing reference |
| M03 | killed | Ignore preservation failing baseline |
| M04 | killed | Treat unresolved discriminator as complete |
| M05 | survived | Skip registered input bindings while retaining reviewer bindings |
| M06 | killed | Skip independent reviewer bindings |
| M07 | killed | Release unknown cost reservation |
| M08 | killed | Discard final known author cost |
| M09 | survived | Skip prior frozen contract digest at preparation call site |
| M10 | survived | Skip prior frozen test digest at preparation call site |
| M11 | survived | Skip preparation visibility validation call site |
| M12 | survived | Skip original snapshot clone |
| M13 | survived | Omit copied compatibility module search path from fresh author process |
| M14 | survived | Disable parent host resource admission |
| M15 | survived | Accept failed prior gate receipt |
| M16 | killed | Allow invalid resource cell |

## Behavior deliberately not judged

- Native/model validity: no model/provider/native launch authorized for this reviewer, and Python fixtures cannot prove it. A successful real preflight/import remains only admission evidence; actual launch receipts/wire effort/resource/cleanup evidence are required later.
- Functional oracle success and assertion semantics: no new frozen author output exists. Offline evaluator wiring is explicitly a separate post-freeze phase; absence now is not an admission defect. Inspect future assertion bodies and public evidence, then run unchanged baseline/wrong/reference cells before any success claim.
- Causal efficacy or low-versus-xhigh capability: one exposed case with a follow-up, extra seed/time/draw is descriptive development evidence only. Existing negative pair is not a causal comparator; no new model control requested.
- Complete-contract success: policy separates unresolved/invalid outcomes; abstention is not success. The pure decision function assumes rows originate from independently validated measurements; it does not itself establish resource validity from raw logs.
- Exhaustive exclusion against adversarial modification of every unregistered host/plugin/directory entry was not established. The reviewed actual packet had exact known snapshot inventory and prompt reconstruction; hashes prove registered files only.
- Cost ceiling was checked as registered USD0.75 CLI / USD1 reservation against USD64.106761199999998654 known + USD4 hold / USD200 ceiling; reservation is not a guaranteed provider cap. No additional cost incurred by this review.

Complete exact reviewed SHA256 map: reviewed-hashes.json. Key hashes:
- `uncertainty.py`: `627e7d4e9793cda95b7dbc51e7b9f8770019f746fd0e9fedf49d993f3191ca3d`
- `prepare.py`: `431ea4a79f0f578475aec4ec03d32b68c3fec625d11ccd0d6e419ab2ade00acb`
- `run.py`: `8091326c34b3e20e99ccc619ace59001cacf77bcdce1c3069efa6d7778220ea7`
- `registration.json`: `a6c0e797cb3edbe8644dcc523251d9e29bab6ac95aabe93844134833116ed9ac`
- `low/verifier/prepared.json`: `c810d570f23fd669425667855c50f85248b135b10105702858283d5c2b5d99a1`

Ledger checked: 02b930bd7339c2e5 (known module collision), e4ea36b8419fda10 (prior generated contrast acceptance/reference bug); active-ledger query returned a capped 50-item page, not a claim of all known bugs.
