"""Model-free frozen three-variant evaluation; reuse qualified cell and single-job wrapper."""
import json
import pathlib
import sys
import time
from uncertainty import decide
from prepare_uncertainty import load, save, sha

ROOT = pathlib.Path(__file__).resolve().parent
PRIOR = ROOT.parent / "baseline-first-oracle-20261107"
sys.path.insert(0, str(PRIOR))
import run_pair
import offline_single_job as qualified_single

def main():
    run_pair.require_frozen_pair(ROOT, ["low"])
    assert load(ROOT / "author-audit.json")["author_valid"] is True
    assert sha(qualified_single.__file__) == "091840606011bc39dd00b949dc680c3768065eced74b0530443583817a10f0d6"
    ev = qualified_single.ev
    previous = load(PRIOR / "xhigh/oracle-evaluation-registration.json")
    assert sha(ev.__file__) == previous["executor_sha256"]
    frozen = load(ROOT / "low/frozen/freeze.json")
    assert frozen["status"] == "frozen" and 0 < len(frozen["tests"]) <= 8
    patch = ROOT / "low/frozen/generated-tests.patch"
    contract = ROOT / "low/frozen/oracle_contract.json"
    record = pathlib.Path("/home/marius/work/claude/setup-ab-data/fresh-tasks/nushell__nushell-18863/build/record.json")
    assert sha(record) == "8bb14b9ac8bd98d78f3ae2e3776a523b64d826269a79277058ea2677f5344114"
    out = ROOT / "offline-evaluation-1"; out.mkdir()
    (out / "generated-tests.patch").write_bytes(patch.read_bytes())
    bindings = {str(p): sha(p) for p in [ROOT/"all-authors-frozen.json", ROOT/"author-audit.json",
                patch, contract, record, pathlib.Path(ev.__file__), pathlib.Path(qualified_single.__file__),
                ROOT/"uncertainty.py", pathlib.Path(__file__)]}
    for row in previous["variants"]:
        if row["patch"]:
            assert sha(row["patch"]) == row["sha256"]
            bindings[row["patch"]] = row["sha256"]
    reg = dict(previous, tests=frozen["tests"], test_patch_sha256=sha(patch),
               all_frozen_receipt_sha256=sha(ROOT/"all-authors-frozen.json"))
    save(out / "registration.json", {"evaluation":reg,"bindings":bindings,"provider_calls":0,
         "cargo_build_jobs":1,"prelaunch_mem_gib":28,"prelaunch_samples":3,
         "continuous_mem_gib":24,"native_mem_gib":8,"native_cpus":4,"automatic_retry":False})
    ev.ROOT, ev.q.FLOORS = out, reg["floors"]
    parser = load(record)["log_parser"]
    wrapped = qualified_single.single_job_docker(ev.docker, out); ev.docker = wrapped
    rows=[]
    try:
        for variant in reg["variants"]:
            for p,h in bindings.items(): assert sha(p)==h,p
            run_pair.require_frozen_pair(ROOT, ["low"])
            good, deadline = 0, time.monotonic()+900
            while time.monotonic() < deadline:
                sample=ev.q.host_sample()
                with (out/"admission-samples.jsonl").open("a") as f:
                    f.write(json.dumps({"label":variant["label"],"sample":sample})+"\n")
                if sample["mem_gib"]>=28 and sample["root_gib"]>=80 and sample["tmp_gib"]>=4:
                    good+=1
                    if good==3: break
                else: good=0
                time.sleep(10)
            else: raise RuntimeError("Bounded admission expired before "+variant["label"])
            row=ev.cell(reg,variant,parser)
            proof=wrapped.proofs[-1] if wrapped.proofs else {}
            if proof.get("container")!=row["runtime"]["container"] or not proof.get("single_job_env_present") or proof.get("record_error"):
                row["valid"]=False; row["error"]="Missing or invalid compile environment proof"
            rows.append(row)
            if not row["valid"]: break
        result={"rows":rows,"all_three_valid":len(rows)==3 and all(r["valid"] for r in rows),
                "decision":decide(load(contract),rows),"provider_calls":0}
        save(out/"results.json",result)
        print(json.dumps({"all_three_valid":result["all_three_valid"],"decision":result["decision"],"provider_calls":0},indent=2))
    except BaseException as exc:
        save(out/"stopped.json",{"error":type(exc).__name__+": "+str(exc),"rows_completed":len(rows),
             "provider_calls":0,"automatic_retry":False})
        raise

if __name__ == "__main__":
    main()
