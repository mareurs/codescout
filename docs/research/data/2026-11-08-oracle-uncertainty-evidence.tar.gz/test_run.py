import json
import pathlib
import tempfile
import unittest
from unittest.mock import patch
import run_uncertainty as run

class AdmissionTests(unittest.TestCase):
    def test_review_required(self):
        with self.assertRaises(ValueError):
            run.require_admission({"hashes": {}}, {"admitted": False, "source_bindings": {}})

    def test_reviewed_and_registered_hashes_are_both_checked(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / "input"; p.write_text("ok")
            h = run.sha(p)
            reg, review = {"hashes": {str(p): h}}, {"admitted": True, "source_bindings": {str(p): h}}
            run.require_admission(reg, review)
            p.write_text("drift")
            with self.assertRaises(ValueError): run.require_admission(reg, review)
            reg["hashes"] = {}
            with self.assertRaises(ValueError): run.require_admission(reg, review)
    def test_registered_only_drift_with_distinct_valid_reviewer_file(self):
        with tempfile.TemporaryDirectory() as d:
            p, q = pathlib.Path(d) / "registered", pathlib.Path(d) / "reviewed"
            p.write_text("registered"); q.write_text("reviewed")
            reg = {"hashes": {str(p): run.sha(p)}}
            review = {"admitted": True, "source_bindings": {str(q): run.sha(q)}}
            run.require_admission(reg, review)
            p.write_text("changed")
            with self.assertRaises(ValueError):
                run.require_admission(reg, review)

class CostTests(unittest.TestCase):
    def test_launch_failure_keeps_final_known_cost(self):
        self.check_failure({"cost_usd": 0.25, "unknown_provider_cost": False, "lifecycle": {"cost_is_final": True}}, "64.356761199999998654", "0")

    def test_launch_failure_keeps_unknown_reservation(self):
        self.check_failure({}, "64.106761199999998654", "1")

    def check_failure(self, receipt, expected_known, expected_reserve):
        with tempfile.TemporaryDirectory() as d:
            root = pathlib.Path(d); arm = root / "low"; out = arm / "verifier"; out.mkdir(parents=True)
            (out / "receipt.json").write_text(json.dumps(receipt))
            reg = {"out": str(out), "reserve_usd": "1", "prior_series_usd": "64.106761199999998654", "qualified_runner": "/not/executed.py"}
            with patch.object(run.subprocess, "run", side_effect=OSError("fixture launch failure")):
                with self.assertRaises(OSError): run.invoke_author(reg, root)
            self.assertTrue((arm / "cost-accounting.json").is_file(), "launch failure must preserve cost accounting")
            cost = json.loads((arm / "cost-accounting.json").read_text())
            self.assertEqual(cost["known_series_subtotal_usd"], expected_known)
            self.assertEqual(cost["current_unknown_reserve_usd"], expected_reserve)

if __name__ == "__main__":
    unittest.main()
