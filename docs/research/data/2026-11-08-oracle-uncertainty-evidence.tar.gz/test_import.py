"""Real qualified import and copied child compatibility-path regression; no launch."""
import pathlib
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import run_uncertainty as run

ROOT = pathlib.Path(__file__).resolve().parent
class ImportTests(unittest.TestCase):
    def test_real_qualified_import_after_experiment_preparer(self):
        code = """import sys,pathlib,importlib.util
sys.path.insert(0,sys.argv[1])
import prepare_uncertainty
s=importlib.util.spec_from_file_location('qualified_import_check',sys.argv[2])
q=importlib.util.module_from_spec(s); s.loader.exec_module(q)
assert str(pathlib.Path(q.external.__file__).resolve()).endswith('/ca35/codescout/tools/agent_lifecycle/external.py')
print('qualified-import-ok')
"""
        runner=ROOT.parent/"differential-oracle-recovery-20261107/run_verifier_recovery.py"
        p=subprocess.run([sys.executable,"-B","-c",code,str(ROOT),str(runner)],capture_output=True,text=True)
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertIn("qualified-import-ok",p.stdout)

    def test_child_uses_compatibility_from_registered_experiment_root(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d); arm=root/"low"; out=arm/"verifier"; out.mkdir(parents=True)
            (root/"runtime_compat.py").write_text("QUALIFIED_COMPAT = 'expected-fixture'\n")
            qualified=root/"qualified.py"
            qualified.write_text("import runtime_compat\nimport pathlib,json\ndef main():\n assert runtime_compat.QUALIFIED_COMPAT=='expected-fixture'\n with (ROOT/'verifier-closed.json').open('x') as f: json.dump({'status':'fixture-closed'},f)\n")
            reg={"out":str(out),"qualified_runner":str(qualified),"prior_series_usd":"64","reserve_usd":"1"}
            saved_run=run.subprocess.run
            with patch.object(run.subprocess,"run",side_effect=lambda args,**kw:saved_run(args,**kw,cwd="/")):
                result=run.invoke_author(reg,root)
            self.assertEqual(result["status"],"fixture-closed")
