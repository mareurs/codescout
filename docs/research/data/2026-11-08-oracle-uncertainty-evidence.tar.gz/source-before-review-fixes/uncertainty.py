import hashlib
import pathlib

"""Public-only uncertainty experiment policy; no model or evaluator side effects."""
def decide(contract, rows):
    clauses = contract.get("clauses", [])
    if not isinstance(clauses, list) or not clauses:
        return {"status": "protocol_invalid"}
    names, requirements, preservation, ids = [], [], [], set()
    unresolved = False
    for clause in clauses:
        if not isinstance(clause, dict):
            return {"status": "protocol_invalid"}
        kind, tests, cid = clause.get("kind"), clause.get("test_names"), clause.get("id")
        if kind not in ("requirement", "preservation", "unresolved") or not isinstance(tests, list):
            return {"status": "protocol_invalid"}
        if not isinstance(cid, str) or cid in ids:
            return {"status": "protocol_invalid"}
        ids.add(cid)
        if any(not isinstance(n, str) or not n.startswith("contrast_") for n in tests):
            return {"status": "protocol_invalid"}
        if kind == "unresolved":
            if tests:
                return {"status": "protocol_invalid"}
            unresolved = True
        else:
            if not tests:
                return {"status": "protocol_invalid"}
            (requirements if kind == "requirement" else preservation).extend(tests)
        names.extend(tests)
    if len(names) != len(set(names)) or len(names) > 8:
        return {"status": "protocol_invalid"}
    if not names:
        return {"status": "unresolved" if unresolved else "protocol_invalid"}
    if not requirements or not preservation:
        return {"status": "protocol_invalid"}
    if len(rows) != 3 or {r["label"] for r in rows} != {"baseline", "low-control", "reference"}:
        return {"status": "measurement_invalid"}
    if any(r.get("valid") is not True or set(r.get("statuses", {})) != set(names)
           or any(s not in ("pass", "fail") for s in r["statuses"].values()) for r in rows):
        return {"status": "measurement_invalid"}
    by_label = {r["label"]: r["statuses"] for r in rows}
    base, wrong, reference = (by_label[k] for k in ("baseline", "low-control", "reference"))
    reference_retained = all(s == "pass" for s in reference.values())
    baseline_preserved = all(base[t] == "pass" for t in preservation)
    requirement_distinction = any(base[t] == "fail" and reference[t] == "pass" for t in requirements)
    wrong_repair_rejected = any(wrong[t] == "fail" for t in preservation)
    useful = reference_retained and baseline_preserved and requirement_distinction and wrong_repair_rejected
    return {"status": "unresolved" if unresolved else ("complete_discriminator" if useful else "negative"),
            "reference_retained": reference_retained, "baseline_preserved": baseline_preserved,
            "requirement_distinction": requirement_distinction, "wrong_repair_rejected": wrong_repair_rejected}

def verify_seed(path, expected):
    data = pathlib.Path(path).read_bytes()
    if hashlib.sha256(data).hexdigest() != expected:
        raise ValueError("Frozen seed bytes changed")
    return data
def build_prompt(original, contract, tests, follow_up):
    """Attach only the previously frozen self-authored seed, as data."""
    return (original + "\n\n" + follow_up
            + "\n\nBEGIN PRIOR CONTRACT DATA\n" + contract.decode()
            + "\nEND PRIOR CONTRACT DATA\n\nBEGIN PRIOR TEST DATA\n"
            + tests.decode() + "\nEND PRIOR TEST DATA\n")
