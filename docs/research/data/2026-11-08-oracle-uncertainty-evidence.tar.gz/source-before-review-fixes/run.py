import importlib.util
import sys
import time
from decimal import Decimal

"""One-shot qualified author entry; frozen tests are evaluated in a separate phase."""
import hashlib
import json
import pathlib
import subprocess

def sha(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
def load(path):
    return json.loads(pathlib.Path(path).read_text())

def save(path, data):
    with pathlib.Path(path).open("x") as stream:
        json.dump(data, stream, indent=2); stream.write("\n")

def require_admission(reg, review):
    if review.get("admitted") is not True:
        raise ValueError("Independent source-bound review is required")
    for bindings in (reg["hashes"], review["source_bindings"]):
        for p, expected in bindings.items():
            if sha(p) != expected:
                raise ValueError("Registered or reviewed source/input drift: " + p)

def invoke_author(reg, root):
    root = pathlib.Path(root)
    arm, out = root / "low", pathlib.Path(reg["out"])
    error = None
    try:
        code = ("import importlib.util,pathlib,sys; "
                "sys.path.insert(0,str(pathlib.Path(sys.argv[2]).parent)); "
                "s=importlib.util.spec_from_file_location('qualified_author',sys.argv[1]); "
                "m=importlib.util.module_from_spec(s); s.loader.exec_module(m); "
                "m.ROOT=pathlib.Path(sys.argv[2]); m.main()")
        with (arm / "author-process.log").open("xb") as stream:
            process = subprocess.run([sys.executable, "-B", "-c", code, reg["qualified_runner"], str(arm)],
                                     stdout=stream, stderr=subprocess.STDOUT)
        save(arm / "author-process.json", {"exit_code": process.returncode, "qualified_runner_fresh_process": True})
        if process.returncode:
            raise RuntimeError("Qualified author process exited " + str(process.returncode))
    except BaseException as exc:
        error = type(exc).__name__ + ": " + str(exc)
        raise
    finally:
        receipt = load(out / "receipt.json") if (out / "receipt.json").is_file() else {}
        cost = receipt.get("cost_usd")
        final = (cost is not None and receipt.get("lifecycle", {}).get("cost_is_final") is True
                 and receipt.get("unknown_provider_cost", True) is False)
        known = Decimal(reg["prior_series_usd"]) + (Decimal(str(cost)) if final else Decimal(0))
        save(arm / "cost-accounting.json", {"cost_usd": cost, "cost_is_final": final,
             "known_series_subtotal_usd": str(known), "current_unknown_reserve_usd": "0" if final else reg["reserve_usd"],
             "original_unresolved_reserve_usd": "4", "error": error})
    return load(arm / "verifier-closed.json")
def main():
    root = pathlib.Path(__file__).resolve().parent
    import prepare
    from uncertainty import decide
    reg, review = load(root / "registration.json"), load(root / "review-admission.json")
    require_admission(reg, review)
    assert reg["status"] == "prepared_unstarted" and reg["retry_allowed"] is False
    assert Decimal(reg["prior_series_usd"]) + Decimal(reg["unresolved_usd"]) + Decimal(reg["reserve_usd"]) < Decimal(reg["ceiling_usd"])
    assert sha(reg["qualified_runner"]) == reg["qualified_runner_sha256"]
    assert sha(reg["source_gate_receipt"]) == reg["source_gate_receipt_sha256"]
    assert load(reg["source_gate_receipt"])["exit_code"] == 0
    assert subprocess.check_output(["git", "-C", reg["source"], "rev-parse", "HEAD"], text=True).strip() == reg["source_commit"]
    assert not subprocess.check_output(["git", "-C", reg["source"], "status", "--porcelain"], text=True)
    out, arm = pathlib.Path(reg["out"]), root / "low"
    assert not any((out / n).exists() for n in ("started.json", "launch.json", "receipt.json"))
    cfg = load(out / "prepared.json")
    prepare.validate_author(cfg, load(out / "mcp-native-argv.json"), reg["expected_mounts"], reg["image"])
    plugin_hashes = {str(p): sha(p) for p in pathlib.Path(cfg["plugin"]).rglob("*") if p.is_file()}
    arm_reg = dict(reg)
    arm_reg["hashes"] = dict(reg["hashes"], **plugin_hashes)
    save(arm / "registration.json", arm_reg)
    save(root / "execution-registration.json", {"registration_sha256": sha(root / "registration.json"),
         "review_sha256": sha(root / "review-admission.json"), "plugin_bindings": plugin_hashes,
         "model_attempts": 1, "automatic_retry": False})
    save(root / "attempt.json", {"effort": "low", "automatic_retry": False})
    spec = importlib.util.spec_from_file_location("uncertainty_qualified", reg["qualified_runner"])
    qualified = importlib.util.module_from_spec(spec); spec.loader.exec_module(qualified)
    good, deadline = 0, time.monotonic() + 900
    while time.monotonic() < deadline:
        sample = qualified.host_sample()
        with (root / "host-admission-samples.jsonl").open("a") as f:
            f.write(json.dumps(sample) + "\n")
        if sample["mem_available"] >= 24 * 2**30 and sample["root_free"] >= 80 * 2**30 and sample["tmp_free"] >= 4 * 2**30:
            good += 1
            if good == 3:
                break
        else:
            good = 0
        time.sleep(10)
    else:
        raise RuntimeError("Bounded admission expired before model launch")
    require_admission(reg, review)
    closed = invoke_author(arm_reg, root)
    setup = (prepare.PRIOR / "expected-bootstrap-gitignore.patch").read_bytes()
    frozen = prepare.capture.freeze_capture(arm, closed["generated_candidate_sha256"], setup)
    save(root / "all-authors-frozen.json", {"arms": [frozen], "before_reference_evaluation": True,
         "known_series_subtotal_usd": load(arm / "cost-accounting.json")["known_series_subtotal_usd"]})
    contract = load(arm / "frozen/oracle_contract.json")
    # This process ends before host-only reference/candidate evaluation.
    save(root / "author-result.json", {"status": frozen["status"], "frozen_tests": frozen["tests"],
         "contains_unresolved": any(c["kind"] == "unresolved" for c in contract.get("clauses", [])),
         "provider_cost": load(arm / "cost-accounting.json"), "evaluation": "not_started"})
    print(json.dumps(load(root / "author-result.json"), indent=2))


if __name__ == "__main__":
    main()
