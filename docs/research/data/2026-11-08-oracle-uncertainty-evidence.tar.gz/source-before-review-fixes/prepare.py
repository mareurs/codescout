"""Prepare one public-only low uncertainty follow-up; no model calls."""
import copy
import importlib.util
import json
import pathlib
import shutil
import subprocess
import sys
from uncertainty import build_prompt, verify_seed

ROOT = pathlib.Path(__file__).resolve().parent
PRIOR = ROOT.parent / "baseline-first-oracle-20261107"
sys.path.insert(0, str(PRIOR))
import prepare_pair as prior
import run_pair as capture
from baseline_pair import validate_author

def load(path):
    return json.loads(pathlib.Path(path).read_text())

def sha(path):
    import hashlib
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()

def save(path, data):
    with pathlib.Path(path).open("x") as f:
        json.dump(data, f, indent=2); f.write("\n")

def main():
    assert not (ROOT / "registration.json").exists()
    old = load(PRIOR / "pair-registration-v2.json")
    assert subprocess.check_output(["git", "-C", old["source"], "rev-parse", "HEAD"], text=True).strip() == old["source_commit"]
    assert not subprocess.check_output(["git", "-C", old["source"], "status", "--porcelain"], text=True)
    capture.require_frozen_pair(PRIOR, ["low", "xhigh"])
    frozen = load(PRIOR / "low/frozen/freeze.json")
    seed_contract = PRIOR / "low/frozen/oracle_contract.json"
    seed_tests = PRIOR / "low/frozen/generated-tests.patch"
    contract = verify_seed(seed_contract, frozen["bindings"][str(seed_contract)])
    tests = verify_seed(seed_tests, frozen["bindings"][str(seed_tests)])
    project = load(prior.BASE / "semantic-contract-pilot-20261106/prompt-inputs-registration.json")["projects"]["nushell__nushell-18863"]
    manifest_path = pathlib.Path(project["runtime_snapshot_manifest"])
    verify_seed(manifest_path, project["runtime_snapshot_manifest_sha256"])
    manifest = load(manifest_path)
    prep_path = pathlib.Path("/home/marius/work/claude/codescout/.worktrees/semantic-contract-runtime-01a15ca9/tools/agent_lifecycle/semantic_prepare.py")
    spec = importlib.util.spec_from_file_location("uncertainty_snapshot", prep_path)
    prep = importlib.util.module_from_spec(spec); spec.loader.exec_module(prep)
    arm = ROOT / "low"; arm.mkdir()
    out = arm / "verifier"
    proof = prep.clone_snapshot(manifest_path.parent, out, manifest)
    save(out / "clone-proof.json", proof)
    actor = pathlib.Path("/tmp/cs-oracle-uncertainty-01a15ca9-20261108"); actor.mkdir()
    original = load(prior.ORIGINAL / "prepared.json")
    for name in ("CLAUDE.md", "AGENTS.md"):
        shutil.copyfile(prior.ORIGINAL / "actor-context" / name, actor / name)
    shutil.copyfile(prior.ORIGINAL / "global-CLAUDE.md", out / "global-CLAUDE.md")
    native = prep.rewrite_native(load(prior.ORIGINAL / "mcp-native-argv.json"), out, manifest["projects"], "cs-uncertainty-low-01a15ca9")
    save(out / "mcp-native-argv.json", native)
    mounts = [native[i + 1] for i, a in enumerate(native) if a == "--mount"]
    for raw in mounts:
        fields = dict(x.split("=", 1) if "=" in x else (x, "") for x in raw.split(","))
        if "readonly" not in fields:
            assert pathlib.Path(fields["src"]).is_relative_to(out)
        assert "/proposal" not in raw and "/public-observations" not in raw
    for name in ("runtime_compat.py", "supervision_headroom.py"):
        shutil.copyfile(PRIOR / name, ROOT / name)
    import runtime_compat
    original_prompt = load(PRIOR / "low/verifier/prepared.json")["prompt"]
    prompt = build_prompt(original_prompt, contract, tests, (ROOT / "follow-up.txt").read_text())
    cfg = copy.deepcopy(original)
    cfg.update(image=old["image"], actor=str(actor), global_rules=str(out / "global-CLAUDE.md"),
               prompt=prompt, timeout_s=1800, check_timeout_s=30, max_continuations=8,
               checks=[{"id": "patch_hygiene_only", "command": "git diff --check"},
                       {"id": "contract_syntax_only", "command": "python3 -m json.tool oracle_contract.json >/dev/null"}])
    cfg["files"] = {str(p): sha(p) for p in (out / "mcp-native-argv.json", out / "global-CLAUDE.md", pathlib.Path(cfg["cli"]), actor / "CLAUDE.md", actor / "AGENTS.md")}
    validate_author(cfg, native, mounts, old["image"])
    save(out / "prepared.json", cfg)
    stdio = runtime_compat.materialize(out)
    hashes = {p: h for p, h in old["arms"][0]["hashes"].items() if p.startswith(old["source"] + "/") or p.endswith("/grade_policy.py")}
    hashes.update(cfg["files"])
    hashes.update({str(out / rel): rec["sha256"] for rel, rec in manifest["files"].items()})
    immutable = [out / "prepared.json", ROOT / "prepare.py", ROOT / "uncertainty.py", ROOT / "follow-up.txt",
                 ROOT / "runtime_compat.py", ROOT / "supervision_headroom.py", stdio, prep_path,
                 seed_contract, seed_tests, PRIOR / "all-authors-frozen.json", PRIOR / "run_pair.py", PRIOR / "baseline_pair.py",
                 PRIOR / "prepare_pair.py", manifest_path]
    hashes.update({str(p): sha(p) for p in immutable})
    for path, expected in hashes.items():
        verify_seed(path, expected)
    reg = {"status": "prepared_unstarted", "retry_allowed": False, "effort": "low", "out": str(out),
           "source": old["source"], "source_commit": old["source_commit"], "image": old["image"],
           "reserve_usd": "1", "cli_cap_usd": "0.75", "prior_series_usd": "64.106761199999998654",
           "unresolved_usd": "4", "ceiling_usd": "200", "expected_mounts": mounts, "hashes": hashes,
           "snapshot_manifest": str(manifest_path), "prompt_sha256": __import__("hashlib").sha256(prompt.encode()).hexdigest(),
           "qualified_runner": str(prior.RECOVERY / "run_verifier_recovery.py"),
           "qualified_runner_sha256": old["qualified_runner_sha256"],
           "source_gate_receipt": old["source_gate_receipt"], "source_gate_receipt_sha256": old["source_gate_receipt_sha256"]}
    save(ROOT / "registration.json", reg)
    print(json.dumps({"prepared": "low", "provider_calls": 0, "prompt_sha256": reg["prompt_sha256"]}))

if __name__ == "__main__":
    main()
