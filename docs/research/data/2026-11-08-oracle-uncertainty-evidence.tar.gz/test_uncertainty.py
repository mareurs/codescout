import copy
import json
import pathlib
import tempfile
import unittest
from uncertainty import decide, verify_seed

CONTRACT = {"clauses": [
    {"id": "r", "kind": "requirement", "test_names": ["contrast_required"]},
    {"id": "p", "kind": "preservation", "test_names": ["contrast_preserved"]},
]}

def cells():
    return [
        {"label": "baseline", "valid": True, "statuses": {"contrast_required": "fail", "contrast_preserved": "pass"}},
        {"label": "low-control", "valid": True, "statuses": {"contrast_required": "pass", "contrast_preserved": "fail"}},
        {"label": "reference", "valid": True, "statuses": {"contrast_required": "pass", "contrast_preserved": "pass"}},
    ]

class DecisionTests(unittest.TestCase):
    def test_positive_control(self):
        self.assertEqual(decide(CONTRACT, cells())["status"], "complete_discriminator")

    def test_wrong_repair_all_pass_is_negative(self):
        rows = cells(); rows[1]["statuses"]["contrast_preserved"] = "pass"
        self.assertEqual(decide(CONTRACT, rows)["status"], "negative")

    def test_reference_failure_is_negative(self):
        rows = cells(); rows[2]["statuses"]["contrast_required"] = "fail"
        self.assertEqual(decide(CONTRACT, rows)["status"], "negative")
    def test_reference_preservation_failure_with_other_predicates_true(self):
        rows = cells()
        rows[2]["statuses"]["contrast_preserved"] = "fail"
        result = decide(CONTRACT, rows)
        self.assertEqual(result["status"], "negative")
        self.assertFalse(result["reference_retained"])
        self.assertTrue(result["requirement_distinction"])
        self.assertTrue(result["baseline_preserved"])
        self.assertTrue(result["wrong_repair_rejected"])

    def test_preservation_must_pass_baseline(self):
        rows = cells(); rows[0]["statuses"]["contrast_preserved"] = "fail"
        self.assertEqual(decide(CONTRACT, rows)["status"], "negative")

    def test_requirement_must_distinguish_baseline(self):
        rows = cells(); rows[0]["statuses"]["contrast_required"] = "pass"
        self.assertEqual(decide(CONTRACT, rows)["status"], "negative")

    def test_unresolved_is_separate_even_with_discrimination(self):
        c = copy.deepcopy(CONTRACT)
        c["clauses"].append({"id": "u", "kind": "unresolved", "test_names": []})
        self.assertEqual(decide(c, cells())["status"], "unresolved")

    def test_empty_contract_cannot_succeed(self):
        self.assertEqual(decide({"clauses": []}, cells())["status"], "protocol_invalid")

    def test_all_cells_and_statuses_required(self):
        for rows in (cells()[:2], [cells()[0]] * 3):
            with self.subTest(rows=rows):
                self.assertEqual(decide(CONTRACT, rows)["status"], "measurement_invalid")
        rows = cells(); del rows[1]["statuses"]["contrast_preserved"]
        self.assertEqual(decide(CONTRACT, rows)["status"], "measurement_invalid")
        rows = cells(); rows[1]["valid"] = False
        self.assertEqual(decide(CONTRACT, rows)["status"], "measurement_invalid")

    def test_no_preservation_or_no_requirement_cannot_succeed(self):
        for c in ({"clauses": CONTRACT["clauses"][:1]}, {"clauses": CONTRACT["clauses"][1:]}):
            with self.subTest(c=c):
                self.assertEqual(decide(c, cells())["status"], "protocol_invalid")

class SeedTests(unittest.TestCase):
    def test_changed_seed_is_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / "seed"
            p.write_bytes(b"changed")
            with self.assertRaises(ValueError):
                verify_seed(p, "0" * 64)

if __name__ == "__main__":
    unittest.main()
