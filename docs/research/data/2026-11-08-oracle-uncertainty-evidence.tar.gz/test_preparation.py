"""Exercise real preparer call sites; external snapshot/native operations use filesystem fixtures."""
import hashlib
import json
import pathlib
import shutil
import tempfile
import types
import unittest
from unittest.mock import patch
import prepare_uncertainty as prep

class PreparationTests(unittest.TestCase):
    def scenario(self, changed_seed=None, invalid_native=False):
        with tempfile.TemporaryDirectory() as d:
            base=pathlib.Path(d); root=base/"experiment"; root.mkdir()
            prior=root.parent/"prior"; prior.mkdir(); original=base/"original"; original.mkdir()
            def write(p,data):
                p.parent.mkdir(parents=True,exist_ok=True)
                p.write_text(json.dumps(data) if isinstance(data,(dict,list)) else data)
            source=base/"source"; source.mkdir()
            src=source/"bound.py"; write(src,"source")
            cli=base/"cli"; write(cli,"cli")
            recovery=base/"recovery"; runner=recovery/"run_verifier_recovery.py"; write(runner,"runner")
            gate=base/"gate"; write(gate,{"exit_code":0})
            old={"source":str(source),"source_commit":"head","image":"fixture-image","arms":[{"hashes":{str(src):prep.sha(src)}}],
                 "qualified_runner_sha256":prep.sha(runner),"source_gate_receipt":str(gate),"source_gate_receipt_sha256":prep.sha(gate)}
            write(prior/"pair-registration-v2.json",old)
            seeds=[prior/"low/frozen/oracle_contract.json",prior/"low/frozen/generated-tests.patch"]
            write(seeds[0],{"clauses":[{"id":"u","kind":"unresolved","test_names":[]}]}); write(seeds[1],"seed-tests")
            write(prior/"low/frozen/freeze.json",{"bindings":{str(p):prep.sha(p) for p in seeds}})
            write(prior/"all-authors-frozen.json",{"fixture":True})
            if changed_seed is not None: write(seeds[changed_seed],"changed")
            snapshot=base/"snapshot"; payload=snapshot/"knowledge/payload"; write(payload,"original")
            manifest_path=snapshot/"manifest.json"
            write(manifest_path,{"projects":[],"files":{"knowledge/payload":{"sha256":prep.sha(payload)}}})
            write(base/"semantic-contract-pilot-20261106/prompt-inputs-registration.json",
                  {"projects":{"nushell__nushell-18863":{"runtime_snapshot_manifest":str(manifest_path),
                                                       "runtime_snapshot_manifest_sha256":prep.sha(manifest_path)}}})
            write(original/"prepared.json",{"cli":str(cli)})
            write(original/"mcp-native-argv.json",[])
            write(original/"actor-context/CLAUDE.md","project")
            write(original/"actor-context/AGENTS.md","pointer")
            write(original/"global-CLAUDE.md","global")
            write(prior/"low/verifier/prepared.json",{"prompt":"Original public task"})
            for name in ("runtime_compat.py","supervision_headroom.py","run_pair.py","baseline_pair.py","prepare_pair.py"):
                write(prior/name,"fixture dependency")
            for name in ("prepare_uncertainty.py","uncertainty.py","follow-up.txt"):
                write(root/name,"fixture current")
            helper_path=base/"snapshot_helper.py"; write(helper_path,"fixture")
            actors=base/"actors"; actors.mkdir(); events=[]
            def clone(origin,out,manifest):
                self.assertEqual(origin,manifest_path.parent)
                self.assertEqual(manifest["files"]["knowledge/payload"]["sha256"],prep.sha(payload))
                events.append("clone")
                for rel in manifest["files"]:
                    (out/rel).parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(origin/rel,out/rel)
                return {"fixture":"cloned"}
            def rewrite(native,out,projects,label):
                args=["docker","--mount",f"type=bind,src={out/'knowledge'},dst=/state","fixture-image","a","b","c"]
                if invalid_native: args.insert(1,"--mount=type=bind,src=/private,dst=/proposal")
                return args
            def materialize(out):
                p=out/"compat-stdio/stdio.py"; write(p,"stdio"); return p
            fake_prior=types.SimpleNamespace(BASE=base,ORIGINAL=original,RECOVERY=recovery)
            fake_capture=types.SimpleNamespace(require_frozen_pair=lambda *a:None)
            helper=types.SimpleNamespace(clone_snapshot=clone,rewrite_native=rewrite)
            spec=types.SimpleNamespace(loader=types.SimpleNamespace(exec_module=lambda m:None))
            with patch.object(prep,"ROOT",root), patch.object(prep,"PRIOR",prior), patch.object(prep,"ACTOR_PARENT",actors), \
                 patch.object(prep,"PREP_PATH",helper_path), patch.object(prep,"prior",fake_prior), patch.object(prep,"capture",fake_capture), \
                 patch.object(prep.subprocess,"check_output",side_effect=["head",""]), \
                 patch.object(prep.importlib.util,"spec_from_file_location",return_value=spec), \
                 patch.object(prep.importlib.util,"module_from_spec",return_value=helper), \
                 patch.dict("sys.modules",{"runtime_compat":types.SimpleNamespace(materialize=materialize)}):
                if changed_seed is not None or invalid_native:
                    with self.assertRaises(ValueError): prep.main()
                    self.assertFalse((root/"registration.json").exists())
                    if changed_seed is not None: self.assertEqual(events,[])
                else:
                    prep.main()
                    self.assertEqual(events,["clone"])
                    reg=json.loads((root/"registration.json").read_text())
                    cfg=json.loads((root/"low/verifier/prepared.json").read_text())
                    self.assertIn("seed-tests",cfg["prompt"])
                    self.assertEqual(reg["effort"],"low")
                    self.assertEqual(reg["cli_cap_usd"],"0.75")
                    self.assertNotEqual(payload.stat().st_ino,(root/"low/verifier/knowledge/payload").stat().st_ino)

    def test_actual_preparation_entry_clones_original_and_binds_seed(self):
        self.scenario()
    def test_changed_contract_seed_rejected_at_call_site(self):
        self.scenario(changed_seed=0)
    def test_changed_test_seed_rejected_at_call_site(self):
        self.scenario(changed_seed=1)
    def test_prohibited_native_mount_rejected_at_call_site(self):
        self.scenario(invalid_native=True)
