"""Archive the closed compatibility delta and verify every emitted payload."""
import hashlib
import io
import json
import pathlib
import tarfile
import time

ROOT = pathlib.Path(__file__).resolve().parent
TARGET = pathlib.Path("/home/marius/work/claude/codescout/docs/research/data/2026-11-07-native-probe-compatibility-evidence.tar.gz")


def main():
    assert not TARGET.exists()
    assert json.loads((ROOT / "common-closed-audit.json").read_text())["qualified"] is True
    payloads = {}
    retained = []
    for path in sorted(ROOT.rglob("*")):
        relative = path.relative_to(ROOT)
        if "__pycache__" in relative.parts or path.suffix == ".pyc":
            continue
        if not path.is_file():
            continue
        assert not path.is_symlink(), str(path)
        raw = path.read_bytes()
        if len(relative.parts) > 1 and relative.parts[0] == "common" and relative.parts[1] in ("knowledge", "member-state", "native-home"):
            retained.append({"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()})
        else:
            payloads[relative.as_posix()] = raw
    payloads["retained-reused-inputs.json"] = (json.dumps({"files": retained, "resident_bytes_retained": True}, indent=2) + "\n").encode()
    manifest = {name: {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()} for name, raw in payloads.items()}
    payloads["MANIFEST.json"] = (json.dumps({"files": manifest, "scope": "Closed compatibility delta, linked invalid v1 retained separately; no paid repair result."}, indent=2) + "\n").encode()
    with tarfile.open(TARGET, "x:gz") as archive:
        for name, raw in payloads.items():
            info = tarfile.TarInfo(name)
            info.size = len(raw)
            info.mode = 0o644
            info.mtime = int(time.time())
            archive.addfile(info, io.BytesIO(raw))
    with tarfile.open(TARGET, "r:gz") as archive:
        members = archive.getmembers()
        assert len(members) == len(payloads) and {m.name for m in members} == set(payloads)
        for member in members:
            assert archive.extractfile(member).read() == payloads[member.name]
    receipt = {"archive": str(TARGET), "sha256": hashlib.sha256(TARGET.read_bytes()).hexdigest(),
               "bytes": TARGET.stat().st_size, "verified_payloads": len(manifest), "verified_manifest": True,
               "retained_reused_snapshot_files": len(retained), "qualified": True, "paid_admission": False}
    raw = json.dumps(receipt, indent=2) + "\n"
    (ROOT / "archive-receipt.json").write_text(raw)
    TARGET.with_name(TARGET.name + ".json").write_text(raw)
    print(raw)


if __name__ == "__main__":
    main()
