# Personal Claude Code Configuration

Private notes for this machine. Not tracked in any git repo.

## Four Claude Code Instances

This machine runs **four separate Claude Code instances** with independent config dirs:

- `~/.claude/` — main instance
- `~/.claude-sdd/` — secondary instance (SDD profile)
- `~/.claude-kat/` — third instance
- `~/.claude-stef/` — fourth instance

**When making config changes (plugins, settings, installed_plugins.json), always check and
apply to ALL FOUR instances.** They share the same plugin source repos but have separate caches,
settings, and plugin install records.

Note 2026-05-16: `~/.claude-kat/`'s `installed_plugins.json` was previously found with
a cross-profile `installPath` pointing at `~/.claude/`'s cache (likely past config drift).
Each profile should use its own `cache/` directory. When updating install records, verify
`installPath` starts with the same profile root as the file itself.

We are in 2026

## Iron Rules

### Memory — Use Codescout, Not Claude Code Memory

Do **not** use Claude Code's built-in memory (the per-profile auto-memory stored
under `<config-dir>/projects/.../memory/`). This machine runs four profiles
(`~/.claude`, `~/.claude-sdd`, `~/.claude-kat`, `~/.claude-stef`), each with its own
memory store, so anything written to one profile's memory is invisible to the other
three and gets lost. Reading from it is fine; do not write durable facts there.

Persist durable facts where every profile and session can reach them:

- **codescout memory** — the `memory()` tool, for project exploration notes and
  system-prompt facts tied to a codebase.
- **codescout trackers** (librarian artifacts) — for structured, ongoing
  tracking (sessions, decisions, bugs, friction logs).

When tempted to "remember" something across sessions, write it to a codescout
memory or the appropriate tracker instead of Claude Code memory.

### Subagent Dispatch — Review Escalation

**For task reviews, prefer escalating to a stronger model (Opus) over the
skill's default mid-tier reviewer — especially for test-rigor / edge-case
coverage on load-bearing code.** Empirically validated 2026-07-07

### Long Tasks — Activate a Monitor, Do Not Poll

When you wait on a long task (a build, a test run, a deploy, any background
command), activate a Monitor on it so the harness notifies you when it
finishes. Do not poll with repeated status checks or short sleeps. Do not
end your turn without a way to be told that the task is done.

<!-- BEGIN operator-rules (generated from docs/trackers/operator-rules.md — do not edit) -->
<!-- rules: OP-1, OP-6 -->

Do not hypothesise but ALWAYS VERIFY. Do not go over code or issues found quickly and assume, but ALWAYS VERIFY!

For architecture design, architecture questions, or architecture brainstorming, invoke the `buddy:architecture-snow-lion` skill BEFORE answering — unless its body is already in this context. Do not improvise the architectural answer.

<!-- END operator-rules -->
