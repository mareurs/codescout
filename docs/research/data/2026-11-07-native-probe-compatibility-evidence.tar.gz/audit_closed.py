"""Independent at-rest closure audit; never launches an actor or model."""
import hashlib
import json
import pathlib
import re
import subprocess
import time

from paid_backend import PaidBackend
import campaign

ROOT = pathlib.Path(__file__).resolve().parent


def main():
    reg = campaign.load(ROOT / "common-registration.json")
    row = reg["arms"][0]
    out = pathlib.Path(row["out"])
    native = campaign.load("/tmp/codescout-bg/455879-a720241d-bg_0000014c.json")
    assert native["state"] == "exited" and native["exit_code"] == 0
    assert native["command"].startswith("python3 -B " + str(ROOT / "run_common.py"))
    campaign.check_hashes(reg["shared_hashes"])
    campaign.check_hashes(row["immutable_hashes"])
    protected = {}
    for hashes in campaign.load(ROOT / "real-inputs-before.json").values():
        campaign.check_hashes(hashes)
        protected.update(hashes)
    assert len(protected) == 5899
    backend = PaidBackend(reg, qualification_plan=reg["scripted_plan"])
    backend.validate_shared(reg)
    receipt = campaign.load(out / "receipt.json")
    campaign.receipt_check(receipt)
    assert receipt["scripted"] is True and receipt["forwarded"] == 0
    assert receipt["unknown_provider_cost"] is False and campaign.amount(receipt["cost_usd"]) == 0
    assert campaign.load(out / "launch.json")["real_credentials_read"] is False
    assert receipt["lifecycle"]["continuations"] == 1 and receipt["lifecycle"]["turns"] == 2
    assert receipt["workflow_completed"] is True
    assert receipt["lifecycle"]["status"] == "settled"
    assert receipt["lifecycle"]["cost_is_final"] is True
    public = backend.valid_public(row, receipt)
    checks = campaign.load(out / "public-classifications.json")["checks"]
    assert [c["classification"]["kind"] for c in checks] == ["functional_failure", "pass"]
    assert [c["exit_code"] for c in checks] == [1, 0]
    candidate = receipt["artifact_evidence"]
    patch = pathlib.Path(candidate["path"])
    assert candidate["complete"] is True and patch.resolve() == (out / "candidate.patch").resolve()
    assert patch.stat().st_size == candidate["bytes"]
    assert campaign.digest(patch) == candidate["sha256"]
    assert campaign.load(out / "background-evidence.json")["complete"] is True
    samples = [json.loads(line) for line in (out / "resource-samples.jsonl").read_text().splitlines()]
    final = campaign.load(out / "supervision-final.json")
    probes = [s for s in samples if "memory_events" in s]
    assert len(samples) == 6 and len(probes) == final["cgroup_probes"] == 5
    assert [s["phase"] for s in samples] == ["initial-host", "before-public", "after-public", "before-public", "after-public", "final"]
    assert final["complete"] is True and final["resource_ok"] is True and not final["errors"]
    for sample in samples:
        assert "error" not in sample
        for key, floor in (("root_free", 80 * 1024**3), ("tmp_free", 4 * 1024**3), ("mem_available", 48 * 1024**3)):
            assert sample["host"][key] >= floor
    ids = set()
    for sample in probes:
        info = sample["profile"]
        ids.add(info["Id"])
        assert info["Id"] == sample["container"] == final["container_id"]
        assert info["Name"] == "/" + final["container_name"]
        assert info["Image"] == candidate["image"]
        assert info["Config"]["Labels"]["codescout.hfa"] == final["container_name"]
        assert info["State"]["Running"] is True and info["State"]["OOMKilled"] is False
        host = info["HostConfig"]
        assert host["Memory"] == 32 * 1024**3 and host["NanoCpus"] == 4 * 10**9
        assert host["NetworkMode"] == "none"
        tmp = set(host["Tmpfs"]["/tmp"].split(","))
        assert {"rw", "exec", "uid=1000", "gid=1000"} <= tmp
        assert {"size=4g", "size=4294967296"} & tmp and "noexec" not in tmp
        assert sample["memory_events"]["oom_kill"] == 0
        assert sample["memory_events"].get("oom_group_kill", 0) == 0
    assert ids == set(final["observed_container_ids"]) == {candidate["container_id"]}
    inspections = [json.loads(line) for line in (out / "native-inspections.jsonl").read_text().splitlines()]
    missing = []
    successes = 0
    names = {campaign.load(p)["name"] for p in out.glob("mcp-launch-*.json")}
    for probe in inspections:
        assert probe["name"] in names and probe["args"] == ["inspect", probe["name"]]
        if probe["exit_code"]:
            pattern = r"(?:error(?: response from daemon)?:\s*)?no such (?:object|container):\s*" + re.escape(probe["name"])
            assert re.fullmatch(pattern, probe["stderr"].strip(), re.IGNORECASE)
            missing.append(probe["stderr"])
        else:
            info = json.loads(probe["stdout"])
            assert len(info) == 1 and info[0]["Id"] in ids
            successes += 1
    assert missing and successes
    daemon = subprocess.run(["docker", "info", "--format", "{{json .ServerVersion}}"], capture_output=True, text=True, timeout=20)
    assert daemon.returncode == 0
    absence = []
    for identity in sorted(ids | names):
        query = subprocess.run(["docker", "inspect", identity], capture_output=True, text=True, timeout=20)
        assert query.returncode != 0
        assert re.fullmatch(r"error: no such object:\s*" + re.escape(identity), query.stderr.strip(), re.IGNORECASE)
        absence.append({"identity": identity, "exit": query.returncode, "stdout": query.stdout, "stderr": query.stderr})
    result = {
        "qualified": True, "paid_admission": False, "unix": time.time(),
        "native_job": native, "source_commit": reg["source_commit"],
        "registration_sha256": campaign.digest(ROOT / "common-registration.json"),
        "source_paths_rehashed": len(reg["shared_hashes"]),
        "common_immutable_hash_records": len(row["immutable_hashes"]),
        "protected_real_unique_paths": len(protected),
        "synthetic_cost_usd": "0", "provider_calls": 0, "credential_reads": 0,
        "continuations": 1, "turns": 2, "public": public, "candidate": candidate,
        "resource_sample_rows": len(samples), "phases": [s["phase"] for s in samples],
        "cgroup_probes": len(probes), "oom_kill": 0, "oom_group_kill": 0,
        "host_minimum_bytes": {key: min(s["host"][key] for s in samples) for key in ("root_free", "tmp_free", "mem_available")},
        "raw_inspections": len(inspections), "normal_absence_inspections": len(missing),
        "successful_inspections": successes, "fresh_daemon_exit": daemon.returncode, "fresh_absence": absence,
        "limits": "At-rest checks of this one synthetic integration; sampled health, no continuous assurance or model efficacy; no private grading.",
    }
    campaign.save(ROOT / "common-closed-audit.json", result, exclusive=True)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
