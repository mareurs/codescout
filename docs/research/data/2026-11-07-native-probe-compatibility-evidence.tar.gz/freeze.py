"""Bind unchanged product gate and fresh private-delta tests to one follow-up."""
import hashlib
import inspect
import json
import pathlib
import shutil
import subprocess
import time
from paid_backend import PaidBackend
import campaign

ROOT=pathlib.Path(__file__).resolve().parent
BASE=ROOT.parent
PRIOR=BASE/"semantic-contract-adapter-20261106"
SOURCE=pathlib.Path("/home/marius/.codex/worktrees/ca35/codescout")
COMMIT="fe8bb4b34f5e7912f9b16c4c0bf1ff73a3a10a23"


def main():
    if (ROOT/"common-registration.json").exists():raise ValueError("do not overwrite a qualification epoch")
    delta=campaign.load(ROOT/"delta-verification.json")
    if (delta.get("qualified") is not True or delta["tested_hashes_before"]!=delta["tested_hashes_after"]
            or delta.get("applied")!=4 or delta.get("killed")!=4 or delta.get("survivors")!=[]
            or len(delta["baselines"])!=3 or any(row["exit_code"] for row in delta["baselines"])):
        raise ValueError("fresh private delta unqualified")
    campaign.check_hashes(delta["tested_hashes_before"])
    head=subprocess.run(["git","rev-parse","HEAD"],cwd=SOURCE,capture_output=True,text=True,check=True).stdout.strip()
    dirty=subprocess.run(["git","status","--porcelain"],cwd=SOURCE,capture_output=True,text=True,check=True).stdout
    if head!=COMMIT or dirty:raise ValueError("unchanged committed product source not proven")
    oldreg=campaign.load(PRIOR/"common-registration.json");campaign.check_hashes(oldreg["shared_hashes"])
    gate_receipt=campaign.load(PRIOR/"gate-final-receipt.json")
    campaign.check_hashes({gate_receipt["native_record"]:gate_receipt["native_record_sha256"],
                          gate_receipt["result"]:gate_receipt["result_sha256"]})
    gate=campaign.load(gate_receipt["result"])
    native=campaign.load(gate_receipt["native_record"])
    if gate["exit_code"]!=0 or gate["source_before"]!=gate["source_after"] or native["state"]!="exited" or native["exit_code"]!=0:
        raise ValueError("original actual product gate invalid")
    campaign.check_hashes(gate["source_before"])
    prior_audit=campaign.load(PRIOR/"common-closed-audit.json")
    if prior_audit["qualified"] is not False or prior_audit["synthetic_cost_usd"]!="0":
        raise ValueError("invalid v1 must remain invalid")
    archive=campaign.load(PRIOR/"archive-receipt.json")
    campaign.check_hashes({archive["archive"]:archive["sha256"]})
    reg=campaign.load(ROOT/"common-registration-unfrozen.json")
    reg["shared_hashes"].update(oldreg["shared_hashes"])
    reg["shared_hashes"].update({str(p):campaign.digest(p) for p in ROOT.glob("*.py")})
    reg["shared_hashes"].update({str(ROOT/name):campaign.digest(ROOT/name) for name in
        ("mutation_candidates.json","delta-verification.json")})
    for p in (PRIOR/"common-registration.json",PRIOR/"common-closed-audit.json",
              PRIOR/"absence-reproduction.json",PRIOR/"archive-receipt.json",
              pathlib.Path(archive["archive"]),PRIOR/"gate-final-receipt.json",
              pathlib.Path(gate_receipt["result"]),pathlib.Path(gate_receipt["native_record"])):
        reg["shared_hashes"][str(p)]=campaign.digest(p)
    for hashes in campaign.load(ROOT/"real-inputs-before.json").values():campaign.check_hashes(hashes)
    reg.update(source_commit=COMMIT,registered_unix=time.time(),repair_admitted=False,
        product_gate={"receipt":str(PRIOR/"gate-final-receipt.json"),"scope":"Unchanged fe8 product only; v1 private gate does not qualify changed v2 private code"},
        private_delta={"result":str(ROOT/"delta-verification.json"),"fresh_tests":[4,12,19],"mutations_killed":4},
        prior_invalid_qualification={"root":str(PRIOR),"qualified":False,"archive_sha256":archive["sha256"]},
        expected_inspection_diagnostics="Complete raw native-inspections.jsonl with exact named absence recognition")
    backend=PaidBackend(reg,qualification_plan=reg["scripted_plan"])
    if pathlib.Path(inspect.getsourcefile(backend.supervisor_factory)).resolve()!=ROOT/"supervision.py":
        raise ValueError("wrong supervisor factory source")
    backend.validate_shared(reg)
    for row in reg["arms"]:
        campaign.check_hashes(row["immutable_hashes"]);campaign.check_hashes(row["writable_hashes"])
        backend.validate(row)
    campaign.resource_check(backend.resources(reg["arms"][0]))
    for i,(path,expected) in enumerate(reg["shared_hashes"].items()):
        dst=ROOT/"frozen-source"/str(i)/pathlib.Path(path).name
        dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,dst)
        if campaign.digest(dst)!=expected:raise ValueError("frozen source copy differs")
    campaign.check_hashes(reg["shared_hashes"])
    campaign.save(ROOT/"common-registration.json",reg,exclusive=True)
    campaign.save(ROOT/"freeze-receipt.json",{"product_source_commit":COMMIT,
        "shared_bound_paths":len(reg["shared_hashes"]),"registration_sha256":campaign.digest(ROOT/"common-registration.json"),
        "fresh_private_delta_only":True,"paid_admission":False})
    print(json.dumps({"frozen":True,"shared_paths":len(reg["shared_hashes"]),"paid_admission":False}))


if __name__=="__main__":main()
