"""Two offline consistency counterexamples on disposable fixture campaigns only."""
import json
import pathlib
import campaign
from test_campaign import CampaignTests,save,load,digest

def main():
    result=[]
    for scenario in ("incoherent_workflow_flag","registration_and_admission_replaced"):
        case=CampaignTests();case.setUp()
        try:
            if scenario=="incoherent_workflow_flag":
                original=case.backend.launch
                def launch(row,reserve,cli):
                    receipt=original(row,reserve,cli)
                    receipt["workflow_completed"]=False
                    save(pathlib.Path(row["out"])/"receipt.json",receipt)
                    return receipt
                case.backend.launch=launch
            else:
                def changed(index):
                    if index==0:
                        case.reg["prior_usd"]="0"
                        case.bind()
                case.backend.change=changed
            try:
                case.invoke();observed="accepted_all_six"
            except Exception as exc:
                observed="rejected:"+type(exc).__name__+":"+str(exc)
            row={"scenario":scenario,"observed":observed,"external_fixture_calls":len(case.backend.launches)}
            if (case.root/"campaign-started.json").exists():
                row["start_registration_sha256"]=load(case.root/"campaign-started.json")["registration_sha256"]
                row["final_registration_sha256"]=digest(case.regfile)
            result.append(row)
        finally:case.doCleanups()
    output=pathlib.Path(__file__).parent/"consistency-probe.json"
    if output.exists():raise ValueError("Refuse overwrite")
    output.write_text(json.dumps(result,indent=2)+"\n");print(json.dumps(result,indent=2))
if __name__=="__main__":main()
