import copy
import json
import pathlib
import tempfile
import unittest
import campaign
import real_backend

class ReadonlyTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=pathlib.Path(self.tmp.name);self.source=self.root/"readonly";self.source.mkdir()
        (self.source/"data").write_bytes(b"qualified")
        (self.source/"link").symlink_to("data")
        self.arm=self.root/"arm";self.arm.mkdir()
        campaign.save(self.arm/"mcp-native-argv.json",["docker","run","--mount","type=bind,src="+str(self.source)+",dst=/bench/bin,readonly"])
        self.manifest={"/bench/bin":{"data":{"sha256":campaign.digest(self.source/"data")},"link":{"link":"data","resolved_sha256":campaign.digest(self.source/"data")}}}
        campaign.save(self.root/"readonly.json",self.manifest)
        self.reg={"readonly_manifest":str(self.root/"readonly.json"),"arms":[{"out":str(self.arm)}]}
    def test_complete_real_directory_and_link_inputs(self):
        result=real_backend.verify_readonly(self.reg)
        self.assertEqual(result,{"unique_source_mount_pairs":1,"records_by_destination":{"/bench/bin":2}})
    def test_unlisted_file_rejected(self):
        (self.source/"extra").write_bytes(b"extra")
        with self.assertRaises(ValueError):real_backend.verify_readonly(self.reg)
    def test_same_target_bytes_but_changed_link_rejected(self):
        (self.source/"link").unlink();(self.source/"link").symlink_to(str(self.source/"data"))
        with self.assertRaises(ValueError):real_backend.verify_readonly(self.reg)
    def test_changed_resolved_bytes_rejected(self):
        (self.source/"data").write_bytes(b"wrong")
        with self.assertRaises(ValueError):real_backend.verify_readonly(self.reg)
    def test_mount_must_still_be_readonly(self):
        campaign.save(self.arm/"mcp-native-argv.json",["docker","run","--mount","type=bind,src="+str(self.source)+",dst=/bench/bin"])
        with self.assertRaises(ValueError):real_backend.verify_readonly(self.reg)

if __name__=="__main__":unittest.main()
