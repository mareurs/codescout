"""Read-only calibration against four already closed paid receipts; no new launch."""
import hashlib
import json
import pathlib
import sys
from decimal import Decimal
ROOT=pathlib.Path(__file__).parent
BASE=ROOT.parent
SOURCE=pathlib.Path("/home/marius/work/claude/codescout/.worktrees/semantic-contract-runtime-01a15ca9")
sys.path[:0]=[str(SOURCE/"tools/agent_lifecycle"),str(SOURCE/"tools"),str(SOURCE/"tools/hint_authority_pilot"),str(SOURCE/"tools/hint_authority_workflow")]
import driver
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    out=ROOT/"closed-receipt-calibration.json"
    if out.exists():raise ValueError("Refuse overwrite")
    old=BASE/"external-matched-repairs-20261105"
    reg=json.loads((old/"registration.json").read_text())
    rows=[];protected={}
    for task,effort in reg["repair_order"]:
        case=old/(task+"--"+effort)
        for name in ("stream.jsonl","stdout.json","receipt.json","cost-reconciled.json"):
            protected[str(case/name)]=sha(case/name)
        receipt=json.loads((case/"receipt.json").read_text())
        observed=driver.reconcile(case,receipt,Decimal(reg["repair_reserve_usd_each"]))
        registered=Decimal(json.loads((case/"cost-reconciled.json").read_text())["cost_usd"])
        if observed!=registered:raise ValueError("Cost calibration mismatch")
        rows.append({"task":task,"effort":effort,"observed_usd":str(observed),"registered_usd":str(registered),"matched":True})
    for path,digest in protected.items():
        if sha(pathlib.Path(path))!=digest:raise ValueError("Original receipt drift")
    result={"observed_closed_receipts":rows,"all_four_match":True,"original_file_hashes":protected,
            "driver_source":str(SOURCE/"tools/hint_authority_workflow/driver.py"),
            "driver_sha256":sha(SOURCE/"tools/hint_authority_workflow/driver.py"),
            "provider_calls":0,"old_workflow_or_grade_verdict_changed":False,
            "limits":"Read-only cost reconciliation overlap only; no provider-budget-enforcement or new paid-adapter claim."}
    out.write_text(json.dumps(result,indent=2)+"\n");print(json.dumps({k:v for k,v in result.items() if k!="original_file_hashes"},indent=2))
if __name__=="__main__":main()
