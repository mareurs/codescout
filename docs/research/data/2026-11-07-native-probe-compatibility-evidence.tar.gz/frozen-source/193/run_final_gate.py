"""Post-fix targeted suites plus full gate, all bound to unchanged source bytes."""
import json
import pathlib
import subprocess
import sys
import time

from paid_backend import campaign

ROOT=pathlib.Path(__file__).resolve().parent
SOURCE=pathlib.Path("/home/marius/.codex/worktrees/ca35/codescout")


def inputs():
    result={}
    for name in ("src","crates","tests","scripts","tools/agent_lifecycle",
                 "tools/hint_authority_pilot","tools/hint_authority_workflow","tools/hint_authority_resume"):
        for path in (SOURCE/name).rglob("*"):
            if path.is_file() and not path.is_symlink() and "__pycache__" not in path.parts:
                result[str(path)]=campaign.digest(path)
    for name in ("Cargo.toml","Cargo.lock","CLAUDE.md"):
        path=SOURCE/name;result[str(path)]=campaign.digest(path)
    for name in ("supervision.py","paid_backend.py","test_adapter_supervision.py","test_paid_backend.py",
                 "run_final_gate.py","freeze_common.py","run_common.py","test_qualification.py"):
        path=ROOT/name;result[str(path)]=campaign.digest(path)
    return result


def main():
    preliminary=campaign.load("/tmp/codescout-bg/455879-a720241d-bg_0000013e.json")
    if preliminary.get("state")!="exited" or preliminary.get("exit_code")!=0:
        raise ValueError("preliminary gate did not close successfully; inspect before another run")
    before=inputs();rows=[];started=time.time()
    commands=[("lifecycle",[sys.executable,"-B","-m","unittest","discover","-s","tools/agent_lifecycle"]),
              ("transport",[sys.executable,"-B","-m","unittest","discover","-s","tools/hint_authority_pilot"]),
              ("supervisor",[sys.executable,"-B","-m","unittest","discover","-s",str(ROOT),"-p","test_adapter_supervision.py"]),
              ("backend",[sys.executable,"-B","-m","unittest","discover","-s",str(ROOT),"-p","test_paid_backend.py"]),
              ("qualification",[sys.executable,"-B","-m","unittest","discover","-s",str(ROOT),"-p","test_qualification.py"]),
              ("full_gate",["./scripts/gate.sh"])]
    for name,argv in commands:
        path=ROOT/("final-"+name+".log")
        with path.open("wb") as stream:
            proc=subprocess.run(argv,cwd=SOURCE,stdout=stream,stderr=subprocess.STDOUT)
        rows.append({"suite":name,"command":argv,"exit_code":proc.returncode,
                     "log":str(path),"log_sha256":campaign.digest(path)})
        if proc.returncode:break
    after=inputs()
    code=0 if len(rows)==len(commands) and all(row["exit_code"]==0 for row in rows) and before==after else 1
    campaign.save(ROOT/"gate-final-result.json",{"started_unix":started,"finished_unix":time.time(),
        "exit_code":code,"source_before":before,"source_after":after,"suites":rows})
    print(json.dumps({"exit_code":code,"suites":[(row["suite"],row["exit_code"]) for row in rows]}))
    raise SystemExit(code)


if __name__=="__main__":main()
