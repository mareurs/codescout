"""Explicit prospective adjudication; the raw grader and frozen records stay unchanged."""
import re

import audit_reparse as audit
import multilang_grade as grade
import multilang_tasks as tasks

POLICY_VERSION = "semantic-contract-v1"

def invalid(message, raw=None):
    return {"policy_version": POLICY_VERSION, "valid": False, "pass": False,
            "kind": "measurement_invalid", "error": message, "raw": raw}


def runtime_issue(runtime):
    if not isinstance(runtime, dict):
        return "runtime proof missing"
    if runtime.get("complete") is not True or runtime.get("resource_ok") is not True:
        return "runtime evidence incomplete or host resource floor failed"
    if type(runtime.get("cgroup_probes")) is not int or runtime["cgroup_probes"] < 2:
        return "initial/final cgroup observations missing"
    if type(runtime.get("oom_kill")) is not int or runtime["oom_kill"] != 0:
        return "OOM state unknown or nonzero"
    if runtime.get("errors") != []:
        return "runtime observation error"
    return None


def diagnostic_lines(log):
    # Reuse the source-bound Rust ANSI normalizer; ignore compiler source gutters.
    return [line.strip() for line in audit._ANSI.sub("", log).splitlines()
            if not re.match(r"^\s*(?:\d+\s*\||\|)", line)]


def infrastructure_issue(log):
    lines = diagnostic_lines(log)
    signal = grade.toolchain_crash("\n".join(lines))
    if signal:
        return "process-fatal diagnostic: " + signal
    for line in lines:
        if re.search(r"(?:^|:\s)(?:No space left on device|Disk quota exceeded)(?: \(os error \d+\))?$", line):
            return "storage diagnostic: " + line
        if re.search(r"(?:^|\s)/tmp/\S+:\s+Permission denied(?:\s|$)", line):
            return "temporary execution diagnostic: " + line
    return None


def compiler_diagnostic(log):
    """Require a top-level rustc code, or a header with adjacent source context.

    Test stdout can contain arbitrary error fields. Retain physical indentation;
    a naked error: prefix or Cargo test summary is not compiler provenance.
    """
    lines = audit._ANSI.sub("", log).splitlines()
    for i, line in enumerate(lines):
        if re.match(r"^error\[E\d+\]: ", line):
            return line
        if re.match(r"^error: ", line) and any(
                re.match(r"^\s*(?:-->\s+\S+:\d+:\d+|\d+\s*\|)", context)
                for context in lines[i + 1:i + 5]):
            return line
    return None



def classify_public(log, exit_code, *, runtime, truncated=False):
    issue = runtime_issue(runtime) or infrastructure_issue(log)
    if issue or truncated or type(exit_code) is not int or exit_code < 0:
        return invalid(issue or "capture incomplete or process exit unknown/fatal")
    return {"policy_version": POLICY_VERSION, "valid": True, "pass": exit_code == 0,
            "kind": "pass" if exit_code == 0 else "functional_failure", "error": None}

def adjudicate_private(raw, full_evidence, record, bundle, *, log, runtime):
    """Adjudicate a completed private grade; never rewrite its log or raw receipt."""
    issue = runtime_issue(runtime)
    if issue:
        return invalid(issue, raw)
    try:
        if (type(raw.get("pass")) is not bool or raw.get("oom_killed") is not False
                or raw.get("container_removed") is not True or raw.get("error")
                or raw.get("infra") is not None):
            return invalid("raw grader fault or unknown terminal metadata", raw)
        steps = full_evidence["steps"]
        expected_steps = (["grade:rebuild"] if any(
            isinstance(cmd, str) and cmd.strip() for cmd in record.get("rebuild_cmds", [])) else [])
        expected_steps += [f"grade:test[{i}]" for i in range(len(record["test_cmds"]))]
        expected_steps += [f"grade:print[{i}]" for i in range(len(record["print_cmds"]))]
        if not record["test_cmds"] or not record["print_cmds"] or [s["name"] for s in steps] != expected_steps:
            return invalid("full step evidence missing or out of order", raw)
        for step in steps:
            code = step["returncode"]
            if not isinstance(step.get("tail"), str):
                return invalid("full step tail missing or malformed", raw)
            if type(code) is not int or code < 0 or step.get("truncated"):
                return invalid("step process/capture invalid", raw)
            if step["name"].startswith("grade:print[") and code != 0:
                return invalid("print command failed; log is not qualified", raw)
        combined = log + "\n" + "\n".join(s.get("tail", "") for s in steps)
        issue = infrastructure_issue(combined)
        if issue:
            return invalid(issue, raw)
        f2p, p2p = tasks.expected_sets(record, bundle)
        expected = f2p + p2p
        if not f2p or len(set(expected)) != len(expected):
            return invalid("expected set empty or ambiguous", raw)
        observed = grade.run_parser(record["log_parser"], log)
        original = grade.verdict(observed, f2p, p2p)
        for key, value in original.items():
            if (type(raw.get(key)) is not type(value) or raw.get(key) != value
                    or full_evidence.get(key) != value):
                return invalid("raw verdict contradicts parser/evidence", raw)
        result = audit.reparse(record, log, f2p, p2p)
        if result["original"] != original:
            return invalid("audit raw verdict disagrees", raw)
        adjusted = dict(observed)
        for recovered in result["recovered"]:
            adjusted[recovered["key"]] = recovered["status"]
        statuses = {key: adjusted[key] for key in expected if key in adjusted}
        if any(value not in ("pass", "fail", "skip") for value in statuses.values()):
            return invalid("unknown expected status", raw)
        compile_failure = any(
            step["returncode"] != 0 and compiler_diagnostic(step.get("tail", "") + "\n" + log)
            for step in steps if not step["name"].startswith("grade:print["))
        failed_rebuild = any(s["name"] == "grade:rebuild" and s["returncode"] != 0 for s in steps)
        if failed_rebuild and not compile_failure:
            return invalid("rebuild failed without a classified compiler diagnostic", raw)
        if result["adjusted"]["missing"] and not compile_failure:
            return invalid("expected statuses missing without compiler evidence", raw)
        passed = result["adjusted"]["pass"] and not compile_failure
        return {"policy_version": POLICY_VERSION, "valid": True, "pass": passed,
                "kind": "compile_failure" if compile_failure else ("pass" if passed else "test_failure"),
                "error": None, "raw": original, "adjusted": result["adjusted"],
                "statuses": statuses, "recovered": result["recovered"],
                "raw_parsed_keys": len(observed)}
    except (KeyError, TypeError, ValueError, grade.ParserError) as exc:
        return invalid("policy evidence refused: " + str(exc), raw)
