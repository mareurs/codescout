"""Build one NEW unstarted disposable qualification; never launches or reads credentials."""
import copy
import hashlib
import importlib.util
import json
import pathlib
import shutil
import time

ROOT=pathlib.Path(__file__).resolve().parent
BASE=ROOT.parent
SOURCE=pathlib.Path("/home/marius/.codex/worktrees/ca35/codescout")
OLD_SOURCE=pathlib.Path("/home/marius/work/claude/codescout/.worktrees/semantic-contract-runtime-01a15ca9")
ACTOR=pathlib.Path("/tmp/cs-native-probe-01a15ca9-20261107")
POLICY=pathlib.Path("/home/marius/work/claude/codescout.worktrees/grader-validity/tools/setup-ab-eval/grade_policy.py")


def load(path):return json.loads(pathlib.Path(path).read_text())
def save(path,value):
    path=pathlib.Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2)+"\n")
def digest(path):return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def main():
    out=ROOT/"common"
    if out.exists() or ACTOR.exists() or (ROOT/"common-registration.json").exists():
        raise ValueError("one-shot common qualification already prepared")
    old=load(BASE/"semantic-contract-controller-20261106/post-review/registration.json")
    for path,expected in old["shared_hashes"].items():
        if digest(path)!=expected:raise ValueError("prior shared source drift: "+path)
    for row in old["arms"]:
        for path,expected in {**row["immutable_hashes"],**row["writable_hashes"]}.items():
            if digest(path)!=expected:raise ValueError("real prepared population drift: "+path)
        if any((pathlib.Path(row["out"])/name).exists() for name in ("started.json","launch.json","receipt.json")):
            raise ValueError("real repair already started")
    original=pathlib.Path(old["arms"][0]["out"])
    cfg=load(original/"prepared.json")
    frozen=load(BASE/"semantic-contract-pilot-20261106/prompt-inputs-registration.json")
    snapshot=pathlib.Path(frozen["projects"][old["arms"][0]["task"]]["runtime_snapshot_manifest"]).parent
    manifest=load(snapshot/"manifest.json")
    spec=importlib.util.spec_from_file_location("frozen_semantic_prepare",OLD_SOURCE/"tools/agent_lifecycle/semantic_prepare.py")
    prep=importlib.util.module_from_spec(spec);spec.loader.exec_module(prep)
    cloned=prep.clone_snapshot(snapshot,out,manifest)
    save(out/"clone-proof.json",cloned)
    ACTOR.mkdir()
    for name in ("CLAUDE.md","AGENTS.md"):
        shutil.copyfile(original/"actor-context"/name,ACTOR/name)
    native=prep.rewrite_native(load(original/"mcp-native-argv.json"),out,manifest["projects"],"cs-adapter-smoke-01a15ca9")
    save(out/"mcp-native-argv.json",native)
    # A disposable /tmp sentinel causes a genuine first public failure and then a pass.
    # It does not read private tests or alter the actor task prompt.
    command=("if test -f /tmp/semantic-adapter-common-once; then printf 'public check passed\\n'; "
             "else touch /tmp/semantic-adapter-common-once; "
             "printf 'assertion failed: first public check requests another turn\\n'; exit 1; fi")
    cfg.update(actor=str(ACTOR),checks=[{"id":"common_public_feedback","command":command}],
               timeout_s=300,check_timeout_s=30,max_continuations=2)
    cfg["files"]={str(p):digest(p) for p in (out/"mcp-native-argv.json",pathlib.Path(cfg["global_rules"]),
        pathlib.Path(cfg["cli"]),ACTOR/"CLAUDE.md",ACTOR/"AGENTS.md")}
    save(out/"prepared.json",cfg)
    row=copy.deepcopy(old["arms"][0]);row.update(out=str(out),arm_id="common-low-native-probe-compatibility-v2",
        immutable_hashes={**cfg["files"],str(out/"prepared.json"):digest(out/"prepared.json")},
        writable_hashes={str(out/relative):proof["sha256"] for relative,proof in manifest["files"].items()
                         if relative.startswith(("knowledge/","member-state/","native-home/"))})
    reg=copy.deepcopy(old);reg.update(qualified_source=str(SOURCE),public_policy=str(POLICY),
        mode="qualification",arms=[row],stage="native-probe-compatibility-v2-unstarted")
    # This initial set is extended/frozen AFTER review, gate and source commit, BEFORE launch.
    reg["shared_hashes"].update({str(p):digest(p) for group in ("agent_lifecycle","hint_authority_pilot","hint_authority_workflow")
        for p in (SOURCE/"tools"/group).glob("*.py")})
    reg["shared_hashes"].update({str(ROOT/name):digest(ROOT/name)
        for name in ("supervision.py","paid_backend.py","prepare_common.py")})
    reg["shared_hashes"].update({str(p):digest(p) for p in POLICY.parent.glob("*.py")})
    reg["scripted_plan"]=[["Skill",{"skill":"codescout-companion:reconnaissance"}],
        ["mcp__codescout__read_file",{"path":".codescout/system-prompt.md","force":True}],
        ["mcp__codescout__symbols",{"path":"src/main.rs","name":"main","include_body":True}]]
    reg["registered_unix"]=time.time()
    reg["question"]="One newly registered compatibility follow-up after invalid v1: recognize stale missing-container diagnostics, retain raw inspections, then prove functional feedback/continuation/final native health and cleanup. No paid model repair."
    save(ROOT/"common-registration-unfrozen.json",reg)
    save(ROOT/"real-inputs-before.json",{row["arm_id"]:{**row["immutable_hashes"],**row["writable_hashes"]} for row in old["arms"]})
    print(json.dumps({"common":str(out),"actor":str(ACTOR),"launch_admitted":False,"provider_calls":0}))


if __name__=="__main__":main()
