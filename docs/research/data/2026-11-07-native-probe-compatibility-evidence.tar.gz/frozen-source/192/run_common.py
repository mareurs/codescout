"""ONE actual-CLI scripted common qualification; no paid activation/retry."""
import json
import pathlib
import subprocess
import sys
import time
from decimal import Decimal

from paid_backend import PaidBackend
import campaign

ROOT=pathlib.Path(__file__).resolve().parent
BASE=ROOT.parent


def no_upstream(*args,**kwargs):
    raise AssertionError("qualification forbids provider contact")


def audit_wire(reg,row):
    verifier=BASE/"semantic-contract-wire-20261106/control-v3-offline.py"
    program = """
import importlib.util,json,pathlib,sys
spec=importlib.util.spec_from_file_location('frozen_wire_audit',sys.argv[1])
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
reg=json.loads(pathlib.Path(sys.argv[2]).read_text());row=reg['arms'][0]
cfg=json.loads((pathlib.Path(row['out'])/'prepared.json').read_text())
protocol=pathlib.Path(sys.argv[3]).read_text()
print(json.dumps(module.verify_wire(pathlib.Path(row['out']),row,cfg,protocol)))
"""
    result=subprocess.run([sys.executable,"-B","-c",program,str(verifier),
        str(ROOT/"common-registration.json"),str(BASE/"semantic-contract-pilot-20261106/protocol.txt")],
        capture_output=True,text=True,timeout=60)
    campaign.save(ROOT/"common-wire-audit-process.json",{"exit_code":result.returncode,"stdout":result.stdout,"stderr":result.stderr})
    if result.returncode:raise ValueError("common wire audit failed")
    return json.loads(result.stdout)


def reconcile_common(backend, row, receipt):
    try:
        backend.reconcile(row,receipt,Decimal("20"))
    except ValueError as exc:
        rejection=str(exc)
    else:
        raise ValueError("scripted fixture must remain rejected by paid reconciliation")
    calibration=campaign.load(BASE/"semantic-contract-controller-20261106/closed-receipt-calibration.json")
    campaign.check_hashes(calibration["original_file_hashes"])
    old=BASE/"external-matched-repairs-20261105"
    registration=campaign.load(old/"registration.json")
    allowance=Decimal(registration["repair_reserve_usd_each"])
    observed=[]
    for reference in calibration["observed_closed_receipts"]:
        out=old/(reference["task"]+"--"+reference["effort"])
        paid=campaign.load(out/"receipt.json")
        actual=backend.reconcile({"out":str(out)},paid,allowance)
        if actual!=Decimal(reference["registered_usd"]):
            raise ValueError("concrete paid reconciliation calibration differs")
        observed.append({"task":reference["task"],"effort":reference["effort"],
                         "observed_usd":str(actual),"registered_usd":reference["registered_usd"]})
    campaign.check_hashes(calibration["original_file_hashes"])
    result={"scripted_receipt_rejected":True,"scripted_rejection":rejection,
            "closed_paid_receipts":observed,"protected_old_files":len(calibration["original_file_hashes"]),
            "new_paid_calls":0,"limits":"At-rest cost overlap, not a new paid run or old outcome change."}
    campaign.save(ROOT/"common-reconciliation.json",result)
    return result

def main():
    registration=ROOT/"common-registration.json"
    reg=campaign.load(registration);epoch={str(registration):campaign.digest(registration)}
    campaign.check_hashes(reg["shared_hashes"])
    for hashes in campaign.load(ROOT/"real-inputs-before.json").values():campaign.check_hashes(hashes)
    if reg.get("mode")!="qualification" or reg.get("repair_admitted") is not False or len(reg["arms"])!=1:
        raise ValueError("wrong qualification mode")
    row=reg["arms"][0];out=pathlib.Path(row["out"])
    if any((out/name).exists() for name in ("started.json","launch.json","receipt.json")):
        raise ValueError("existing common attempt; preserve/reconcile, never retry")
    backend=PaidBackend(reg,qualification_plan=reg["scripted_plan"])
    # Fail closed even if a future edit accidentally routes a scripted request upstream.
    backend.external.transport.Proxy.upstream=no_upstream
    before=backend.resources(row);campaign.resource_check(before)
    campaign.save(ROOT/"common-attempt.json",{"registered_sha256":epoch[str(registration)],"unix":time.time(),
        "provider_forbidden":True,"real_credentials_forbidden":True,"retry_allowed":False},exclusive=True)
    receipt=None
    try:
        receipt=backend.launch(row,Decimal("20"),Decimal("19"))
        reconciliation=reconcile_common(backend,row,receipt)
        campaign.receipt_check(receipt)
        if receipt.get("scripted") is not True or receipt.get("forwarded")!=0 or Decimal(receipt["cost_usd"])!=0:
            raise ValueError("common fixture cost/provider boundary failed")
        lifecycle=receipt["lifecycle"]
        if lifecycle["continuations"]!=1 or lifecycle["turns"]!=2 or receipt["workflow_completed"] is not True:
            raise ValueError("genuine first-failure/second-pass same-session qualification did not occur")
        public=backend.valid_public(row,receipt)
        if public["rounds"]!=2:raise ValueError("public round count differs")
        evidence=campaign.load(out/"public-classifications.json")["checks"]
        if [r["classification"]["kind"] for r in evidence]!=["functional_failure","pass"]:
            raise ValueError("public policy sequence differs")
        cleanup=backend.cleanup(row)
        wire=audit_wire(reg,row)
        for hashes in campaign.load(ROOT/"real-inputs-before.json").values():campaign.check_hashes(hashes)
        campaign.check_hashes(reg["shared_hashes"]);campaign.check_hashes(epoch)
        backend.validate_shared(reg)
        after=backend.resources(row);campaign.resource_check(after)
        proof=campaign.load(out/"supervision-final.json")
        if proof.get("complete") is not True or proof["oom_kill"]!=0:raise ValueError("runtime proof incomplete")
        samples=[json.loads(line) for line in (out/"resource-samples.jsonl").read_text().splitlines()]
        result={"qualified":True,"source_commit":reg["source_commit"],
            "common_registration_sha256":epoch[str(registration)],"unix":time.time(),
            "provider_calls":0,"credential_reads":0,"synthetic_cost_usd":"0",
            "same_session_continuations":1,"turns":2,"public":public,"runtime":proof,
            "resource_sample_rows":len(samples),"resource_before":before,"resource_after":after,
            "cleanup":cleanup,"wire":wire,"reconciliation":reconciliation,"paid_admission":False,
            "scope":"One NEW actual CLI scripted common adapter/continuation/runtime/cleanup fixture; no model repair efficacy."}
        campaign.save(ROOT/"common-result.json",result,exclusive=True)
        print(json.dumps(result,indent=2))
    except BaseException as exc:
        campaign.save(ROOT/"common-stopped.json",{"type":type(exc).__name__,"message":str(exc),
            "receipt_saved":(out/"receipt.json").exists(),"retry_allowed":False,"paid_admission":False,
            "cost_state":"read preserved receipt; do not infer zero from exception"})
        raise


if __name__=="__main__":main()
