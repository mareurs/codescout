import copy
import json
import pathlib
import subprocess
import sys
import tempfile
import time
import types
import unittest
from unittest.mock import patch

import supervision

POLICY = pathlib.Path("/home/marius/work/claude/codescout.worktrees/grader-validity/tools/setup-ab-eval/grade_policy.py")
CID = "c"*64
IMAGE = "sha256:"+"a"*64
NAME = "hfa-native-"+"b"*32
HEALTHY = {"root_free":100*1024**3,"tmp_free":10*1024**3,"mem_available":80*1024**3}


class Docker:
    def __init__(self):
        self.calls=[]
        self.info={"Id":CID,"Image":IMAGE,"Name":"/"+NAME,
            "Config":{"Labels":{"codescout.hfa":NAME}},
            "HostConfig":{"Memory":32*1024**3,"NanoCpus":4*10**9,"NetworkMode":"none",
                "Tmpfs":{"/tmp":"rw,exec,size=4g,uid=1000,gid=1000"}},
            "State":{"Running":True,"OOMKilled":False}}
        self.events="low 0\nhigh 0\nmax 0\noom 0\noom_kill 0\noom_group_kill 0\n"
    def __call__(self,args):
        self.calls.append(args)
        if args[0]=="inspect": return types.SimpleNamespace(returncode=0,stdout=json.dumps([self.info]),stderr="")
        if args[0]=="exec": return types.SimpleNamespace(returncode=0,stdout=self.events,stderr="")
        if args[0]=="kill": return types.SimpleNamespace(returncode=0,stdout=CID,stderr="")
        raise AssertionError(args)


class SupervisionTests(unittest.TestCase):
    def prepare(self,root,*,host=None,docker=None,interval=100):
        docker=docker or Docker()
        (root/("mcp-launch-"+NAME+".json")).write_text(json.dumps({"name":NAME}))
        obj=supervision.Supervisor(POLICY,host=host or (lambda:copy.deepcopy(HEALTHY)),docker=docker,interval=interval)
        server=types.SimpleNamespace()
        obj.bind(out=root,image=IMAGE,server=server)
        self.addCleanup(obj.stop_monitor)
        return obj,docker,server

    def test_host_floors_are_independently_enforced_before_client(self):
        for key in HEALTHY:
            with self.subTest(key=key),tempfile.TemporaryDirectory() as d:
                host=dict(HEALTHY);host[key]=0
                obj=supervision.Supervisor(POLICY,host=lambda:host,docker=Docker())
                with self.assertRaisesRegex(ValueError,"resource floor"):
                    obj.bind(out=pathlib.Path(d),image=IMAGE,server=types.SimpleNamespace())
                obj.stop_monitor()

    def test_native_identity_and_exact_profile_faults_never_kill_unverified_cid(self):
        for field,value in [("Image","sha256:wrong"),("Id","d"*64)]:
            with self.subTest(field=field),tempfile.TemporaryDirectory() as d:
                docker=Docker();docker.info[field]=value
                obj,_,_=self.prepare(pathlib.Path(d),docker=docker)
                if field=="Id":
                    # The first verified id may be any immutable valid CID; switching is forbidden.
                    obj.before_public();docker.info["Id"]=CID
                with self.assertRaises(ValueError):obj.before_public()
                killed=[a for a in docker.calls if a[0]=="kill"]
                self.assertFalse(killed if field=="Image" else any(a[1]==CID for a in killed))

    def test_each_actor_profile_dimension_is_required(self):
        cases=[("Memory",8*1024**3),("NanoCpus",2*10**9),("NetworkMode","bridge"),
               ("Tmpfs",{"/tmp":"rw,noexec,size=4g"})]
        for key,value in cases:
            with self.subTest(key=key),tempfile.TemporaryDirectory() as d:
                docker=Docker();docker.info["HostConfig"][key]=value
                obj,_,_=self.prepare(pathlib.Path(d),docker=docker)
                with self.assertRaisesRegex(ValueError,"profile"):obj.before_public()
                self.assertFalse(any(a[0]=="kill" for a in docker.calls))

    def test_unknown_cgroup_and_group_oom_stop_verified_worker(self):
        for events in ["oom 0\n", "oom_kill -1\n", "oom_kill 0\noom_group_kill 1\n"]:
            with self.subTest(events=events),tempfile.TemporaryDirectory() as d:
                obj,docker,_=self.prepare(pathlib.Path(d))
                docker.events=events
                with self.assertRaises(ValueError):obj.before_public()
                self.assertIn(["kill",CID],docker.calls)
                self.assertTrue(obj.errors)

    def test_public_policy_distinguishes_real_failure_from_infrastructure(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);obj,_,_=self.prepare(root)
            obj.before_public()
            log=root/"public.log";log.write_text("assertion failed: expected 2 got 1\n")
            obj.after_public("cargo test",log,1)
            result=json.loads((root/"public-classifications.json").read_text())["checks"][-1]
            self.assertTrue(result["classification"]["valid"])
            self.assertEqual(result["classification"]["kind"],"functional_failure")
            log.write_text("rustc: fatal error: terminated with signal 7 [Bus error]\n")
            with self.assertRaisesRegex(ValueError,"public verification invalid"):
                obj.after_public("cargo test",log,101)

    def test_complete_bounded_capture_and_final_sample_are_mandatory(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);obj,docker,_=self.prepare(root)
            obj.before_public()
            log=root/"public.log";log.write_text("ok\n")
            obj.after_public("check",log,0)
            with patch.object(supervision,"MAX_LOG_BYTES",2):
                with self.assertRaisesRegex(ValueError,"capture"):
                    obj.after_public("check",log,0)
            with self.assertRaises(ValueError):obj.finish()
            proof=json.loads((root/"supervision-final.json").read_text())
            self.assertFalse(proof["complete"])
            self.assertGreaterEqual(proof["cgroup_probes"],2)
            self.assertIn(["kill",CID],docker.calls)

    def test_healthy_finish_records_final_native_probe_before_cleanup(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);obj,_,server=self.prepare(root)
            obj.before_public();log=root/"public.log";log.write_text("ok")
            obj.after_public("check",log,0);obj.finish()
            proof=json.loads((root/"supervision-final.json").read_text())
            self.assertTrue(proof["complete"])
            self.assertEqual(proof["container_id"],CID)
            self.assertGreaterEqual(proof["cgroup_probes"],3)
            server.request_guard()
            self.assertEqual(json.loads((root/"resource-samples.jsonl").read_text().splitlines()[-1])["phase"],"final")

    def test_periodic_fault_reaps_only_actual_observed_process(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);host=dict(HEALTHY)
            obj,docker,server=self.prepare(root,host=lambda:dict(host),interval=.02)
            argv=[sys.executable,"-c","import time;time.sleep(30)"]
            (root/"launch.json").write_text(json.dumps({"argv":argv}))
            proc=subprocess.Popen(argv,start_new_session=True)
            peer=subprocess.Popen(argv,start_new_session=True)
            try:
                obj.client_started(proc)
                obj.before_public()
                host["tmp_free"]=0
                deadline=time.monotonic()+2
                while proc.poll() is None and time.monotonic()<deadline:time.sleep(.01)
                self.assertIsNotNone(proc.poll())
                self.assertIsNone(peer.poll())
                self.assertIn(["kill",CID],docker.calls)
                with self.assertRaises(ValueError):server.request_guard()
            finally:
                for child in (proc,peer):
                    if child.poll() is None:child.kill()
                    child.wait()

    def test_fabricated_process_object_cannot_grant_kill_ownership(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);obj,_,_=self.prepare(root)
            (root/"launch.json").write_text(json.dumps({"argv":["fake"]}))
            with self.assertRaisesRegex(ValueError,"Popen"):
                obj.client_started(types.SimpleNamespace(pid=1,args=["fake"]))
    def test_wrong_or_missing_native_label_is_rejected_without_cid_ownership(self):
        for labels in ({},{"codescout.hfa":"wrong-owner"}):
            with self.subTest(labels=labels),tempfile.TemporaryDirectory() as d:
                docker=Docker();docker.info["Config"]["Labels"]=labels
                obj,_,_=self.prepare(pathlib.Path(d),docker=docker)
                with self.assertRaisesRegex(ValueError,"label"):obj.before_public()
                self.assertIsNone(obj.cid)
                self.assertFalse(any(args[0]=="kill" for args in docker.calls))

    def test_actual_matching_argv_child_in_inherited_group_cannot_grant_ownership(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);obj,_,_=self.prepare(root)
            argv=[sys.executable,"-c","import time;time.sleep(30)"]
            (root/"launch.json").write_text(json.dumps({"argv":argv}))
            proc=subprocess.Popen(argv)  # deliberately inherits this test's group
            try:
                with patch.object(supervision.os,"killpg",side_effect=AssertionError("foreign group")):
                    with self.assertRaisesRegex(ValueError,"ownership"):
                        obj.client_started(proc)
                    self.assertIsNone(obj.proc)
                    obj.fault("synthetic failure after rejected ownership")
                self.assertIsNone(proc.poll())
            finally:
                proc.kill();proc.wait()

    def test_each_bound_policy_dependency_drift_refuses_before_classification(self):
        import shutil
        for name in ("grade_policy.py","audit_reparse.py","multilang_grade.py","multilang_tasks.py"):
            with self.subTest(name=name),tempfile.TemporaryDirectory() as d:
                root=pathlib.Path(d);policy=root/"policy";policy.mkdir()
                for path in POLICY.parent.glob("*.py"):shutil.copyfile(path,policy/path.name)
                (root/("mcp-launch-"+NAME+".json")).write_text(json.dumps({"name":NAME}))
                obj=supervision.Supervisor(policy/"grade_policy.py",host=lambda:dict(HEALTHY),docker=Docker(),interval=100)
                obj.bind(out=root,image=IMAGE,server=types.SimpleNamespace());self.addCleanup(obj.stop_monitor)
                obj.before_public();log=root/"public.log";log.write_text("ok")
                with (policy/name).open("a") as stream:stream.write("\n# changed after binding\n")
                with patch.object(supervision,"classify",side_effect=AssertionError("changed policy invoked")):
                    with self.assertRaisesRegex(ValueError,"policy source drift"):
                        obj.after_public("check",log,0)


if __name__=="__main__":unittest.main()
