"""Concrete adapter. Importing it launches nothing and reads no credential."""
import hashlib
import importlib.util
import json
import pathlib
import re
import subprocess
import sys
from decimal import Decimal

CONTROLLER = pathlib.Path("/home/marius/.cache/codescout-resident/codescout/semantic-contract-controller-20261106")
sys.path.insert(0,str(CONTROLLER))
import campaign
from real_backend import Readiness
from supervision import Supervisor, classify

class PaidBackend(Readiness):
    def __init__(self,reg,*,qualification_plan=None,supervisor_factory=Supervisor):
        super().__init__(reg)
        self.qualification_plan=qualification_plan
        self.supervisor_factory=supervisor_factory
        source=pathlib.Path(reg["qualified_source"]).resolve()
        if pathlib.Path(self.external.__file__).resolve()!=source/"tools/agent_lifecycle/external.py":
            raise ValueError("runtime module source does not match registration")
        spec=importlib.util.spec_from_file_location("adapter_cost_driver",source/"tools/hint_authority_workflow/driver.py")
        self.driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.driver)

    def launch(self,row,reserve,cli):
        # This last host boundary runs before external.launch can read a credential.
        campaign.check_hashes(self.reg["shared_hashes"])
        campaign.check_hashes(row["immutable_hashes"])
        campaign.check_hashes(row["writable_hashes"])
        self.validate_shared(self.reg)
        if reserve!=campaign.amount(self.reg["reserve_usd"]) or cli!=campaign.amount(self.reg["cli_cap_usd"]):
            raise ValueError("attempt budget differs from registration")
        mode=self.reg.get("mode")
        if (mode=="paid" and self.qualification_plan is not None
                or mode=="qualification" and self.qualification_plan is None
                or mode not in ("paid","qualification")):
            raise ValueError("qualification/paid mode mismatch")
        out=pathlib.Path(row["out"])
        supervisor=self.supervisor_factory(pathlib.Path(self.reg["public_policy"]))
        kwargs={"effort":row["effort"],"allowance":str(reserve),"cli_cap":str(cli),"supervisor":supervisor}
        if mode=="qualification":
            from qualify import NoCredential
            kwargs.update(scripted_plan=self.qualification_plan,token_path=NoCredential())
        try:
            return self.external.launch(out,**kwargs)
        except BaseException as exc:
            campaign.save(out/"adapter-launch-error.json",{"type":type(exc).__name__,
                "message":str(exc)[:500],"cost_known":False,"retry_allowed":False})
            raise

    def reconcile(self,row,receipt,reserve):
        return self.driver.reconcile(pathlib.Path(row["out"]),receipt,reserve)

    def valid_public(self,row,receipt):
        out=pathlib.Path(row["out"]);policy=pathlib.Path(self.reg["public_policy"])
        campaign.check_hashes(self.reg["shared_hashes"])
        proof=campaign.load(out/"supervision-final.json")
        if receipt.get("supervision_error") is not None:
            raise ValueError("runtime finalization failed")
        if classify(policy,"",0,proof).get("valid") is not True:
            raise ValueError("final runtime proof invalid")
        bound=campaign.load(out/"public-classifications.json")["checks"]
        rounds=sorted(out.glob("verification-*/receipt.json"),key=lambda p:int(p.parent.name.split("-")[1]))
        if not rounds:raise ValueError("no public rounds")
        expected=campaign.load(out/"prepared.json")["checks"]
        observed=[]
        for index,path in enumerate(rounds):
            result=campaign.load(path)
            if result.get("round")!=index or result.get("status")!="completed" or result.get("error") is not None:
                raise ValueError("public round incomplete")
            if [(c["id"],c["command"]) for c in result["checks"]]!=[(c["id"],c["command"]) for c in expected]:
                raise ValueError("public manifest mismatch")
            for check in result["checks"]:
                log=pathlib.Path(check["log"])
                if log.is_symlink() or not log.resolve().is_relative_to(out.resolve()):
                    raise ValueError("public log ownership mismatch")
                raw=log.read_bytes()
                actual=classify(policy,raw.decode("utf-8","replace"),check["exit_code"],proof)
                if actual.get("valid") is not True:raise ValueError("public classification invalid")
                observed.append({"command":check["command"],"log":str(log),"bytes":len(raw),
                    "sha256":hashlib.sha256(raw).hexdigest(),"exit_code":check["exit_code"],"classification":actual})
            if result.get("passed") is not all(c["exit_code"]==0 for c in result["checks"]):
                raise ValueError("public pass flag contradicts exits")
        if observed!=bound:raise ValueError("public classification population or bytes differ")
        if campaign.load(rounds[-1])!=receipt.get("public_verification"):
            raise ValueError("receipt public result differs")
        return {"valid":True,"rounds":len(rounds),"checks":len(observed)}

    def cleanup(self,row):
        out=pathlib.Path(row["out"])
        proof=campaign.load(out/"supervision-final.json")
        cids=proof.get("observed_container_ids")
        names=[p["name"] for p in campaign.load(out/"cleanup.json")]
        if (not isinstance(cids,list) or not cids or any(not re.fullmatch(r"[0-9a-f]{64}",cid) for cid in cids)
                or not names or any(p.get("absent") is not True for p in campaign.load(out/"cleanup.json"))):
            raise ValueError("native cleanup identity/evidence missing")
        daemon=subprocess.run(["docker","info","--format","{{json .ServerVersion}}"],
                              capture_output=True,text=True,timeout=20)
        trace={"daemon_exit":daemon.returncode,"observations":[]}
        if daemon.returncode:raise ValueError("Docker daemon not queryable")
        for identity in [*cids,*names]:
            result=subprocess.run(["docker","inspect",identity],capture_output=True,text=True,timeout=20)
            absent=result.returncode!=0 and "no such" in result.stderr.lower()
            trace["observations"].append({"identity":identity,"exit_code":result.returncode,"stderr":result.stderr,"absent":absent})
            campaign.save(out/"adapter-cleanup.json",trace)
            if not absent:raise ValueError("owned native absence not proven")
        return {"daemon_query_succeeded":True,"independently_absent":True,"observed_ids":cids,"names":names}
