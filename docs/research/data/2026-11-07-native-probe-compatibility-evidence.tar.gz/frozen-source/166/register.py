"""Freeze one prospective control cohort. No containers/providers started."""
import json
from pathlib import Path
import subprocess
import qualify as q

ROOT=Path(__file__).parent
MAIN=Path("/home/marius/work/claude/codescout")
DATA=Path("/home/marius/work/claude/setup-ab-data")
CASES={
 "NU":("nushell__nushell-18863","sha256:e317a8e791bfa1f546ab9b58af244ba0844311fef0019306042522d5f68d81b2"),
 "RA":("rust-lang__rust-analyzer-22992","sha256:b3df4c943af162ec27e038ed6b80557ae8764e869e43402ea96c477d876066c9")}
def build():
    bound=list(q.TOOLS.glob("*.py"))
    bound += [ROOT/name for name in ("qualify.py","test_qualify.py","register.py","calibrate.py")]
    reg={"version":1,"policy_version":q.policy.POLICY_VERSION,"order":q.ORDER,
         "floors":q.FLOORS,"resources":["--cpus","4","--memory","8g"],
         "step_timeout":q.tasks.GRADE_STEP_TIMEOUT,"tasks":{},"hashes":{},
         "source_commit":subprocess.check_output(["git","-C",str(q.TOOLS),"rev-parse","HEAD"],text=True).strip(),
         "scope":"Six fresh native controls only. No paid/public-workflow admission.",
         "provider_calls":0}
    for label,(ident,image) in CASES.items():
        b=DATA/"fresh-tasks"/ident/"bundle.json"
        bundle=json.loads(b.read_text())
        r=Path(bundle["record_path"])
        gold=b.parent/"build/gold.patch"
        record=json.loads(r.read_text())
        f2p,p2p=q.tasks.expected_sets(record,bundle)
        reg["tasks"][label]={"id":ident,"image":image,"bundle":str(b),"record":str(r),
                              "gold":str(gold),"f2p":f2p,"p2p":p2p}
        bound += [b,r,gold]
    old=json.loads((MAIN/"docs/research/data/2026-11-06-grader-validity-audit-v2.json").read_text())
    for path,obj in old["protected_files_before_after"].items():
        if q.sha(path)!=obj:
            raise ValueError("old evidence changed: "+path)
        bound.append(Path(path))
    reg["hashes"]={str(path):q.sha(path) for path in bound}
    q.preflight(reg)
    return reg
def main():
    reg=build()
    path=ROOT/"registration.json"
    with path.open("x") as stream:
        stream.write(json.dumps(reg,indent=2)+"\n")
    print(json.dumps({"path":str(path),"sha256":q.sha(path),"bound_files":len(reg["hashes"]),
                      "source_commit":reg["source_commit"],"provider_calls":0}))
if __name__=="__main__":main()
