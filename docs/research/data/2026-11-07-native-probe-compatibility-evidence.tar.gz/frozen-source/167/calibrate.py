"""Offline classification overlap only: runtime proof is deliberately a fixture, not admission."""
import hashlib,json,pathlib,sys
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/prospective-grader-policy-20261106")
MAIN=pathlib.Path("/home/marius/work/claude/codescout")
SOURCE=pathlib.Path("/home/marius/work/claude/codescout.worktrees/grader-validity/tools/setup-ab-eval")
DATA=pathlib.Path("/home/marius/work/claude/setup-ab-data/fresh-tasks")
COHORT=ROOT.parent/"external-matched-repairs-20261105"
sys.path.insert(0,str(SOURCE))
import grade_policy
RUNTIME={"complete":True,"resource_ok":True,"cgroup_probes":2,"oom_kill":0,"errors":[]}

def main():
    out=ROOT/"offline-calibration.json"
    if out.exists():raise ValueError("Refuse overwrite")
    old=json.loads((MAIN/"docs/research/data/2026-11-06-grader-validity-audit-v2.json").read_text())
    rows=[]
    for row in old["rows"]:
        arm=COHORT/(row["task"]+"--"+row["effort"])
        raw=json.loads((arm/"private-grade.json").read_text())
        logpath=pathlib.Path(raw["log"]);full=json.loads((logpath.parent/"grade.json").read_text())
        bundle=json.loads((DATA/row["task"]/"bundle.json").read_text())
        record=json.loads(pathlib.Path(bundle["record_path"]).read_text())
        result=grade_policy.adjudicate_private(raw,full,record,bundle,log=logpath.read_text(),runtime=RUNTIME)
        expected="measurement_invalid" if row["task"].startswith("nushell") and row["effort"]=="low" else ("test_failure" if row["task"].startswith("nushell") else "pass")
        rows.append({"task":row["task"],"effort":row["effort"],"expected_kind":expected,
                     "observed_kind":result["kind"],"valid_conditional_on_fixture_runtime":result["valid"],
                     "pass":result["pass"],"error":result["error"],"recovered":result.get("recovered",[])})
    for name,digest in old["protected_files_before_after"].items():
        if hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()!=digest:raise ValueError("Protected old evidence drift")
    receipt={"scope":"Logical classification overlap with SYNTHETIC runtime proof; not native qualification or paid admission",
             "rows":rows,"protected_old_files_unchanged":len(old["protected_files_before_after"]),
             "policy_sha256":hashlib.sha256((SOURCE/"grade_policy.py").read_bytes()).hexdigest(),
             "provider_calls":0,"native_regrades":0}
    out.write_text(json.dumps(receipt,indent=2)+"\n");print(json.dumps(receipt,indent=2))
    if any(r["expected_kind"]!=r["observed_kind"] for r in rows):raise ValueError("Classification mismatch; retain evidence and investigate")
if __name__=="__main__":main()
