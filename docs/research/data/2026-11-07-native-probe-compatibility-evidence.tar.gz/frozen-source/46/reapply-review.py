"""One fixed-population reapplication on copies; never replays a real arm."""
import hashlib
import json
import pathlib
import shutil
import subprocess
import sys
ROOT=pathlib.Path(__file__).parent
REVIEW=pathlib.Path("/tmp/semantic-contract-controller-review-20261106")
OUT=ROOT/"fix-pass"
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    if OUT.exists():raise ValueError("Refuse overwrite")
    OUT.mkdir()
    population=json.loads((REVIEW/"mutation-population.json").read_text())
    if len(population)!=14:raise ValueError("Mutation population drift")
    results=[]
    for mutation in [None]+population:
        name="baseline" if mutation is None else mutation["id"]
        dest=OUT/name;dest.mkdir()
        for filename in ("campaign.py","real_backend.py","test_campaign.py","test_real_backend.py","test_review_v2.py"):
            shutil.copyfile(ROOT/filename,dest/filename)
        if mutation:
            target=dest/mutation["file"];body=target.read_text()
            if body.count(mutation["from"])!=1:raise ValueError("Exact mutation no longer unique "+name)
            target.write_text(body.replace(mutation["from"],mutation["to"],1))
        proc=subprocess.run([sys.executable,"-B","-m","unittest","discover","-s",str(dest),"-p","test_*.py","-v"],capture_output=True,text=True,timeout=30)
        log=proc.stdout+proc.stderr;(dest/"suite.log").write_text(log)
        if "Ran 32 tests" not in log or any(token in log for token in ("ImportError","SyntaxError","ModuleNotFoundError")):
            raise ValueError("Invalid harness "+name)
        if mutation is None and proc.returncode:raise ValueError("Expanded baseline fails")
        results.append({"id":name,"exit_code":proc.returncode,"observed":"pass" if mutation is None else ("killed" if proc.returncode else "survived"),
                        "campaign_sha256":sha(dest/"campaign.py"),"backend_sha256":sha(dest/"real_backend.py"),"log":str(dest/"suite.log")})
    record={"baseline_tests":32,"original_mutation_population":14,"original_killed":7,"original_survived":7,
            "fixed_mutation_population":14,"killed":sum(r["observed"]=="killed" for r in results),"survived":sum(r["observed"]=="survived" for r in results),
            "results":results,"provider_calls":0,"real_actors_rerun":False}
    (ROOT/"fix-pass-results.json").write_text(json.dumps(record,indent=2)+"\n");print(json.dumps(record,indent=2))
    if record["survived"]:raise ValueError("Unresolved mutation survivors")
if __name__=="__main__":main()
