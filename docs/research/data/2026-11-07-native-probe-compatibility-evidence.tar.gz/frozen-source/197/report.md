# One fresh whole-change final review

Review date: 2026-11-06. Reviewed product worktree: /home/marius/.codex/worktrees/ca35/codescout; base commit `36fec1201b0f809d6f21cc31082def4d651b6cf8`. Private adapter root: /home/marius/.cache/codescout-resident/codescout/semantic-contract-adapter-20261106. Requirements: spec fb7d21b6e59730b3 and plan 717fe707915d297c.

**Changes requested before source freeze.** Twenty independent source mutations were actually applied to isolated copies: **10 killed, 10 survived**. These are observed process results, not estimates of coverage. Ten medium/Important regression-guard gaps and two medium/Important qualification-scaffolding issues are filed in MAIN/docs/issues. No production-behavior defect was demonstrated in the original supervisory hooks by these mutations; the surviving guards exist but are not independently protected by tests.

## Findings

All paths below are relative to the product worktree for tools/ paths, and the private adapter root otherwise.

| Severity | Site | Observed finding | Issue |
|---|---|---|---|
| Medium / Important | tools/agent_lifecycle/workflow.py:205 | M03 disconnects the workflow-to-session guard; lifecycle 83 and backend 15 tests both still exit 0. Direct session tests do not pin this caller. Add a real workflow idle/pending-job guard fault with no later continuation. | 77921b8f64c95dd2 |
| Medium / Important | tools/agent_lifecycle/workflow.py:176 | M06 clears/swallows a finish exception; both suites remain green. Add a failure arising only in finish(), after successful public/capture work, and observe incomplete receipt plus retained error and cleanup ordering. | be980c920dbde10b |
| Medium / Important | supervision.py:134 | M07 removes the native label equality check; supervisor 9 and backend 15 pass. Use an otherwise valid image/CID/name/profile with only a wrong or missing label; require no kill of the unverified CID. | a8b6d4c61c7d371e |
| Medium / Important | supervision.py:105 | M08 removes process-group isolation validation; supervisor/backend pass. Use a real matching-argv Popen in an inherited group, require rejection before ownership and no killpg; directly clean up the test child. | 3ae5ca8480e9bfe2 |
| Medium / Important | paid_backend.py:32 | M12 skips writable input hashes; backend passes. Drift only this dimension and require rejection before launch/credentials. | e41b43b794500dba |
| Medium / Important | paid_backend.py:33 | M13 skips actual plugin/read-only validation; backend passes. Existing backend fixtures stub this boundary. Test actual validate_shared with valid sibling inputs and isolated plugin/source drift. | 9db3d4aabcc7df06 |
| Medium / Important | paid_backend.py:72 | M14 skips round/status/error validation; backend passes. Independently corrupt each field in otherwise valid rounds and keep the final receipt consistent, so another guard does not mask this site. | 1c957d7be0326251 |
| Medium / Important | paid_backend.py:103 | M15 omits the failed-daemon rejection; backend passes because its negative fixture also makes inspect fail. Make info fail while all identity inspections return no-such, and require rejection. | a5701639141a1767 |
| Medium / Important | supervision.py:201 | M19 skips classifier-source hashes; supervisor/backend pass. Copy policy dependencies to scratch, bind, mutate one copy, and require refusal before classifier invocation. Never change the frozen grader. | ddfecc354f89859d |
| Medium / Important | paid_backend.py:31 | M20 skips immutable arm hashes; backend passes. Corrupt only an immutable arm input and observe refusal before external.launch. | 7b494f0411adc9b9 |
| Medium / Important | freeze_common.py:25 | Freeze accepts historical gate13e success and unrelated current HEAD. The actual gate record was still running and had started at 2026-11-06T19:40:31.783290476+00:00, before the forthcoming fix pass. Bind a post-fix gate to exact tested source/test hashes and use that record; also replace the hardcoded success string at :72. | b81c0bf318265944 |
| Medium / Important | run_common.py:55 | The common smoke never calls concrete PaidBackend.reconcile (:54-55), so it omits that boundary. A control-flow witness produced qualified=True with zero calls to a deliberately rejecting reconcile stub. Preserve intentional rejection of scripted receipts; verify that rejection and separately exercise existing bound paid receipts for positive calibrated reconciliation. | b85449246dae9236 |

The first reconciliation remediation I proposed—require a zero return for the scripted receipt—was incorrect. Reading tools/hint_authority_workflow/driver.py:63 established that scripted receipts are intentionally rejected. The issue and this report contain the corrected recommendation. The witness proves only the omitted call; all backend/native/provider operations were stubbed.

## Measured test population and import provenance

The successful copied baseline was:

| Separate suite invocation | Tests run | Process exit | Failures/errors |
|---|---:|---:|---|
| lifecycle | 83 | 0 | 0/0 |
| transport | 32 | 0 | 0/0 |
| supervisor | 9 | 0 | 0/0 |
| backend | 15 | 0 | 0/0 |

The backend population includes **7 BackendTests methods and 8 imported ExternalEntryTests methods**. Do not describe it as 15 new backend tests. Counts are unittest result.testsRun, not subtest counts or unique tests across invocations.

Each invocation ran in a fresh /usr/bin/python3 interpreter (3.14.9), with -B. run_suite.py records actual module __file__ and SHA256 after the suite. build_manifest.py verified every mutated target was imported from that exact mutant tree with the exact changed hash. No foreign mutated-source import was accepted.

The copied test_paid_backend.py SOURCE constant points to its own copied tree. POLICY remains at the frozen original grader path. The three requested source directories were copied; hint_authority_resume was additionally copied because full transport discovery imports its driver. The first transport setup failed on that absent dependency, before mutation measurement; it was corrected and the complete 32-test baseline passed. No import-error run is counted as a mutation kill.

## Applied mutations

L=lifecycle, T=transport, S=supervisor, B=backend. Every baseline suite listed below exited 0. Killed means at least one relevant mutated suite exited nonzero; counts are preserved per invocation in mutations.json.

| ID | Actual mutation | Suites and mutated exits | Observed |
|---|---|---|---|
| M01 | Remove session pre-spawn guard | L=1 | killed |
| M02 | Remove remaining-time guard | L=1 | killed |
| M03 | Pass guard=None from workflow | L=0 B=0 | survived |
| M04 | Omit before_public caller | L=1 B=1 | killed |
| M05 | Omit after_public caller | L=1 B=1 | killed |
| M06 | Swallow finish exception | L=0 B=0 | survived |
| M07 | Skip native label equality | S=0 B=0 | survived |
| M08 | Skip isolated process-group equality | S=0 B=0 | survived |
| M09 | Ignore oom_group_kill | S=1 B=0 | killed |
| M10 | Omit owned client abort | S=1 | killed |
| M11 | Omit final native sample | S=1 B=0 | killed |
| M12 | Skip writable input hashes | B=0 | survived |
| M13 | Skip validate_shared caller | B=0 | survived |
| M14 | Skip public round completion/identity | B=0 | survived |
| M15 | Skip independent daemon check | B=0 | survived |
| M16 | Inspect names without exact CIDs | B=1 | killed |
| M17 | Omit proxy request-entry guard | T=1 | killed |
| M18 | Omit proxy actual-upstream guard | T=1 | killed |
| M19 | Skip policy source hash comparison | S=0 B=0 | survived |
| M20 | Skip immutable arm hashes | B=0 | survived |

M05 includes one missing-classification-file error caused by the removed call; it also has explicit behavioral assertion failures in lifecycle and backend, so the kill does not depend on treating an import/fixture failure as evidence.

## Reapply exactly once during the offline fix pass

1. Preserve baseline/ and M01–M20/ as original review evidence. Create new post-fix copies.
2. Read each mutation's file, symbol, original and replacement from mutations.json. Require exactly one match of original. M17/M18 include method context to distinguish their otherwise identical guard lines.
3. Apply that exact substitution within the named symbol through edit_code. Do not mutate frozen original runtime/grader/controller files.
4. Run the listed suites against the copied post-fix tree using run_suite.py or run_batch.py. Confirm actual target __file__/SHA again.
5. Record pre-fix survivor results separately from post-fix kills. A passing unchanged suite is not a kill. Restore bytes and verify the post-fix baseline.
6. Run the required final gate against the final product/test bytes before freeze. Parent owns that gate and source commit; reviewer made no commit.

Machine-readable evidence: [mutations.json](mutations.json), [candidates.json](candidates.json), baseline-results.json, Mxx-results.json and Mxx-suite.log. The manifest includes exact before/after replacements, byte hashes, commands, real exits, test counts, interpreter/import provenance, and log hashes. **Every entire mutated file was verified equal to its baseline plus exactly the declared substitution.** Original source/test bytes were compared to baseline snapshots, allowing only the declared copied SOURCE rewrite; all matched at handback.

mutations.json SHA256: f9183dfb08f8acdfb7324d656abcafae5f36c05ae39af7d4274166920e120226.

## Limits and preserved scope

No native Docker execution, credential/provider/model call, paid attempt, early private grade, original source edit, commit, merge, or push was performed. Local subprocess and loopback HTTP fixtures ran. Existing closed private controls, onboarding and old wire cases were not repeated. The two qualification scripts were inspected within this same review after parent supplied them; no second review or extra mutation cycle was performed.

No claim is made that these 20 mutations exhaust edge cases. The existing full gate is parent-owned and was still running when inspected; this review does not represent that gate as passed. Known classifier limitation e6ca1ffc981b1105 (synthetic rustc ICE text without a signal diagnostic) remains unchanged and outside this fix scope.

Ledger checked: existing open/taken/investigating/zombie population (44 records; titles read), including e6ca1ffc981b1105, e6b99f20243e4fd0 and 501a1f3b1384ceb5; new review issues 77921b8f64c95dd2, be980c920dbde10b, a8b6d4c61c7d371e, 3ae5ca8480e9bfe2, e41b43b794500dba, 9db3d4aabcc7df06, 1c957d7be0326251, a5701639141a1767, ddfecc354f89859d, 7b494f0411adc9b9, b81c0bf318265944, b85449246dae9236.
