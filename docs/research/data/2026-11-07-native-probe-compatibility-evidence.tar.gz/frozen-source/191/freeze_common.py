"""Freeze final reviewed host source and ONE common fixture before its launch."""
import copy
import hashlib
import json
import pathlib
import shutil
import subprocess
import time
from paid_backend import PaidBackend
import campaign

ROOT=pathlib.Path(__file__).resolve().parent
BASE=ROOT.parent
SOURCE=pathlib.Path("/home/marius/.codex/worktrees/ca35/codescout")
PRODUCT=("tools/agent_lifecycle/session.py","tools/agent_lifecycle/workflow.py","tools/agent_lifecycle/external.py",
         "tools/agent_lifecycle/test_supervision.py","tools/agent_lifecycle/test_external_entry.py",
         "tools/hint_authority_pilot/transport.py","tools/hint_authority_pilot/test_request_guard.py")


def verify_gate(receipt, source):
    native=campaign.load(receipt["native_record"])
    if (campaign.digest(receipt["native_record"])!=receipt["native_record_sha256"]
            or native.get("state")!="exited" or native.get("exit_code")!=0
            or "run_final_gate.py" not in native.get("command","")):
        raise ValueError("final native gate record invalid")
    result=campaign.load(receipt["result"])
    if campaign.digest(receipt["result"])!=receipt["result_sha256"] or result.get("exit_code")!=0:
        raise ValueError("final gate result invalid")
    if result.get("source_before")!=result.get("source_after") or not result.get("source_before"):
        raise ValueError("source changed during final qualification")
    for relative in PRODUCT:
        path=pathlib.Path(source)/relative
        if result["source_before"].get(str(path))!=campaign.digest(path):
            raise ValueError("final gate source drift")
    campaign.check_hashes(result["source_before"])
    if {r["suite"] for r in result.get("suites",[])}!={"lifecycle","transport","supervisor","backend","qualification","full_gate"}:
        raise ValueError("final gate suite population incomplete")
    if any(row["exit_code"]!=0 for row in result["suites"]):
        raise ValueError("final gate suite failed")
    return result

def main():
    target=ROOT/"common-registration.json"
    if target.exists():raise ValueError("frozen registration already exists")
    fix=campaign.load(ROOT/"fix-pass.json")
    if fix.get("qualified") is not True:raise ValueError("review/fix evidence incomplete")
    gate_receipt=campaign.load(ROOT/"gate-final-receipt.json")
    gate=verify_gate(gate_receipt,SOURCE)
    status=subprocess.run(["git","status","--porcelain"],cwd=SOURCE,capture_output=True,text=True,check=True)
    if status.stdout:raise ValueError("source must be committed and clean")
    head=subprocess.run(["git","rev-parse","HEAD"],cwd=SOURCE,capture_output=True,text=True,check=True).stdout.strip()
    if head=="36fec1201b0f809d6f21cc31082def4d651b6cf8":raise ValueError("new source not committed")
    for name in PRODUCT:
        blob=subprocess.run(["git","show","HEAD:"+name],cwd=SOURCE,capture_output=True,check=True).stdout
        if hashlib.sha256(blob).hexdigest()!=campaign.digest(SOURCE/name):
            raise ValueError("committed product bytes mismatch")
    reg=campaign.load(ROOT/"common-registration-unfrozen.json")
    old=campaign.load(BASE/"semantic-contract-controller-20261106/post-review/registration.json")
    shared=copy.deepcopy(old["shared_hashes"])
    campaign.check_hashes(shared)
    private=campaign.load(BASE/"prospective-grader-policy-20261106/registration.json")
    campaign.check_hashes(private["hashes"]);shared.update(private["hashes"])
    for group in ("agent_lifecycle","hint_authority_pilot","hint_authority_workflow"):
        shared.update({str(p):campaign.digest(p) for p in (SOURCE/"tools"/group).glob("*.py")})
    for name in ("supervision.py","paid_backend.py","prepare_common.py","check_prepared.py",
                 "freeze_common.py","run_common.py","run_final_gate.py","gate-final-receipt.json","gate-final-result.json","fix-pass.json","review/report.md","review/mutations.json"):
        p=ROOT/name
        shared[str(p)]=campaign.digest(p)
    wire=BASE/"semantic-contract-wire-20261106"
    for p in (wire/"control-v3-offline.py",wire/"recon-body-reference.txt",
              BASE/"semantic-contract-controller-20261106/closed-receipt-calibration.json",
              BASE/"external-matched-repairs-20261105/registration.json",
              ROOT/"real-inputs-before.json",ROOT/"common-readiness-unstarted.json"):
        shared[str(p)]=campaign.digest(p)
    for hashes in campaign.load(ROOT/"real-inputs-before.json").values():campaign.check_hashes(hashes)
    reg.update(shared_hashes=shared,registered_unix=time.time(),source_commit=head,
        original_runtime_commit="36fec1201b0f809d6f21cc31082def4d651b6cf8",
        grader_commit=private["source_commit"],source_gate_record=gate,
        review_fix_receipt=str(ROOT/"fix-pass.json"),repair_admitted=False)
    backend=PaidBackend(reg,qualification_plan=reg["scripted_plan"])
    backend.validate_shared(reg)
    for row in reg["arms"]:
        campaign.check_hashes(row["immutable_hashes"]);campaign.check_hashes(row["writable_hashes"])
        backend.validate(row)
    campaign.resource_check(backend.resources(reg["arms"][0]))
    for i,(name,expected) in enumerate(shared.items()):
        path=pathlib.Path(name)
        copy_path=ROOT/"frozen-source"/str(i)/path.name
        copy_path.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,copy_path)
        if campaign.digest(copy_path)!=expected:raise ValueError("frozen source copy drift")
    campaign.check_hashes(shared)
    campaign.save(target,reg,exclusive=True)
    campaign.save(ROOT/"source-freeze.json",{"source_commit":head,"shared_paths":len(shared),
        "hashes":shared,"common_registration_sha256":campaign.digest(target),
        "source_gate_receipt":gate_receipt,"paid_admission":False,"provider_calls":0})
    print(json.dumps({"source_commit":head,"common_ready_for_one_scripted_launch":True,"paid_admission":False}))


if __name__=="__main__":main()
