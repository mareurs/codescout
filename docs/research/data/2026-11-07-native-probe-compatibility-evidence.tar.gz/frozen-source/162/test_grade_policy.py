"""Policy observations, with the dataset parser unchanged and no Docker/model boundary."""
import copy
import json
import unittest
from pathlib import Path

import grade_policy as policy
import multilang_grade as grade

PARSER = json.loads((Path(__file__).parent / "fixtures/multilang/rust_concat_record.json").read_text())["log_parser"]
RECORD = {"log_parser": PARSER, "FAIL_TO_PASS": ["bin::f"], "PASS_TO_PASS": ["bin::p"],
          "test_cmds": ["cargo test"], "print_cmds": ["cat reports/log"], "rebuild_cmds": []}
BUNDLE = {"expected": {"fail_to_pass": 1, "pass_to_pass_kept": 1, "dropped": []}}
OK = {"complete": True, "resource_ok": True, "cgroup_probes": 2, "oom_kill": 0, "errors": []}
PASS_LOG = "Running tests/main.rs (bin)\ntest f ... ok\ntest p ... ok\n"
FAIL_LOG = "Running tests/main.rs (bin)\ntest f ... FAILED\ntest p ... ok\n"
SIGNAL = "collect2: fatal error: ld terminated with signal 7 [Bus error], core dumped"


def fixture(log):
    verdict = grade.verdict(grade.run_parser(PARSER, log), ["bin::f"], ["bin::p"])
    raw = dict(verdict, oom_killed=False, container_removed=True)
    full = dict(raw, steps=[{"name": "grade:test[0]", "returncode": 0, "tail": ""},
                            {"name": "grade:print[0]", "returncode": 0, "tail": ""}])
    return raw, full


class PolicyTests(unittest.TestCase):
    def private(self, log, *, runtime=None, raw=None, full=None, record=None):
        default_raw, default_full = fixture(log)
        return policy.adjudicate_private(default_raw if raw is None else raw,
                                          default_full if full is None else full,
                                          RECORD if record is None else record, BUNDLE,
                                          log=log, runtime=OK if runtime is None else runtime)

    def test_public_success_and_functional_failure(self):
        self.assertEqual(policy.classify_public("build complete", 0, runtime=OK)["kind"], "pass")
        result = policy.classify_public("assertion failed", 101, runtime=OK)
        self.assertIs(result["valid"], True)
        self.assertIs(result["pass"], False)
        self.assertEqual(result["kind"], "functional_failure")

    def test_public_unknown_or_bad_runtime_fails_closed(self):
        for runtime in ({}, dict(OK, complete=False), dict(OK, resource_ok=False),
                        dict(OK, oom_kill=1), dict(OK, cgroup_probes=0), dict(OK, errors=["probe failed"])):
            with self.subTest(runtime=runtime):
                result = policy.classify_public("success", 0, runtime=runtime)
                self.assertIs(result["valid"], False)
                self.assertIs(result["pass"], False)
                self.assertTrue(result["error"])

    def test_public_capture_signal_storage_and_process_failure_invalidate(self):
        for log, code, truncated in ((SIGNAL, 1, False),
                                     ("error: No space left on device (os error 28)", 1, False),
                                     ("bash: /tmp/test-exec: Permission denied", 126, False),
                                     ("", -9, False), ("", 0, True)):
            with self.subTest(log=log, code=code, truncated=truncated):
                self.assertFalse(policy.classify_public(log, code, runtime=OK, truncated=truncated)["valid"])

    def test_private_complete_pass_and_real_test_failure(self):
        passed, failed = self.private(PASS_LOG), self.private(FAIL_LOG)
        self.assertTrue(passed["valid"])
        self.assertTrue(passed["pass"])
        self.assertEqual(passed["statuses"], {"bin::f": "pass", "bin::p": "pass"})
        self.assertTrue(failed["valid"])
        self.assertFalse(failed["pass"])
        self.assertEqual(failed["kind"], "test_failure")
        self.assertEqual(failed["statuses"]["bin::f"], "fail")

    def test_private_recovers_expected_p2p_with_physical_provenance(self):
        log = "Running tests/main.rs (bin)\ntest f ... ok\noutputtest p ... ok\n"
        result = self.private(log)
        self.assertTrue(result["valid"])
        self.assertTrue(result["pass"])
        self.assertEqual((result["raw"]["missing"], result["adjusted"]["missing"]), (1, 0))
        self.assertEqual(result["recovered"], [{"key": "bin::p", "status": "pass",
                                              "line": 3, "raw": "outputtest p ... ok"}])

    def test_private_recovery_does_not_replace_failure(self):
        result = self.private(FAIL_LOG + "outputtest f ... ok\n")
        self.assertTrue(result["valid"])
        self.assertFalse(result["pass"])
        self.assertEqual(result["statuses"]["bin::f"], "fail")

    def test_private_missing_status_is_not_fabricated_failure(self):
        result = self.private("Running tests/main.rs (bin)\ntest f ... ok\n")
        self.assertFalse(result["valid"])
        self.assertEqual(result["kind"], "measurement_invalid")
        self.assertTrue(result["error"])

    def test_private_compiler_failure_is_semantic_with_zero_statuses(self):
        log = "error[E0425]: cannot find value missing\nerror: could not compile candidate\n"
        raw, full = fixture(log)
        full["steps"][0]["returncode"] = 101
        result = self.private(log, raw=raw, full=full)
        self.assertTrue(result["valid"])
        self.assertFalse(result["pass"])
        self.assertEqual(result["kind"], "compile_failure")
        self.assertEqual(result["statuses"], {})

    def test_private_source_excerpt_is_not_infrastructure(self):
        log = "error: format argument must be a string literal\n2 | println!(Bus error);\n"
        raw, full = fixture(log)
        full["steps"][0]["returncode"] = 101
        result = self.private(log, raw=raw, full=full)
        self.assertTrue(result["valid"])
        self.assertEqual(result["kind"], "compile_failure")

    def test_private_partial_statuses_cannot_hide_toolchain_or_storage_fault(self):
        for suffix in (SIGNAL, "error: No space left on device (os error 28)"):
            with self.subTest(suffix=suffix):
                self.assertFalse(self.private(PASS_LOG + suffix + "\n")["valid"])

    def test_private_runtime_and_raw_faults_never_recover_to_pass(self):
        self.assertFalse(self.private(PASS_LOG, runtime=dict(OK, oom_kill=1))["valid"])
        for change in ({"error": "timeout"}, {"infra": "unknown"}, {"oom_killed": True},
                       {"container_removed": False}, {"pass": False}):
            with self.subTest(change=change):
                raw, full = fixture(PASS_LOG)
                raw.update(change)
                self.assertFalse(self.private(PASS_LOG, raw=raw, full=full)["valid"])

    def test_private_requires_exact_complete_capture_steps(self):
        raw, original = fixture(PASS_LOG)
        variants = [dict(original, steps=[]),
                    dict(original, steps=list(reversed(original["steps"])))]
        for change in ({"truncated": True}, {"returncode": 1}, {"returncode": True}):
            full = copy.deepcopy(original)
            full["steps"][1].update(change)
            variants.append(full)
        for full in variants:
            with self.subTest(full=full):
                self.assertFalse(self.private(PASS_LOG, raw=raw, full=full)["valid"])

    def test_private_failed_rebuild_cannot_pass_on_stale_complete_test_log(self):
        record = dict(RECORD, rebuild_cmds=["cargo build"])
        raw, full = fixture(PASS_LOG)
        full["steps"].insert(0, {"name": "grade:rebuild", "returncode": 101,
                                 "tail": "error[E0425]: cannot find value missing"})
        result = self.private(PASS_LOG, raw=raw, full=full, record=record)
        self.assertTrue(result["valid"])
        self.assertFalse(result["pass"])
        self.assertEqual(result["kind"], "compile_failure")

    def test_selected_expected_pass_can_survive_unselected_test_failures(self):
        # Existing NU gold controls exit101 for unselected tests; the selected oracle
        # is the registered expected set, not cargo's whole-project return code.
        log = PASS_LOG + "error: test failed, to rerun pass --lib\n"
        raw, full = fixture(log)
        full["steps"][0]["returncode"] = 101
        result = self.private(log, raw=raw, full=full)
        self.assertTrue(result["valid"])
        self.assertTrue(result["pass"])


    def test_cargo_aggregate_test_failure_is_not_a_compiler_diagnostic(self):
        log = FAIL_LOG + "error: 3 targets failed:\n"
        raw, full = fixture(log)
        full["steps"][0]["returncode"] = 101
        result = self.private(log, raw=raw, full=full)
        self.assertTrue(result["valid"])
        self.assertFalse(result["pass"])
        self.assertEqual(result["kind"], "test_failure")
        self.assertIsNone(policy.compiler_diagnostic("error: 3 targets failed:"))

    def test_test_debug_error_field_is_not_a_compiler_diagnostic(self):
        for diagnostic in ('                error: "boom",\n',
                           'error: "boom",\n',
                           'error: ordinary test message\n'):
            with self.subTest(diagnostic=diagnostic):
                log = FAIL_LOG + "---- failed test stdout ----\nGenericError {\n" + diagnostic + "}\n"
                raw, full = fixture(log)
                full["steps"][0]["returncode"] = 101
                result = self.private(log, raw=raw, full=full)
                self.assertTrue(result["valid"])
                self.assertEqual(result["kind"], "test_failure")
                self.assertIsNone(policy.compiler_diagnostic(log))

    def test_compiler_headers_need_physical_rust_diagnostic_evidence(self):
        for diagnostic in ("error[E0425]: cannot find value missing\n",
                           "\x1b[31merror[E0425]\x1b[0m: cannot find value missing\n",
                           "error: malformed expression\n --> src/main.rs:2:3\n"):
            with self.subTest(diagnostic=diagnostic):
                self.assertIsNotNone(policy.compiler_diagnostic(diagnostic))

    def test_full_step_tails_are_required_even_when_statuses_are_complete(self):
        raw, full = fixture(PASS_LOG)
        full["steps"][0]["tail"] = SIGNAL
        self.assertFalse(self.private(PASS_LOG, raw=raw, full=full)["valid"])
        for tail in ("missing", None, 123, [], True):
            with self.subTest(tail=tail):
                stripped = copy.deepcopy(full)
                if tail == "missing":
                    for step in stripped["steps"]:
                        step.pop("tail")
                else:
                    stripped["steps"][0]["tail"] = tail
                result = self.private(PASS_LOG, raw=raw, full=stripped)
                self.assertFalse(result["valid"])
                self.assertTrue(result["error"])
