import hashlib
import json
import pathlib
import subprocess
import sys

ROOT=pathlib.Path(__file__).resolve().parent
FILES=("supervision.py","paid_backend.py","test_absence.py","test_adapter_supervision.py","test_paid_backend.py")
PROGRAM="""
import hashlib,json,pathlib,sys,unittest
root=pathlib.Path(sys.argv[1]).resolve();sys.path.insert(0,str(root))
suite=unittest.defaultTestLoader.discover(str(root),pattern=sys.argv[2])
result=unittest.TextTestRunner(verbosity=2).run(suite)
import supervision
path=pathlib.Path(supervision.__file__).resolve()
data={'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
      'supervisor_file':str(path),'supervisor_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
print('DELTA_RESULT='+json.dumps(data))
sys.exit(0 if result.wasSuccessful() and path==root/'supervision.py' else 1)
"""


def sha(path):return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
def run(tree,pattern,name):
    command=[sys.executable,"-B","-c",PROGRAM,str(tree),pattern]
    result=subprocess.run(command,capture_output=True,text=True,timeout=90)
    log=ROOT/(name+".log");log.write_text(result.stdout+result.stderr)
    rows=[line.split("=",1)[1] for line in result.stdout.splitlines() if line.startswith("DELTA_RESULT=")]
    if not rows:raise ValueError("no executed suite result")
    return {"command":command,"exit_code":result.returncode,"log":str(log),"log_sha256":sha(log),"result":json.loads(rows[-1])}


def main():
    if (ROOT/"delta-verification.json").exists():raise ValueError("one delta measurement only")
    before={str(ROOT/name):sha(ROOT/name) for name in FILES}
    baselines=[run(ROOT,pattern,"baseline-"+name) for pattern,name in
               (("test_absence.py","absence"),("test_adapter_supervision.py","supervisor"),("test_paid_backend.py","backend"))]
    if any(row["exit_code"] for row in baselines):raise ValueError("delta baseline not green")
    rows=[]
    for mutation in json.loads((ROOT/"mutation_candidates.json").read_text()):
        path=ROOT/"mutations"/mutation["id"]/"supervision.py"
        original=(ROOT/"supervision.py").read_bytes()
        if path.read_bytes()!=original.replace(mutation["original"].encode(),mutation["replacement"].encode(),1):
            raise ValueError("not exact declared mutation")
        result=run(path.parent,"test_absence.py",mutation["id"])
        if result["result"]["supervisor_file"]!=str(path) or result["result"]["supervisor_sha256"]!=sha(path):
            raise ValueError("wrong mutant import")
        rows.append(dict(mutation,exact_delta=True,run=result,killed=result["exit_code"]!=0 and result["result"]["failures"]>0))
    after={str(ROOT/name):sha(ROOT/name) for name in FILES}
    survivors=[row["id"] for row in rows if not row["killed"]]
    data={"qualified":before==after and not survivors,"tested_hashes_before":before,"tested_hashes_after":after,
          "baselines":baselines,"mutations":rows,"applied":len(rows),"killed":len(rows)-len(survivors),"survivors":survivors,
          "scope":"Private compatibility delta only; unchanged fe8 product scope reuses actual full gate143"}
    (ROOT/"delta-verification.json").write_text(json.dumps(data,indent=2)+"\n")
    print(json.dumps({"qualified":data["qualified"],"suite_tests":[r["result"]["tests_run"] for r in baselines],
                     "applied":len(rows),"killed":len(rows)-len(survivors),"survivors":survivors}))
    if not data["qualified"]:raise SystemExit(1)


if __name__=="__main__":main()
