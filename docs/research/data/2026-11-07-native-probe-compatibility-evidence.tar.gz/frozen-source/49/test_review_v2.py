"""Added only after observed v1 survivors and three disposable counterexamples."""
import hashlib
import pathlib
import sqlite3
import tempfile
import unittest
from decimal import Decimal
import campaign
import real_backend
import test_campaign as fixtures
import test_real_backend as readonly_fixtures
HELPER="/home/marius/.cache/codescout-resident/codescout/semantic-contract-plugin-binding-20261106/tree_identity.py"

class ControllerReviewTests(unittest.TestCase):
    def setUp(self):
        self.case=fixtures.CampaignTests();self.case.setUp();self.addCleanup(self.case.doCleanups)
    def test_preflight_immutable_guard_before_launch(self):
        c=self.case;(pathlib.Path(c.reg["arms"][0]["out"])/"prepared.json").write_text("altered")
        with self.assertRaises(ValueError):campaign.preflight(c.regfile,c.admit,c.backend)
        self.assertEqual(c.backend.launches,[])
    def test_native_validation_call_is_required(self):
        c=self.case
        def fail(row):raise ValueError("native validator rejected")
        c.backend.validate=fail
        with self.assertRaises(ValueError):campaign.preflight(c.regfile,c.admit,c.backend)
        self.assertEqual(c.backend.launches,[])
    def test_reconciled_cost_must_equal_receipt(self):
        c=self.case;c.backend.reconcile=lambda row,receipt,reserve:Decimal("0.50")
        with self.assertRaises(ValueError):c.invoke()
        self.assertEqual(len(c.backend.launches),1)
        self.assertFalse((pathlib.Path(c.reg["arms"][0]["out"])/"cost-reconciled.json").exists())
    def test_negative_cleanup_result_stops(self):
        c=self.case;c.backend.cleanup=lambda row:{"daemon_query_succeeded":True,"independently_absent":False}
        with self.assertRaises(ValueError):c.invoke()
        self.assertEqual(len(c.backend.launches),1)
        self.assertTrue(fixtures.load(pathlib.Path(c.reg["arms"][0]["out"])/"cost-reconciled.json")["cost_known"])
    def test_same_length_candidate_drift_stops(self):
        c=self.case
        def change(index):
            if index==0:(pathlib.Path(c.reg["arms"][0]["out"])/"candidate.patch").write_bytes(b"different data")
        c.backend.change=change
        with self.assertRaises(ValueError):c.invoke()
        self.assertEqual(len(c.backend.launches),1)
    def test_workflow_flag_must_match_lifecycle_and_public_result(self):
        for value in (False,True):
            with self.subTest(flag=value):
                c=fixtures.CampaignTests();c.setUp()
                try:
                    if value:c.backend.mode="functional"
                    original=c.backend.launch
                    def launch(row,reserve,cli):
                        receipt=original(row,reserve,cli);receipt["workflow_completed"]=value
                        fixtures.save(pathlib.Path(row["out"])/"receipt.json",receipt)
                        return receipt
                    c.backend.launch=launch
                    with self.assertRaises(ValueError):c.invoke()
                    self.assertEqual(len(c.backend.launches),1)
                    self.assertTrue(fixtures.load(pathlib.Path(c.reg["arms"][0]["out"])/"cost-reconciled.json")["cost_known"])
                finally:c.doCleanups()
    def test_registration_epoch_and_admission_epoch_cannot_change(self):
        for kind in ("both","admission_only","last"):
            with self.subTest(kind=kind):
                c=fixtures.CampaignTests();c.setUp()
                try:
                    def change(index):
                        if index==(5 if kind=="last" else 0):
                            if kind!="admission_only":c.reg["prior_usd"]="0";c.bind()
                            else:
                                c.admission["note"]="new epoch";fixtures.save(c.admit,c.admission)
                    c.backend.change=change
                    with self.assertRaises(ValueError):c.invoke()
                    self.assertEqual(len(c.backend.launches),6 if kind=="last" else 1)
                    self.assertFalse((c.root/"repairs-closed.json").exists())
                    self.assertIsNone(fixtures.load(c.root/"campaign-stopped.json")["unreconciled_attempt"])
                finally:c.doCleanups()
    def test_future_sqlite_wal_changes_effective_state_without_db_hash(self):
        c=self.case;row=c.reg["arms"][5];db=pathlib.Path(row["out"])/"state.db";db.unlink()
        conn=sqlite3.connect(db)
        conn.execute("pragma journal_mode=wal");conn.execute("create table t(v)")
        conn.execute("insert into t values (1)");conn.commit();conn.close()
        old=fixtures.digest(db);row["writable_hashes"][str(db)]=old;c.bind()
        conn=sqlite3.connect(db)
        try:
            conn.execute("pragma wal_autocheckpoint=0");conn.execute("update t set v=2");conn.commit()
            self.assertEqual(fixtures.digest(db),old)
            self.assertEqual(conn.execute("select v from t").fetchone(),(2,))
            with self.assertRaises(ValueError):campaign.preflight(c.regfile,c.admit,c.backend)
            self.assertEqual(c.backend.launches,[])
        finally:conn.close()

class ReadinessReviewTests(unittest.TestCase):
    def setUp(self):
        self.fixture=readonly_fixtures.ReadonlyTests();self.fixture.setUp();self.addCleanup(self.fixture.doCleanups)
        self.plugin=self.fixture.root/"plugin";self.plugin.mkdir()
        skill=self.plugin/"SKILL.md";skill.write_bytes(b"full body")
        manifest={"plugin":str(self.plugin),"identity":{
            ".":{"kind":"directory","mode":self.plugin.stat().st_mode & 0o7777},
            "SKILL.md":{"kind":"file","mode":skill.stat().st_mode & 0o7777,"bytes":9,"sha256":hashlib.sha256(b"full body").hexdigest()}}}
        manifest_path=self.fixture.root/"plugin.json";fixtures.save(manifest_path,manifest)
        self.reg={**self.fixture.reg,"plugin_manifest":str(manifest_path),"plugin_helper":HELPER}
        self.readiness=real_backend.Readiness.__new__(real_backend.Readiness)
    def test_actual_readiness_calls_readonly_guard(self):
        (self.fixture.source/"data").write_bytes(b"changed")
        with self.assertRaises(ValueError):self.readiness.validate_shared(self.reg)
    def test_actual_readiness_calls_complete_plugin_guard(self):
        (self.plugin/"SKILL.md").write_bytes(b"bad! body")
        with self.assertRaises(ValueError):self.readiness.validate_shared(self.reg)

if __name__=="__main__":unittest.main()
