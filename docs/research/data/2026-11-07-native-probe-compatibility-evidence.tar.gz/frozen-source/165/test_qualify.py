"""Deterministic contract tests; never native qualification."""
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

HERE = Path(__file__).parent
spec = importlib.util.spec_from_file_location("qualify", HERE / "qualify.py")
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)

class RunnerTests(unittest.TestCase):
    def registration(self, root):
        p = root / "bound-input"
        p.write_text("frozen")
        return {"version": 1, "hashes": {str(p): q.sha(p)}, "floors": q.FLOORS,
                "order": q.ORDER, "tasks": {
                    name: {"image": "sha256:" + "a"*64, "f2p": ["f"], "p2p": ["p"]}
                    for name in ("NU", "RA")}}

    def test_preflight_rejects_drift_order_and_sources(self):
        with tempfile.TemporaryDirectory() as tmp:
            reg = self.registration(Path(tmp))
            q.preflight(reg)
            bad = copy.deepcopy(reg)
            bad["order"] = list(reversed(q.ORDER))
            with self.assertRaises(ValueError):
                q.preflight(bad)
            Path(next(iter(reg["hashes"]))).write_text("changed")
            with self.assertRaises(ValueError):
                q.preflight(reg)

    def test_runtime_missing_cgroup_and_oom_fail_closed(self):
        for events in ("oom_kill 1\n", "low 0\n", "oom_kill nonsense\n"):
            with self.subTest(events=events), tempfile.TemporaryDirectory() as tmp:
                backend = FakeDocker(events=events)
                mon = q.ResourceMonitor(backend, "sha256:"+"a"*64, Path(tmp)/"samples.jsonl", host=good_host)
                mon.attach("a"*64, "sab-grade-owned")
                mon.finish()
                self.assertFalse(mon.proof()["resource_ok"])
                self.assertTrue(mon.proof()["errors"])
                self.assertEqual(backend.killed, ["a"*64])

    def test_floor_violation_kills_only_owned_container(self):
        for floor in q.FLOORS:
            with self.subTest(floor=floor), tempfile.TemporaryDirectory() as tmp:
                backend = FakeDocker()
                mon = q.ResourceMonitor(backend, "sha256:"+"a"*64, Path(tmp)/"samples.jsonl",
                                        host=lambda: dict(good_host(), **{floor:0}))
                mon.attach("a"*64, "sab-grade-owned")
                mon.finish()
                self.assertFalse(mon.proof()["resource_ok"])
                self.assertEqual(backend.killed, ["a"*64])

    def test_profile_and_probe_failure_cannot_become_zero(self):
        for kwargs in ({"profile_bad":True}, {"probe_bad":True}):
            with self.subTest(kwargs=kwargs), tempfile.TemporaryDirectory() as tmp:
                backend = FakeDocker(**kwargs)
                mon = q.ResourceMonitor(backend, "sha256:"+"a"*64, Path(tmp)/"samples.jsonl",host=good_host)
                mon.attach("a"*64, "sab-grade-owned")
                mon.finish()
                self.assertFalse(mon.proof()["resource_ok"])

    def test_native_boundary_collects_two_probes_and_preserves_samples(self):
        with tempfile.TemporaryDirectory() as tmp:
            backend = FakeDocker()
            mon = q.ResourceMonitor(backend, "sha256:"+"a"*64, Path(tmp)/"samples.jsonl",host=good_host)
            mon.attach("a"*64, "sab-grade-owned")
            mon.finish()
            proof=mon.proof()
            self.assertTrue(proof["complete"])
            self.assertTrue(proof["resource_ok"])
            self.assertGreaterEqual(proof["cgroup_probes"],2)
            self.assertEqual(proof["oom_kill"],0)
            rows=[json.loads(x) for x in (Path(tmp)/"samples.jsonl").read_text().splitlines()]
            self.assertGreaterEqual(len(rows),2)
            self.assertEqual(rows[-1]["phase"],"final")
            self.assertEqual(backend.killed,[])

    def test_invalid_measurement_stops_before_second_control_and_retains_raw(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); reg=self.registration(root); calls=[]
            def attempt(label, name, task, out):
                calls.append((label,name))
                return {"raw":{"error":"probe lost"}, "policy":{"valid":False,"pass":False}}
            result=q.run(reg,root/"run",attempt)
            self.assertFalse(result["qualified"])
            self.assertEqual(calls,[("NU","negative")])
            saved=json.loads((root/"run/NU-negative/receipt.json").read_text())
            self.assertEqual(saved["raw"]["error"],"probe lost")
            self.assertTrue((root/"run/started.json").exists())
            with self.assertRaises(FileExistsError):
                q.run(reg,root/"run",attempt)

    def test_exact_six_order_gold_repeat_and_expected_statuses(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);reg=self.registration(root); calls=[]
            def attempt(label,name,task,out):
                calls.append(label+"-"+name)
                return {"raw":{"pass":name!="negative"},
                        "policy":{"valid":True,"pass":name!="negative",
                                  "statuses":{"f":"fail" if name=="negative" else "pass","p":"pass"}}}
            result=q.run(reg,root/"run",attempt)
            self.assertTrue(result["qualified"])
            self.assertEqual(calls,q.ORDER)
            self.assertEqual(len(result["rows"]),6)
            self.assertFalse(result["paid_admission"])

    def test_negative_requires_actual_complete_statuses_and_gold_must_pass(self):
        for change in ("missing", "base-pass", "gold-fail", "repeat-fail"):
            with self.subTest(change=change),tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp);reg=self.registration(root)
                def attempt(label,name,task,out):
                    statuses={"f":"fail" if name=="negative" else "pass","p":"pass"}
                    if change=="missing" and name=="negative":statuses.pop("f")
                    if change=="base-pass" and name=="negative":statuses["f"]="pass"
                    if change=="gold-fail" and name=="gold":statuses["p"]="fail"
                    if change=="repeat-fail" and name=="repeat":statuses["p"]="fail"
                    return {"raw":{}, "policy":{"valid":True,"pass":name!="negative","statuses":statuses}}
                self.assertFalse(q.run(reg,root/"run",attempt)["qualified"])

    def test_source_drift_at_boundary_stops_after_first_control(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);reg=self.registration(root);calls=[]
            def attempt(label,name,task,out):
                calls.append(name)
                Path(next(iter(reg["hashes"]))).write_text("mutated")
                return {"raw":{},"policy":{"valid":True,"pass":False,"statuses":{"f":"fail","p":"pass"}}}
            result=q.run(reg,root/"run",attempt)
            self.assertFalse(result["qualified"])
            self.assertEqual(calls,["negative"])
            self.assertEqual(len(result["rows"]),1)

    def test_registration_builder_calibrates_real_manifest_without_starting_anything(self):
        sys_path = __import__("sys").path
        sys_path.insert(0,str(HERE))
        import register
        reg=register.build()
        self.assertEqual(reg["order"],q.ORDER)
        self.assertGreaterEqual(len(reg["hashes"]),17)
        self.assertEqual(len(reg["tasks"]),2)
        self.assertTrue(q.preflight(reg))

def good_host():
    return {"root_gib":1000,"tmp_gib":20,"mem_gib":100}

class FakeDocker:
    def __init__(self,events="oom_kill 0\n",profile_bad=False,probe_bad=False):
        self.events=events;self.profile_bad=profile_bad;self.probe_bad=probe_bad;self.killed=[]
    def __call__(self,*args,**kwargs):
        from types import SimpleNamespace
        if args[0]=="inspect":
            obj={"id":"a"*64,"image":"sha256:"+"a"*64,"memory":8*1024**3,
                 "cpus":4*10**9,"network":"none","running":True,"oom":False}
            if self.profile_bad:obj["memory"]=32*1024**3
            return SimpleNamespace(returncode=0,stdout=json.dumps(obj))
        if args[0]=="exec":
            return SimpleNamespace(returncode=1 if self.probe_bad else 0,stdout=self.events)
        if args[0]=="kill":
            self.killed.append(args[1])
            return SimpleNamespace(returncode=0,stdout="")
        raise AssertionError(args)

class NativeDocker(FakeDocker):
    def __init__(self, *, final_events="oom_kill 0\n", absence="absent"):
        super().__init__()
        self.final_events=final_events
        self.absence=absence
        self.calls=[]
        self.exec_count=0
        self.removed=False
    def __call__(self,*args,**kwargs):
        from types import SimpleNamespace
        self.calls.append(args)
        if args[0]=="run":
            return SimpleNamespace(returncode=0,stdout="a"*64+"\n")
        if args[0]=="rm":
            self.removed=True
            return SimpleNamespace(returncode=0,stdout="")
        if args[0]=="ps":
            return SimpleNamespace(returncode=1 if self.absence=="daemon-error" else 0,
                                   stdout="a"*64 if self.absence=="present" else "")
        if args[0]=="inspect" and self.removed:
            return SimpleNamespace(returncode=1,stdout="No such container")
        if args[0]=="exec":
            self.exec_count+=1
            self.events="oom_kill 0\n" if self.exec_count==1 else self.final_events
        return super().__call__(*args,**kwargs)

class NativeWiringTests(unittest.TestCase):
    def setup_case(self, root, backend, *, final_host=None):
        import test_grade_policy as f
        b=root/"bundle.json";r=root/"record.json";g=root/"gold.patch"
        b.write_text(json.dumps(f.BUNDLE));r.write_text(json.dumps(f.RECORD));g.write_text("gold fixture")
        task={"bundle":str(b),"record":str(r),"gold":str(g),"image":"sha256:"+"a"*64,
              "f2p":["bin::f"],"p2p":["bin::p"]}
        def factory(record,bundle,image,gdir):
            def grade_one(patch,name):
                raw,full=f.fixture(f.PASS_LOG)
                folder=Path(gdir)/"captured"
                folder.mkdir(parents=True)
                raw.update(container="sab-grade-owned",log=str(folder/"grade.log"))
                full.update(raw)
                try:
                    q.pilot.docker("run","-d","--name","sab-grade-owned")
                finally:
                    q.pilot.docker("rm","-f","-v","sab-grade-owned")
                Path(raw["log"]).write_text(f.PASS_LOG)
                (folder/"grade.json").write_text(json.dumps(full))
                return raw
            return grade_one
        hosts=[good_host(),good_host(),final_host or good_host()]
        counter=[0]
        def host():
            i=min(counter[0],len(hosts)-1);counter[0]+=1;return hosts[i]
        return task, (mock.patch.object(q.pilot,"docker",backend),
                      mock.patch.object(q.tasks,"live_grader",side_effect=factory),
                      mock.patch.object(q,"host_sample",side_effect=host))

    def invoke(self,root,backend,*,final_host=None):
        task,patches=self.setup_case(root,backend,final_host=final_host)
        out=root/"cell";out.mkdir()
        with patches[0],patches[1],patches[2]:
            receipt=q.native_attempt("NU","gold",task,out)
        return receipt

    def test_native_call_chain_samples_before_removal_and_passes_actual_proof(self):
        with tempfile.TemporaryDirectory() as tmp:
            backend=NativeDocker()
            receipt=self.invoke(Path(tmp),backend)
            self.assertTrue(receipt["policy"]["valid"])
            self.assertTrue(receipt["policy"]["pass"])
            self.assertTrue(receipt["independently_absent"])
            self.assertEqual(receipt["runtime"]["cgroup_probes"],2)
            commands=[call[0] for call in backend.calls]
            self.assertLess(max(i for i,cmd in enumerate(commands) if cmd=="exec"),commands.index("rm"))
            samples=Path(receipt["runtime"]["samples"]).read_text().splitlines()
            self.assertEqual([json.loads(s)["phase"] for s in samples],["initial","final"])

    def test_native_absence_requires_successful_daemon_query_and_empty_result(self):
        for absence in ("present","daemon-error"):
            with self.subTest(absence=absence), tempfile.TemporaryDirectory() as tmp:
                receipt=self.invoke(Path(tmp),NativeDocker(absence=absence))
                self.assertFalse(receipt["independently_absent"])
                self.assertFalse(receipt["policy"]["valid"])
                self.assertTrue(receipt["runtime"]["errors"])

    def test_native_late_oom_group_oom_and_each_floor_reach_policy(self):
        cases=[("oom",NativeDocker(final_events="oom_kill 1\n"),None),
               ("group-oom",NativeDocker(final_events="oom_kill 0\noom_group_kill 1\n"),None)]
        cases += [(floor,NativeDocker(),dict(good_host(),**{floor:0})) for floor in q.FLOORS]
        for label,backend,host in cases:
            with self.subTest(label=label), tempfile.TemporaryDirectory() as tmp:
                receipt=self.invoke(Path(tmp),backend,final_host=host)
                self.assertFalse(receipt["policy"]["valid"])
                self.assertTrue(receipt["runtime"]["errors"])
                self.assertEqual(backend.killed,["a"*64])

    def test_invalid_native_attempt_stops_fixed_sequence_after_one_actual_wiring(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);backend=NativeDocker(final_events="oom_kill 0\noom_group_kill 1\n")
            task,patches=self.setup_case(root,backend)
            reg={"version":1,"order":q.ORDER,"floors":q.FLOORS,
                 "hashes":{task["record"]:q.sha(task["record"])},"tasks":{"NU":task,"RA":task}}
            with patches[0],patches[1],patches[2]:
                result=q.run(reg,root/"run",q.native_attempt)
            self.assertFalse(result["qualified"])
            self.assertEqual(len(result["rows"]),1)
            self.assertEqual(sum(call[0]=="run" for call in backend.calls),1)
            self.assertTrue((root/"run/NU-negative/raw.json").exists())
            self.assertFalse((root/"run/RA-negative").exists())

if __name__=="__main__": unittest.main()
