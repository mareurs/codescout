"""Fresh, non-resumable matched complete-workflow calibration; explicit paid mode only."""
import hashlib
import importlib.util
import shutil
import subprocess
import json
import os
import pathlib
import sys
import time
import uuid
from decimal import Decimal
HERE=pathlib.Path(__file__).resolve().parent
sys.path[:0]=[str(HERE.parent/"hint_authority_pilot")]
import audit
import run as worker
from core import amount,extract_result

THREAD_PRIOR=Decimal("33.571720199999999964")
THREAD_CAP=Decimal("60")
ALLOCATION=Decimal("8")
ARM_CAP=Decimal("4")

def save(path,value):
    path=pathlib.Path(path)
    temporary=path.with_name(path.name+"."+uuid.uuid4().hex+".tmp")
    with temporary.open("x") as output:
        json.dump(value,output,indent=2)
        output.write("\n")
        output.flush()
        os.fsync(output.fileno())
    os.replace(temporary,path)

def composition(root,*,files=None):
    previous=audit.L
    try:
        audit.L=pathlib.Path(root)
        legacy=audit.fingerprint()
    finally:
        audit.L=previous
    if files is None:
        files=[pathlib.Path(root)/"plan.json",HERE/"public-checks.json"]
        for name in ("agent_lifecycle","hint_authority_pilot","hint_authority_completion","hint_authority_resume","hint_authority_workflow"):
            files+=list((HERE.parent/name).glob("*.py"))
    inventory={}
    for path in sorted(map(pathlib.Path,files)):
        if path.is_symlink():
            inventory[str(path)+"#link"]=str(path.readlink())
        inventory[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
    return hashlib.sha256(json.dumps(dict(legacy=legacy,files=inventory),sort_keys=True).encode()).hexdigest()

def reconcile(out,receipt,allowance):
    sid=receipt["session_id"]
    events=[json.loads(line) for line in (out/"stream.jsonl").read_text().splitlines() if line.strip()]
    terminals=[event for event in events if event.get("type")=="result"]
    terminal=extract_result(terminals[-1:],sid)
    stdout=json.loads((out/"stdout.json").read_text())
    corroborating=extract_result(stdout if isinstance(stdout,list) else [stdout],sid)
    cost=amount(receipt["cost_usd"])
    coverage=receipt["cost_coverage"]
    forwarded=receipt["forwarded"]
    if (receipt.get("unknown_provider_cost") is not False or receipt.get("scripted") is not False
        or cost!=terminal["cost"] or cost!=corroborating["cost"]
        or cost>allowance or amount(receipt["upper_usage_cost"])>allowance
        or amount(receipt["campaign_available_usd"])!=allowance
        or type(forwarded) is not int or forwarded<0
        or coverage["forwarded_at_terminal"]!=forwarded or coverage["forwarded_total"]!=forwarded):
        raise ValueError("Unknown, inconsistent or excessive attempt cost")
    return cost

def execute_pair(root,*,check,run_cell,grade_cell,thread_remaining=THREAD_CAP-THREAD_PRIOR):
    root=pathlib.Path(root)
    if amount(thread_remaining)<ALLOCATION or THREAD_PRIOR+ALLOCATION>THREAD_CAP:
        raise ValueError("Complete pair reserve is unavailable")
    fingerprint=check()
    with (root/"started.json").open("x") as marker:
        json.dump(dict(cells=["low","xhigh"],fingerprint=fingerprint,allocation_usd=str(ALLOCATION)),marker)
    results=[]
    spent=Decimal(0)
    ledger=dict(prior_thread_cost_usd=str(THREAD_PRIOR),allocation_usd=str(ALLOCATION),results=results,cost_is_final=True)
    def persist():
        ledger.update(new_cost_usd=str(spent),thread_cost_usd=str(THREAD_PRIOR+spent))
        save(root/"results.json",ledger)
    persist()
    for index,effort in enumerate(("low","xhigh")):
        current=check()
        if current!=fingerprint:
            raise ValueError("Composition changed between arms")
        if spent+ARM_CAP>ALLOCATION:
            raise ValueError("Next arm reserve unavailable")
        label=f"workflow-{index}-{effort}"
        out=root/label
        save(root/"inflight.json",dict(attempt=label,effort=effort,state="awaiting_cost",allowance_usd=str(ARM_CAP)))
        ledger["cost_is_final"]=False
        persist()
        started=time.monotonic()
        try:
            receipt=run_cell(label,effort,ARM_CAP)
            cost=reconcile(out,receipt,ARM_CAP)
        except Exception as error:
            save(root/"halt.json",dict(attempt=label,cost_state="unknown_pending_reconciliation",
                known_prior_new_cost_usd=str(spent),reason=type(error).__name__+": "+str(error)[:500]))
            raise
        spent+=cost
        ledger["cost_is_final"]=True
        public=receipt.get("public_verification") or {}
        lifecycle=receipt.get("lifecycle") or {}
        required=json.loads((HERE/"public-checks.json").read_text())["checks"]
        observed=public.get("checks",[])
        all_checks=(len(observed)==len(required) and all(
            actual.get("id")==expected["id"] and actual.get("command")==expected["command"]
            and actual.get("exit_code")==0 for actual,expected in zip(observed,required)))
        verified=(all_checks and receipt.get("context_valid") is True and receipt.get("workflow_completed") is True and public.get("status")=="completed"
            and public.get("passed") is True and lifecycle.get("status")=="settled"
            and not receipt.get("transport_errors") and not receipt.get("cleanup_error")
            and not receipt.get("budget_stop"))
        row=dict(attempt=label,effort=effort,declaration=False,cost_usd=str(cost),
            fingerprint=fingerprint,workflow_verified=verified,accepted=False,receipt=receipt)
        results.append(row)
        persist()
        save(root/"inflight.json",dict(attempt=label,state="cost_reconciled",new_cost_usd=str(spent)))
        if receipt.get("transport_errors") or receipt.get("cleanup_error") or receipt.get("context_valid") is False:
            row["stop_reason"]="unsafe transport or cleanup"
            persist()
            break
        try:
            grade=grade_cell(label)
        except Exception as error:
            save(root/"halt.json",dict(attempt=label,cost_state="known_in_results",
                reason=type(error).__name__+": "+str(error)[:500]))
            raise
        row.update(grade=grade,accepted=verified and grade["exit_code"]==0,
            complete_wall_s=time.monotonic()-started)
        persist()
    ledger["pair_completed"]=len(results)==2
    persist()
    return ledger
def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()

def historical():
    location=HERE.parent/"hint_authority_completion/driver.py"
    spec=importlib.util.spec_from_file_location("closed_completion",location)
    previous=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(previous)
    frozen=worker.P/"launch-budget-requalification-20261104"
    spent=previous.historical_spend(worker.P/"launch-v1")
    saved=json.loads((frozen/"completion-results.json").read_text())
    if amount(saved["prior_pilot_cost_usd"])!=spent or len(saved["results"])!=2:
        raise ValueError("Closed pilot history changed")
    for index,effort in enumerate(("low","xhigh")):
        row=saved["results"][index]
        if row["effort"]!=effort or row["declaration"] is not False or row["unknown_provider_cost"] is not False:
            raise ValueError("Closed matched cell changed")
        raw=json.loads((frozen/f"completion-{index}"/"stdout.json").read_text())
        terminal=extract_result(raw if isinstance(raw,list) else [raw],row["session_id"])
        if terminal["cost"]!=amount(row["cost_usd"]):
            raise ValueError("Closed matched terminal mismatch")
        spent+=terminal["cost"]
    if spent!=amount(saved["pilot_cost_usd"]) or spent!=Decimal("2.57626490000000013"):
        raise ValueError("Closed pilot total changed")
    return spent


def aborted_history(root=None):
    root=pathlib.Path(root) if root is not None else worker.P.parent/"complete-workflow-calibration-20261105"
    ledger=json.loads((root/"results.json").read_text())
    revoked=json.loads((root/"admission-revoked.json").read_text())
    if (ledger.get("cost_is_final") is not True or len(ledger.get("results",[]))!=1
            or revoked.get("remaining_model_admission") is not False
            or (root/"workflow-1-xhigh").exists()):
        raise ValueError("Aborted workflow history is not closed and reconciled")
    row=ledger["results"][0]
    out=root/"workflow-0-low"
    receipt=json.loads((out/"receipt.json").read_text())
    cost=reconcile(out,receipt,ARM_CAP)
    if (row.get("effort")!="low" or row.get("declaration") is not False
            or receipt.get("workflow_completed") is not False or row.get("accepted") is not False
            or cost!=amount(row["cost_usd"]) or cost!=amount(ledger["new_cost_usd"])
            or amount(ledger["prior_thread_cost_usd"])!=Decimal("31.797419199999999964")
            or amount(ledger["thread_cost_usd"])!=Decimal("31.797419199999999964")+cost
            or cost!=Decimal("0.4249394")):
        raise ValueError("Aborted workflow cost or identity changed")
    return cost


def closed_recovery_history(root=None):
    root=pathlib.Path(root) if root is not None else worker.P.parent/"complete-workflow-cold-recovery-20261105"
    ledger=json.loads((root/"results.json").read_text())
    if (ledger.get("cost_is_final") is not True or ledger.get("pair_completed") is not True
            or len(ledger.get("results",[]))!=2):
        raise ValueError("Closed recovery pair is not fully reconciled")
    spent=Decimal(0)
    for index,effort in enumerate(("low","xhigh")):
        row=ledger["results"][index]
        out=root/f"workflow-{index}-{effort}"
        receipt=json.loads((out/"receipt.json").read_text())
        cost=reconcile(out,receipt,ARM_CAP)
        if row.get("effort")!=effort or row.get("declaration") is not False or cost!=amount(row["cost_usd"]):
            raise ValueError("Closed recovery arm cost or identity changed")
        spent+=cost
    prior=Decimal("32.222358599999999964")
    if (amount(ledger["prior_thread_cost_usd"])!=prior or spent!=amount(ledger["new_cost_usd"])
            or amount(ledger["thread_cost_usd"])!=prior+spent or spent!=Decimal("1.3493616")):
        raise ValueError("Closed recovery pair ledger changed")
    return spent

def registration():
    old=historical()
    aborted=aborted_history()
    recovery=closed_recovery_history()
    if Decimal("29.221154299999999834")+old+aborted+recovery!=THREAD_PRIOR:
        raise ValueError("Prior thread ledger changed")
    return dict(schema=3,cells=[["low",False],["xhigh",False]],
        allocation_usd=str(ALLOCATION),arm_cap_usd=str(ARM_CAP),
        thread_prior_usd=str(THREAD_PRIOR),thread_cap_usd=str(THREAD_CAP),
        old_pilot_spent_usd=str(old),aborted_workflow_spent_usd=str(aborted),
        closed_recovery_spent_usd=str(recovery),
        public_manifest_sha256=digest(HERE/"public-checks.json"),
        image=worker.IMAGE,max_turns=None,output_tokens=8192,
        scope="Exposed task, cost/time-bounded complete-workflow calibration; no transfer or authority-effect estimate")

def check(root):
    root=pathlib.Path(root)
    if json.loads((root/"plan.json").read_text())!=registration():
        raise ValueError("Changed registered campaign")
    current=composition(root)
    review=json.loads((root/"review.json").read_text())
    qualification=json.loads((root/"qualification.json").read_text())
    controls=json.loads((root/"acceptance-controls.json").read_text())
    cold=json.loads((root/"cold-public-control.json").read_text())
    profile=json.loads((HERE/"public-checks.json").read_text())
    if (review.get("accepted") is not True or review.get("fingerprint")!=current
        or review.get("qualification_sha256")!=digest(root/"qualification.json")
        or review.get("acceptance_sha256")!=digest(root/"acceptance-controls.json")
        or review.get("cold_control_sha256")!=digest(root/"cold-public-control.json")):
        raise ValueError("Unreviewed composition or control proofs")
    if (qualification.get("qualified") is not True or qualification.get("cli_budget_usd")!="4"
        or qualification.get("provider_cost_usd")!="0"
        or qualification.get("cells")!=["low:success","low:repair","low:unknown","xhigh:success"]):
        raise ValueError("Missing intended CLI/native qualifications")
    for path,want in qualification["runtime_hashes"].items():
        if digest(path)!=want:raise ValueError("Qualified runtime changed")
    if (controls.get("baseline_rejected") is not True or controls.get("reference_accepted") is not True
        or controls.get("oracle_version")!=2):
        raise ValueError("Invalid private acceptance controls")
    if (cold.get("qualified") is not True or cold.get("cold_target") is not True
            or cold.get("cpu_quota")!=4 or cold.get("memory_bytes")!=12*1024**3
            or cold.get("workflow_timeout_s")!=profile["timeout_s"]
            or cold.get("check_timeout_s")!=profile["check_timeout_s"]
            or cold.get("provider_cost_usd")!="0" or cold.get("public_passed") is not True
            or cold.get("cleanup_absent") is not True or cold.get("public_checks")!=profile["checks"]
            or set(cold.get("actual_logs",{}))!={check["id"] for check in profile["checks"]}):
        raise ValueError("Missing matching cold public resource/deadline proof")
    for log in cold["actual_logs"].values():
        if digest(log["path"])!=log["sha256"]:
            raise ValueError("Cold public log evidence changed")
    return current

def prepare_root(root):
    root=pathlib.Path(root)
    root.mkdir()
    sys.path.insert(0,str(HERE.parent/"agent_lifecycle"))
    from workflow import prepare_actor
    prepare_actor(root)
    frozen=worker.P/"launch-budget-requalification-20261104"
    for name in ("source","skill-only-plugin"):
        shutil.copytree(frozen/name,root/name)
    shutil.copyfile(frozen/"reference.patch",root/"reference.patch")
    save(root/"plan.json",registration())
    return root

def paid(root):
    import prepare
    root=pathlib.Path(root)
    config=json.loads((HERE/"public-checks.json").read_text())
    def run_cell(label,effort,allowance):
        worker.L=root
        receipt=worker.one(label,effort,False,False,campaign_remaining=allowance,
            workflow=config,client_budget_usd="4")
        from core import audit_request
        out=root/label
        expected=json.loads((out/"expected.json").read_text())
        requests=list(out.glob("request-*.json"))
        context_error=None
        try:
            if not requests:raise ValueError("No observed model requests")
            for path in requests:
                audit_request(json.loads(path.read_text()),expected)
        except Exception as exc:
            context_error=type(exc).__name__+": "+str(exc)
        save(out/"context-audit.json",dict(valid=context_error is None,requests=len(requests),error=context_error))
        return dict(receipt,context_valid=context_error is None)
    def grade_cell(label):
        prepare.L=root
        actor=root/label/"project"
        destination=root/(label+"-grader")
        shutil.copytree(actor,destination,ignore=shutil.ignore_patterns(".git","target"))
        return prepare.grade(destination,"wfc-"+root.name+"-"+label)
    return execute_pair(root,check=lambda:check(root),run_cell=run_cell,grade_cell=grade_cell)

def main():
    if len(sys.argv)!=3 or sys.argv[1] not in {"--prepare","--check","--paid"}:
        raise ValueError("Choose --prepare, --check or --paid and an exclusive root")
    mode,root=sys.argv[1],pathlib.Path(sys.argv[2]).resolve()
    if mode=="--prepare":
        prepare_root(root)
        print(json.dumps(dict(prepared=True,paid_admitted=False,root=str(root))))
    elif mode=="--check":
        print(json.dumps(dict(fingerprint=check(root),provider_calls=0)))
    else:
        print(json.dumps(paid(root)),flush=True)

if __name__=="__main__":
    main()
