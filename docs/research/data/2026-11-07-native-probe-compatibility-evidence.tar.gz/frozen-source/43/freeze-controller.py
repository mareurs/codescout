"""Source-bound read-only preflight. No production launch adapter is provided."""
import datetime
import json
import pathlib
import shutil
import sys
from decimal import Decimal
import campaign
import real_backend
ROOT=pathlib.Path(__file__).parent
BASE=ROOT.parent
SOURCE=pathlib.Path("/home/marius/work/claude/codescout/.worktrees/semantic-contract-runtime-01a15ca9")

def main():
    dest=ROOT if len(sys.argv)==1 else pathlib.Path(sys.argv[1])
    dest.mkdir(parents=True,exist_ok=True)
    if (dest/"registration.json").exists():raise ValueError("Refuse registration overwrite")
    plugin_root=BASE/"semantic-contract-plugin-binding-20261106"
    plugin_manifest=plugin_root/"plugin-inputs-before.json"
    original=campaign.load(BASE/"semantic-contract-runtime-20261106/prepared/prepared-manifests.json")["arms"]
    sources=[p for folder in ("agent_lifecycle","hint_authority_pilot","hint_authority_workflow") for p in sorted((SOURCE/"tools"/folder).rglob("*.py"))]
    sources+=sorted(ROOT.glob("*.py"))
    sources.append(plugin_root/"tree_identity.py")
    shared={str(p):campaign.digest(p) for p in sources}
    evidence={
      "runtime_wire":pathlib.Path("/home/marius/work/claude/codescout/docs/research/data/2026-11-06-semantic-contract-wire-evidence.tar.gz.json"),
      "plugin":pathlib.Path("/home/marius/work/claude/codescout/docs/research/data/2026-11-06-semantic-contract-plugin-binding-evidence.tar.gz.json")}
    for p in [plugin_manifest,BASE/"semantic-contract-runtime-20261106/prepared/prepared-manifests.json",
              BASE/"semantic-contract-pilot-20261106/matrix.json",BASE/"semantic-contract-pilot-20261106/protocol.txt",
              BASE/"external-matched-repairs-20261105/native-readonly-inputs.json"]+list(evidence.values()):
        shared[str(p)]=campaign.digest(p)
    prior_path=BASE/"external-matched-repairs-20261105/repairs-closed.json"
    prior=campaign.load(prior_path)["known_series_subtotal_usd"]
    if Decimal(prior)!=Decimal("58.180531399999999104"):raise ValueError("Known prior series differs")
    shared[str(prior_path)]=campaign.digest(prior_path)
    for p in sorted((BASE/"external-matched-repairs-20261105").glob("*/cost-reconciled.json")):
        shared[str(p)]=campaign.digest(p)
    arms=[]
    for row in original:
        out=pathlib.Path(row["out"])
        if any((out/name).exists() for name in ("started.json","launch.json","receipt.json","cost-reconciled.json")):
            raise ValueError("Real arm already attempted")
        if campaign.digest(out/"prepared.json")!=row["prepared_sha256"] or campaign.digest(out/"input-clone-manifest.json")!=row["clone_manifest_sha256"]:
            raise ValueError("Frozen configuration drift")
        clones=campaign.load(out/"input-clone-manifest.json")["files"]
        writable={};immutable={}
        for p in out.rglob("*"):
            if not p.is_file():continue
            relative=p.relative_to(out).as_posix()
            digest=campaign.digest(p)
            if relative in clones and digest!=clones[relative]["sha256"]:raise ValueError("Clone drift")
            target=writable if relative in clones and p.relative_to(out).parts[0] in {"knowledge","native-home","member-state"} else immutable
            target[str(p)]=digest
        cfg=campaign.load(out/"prepared.json")
        immutable.update(cfg["files"])
        for name,digest in immutable.items():
            if campaign.digest(name)!=digest:raise ValueError("Immutable input drift")
        arms.append({**row,"immutable_hashes":immutable,"writable_hashes":writable,
                     "writable_roots":[str(out/name) for name in ("knowledge","native-home","member-state")]})
    reg={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"stage":"controller-preflight-only","arms":arms,
         "qualified_source":str(SOURCE),"shared_hashes":shared,"prior_usd":prior,"ceiling_usd":"200","reserve_usd":"20","cli_cap_usd":"19",
         "plugin_manifest":str(plugin_manifest),"plugin_helper":str(plugin_root/"tree_identity.py"),
         "readonly_manifest":str(BASE/"external-matched-repairs-20261105/native-readonly-inputs.json"),
         "previous_job_records":["/tmp/codescout-bg/455879-a720241d-bg_0000010e.json","/tmp/codescout-bg/455879-a720241d-bg_00000117.json"],
         "provider_calls":0,"launch_admitted":False}
    campaign.save(dest/"registration.json",reg,exclusive=True)
    proofs={name:{"qualified":False,"reason":"Pending reviewed committed grader/live policy/new controls/controller integration"} for name in campaign.GATES}
    for name,p in evidence.items():proofs[name]={"qualified":True,"path":str(p),"sha256":campaign.digest(p)}
    admission={"repair_admitted":False,"registration_sha256":campaign.digest(dest/"registration.json"),"proofs":proofs}
    campaign.save(dest/"admission-pending.json",admission,exclusive=True)
    backend=real_backend.Readiness(reg)
    campaign.check_hashes(shared);backend.validate_shared(reg)
    for row in arms:
        campaign.check_hashes(row["immutable_hashes"]);campaign.check_hashes(row["writable_hashes"])
        campaign.future_population(row)
        backend.validate(row)
    resources=backend.resources(arms[0]);campaign.resource_check(resources)
    # Exercise the actual gate, expecting an explicit refusal with no actor side effects.
    try:campaign.preflight(dest/"registration.json",dest/"admission-pending.json",backend)
    except ValueError as exc:
        reason=str(exc)
        if not reason.startswith("Paid admission false; missing prerequisites:"):raise
    else:raise ValueError("Pending admission unexpectedly accepted")
    campaign.check_hashes(shared)
    for row in arms:
        campaign.check_hashes(row["immutable_hashes"]);campaign.check_hashes(row["writable_hashes"])
        if any((pathlib.Path(row["out"])/name).exists() for name in ("started.json","launch.json","receipt.json")):
            raise ValueError("Unexpected actor side effect")
    backup=dest/"source-v1";backup.mkdir()
    for index,p in enumerate(sources):shutil.copyfile(p,backup/(str(index).zfill(3)+"-"+p.name))
    result={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"real_native_configs_validated":len(arms),
            "immutable_hash_records":sum(len(r["immutable_hashes"]) for r in arms),
            "writable_hash_records":sum(len(r["writable_hashes"]) for r in arms),"shared_hash_records":len(shared),
            "readonly":backend.readonly,"resources":resources,"prospective_gate_observed":"rejected","reason":reason,
            "no_real_arm_started":True,"provider_calls":0,"credential_reads":0,"onboarding_calls":0,
            "paid_launch_adapter_present":False,"launch_admitted":False}
    campaign.save(dest/"preflight.json",result,exclusive=True);print(json.dumps(result,indent=2))
if __name__=="__main__":main()
