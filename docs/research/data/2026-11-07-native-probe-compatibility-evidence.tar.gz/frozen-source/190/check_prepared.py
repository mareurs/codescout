"""Read-only readiness of the NEW common fixture; no launch or credential."""
import json
import pathlib
import time
from paid_backend import PaidBackend
from supervision import FLOORS
import campaign

ROOT=pathlib.Path(__file__).resolve().parent


def main():
    reg=campaign.load(ROOT/"common-registration-unfrozen.json")
    backend=PaidBackend(reg)
    backend.validate_shared(reg)
    for row in reg["arms"]:
        campaign.check_hashes(row["immutable_hashes"])
        campaign.check_hashes(row["writable_hashes"])
        backend.validate(row)
    resources=backend.resources(reg["arms"][0])
    campaign.resource_check(resources)
    real=campaign.load(ROOT/"real-inputs-before.json")
    files={}
    for hashes in real.values():
        campaign.check_hashes(hashes)
        files.update(hashes)
    campaign.save(ROOT/"common-readiness-unstarted.json",{"unix":time.time(),
        "prepared_valid":True,"readonly":backend.readonly,"resources":resources,
        "protected_real_unique_paths":len(files),"launch_admitted":False,
        "provider_calls":0,"credential_reads":0,
        "limits":"Prepared fixture/read-only/image/resource checks only. Original source review, gate, commit and fresh freeze still required."})
    print(json.dumps({"prepared_valid":True,"protected_real_unique_paths":len(files),"launch_admitted":False}))


if __name__=="__main__":main()
