import json
import pathlib
import tempfile
import types
import unittest

import supervision
from test_adapter_supervision import Docker,HEALTHY,POLICY,IMAGE,NAME,CID

MISSING="hfa-native-"+"a"*32


class AbsenceTests(unittest.TestCase):
    def prepare(self,root,stderr,*,live=True):
        backend=Docker()
        (root/("mcp-launch-"+MISSING+".json")).write_text(json.dumps({"name":MISSING}))
        if live:(root/("mcp-launch-"+NAME+".json")).write_text(json.dumps({"name":NAME}))
        def docker(args):
            if args==["inspect",MISSING]:
                return types.SimpleNamespace(returncode=1,stdout="[]\n",stderr=stderr)
            return backend(args)
        obj=supervision.Supervisor(POLICY,host=lambda:dict(HEALTHY),docker=docker,interval=100)
        obj.bind(out=root,image=IMAGE,server=types.SimpleNamespace())
        self.addCleanup(obj.stop_monitor)
        return obj,backend

    def rows(self,root):
        path=root/"native-inspections.jsonl"
        self.assertTrue(path.is_file(),"actual inspect diagnostics were not preserved")
        return [json.loads(line) for line in path.read_text().splitlines()]

    def test_known_absence_cases_skip_only_stale_name_and_pin_live_worker(self):
        for stderr in ("error: no such object: "+MISSING+"\n",
                       "Error: No such object: "+MISSING+"\n",
                       "Error response from daemon: No such container: "+MISSING+"\n"):
            with self.subTest(stderr=stderr),tempfile.TemporaryDirectory() as d:
                root=pathlib.Path(d);obj,docker=self.prepare(root,stderr)
                failure=None
                try:obj.before_public()
                except ValueError as exc:failure=str(exc)
                self.assertIsNone(failure,"a recognized stale discovery name blocked the live worker")
                self.assertEqual(obj.cid,CID)
                rows=self.rows(root)
                missing=[row for row in rows if row["name"]==MISSING]
                self.assertEqual(missing[0]["stderr"],stderr)
                self.assertEqual(missing[0]["exit_code"],1)
                self.assertEqual(missing[0]["stdout"],"[]\n")
                self.assertFalse(any(args[0]=="kill" for args in docker.calls))

    def test_all_absent_optional_discovery_is_not_an_error_but_public_requires_worker(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);obj,_=self.prepare(root,"error: no such object: "+MISSING+"\n",live=False)
            failure=None
            try:result=obj.identify(required=False)
            except ValueError as exc:failure=str(exc);result="failed"
            self.assertIsNone(failure)
            self.assertIsNone(result)
            with self.assertRaisesRegex(ValueError,"native worker missing"):obj.before_public()
            self.assertIsNone(obj.cid)
            self.assertTrue(self.rows(root))

    def test_unknown_errors_and_wrong_target_are_not_normal_absence(self):
        errors=("permission denied", "Cannot connect to Docker daemon: No such file or directory",
                "error: no such object: hfa-native-"+"d"*32+"\n", "opaque daemon failure")
        for stderr in errors:
            with self.subTest(stderr=stderr),tempfile.TemporaryDirectory() as d:
                root=pathlib.Path(d);obj,docker=self.prepare(root,stderr,live=False)
                with self.assertRaisesRegex(ValueError,"identity probe failed"):
                    obj.identify(required=False)
                self.assertIsNone(obj.cid)
                self.assertEqual(self.rows(root)[0]["stderr"],stderr)
                self.assertFalse(any(args[0]=="kill" for args in docker.calls))

    def test_successful_inspect_raw_diagnostics_precede_profile_validation(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);docker=Docker()
            (root/("mcp-launch-"+NAME+".json")).write_text(json.dumps({"name":NAME}))
            docker.info["Config"]["Labels"]={}
            obj=supervision.Supervisor(POLICY,host=lambda:dict(HEALTHY),docker=docker,interval=100)
            obj.bind(out=root,image=IMAGE,server=types.SimpleNamespace());self.addCleanup(obj.stop_monitor)
            with self.assertRaisesRegex(ValueError,"label"):obj.before_public()
            rows=self.rows(root)
            self.assertEqual(json.loads(rows[0]["stdout"])[0]["Id"],CID)
            self.assertEqual(rows[0]["exit_code"],0)
            self.assertIsNone(obj.cid)


if __name__=="__main__":unittest.main()
