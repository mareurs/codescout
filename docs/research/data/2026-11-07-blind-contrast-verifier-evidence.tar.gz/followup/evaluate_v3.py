"""Execute frozen verifier additions; never sends outcomes to an actor."""
import hashlib
import importlib.util
import json
import pathlib
import re
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent
BASE = ROOT.parent
POLICY_ROOT = BASE / "semantic-contract-policy-v2-20261107"
sys.path.insert(0, str(POLICY_ROOT))
# Load by path because the actor adapter has a different module named qualify.
spec = importlib.util.spec_from_file_location("closed_grade_runtime", POLICY_ROOT / "qualify.py")
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)

def load(path):
    return json.loads(pathlib.Path(path).read_text())

def sha(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()

def save(path, value):
    with pathlib.Path(path).open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")

def docker(*args, check=True, timeout=60):
    return subprocess.run(["docker", *args], check=check, timeout=timeout,
                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)

def segments(raw):
    result = {}
    for part in raw.split(b"diff --git ")[1:]:
        header, _ = part.split(b"\n", 1)
        match = re.fullmatch(rb"a/([A-Za-z0-9_./-]+) b/([A-Za-z0-9_./-]+)", header)
        assert match and match[1] == match[2], "Unexpected patch header"
        path = match[1].decode()
        assert path not in result
        result[path] = b"diff --git " + part
    return result

def freeze():
    closed = load(ROOT / "verifier-closed.json")
    assert closed["status"] == "closed"
    out = ROOT / "verifier"
    assert sha(out / "candidate.patch") == closed["generated_candidate_sha256"]
    reg = load(ROOT / "registration.json")
    known = BASE / "blind-contrast-verifier-20261107/image-context/candidate.patch"
    original = segments(known.read_bytes())
    generated = segments((out / "candidate.patch").read_bytes())
    assert all(generated.get(k) == v for k, v in original.items()), "Verifier altered the production proposal"
    tests = {k: v for k, v in generated.items() if k not in original}
    assert tests and all(k.startswith("crates/nu-cli/tests/") and k.endswith(".rs") for k in tests), "Verifier changed non-test paths"
    assert all(not any(line.startswith(b"-") and not line.startswith(b"---") for line in part.splitlines()) for part in tests.values()), "Existing test code removed"
    raw = b"".join(tests.values())
    names = re.findall(rb"(?m)^\+fn (contrast_[A-Za-z0-9_]+)\(", raw)
    assert names and len(names) == len(set(names)), "Missing or duplicate named contrast assertions"
    test_patch = ROOT / "generated-tests.patch"
    test_patch.write_bytes(raw)
    runtime = BASE / "semantic-contract-runtime-20261106/prepared/arms"
    variants = [
        ("baseline", None),
        ("low-control", runtime / "nushell__nushell-18863--low-control/candidate.patch"),
        ("low-contract", runtime / "nushell__nushell-18863--low-contract/candidate.patch"),
        ("xhigh-control", runtime / "nushell__nushell-18863--xhigh-control/candidate.patch"),
        ("reference", pathlib.Path("/home/marius/work/claude/setup-ab-data/fresh-tasks/nushell__nushell-18863/build/gold.patch")),
    ]
    frozen = {
        "question": reg["question"], "image": reg["base_image"],
        "tests": [n.decode() for n in names], "test_paths": list(tests),
        "test_patch_sha256": sha(test_patch), "candidate_capture_sha256": sha(out / "candidate.patch"),
        "verifier_closed_sha256": sha(ROOT / "verifier-closed.json"),
        "registration_sha256": sha(ROOT / "registration.json"),
        "variants": [{"label": label, "patch": str(p) if p else None, "sha256": sha(p) if p else None} for label, p in variants],
        "evaluator_sha256": sha(__file__),
        "boundary": "Verifier ended before this evaluator read or mounted reference input. No private test patch is executed.",
    }
    save(ROOT / "evaluation-registration.json", frozen)
    return frozen

def calibration():
    # Validate the reused real parser on a known closed full log before using it on new names.
    old = POLICY_ROOT / "saved-grades/nushell__nushell-18863--xhigh-control"
    receipt = load(old / "receipt.json")
    log = pathlib.Path(receipt["raw"]["log"]).read_text()
    record = load("/home/marius/work/claude/setup-ab-data/fresh-tasks/nushell__nushell-18863/build/record.json")
    observed = q.grade.run_parser(record["log_parser"], log)
    expected = receipt["policy"]["statuses"]
    assert all(observed.get(k) == v for k, v in expected.items())
    save(ROOT / "parser-calibration.json", {"selected_keys": len(expected), "all_selected_equal": True,
         "parser_sha256": hashlib.sha256(record["log_parser"].encode()).hexdigest(), "log_sha256": sha(receipt["raw"]["log"])})
    return record["log_parser"]

def cell(reg, row, parser):
    folder = ROOT / ("evaluation-v3-" + row["label"])
    folder.mkdir()
    name = "sab-grade-contrast-v3-01a15ca9-" + row["label"]
    started = time.monotonic()
    monitor = q.ResourceMonitor(docker, reg["image"], folder / "resource-samples.jsonl")
    cid = None
    steps = []
    error = None
    statuses = {}

    def apply(path, label):
        # stdin reaches the running mount namespace; Docker cp to tmpfs does not here.
        for operation in ("check", "apply"):
            args = ["docker", "exec", "-i", cid, "git", "apply"]
            if operation == "check":
                args.append("--check")
            args.append("-")
            log = folder / (label + "-" + operation + ".log")
            with pathlib.Path(path).open("rb") as source, log.open("wb") as stream:
                result = subprocess.run(args, stdin=source, stdout=stream, stderr=subprocess.STDOUT, timeout=60)
            if result.returncode:
                raise RuntimeError(label + " " + operation + " failed: " + log.read_text()[-1000:])

    try:
        p = docker("run", "-d", "--init", "--pull=never", "--name", name, "--label", "codescout.contrast=" + name,
                   "--network=none", "--cpus=4", "--memory=8g", "--memory-swap=8g", "--pids-limit=4096",
                   "--tmpfs", "/tmp:rw,exec,size=4g,uid=1000,gid=1000", "--user=1000:1000",
                   "--workdir=/testbed", "--entrypoint=/bin/sleep", reg["image"], "infinity")
        cid = p.stdout.strip()
        monitor.attach(cid, name)
        assert not monitor.errors
        if row["patch"]:
            assert sha(row["patch"]) == row["sha256"]
            apply(row["patch"], "repair")
        assert sha(ROOT / "generated-tests.patch") == reg["test_patch_sha256"]
        apply(ROOT / "generated-tests.patch", "contrast")
        commands = [
            ["cargo", "build", "--offline", "--bin", "nu"],
            ["cargo", "test", "--offline", "-p", "nu-cli", "contrast_", "--", "--nocapture"],
        ]
        for index, command in enumerate(commands):
            path = folder / (str(index) + ".log")
            with path.open("wb") as stream:
                result = subprocess.run(["docker", "exec", cid, *command], stdout=stream, stderr=subprocess.STDOUT, timeout=1800)
            steps.append({"command": command, "exit_code": result.returncode, "log": str(path), "sha256": sha(path)})
            if index == 0 and result.returncode:
                raise RuntimeError("Build failed; no assertion outcome")
        log = pathlib.Path(steps[-1]["log"]).read_text()
        statuses = q.grade.run_parser(parser, log)
        selected = {}
        for test in reg["tests"]:
            matches = [k for k in statuses if k.split("::")[-1] == test]
            assert len(matches) == 1, "Missing or ambiguous named assertion: " + test
            assert statuses[matches[0]] in ("pass", "fail"), "Skipped assertion"
            selected[test] = statuses[matches[0]]
        assert (steps[-1]["exit_code"] == 0) if all(v == "pass" for v in selected.values()) else (steps[-1]["exit_code"] in (1, 101))
        statuses = selected
    except BaseException as exc:
        error = type(exc).__name__ + ": " + str(exc)
        if isinstance(exc, subprocess.CalledProcessError):
            error += "\n" + str(exc.stdout)[-2000:]
    finally:
        if cid:
            monitor.finish()
            removal = docker("rm", "-f", cid, check=False)
            absent = docker("ps", "-a", "--no-trunc", "--filter", "id=" + cid, "--format", "{{.ID}}")
            save(folder / "absence.json", {"container": cid, "remove_exit": removal.returncode, "absent": not absent.stdout.strip()})
    proof = monitor.proof()
    valid = error is None and proof["complete"] and proof["resource_ok"] and proof["oom_kill"] == 0
    result = {"label": row["label"], "valid": valid, "error": error, "statuses": statuses, "steps": steps,
              "runtime": proof, "wall_seconds": time.monotonic() - started}
    save(folder / "result.json", result)
    return result

def main():
    assert not (ROOT / "evaluation-v3-registration.json").exists()
    reg = load(ROOT / "evaluation-registration.json")
    assert sha(ROOT / "generated-tests.patch") == reg["test_patch_sha256"]
    assert sha(ROOT / "verifier/candidate.patch") == reg["candidate_capture_sha256"]
    record = load("/home/marius/work/claude/setup-ab-data/fresh-tasks/nushell__nushell-18863/build/record.json")
    parser = record["log_parser"]
    calibrated = load(ROOT / "parser-calibration.json")
    assert calibrated["all_selected_equal"] is True and calibrated["selected_keys"] == 8622
    assert hashlib.sha256(parser.encode()).hexdigest() == calibrated["parser_sha256"]
    prior = load(ROOT / "evaluation-v2-baseline/result.json")
    assert prior["error"] == "AssertionError: " and prior["valid"] is False
    assert prior["steps"][0]["exit_code"] == 0 and prior["steps"][1]["exit_code"] == 1
    assert prior["runtime"]["complete"] and prior["runtime"]["resource_ok"] and prior["runtime"]["oom_kill"] == 0
    log = pathlib.Path(prior["steps"][1]["log"]).read_text()
    assert sha(prior["steps"][1]["log"]) == prior["steps"][1]["sha256"]
    assert "test result: FAILED. 1 passed; 1 failed;" in log
    parsed = q.grade.run_parser(parser, log)
    selected = {}
    for test in reg["tests"]:
        keys = [k for k in parsed if k.split("::")[-1] == test]
        assert len(keys) == 1 and parsed[keys[0]] in ("pass", "fail")
        selected[test] = parsed[keys[0]]
    assert list(selected.values()) == ["pass", "fail"]
    baseline = dict(prior, valid=True, error=None, statuses=selected)
    save(ROOT / "baseline-readjudication.json", baseline)
    save(ROOT / "evaluation-v3-registration.json", {
        "frozen_original_registration_sha256": sha(ROOT / "evaluation-registration.json"),
        "evaluator_sha256": sha(__file__), "unchanged_test_patch_sha256": reg["test_patch_sha256"],
        "change": "Admit observed ordinary failure exit 1 with complete named assertion evidence; reuse saved baseline, no rerun",
        "baseline_original_result_sha256": sha(ROOT / "evaluation-v2-baseline/result.json"),
        "baseline_readjudicated_sha256": sha(ROOT / "baseline-readjudication.json"),
        "source_hashes": {str(p): sha(p) for p in (POLICY_ROOT / "qualify.py", q.TOOLS / "multilang_grade.py")},
        "model_calls": 0,
    })
    rows = [baseline]
    for row in reg["variants"][1:]:
        result = cell(reg, row, parser)
        rows.append(result)
        save(ROOT / ("progress-" + row["label"] + ".json"), result)
        if not result["valid"]:
            break
    save(ROOT / "evaluation-v3-results.json", {
        "rows": rows, "all_five_valid": len(rows) == 5 and all(r["valid"] for r in rows),
        "provider_calls": 0, "frozen_test_patch_sha256": reg["test_patch_sha256"],
        "baseline_native_rerun": False,
        "claim_scope": "One exposed development task; no population efficacy estimate"})
    print(json.dumps(load(ROOT / "evaluation-v3-results.json"), indent=2))

if __name__ == "__main__":
    main()
