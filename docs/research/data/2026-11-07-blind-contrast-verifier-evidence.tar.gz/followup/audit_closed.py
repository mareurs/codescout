"""Recompute assertion cells from logs and preserve a bounded, credential-free evidence bundle."""
import hashlib
import importlib.util
import json
import pathlib
import subprocess
import sys
import tarfile

ROOT = pathlib.Path(__file__).resolve().parent
BASE = ROOT.parent
sys.path.insert(0, str(ROOT))
import evaluate_v3 as ev

def check_final_binding():
    binding = ev.load(ROOT / "evaluation-final-registration.json")
    assert ev.sha(ROOT / "continue_evaluation.py") == binding["continuation_sha256"]
    assert ev.sha(ROOT / "evaluate_v3.py") == binding["evaluator_sha256"]
    assert ev.sha(ROOT / "evaluation-registration.json") == binding["original_registration_sha256"]
    assert ev.sha(ROOT / "generated-tests.patch") == binding["test_patch_sha256"]
    assert ev.sha(ROOT / "evaluation-v3-xhigh-control/result.json") == binding["preserved_resource_invalid_result_sha256"]
    return binding


def main():
    check_final_binding()
    result = ev.load(ROOT / "evaluation-final-results.json")
    reg = ev.load(ROOT / "evaluation-registration.json")
    assert result["all_five_valid"] is True
    assert result["frozen_test_patch_sha256"] == reg["test_patch_sha256"] == ev.sha(ROOT / "generated-tests.patch")
    assert ev.sha(ROOT / "verifier/candidate.patch") == reg["candidate_capture_sha256"]
    binding = ev.load(ROOT / "evaluation-v3-registration.json")
    assert ev.sha(ROOT / "evaluate_v3.py") == binding["evaluator_sha256"]
    for path, expected in binding["source_hashes"].items():
        assert ev.sha(path) == expected
    record = ev.load("/home/marius/work/claude/setup-ab-data/fresh-tasks/nushell__nushell-18863/build/record.json")
    live = set(subprocess.check_output(["docker", "ps", "-a", "--no-trunc", "--format", "{{.ID}}"], text=True).splitlines())
    observed = []
    for row in result["rows"]:
        folder = pathlib.Path(row["runtime"]["samples"]).parent
        assert ev.load(ROOT / "baseline-readjudication.json" if row["label"] == "baseline" else folder / "result.json") == row
        assert row["valid"] is True and row["error"] is None
        assert row["runtime"]["container"] not in live
        assert ev.load(folder / "absence.json")["absent"] is True
        samples = [json.loads(line) for line in pathlib.Path(row["runtime"]["samples"]).read_text().splitlines()]
        assert samples[0]["phase"] == "initial" and samples[-1]["phase"] == "final"
        assert len(samples) == row["runtime"]["cgroup_probes"]
        assert all("error" not in s and s["memory_events"]["oom_kill"] == 0 and s["memory_events"].get("oom_group_kill", 0) == 0 for s in samples)
        assert all(all(s["host"][key] >= floor for key, floor in ev.q.FLOORS.items()) for s in samples)
        for step in row["steps"]:
            assert ev.sha(step["log"]) == step["sha256"]
        actual = ev.q.grade.run_parser(record["log_parser"], pathlib.Path(row["steps"][-1]["log"]).read_text())
        selected = {}
        for test in reg["tests"]:
            keys = [k for k in actual if k.split("::")[-1] == test]
            assert len(keys) == 1
            selected[test] = actual[keys[0]]
        assert selected == row["statuses"]
        observed.append({"variant": row["label"], "statuses": selected, "all_pass": all(v == "pass" for v in selected.values()),
                         "wall_seconds": row["wall_seconds"], "cgroup_probes": len(samples)})
    summary = {
        "task_role": "one_exposed_development_control",
        "tests": reg["tests"], "rows": observed,
        "wrong_patches_rejected": sum(not r["all_pass"] for r in observed if r["variant"] in ("low-control", "low-contract", "xhigh-control")),
        "wrong_patch_variants": 3, "reference_retained": next(r["all_pass"] for r in observed if r["variant"] == "reference"),
        "verifier_cost_usd": ev.load(ROOT / "verifier-closed.json")["cost_usd"],
        "invalid_attempt_cost_usd": ev.load(BASE / "blind-contrast-verifier-20261107/invalid-attempt-accounting.json")["client_cost_usd"],
        "series_known_subtotal_usd": ev.load(ROOT / "verifier-closed.json")["series_known_subtotal_usd"],
        "test_patch_sha256": reg["test_patch_sha256"], "private_feedback_to_verifier": False,
        "all_five_cells_valid": True, "all_owned_eval_containers_absent": True, "audit_native_reruns": 0,
    }
    ev.save(ROOT / "closed-audit.json", summary)
    # Explicit allowlist excludes native-home, knowledge, client-home and auth-bearing runtime state.
    paths = []
    for p in ROOT.rglob("*"):
        rel = p.relative_to(ROOT).as_posix()
        if p.is_file() and ("/" not in rel and p.suffix in (".py", ".json", ".patch")
             or rel.startswith(("evaluation-", "resource-recovery/")) and p.suffix in (".json", ".jsonl", ".log")
             or rel.startswith("verifier/") and p.name in ("candidate.patch", "candidate-capture.json", "receipt.json", "stdout.json", "launch.json", "prepared.json", "supervision-final.json", "resource-samples.jsonl", "cleanup.json", "stream.jsonl")):
            paths.append(p)
    old = BASE / "blind-contrast-verifier-20261107"
    extra = [old / "invalid-attempt-accounting.json", old / "verifier/receipt.json", old / "verifier-stopped.json",
             old / "prepare.py", old / "prepare_followup.py", old / "protocol.txt", old / "image-context/Dockerfile",
             old / "image-context/candidate.patch", old / "image-build-id-failure.log"]
    entries = {("followup/" + p.relative_to(ROOT).as_posix()): p for p in paths}
    entries.update({("first-attempt/" + p.relative_to(old).as_posix()): p for p in extra})
    entries.update({("evaluation-inputs/" + row["label"] + ".patch"): pathlib.Path(row["patch"]) for row in reg["variants"] if row["patch"]})
    entries["evaluation-inputs/log-parser.txt"] = ROOT / "frozen-log-parser.txt"
    (ROOT / "frozen-log-parser.txt").write_text(record["log_parser"])
    manifest = {name: {"sha256": ev.sha(p), "bytes": p.stat().st_size} for name, p in entries.items()}
    ev.save(ROOT / "evidence-manifest.json", manifest)
    target = pathlib.Path("/home/marius/work/claude/codescout/docs/research/data/2026-11-07-blind-contrast-verifier-evidence.tar.gz")
    assert not target.exists()
    with tarfile.open(target, "w:gz") as archive:
        for name, p in sorted(entries.items()):
            archive.add(p, arcname=name, recursive=False)
        archive.add(ROOT / "evidence-manifest.json", arcname="MANIFEST.json")
    with tarfile.open(target, "r:gz") as archive:
        assert set(archive.getnames()) == set(manifest) | {"MANIFEST.json"}
        for name, expected in manifest.items():
            data = archive.extractfile(name).read()
            assert len(data) == expected["bytes"] and hashlib.sha256(data).hexdigest() == expected["sha256"]
    ev.save(ROOT / "archive-receipt.json", {"archive": str(target), "sha256": ev.sha(target), "payloads": len(entries), "all_payloads_reopened_and_verified": True})
    print(json.dumps(summary, indent=2))
    print(json.dumps(ev.load(ROOT / "archive-receipt.json"), indent=2))

if __name__ == "__main__":
    main()
