"""Reproduce only the evaluator file-transfer boundary, preserving full outputs."""
import json
import pathlib
import subprocess

ROOT = pathlib.Path(__file__).resolve().parent
rows = []
def call(*args):
    p = subprocess.run(["docker", *args], capture_output=True, text=True, timeout=30)
    rows.append({"argv": list(args), "exit_code": p.returncode, "stdout": p.stdout, "stderr": p.stderr})
    return p

cid = None
try:
    p = call("run", "-d", "--pull=never", "--network=none", "--cpus=4", "--memory=8g", "--memory-swap=8g",
             "--user=1000:1000", "--workdir=/testbed", "--entrypoint=/bin/sleep",
             "sha256:3767f31b9b1a3288ad7132740dcff712737d5e855029079a4171a8065a2040ef", "infinity")
    assert p.returncode == 0
    cid = p.stdout.strip()
    assert call("cp", str(ROOT / "generated-tests.patch"), cid + ":/tmp/contrast.patch").returncode == 0
    call("exec", cid, "stat", "-c", "%u:%g %a", "/tmp/contrast.patch")
    before = call("exec", cid, "git", "apply", "--check", "/tmp/contrast.patch")
    assert call("exec", "--user=0:0", cid, "chmod", "0644", "/tmp/contrast.patch").returncode == 0
    after = call("exec", cid, "git", "apply", "--check", "/tmp/contrast.patch")
    assert before.returncode == 128 and "Permission denied" in before.stderr and after.returncode == 0
finally:
    if cid:
        call("rm", "-f", cid)
    (ROOT / "copy-diagnostic.json").write_text(json.dumps(rows, indent=2) + "\n")
print(json.dumps(rows, indent=2))
