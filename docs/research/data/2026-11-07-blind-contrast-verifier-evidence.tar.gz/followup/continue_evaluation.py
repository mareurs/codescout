"""Complete only the resource-interrupted and unstarted cells; preserve every prior outcome."""
import pathlib
import shutil
import evaluate_v3 as ev

ROOT = pathlib.Path(__file__).resolve().parent

def main():
    original = ev.load(ROOT / "evaluation-registration.json")
    prior = ev.load(ROOT / "evaluation-v3-results.json")
    assert len(prior["rows"]) == 4
    assert all(row["valid"] for row in prior["rows"][:3])
    failed = prior["rows"][3]
    assert failed["label"] == "xhigh-control" and failed["valid"] is False
    assert "host resource floor violated" in str(failed["runtime"]["errors"])
    assert failed["statuses"] == {}
    assert ev.sha(ROOT / "generated-tests.patch") == original["test_patch_sha256"]
    host = ev.q.host_sample()
    assert all(host[k] >= floor for k, floor in ev.q.FLOORS.items()), host
    recovery = ROOT / "resource-recovery"
    recovery.mkdir()
    shutil.copyfile(ROOT / "generated-tests.patch", recovery / "generated-tests.patch")
    assert ev.sha(recovery / "generated-tests.patch") == original["test_patch_sha256"]
    ev.save(ROOT / "evaluation-final-registration.json", {
        "original_registration_sha256": ev.sha(ROOT / "evaluation-registration.json"),
        "evaluator_sha256": ev.sha(ROOT / "evaluate_v3.py"),
        "continuation_sha256": ev.sha(__file__),
        "preserved_resource_invalid_result_sha256": ev.sha(ROOT / "evaluation-v3-xhigh-control/result.json"),
        "test_patch_sha256": original["test_patch_sha256"],
        "host_preflight": host, "remaining_order": ["xhigh-control", "reference"],
        "reused_valid_cells": ["baseline", "low-control", "low-contract"],
        "model_calls": 0, "assertion_changes": 0,
        "technical_change": "Fresh output folders for resource-invalid xhigh cell and unstarted reference; same profile/guard/commands/tests",
    })
    ev.ROOT = recovery
    parser = ev.load("/home/marius/work/claude/setup-ab-data/fresh-tasks/nushell__nushell-18863/build/record.json")["log_parser"]
    rows = prior["rows"][:3]
    for row in original["variants"][3:]:
        sample = ev.q.host_sample()
        assert all(sample[k] >= floor for k, floor in ev.q.FLOORS.items()), sample
        result = ev.cell(original, row, parser)
        rows.append(result)
        if not result["valid"]:
            break
    ev.save(ROOT / "evaluation-final-results.json", {
        "rows": rows, "all_five_valid": len(rows) == 5 and all(r["valid"] for r in rows),
        "provider_calls": 0, "frozen_test_patch_sha256": original["test_patch_sha256"],
        "reused_valid_cells": ["baseline", "low-control", "low-contract"],
        "resource_invalid_cell_preserved": True,
        "claim_scope": "One exposed development task; no population efficacy estimate",
    })
    print(__import__("json").dumps(ev.load(ROOT / "evaluation-final-results.json"), indent=2))

if __name__ == "__main__":
    main()
