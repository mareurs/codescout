"""Reproduce the exact tmpfs profile and compare cp versus stdin transport."""
import json
import pathlib
import subprocess

ROOT = pathlib.Path(__file__).resolve().parent
rows = []
def call(*args, payload=None):
    p = subprocess.run(["docker", *args], input=payload, capture_output=True, timeout=30)
    rows.append({"argv": list(args), "exit_code": p.returncode,
                 "stdout": p.stdout.decode("utf-8", "replace"), "stderr": p.stderr.decode("utf-8", "replace")})
    return p

cid = None
try:
    p = call("run", "-d", "--init", "--pull=never", "--network=none", "--cpus=4", "--memory=8g", "--memory-swap=8g",
             "--pids-limit=4096", "--tmpfs", "/tmp:rw,exec,size=4g,uid=1000,gid=1000",
             "--user=1000:1000", "--workdir=/testbed", "--entrypoint=/bin/sleep",
             "sha256:3767f31b9b1a3288ad7132740dcff712737d5e855029079a4171a8065a2040ef", "infinity")
    assert p.returncode == 0
    cid = p.stdout.decode().strip()
    assert call("cp", str(ROOT / "generated-tests.patch"), cid + ":/tmp/contrast.patch").returncode == 0
    call("exec", cid, "stat", "-c", "%u:%g %a", "/tmp/contrast.patch")
    before = call("exec", cid, "git", "apply", "--check", "/tmp/contrast.patch")
    after = call("exec", "-i", cid, "git", "apply", "--check", "-", payload=(ROOT / "generated-tests.patch").read_bytes())
    assert before.returncode != 0 and after.returncode == 0
finally:
    if cid:
        call("rm", "-f", cid)
    (ROOT / "tmpfs-copy-diagnostic.json").write_text(json.dumps(rows, indent=2) + "\n")
print(json.dumps(rows, indent=2))
