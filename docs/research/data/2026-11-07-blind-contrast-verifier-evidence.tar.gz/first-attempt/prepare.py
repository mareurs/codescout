"""One new public-only verifier packet. No provider contact."""
import hashlib
import importlib.util
import json
import pathlib
import shutil
import subprocess

ROOT = pathlib.Path(__file__).resolve().parent
BASE = ROOT.parent
SOURCE = pathlib.Path("/home/marius/.codex/worktrees/ca35/codescout")
OLD_SOURCE = pathlib.Path("/home/marius/work/claude/codescout/.worktrees/semantic-contract-runtime-01a15ca9")
ORIGINAL = BASE / "semantic-contract-runtime-20261106/prepared/arms/nushell__nushell-18863--low-control"
ACTOR = pathlib.Path("/tmp/cs-contrast-verifier-01a15ca9-20261107")
OUT = ROOT / "verifier"

def load(path):
    return json.loads(pathlib.Path(path).read_text())

def sha(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()

def save(path, value):
    pathlib.Path(path).write_text(json.dumps(value, indent=2) + "\n")

def local_base(image):
    tag = "codescout-contrast-base-01a15ca9:20261107"
    prior = subprocess.run(["docker", "image", "inspect", "--format", "{{.Id}}", tag], capture_output=True, text=True)
    if prior.returncode == 0:
        assert prior.stdout.strip() == image, "Local base tag already belongs to another image"
    else:
        subprocess.run(["docker", "tag", image, tag], check=True)
    assert subprocess.check_output(["docker", "image", "inspect", "--format", "{{.Id}}", tag], text=True).strip() == image
    return tag


def main():
    assert not OUT.exists() and not ACTOR.exists() and not (ROOT / "registration.json").exists()
    assert subprocess.check_output(["git", "-C", str(SOURCE), "rev-parse", "HEAD"], text=True).strip() == "fe8bb4b34f5e7912f9b16c4c0bf1ff73a3a10a23"
    assert not subprocess.check_output(["git", "-C", str(SOURCE), "status", "--porcelain"], text=True)
    cfg = load(ORIGINAL / "prepared.json")
    project = load(BASE / "semantic-contract-pilot-20261106/prompt-inputs-registration.json")["projects"]["nushell__nushell-18863"]
    manifest_path = pathlib.Path(project["runtime_snapshot_manifest"])
    assert sha(manifest_path) == project["runtime_snapshot_manifest_sha256"]
    proposal = ORIGINAL / "candidate.patch"
    assert sha(proposal) == "2fdd4ff1fe86e786a68c6f704fa25957f7319511b7c37022d1a0e04fefd23db4"
    # Explicitly allow only this public proposal and source-only preparation.
    build = ROOT / "image-context"
    build.mkdir(exist_ok=True)
    shutil.copyfile(proposal, build / "candidate.patch")
    dockerfile = (
        "FROM " + local_base(cfg["image"]) + "\nUSER root\n"
        "COPY candidate.patch /proposal/candidate.patch\n"
        "RUN cd /testbed && git apply --check /proposal/candidate.patch && git apply /proposal/candidate.patch\n"
        "USER 1000:1000\n"
    )
    (build / "Dockerfile").write_text(dockerfile)
    with (ROOT / "image-build.log").open("wb") as log:
        subprocess.run(["docker", "build", "--network=none", "--pull=false", "--iidfile", str(ROOT / "image-id.txt"), str(build)],
                       stdout=log, stderr=subprocess.STDOUT, check=True, timeout=180)
    image = (ROOT / "image-id.txt").read_text().strip()
    spec = importlib.util.spec_from_file_location("frozen_prep", OLD_SOURCE / "tools/agent_lifecycle/semantic_prepare.py")
    prep = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(prep)
    manifest = load(manifest_path)
    cloned = prep.clone_snapshot(manifest_path.parent, OUT, manifest)
    save(OUT / "clone-proof.json", cloned)
    ACTOR.mkdir()
    for name in ("CLAUDE.md", "AGENTS.md"):
        shutil.copyfile(ORIGINAL / "actor-context" / name, ACTOR / name)
    shutil.copyfile(ORIGINAL / "global-CLAUDE.md", OUT / "global-CLAUDE.md")
    native = prep.rewrite_native(load(ORIGINAL / "mcp-native-argv.json"), OUT, manifest["projects"], "cs-contrast-verifier-01a15ca9")
    native[-4] = image
    save(OUT / "mcp-native-argv.json", native)
    guidance, task = cfg["prompt"].split("Repair task:\n", 1)
    protocol = """Independent regression audit of a proposed repair

You are the verifier, not the repair implementer. The proposed patch is already applied in /testbed and its exact diff is /proposal/candidate.patch. Work only from the public request, repository source, existing tests and this proposal.

Trace the behavior changed by the patch and its producer/caller contracts. Identify the strongest plausible over-correction or under-correction. Derive a small executable contrast test whose expected result follows from the public requirement or a legitimate behavior preserved by the baseline. A test reproducing the original bug alone does not discriminate between different plausible repairs. Do not assume that the proposal is correct.

Add independent tests with function names starting contrast_ in the appropriate existing test file or a new integration test file. Keep existing test bodies and production code unchanged. Do not repair the proposal, disable tests, change configuration, or alter CLAUDE.md/AGENTS.md. Run the tests and retain failing assertions: a discovered regression is a useful verifier result, not a reason to weaken the test.

Before finishing, report each new test, the public/source basis for its expected behavior, the exact command and observed result. If you cannot justify an executable counterexample, report not found rather than inventing an expected answer. Do not commit, push, or access external sources.
"""
    (ROOT / "protocol.txt").write_text(protocol)
    cfg.update(image=image, actor=str(ACTOR), global_rules=str(OUT / "global-CLAUDE.md"),
               prompt=guidance + "Original public repair request:\n" + task + "\n\n" + protocol,
               checks=[{"id": "patch_hygiene_only", "command": "git diff --check"}],
               timeout_s=1800, check_timeout_s=30, max_continuations=0)
    cfg["files"] = {str(p): sha(p) for p in (OUT / "mcp-native-argv.json", OUT / "global-CLAUDE.md",
                   pathlib.Path(cfg["cli"]), ACTOR / "CLAUDE.md", ACTOR / "AGENTS.md")}
    save(OUT / "prepared.json", cfg)
    hashes = dict(cfg["files"])
    for base in (SOURCE / "tools/agent_lifecycle", SOURCE / "tools/hint_authority_pilot", SOURCE / "tools/hint_authority_workflow"):
        hashes.update({str(p): sha(p) for p in base.glob("*.py")})
    for p in (ROOT / "prepare.py", ROOT / "protocol.txt", OUT / "prepared.json", build / "Dockerfile", build / "candidate.patch",
              BASE / "semantic-contract-native-probe-20261107/supervision.py",
              pathlib.Path("/home/marius/.codex/worktrees/add2/codescout/tools/setup-ab-eval/grade_policy.py")):
        hashes[str(p)] = sha(p)
    hashes.update({str(OUT / rel): proof["sha256"] for rel, proof in manifest["files"].items()})
    registration = {
        "question": "Can one fresh low verifier derive an executable regression contrast from the public task/source/proposal?",
        "status": "prepared_unstarted", "task_role": "exposed_development_control",
        "source": str(SOURCE), "source_commit": "fe8bb4b34f5e7912f9b16c4c0bf1ff73a3a10a23",
        "out": str(OUT), "image": image, "base_image": project["image"], "proposal_sha256": sha(proposal),
        "effort": "low", "reserve_usd": "4", "cli_cap_usd": "3",
        "prior_series_usd": "61.746769099999999054", "series_ceiling_usd": "200",
        "hashes": hashes, "snapshot_manifest_sha256": sha(manifest_path),
        "actor_inputs": ["public source base image plus candidate.patch", "source-only snapshot", "global/project instructions", "generic verifier protocol"],
        "excluded": ["private test patch", "gold/reference", "grade logs", "diagnosis", "prior actor transcript", "outcome labels"],
        "evaluation": "Freeze generated tests before baseline/three-proposal/reference execution. No private feedback to verifier.",
        "retry_allowed": False,
    }
    save(ROOT / "registration.json", registration)
    print(json.dumps({k: v for k, v in registration.items() if k != "hashes"}, indent=2))

if __name__ == "__main__":
    main()
