"""Preserve invalid attempt and prepare one lifecycle-only follow-up."""
import importlib.util
import json
import pathlib
import shutil
from decimal import Decimal
import prepare as old

ROOT = old.BASE / "blind-contrast-verifier-followup-20261107"
OUT = ROOT / "verifier"
ACTOR = pathlib.Path("/tmp/cs-contrast-verifier-followup-01a15ca9-20261107")

def main():
    prior = old.load(old.ROOT / "registration.json")
    receipt = old.load(old.OUT / "receipt.json")
    assert receipt["workflow_completed"] is False
    assert receipt["lifecycle"]["error"] == "ValueError: continuation limit reached with undelivered jobs"
    assert receipt["unknown_provider_cost"] is False
    assert receipt["cost_coverage"]["forwarded_at_terminal"] == receipt["cost_coverage"]["forwarded_total"] == receipt["forwarded"]
    assert not ROOT.exists() and not ACTOR.exists()
    ROOT.mkdir()
    old.save(old.ROOT / "invalid-attempt-accounting.json", {
        "valid": False, "scored": False, "client_cost_usd": receipt["cost_usd"],
        "prior_series_usd": prior["prior_series_usd"],
        "series_known_subtotal_usd": str(Decimal(prior["prior_series_usd"]) + Decimal(receipt["cost_usd"])),
        "reason": receipt["lifecycle"]["error"], "receipt_sha256": old.sha(old.OUT / "receipt.json"),
    })
    public = old.load(old.ORIGINAL / "prepared.json")
    cfg = old.load(old.OUT / "prepared.json")
    assert old.sha(old.OUT / "prepared.json") == prior["hashes"][str(old.OUT / "prepared.json")]
    project = old.load(old.BASE / "semantic-contract-pilot-20261106/prompt-inputs-registration.json")["projects"]["nushell__nushell-18863"]
    manifest_path = pathlib.Path(project["runtime_snapshot_manifest"])
    assert old.sha(manifest_path) == project["runtime_snapshot_manifest_sha256"]
    manifest = old.load(manifest_path)
    spec = importlib.util.spec_from_file_location("frozen_prep", old.OLD_SOURCE / "tools/agent_lifecycle/semantic_prepare.py")
    prep = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(prep)
    cloned = prep.clone_snapshot(manifest_path.parent, OUT, manifest)
    old.save(OUT / "clone-proof.json", cloned)
    ACTOR.mkdir()
    for name in ("CLAUDE.md", "AGENTS.md"):
        shutil.copyfile(old.ORIGINAL / "actor-context" / name, ACTOR / name)
    shutil.copyfile(old.OUT / "global-CLAUDE.md", OUT / "global-CLAUDE.md")
    native = prep.rewrite_native(old.load(old.ORIGINAL / "mcp-native-argv.json"), OUT, manifest["projects"], "cs-contrast-verifier-followup-01a15ca9")
    native[-4] = prior["image"]
    old.save(OUT / "mcp-native-argv.json", native)
    cfg.update(actor=str(ACTOR), global_rules=str(OUT / "global-CLAUDE.md"), max_continuations=4)
    cfg["files"] = {str(p): old.sha(p) for p in (OUT / "mcp-native-argv.json", OUT / "global-CLAUDE.md", pathlib.Path(cfg["cli"]), ACTOR / "CLAUDE.md", ACTOR / "AGENTS.md")}
    old.save(OUT / "prepared.json", cfg)
    shutil.copyfile(old.ROOT / "run_verifier.py", ROOT / "run_verifier.py")
    hashes = {p: h for p, h in prior["hashes"].items() if p.startswith(str(old.SOURCE) + "/") or p.endswith("/supervision.py") or p.endswith("/grade_policy.py")}
    hashes.update(cfg["files"])
    hashes.update({str(OUT / rel): proof["sha256"] for rel, proof in manifest["files"].items()})
    hashes.update({str(p): old.sha(p) for p in (OUT / "prepared.json", ROOT / "run_verifier.py", pathlib.Path(__file__), old.ROOT / "prepare.py")})
    reg = dict(prior)
    reg.update(out=str(OUT), hashes=hashes, prior_series_usd=str(Decimal(prior["prior_series_usd"]) + Decimal(receipt["cost_usd"])),
               previous_invalid_attempt=str(old.ROOT), technical_change="max_continuations 0 -> 4; fresh disposable state/session",
               prompt_sha256=__import__("hashlib").sha256(cfg["prompt"].encode()).hexdigest())
    assert cfg["prompt"] == old.load(old.OUT / "prepared.json")["prompt"]
    old.save(ROOT / "registration.json", reg)
    print(json.dumps({k: v for k, v in reg.items() if k != "hashes"}, indent=2))

if __name__ == "__main__":
    main()
