---
id: '26021c97d11af0a0'
kind: bug
status: fixed
title: External image capture guard test can fail on an unrealistic Docker response type
tags:
- cluster/unclassified
- evaluation
- testing
closed: 2026-11-05
opened: 2026-11-05
owner: marius
severity: medium
unverified: Fix is committed and verified on isolated research/fixed-acceptance-population-20261101; integration on experiments remains pending.
---

# BUG: Wrong-image capture guard test uses text for a byte-producing Docker call

## Class fit

This is a research-test instrument defect: the mismatch fixture returns JSON text for every Docker invocation, including head-copy calls that request binary stdout. It differs from a production capture bug because the original image guard is intact; the defect is that its regression test can fail for an unrelated Python type error after that guard is removed.

## Symptom (Effect)

Independent finite mutation review applied e05_capture_image_guard. Omission reaches head-copy, receives str rather than bytes, and write_bytes raises TypeError. The test then fails on the error-message assertion. This does not qualify as an observed meaningful mutation kill.

## Reproduction

V tools/agent_lifecycle/test_external_runtime.py, ExternalImageTests.test_image_mismatch_is_rejected_at_every_external_boundary. Review copy /tmp/external-runtime-review-01a15ca9-20261105. Apply reviewer e05 and run the actual suite; e05 patch/raw log retained. No paid calls.

## Root cause

The external Docker stub models inspect but reuses its text response for binary head output. A missing image guard should instead be caught by observing an actual attempted wrong-container read with a valid byte response, or a direct forbidden-boundary assertion.

## Containment

Resolved in the reviewed research fixture. Original e05 remains classified instrument-invalid; corrected e09 supplies the meaningful execution witness. No paid run was admitted by this review. Keep this record unarchived until integration on experiments.

## Evidence

Reviewer message reports seven direct assertion kills, one invalid instrument-dependent result; /tmp/external-runtime-review-01a15ca9-20261105/e05.patch and e05.log (locate exact names before reuse).

## Tests added

Corrected mismatch stub returns actual bytes for head-copy and JSON job content for cat, with a direct forbidden-operation assertion for other wrong-image actions. Controller ran all61 lifecycle methods GREEN after the fix. Reviewer reran the same4external-runtime methods before/after exact e05 reapplication (e09, identical patch bytes): the broken helper accepts wrong-image log bytes and sets complete=true, producing an observed direct AssertionError at assertFalse(proof.complete). No TypeError or harness timeout. Original7validkills+1instrument-invalid retained; final finite totals8distinct candidates/9executions/8validkills/1historicalinvalid resolved/0survivors. Review: /tmp/external-runtime-review-01a15ca9-20261105/review.md and review-binding.json. No production guard change was necessary; only the research fixture was corrected.

## Fix provenance

- **SHA:** `9751891074a2bc9ce6da17b9f88e685af5d058d8` (`research/fixed-acceptance-population-20261101`, not integrated on experiments)
- **patch-id:** `5545a673424ea246b03e8205b2630fd334ac4a59`

Full V product gate @bg_00000091 exited0: PYTHON_LIGHT/FMT/CLIPPY/LEAN/DEFAULT all0. The final fixture change occurred after that gate began; all61 research lifecycle methods were independently executed after the correction and are outside the gate's37-file Python light selection. Pilot30and campaign24methods also independently pass. Keep the record unarchived until integration.
