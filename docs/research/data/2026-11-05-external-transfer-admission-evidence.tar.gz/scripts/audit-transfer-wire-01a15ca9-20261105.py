import hashlib,json,pathlib,subprocess,sys
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
sys.path.insert(0,str(V/"tools/hint_authority_pilot"))
from core import audit_request
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/external-transfer-admission-20261105/evaluated-cli-wire")
HOME=pathlib.Path("/home/marius/work/claude/codescout")
def main():
 rows=[]
 for d in ROOT.iterdir():
  if not d.is_dir():continue
  result=json.loads((d/"result.json").read_text())
  expected=json.loads((d/"expected.json").read_text())
  uses={};results={};request_text=[]
  paths=list(d.glob("request-*.json"))
  for path in paths:
   req=json.loads(path.read_text());assert audit_request(req,expected)
   request_text.append(path.read_text())
   for msg in req.get("messages",[]):
    content=msg.get("content",[])
    if not isinstance(content,list):continue
    for b in content:
     if not isinstance(b,dict):continue
     if b.get("type")=="tool_use":uses[b["id"]]=b["name"]
     elif b.get("type")=="tool_result":results[b["tool_use_id"]]=b
  assert set(uses)<=set(results)
  assert not any(b.get("is_error",False) for b in results.values())
  skill_ids=[i for i,n in uses.items() if n=="Skill"]
  assert len(skill_ids)==1 and "Launching skill: codescout-companion:reconnaissance" in str(results[skill_ids[0]]["content"])
  assert any("A **seam** is a place" in t for t in request_text)
  host_reads=[results[i] for i,n in uses.items() if n=="mcp__codescout__read_file"]
  assert len(host_reads)==1 and "file not found" in json.dumps(host_reads[0])
  cleanup=json.loads((d/"cleanup.json").read_text())
  for item in cleanup:
   proc=subprocess.run(["docker","inspect",item["name"]],capture_output=True,text=True,timeout=10)
   assert proc.returncode!=0 and "no such" in proc.stderr.lower()
  launches=[json.loads(p.read_text()) for p in d.glob("mcp-launch-*.json")]
  for launch in launches:
   argv=launch["argv"]
   assert argv[argv.index("--memory")+1]=="24g" and argv[argv.index("--cpus")+1]=="4"
   assert argv[argv.index("--pids-limit")+1]=="4096"
  assert result["receipt"]["workflow_completed"] and result["provider_calls"]==0
  row={"id":d.name,"actual_cli_requests_audited":len(paths),"tool_use_ids_with_results":len(uses),
   "all_tool_result_blocks_non_error":True,"recon_skill_invoked_and_body_in_wire":True,
   "global_and_project_ordered_visible_content_each_request":True,"host_path_denied":True,
   "native_connections":len(launches),"all_native_launches_resource_profile":{"cpus":4,"memory_gib":24,"pids_limit":4096},
   "native_jobs_delivered":len(result["receipt"]["lifecycle"]["jobs"]),
   "continuations":result["receipt"]["lifecycle"]["continuations"],"terminal_cost_usd":result["receipt"]["cost_usd"],
   "provider_calls":0,"credential_reads":0,"all_recorded_containers_independently_absent":True,
   "result_sha256":hashlib.sha256((d/"result.json").read_bytes()).hexdigest()}
  rows.append(row)
 out=HOME/"docs/research/data/2026-11-05-transfer-cli-wire-audit.json"
 with out.open("x") as stream:
  json.dump({"tasks":rows,"paid_admitted":False,"limits":"Synthetic provider responses and marker public check only; no semantic/reference or final-patch preservation qualification, no LLM author/repair quality."},stream,indent=2)
  stream.write("\n")
 print(json.dumps(rows,indent=2))
if __name__=="__main__":main()
