import hashlib,io,json,pathlib,shutil,subprocess,tarfile
HOME=pathlib.Path("/home/marius/work/claude/codescout")
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/external-transfer-admission-20261105")
REVIEW=pathlib.Path("/tmp/external-runtime-review-01a15ca9-20261105")
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 job=json.loads(pathlib.Path("/tmp/codescout-bg/455879-a720241d-bg_00000091.json").read_text())
 if job["state"]!="exited" or job["exit_code"]!=0:raise RuntimeError("gate not green; do not seal")
 binding=json.loads((REVIEW/"review-binding.json").read_text())
 for p,h in binding["source_hashes"].items():assert sha(V/p)==h,p
 inputs={}
 def add(path,arc):
  if path.is_symlink() or not path.is_file():raise RuntimeError("unexpected evidence file "+str(path))
  if arc in inputs:raise RuntimeError("duplicate evidence name "+arc)
  inputs[arc]=path
 for name in ["2026-11-05-transfer-candidate-selection.json","2026-11-05-transfer-context-preflight.json",
     "2026-11-05-transfer-control-replay.json","2026-11-05-transfer-public-controls.json",
     "2026-11-05-transfer-admission-manifest.json","2026-11-05-transfer-cli-wire-audit.json"]:
  add(HOME/"docs/research/data"/name,"data/"+name)
 for p in ROOT.rglob("*"):
  if not p.is_file() or p.is_symlink():continue
  rel=p.relative_to(ROOT)
  if any(part in {"client-home","native-home","home","generated-codescout","__pycache__"} for part in rel.parts):continue
  add(p,"admission/"+str(rel))
 for p in REVIEW.iterdir():
  if p.is_file() and p.suffix in {".md",".json",".log",".patch"}:add(p,"review/"+p.name)
 for folder in ["agent_lifecycle","hint_authority_pilot","hint_authority_workflow"]:
  for p in (V/"tools"/folder).glob("*.py"):add(p,"source/tools/"+folder+"/"+p.name)
 for name in ["replay-transfer-controls","transfer-public-controls","transfer-native-probe",
     "transfer-cli-wire","transfer-admission-manifest","audit-transfer-wire","verify-external-runtime",
     "preserve-transfer-admission"]:
  p=pathlib.Path("/tmp")/(name+"-01a15ca9-20261105.py");add(p,"scripts/"+p.name)
 add(pathlib.Path(job["log_path"]),"gate/product-gate.log")
 add(pathlib.Path("/tmp/codescout-bg/455879-a720241d-bg_00000091.json"),"gate/job.json")
 add(pathlib.Path("/home/marius/.claude/CLAUDE.md"),"instructions/global-CLAUDE.md")
 add(HOME/"docs/superpowers/plans/2026-11-05-external-workflow-transfer-admission.md","docs/admission-plan-at-seal.md")
 add(HOME/"docs/issues/2026-11-05-external-capture-guard-test-uses-text-for-byte-copy.md","docs/fixture-bug-at-seal.md")
 for ident in ["nushell__nushell-18863","rust-lang__rust-analyzer-22992"]:
  task=pathlib.Path("/home/marius/work/claude/setup-ab-data/fresh-tasks")/ident
  for rel in ["bundle.json","build/record.json","build/assembly.json","prescan/prescan.json"]:
   add(task/rel,"private-task-inputs/"+ident+"/"+rel)
  controls=pathlib.Path("/home/marius/work/claude/setup-ab-data/fresh-build/controls")/ident
  for p in controls.iterdir():
   if p.is_file() and p.suffix in {".json",".log"}:add(p,"private-control-inputs/"+ident+"/"+p.name)
 head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=V,text=True).strip()
 manifest={"source_head_at_seal":head,"files":{arc:sha(p) for arc,p in sorted(inputs.items())},
  "scope":"External controls, native/actual synthetic CLI qualification, explicit image/resource delta and finite review. No paid repairs or complete onboarding.",
  "limits":"Docker image bytes not archived; retain pinned images. Client profiles/live DB/WAL/index/cache excluded. Private control patches/test sets stay controller-only.",
  "provider_calls":0,"onboarding_author_calls":0}
 dest=HOME/"docs/research/data/2026-11-05-external-transfer-admission-evidence.tar.gz"
 if dest.exists():raise RuntimeError("exclusive archive exists")
 with tarfile.open(dest,"x:gz") as archive:
  for arc,p in sorted(inputs.items()):archive.add(p,arcname=arc,recursive=False)
  content=(json.dumps(manifest,indent=2,sort_keys=True)+"\n").encode()
  info=tarfile.TarInfo("MANIFEST.json");info.size=len(content);archive.addfile(info,io.BytesIO(content))
 with tarfile.open(dest,"r:gz") as archive:
  members={p.name:p for p in archive.getmembers()}
  assert set(members)==set(inputs)|{"MANIFEST.json"}
  for arc,h in manifest["files"].items():assert hashlib.sha256(archive.extractfile(members[arc]).read()).hexdigest()==h,arc
 receipt={"archive":str(dest),"sha256":sha(dest),"payload_files_verified":len(inputs),
  "gate_job":job,"source_hashes":binding["source_hashes"],"provider_calls":0,
  "paid_admitted":False,"source_head_at_seal":head}
 with (ROOT/"preservation.json").open("x") as f:json.dump(receipt,f,indent=2);f.write("\n")
 print(json.dumps(receipt,indent=2))
if __name__=="__main__":main()
