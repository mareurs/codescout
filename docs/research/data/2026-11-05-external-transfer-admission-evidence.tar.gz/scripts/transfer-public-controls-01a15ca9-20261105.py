import hashlib, json, pathlib, subprocess, time
HOME = pathlib.Path("/home/marius/work/claude/codescout")
ROOT = pathlib.Path("/home/marius/.cache/codescout-resident/codescout/external-transfer-admission-20261105")
TASKS = [
    ("nushell__nushell-18863", "sha256:3767f31b9b1a3288ad7132740dcff712737d5e855029079a4171a8065a2040ef",
     ["cargo build --offline", "cargo test --offline --workspace --no-fail-fast -- --skip plugin_persistence::plugin_process_exits_when_nushell_exits"]),
    ("rust-lang__rust-analyzer-22992", "sha256:0d74e4f14c68a438dce6cf9e4a02c626432ce12b866f55ac69c6cc687f7fff7a",
     ["cargo build --offline", "RUN_SLOW_TESTS=1 cargo +stable test --offline --no-fail-fast -- --nocapture"]),
]
def absent(name):
    p = subprocess.run(["docker", "inspect", name], capture_output=True, text=True, timeout=10)
    return p.returncode != 0 and "no such" in p.stderr.lower()
def main():
    ROOT.mkdir()
    registration = {"provider_calls": 0, "onboarding_calls": 0, "purpose": "public baseline, no hidden test patch",
        "cpus": 4, "memory": "24g", "pids_limit": 4096, "command_timeout_s": 1800,
        "task_order": [x[0] for x in TASKS], "tasks": [
            {"id": ident, "image": image, "commands": commands} for ident, image, commands in TASKS],
        "nushell_skip_reason": "This existing public test fails in saved base/gold/gold-repeat controls and is outside selected P2P; skip fixed before fresh executions. Does not change private expected sets.",
        "limitations": "New baseline public controls only. No native MCP, actual model-context delivery or cold 12GiB worker qualification claimed."}
    (ROOT / "public-profile-registration.json").write_text(json.dumps(registration, indent=2) + "\n")
    results = []
    for index, (ident, image, commands) in enumerate(TASKS):
        dst = ROOT / ident
        dst.mkdir()
        name = "cs-transfer-public-01a15ca9-20261105-" + str(index)
        if not absent(name):
            raise RuntimeError("owned name already exists")
        row = {"id": ident, "image": image, "commands": commands, "steps": []}
        started = time.monotonic()
        cid = None
        try:
            argv = ["docker", "run", "-d", "--pull=never", "--init", "--network", "none",
                "--cpus", "4", "--memory", "24g", "--memory-swap", "24g", "--pids-limit", "4096",
                "--user", "1000:1000", "--name", name,
                "--label", "codescout.transfer-public=01a15ca9-f939-7603-acb5-01c6b02f68e2",
                "--workdir", "/testbed", "--entrypoint", "/bin/bash", image, "-c", "sleep infinity"]
            cid = subprocess.check_output(argv, text=True, timeout=60).strip()
            row["container_id"] = cid
            meta = subprocess.check_output(["docker", "exec", cid, "python3", "-c",
                "import pathlib,json,os,shutil; print(json.dumps({'uid':os.getuid(),'cargo':shutil.which('cargo'),'rustc':shutil.which('rustc'),'target_exists':pathlib.Path('/testbed/target').is_dir(),'claude':pathlib.Path('/testbed/CLAUDE.md').read_text(),'agents':pathlib.Path('/testbed/AGENTS.md').read_text(),'private_marker_paths':[p for p in ['/oracle','/controller','/bench/oracle'] if pathlib.Path(p).exists()]}))"],
                text=True, timeout=30)
            (dst / "actual-context.json").write_text(meta)
            for i, command in enumerate(commands):
                log = dst / ("public-" + str(i) + ".log")
                t = time.monotonic()
                try:
                    with log.open("wb") as stream:
                        p = subprocess.run(["docker", "exec", "-w", "/testbed", cid,
                            "/bin/bash", "-o", "pipefail", "-c", command], stdout=stream,
                            stderr=subprocess.STDOUT, timeout=1800)
                    step = {"command": command, "exit_code": p.returncode, "timeout": False}
                except subprocess.TimeoutExpired:
                    step = {"command": command, "exit_code": None, "timeout": True}
                step.update(wall_s=time.monotonic()-t, log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(), log_bytes=log.stat().st_size)
                row["steps"].append(step)
                (dst / "partial.json").write_text(json.dumps(row, indent=2)+"\n")
                if step["exit_code"] != 0:
                    break
            inspect = json.loads(subprocess.check_output(["docker", "inspect", cid], text=True, timeout=10))[0]
            row["oom_killed"] = inspect["State"]["OOMKilled"]
        except Exception as e:
            row["error"] = type(e).__name__ + ": " + str(e)
        finally:
            if cid:
                p = subprocess.run(["docker", "rm", "-f", "-v", cid], capture_output=True, text=True, timeout=60)
                row["remove_exit_code"] = p.returncode
            row["container_absent"] = absent(cid or name)
        row["wall_s"] = time.monotonic()-started
        row["public_baseline_pass"] = len(row["steps"]) == len(commands) and all(s["exit_code"] == 0 for s in row["steps"]) and not row.get("error") and not row.get("oom_killed") and row["container_absent"]
        (dst / "result.json").write_text(json.dumps(row, indent=2)+"\n")
        results.append(row)
        print(json.dumps(row), flush=True)
    result = {"registration": registration, "results": results}
    (ROOT / "public-controls.json").write_text(json.dumps(result, indent=2)+"\n")
    (HOME / "docs/research/data/2026-11-05-transfer-public-controls.json").write_text(json.dumps(result, indent=2)+"\n")
    if not all(r["public_baseline_pass"] for r in results):
        raise SystemExit(1)
if __name__ == "__main__":
    main()
