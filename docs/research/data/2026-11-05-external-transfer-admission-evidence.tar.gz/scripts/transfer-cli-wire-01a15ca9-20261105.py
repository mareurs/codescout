import hashlib,json,pathlib,sys,uuid
from decimal import Decimal
from types import SimpleNamespace
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
sys.path[:0]=[str(V/"tools/agent_lifecycle"),str(V/"tools/hint_authority_pilot")]
import workflow, qualify, run as worker, transport
BASE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
ROOT=BASE/"external-transfer-admission-20261105/evaluated-cli-wire"
FROZEN=BASE/"complete-workflow-action-budget-20261105"
def save(path,obj):
 path.write_text(json.dumps(obj,indent=2)+"\n")
def no_provider(*args,**kwargs):
 raise AssertionError("provider forbidden for external CLI wire qualification")
def main():
 ROOT.mkdir()
 transport.Proxy.upstream=no_provider
 results=[]
 for index,ident in enumerate(["nushell__nushell-18863","rust-lang__rust-analyzer-22992"]):
  out=ROOT/ident;out.mkdir()
  actor=pathlib.Path("/tmp")/("cs-transfer-cli-wire-01a15ca9-20261105-"+str(index))
  actor.mkdir()
  context=json.loads((ROOT.parent/ident/"actual-context.json").read_text())
  (actor/"CLAUDE.md").write_text(context["claude"])
  (actor/"AGENTS.md").write_text(context["agents"])
  canary="HOST_CANARY_"+uuid.uuid4().hex
  (actor/"host-canary.txt").write_text(canary)
  glob=pathlib.Path("/home/marius/.claude/CLAUDE.md").read_text()
  home=out/"client-home";config=home/".claude";config.mkdir(parents=True)
  (config/"CLAUDE.md").write_text(glob)
  nativehome=out/"native-home";(nativehome/".claude").mkdir(parents=True)
  (nativehome/".claude/CLAUDE.md").write_text(glob)
  original=json.loads((ROOT.parent/"native-probes"/ident/"launch.json").read_text())["argv"]
  image=original[-4]
  native=[];i=0
  while i<len(original):
   x=original[i]
   if x in ["--init","--cpus","--memory-swap"]:
    i+=1 if x=="--init" else 2;continue
   if x.startswith("type=bind,") and ",dst=/bench-home" in x and ",dst=/bench-home/" not in x:
    x="type=bind,src="+str(nativehome)+",dst=/bench-home"
   native.append(x);i+=1
  native[native.index("--pids-limit")+1]="4096"
  native=workflow.verified_native_argv(native,memory_gib=24)
  save(out/"mcp-native-argv.json",native)
  save(out/"mcp.json",{"mcpServers":{"codescout":{"command":"/usr/bin/python3","args":["-B",str(V/"tools/hint_authority_pilot/stdio.py"),str(out)]}}})
  names=["workspace","index","onboarding","symbols","read_file","run_command","create_file"]
  allowed=["Skill","ToolSearch"]+["mcp__codescout__"+n for n in names]
  save(out/"settings.json",{"permissions":{"allow":allowed}})
  state=out/"hook";state.mkdir()
  source="src/main.rs" if index==0 else "crates/rust-analyzer/src/bin/main.rs"
  marker="EXTERNAL_NATIVE_JOB_"+uuid.uuid4().hex
  plan=[
   ("Skill",{"skill":"codescout-companion:reconnaissance"}),
   ("mcp__codescout__workspace",{"action":"status"}),
   ("mcp__codescout__index",{"action":"status"}),
   ("mcp__codescout__onboarding",{}),
   ("mcp__codescout__symbols",{"path":source,"name":"main","include_body":True}),
   ("mcp__codescout__read_file",{"path":str(actor/"host-canary.txt"),"force":True}),
   ("mcp__codescout__run_command",{"command":"printf '"+marker+"\\n'; cargo --version","run_in_background":True}),
   ("mcp__codescout__create_file",{"path":"cs-wire-probe.txt","content":"synthetic transport marker\n"}),
  ]
  expected={"effort":"low","declaration":False,"clause":worker.CLAUSE,
     "global_visible":worker.visible(glob),"project_visible":worker.visible(context["claude"])}
  save(out/"expected.json",expected)
  server=transport.server(out,expected,True,plan,campaign_remaining=0)
  sid=str(uuid.uuid4())
  prompt="Provider-disabled external transport qualification. Follow the scripted tools and retain this session; no repair task, hidden tests, or paid onboarding author is supplied."
  argv=[str(worker.CLI),"-p","--model","claude-sonnet-5-5","--effort","low","--session-id",sid,
   "--setting-sources","user,project,local","--settings",str(out/"settings.json"),
   "--strict-mcp-config","--mcp-config",str(out/"mcp.json"),"--permission-mode","acceptEdits",
   "--tools","Skill,ToolSearch","--allowedTools",",".join(allowed),"--output-format","json",
   "--max-budget-usd","1","--plugin-dir",str(FROZEN/"skill-only-plugin"),"--",prompt]
  env={"HOME":str(home),"USER":"marius","LANG":"C.UTF-8","PATH":"/usr/local/bin:/usr/bin:/bin",
   "CLAUDE_CONFIG_DIR":str(config),"ANTHROPIC_BASE_URL":"http://127.0.0.1:"+str(server.server_port),
   "ANTHROPIC_API_KEY":"scripted-no-real-credential","DISABLE_AUTOUPDATER":"1",
   "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC":"1","CLAUDE_CODE_MAX_OUTPUT_TOKENS":"8192",
   "PYTHONDONTWRITEBYTECODE":"1"}
  save(out/"launch.json",{"argv":argv,"session_id":sid,"scripted":True,"real_credentials_read":False,
    "host_context":str(actor),"host_canary":str(actor/"host-canary.txt"),"native_source_mode":"isolated image overlay; no host source bind"})
  runtime=SimpleNamespace(IMAGE=image,save=save,extract_result=worker.extract_result,audit_hooks=worker.audit_hooks)
  receipt=workflow.execute(runtime,{"checks":[{"id":"native_marker","command":"test -f cs-wire-probe.txt"}],
   "timeout_s":300,"check_timeout_s":30,"max_continuations":4},out,actor,argv,env,server,sid,state,Decimal(1))
  requests=[json.loads(p.read_text()) for p in out.glob("request-*.json")]
  leaked=any(canary in json.dumps(req) for req in requests)
  result={"id":ident,"image":image,"receipt":receipt,"scripted_steps":server.stage,"required_steps":len(plan),
   "host_canary_content_leaked":leaked,"provider_calls":server.forwarded,"credential_reads":0,
   "raw_request_count":len(requests),"global_sha256":hashlib.sha256(glob.encode()).hexdigest(),
   "global_and_project_audited_each_request":not server.errors,
   "limits":"Synthetic model responses; no repair efficacy, semantic/index readiness, full oracle scan, completed author onboarding or paid-run admission."}
  save(out/"result.json",result)
  results.append(result)
  print(json.dumps(result),flush=True)
  if not receipt["workflow_completed"] or server.forwarded or server.errors or leaked or server.stage!=len(plan):
   raise RuntimeError("external wire qualification failed; retain evidence without paid retry")
 save(ROOT/"results.json",results)
if __name__=="__main__":main()
