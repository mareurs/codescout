import collections, hashlib, importlib.util, json, pathlib, sys
HOME = pathlib.Path("/home/marius/work/claude/codescout")
DATA = pathlib.Path("/home/marius/work/claude/setup-ab-data")
sys.path.insert(0, str(HOME / "tools/setup-ab-eval"))
import multilang_grade as grade
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    result = {"provider_calls": 0, "test_executions": 0, "method": "existing isolated parser and verdict replay on full saved logs", "tasks": []}
    for ident in ("nushell__nushell-18863", "rust-lang__rust-analyzer-22992"):
        rp = DATA / "fresh-tasks" / ident / "build/record.json"
        cp = DATA / "fresh-build/controls" / ident
        rec = json.loads(rp.read_text())
        stored = json.loads((cp / "control.json").read_text())
        parsed = {}
        logs = {}
        for state in ("base", "gold", "gold-repeat"):
            lp = cp / (state + ".log")
            parsed[state] = grade.run_parser(rec["log_parser"], lp.read_text(), isolate_network=True)
            logs[state] = {"sha256": sha(lp), "bytes": lp.stat().st_size,
                "counts": dict(collections.Counter(parsed[state].values())),
                "not_pass_or_skip": {k:v for k,v in parsed[state].items() if v not in ("pass", "skip")}}
        f2p, p2p = rec["FAIL_TO_PASS"], rec["PASS_TO_PASS"]
        row = {"instance_id": ident, "record_sha256": sha(rp),
            "control_sha256": sha(cp / "control.json"),
            "parser_sha256": hashlib.sha256(rec["log_parser"].encode()).hexdigest(),
            "f2p": f2p, "p2p_count": len(p2p), "dropped_f2p": rec["dropped_f2p"],
            "logs": logs,
            "current_expected_control": grade.control_verdict(parsed["base"], parsed["gold"], f2p, p2p, gold_repeat=parsed["gold-repeat"]),
            "current_base": grade.verdict(parsed["base"], f2p, p2p),
            "current_gold": grade.verdict(parsed["gold"], f2p, p2p),
            "current_repeat": grade.verdict(parsed["gold-repeat"], f2p, p2p),
            "stored_expected": stored["verdict"]["expected"],
            "current_plus_dropped_expected": len(f2p) + len(p2p) + len(rec["dropped_f2p"]),
            "dropped_passing_gold": all(parsed["gold"].get(n) == "pass" for n in rec["dropped_f2p"]),
            "dropped_passing_repeat": all(parsed["gold-repeat"].get(n) == "pass" for n in rec["dropped_f2p"]),
            "steps": [{k:v for k,v in s.items() if k != "tail"} for s in stored["steps"]]}
        if not row["current_expected_control"]["ok"] or row["current_base"]["pass"] or not row["current_gold"]["pass"] or not row["current_repeat"]["pass"]:
            raise RuntimeError("current control fails: " + ident)
        if row["stored_expected"] != row["current_plus_dropped_expected"]:
            raise RuntimeError("unexplained expected-set difference: " + ident)
        result["tasks"].append(row)
    out = HOME / "docs/research/data/2026-11-05-transfer-control-replay.json"
    with out.open("x") as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps(result, indent=2, sort_keys=True))
if __name__ == "__main__":
    main()
