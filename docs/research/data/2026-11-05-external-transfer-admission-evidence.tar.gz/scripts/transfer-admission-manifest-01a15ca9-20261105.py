import hashlib,json,pathlib
from decimal import Decimal
HOME=pathlib.Path("/home/marius/work/claude/codescout")
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/external-transfer-admission-20261105")
DATA=pathlib.Path("/home/marius/work/claude/setup-ab-data/fresh-tasks")
def digest(path):
 return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
 controls=json.loads((ROOT/"public-controls.json").read_text())
 replay=json.loads((HOME/"docs/research/data/2026-11-05-transfer-control-replay.json").read_text())
 rows=[]
 for row, private in zip(controls["results"],replay["tasks"],strict=True):
  ident=row["id"]
  assert ident==private["instance_id"] and row["public_baseline_pass"]
  rp=DATA/ident/"build/record.json";rec=json.loads(rp.read_text())
  ctx=ROOT/ident/"actual-context.json";context=json.loads(ctx.read_text())
  project=context["claude"].encode()
  assert context["claude"]==context["agents"]
  rows.append({
   "instance_id":ident,"source_image_id":row["image"],"upstream_base_commit":rec["base_commit"],
   "task_record_sha256":digest(rp),"problem_statement_sha256":hashlib.sha256(rec["problem_statement"].encode()).hexdigest(),
   "project_instructions_sha256":hashlib.sha256(project).hexdigest(),
   "public_checks":[{"id":"build" if i==0 else "tests","command":s["command"],"timeout_s":1800} for i,s in enumerate(row["steps"])],
   "control_resources":{"cpus":4,"memory_gib":24,"pids_limit":4096,"network":"none","user":"1000:1000"},
   "private_control":{"expected":private["current_expected_control"]["expected"],"f2p":len(private["f2p"]),
       "p2p":private["p2p_count"],"base_rejected":not private["current_base"]["pass"],"gold_accepted":private["current_gold"]["pass"],
       "repeat_accepted":private["current_repeat"]["pass"],"parser_sha256":private["parser_sha256"]},
   "knowledge":{"complete_source_only_snapshot":None,"author_calls_this_phase":0,
       "known_cache_inventory":"No complete suitable KB found in inspected known caches; RA22849 had only onboarding/language-pattern boilerplate. Search bounded to six levels with build/target/runs/pruned directories excluded; not exhaustive machine absence.",
       "bootstrap_evidence":str(ROOT/"native-probes"/ident),"embedding_config_required":"local:JinaEmbeddingsV2BaseCode"},
   "status":"public-and-historical-private-controls-verified; evaluated-client-admission-pending"})
 prior=Decimal("35.255714099999999604")
 result={"schema":1,"purpose":"external source/task admission, not a paid-launch authorization receipt",
  "global_instructions_sha256":digest(pathlib.Path("/home/marius/.claude/CLAUDE.md")),
  "global_instruction_comparison":"identical to previous E global snapshot; cs-hint authority factorial remains separately unmeasured",
  "setting_sources_required":"user,project,local","provider_calls_this_phase":0,"setup_author_calls_this_phase":0,
  "known_prior_cli_repair_continuation_usd":str(prior),"finite_thread_ceiling_usd":"60",
  "remaining_against_known_cli_costs_usd":str(Decimal("60")-prior),
  "budget_limits":"Not total research/setup/review/CPU/provider invoice spend; new launch must bind all existing known costs and allocate adequate author plus both-arm reserves.",
  "tasks":rows,"paid_runs_admitted":False,"pending":["generic evaluated-client task adapter and source/patch preservation",
  "actual provider-disabled CLI full instruction/skills/native/wire/oracle-boundary qualification",
  "source-only author once per project then immutable identical per-arm knowledge",
  "semantic/named-reference readiness on selected runtime",
  "independent finite mutation review and full gate for adapter",
  "fresh matched four-attempt order/full cost registration"]}
 out=HOME/"docs/research/data/2026-11-05-transfer-admission-manifest.json"
 with out.open("x") as f:json.dump(result,f,indent=2,sort_keys=True);f.write("\n")
 print(json.dumps({"path":str(out),"sha256":digest(out),"task_count":len(rows),"paid_runs_admitted":False}))
if __name__=="__main__":main()
