import asyncio, hashlib, json, os, pathlib, subprocess, time
BASE = pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
ROOT = BASE / "external-transfer-admission-20261105/native-probes"
Q = BASE / "native-env-admission-20261104/qualification-20261104"
R = BASE / "native-build-provenance-20261104"
TASKS = [
 ("nushell__nushell-18863", "sha256:3767f31b9b1a3288ad7132740dcff712737d5e855029079a4171a8065a2040ef", "src/main.rs"),
 ("rust-lang__rust-analyzer-22992", "sha256:0d74e4f14c68a438dce6cf9e4a02c626432ce12b866f55ac69c6cc687f7fff7a", "crates/rust-analyzer/src/bin/main.rs"),
]
def save(path, data):
 path.write_text(json.dumps(data, indent=2)+"\n")
def inspect(name):
 p=subprocess.run(["docker","inspect",name],capture_output=True,text=True,timeout=10)
 if p.returncode:
  if "no such" not in p.stderr.lower():raise RuntimeError(p.stderr)
  return None
 return json.loads(p.stdout)[0]
async def probe(index, ident, image, path):
 out=ROOT/ident;out.mkdir()
 home=out/"home";(home/".claude").mkdir(parents=True)
 global_bytes=pathlib.Path("/home/marius/.claude/CLAUDE.md").read_bytes()
 (home/".claude/CLAUDE.md").write_bytes(global_bytes)
 name="cs-transfer-native-01a15ca9-20261105-"+str(index)
 if inspect(name) is not None: raise RuntimeError("owned name exists")
 argv=["docker","run","--pull=never","--init","-i","--network","none","--user","1000:1000","--pids-limit","512","--cpus","2","--memory","6g","--memory-swap","6g","--tmpfs","/tmp:rw,size=1g,uid=1000,gid=1000","--name",name,"--label","codescout.transfer-native="+name]
 for host, guest in [(R/"bin","/bench/bin"),(Q/"runtime-v2","/bench/runtime"),(Q/"patched-lsp","/bench/lsp"),(Q/"jina-cache","/bench-home/.cache/codescout/fastembed")]:
  argv += ["--mount","type=bind,src="+str(host)+",dst="+guest+",readonly"]
 argv+=["--mount","type=bind,src="+str(home)+",dst=/bench-home"]
 for entry in ["HOME=/bench-home","USER=bench","PATH=/bench/lsp/bin:/opt/sab/bin:/usr/local/cargo/bin:/usr/local/bin:/usr/bin:/bin","CARGO_NET_OFFLINE=true","FASTEMBED_CACHE_PATH=/bench-home/.cache/codescout/fastembed","HF_HUB_OFFLINE=1","CODESCOUT_DISABLE_SPARSE=1","CODESCOUT_VECTOR_BACKEND=sqlite-vec","CODESCOUT_ARTIFACT_BACKEND=sqlite-vec","CODESCOUT_INDEX_FLUSH_BATCH=8"]:
  argv+=["-e",entry]
 argv+=["--workdir","/testbed","--entrypoint","/bench/bin/codescout",image,"start","--project","/testbed"]
 save(out/"launch.json",{"argv":argv,"global_sha256":hashlib.sha256(global_bytes).hexdigest(),"provider_disabled":True,"scope":"native image compatibility and source-only bootstrap; not evaluated CLI context qualification"})
 proc=None;responses=[];failure=None;seq=0;started=time.monotonic()
 err=(out/"stderr.log").open("wb")
 try:
  proc=await asyncio.create_subprocess_exec(*argv,stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=err,limit=8*1024*1024)
  async def send(row):
   proc.stdin.write((json.dumps(row)+"\n").encode());await proc.stdin.drain()
  async def rpc(method,params):
   nonlocal seq
   seq+=1;request={"jsonrpc":"2.0","id":seq,"method":method,"params":params}
   await send(request)
   while True:
    line=await asyncio.wait_for(proc.stdout.readline(),timeout=120)
    if not line:raise RuntimeError("MCP stream ended")
    response=json.loads(line)
    with (out/"wire.jsonl").open("a") as stream:stream.write(json.dumps({"request":request,"response":response})+"\n")
    if response.get("id")==seq:
     save(out/(str(seq)+"-response.json"),response)
     responses.append({"method":method,"arguments":params,"jsonrpc_error":response.get("error"),"is_error":response.get("result",{}).get("isError",False),"bytes":len(line)})
     return response
  first=await rpc("initialize",{"protocolVersion":"2025-06-18","capabilities":{},"clientInfo":{"name":"external-transfer-admission","version":"1"}})
  if "result" not in first:raise RuntimeError("initialization rejected")
  await send({"jsonrpc":"2.0","method":"notifications/initialized"})
  listed=await rpc("tools/list",{})
  save(out/"tool-names.json",[t["name"] for t in listed["result"]["tools"]])
  for tool,args in [
   ("workspace",{"action":"status"}),
   ("index",{"action":"status"}),
   ("onboarding",{}),
   ("symbols",{"path":path,"name":"main","include_body":True}),
   ("run_command",{"command":"cargo --version","effect":"read","timeout_secs":20}),
   ("read_file",{"path":"/home/marius/work/claude/codescout/Cargo.toml","start_line":1,"end_line":4,"force":True}),
  ]:
   await rpc("tools/call",{"name":tool,"arguments":args})
   print(json.dumps({"task":ident,"last":responses[-1]}),flush=True)
  p=subprocess.run(["docker","cp",name+":/testbed/.codescout",str(out/"generated-codescout")],capture_output=True,text=True,timeout=30)
  save(out/"scaffold-copy.json",{"exit_code":p.returncode,"stderr":p.stderr})
 except Exception as exc:
  failure=type(exc).__name__+": "+str(exc)
 finally:
  if proc:
   if proc.stdin:proc.stdin.close()
   try:await asyncio.wait_for(proc.wait(),timeout=8)
   except asyncio.TimeoutError:
    proc.terminate()
    try:await asyncio.wait_for(proc.wait(),timeout=5)
    except asyncio.TimeoutError:proc.kill();await proc.wait()
  err.close()
  live=inspect(name)
  if live:
   if live["Image"]!=image or live["Config"]["Labels"].get("codescout.transfer-native")!=name:raise RuntimeError("cleanup identity mismatch")
   subprocess.run(["docker","rm","-f","-v",live["Id"]],capture_output=True,check=True,timeout=60)
  gone=inspect(name) is None
  result={"id":ident,"image":image,"responses":responses,"failure":failure,"container_absent":gone,"wall_s":time.monotonic()-started,"provider_calls":0,"credential_reads":0,"onboarding_author_calls":0,"paid_admission":False}
  save(out/"result.json",result)
  print(json.dumps(result),flush=True)
  return result
async def main():
 ROOT.mkdir()
 results=[]
 for i,row in enumerate(TASKS):results.append(await probe(i,*row))
 save(ROOT/"results.json",results)
if __name__=="__main__":asyncio.run(main())
