import hashlib,json,pathlib,subprocess,time
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/external-transfer-admission-20261105/runtime-delta")
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
def main():
 binding=json.loads(pathlib.Path("/tmp/external-runtime-review-01a15ca9-20261105/review-binding.json").read_text())
 for p,h in binding["source_hashes"].items():assert hashlib.sha256((V/p).read_bytes()).hexdigest()==h,p
 rows=[]
 for suite in ("agent_lifecycle","hint_authority_pilot","hint_authority_workflow"):
  log=ROOT/(suite+"-final.log")
  if log.exists():raise RuntimeError("exclusive verification output exists")
  argv=["python3","-m","unittest","discover","-s","tools/"+suite,"-p","test_*.py","-v"]
  started=time.monotonic()
  with log.open("xb") as f:
   p=subprocess.run(argv,cwd=V,stdout=f,stderr=subprocess.STDOUT,timeout=60)
  row={"suite":suite,"argv":argv,"exit_code":p.returncode,"wall_s":time.monotonic()-started,
   "log_sha256":hashlib.sha256(log.read_bytes()).hexdigest()}
  rows.append(row)
  print(json.dumps(row),flush=True)
  assert p.returncode==0
 result={"suites":rows,"review_source_hashes":binding["source_hashes"],
  "scope":"Final research suites separately executed; no inference that they belong to product gate Python lane."}
 with (ROOT/"verification.json").open("x") as f:json.dump(result,f,indent=2);f.write("\n")
if __name__=="__main__":main()
