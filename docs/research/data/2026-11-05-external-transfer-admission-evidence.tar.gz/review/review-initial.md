# External runtime review — original snapshot

Base d3c1d104708df2d21a6cf6920d72e3af8ff9ddc6; original five reviewed hashes in source-hashes-initial.json. Original verdict: with fixes, due one Important instrument defect.

Observed baseline:61 lifecycle methods pass. Exactly8 distinct candidate mutations applied independently:7 direct assertion kills,0survivors,1instrument-invalid result,0harness timeouts. See aggregate-initial.json and e01 through e08 patches/logs. All private source restorations matched the original snapshot.

Important finding: test_external_runtime.py:93 returned text JSON for all Docker operations, including binary head output. Removing preserve_background_logs's image guard at qualify.py:84 (e05) reached write_bytes with str and recorded TypeError. The test failed at its error-text assertion (original test line104), not a meaningful wrong-image byte-copy witness. This result was explicitly excluded from assertion kills. Fix the stub's response types and repeat only this exact mutation.

The cleanup guard mutation e06 completed in38.574s after the existing30s absence poll and failed the expected identity-mismatch assertion. That is a completed assertion kill, not a harness timeout.

No production defect was observed. Explicit image forwarding at workflow.py:153,161,167, the other image checks at qualify.py:44,135, and memory normalization/validation at workflow.py:34,71 had observed assertion kills. No V/MAIN source writes, real Docker, provider, credential or native qualification calls occurred.

This report preserves the original snapshot and invalid measurement; the later corrected-fixture result belongs to review.md and e09, not this initial result.

Ledger checked:2db5e6fbda0834c2 (related cleanup race); the reported fixture defect was subsequently filed as26021c97d11af0a0.
