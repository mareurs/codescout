# External runtime contract review

Verdict: accepted for the exact five-path source hashes in source-hashes.json. No unresolved Important or Critical finding remains after the specifically authorized fixture correction and one exact mutation recheck. This review is not paid-run admission.

Base d3c1d104708df2d21a6cf6920d72e3af8ff9ddc6. V and MAIN source remained read-only. All mutations ran on private copies under this review directory. The original snapshot report is preserved in review-initial.md with its original source hashes and aggregate.

## Initial and corrected evidence

Initial baseline:61 lifecycle methods pass. Initial pass: exactly8 distinct candidate mutations;7 direct assertion kills,0survivors,1instrument-invalid result,0harness timeouts.

The eight candidates independently removed:
1. runtime.IMAGE forwarding to native_record (workflow.py:161).
2. runtime.IMAGE forwarding to preserve_background_logs (workflow.py:153).
3. runtime.IMAGE forwarding to cleanup_native (workflow.py:167).
4. native_record's image mismatch guard (qualify.py:44).
5. preserve_background_logs's image mismatch guard (qualify.py:84).
6. cleanup_owned's image mismatch guard (qualify.py:135).
7. requested memory normalization, replacing it with fixed12g (workflow.py:71).
8. integer1..64 memory validation (workflow.py:34).

Candidate5 is retained as instrument-invalid: the original mock supplied str for a bytes-producing head call and caused TypeError. Its test failure is not counted as a valid assertion kill. Candidate6 completed normally after the existing30s absence deadline, then failed the identity-mismatch assertion; no harness timeout occurred.

The parent corrected only test_external_runtime.py. Production hashes stayed identical. The new fixture returns bytes for head, JSON for cat, and explicitly rejects forbidden operations. I read the revised test at test_external_runtime.py:84.

One specifically authorized reapplication e09 repeats candidate5 with a byte-identical mutation patch. The corrected external-runtime suite passes4methods before mutation. Under e09, the helper actually accepts the wrong-image byte-copy and produces complete=true; test_external_runtime.py:110 rejects that result with AssertionError: True is not false. After exact source restoration, the same4methods pass again. No TypeError, import error or harness timeout underlies this kill.

Totals across both phases:8 distinct candidates,9 executions,8 valid assertion-killed executions,1 historical instrument-invalid execution,0survivors,0unresolved invalid results,0harness timeouts. This is a finite observed result, not a coverage percentage.

## Resolved finding

Issue26021c97d11af0a0: original capture-guard test's unrealistic response type masked a missing guard. Exact original e05.patch/log/result remain retained; e09 supplies the meaningful corrected observation. Parent owns status updates, broader test execution and the full gate.

## Contract assessment

qualify.py:28,62,122 accepts optional explicit image and preserves pilot IMAGE when omitted. workflow.py independently forwards runtime.IMAGE to record reads, log capture and exact owned cleanup. Existing immutable-ID and label conditions remain in the reviewed diff.

workflow.py:32 defaults to12GiB, accepts actual integer memory values1..64 (booleans excluded), and produces requested24GiB while retaining4CPU/init and existing Docker-option checks. The tests observe normalized argv and invalid values.

The external fixture uses a real client subprocess with Docker boundaries mocked and exercises both external image labels, background continuation, saved log bytes and exact-ID cleanup. Existing legacy test paths pass in the initial61-method baseline.

## Declined to judge

- Actual native image operation and resource feasibility: parent-owned qualifications, not established by mocked Docker tests.
- Model/provider behavior, paid admission and generic quality: no such work or claim here.
- Full gate and commits: parent-owned and not independently verified. Parent reports a full gate began before the final test-only fixture change; this reviewer records the corrected focused baseline only.
- Unchanged broader campaign/runtime logic: outside this finite delta.

No real Docker, credentials, providers, qualifiers or actor/model campaign was invoked. No second eight-candidate pass was run. All five final hashes match V, restored work and pristine-final.

Ledger checked:2db5e6fbda0834c2 (related),26021c97d11af0a0 (resolved by corrected witness in this review).
