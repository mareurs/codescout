"""Model-free continuation with bounded single-job Cargo compilation."""
import hashlib
import json
import pathlib
import sys
import time

ROOT=pathlib.Path(__file__).resolve().parent
OLD=ROOT.parent/"blind-contrast-verifier-followup-20261107"
sys.path.insert(0,str(OLD))
import evaluate_v3 as ev
import run_pair


def sha(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(pathlib.Path(path).read_text())


def save(path, data):
    with pathlib.Path(path).open('x') as f:
        json.dump(data, f, indent=2)
        f.write('\n')


def single_job_docker(docker, out):
    """Set Cargo concurrency only on run; retain CID even if proof fails."""
    proofs = []
    def wrapped(*args, **kwargs):
        if not args or args[0] != 'run':
            return docker(*args, **kwargs)
        result = docker('run', '--env=CARGO_BUILD_JOBS=1', *args[1:], **kwargs)
        if result.returncode == 0 and result.stdout.strip():
            cid = result.stdout.strip()
            proof = {'container': cid, 'single_job_env_present': False, 'inspect_exit_code': None}
            try:
                observed = docker('inspect', '--format', '{{json .Config.Env}}', cid, check=False)
                proof['inspect_exit_code'] = observed.returncode
                if observed.returncode == 0:
                    proof['single_job_env_present'] = 'CARGO_BUILD_JOBS=1' in json.loads(observed.stdout)
            except Exception as exc:
                proof['probe_error'] = type(exc).__name__
            proofs.append(proof)
            try:
                with (out / 'compile-environment.jsonl').open('a') as f:
                    f.write(json.dumps(proof) + '\n')
            except OSError as exc:
                proof['record_error'] = type(exc).__name__
        return result
    wrapped.proofs = proofs
    return wrapped


def main():
    run_pair.require_frozen_pair(ROOT,['low','xhigh'])
    original=load(ROOT/'xhigh/oracle-evaluation-results.json')
    assert len(original['rows'])==1 and not original['rows'][0]['valid']
    invalid=original['rows'][0]
    assert invalid['label']=='baseline' and invalid['steps'][0]['exit_code']==0
    assert invalid['runtime']['oom_kill']==0 and not invalid['runtime']['resource_ok']
    assert any('host resource floor violated' in e for e in invalid['runtime']['errors'])
    assert load(ROOT/'low/oracle-evaluation-results.json')['all_three_valid']
    reg=load(ROOT/'xhigh/oracle-evaluation-registration.json')
    assert sha(OLD/'evaluate_v3.py')==reg['executor_sha256']
    record=pathlib.Path('/home/marius/work/claude/setup-ab-data/fresh-tasks/nushell__nushell-18863/build/record.json')
    assert sha(record)=='8bb14b9ac8bd98d78f3ae2e3776a523b64d826269a79277058ea2677f5344114'
    frozen=ROOT/'xhigh/frozen/generated-tests.patch'
    assert sha(frozen)==reg['test_patch_sha256']
    wait_only=load(ROOT/'offline-continuation-1/stopped.json')
    assert wait_only['rows_completed']==0 and wait_only['provider_calls']==0
    out=ROOT/'offline-single-job-2'; out.mkdir()
    (out/'generated-tests.patch').write_bytes(frozen.read_bytes())
    bindings={str(p):sha(p) for p in [ROOT/'all-authors-frozen.json',ROOT/'low/oracle-evaluation-results.json',ROOT/'xhigh/oracle-evaluation-results.json',ROOT/'xhigh/oracle-evaluation-registration.json',frozen,record,OLD/'evaluate_v3.py',pathlib.Path(__file__)]}
    for variant in reg['variants']:
        if variant['patch']:
            assert sha(variant['patch'])==variant['sha256']; bindings[variant['patch']]=variant['sha256']
    registration={'bindings':bindings,'evaluation':reg,'selection':'Only resource-invalid xhigh baseline and previously unstarted wrong/reference. Valid low cells remain untouched.','cargo_build_jobs':1,'prelaunch_host_available_gib':28,'prelaunch_consecutive_samples':3,'prelaunch_interval_s':10,'continuous_host_floor_gib':24,'native_hard_limit_gib':8,'cpus':4,'model_calls':0,'automatic_retry':False,'max_wait_per_cell_s':900}
    save(out/'registration.json',registration)
    ev.ROOT=out; ev.q.FLOORS=reg['floors']; parser=load(record)['log_parser']; rows=[]
    wrapped=single_job_docker(ev.docker,out)
    ev.docker=wrapped
    try:
        for variant in reg['variants']:
            for p,h in bindings.items(): assert sha(p)==h,p
            run_pair.require_frozen_pair(ROOT,['low','xhigh'])
            deadline=time.monotonic()+900; good=0
            while time.monotonic()<deadline:
                sample=ev.q.host_sample()
                with (out/'admission-samples.jsonl').open('a') as f: f.write(json.dumps({'label':variant['label'],'sample':sample})+'\n')
                if sample['mem_gib']>=28 and sample['root_gib']>=80 and sample['tmp_gib']>=4:
                    good+=1
                    if good>=3: break
                else: good=0
                time.sleep(10)
            else: raise RuntimeError('Bounded admission expired before '+variant['label'])
            result=ev.cell(reg,variant,parser)
            proof=wrapped.proofs[-1] if wrapped.proofs else {}
            if proof.get('container') != result['runtime']['container'] or not proof.get('single_job_env_present') or proof.get('record_error'):
                result['valid']=False
                result['error']='Missing or invalid single-job compilation environment proof'
            rows.append(result)
            if not result['valid']: break
        result={'rows':rows,'all_three_valid':len(rows)==3 and all(r['valid'] for r in rows),'provider_calls':0,'original_resource_invalid_retained':True,'frozen_patch_unchanged':sha(frozen)==reg['test_patch_sha256']}
        save(out/'results.json',result)
        print(json.dumps({'all_three_valid':result['all_three_valid'],'cells_completed':len(rows),'provider_calls':0},indent=2))
    except BaseException as exc:
        save(out/'stopped.json',{'error':type(exc).__name__+': '+str(exc),'rows_completed':len(rows),'provider_calls':0,'automatic_retry':False})
        raise

if __name__ == '__main__':
    main()
