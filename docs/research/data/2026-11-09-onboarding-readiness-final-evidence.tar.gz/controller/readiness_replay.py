"""Consume actual captured native wire; no model, indexing, or worker launch."""
import hashlib
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "tools/effort_protocol"))
# This script lives four levels below the repository, not in a package.
sys.path.insert(0, str(Path.cwd() / "tools/effort_protocol"))
from readiness import validate_readiness
from receipts import input_digest

root = Path(sys.argv[1])
project = root / "project"
summary = json.loads((root / "summary.json").read_text())
container = json.loads((root / "container-before.json").read_text())
calls = json.loads((root / "calls.json").read_text())
specs = []
witnesses = {
    "references": ["src/lib.rs", "use_double"],
    "symbol_at": ["pub fn double"],
    "call_graph": ["use_double", "lsp"],
    "semantic_search": ["src/lib.rs", "double"],
}
observations = []
for n, (tool, arguments) in enumerate(calls, 3):
    if tool in witnesses:
        specs.append({"tool": tool, "arguments": arguments, "must_contain": witnesses[tool]})
        observations.append({"tool": tool, "arguments": arguments,
                             "response": json.loads((root / f"reply-{n}.json").read_text())})
binding = {"image": container["Image"], "executable_sha256": summary["executable_sha256"],
           "source_snapshot_sha256": input_digest(project, ["Cargo.toml", "CLAUDE.md", "src"]),
           "knowledge_sha256": input_digest(project, [".codescout/project.toml"])}
expected = {"project_root": "/testbed", "languages": ["rust"],
            "tools": ["symbols", "references", "symbol_at", "call_graph", "semantic_search"],
            "binding": binding, "probes": specs}
wire = {"binding": binding, "status": json.loads((root / "reply-3.json").read_text()),
        "index_verification": json.loads((root / "reply-8.json").read_text()),
        "tool_pages": [json.loads((root / "reply-2.json").read_text())], "probes": observations}
result = validate_readiness(expected, wire)
(root / "readiness.json").write_text(json.dumps({"expected": expected, "wire": wire, "result": result}, indent=2))
print(json.dumps(result, indent=2))
