"""Read-only audit of frozen config inputs; does not activate old projects."""
import hashlib
import json
from pathlib import Path
import sys
import tomllib

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

reg = Path("/home/marius/.cache/codescout-resident/codescout/semantic-contract-paid-20261107/registration.json")
registration = json.loads(reg.read_text())
rows = []
for arm in registration["arms"]:
    out = Path(arm["out"])
    config = out / "knowledge/project.toml"
    project = tomllib.loads(config.read_text())["project"]
    declared = arm["writable_hashes"]
    mems = sorted((out / "knowledge/memories").glob("*.md"))
    docs = [{"path": str(p), "sha256": sha(p), "bytes": p.stat().st_size,
             "matches_registered_hash": sha(p) == declared[str(p)] if str(p) in declared else None}
            for p in mems]
    pinned = {}
    for label, path in (("global_rules", out / "global-CLAUDE.md"),
                        ("project_rules", out / "instructions/CLAUDE.md"),
                        ("system_prompt", out / "knowledge/system-prompt.md")):
        expected = arm["immutable_hashes"].get(str(path), declared.get(str(path)))
        pinned[label] = {"path": str(path), "sha256": sha(path),
                         "matches_registered_hash": sha(path) == expected if expected else None}
    rows.append({"arm_id": arm["arm_id"], "config_path": str(config),
                 "languages": project.get("languages"), "onboarding_version": project.get("onboarding_version"),
                 "config_sha256": sha(config), "matches_launch_config_hash": sha(config) == declared[str(config)],
                 "root_memory_markdown_files": docs, "rules": pinned})
oracle = []
root = reg.parent.parent / "baseline-first-oracle-20261107"
for arm in ("low", "xhigh"):
    directory = root / arm / "verifier"
    config = directory / "knowledge/project.toml"
    requests = list(directory.glob("request-*.json"))
    advertised = set()
    for path in requests:
        value = json.loads(path.read_text())
        for tool in value.get("tools", []):
            if isinstance(tool, dict):
                advertised.add(tool.get("name", ""))
    oracle.append({"arm": arm, "config_sha256": sha(config),
                   "languages": tomllib.loads(config.read_text())["project"].get("languages"),
                   "request_files_read": len(requests),
                   "api_advertised_lsp_tools_seen": sorted(t for t in advertised if t.split("__")[-1] in {"references", "symbol_at", "call_graph"}),
                   "limit": "Deferred API advertisement absence does not establish MCP tool unavailability."})
result = {"registration": str(reg), "registration_sha256": sha(reg),
          "registered_arm_count": len(registration["arms"]), "config_rows": rows,
          "oracle_pair_configs": oracle,
          "interpretation": "Inputs only; no historical live MCP/LSP/backend or CLAUDE-delivery requalification, no activation of sealed roots."}
Path(sys.argv[1]).write_text(json.dumps(result, indent=2))
print(json.dumps({"registered_arms": len(rows), "rust_present": sum("rust" in r["languages"] for r in rows),
                  "launch_config_hash_matches": sum(r["matches_launch_config_hash"] for r in rows),
                  "root_memory_files_per_arm": [len(r["root_memory_markdown_files"]) for r in rows]}))
