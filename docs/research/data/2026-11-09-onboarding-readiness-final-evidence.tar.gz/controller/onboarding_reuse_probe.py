"""Reuse the programmatic fixture config; index locally, then probe real MCP."""
import hashlib
import json
import os
from pathlib import Path
import select
import shutil
import subprocess
import sys
import time
import uuid

def main():
    original = Path(sys.argv[1])
    out = Path(sys.argv[2]).absolute()
    out.mkdir(exist_ok=False)
    root = out / "project"
    root.mkdir()
    for name in ("src", "Cargo.toml", "CLAUDE.md"):
        src = original / "project" / name
        shutil.copytree(src, root / name) if src.is_dir() else shutil.copy2(src, root / name)
    (root / ".codescout").mkdir()
    cfg = (original / "project/.codescout/project.toml").read_text()
    # The initial hardware recommendation is not the study's pinned daily model.
    cfg = cfg.replace('model = "local:AllMiniLML6V2Q"', 'model = "local:JinaEmbeddingsV2BaseCode"')
    (root / ".codescout/project.toml").write_text(cfg)
    home = out / "home"; home.mkdir()
    old = json.loads((original / "container-before.json").read_text())
    image = old["Image"]
    name = "effort-onboard-reuse-" + uuid.uuid4().hex
    argv = ["docker", "create", "--pull=never", "--name", name, "--init", "--network", "none",
            "--label", "codescout.effort-onboarding=" + name, "--user", "1000:1000",
            "--cpus", "2", "--memory", "4g", "--memory-swap", "4g", "--pids-limit", "512",
            "--tmpfs", "/tmp:rw,exec,size=128m,uid=1000,gid=1000", "--cap-drop", "ALL",
            "--security-opt", "no-new-privileges", "--entrypoint", "/bin/sleep", "--workdir", "/testbed"]
    for m in old["Mounts"]:
        if m["Destination"] in {"/bench/bin", "/bench/runtime", "/bench/lsp", "/bench-home/.cache/codescout/fastembed"}:
            argv += ["--mount", "type=bind,src=" + m["Source"] + ",dst=" + m["Destination"] + ",readonly"]
    argv += ["--mount", f"type=bind,src={root},dst=/testbed",
             "--mount", f"type=bind,src={home},dst=/bench-home"]
    for value in old["Config"]["Env"]:
        if value.split("=")[0] in {"HOME", "USER", "PATH", "CARGO_NET_OFFLINE", "HF_HUB_OFFLINE",
                                  "CODESCOUT_DISABLE_SPARSE", "FASTEMBED_CACHE_PATH", "CODESCOUT_VECTOR_BACKEND",
                                  "CODESCOUT_ARTIFACT_BACKEND", "CODESCOUT_SQLITE_DIR", "MCP_PROTOCOL_NEGOTIATION"}:
            argv += ["-e", value]
    argv += [image, "infinity"]
    def docker(*args):
        return subprocess.run(["docker", *args], capture_output=True, text=True, timeout=180, check=True)
    cid = ""; proc = None
    summary = {"provider_calls": 0, "onboarding_author_calls": 0, "programmatic_onboarding_calls": 0}
    try:
        cid = subprocess.run(argv, capture_output=True, text=True, timeout=60, check=True).stdout.strip()
        state = json.loads(docker("inspect", cid).stdout)[0]
        if state["Id"] != cid or state["Image"] != image or state["Name"] != "/" + name or state["Config"]["Labels"].get("codescout.effort-onboarding") != name:
            raise ValueError("native ownership mismatch")
        (out / "container-before.json").write_text(json.dumps(state, indent=2))
        docker("start", cid)
        result = subprocess.run(["docker", "exec", cid, "/bench/bin/codescout", "index", "-p", "/testbed"],
                                capture_output=True, text=True, timeout=180)
        (out / "index.stdout").write_text(result.stdout)
        (out / "index.stderr").write_text(result.stderr)
        summary["index_exit"] = result.returncode
        stderr = (out / "server.stderr").open("wb")
        proc = subprocess.Popen(["docker", "exec", "-i", cid, "/bench/bin/codescout", "start", "--project", "/testbed"],
                                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr)
        buf = b""
        def request(method, params, number):
            nonlocal buf
            proc.stdin.write((json.dumps({"jsonrpc": "2.0", "id": number, "method": method, "params": params}) + "\n").encode()); proc.stdin.flush()
            deadline = time.monotonic() + 120
            while time.monotonic() < deadline:
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    if line.strip():
                        reply = json.loads(line)
                        if reply.get("id") == number:
                            (out / f"reply-{number}.json").write_text(json.dumps(reply, indent=2))
                            return reply
                ready, _, _ = select.select([proc.stdout], [], [], max(0, deadline - time.monotonic()))
                if ready:
                    chunk = os.read(proc.stdout.fileno(), 65536)
                    if not chunk: raise RuntimeError("MCP EOF")
                    buf += chunk
            raise TimeoutError(method)
        request("initialize", {"protocolVersion": "2025-06-18", "capabilities": {}, "clientInfo": {"name": "effort-readiness-reuse", "version": "1"}}, 1)
        proc.stdin.write(b'{"jsonrpc":"2.0","method":"notifications/initialized"}\n'); proc.stdin.flush()
        request("tools/list", {}, 2)
        calls = [("workspace", {"action": "status"}),
                 ("references", {"path": "src/lib.rs", "symbol": "double"}),
                 ("symbol_at", {"path": "src/lib.rs", "line": 2, "col": 34}),
                 ("call_graph", {"path": "src/lib.rs", "symbol": "double", "direction": "callers"}),
                 ("semantic_search", {"query": "double the input value", "limit": 3}),
                 ("index", {"action": "verify"})]
        for n, (tool, arguments) in enumerate(calls, 3):
            request("tools/call", {"name": tool, "arguments": arguments}, n)
        (out / "calls.json").write_text(json.dumps(calls, indent=2))
        summary["executable_sha256"] = docker("exec", cid, "sha256sum", "/bench/bin/codescout").stdout.split()[0]
        proc.stdin.close(); proc.wait(timeout=30)
        summary["server_exit"] = proc.returncode
    finally:
        if proc and proc.poll() is None: proc.kill(); proc.wait(timeout=15)
        if cid:
            docker("rm", "-f", cid)
            summary["owned_container_absent"] = not docker("ps", "-a", "--no-trunc", "--filter", "id=" + cid, "--format", "{{.ID}}").stdout.strip()
        (out / "summary.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))

if __name__ == "__main__":
    main()
