"""Model-free native onboarding control; only new owned fixtures are writable."""
import hashlib
import json
import os
from pathlib import Path
import select
import subprocess
import sys
import time
import uuid

def main():
    out = Path(sys.argv[1]).absolute()
    out.mkdir(exist_ok=False)
    source = out / "project"
    source.mkdir()
    (source / "src").mkdir()
    (source / "Cargo.toml").write_text('[package]\nname="readiness_fixture"\nversion="0.1.0"\nedition="2021"\n')
    (source / "src/lib.rs").write_text("pub fn double(value: i32) -> i32 { value * 2 }\npub fn use_double() -> i32 { double(3) }\n")
    (source / "CLAUDE.md").write_text("# Public readiness fixture\nUse the configured Codescout project.\n")
    home = out / "home"
    home.mkdir()
    old = json.loads(Path(sys.argv[2]).read_text())
    image = old[-4]
    name = "effort-onboard-" + uuid.uuid4().hex
    base = ["docker", "create", "--pull=never", "--init", "--name", name,
            "--label", "codescout.effort-onboarding=" + name, "--network", "none",
            "--user", "1000:1000", "--cpus", "2", "--memory", "4g",
            "--memory-swap", "4g", "--pids-limit", "512",
            "--tmpfs", "/tmp:rw,exec,size=128m,uid=1000,gid=1000",
            "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
            "--entrypoint", "/bin/sleep"]
    for i, arg in enumerate(old[:-1]):
        if arg == "--mount":
            spec = dict(p.split("=", 1) for p in old[i + 1].split(",") if "=" in p)
            if spec.get("dst") in {"/bench/bin", "/bench/runtime", "/bench/lsp", "/bench-home/.cache/codescout/fastembed"}:
                base += ["--mount", old[i + 1]]
    base += ["--mount", f"type=bind,src={source},dst=/testbed",
             "--mount", f"type=bind,src={home},dst=/bench-home",
             "--workdir", "/testbed"]
    env = ["HOME=/bench-home", "USER=bench",
           "PATH=/bench/lsp/bin:/opt/sab/bin:/usr/local/cargo/bin:/usr/local/bin:/usr/bin:/bin",
           "CARGO_NET_OFFLINE=true", "HF_HUB_OFFLINE=1", "CODESCOUT_DISABLE_SPARSE=1",
           "FASTEMBED_CACHE_PATH=/bench-home/.cache/codescout/fastembed",
           "CODESCOUT_VECTOR_BACKEND=sqlite-vec", "CODESCOUT_ARTIFACT_BACKEND=sqlite-vec",
           "CODESCOUT_SQLITE_DIR=/testbed/.codescout/embeddings",
           "MCP_PROTOCOL_NEGOTIATION=legacy"]
    for e in env:
        base += ["-e", e]
    base += [image, "infinity"]
    def docker(*args):
        return subprocess.run(["docker", *args], text=True, capture_output=True, timeout=60, check=True)
    cid = ""
    proc = None
    summary = {"image": image, "provider_calls": 0, "onboarding_author_calls": 0, "steps": []}
    try:
        cid = subprocess.run(base, capture_output=True, text=True, timeout=60, check=True).stdout.strip()
        inspect = json.loads(docker("inspect", cid).stdout)[0]
        if inspect["Id"] != cid or inspect["Name"] != "/" + name or inspect["Config"]["Labels"].get("codescout.effort-onboarding") != name or inspect["Image"] != image:
            raise ValueError("owned native container identity mismatch")
        (out / "container-before.json").write_text(json.dumps(inspect, indent=2))
        docker("start", cid)
        stderr = (out / "server.stderr").open("wb")
        proc = subprocess.Popen(["docker", "exec", "-i", cid, "/bench/bin/codescout", "start", "--project", "/testbed"],
                                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr)
        buf = b""
        def request(method, params, number):
            nonlocal buf
            proc.stdin.write((json.dumps({"jsonrpc": "2.0", "id": number, "method": method, "params": params}) + "\n").encode())
            proc.stdin.flush()
            deadline = time.monotonic() + 120
            while time.monotonic() < deadline:
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    if line.strip():
                        response = json.loads(line)
                        if response.get("id") == number:
                            (out / f"reply-{number}.json").write_text(json.dumps(response, indent=2))
                            summary["steps"].append({"id": number, "method": method, "params": params})
                            return response
                ready, _, _ = select.select([proc.stdout], [], [], max(0, deadline - time.monotonic()))
                if ready:
                    chunk = os.read(proc.stdout.fileno(), 65536)
                    if not chunk:
                        raise RuntimeError("native MCP EOF")
                    buf += chunk
            raise TimeoutError(f"native MCP deadline: {method}")
        request("initialize", {"protocolVersion": "2025-06-18", "capabilities": {}, "clientInfo": {"name": "effort-readiness-control", "version": "1"}}, 1)
        proc.stdin.write(b'{"jsonrpc":"2.0","method":"notifications/initialized"}\n'); proc.stdin.flush()
        before = request("tools/list", {}, 2)
        names = {t["name"] for t in before.get("result", {}).get("tools", [])}
        status_name = "workspace" if "workspace" in names else "activate_project"
        if status_name == "workspace":
            request("tools/call", {"name": status_name, "arguments": {"action": "status"}}, 3)
        request("tools/call", {"name": "onboarding", "arguments": {}}, 4)
        after = request("tools/list", {}, 5)
        request("tools/call", {"name": "workspace", "arguments": {"action": "status"}}, 6)
        request("tools/call", {"name": "symbols", "arguments": {"path": "src/lib.rs", "name": "double", "include_body": True}}, 7)
        request("tools/call", {"name": "references", "arguments": {"path": "src/lib.rs", "symbol": "double"}}, 8)
        request("tools/call", {"name": "symbol_at", "arguments": {"path": "src/lib.rs", "line": 2, "column": 34}}, 9)
        request("tools/call", {"name": "call_graph", "arguments": {"path": "src/lib.rs", "symbol": "double", "direction": "callers"}}, 10)
        summary["tools_before"] = sorted(names)
        summary["tools_after"] = sorted(t["name"] for t in after.get("result", {}).get("tools", []))
        config = source / ".codescout/project.toml"
        summary["project_config_sha256"] = hashlib.sha256(config.read_bytes()).hexdigest() if config.exists() else None
        proc.stdin.close()
        proc.wait(timeout=30)
        summary["server_exit"] = proc.returncode
    finally:
        if proc and proc.poll() is None:
            proc.kill(); proc.wait(timeout=15)
        if cid:
            docker("rm", "-f", cid)
            absent = docker("ps", "-a", "--no-trunc", "--filter", "id=" + cid, "--format", "{{.ID}}").stdout.strip() == ""
            summary["owned_container_absent"] = absent
        (out / "summary.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))

if __name__ == "__main__":
    main()
