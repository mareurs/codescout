"""Actual four-state native readiness characterization; no model/client inference."""
import asyncio,json,pathlib,shutil,sys,hashlib
W=pathlib.Path(__file__).resolve().parent
E=W.parent/'native-env-admission-20261104';S=E/'semantic-minimal-20261104'
sys.path.insert(0,str(E));from reuse_native_probe import Native,text,save
async def main():
 outcomes=[]
 for populated,marker in [(False,False),(False,True),(True,False),(True,True)]:
  root=W/('readiness-'+str(int(populated))+str(int(marker)));root.mkdir(exist_ok=False)
  actor=root/'project';shutil.copytree(S/'tiny-project',actor,ignore=shutil.ignore_patterns('embeddings'))
  db=actor/'.codescout/embeddings'
  if populated:shutil.copytree(S/'tiny-project/.codescout/embeddings',db)
  else:db.mkdir()
  if marker:(db/'project.db').write_bytes(b'')
  home=root/'home';(home/'.cache/codescout/fastembed').mkdir(parents=True)
  out=root/'mcp';out.mkdir();x=Native(actor,home,out)
  args=json.loads((S/'cli-launch.json').read_text())['argv'];args[1]='run';args[2:2]=['-i'];args[args.index('--name')+1]=x.name;args[args.index('--label')+1]='codescout.reuse-probe='+x.name;args[-3:]=['start','--project','/testbed']
  for i,value in enumerate(args):
   if value.startswith('type=bind,') and 'dst=/bench/bin' in value.split(','):args[i]='type=bind,src='+str(W/'bin')+',dst=/bench/bin,readonly'
   if value.startswith('type=bind,') and 'dst=/testbed' in value.split(','):args[i]='type=bind,src='+str(actor)+',dst=/testbed'
   if value.startswith('type=bind,') and 'dst=/bench-home' in value.split(','):args[i]='type=bind,src='+str(home)+',dst=/bench-home'
  save(out/'launch.json',dict(argv=args,container_name=x.name));x.err=(out/'stderr.log').open('wb');x.proc=await asyncio.create_subprocess_exec(*args,stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=x.err,limit=2**22)
  try:
   await x.rpc('initialize',dict(protocolVersion='2025-06-18',capabilities={},clientInfo=dict(name='readiness-counterexample',version='1')));await x.send(dict(jsonrpc='2.0',method='notifications/initialized'))
   status=await x.call('index',dict(action='status'));primary=json.loads(status['result']['content'][0]['text']);raw=text(status)
   query=await x.call('semantic_search',dict(query='group severity log messages and count entries',limit=3,detail_level='full'));q=json.loads(query['result']['content'][0]['text'])
   observed=dict(populated=populated,legacy_zero_byte_marker=marker,indexed=primary['indexed'],queryable=primary.get('queryable'),bootstrap_built='Semantic index:** Built' in raw,bootstrap_not_built='Semantic index:** Not built' in raw,returned_results=len(q.get('results',[])))
   assert observed['indexed']==populated,observed
   assert observed['bootstrap_built']==populated,observed
   assert observed['bootstrap_not_built']==(not populated),observed
   assert bool(observed['returned_results'])==populated,observed
   outcomes.append(observed);save(root/'observation.json',observed)
  finally:await x.__aexit__(None,None,None)
 save(W/'readiness-results.json',dict(outcomes=outcomes,proposition='Actual bootstrap and native status/search follow the selected backend population independently of zero-byte legacy marker',new_model_calls=0,observed_binary_all_four_cells_consistent=True,source_to_binary_build_proven=False,paid_worker_admitted=False));print(json.dumps(outcomes),flush=True)
if __name__=='__main__':asyncio.run(main())
