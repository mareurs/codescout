"""Model-free MCP checks on two independent copies; records complete wire evidence."""
import asyncio,hashlib,json,os,pathlib,subprocess,uuid
R=pathlib.Path(__file__).resolve().parent
TASK='rust-lang__rust-bindgen-3390'
IMAGE='sha256:911fb163bff53a3cf755fd472526e1195d1c1df6c6e6b57e10e41b869b0875bd'
def save(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
class Native:
 def __init__(self,actor,home,out):self.actor,self.home,self.out=actor,home,out;self.seq=0;self.proc=None;self.name='reuse-native-'+uuid.uuid4().hex
 async def __aenter__(self):
  self.out.mkdir(parents=True,exist_ok=False);self.home.mkdir(parents=True,exist_ok=False)
  (self.home/'.claude').mkdir();(self.home/'.claude/CLAUDE.md').write_bytes((R/'global-CLAUDE.md').read_bytes())
  args=['docker','run','--pull=never','--rm','-i','--network','none','--read-only','--user',str(os.getuid())+':'+str(os.getgid()),'--pids-limit','256','--memory','4g','--tmpfs','/tmp:rw,size=1g,uid='+str(os.getuid())+',gid='+str(os.getgid()),'--name',self.name,'--label','codescout.reuse-probe='+self.name,'-e','HOME=/bench-home','-e','USER=bench','-e','CARGO_NET_OFFLINE=true']
  for host,guest,ro in [(R/'bin','/bench/bin',True),(R/'runtime','/bench/runtime',True),(self.actor,'/testbed',False),(self.home,'/bench-home',False)]:args+=['--mount','type=bind,src='+str(host)+',dst='+guest+(',readonly' if ro else '')]
  args+=['--workdir','/testbed','--entrypoint','/bench/runtime/ld-linux-x86-64.so.2',IMAGE,'--library-path','/bench/runtime','/bench/bin/codescout','start','--project','/testbed']
  save(self.out/'launch.json',dict(argv=args,actor=str(self.actor),container_name=self.name))
  self.err=(self.out/'stderr.log').open('wb')
  self.proc=await asyncio.create_subprocess_exec(*args,stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=self.err,limit=2**22)
  try:
   await self.rpc('initialize',dict(protocolVersion='2025-06-18',capabilities={},clientInfo=dict(name='reuse-isolation-probe',version='1')))
   await self.send(dict(jsonrpc='2.0',method='notifications/initialized'))
   return self
  except BaseException:
   await self.__aexit__(None,None,None);raise
 async def send(self,x):self.proc.stdin.write((json.dumps(x)+'\n').encode());await self.proc.stdin.drain()
 async def rpc(self,method,params):
  self.seq+=1;req=dict(jsonrpc='2.0',id=self.seq,method=method,params=params);await self.send(req)
  while True:
   line=await asyncio.wait_for(self.proc.stdout.readline(),timeout=90)
   if not line:raise RuntimeError('MCP stream ended')
   row=json.loads(line)
   with (self.out/'wire.jsonl').open('a') as f:f.write(json.dumps(dict(request=req,response=row))+'\n')
   if row.get('id')==self.seq:
    save(self.out/(str(self.seq)+'-response.json'),row)
    if row.get('error') or row.get('result',{}).get('isError'):raise RuntimeError('Native RPC error '+json.dumps(row))
    return row
 async def call(self,name,args):return await self.rpc('tools/call',dict(name=name,arguments=args))
 async def __aexit__(self,*_):
  if self.proc:
   self.proc.stdin.close()
   try:await asyncio.wait_for(self.proc.wait(),timeout=8)
   except asyncio.TimeoutError:self.proc.terminate();await asyncio.wait_for(self.proc.wait(),timeout=5)
  if hasattr(self,'err'):self.err.close()
  p=subprocess.run(['docker','inspect',self.name],capture_output=True,text=True,timeout=15)
  if p.returncode==0:
   row=json.loads(p.stdout)[0]
   if row['Image']!=IMAGE or row['Config']['Labels'].get('codescout.reuse-probe')!=self.name:raise ValueError('Wrong cleanup owner')
   subprocess.run(['docker','rm','-f',row['Id']],check=True,capture_output=True,timeout=15)
  p=subprocess.run(['docker','inspect',self.name],capture_output=True,text=True,timeout=15)
  absent=p.returncode==1 and 'no such' in p.stderr.lower();save(self.out/'cleanup.json',dict(container_absent=absent,name=self.name));assert absent

def text(row):return '\n'.join(c.get('text','') for c in row['result'].get('content',[]) if c.get('type')=='text')
async def main():
 import snapshot_reuse as cache
 author_starts_before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (R/'onboarding-author').glob('*/started.json')}
 spec=json.loads((R/'bindgen-snapshot-spec.json').read_text());snapshot=R/'snapshots'/TASK
 cache.verify(snapshot,spec['baseline']);clones=R/'reuse-clones';clones.mkdir(exist_ok=False)
 a,b=clones/'A',clones/'B';ca=cache.clone(snapshot,a,spec['baseline']);cb=cache.clone(snapshot,b,spec['baseline'])
 initial_a=cache.inventory(a);initial_b=cache.inventory(b);assert initial_a==initial_b
 ah,bh=clones/'home-A',clones/'home-B'
 async with Native(a,ah,clones/'mcp-A') as x,Native(b,bh,clones/'mcp-B') as y:
  wa=await x.call('workspace',dict(action='status'));wb=await y.call('workspace',dict(action='status'))
  oa=await x.call('onboarding',{});ob=await y.call('onboarding',{})
  # The native tool's actual completed-path wording must be observed, not guessed from config.
  for row in [oa,ob]:
   s=text(row).lower()
   assert 'onboarding already performed' in s or 'already onboarded' in s,s
   assert 'onboarding-prompt.md' not in s and 'refresh required' not in s,s
  # Path-based tree-sitter bodies test copy binding without claiming named LSP lookup works.
  (a/'reuse_probe.rs').write_text('pub fn onboarding_clone_probe() -> u32 { 101 }\n')
  (b/'reuse_probe.rs').write_text('pub fn onboarding_clone_probe() -> u32 { 202 }\n')
  body_a=await x.call('symbols',dict(path='reuse_probe.rs',detail_level='full'))
  body_b=await y.call('symbols',dict(path='reuse_probe.rs',detail_level='full'))
  assert '101' in text(body_a) and 'onboarding_clone_probe' in text(body_a),text(body_a)
  assert '202' in text(body_b) and '101' not in text(body_b),text(body_b)
  assert '101' in (a/'reuse_probe.rs').read_text() and '202' in (b/'reuse_probe.rs').read_text()
  ma=await x.call('memory',dict(action='write',topic='reuse-isolation-probe',content='# Isolation\nA_ONLY_REUSE_PROBE\n'))
  mb=await y.call('memory',dict(action='read',topic='reuse-isolation-probe'))
  assert not (b/'.codescout/memories/reuse-isolation-probe.md').exists()
  assert 'A_ONLY_REUSE_PROBE' not in text(mb)
  (b/'CLAUDE.md').write_text('B_ONLY_REUSE_PROBE\n');assert 'B_ONLY_REUSE_PROBE' not in (a/'CLAUDE.md').read_text()
 cache.verify(snapshot,spec['baseline'])
 author_starts_after={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (R/'onboarding-author').glob('*/started.json')}
 assert author_starts_before==author_starts_after
 result=dict(project=TASK,snapshot_id=ca['snapshot_id'],initial_clone_populations_equal=True,initial_files=len(initial_a),new_author_start_receipts=len(set(author_starts_after)-set(author_starts_before)),author_start_receipts_before=author_starts_before,author_start_receipts_after=author_starts_after,native_onboarding_reused_both=True,source_symbol_body_isolated=True,memory_writes_isolated=True,instruction_writes_isolated=True,snapshot_unchanged=True,containers_absent=True,native_lsp_ready_claimed=False,ready_for_paid_runs=False)
 save(R/'reuse-native-result.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':asyncio.run(main())
