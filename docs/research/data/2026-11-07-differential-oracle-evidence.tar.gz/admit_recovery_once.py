"""One registered pre-model technical recovery, with no automatic model retry."""
import hashlib
import json
import pathlib
import subprocess
import sys
import time
from decimal import Decimal
import runtime_compat
import supervision_headroom as health

ROOT=pathlib.Path(__file__).resolve().parent
OLD=ROOT.parent/"differential-oracle-20261107"
SOURCE=pathlib.Path("/home/marius/.codex/worktrees/ca35/codescout")

def sha(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()

def save(name,value):
    with (ROOT/name).open("x") as stream:
        json.dump(value,stream,indent=2)
        stream.write("\n")

def state():
    return {"head":subprocess.check_output(["git","-C",str(SOURCE),"rev-parse","HEAD"],text=True).strip(),
            "status":subprocess.check_output(["git","-C",str(SOURCE),"status","--porcelain"],text=True)}

def main():
    reg=json.loads((ROOT/"registration.json").read_text())
    out=pathlib.Path(reg["out"])
    assert not any((out/name).exists() for name in ("started.json","launch.json","receipt.json"))
    gate=json.loads((ROOT/"fixture-source-gate-process.json").read_text())
    assert gate["exit_code"]==0 and gate["unchanged"] is True and state()==gate["after"]
    qualification=OLD/"legacy-startup-probe"
    good=json.loads((qualification/"receipt.json").read_text())
    assert good["workflow_completed"] is True and good["forwarded"]==0 and good["unknown_provider_cost"] is False
    assert len(list(qualification.glob("mcp-launch-*.json")))==1
    assert all(x["absent"] is True for x in json.loads((qualification/"cleanup.json").read_text()))
    assert json.loads((qualification/"supervision-final.json").read_text())["complete"] is True
    compat_test=json.loads((ROOT/"runtime-compat-check.json").read_text())
    assert compat_test["source_sha256"]==sha(ROOT/"runtime_compat.py") and compat_test["survived"]==0
    packet=json.loads((out/"prepared.json").read_text())
    original=json.loads((OLD/"verifier/prepared.json").read_text())
    assert packet["prompt"]==original["prompt"]
    assert hashlib.sha256(packet["prompt"].encode()).hexdigest()=="6d829f1b3ba9e2811fbc5986faa1e10deb9d732a2e12741740e4b2e16cf79a1b"
    for name in ("baseline.log","low-control.log","probe-source.rs"):
        assert sha(ROOT/"public-observations"/name)==sha(OLD/"public-observations"/name)
    committed_upper=Decimal(reg["prior_series_usd"])+Decimal("4")+Decimal(reg["reserve_usd"])
    assert committed_upper<=Decimal(reg["series_ceiling_usd"])
    stdio=runtime_compat.materialize(out)
    bound={str(p):sha(p) for p in (
        pathlib.Path(__file__),ROOT/"registration.json",ROOT/"run_verifier_recovery.py",
        ROOT/"runtime_compat.py",ROOT/"runtime-compat-check.json",ROOT/"supervision_headroom.py",stdio,
        ROOT/"evaluate_oracle_v2.py",ROOT/"fixture-source-gate-process.json",
        qualification/"receipt.json",qualification/"supervision-final.json",qualification/"cleanup.json")}
    save("recovery-registration.json",{
        "role":"One technical recovery after zero-forwarding startup failure; no model outcome selected",
        "original_attempt_root":str(OLD),"bound":bound,"same_public_prompt_and_observation_bytes":True,
        "client_env":{"MCP_PROTOCOL_NEGOTIATION":"legacy"},"single_native_connection_required":True,
        "stdio_retains_diagnostics_until_owned_cleanup":True,"raw_debug_private_mode":"0600",
        "prior_known_cost_usd":reg["prior_series_usd"],"prior_unresolved_reserve_usd":"4",
        "this_cli_cap_usd":reg["cli_cap_usd"],"this_reserve_usd":reg["reserve_usd"],
        "known_plus_both_reserves_usd":str(committed_upper),"ceiling_usd":reg["series_ceiling_usd"],
        "prelaunch_host_available_gib":24,"continuous_host_available_gib":16,
        "continuous_interval_s":2,"native_hard_cap_gib_unchanged":32,"offline_host_floor_gib":24,
        "max_wait_s":900,"model_attempts_max":1,"automatic_paid_retry":False})
    consecutive=0
    deadline=time.monotonic()+900
    while time.monotonic()<deadline:
        host=health.host_sample()
        eligible=host["mem_available"]>=24*1024**3 and host["root_free"]>=80*1024**3 and host["tmp_free"]>=4*1024**3
        consecutive=consecutive+1 if eligible else 0
        with (ROOT/"admission-samples.jsonl").open("a") as stream:
            stream.write(json.dumps({"time":time.time(),"host":host,"eligible":eligible,"consecutive":consecutive})+"\n")
        if consecutive==3:
            assert state()==gate["after"]
            assert all(sha(path)==expected for path,expected in bound.items())
            save("attempt.json",{"time":time.time(),"host":host,"automatic_retry":False})
            with (ROOT/"oracle-author.log").open("xb") as log:
                author=subprocess.run([sys.executable,"-B",str(ROOT/"run_verifier_recovery.py")],stdout=log,stderr=subprocess.STDOUT,timeout=1900)
            save("author-process.json",{"exit_code":author.returncode,"closed_receipt_saved":(ROOT/"verifier-closed.json").exists()})
            if author.returncode:
                save("cost-reservation.json",{"reserve_usd":reg["reserve_usd"],"reason":"Author did not validly close; reconcile preserved final receipt","model_retry":False})
                raise RuntimeError("Recovery author invalid; reconcile terminal/cost, no paid retry")
            assert all(sha(path)==expected for path,expected in bound.items())
            with (ROOT/"oracle-evaluation.log").open("xb") as log:
                evaluated=subprocess.run([sys.executable,"-B",str(ROOT/"evaluate_oracle_v2.py")],stdout=log,stderr=subprocess.STDOUT,timeout=5700)
            save("evaluation-process.json",{"exit_code":evaluated.returncode,"results_saved":(ROOT/"oracle-evaluation-results.json").exists()})
            if evaluated.returncode:
                raise RuntimeError("Frozen-output evaluation needs audit, no model retry")
            return
        time.sleep(10)
    save("not-launched.json",{"reason":"No sustained host admission within900seconds","provider_calls":0,"credentials_read":False})

if __name__=="__main__":
    main()
