"""Prepare one fresh oracle-author session with public differential observations."""
import hashlib
import importlib.util
import json
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent
BASE = ROOT.parent
OLD = BASE / "blind-contrast-verifier-followup-20261107"
ORIGINAL = BASE / "semantic-contract-runtime-20261106/prepared/arms/nushell__nushell-18863--low-control"
SOURCE = pathlib.Path("/home/marius/.codex/worktrees/ca35/codescout")
OUT = ROOT / "verifier"
ACTOR = pathlib.Path("/tmp/cs-differential-oracle-recovery-01a15ca9-20261107")

def load(path):
    return json.loads(pathlib.Path(path).read_text())

def sha(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()

def save(path, value):
    pathlib.Path(path).write_text(json.dumps(value, indent=2) + "\n")

def main():
    assert not OUT.exists() and not ACTOR.exists() and not (ROOT / "registration.json").exists()
    observations = load(ROOT / "observation-v2-results.json")
    assert observations["both_valid"] is True
    assert not subprocess.check_output(["git", "-C", str(SOURCE), "status", "--porcelain"], text=True)
    assert subprocess.check_output(["git", "-C", str(SOURCE), "rev-parse", "HEAD"], text=True).strip() == "fe8bb4b34f5e7912f9b16c4c0bf1ff73a3a10a23"
    packet = ROOT / "public-observations"
    packet.mkdir()
    for row in observations["rows"]:
        source = pathlib.Path(row["steps"][-1]["log"])
        assert sha(source) == row["steps"][-1]["sha256"]
        shutil.copyfile(source, packet / (row["label"] + ".log"))
    shutil.copyfile(ROOT / "observation-v2/probe-source.rs", packet / "probe-source.rs")
    old_reg = load(OLD / "registration.json")
    cfg = load(ORIGINAL / "prepared.json")
    project = load(BASE / "semantic-contract-pilot-20261106/prompt-inputs-registration.json")["projects"]["nushell__nushell-18863"]
    manifest_path = pathlib.Path(project["runtime_snapshot_manifest"])
    assert sha(manifest_path) == project["runtime_snapshot_manifest_sha256"]
    manifest = load(manifest_path)
    prep_path = pathlib.Path("/home/marius/work/claude/codescout/.worktrees/semantic-contract-runtime-01a15ca9/tools/agent_lifecycle/semantic_prepare.py")
    spec = importlib.util.spec_from_file_location("frozen_prep", prep_path)
    prep = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(prep)
    cloned = prep.clone_snapshot(manifest_path.parent, OUT, manifest)
    save(OUT / "clone-proof.json", cloned)
    ACTOR.mkdir()
    for name in ("CLAUDE.md", "AGENTS.md"):
        shutil.copyfile(ORIGINAL / "actor-context" / name, ACTOR / name)
    shutil.copyfile(ORIGINAL / "global-CLAUDE.md", OUT / "global-CLAUDE.md")
    native = prep.rewrite_native(load(ORIGINAL / "mcp-native-argv.json"), OUT, manifest["projects"], "cs-differential-oracle-01a15ca9")
    native[-4] = old_reg["image"]
    native[-4:-4] = ["--mount", "type=bind,src=" + str(packet) + ",dst=/public-observations,readonly"]
    save(OUT / "mcp-native-argv.json", native)
    guidance, task = cfg["prompt"].split("Repair task:\n", 1)
    protocol = """Oracle-author task (supersedes the general repair instruction above)

A proposed repair is already applied in /testbed. Its diff is /proposal/candidate.patch.
You also have public differential observations in /public-observations:
- probe-source.rs: three expectation-free probes; each records before/after stored payload, operation exit, and actual evaluation/output/exit of $ans.
- baseline.log and low-control.log: complete raw outputs from exactly that probe source on the public baseline and this proposal.
All probe tests return success to collect observations; that success says nothing about correctness. The harness runs probes concurrently, so unmarked console output can interleave; only OBS records carry reliable per-probe attribution. A zero fetch exit code alone does not establish the semantic contract.

Your job is to decide what behavior the repair is required to change and what it must preserve. Inspect the observations and relevant source/caller contracts. For every probe p1, p2, p3, classify its observed change as unchanged, intended_change, regression, or unresolved. Justify expected behavior from the public issue or an observed source contract; do not invent extra requirements from the proposed implementation. A baseline difference is not automatically a regression, because the reported bug itself must change. If the public evidence cannot decide an oracle, say unresolved.

Write oracle_decisions.json as {"probes":[{"id":"p1","classification":"...","basis":"...","source_evidence":["path:symbol"],"test_names":["contrast_..."]}, ...]} with exactly p1,p2,p3.

For conclusions you can justify, add executable tests named contrast_... in the existing appropriate test module or a new integration file. Distinguish assertions supported by a public requirement from preservation assertions supported by baseline/source evidence. Run them and retain counterexample failures; do not repair or weaken the proposed production change. Do not alter existing test bodies, production, configuration, CLAUDE.md or AGENTS.md. Do not commit, push or access external sources.

Finish by reporting the probe decisions, the new assertion commands/results, and any uncertainty. This task concerns oracle selection; you are not told any reference solution or private acceptance outcome.
"""
    (ROOT / "oracle-protocol.txt").write_text(protocol)
    cfg.update(image=old_reg["image"], actor=str(ACTOR), global_rules=str(OUT / "global-CLAUDE.md"),
        prompt=guidance + "Original public repair request:\n" + task + "\n\n" + protocol,
        checks=[{"id":"patch_hygiene_only","command":"git diff --check"},
                {"id":"oracle_file_syntax_only","command":"python3 -m json.tool oracle_decisions.json >/dev/null"}],
        timeout_s=1800, check_timeout_s=30, max_continuations=8)
    cfg["files"] = {str(p): sha(p) for p in (OUT / "mcp-native-argv.json", OUT / "global-CLAUDE.md", pathlib.Path(cfg["cli"]), ACTOR / "CLAUDE.md", ACTOR / "AGENTS.md")}
    save(OUT / "prepared.json", cfg)
    shutil.copyfile(OLD / "run_verifier.py", ROOT / "run_verifier.py")
    hashes = {p:h for p,h in old_reg["hashes"].items() if p.startswith(str(SOURCE) + "/") or p.endswith("/supervision.py") or p.endswith("/grade_policy.py")}
    hashes.update(cfg["files"])
    hashes.update({str(OUT / rel): proof["sha256"] for rel, proof in manifest["files"].items()})
    hashes.update({str(p): sha(p) for p in packet.iterdir()})
    hashes.update({str(p): sha(p) for p in (ROOT / "prepare_judge.py", ROOT / "run_verifier.py", ROOT / "oracle-protocol.txt", ROOT / "observation-v2-registration.json", ROOT / "observation-v2-results.json", OUT / "prepared.json", prep_path)})
    save(ROOT / "registration.json", {
        "status":"prepared_unstarted", "retry_allowed":False,
        "question":"Can public baseline/proposal observations improve the oracle chosen by one fresh low actor?",
        "role":"exposed_development_oracle_author", "source":str(SOURCE),
        "source_commit":"fe8bb4b34f5e7912f9b16c4c0bf1ff73a3a10a23",
        "out":str(OUT), "image":cfg["image"], "effort":"low",
        "reserve_usd":"4", "cli_cap_usd":"3", "prior_series_usd":"62.153943199999999054",
        "series_ceiling_usd":"200", "hashes":hashes,
        "proposal_sha256":old_reg["proposal_sha256"],
        "public_packet_paths":sorted(str(p) for p in packet.iterdir()),
        "exclusions":["reference","private test patch","private grades","prior diagnosis","prior actor transcript","expected probe classifications"],
    })
    print(json.dumps({"prepared":str(OUT),"packet_files":sorted(p.name for p in packet.iterdir()),"provider_calls":0,"prompt_sha256":hashlib.sha256(cfg["prompt"].encode()).hexdigest()},indent=2))

if __name__ == "__main__":
    main()
