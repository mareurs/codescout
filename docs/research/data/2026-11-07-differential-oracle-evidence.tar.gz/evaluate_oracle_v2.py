"""Freeze the new oracle/test additions before private reference evaluation."""
import json
import pathlib
import re
import shutil
import sys

ROOT = pathlib.Path(__file__).resolve().parent
OLD = ROOT.parent / "blind-contrast-verifier-followup-20261107"
sys.path.insert(0, str(OLD))
import evaluate_v3 as ev

def executable_test_names(patch):
    added = "\n".join(line[1:] for line in patch.decode().splitlines()
                      if line.startswith("+") and not line.startswith("+++"))
    # Conservative supported declaration form; caller cross-checks actor's declared
    # list and actual runtime statuses. Unknown forms fail explicitly.
    pattern = r"(?m)^[ \t]*#\[test\][ \t]*\n(?:[ \t]*(?://[^\n]*|#\[[^\n]*\])\n)*[ \t]*fn (contrast_[A-Za-z0-9_]+)\("
    return re.findall(pattern, added)


def freeze():
    closed = ev.load(ROOT / "verifier-closed.json")
    capture = ROOT / "verifier/candidate.patch"
    assert ev.sha(capture) == closed["generated_candidate_sha256"]
    original = ev.segments((ROOT.parent / "blind-contrast-verifier-20261107/image-context/candidate.patch").read_bytes())
    generated = ev.segments(capture.read_bytes())
    assert all(generated.get(k) == v for k, v in original.items()), "Production proposal changed"
    extras = {k:v for k,v in generated.items() if k not in original}
    decision = extras.pop("oracle_decisions.json")
    assert b"new file mode" in decision
    data = b"".join(line[1:] + b"\n" for line in decision.splitlines() if line.startswith(b"+") and not line.startswith(b"+++"))
    parsed = json.loads(data)
    assert {p["id"] for p in parsed["probes"]} == {"p1", "p2", "p3"} and len(parsed["probes"]) == 3
    allowed = {"unchanged", "intended_change", "regression", "unresolved"}
    assert all(p["classification"] in allowed and isinstance(p["basis"], str) for p in parsed["probes"])
    assert all(k.startswith("crates/nu-cli/tests/") and k.endswith(".rs") for k in extras)
    assert all(not any(line.startswith(b"-") and not line.startswith(b"---") for line in part.splitlines()) for part in extras.values()), "Existing tests removed"
    patch = b"".join(extras.values())
    names = executable_test_names(patch)
    declared = {name for p in parsed["probes"] for name in p["test_names"]}
    assert set(names) == declared, "Unsupported or unreported test declaration form; no count inferred"
    assert len(names) == len(set(names)), "Duplicate executable test names"
    (ROOT / "oracle_decisions.json").write_bytes(data)
    if not names:
        ev.save(ROOT / "oracle-abstained.json", {
            "actor_validly_closed":True, "generated_candidate_sha256":closed["generated_candidate_sha256"],
            "decisions":parsed, "executable_assertions":0, "mechanism_result":"no_detector_produced",
            "scope":"Abstention is not an infrastructure failure and does not demonstrate discrimination",
        })
        return None, None
    out = ROOT / "oracle-evaluation"
    out.mkdir()
    (out / "generated-tests.patch").write_bytes(patch)
    old = ev.load(OLD / "evaluation-registration.json")
    reg = {
        "image":old["image"], "tests":list(names), "test_patch_sha256":ev.sha(out / "generated-tests.patch"),
        "actor_candidate_sha256":ev.sha(capture), "decisions_sha256":ev.sha(ROOT / "oracle_decisions.json"),
        "source_sha256":ev.sha(__file__), "executor_sha256":ev.sha(OLD / "evaluate_v3.py"),
        "variants":[old["variants"][i] for i in (0,1,4)], "floors":dict(ev.q.FLOORS,mem_gib=24),
        "boundary":"Actor closed and output frozen before host-only reference access; exposed diagnostic",
    }
    ev.save(ROOT / "oracle-evaluation-registration.json",reg)
    return reg,out

def main():
    reg, out = freeze()
    if reg is None:
        print("Oracle author closed without an executable detector; see oracle-abstained.json")
        return
    parser = ev.load("/home/marius/work/claude/setup-ab-data/fresh-tasks/nushell__nushell-18863/build/record.json")["log_parser"]
    ev.ROOT = out
    ev.q.FLOORS = reg["floors"]
    rows = []
    for row in reg["variants"]:
        sample = ev.q.host_sample()
        assert all(sample[k] >= floor for k, floor in reg["floors"].items()), sample
        result = ev.cell(reg, row, parser)
        rows.append(result)
        if not result["valid"]:
            break
    ev.save(ROOT / "oracle-evaluation-results.json", {
        "rows": rows, "all_three_valid": len(rows) == 3 and all(r["valid"] for r in rows),
        "provider_calls": 0, "frozen_test_patch_sha256": reg["test_patch_sha256"],
    })
    print(json.dumps(ev.load(ROOT / "oracle-evaluation-results.json"), indent=2))

if __name__ == "__main__":
    main()
