"""Launch exactly one registered verifier using the unchanged qualified adapter."""
import hashlib
import importlib.util
import json
import pathlib
import sys
from decimal import Decimal

ROOT = pathlib.Path(__file__).resolve().parent
BASE = ROOT.parent
SOURCE = pathlib.Path("/home/marius/.codex/worktrees/ca35/codescout")
COMPAT = BASE / "semantic-contract-native-probe-20261107"
sys.path[:0] = [str(SOURCE / "tools/agent_lifecycle"), str(SOURCE / "tools"), str(SOURCE / "tools/hint_authority_pilot"), str(COMPAT)]
import external
from supervision_headroom import Supervisor, host_sample, FLOORS
from runtime_compat import install

def load(path):
    return json.loads(pathlib.Path(path).read_text())

def sha(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()

def save(path, value):
    with pathlib.Path(path).open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")

def main():
    reg_path = ROOT / "registration.json"
    reg = load(reg_path)
    assert reg["status"] == "prepared_unstarted" and reg["retry_allowed"] is False
    for path, expected in reg["hashes"].items():
        assert sha(path) == expected, "Registered input drift: " + path
    assert str(pathlib.Path(external.__file__).resolve()) == str(SOURCE / "tools/agent_lifecycle/external.py")
    out = pathlib.Path(reg["out"])
    assert not any((out / name).exists() for name in ("started.json", "launch.json", "receipt.json"))
    cfg, _, _, _, _ = external.validate_prepared(out, reg["effort"], reg["reserve_usd"], reg["cli_cap_usd"])
    native = load(out / "mcp-native-argv.json")
    mount_rows = []
    for index, arg in enumerate(native):
        if arg == "--mount":
            mount_rows.append(native[index + 1])
    assert native[-4] == reg["image"] == cfg["image"]
    assert all(str(out) in row or "readonly" in row for row in mount_rows)
    assert not any(word in cfg["prompt"] for word in ("mixed_str_length_result_does_replace_last", "value_is_error_only", "8619", "8620", "gold.patch", "grade.log"))
    policy = pathlib.Path("/home/marius/.codex/worktrees/add2/codescout/tools/setup-ab-eval/grade_policy.py")
    host = host_sample()
    assert all(host[key] >= floor for key, floor in FLOORS.items()), host
    install(external,out)
    supervisor = Supervisor(policy)
    preflight = {
        "registration_sha256": sha(reg_path), "runner_sha256": sha(__file__),
        "actual_mounts": mount_rows, "image": reg["image"], "host_resource_preflight": host,
        "plugin_hashes": {str(p): sha(p) for p in pathlib.Path(cfg["plugin"]).rglob("*") if p.is_file()},
        "public_checks_are_hygiene_only": True, "provider_calls_at_preflight": 0,
        "mcp_protocol_negotiation": "legacy",
        "native_stdio_sha256": sha(out / "compat-stdio/stdio.py"),
        "excluded_private_inputs_not_mounted": True, "retry_allowed": False,
    }
    save(ROOT / "launch-preflight.json", preflight)
    receipt = None
    try:
        receipt = external.launch(out, effort=reg["effort"], allowance=reg["reserve_usd"],
                                  cli_cap=reg["cli_cap_usd"], supervisor=supervisor)
        spec = importlib.util.spec_from_file_location("cost_driver", SOURCE / "tools/hint_authority_workflow/driver.py")
        driver = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(driver)
        cost = driver.reconcile(out, receipt, Decimal(reg["reserve_usd"]))
        assert receipt["workflow_completed"] is True
        assert len(list(out.glob("mcp-launch-*.json"))) == 1, "Unexpected native connection count"
        assert receipt["artifact_evidence"]["complete"] is True
        proof = load(out / "supervision-final.json")
        assert proof["complete"] is True and proof["oom_kill"] == 0
        # Writable actor state has deliberately changed; recheck only immutable packet/source.
        state_prefixes = tuple(str(out / name) + "/" for name in ("knowledge", "member-state", "native-home", "instructions"))
        for path, expected in reg["hashes"].items():
            if not path.startswith(state_prefixes):
                assert sha(path) == expected, "Immutable input drift: " + path
        assert sha(reg_path) == preflight["registration_sha256"]
        save(ROOT / "verifier-closed.json", {
            "status": "closed", "cost_usd": str(cost),
            "series_known_subtotal_usd": str(Decimal(reg["prior_series_usd"]) + cost),
            "generated_candidate_sha256": sha(out / "candidate.patch"),
            "generated_output_frozen_before_private_evaluation": True,
            "detector_result": "unmeasured_pending_assertion_execution",
            "receipt_sha256": sha(out / "receipt.json"),
            "supervision_sha256": sha(out / "supervision-final.json"),
        })
        print(json.dumps(load(ROOT / "verifier-closed.json"), indent=2))
    except BaseException as exc:
        save(ROOT / "verifier-stopped.json", {
            "type": type(exc).__name__, "message": str(exc)[:1000],
            "receipt_saved": (out / "receipt.json").exists(),
            "cost_state": "reconcile preserved receipts; do not infer zero",
            "retry_allowed": False,
        })
        raise

if __name__ == "__main__":
    main()
