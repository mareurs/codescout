import json,pathlib,subprocess,sys,uuid
root=pathlib.Path(sys.argv[1])
args=json.loads((root/'mcp-native-argv.json').read_text())
name='hfa-native-'+uuid.uuid4().hex
args[args.index('--name')+1]=name
args[args.index('--label')+1]='codescout.hfa='+name
(root/('mcp-launch-'+name+'.json')).write_text(json.dumps({'argv':args,'name':name}))
with (root/('native-stderr-'+name+'.log')).open('xb') as err:
 p=subprocess.run(args,stderr=err)
(root/('mcp-exit-'+name+'.json')).write_text(json.dumps({'exit_code':p.returncode}))
sys.exit(p.returncode)
