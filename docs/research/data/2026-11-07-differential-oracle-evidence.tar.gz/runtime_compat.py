"""Process-local legacy negotiation and credential-safe diagnostic capture."""
import json
import pathlib
import re

STDIO = """import json,pathlib,subprocess,sys,uuid
root=pathlib.Path(sys.argv[1])
args=json.loads((root/'mcp-native-argv.json').read_text())
name='hfa-native-'+uuid.uuid4().hex
args[args.index('--name')+1]=name
args[args.index('--label')+1]='codescout.hfa='+name
(root/('mcp-launch-'+name+'.json')).write_text(json.dumps({'argv':args,'name':name}))
with (root/('native-stderr-'+name+'.log')).open('xb') as err:
 p=subprocess.run(args,stderr=err)
(root/('mcp-exit-'+name+'.json')).write_text(json.dumps({'exit_code':p.returncode}))
sys.exit(p.returncode)
"""

def materialize(out):
    folder=pathlib.Path(out)/"compat-stdio"
    folder.mkdir()
    with (folder/"stdio.py").open("x") as stream:
        stream.write(STDIO)
    return folder/"stdio.py"

def sanitize(data,secret):
    if secret:
        data=data.replace(secret,"<redacted-authorized-token>")
        data=data.replace(json.dumps(secret)[1:-1],"<redacted-authorized-token>")
    return re.sub(r"[A-Za-z0-9_./+=-]{32,}","<long-literal-redacted>",data)

def install(external,out):
    folder=pathlib.Path(out)/"compat-stdio"
    assert (folder/"stdio.py").read_text()==STDIO
    external.worker.HERE=folder
    original=external.workflow.execute
    def execute(runtime,config,out,actor,argv,env,server,session_id,hook_state,available,**kwargs):
        env=dict(env,MCP_PROTOCOL_NEGOTIATION="legacy")
        raw=out/"cli-debug.raw.log"
        raw.touch(mode=0o600,exist_ok=False)
        argv=list(argv)
        argv[1:1]=["--debug-file",str(raw)]
        secret=env.get("CLAUDE_CODE_OAUTH_TOKEN","")
        try:
            return original(runtime,config,out,actor,argv,env,server,session_id,hook_state,available,**kwargs)
        finally:
            if raw.exists():
                (out/"cli-debug.sanitized.log").write_text(sanitize(raw.read_text(errors="replace"),secret))
                raw.chmod(0o600)
    external.workflow.execute=execute
