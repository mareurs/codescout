import base64,hashlib,json,os,pathlib,socket,struct,sys
SID='01a15ca9-f939-7603-acb5-01c6b02f68e2'
PATH='/tmp/codex-daemon-1000/baf3e85a09b78b9cfda90cb671ccb79eccfdb541c0cf5df29937c7e7d2543998'
s=socket.socket(socket.AF_UNIX);s.settimeout(25);s.connect(PATH)
key=base64.b64encode(os.urandom(16)).decode()
s.sendall(('GET / HTTP/1.1\r\nHost: localhost\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: '+key+'\r\nSec-WebSocket-Version: 13\r\n\r\n').encode())
header=b''
while not header.endswith(b'\r\n\r\n'):header+=s.recv(1)
assert header.startswith(b'HTTP/1.1 101'),header
accept=base64.b64encode(hashlib.sha1((key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').encode()).digest())
assert accept in header
def send(obj,opcode=1):
 b=json.dumps(obj).encode() if opcode==1 else obj;n=len(b);mask=os.urandom(4)
 h=bytes([128|opcode,128|min(n,126)]) if n<126 else bytes([128|opcode,254])+struct.pack('!H',n)
 s.sendall(h+mask+bytes(v^mask[i%4] for i,v in enumerate(b)))
def exact(n):
 b=b''
 while len(b)<n:
  c=s.recv(n-len(b));assert c,'EOF';b+=c
 return b
def receive():
 pieces=b''
 while True:
  a,b=exact(2);n=b&127
  if n==126:n=struct.unpack('!H',exact(2))[0]
  elif n==127:n=struct.unpack('!Q',exact(8))[0]
  assert not b&128
  data=exact(n);opcode=a&15
  if opcode==9:send(data,10);continue
  assert opcode!=8,'closed'
  pieces+=data
  if a&128:return json.loads(pieces)
def rpc(i,method,params):
 send({'id':i,'method':method,'params':params})
 while True:
  r=receive()
  if r.get('id')==i:return r
init=rpc(1,'initialize',{'clientInfo':{'name':'codescout-deployment-audit','version':'1'},'capabilities':{'experimentalApi':True}})
assert 'result' in init,init
send({'method':'initialized'})
mode=sys.argv[1] if len(sys.argv)>1 else 'read'
if mode=='reload':
 result=rpc(2,'config/mcpServer/reload',None)
elif mode=='call':
 result=rpc(2,'mcpServer/tool/call',{'threadId':SID,'server':'codescout','tool':'workspace','arguments':{'action':'status'}})
else:
 r=rpc(2,'thread/read',{'threadId':SID,'includeTurns':False})
 if 'result'in r:
  t=r['result']['thread'];result={k:t.get(k) for k in ['id','sessionId','status','cwd']}
 else:result=r
print(json.dumps(result,indent=2));s.close()
out=pathlib.Path('/home/marius/.cache/codescout-resident/codescout/native-build-provenance-20261104')
(out/('appserver-'+mode+'.json')).write_text(json.dumps(result,indent=2)+'\n')
