import hashlib,json,os,pathlib,shutil,subprocess,time
ROOT=pathlib.Path('/home/marius/work/claude/codescout')
OUT=pathlib.Path('/home/marius/.cache/codescout-resident/codescout/native-build-provenance-20261104')
OUT.mkdir(parents=True,exist_ok=True)
os.chdir(ROOT)
def run(args):
    return subprocess.check_output(args,text=True).strip()
def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()
scopes=['src','crates','scripts','build.rs','Cargo.toml','Cargo.lock','.cargo','docs/PROGRESSIVE_DISCOVERABILITY.md','docs/trackers/operator-rules.md']
def inventory():
    names=subprocess.check_output(['git','ls-files','-z','--',*scopes]).decode().split('\0')
    result={}
    for name in sorted(filter(None,names)):
        p=ROOT/name
        result[name]={'link':os.readlink(p)} if p.is_symlink() else {'sha256':sha(p),'bytes':p.stat().st_size}
    return result
def save(name,obj): (OUT/name).write_text(json.dumps(obj,indent=2)+'\n')
head=run(['git','rev-parse','HEAD'])
before=inventory(); save('source-before.json',before)
assert not run(['git','status','--porcelain','--untracked-files=all','--',*scopes]),'Build inputs dirty'
receipt={'head':head,'started':time.time(),'scopes':scopes,'source_files':len(before),'source_scope':'tracked files in explicit build scopes; inventory before and after, not filesystem access tracing','dependency_scope':'Cargo.lock and existing shared dependency cache; not an independent dependency rebuild','toolchain':{x:run(cmd) for x,cmd in [('rustc',['rustc','-vV']),('cargo',['cargo','-vV'])]},'environment':{k:os.environ[k] for k in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_TARGET_DIR','CARGO_BUILD_TARGET','CARGO_BUILD_JOBS'] if k in os.environ}}
save('receipt.json',receipt)
for label,command in [('gate',['./scripts/gate.sh','--check']),('build',['./scripts/rb.sh','--locked','--offline','-v'])]:
    receipt[label]={'command':command,'started':time.time()}; save('receipt.json',receipt)
    with (OUT/(label+'.log')).open('wb') as log:
        rc=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT).returncode
    receipt[label].update(exit_code=rc,finished=time.time()); save('receipt.json',receipt)
    if rc: raise SystemExit(rc)
    assert inventory()==before,'Build inputs changed'
    assert run(['git','rev-parse','HEAD'])==head,'HEAD changed'
after=inventory(); save('source-after.json',after)
src=ROOT/'target/release/codescout'; dst=OUT/'codescout'
with src.open('rb') as f, dst.open('wb') as g:
    st=os.fstat(f.fileno()); shutil.copyfileobj(f,g); assert os.fstat(f.fileno())==st
assert src.stat().st_ino==st.st_ino
dst.chmod(0o755)
receipt.update(finished=time.time(),inputs_unchanged=before==after,output={'sha256':sha(dst),'bytes':dst.stat().st_size,'original_inode':st.st_ino,'original_mtime_ns':st.st_mtime_ns,'copied_to':str(dst)},version=run([str(dst),'version']))
save('receipt.json',receipt)
print(json.dumps(receipt,indent=2))
