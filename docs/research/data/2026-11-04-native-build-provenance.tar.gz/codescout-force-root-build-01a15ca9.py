import hashlib,json,os,pathlib,subprocess,time,shutil
ROOT=pathlib.Path('/home/marius/work/claude/codescout');os.chdir(ROOT)
OUT=pathlib.Path('/home/marius/.cache/codescout-resident/codescout/native-build-provenance-20261104')
before=json.loads((OUT/'source-before.json').read_text());head=json.loads((OUT/'receipt.json').read_text())['head']
def check():
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
 for name,v in before.items():
  p=ROOT/name
  assert ({'link':os.readlink(p)} if p.is_symlink() else {'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})==v,name
check()
receipt={'started':time.time(),'head':head,'invalidation':'build.rs mtime only; content checked identical before and after','command':['./scripts/rb.sh','--locked','--offline','-v'],'source_manifest':'source-before.json','dependency_cache_reused':True}
os.utime(ROOT/'build.rs',None)
with (OUT/'forced-root-build.log').open('wb') as f:receipt['exit_code']=subprocess.run(receipt['command'],stdout=f,stderr=subprocess.STDOUT).returncode
check(); receipt['finished']=time.time();receipt['inputs_unchanged']=True
src=ROOT/'target/release/codescout'; receipt['sha256']=hashlib.sha256(src.read_bytes()).hexdigest()
receipt['matches_first_artifact']=receipt['sha256']==json.loads((OUT/'receipt.json').read_text())['output']['sha256']
if receipt['exit_code']==0:
 shutil.copy2(src,OUT/'forced-rebuilt-codescout')
(OUT/'forced-root-build.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2));raise SystemExit(receipt['exit_code'])
