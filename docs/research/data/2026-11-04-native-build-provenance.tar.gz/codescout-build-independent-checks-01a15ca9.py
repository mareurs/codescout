import hashlib,json,pathlib,subprocess
P=pathlib.Path('/home/marius/.cache/codescout-resident/codescout');OUT=P/'native-build-provenance-20261104'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def absent(rc,err):return rc!=0 and 'no such' in err.casefold()
controls=[(1,'error: no such object: x',True),(1,'Error: No such object: x',True),(0,'no such object',False),(1,'Cannot connect to Docker daemon',False)]
for rc,err,expected in controls:assert absent(rc,err)==expected
results=json.loads((OUT/'readiness-results.json').read_text())
assert len(results['outcomes'])==4
checks=[]
for root in sorted(OUT.glob('readiness-*')):
 if not root.is_dir():continue
 launch=json.loads((root/'mcp/launch.json').read_text());name=launch['container_name']
 r=subprocess.run(['docker','inspect','--format','{{.Id}}',name],capture_output=True,text=True)
 assert absent(r.returncode,r.stderr),(name,r.stdout,r.stderr)
 checks.append({'name':name,'exit_code':r.returncode,'stderr':r.stderr,'absent':True})
 for f in ['Cargo.toml','src/lib.rs','src/checksum.rs','.codescout/project.toml']:
  assert sha(root/'project'/f)==sha(P/'native-env-admission-20261104/semantic-minimal-20261104/tiny-project'/f)
assert len(checks)==4
receipt=json.loads((OUT/'receipt.json').read_text());forced=json.loads((OUT/'forced-root-build.json').read_text())
actual=sha(OUT/'codescout');assert actual==forced['sha256']==receipt['output']['sha256']==sha(pathlib.Path('/home/marius/work/claude/codescout/target/release/codescout'))
verdict={'raw_sha256':actual,'packaged_sha256':sha(OUT/'bin/codescout'),'real_store_cells_passed':4,'owned_names_independently_absent':checks,'source_config_instances_compared':16,'absence_predicate_controls_passed':4,'new_provider_model_calls':0,'paid_worker_admitted':False,'controlled_root_rebuild_matches_tested_artifact':True,'independent_dependency_rebuild':False}
(OUT/'qualification.json').write_text(json.dumps(verdict,indent=2)+'\n');print(json.dumps(verdict,indent=2))
