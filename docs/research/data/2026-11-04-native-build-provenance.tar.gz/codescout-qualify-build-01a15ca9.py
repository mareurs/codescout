import hashlib,json,pathlib,shutil,subprocess
P=pathlib.Path('/home/marius/.cache/codescout-resident/codescout')
OUT=P/'native-build-provenance-20261104'
receipt=json.loads((OUT/'receipt.json').read_text())
assert receipt.get('finished') and receipt['inputs_unchanged']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(OUT/'codescout')==receipt['output']['sha256']
(OUT/'bin').mkdir(exist_ok=False)
shutil.copy2(OUT/'codescout',OUT/'bin/codescout')
pack=[str(P/'native-env-admission-20261104/qualification-20261104/patchelf/bin/patchelf'),'--set-interpreter','/bench/runtime/ld-linux-x86-64.so.2','--force-rpath','--set-rpath','/bench/runtime',str(OUT/'bin/codescout')]
subprocess.run(pack,check=True)
source=(P/'native-readiness-recheck-20261104/readiness_controls.py').read_text()
source=source.replace('source_to_binary_build_proven=False','controlled_source_build_receipt_available=True')
(OUT/'readiness_controls.py').write_text(source)
subprocess.run(['python3',str(OUT/'readiness_controls.py')],check=True)
manifest=json.loads((P/'native-env-admission-20261104/semantic-minimal-20261104/source-population.json').read_text())
print('population manifest shape',type(manifest).__name__)
verdict={'raw_sha256':sha(OUT/'codescout'),'packaged_sha256':sha(OUT/'bin/codescout'),'packaging_argv':pack,'real_store_cells_passed':4,'new_provider_model_calls':0,'paid_worker_admitted':False,'shared_release_sha256':sha(pathlib.Path('/home/marius/work/claude/codescout/target/release/codescout'))}
assert verdict['shared_release_sha256']==verdict['raw_sha256']
for root in sorted(OUT.glob('readiness-*')):
    if not root.is_dir():continue
    launch=json.loads((root/'mcp/launch.json').read_text());name=launch['container_name']
    r=subprocess.run(['docker','inspect','--format','{{.Id}}',name],capture_output=True,text=True)
    assert r.returncode!=0 and 'no such' in r.stderr.casefold(),(name,r.stdout,r.stderr)
    old=P/'native-env-admission-20261104/semantic-minimal-20261104/tiny-project'
    for f in ['Cargo.toml','src/lib.rs','src/checksum.rs','.codescout/project.toml']:
        assert sha(root/'project'/f)==sha(old/f),(root,f)
verdict.update(owned_names_independently_absent=4,source_config_instances_compared=16)
(OUT/'qualification.json').write_text(json.dumps(verdict,indent=2)+'\n')
print(json.dumps(verdict,indent=2))
