/// Rotate and combine bytes into a simple checksum.
pub fn rotate_checksum(bytes: &[u8]) -> u64 {
    bytes.iter().fold(0u64, |sum, &byte| sum.rotate_left(5) ^ u64::from(byte))
}
