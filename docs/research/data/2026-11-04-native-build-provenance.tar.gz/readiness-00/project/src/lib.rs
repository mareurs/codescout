use std::collections::BTreeMap;

/// Group log entries by the severity before a colon and count each severity.
pub fn count_entries_by_severity(log: &str) -> BTreeMap<String, usize> {
    let mut counts = BTreeMap::new();
    for line in log.lines() {
        if let Some((severity, _message)) = line.split_once(':') {
            *counts.entry(severity.trim().to_owned()).or_insert(0) += 1;
        }
    }
    counts
}

mod checksum;
