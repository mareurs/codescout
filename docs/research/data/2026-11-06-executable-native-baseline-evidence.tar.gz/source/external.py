"""Prepared external task entry; admission and shared-knowledge assembly stay controller-owned."""
import hashlib
import json
import pathlib
import re
import stat
import uuid
from decimal import Decimal
from types import SimpleNamespace

from qualify import worker
import transport
import workflow
from artifacts import capture_patch
from core import amount


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def validate_prepared(out, effort, allowance, cli_cap):
    out = pathlib.Path(out)
    cfg = json.loads((out / "prepared.json").read_text())
    balance, cap = amount(allowance), amount(cli_cap if cli_cap is not None else allowance)
    if effort not in ("low", "high", "xhigh") or not 0 < cap <= balance:
        raise ValueError("invalid external effort or budget")
    if not re.fullmatch(r"sha256:[0-9a-f]{64}", cfg["image"]):
        raise ValueError("external image must be immutable")
    if not re.fullmatch(r"[0-9a-f]{40}", cfg["baseline_commit"]):
        raise ValueError("external source baseline must be immutable")
    actor = pathlib.Path(cfg["actor"]).resolve()
    if pathlib.Path("/tmp") not in actor.parents:
        raise ValueError("external CLI context must avoid host-home ancestry")
    required = {str(out / "mcp-native-argv.json"), cfg["global_rules"], cfg["cli"],
                str(actor / "CLAUDE.md")}
    if not required <= cfg["files"].keys():
        raise ValueError("external required input hashes missing")
    for name, expected in cfg["files"].items():
        path = pathlib.Path(name)
        if path.is_symlink() or not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError("external input drift: " + name)
    native = json.loads((out / "mcp-native-argv.json").read_text())
    if native[:2] != ["docker", "run"] or native[-4:] != [cfg["image"], "start", "--project", "/testbed"]:
        raise ValueError("unexpected external native boundary")
    options = {}
    valued = {"--pull", "--network", "--user", "--cpus", "--memory", "--memory-swap",
              "--pids-limit", "--name", "--label", "--tmpfs", "--mount", "--workdir",
              "--entrypoint", "-e", "--env"}
    repeated = {"--mount", "-e", "--env"}
    flags = {"--init", "-i"}
    args = native[2:-4]
    index = 0
    while index < len(args):
        raw = args[index]
        option, equals, value = raw.partition("=")
        if option in flags and not equals:
            value = True
        elif option in valued:
            if not equals:
                index += 1
                if index >= len(args) or args[index].startswith("-"):
                    raise ValueError("missing external native option value " + option)
                value = args[index]
            if not value:
                raise ValueError("empty external native option " + option)
        else:
            raise ValueError("unsupported external native option " + raw)
        if option in options and option not in repeated:
            raise ValueError("duplicate external native option " + option)
        options.setdefault(option, []).append(value)
        index += 1
    for option, expected in [("--network", "none"), ("--user", "1000:1000"),
                             ("--cpus", "4"), ("--memory", "32g"), ("--pids-limit", "4096")]:
        if options.get(option) != [expected]:
            raise ValueError("unexpected external native option " + option)
    if options.get("--tmpfs") != ["/tmp:rw,exec,size=4g,uid=1000,gid=1000"]:
        raise ValueError("unexpected external native temporary storage")
    if options.get("--memory-swap", ["32g"]) != ["32g"]:
        raise ValueError("unexpected external native swap limit")
    if options.get("--pull", ["never"]) != ["never"]:
        raise ValueError("external native image pull prohibited")
    if options.get("--init") != [True] or "--name" not in options or "--label" not in options:
        raise ValueError("external native identity/init missing")
    config = workflow.validate_config({"checks": cfg["checks"], "timeout_s": cfg.get("timeout_s", 3600),
        "check_timeout_s": cfg.get("check_timeout_s", 1800), "max_continuations": cfg.get("max_continuations", 8)})
    if not isinstance(cfg["prompt"], str) or not cfg["prompt"].strip():
        raise ValueError("external public prompt missing")
    return cfg, config, actor, balance, cap


def launch(out, *, effort, allowance, cli_cap=None, scripted_plan=None,
           token_path=pathlib.Path("/home/marius/.config/s5/token-claude-stef")):
    out = pathlib.Path(out).resolve()
    cfg, config, actor, balance, cap = validate_prepared(out, effort, allowance, cli_cap)
    scripted = scripted_plan is not None
    with (out / "started.json").open("x") as marker:
        json.dump({"prepared_sha256": hashlib.sha256((out / "prepared.json").read_bytes()).hexdigest(),
                   "scripted": scripted, "effort": effort, "allowance_usd": str(balance)}, marker)
    home = out / "client-home"; client_config = home / ".claude"; client_config.mkdir(parents=True)
    global_md = pathlib.Path(cfg["global_rules"]).read_text()
    project_md = (actor / "CLAUDE.md").read_text()
    (client_config / "CLAUDE.md").write_text(global_md)
    expected = {"effort": effort, "clause": worker.CLAUSE,
        "declaration": worker.CLAUSE in global_md + "\n" + project_md,
        "global_visible": worker.visible(global_md), "project_visible": worker.visible(project_md)}
    save(out / "expected.json", expected)
    save(out / "mcp.json", {"mcpServers": {"codescout": {"command": "/usr/bin/python3",
        "args": ["-B", str(worker.HERE / "stdio.py"), str(out)]}}})
    allowed = ["Skill", "ToolSearch", "mcp__codescout__*"]
    save(out / "settings.json", {"permissions": {"allow": allowed}})
    hook = out / "hook"; hook.mkdir()
    sid = str(uuid.uuid4())
    argv = [cfg["cli"], "-p", "--model", "claude-sonnet-5-5", "--effort", effort, "--session-id", sid,
        "--setting-sources", "user,project,local", "--settings", str(out / "settings.json"),
        "--strict-mcp-config", "--mcp-config", str(out / "mcp.json"), "--permission-mode", "acceptEdits",
        "--tools", "Skill,ToolSearch", "--allowedTools", ",".join(allowed), "--output-format", "json",
        "--max-budget-usd", str(cap), "--plugin-dir", cfg["plugin"], "--", cfg["prompt"]]
    env = {"HOME": str(home), "USER": "marius", "LANG": "C.UTF-8", "PATH": "/usr/local/bin:/usr/bin:/bin",
        "CLAUDE_CONFIG_DIR": str(client_config), "DISABLE_AUTOUPDATER": "1",
        "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC": "1", "CLAUDE_CODE_MAX_OUTPUT_TOKENS": "8192",
        "PYTHONDONTWRITEBYTECODE": "1"}
    if scripted:
        env["ANTHROPIC_API_KEY"] = "scripted-no-real-credential"
    else:
        info = token_path.stat()
        if not stat.S_ISREG(info.st_mode) or info.st_mode & 0o077:
            raise ValueError("credential permissions invalid")
        env["CLAUDE_CODE_OAUTH_TOKEN"] = token_path.read_text().strip()
    server = transport.server(out, expected, scripted, scripted_plan or [], campaign_remaining=balance)
    env["ANTHROPIC_BASE_URL"] = "http://127.0.0.1:" + str(server.server_port)
    save(out / "launch.json", {"argv": argv, "session_id": sid, "scripted": scripted,
        "real_credentials_read": not scripted, "source_image": cfg["image"],
        "hook_set": "Pinned companion skills plus lifecycle observer; no task-specific hint hook"})
    runtime = SimpleNamespace(IMAGE=cfg["image"], save=save,
        extract_result=worker.extract_result, audit_hooks=worker.audit_hooks)
    try:
        receipt = workflow.execute(runtime, config, out, actor, argv, env, server, sid, hook, balance,
            capture_artifacts=lambda: capture_patch(out, cfg["image"], cfg["baseline_commit"]))
    finally:
        server.shutdown(); server.server_close()
    receipt["context_valid"] = bool(server.requests) and not server.errors
    receipt["workflow_completed"] = receipt["workflow_completed"] and receipt["context_valid"]
    save(out / "receipt.json", receipt)
    return receipt
