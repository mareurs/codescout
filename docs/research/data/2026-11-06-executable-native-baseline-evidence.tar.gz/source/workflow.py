"""Opt-in live-session composition for the research worker; no standalone paid entry."""
import json
import pathlib
import posixpath
import shlex
import shutil
import subprocess
import time
from decimal import Decimal
from session import run_session
from verification import PublicVerifier, validate_checks
from qualify import cleanup_owned as cleanup_native, native_record, preserve_background_logs


def prepare_actor(out):
    """Admit supported local disk storage with room for the verified workflow."""
    root=pathlib.Path(out).resolve(strict=True)
    filesystem=subprocess.run(["stat","-f","-c","%T",str(root)],check=True,
        capture_output=True,text=True,timeout=5).stdout.strip()
    if filesystem not in {"ext2/ext3","xfs","btrfs","zfs"}:
        raise ValueError("verified workflow requires supported local disk storage")
    free=shutil.disk_usage(root).free
    minimum=30*1024**3
    if free<minimum:
        raise ValueError("insufficient free space for verified workflow")
    actor=root/"project"
    (root/"runtime-preflight.json").write_text(json.dumps({
        "actor":str(actor),"filesystem":filesystem,"free_bytes":free,
        "minimum_free_bytes":minimum},indent=2)+"\n")
    return actor


def verified_native_argv(argv, *, memory_gib=12):
    """Normalize resources and executable temporary storage for native tests."""
    if type(memory_gib) is not int or not 1<=memory_gib<=64:
        raise ValueError("native memory must be an integer from 1 to 64 GiB")
    if not isinstance(argv,list) or len(argv)<3 or argv[:2]!=["docker","run"]:
        raise ValueError("verified workflow requires docker run argv")
    if any(not isinstance(arg,str) for arg in argv):
        raise ValueError("native argv must contain strings")
    conflicts={"--init","--cpus","--cpu-quota","--cpu-period","--cpuset-cpus"}
    if any(arg.split("=",1)[0] in conflicts for arg in argv[2:]):
        raise ValueError("conflicting native resource flags")
    switches={"-i","--interactive","--read-only","--rm"}
    values={"--pull","--network","--user","--pids-limit","--memory","--tmpfs",
        "--name","--label","-e","--env","--mount","--workdir","--entrypoint"}
    index=2
    replaced=[]
    temporary=[]
    while index<len(argv) and argv[index].startswith("-"):
        start=index
        option,equals,value=argv[index].partition("=")
        if option in switches and not equals:
            index+=1
        elif option in values:
            if equals:
                if not value:
                    raise ValueError("empty native option value")
                index+=1
            else:
                if index+1>=len(argv) or not argv[index+1] or argv[index+1].startswith("-"):
                    raise ValueError("missing native option value")
                value=argv[index+1]
                index+=2
        else:
            raise ValueError("unsupported native Docker option")
        if option=="--memory":
            replaced.append((start,index))
        if option=="--tmpfs":
            destination=value.split(":",1)[0]
            if destination.startswith("/") and posixpath.normpath("/"+destination.lstrip("/"))=="/tmp":
                temporary.append((start,index))
                replaced.append((start,index))
    if len(temporary)>1:
        raise ValueError("duplicate native /tmp temporary mounts")
    if index>=len(argv) or not argv[index].strip():
        raise ValueError("native Docker image is required")
    normalized=list(argv)
    for start,end in reversed(replaced):
        del normalized[start:end]
    return normalized[:2]+["--init","--cpus","4","--memory",str(memory_gib)+"g",
        "--tmpfs","/tmp:rw,exec,size=4g,uid=1000,gid=1000"]+normalized[2:]



def validate_config(config):
    if not isinstance(config,dict):
        raise ValueError("workflow configuration required")
    checks=validate_checks(config.get("checks"))
    timeout=config.get("timeout_s",900)
    check_timeout=config.get("check_timeout_s",timeout)
    if type(timeout) not in (int,float) or not 0<timeout<=3600:
        raise ValueError("workflow deadline out of range")
    if type(check_timeout) not in (int,float) or not 0<check_timeout<=timeout:
        raise ValueError("workflow check deadline out of range")
    turns=config.get("max_continuations",4)
    if type(turns) is not int or not 0<=turns<=8:
        raise ValueError("workflow continuation bound out of range")
    return dict(config,checks=checks,timeout_s=timeout,check_timeout_s=check_timeout,max_continuations=turns)


def native_check(out,image,command,log,timeout_s):
    pinned=out/"record-owner.json"
    pinned_owner=json.loads(pinned.read_text()) if pinned.exists() else None
    names=[pinned_owner["name"]] if pinned_owner else [
        json.loads(p.read_text())["name"] for p in out.glob("mcp-launch-*.json")]
    live=[]
    for name in names:
        res=subprocess.run(["docker","inspect",name],capture_output=True,text=True,timeout=min(5,timeout_s))
        if res.returncode:
            continue
        row=json.loads(res.stdout)[0]
        if row["Image"]!=image or row["Config"]["Labels"].get("codescout.hfa")!=name:
            raise ValueError("public verification worker identity mismatch")
        if row["State"]["Running"]:
            live.append((name,row["Id"]))
    if len(live)!=1:
        raise ValueError("public verification needs one unique live native worker")
    name,container_id=live[0]
    if pinned_owner and pinned_owner.get("container_id",container_id)!=container_id:
        raise ValueError("public verification container identity changed")
    pinned.write_text(json.dumps({"name":name,"container_id":container_id}))
    with (out/"public-worker-identities.jsonl").open("a") as f:
        f.write(json.dumps({"name":name,"container_id":container_id,"image":image,"command":command})+"\n")
    with log.open("wb") as output:
        return subprocess.run(["docker","exec","-w","/testbed",container_id,"/bin/bash","-c",command],
            stdout=output,stderr=subprocess.STDOUT,timeout=timeout_s).returncode


def execute(runtime,config,out,actor,argv,env,server,session_id,hook_state,available,*,capture_artifacts=None):
    config=validate_config(config)
    started=time.monotonic()
    settings=json.loads((out/"settings.json").read_text())
    observer=pathlib.Path(__file__).with_name("observer.py")
    hook="AGENT_LIFECYCLE_OBSERVATIONS="+shlex.quote(str(out/"observations"))+" /usr/bin/python3 -B "+shlex.quote(str(observer))
    settings.setdefault("hooks",{}).setdefault("PostToolUse",[]).append({
        "matcher":"mcp__codescout__run_command","hooks":[{"type":"command","command":hook,"timeout":10}]})
    runtime.save(out/"settings.json",settings)
    prompt=argv[argv.index("--")+1]
    argv=argv[:argv.index("--")]
    argv[argv.index("--output-format")+1]="stream-json"
    argv+=["--input-format","stream-json","--verbose"]
    launch=json.loads((out/"launch.json").read_text())
    launch.update(argv=argv,workflow=True,public_checks=validate_checks(config["checks"]))
    runtime.save(out/"launch.json",launch)
    verifier=PublicVerifier(out,config["checks"],
        lambda command,log,left:native_check(out,runtime.IMAGE,command,log,min(left,config['check_timeout_s'])))

    def check(left):
        if server.budget.pending is not None or server.errors or server.budget_stop:
            raise ValueError("provider state does not permit further verification/continuation")
        return verifier(left)

    terminal_forwarded=None
    def observed_terminal(event):
        nonlocal terminal_forwarded
        terminal_forwarded=server.forwarded

    cleanup_error=None
    artifact_evidence={"required":capture_artifacts is not None,"complete":capture_artifacts is None,"errors":[]}
    background_evidence={"complete":False,"logs":[],"errors":["preservation not reached"]}
    def preserve():
        nonlocal background_evidence, artifact_evidence
        try:
            background_evidence=preserve_background_logs(out,image=runtime.IMAGE)
        except Exception as exc:
            background_evidence={"complete":False,"logs":[],"errors":[type(exc).__name__+": "+str(exc)[:500]]}
            runtime.save(out/"background-evidence.json",background_evidence)
        if capture_artifacts is not None:
            try:
                captured=capture_artifacts()
                if not isinstance(captured,dict) or captured.get("complete") is not True:
                    raise ValueError("required artifact capture did not complete")
                artifact_evidence=dict(captured,required=True)
            except Exception as exc:
                artifact_evidence={"required":True,"complete":False,"errors":[type(exc).__name__+": "+str(exc)[:500]]}
        runtime.save(out/"artifact-evidence.json",artifact_evidence)

    try:
        lifecycle=run_session(argv,cwd=actor,env=env,prompt=prompt,session_id=session_id,
            out=out,read_record=lambda path:native_record(out,path,image=runtime.IMAGE),
            timeout_s=config.get("timeout_s",900),max_continuations=config.get("max_continuations",4),
            completion_check=check,terminal_observer=observed_terminal,before_client_cleanup=preserve)
    finally:
        server.shutdown();server.server_close()
        try:
            cleanup_native(out,image=runtime.IMAGE)
        except Exception as exc:
            cleanup_error=type(exc).__name__+": "+str(exc)
    records=[]
    for line in (out/"stream.jsonl").read_text().splitlines():
        try:
            record=json.loads(line)
        except ValueError:
            continue
        if isinstance(record,dict) and record.get("type")=="result":
            records.append(record)
    runtime.save(out/"turn-results.json",records)
    terminal=None
    try:
        terminal=runtime.extract_result(records[-1:],session_id)
    except ValueError:
        pass
    if records:
        runtime.save(out/"stdout.json",records[-1])
    public=json.loads((out/"public-verification.json").read_text()) if (out/"public-verification.json").exists() else None
    events=[json.loads(l) for l in (hook_state/"events.jsonl").read_text().splitlines()] if (hook_state/"events.jsonl").exists() else []
    unknown=server.budget.pending is not None or terminal is None or terminal_forwarded!=server.forwarded
    within=terminal is not None and terminal["cost"]<=available
    receipt={"session_id":session_id,"scripted":server.scripted,
        "cost_usd":str(terminal["cost"]) if terminal else None,"exit_code":lifecycle["exit_code"],
        "terminal":{k:v for k,v in terminal.items() if k!="cost"} if terminal else None,
        "wall_s":time.monotonic()-started,"requests":len(server.requests),
        "forwarded":server.forwarded,"transport_errors":server.errors,
        "campaign_available_usd":str(available),"budget_stop":server.budget_stop,
        "upper_usage_cost":str(server.budget.spent),"unknown_provider_cost":unknown,
        "cost_coverage":{"forwarded_at_terminal":terminal_forwarded,"forwarded_total":server.forwarded},
        "cli_turn_success":terminal is not None and terminal["is_error"] is False and terminal["subtype"]=="success",
        "lifecycle":lifecycle,"public_verification":public,"cleanup_error":cleanup_error,"background_evidence":background_evidence,"artifact_evidence":artifact_evidence,
        "workflow_completed":lifecycle["status"]=="settled" and public is not None
            and public["status"]=="completed" and public["passed"]
            and within and not unknown and not server.errors and not server.budget_stop and cleanup_error is None and background_evidence["complete"] and artifact_evidence["complete"],
        "hint_then_edit":runtime.audit_hooks(events),"scripted_steps":server.stage,"actor":str(actor)}
    runtime.save(out/"receipt.json",receipt)
    return receipt
