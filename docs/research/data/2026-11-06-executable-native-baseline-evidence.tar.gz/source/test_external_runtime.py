"""Cross-project image identity through the real lifecycle composition."""
import json
import pathlib
import subprocess
import sys
import tempfile
import unittest
from decimal import Decimal
from types import SimpleNamespace
from unittest.mock import patch

import qualify
import workflow


class ExternalImageTests(unittest.TestCase):
    def exercise(self, image):
        with tempfile.TemporaryDirectory() as temp:
            out = pathlib.Path(temp)
            (out / "observations").mkdir()
            (out / "hook").mkdir()
            (out / "settings.json").write_text("{}")
            (out / "launch.json").write_text("{}")
            (out / "mcp-launch-worker.json").write_text(json.dumps({"name": "worker"}))
            path = "/tmp/codescout-bg/7-abcd-bg_00000001.json"
            (out / "observations/job.json").write_text(json.dumps({
                "tool_name": "mcp__codescout__run_command",
                "tool_response": {"output_id": "@bg_00000001", "record": path}}))
            client = out / "client.py"
            client.write_text("import json,sys\nfor line in sys.stdin:\n"
                " print(json.dumps(dict(type='result',subtype='success',is_error=False,"
                "session_id='sid',total_cost_usd=0)),flush=True)\n")
            job = {"schema": 1, "handle": "@bg_00000001", "state": "exited", "exit_code": 0,
                   "log_path": "/tmp/codescout-bg-ABC123.log"}
            calls = []
            removed = False
            def docker(argv, **kwargs):
                nonlocal removed
                calls.append(argv)
                if argv[:2] == ["docker", "inspect"]:
                    if removed:
                        return subprocess.CompletedProcess(argv, 1, "", "No such container")
                    return subprocess.CompletedProcess(argv, 0, json.dumps([{
                        "Id": "immutable-id", "Image": image, "State": {"Running": True},
                        "Config": {"Labels": {"codescout.hfa": "worker"}}}]), "")
                if argv[:4] == ["docker", "exec", "-w", "/testbed"]:
                    return subprocess.CompletedProcess(argv, 0, "", "")
                if argv[:3] == ["docker", "exec", "immutable-id"]:
                    if argv[3] == "cat":
                        return subprocess.CompletedProcess(argv, 0, json.dumps(job), "")
                    if argv[3:5] == ["head", "-c"]:
                        return subprocess.CompletedProcess(argv, 0, b"external build finished\n", b"")
                if argv[:3] == ["docker", "rm", "-f"]:
                    self.assertEqual(argv[3], "immutable-id")
                    removed = True
                    return subprocess.CompletedProcess(argv, 0, "immutable-id", "")
                raise AssertionError("unexpected Docker command: " + repr(argv))
            server = SimpleNamespace(budget=SimpleNamespace(pending=None, spent=Decimal(0)),
                errors=[], budget_stop=None, forwarded=0, requests=[], scripted=True, stage=0,
                shutdown=lambda: None, server_close=lambda: None)
            runtime = SimpleNamespace(IMAGE=image, save=qualify.worker.save,
                extract_result=qualify.worker.extract_result, audit_hooks=qualify.worker.audit_hooks)
            argv = [sys.executable, str(client), "--session-id", "sid", "--output-format",
                    "json", "--", "task"]
            with patch.object(qualify.subprocess, "run", side_effect=docker):
                receipt = workflow.execute(runtime, {"checks": [{"id": "build", "command": "cargo build"}],
                    "timeout_s": 3}, out, out, argv, {}, server, "sid", out / "hook", Decimal(4))
            self.assertTrue(receipt["workflow_completed"], receipt)
            self.assertTrue(receipt["background_evidence"]["complete"])
            log = pathlib.Path(receipt["background_evidence"]["logs"][0]["saved_path"])
            self.assertEqual(log.read_bytes(), b"external build finished\n")
            self.assertTrue(removed)
            self.assertEqual(json.loads((out / "cleanup.json").read_text())[0]["absent"], True)
            self.assertEqual(json.loads((out / "record-owner.json").read_text())["container_id"], "immutable-id")
            self.assertTrue(any(c[:4] == ["docker", "exec", "immutable-id", "cat"] for c in calls))

    def test_two_external_images_complete_without_changing_the_pilot_global(self):
        original = qualify.worker.IMAGE
        for image in ("sha256:external-nushell", "sha256:external-rust-analyzer"):
            with self.subTest(image=image):
                self.exercise(image)
                self.assertEqual(qualify.worker.IMAGE, original)

    def test_image_mismatch_is_rejected_at_every_external_boundary(self):
        with tempfile.TemporaryDirectory() as temp:
            out = pathlib.Path(temp)
            (out / "mcp-launch-worker.json").write_text(json.dumps({"name": "worker"}))
            (out / "record-owner.json").write_text(json.dumps({"name": "worker", "container_id": "immutable-id"}))
            (out / "record-observations.jsonl").write_text(json.dumps({
                "container": "worker", "container_id": "immutable-id",
                "record": {"state": "exited", "log_path": "/tmp/codescout-bg-ABC123.log"}}) + "\n")
            calls = []
            def docker(argv, **kwargs):
                calls.append(argv)
                if argv[:2] == ["docker", "inspect"]:
                    return subprocess.CompletedProcess(argv, 0, json.dumps([{
                        "Id": "immutable-id", "Image": "sha256:wrong",
                        "Config": {"Labels": {"codescout.hfa": "worker"}}}]), "")
                if argv[:4] == ["docker", "exec", "immutable-id", "head"]:
                    return subprocess.CompletedProcess(argv, 0, b"wrong-container build log\n", b"")
                if argv[:4] == ["docker", "exec", "immutable-id", "cat"]:
                    return subprocess.CompletedProcess(argv, 0, json.dumps({
                        "schema": 1, "handle": "@bg_00000001", "state": "exited", "exit_code": 0}), "")
                raise AssertionError("forbidden wrong-image operation: " + repr(argv))
            with patch.object(qualify.subprocess, "run", side_effect=docker):
                try:
                    with self.assertRaisesRegex(ValueError, "identity mismatch"):
                        qualify.native_record(out, "/tmp/codescout-bg/7-abcd-bg_00000001.json", image="sha256:expected")
                    proof = qualify.preserve_background_logs(out, image="sha256:expected")
                    self.assertFalse(proof["complete"])
                    self.assertIn("identity mismatch", proof["errors"][0])
                    with self.assertRaisesRegex(ValueError, "identity mismatch"):
                        qualify.cleanup_owned(out, image="sha256:expected")
                except TypeError as exc:
                    self.fail("external image contract missing: " + str(exc))
            self.assertTrue(calls)
            self.assertFalse(any(c[1] in ("exec", "rm") for c in calls))


class ExternalResourceTests(unittest.TestCase):
    def test_registered_twenty_four_gib_profile_keeps_four_cpu_and_init(self):
        try:
            argv = workflow.verified_native_argv(
                ["docker", "run", "--memory", "6g", "--pids-limit", "4096", "image"],
                memory_gib=24)
        except TypeError as exc:
            self.fail("external resource contract missing: " + str(exc))
        self.assertEqual(argv, ["docker", "run", "--init", "--cpus", "4", "--memory", "24g",
                               "--tmpfs", "/tmp:rw,exec,size=4g,uid=1000,gid=1000",
                               "--pids-limit", "4096", "image"])

    def test_invalid_memory_is_rejected_before_any_launch(self):
        for value in (True, 0, -1, 65, 24.5, "24"):
            with self.subTest(value=value):
                try:
                    with self.assertRaises(ValueError):
                        workflow.verified_native_argv(["docker", "run", "image"], memory_gib=value)
                except TypeError as exc:
                    self.fail("external resource validation missing: " + str(exc))
class TemporaryStorageTests(unittest.TestCase):
    def test_normalizes_inherited_temporary_flags_and_preserves_payload(self):
        inherited_cases = [["--tmpfs", "/tmp:rw,size=1g,uid=1000,gid=1000"], []]
        inherited_cases += [["--tmpfs=" + destination + ":rw,noexec,size=1g"]
                            for destination in ("/tmp", "/tmp/", "/tmp/.", "/other/../tmp", "//tmp")]
        for inherited in inherited_cases:
            with self.subTest(inherited=inherited):
                payload = ["image", "sh", "-c", "echo --tmpfs=/tmp:noexec"]
                argv = workflow.verified_native_argv(
                    ["docker", "run", "--tmpfs", "/scratch:rw,size=1g"] + inherited + payload,
                    memory_gib=32)
                values = []
                for index, item in enumerate(argv[:-len(payload)]):
                    if item == "--tmpfs":
                        values.append(argv[index + 1])
                    elif item.startswith("--tmpfs="):
                        values.append(item.split("=", 1)[1])
                self.assertCountEqual(values, ["/tmp:rw,exec,size=4g,uid=1000,gid=1000",
                                               "/scratch:rw,size=1g"])
                self.assertEqual(argv[-len(payload):], payload)
                self.assertEqual(argv[argv.index("--memory") + 1], "32g")

    def test_duplicate_temporary_mounts_are_rejected(self):
        for first, second in (("/tmp", "/tmp"), ("/tmp", "/tmp/"),
                              ("/tmp/.", "/other/../tmp"), ("//tmp", "/tmp")):
            with self.subTest(first=first, second=second):
                with self.assertRaisesRegex(ValueError, "duplicate.*tmp"):
                    workflow.verified_native_argv(["docker", "run", "--tmpfs", first + ":rw",
                                                  "--tmpfs=" + second + ":rw,exec", "image"])
