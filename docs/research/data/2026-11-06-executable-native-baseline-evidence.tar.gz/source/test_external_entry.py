"""External prepared-task entry validates pinned inputs before credential access."""
import hashlib
import json
import pathlib
import tempfile
import unittest
from unittest.mock import patch
try:
    import external
except ModuleNotFoundError:
    external = None


class ExternalEntryTests(unittest.TestCase):
    def fixture(self, root):
        image = "sha256:" + "a" * 64
        actor = root / "actor"; actor.mkdir()
        (actor / "CLAUDE.md").write_text("PROJECT")
        glob = root / "global.md"; glob.write_text("GLOBAL")
        cli = root / "cli"; cli.write_text("fixture")
        plugin = root / "plugin"; plugin.mkdir()
        native = root / "mcp-native-argv.json"
        native.write_text(json.dumps(["docker", "run", "--init", "--cpus", "4", "--memory", "32g",
            "--tmpfs", "/tmp:rw,exec,size=4g,uid=1000,gid=1000",
            "--pids-limit", "4096", "--network", "none", "--user", "1000:1000",
            "--name", "placeholder", "--label", "codescout.hfa=placeholder",
            image, "start", "--project", "/testbed"]))
        cfg = {"image": image, "baseline_commit": "b" * 40, "actor": str(actor),
            "cli": str(cli), "plugin": str(plugin), "global_rules": str(glob),
            "prompt": "Repair the supplied public task.", "checks": [{"id": "build", "command": "cargo build"}],
            "files": {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                      for p in (native, glob, cli, actor / "CLAUDE.md")}}
        (root / "prepared.json").write_text(json.dumps(cfg))
        return cfg

    def test_drift_and_empty_checks_block_before_credentials_or_start_marker(self):
        self.assertIsNotNone(external, "external entry is not implemented")
        class Forbidden:
            def stat(self):raise AssertionError("credential access")
        for defect in ("drift", "checks"):
            with self.subTest(defect=defect), tempfile.TemporaryDirectory() as temp:
                root = pathlib.Path(temp); cfg = self.fixture(root)
                if defect == "drift":
                    pathlib.Path(cfg["global_rules"]).write_text("CHANGED")
                else:
                    cfg["checks"] = []
                    (root / "prepared.json").write_text(json.dumps(cfg))
                with self.assertRaises(ValueError):
                    external.launch(root, effort="low", allowance="8", token_path=Forbidden())
                self.assertFalse((root / "started.json").exists())

    def test_budget_effort_and_native_boundary_reject_before_credentials(self):
        self.assertIsNotNone(external, "external entry is not implemented")
        for change in ("cap", "effort", "network"):
            with self.subTest(change=change), tempfile.TemporaryDirectory() as temp:
                root = pathlib.Path(temp); cfg = self.fixture(root)
                if change == "network":
                    native = root / "mcp-native-argv.json"
                    native.write_text(native.read_text().replace('"none"', '"host"'))
                    cfg["files"][str(native)] = hashlib.sha256(native.read_bytes()).hexdigest()
                    (root / "prepared.json").write_text(json.dumps(cfg))
                kwargs = {"effort": "medium" if change == "effort" else "low", "allowance": "8"}
                if change == "cap":kwargs["cli_cap"] = "9"
                with self.assertRaises(ValueError):
                    external.launch(root, **kwargs)
                self.assertFalse((root / "started.json").exists())
    def test_conflicting_native_options_reject_before_credentials(self):
        class Forbidden:
            def stat(self):
                raise AssertionError("credential access")
        for option in ("--memory=1g", "--cpus=99", "--network=host", "--user=0:0",
                       "--privileged", "--net=host", "--cpus", "--name=other"):
            with self.subTest(option=option), tempfile.TemporaryDirectory() as temp:
                root = pathlib.Path(temp); cfg = self.fixture(root)
                native = root / "mcp-native-argv.json"
                argv = json.loads(native.read_text())
                argv.insert(-4, option)
                native.write_text(json.dumps(argv))
                cfg["files"][str(native)] = hashlib.sha256(native.read_bytes()).hexdigest()
                (root / "prepared.json").write_text(json.dumps(cfg))
                with self.assertRaises(ValueError):
                    external.launch(root, effort="low", allowance="8", token_path=Forbidden())
                self.assertFalse((root / "started.json").exists())
    def test_external_profile_rejects_legacy_or_nonexecutable_temporary_storage(self):
        for value in (None, "/tmp:rw,size=4g,uid=1000,gid=1000",
                      "/tmp:rw,noexec,size=4g,uid=1000,gid=1000",
                      "/tmp:rw,exec,size=1g,uid=1000,gid=1000",
                      "/tmp:rw,exec,size=4g,uid=0,gid=0"):
            with self.subTest(tmpfs=value), tempfile.TemporaryDirectory() as temp:
                root = pathlib.Path(temp); cfg = self.fixture(root)
                native = root / "mcp-native-argv.json"
                argv = json.loads(native.read_text())
                index = argv.index("--tmpfs")
                if value is None:
                    del argv[index:index + 2]
                else:
                    argv[index + 1] = value
                native.write_text(json.dumps(argv))
                cfg["files"][str(native)] = hashlib.sha256(native.read_bytes()).hexdigest()
                (root / "prepared.json").write_text(json.dumps(cfg))
                with self.assertRaisesRegex(ValueError, "temporary"):
                    external.validate_prepared(root, "low", "8", None)

    def test_new_external_profile_accepts_32_gib_and_rejects_legacy_24_gib(self):
        with tempfile.TemporaryDirectory() as temp:
            root = pathlib.Path(temp); cfg = self.fixture(root)
            external.validate_prepared(root, "low", "8", None)
            native = root / "mcp-native-argv.json"
            argv = json.loads(native.read_text())
            argv[argv.index("--memory") + 1] = "24g"
            native.write_text(json.dumps(argv))
            cfg["files"][str(native)] = hashlib.sha256(native.read_bytes()).hexdigest()
            (root / "prepared.json").write_text(json.dumps(cfg))
            with self.assertRaisesRegex(ValueError, "--memory"):
                external.validate_prepared(root, "low", "8", None)
    def test_external_swap_cap_matches_32_gib_memory(self):
        for option in ([], ["--memory-swap", "32g"], ["--memory-swap=32g"],
                       ["--memory-swap", "24g"], ["--memory-swap=64g"],
                       ["--memory-swap=-1"]):
            with self.subTest(option=option), tempfile.TemporaryDirectory() as temp:
                root = pathlib.Path(temp); cfg = self.fixture(root)
                native = root / "mcp-native-argv.json"
                argv = json.loads(native.read_text())
                argv[-4:-4] = option
                native.write_text(json.dumps(argv))
                cfg["files"][str(native)] = hashlib.sha256(native.read_bytes()).hexdigest()
                (root / "prepared.json").write_text(json.dumps(cfg))
                if option in ([], ["--memory-swap", "32g"], ["--memory-swap=32g"]):
                    external.validate_prepared(root, "low", "8", None)
                else:
                    with self.assertRaisesRegex(ValueError, "swap"):
                        external.validate_prepared(root, "low", "8", None)

    def test_scripted_launch_wires_full_context_budget_and_required_capture(self):
        self.assertIsNotNone(external, "external entry is not implemented")
        with tempfile.TemporaryDirectory() as temp:
            root = pathlib.Path(temp); cfg = self.fixture(root)
            seen = {}
            def execute(runtime, config, out, actor, argv, env, server, sid, hook, available, **kwargs):
                seen.update(argv=argv, env=env, available=str(available), image=runtime.IMAGE,
                            checks=config["checks"], capture=kwargs["capture_artifacts"])
                server.shutdown();server.server_close()
                return {"workflow_completed": True}
            with patch.object(external.workflow, "execute", side_effect=execute), \
                 patch.object(external, "capture_patch", return_value={"complete": True}) as capture:
                result = external.launch(root, effort="low", allowance="8", cli_cap="7", scripted_plan=[])
                seen["capture"]()
                capture.assert_called_once_with(root, cfg["image"], cfg["baseline_commit"])
            self.assertFalse(result["workflow_completed"])  # no actual request can certify context
            self.assertFalse(result["context_valid"])
            argv=seen["argv"]
            self.assertEqual(argv[argv.index("--setting-sources")+1], "user,project,local")
            self.assertEqual(argv[argv.index("--max-budget-usd")+1], "7")
            self.assertNotIn("--max-turns", argv)
            self.assertEqual(seen["available"], "8")
            self.assertEqual(seen["image"], cfg["image"])
            self.assertEqual(seen["checks"], cfg["checks"])
            self.assertNotIn("CLAUDE_CODE_OAUTH_TOKEN", seen["env"])
            self.assertEqual(json.loads((root / "expected.json").read_text())["project_visible"], ["PROJECT"])
            self.assertTrue((root / "started.json").exists())
            with self.assertRaises((ValueError, FileExistsError)):
                external.launch(root, effort="low", allowance="8", scripted_plan=[])
