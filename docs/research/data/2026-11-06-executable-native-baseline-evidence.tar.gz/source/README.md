# Agent lifecycle controller

`session.run_session` keeps a stream-json CLI process and its MCP connections alive after a successful yielded turn. A PostToolUse hook invokes `observer.py` with `AGENT_LIFECYCLE_OBSERVATIONS=<out>/observations`. The controller discovers structured background launch receipts, waits for terminal native records and sends their outcomes into the same session before allowing shutdown.

The caller supplies an argv with `--input-format stream-json --output-format stream-json --verbose`, a session ID matching that argv, an exclusive output directory, and a bounded `read_record(path)` callback scoped to the exact live worker. The caller owns the provider proxy, campaign budget and final worker cleanup. This module has no paid launcher. Costs in CLI result events are cumulative: the receipt keeps the latest total. If `cost_is_final` is false, that total is only the last observed amount; outstanding provider usage must be reconciled by the caller before further spending.

`status=settled` means observed jobs reached terminal states and their outcomes were delivered before a successful subsequent turn. Failed or signalled jobs can settle, while `all_jobs_succeeded` remains false. Neither field proves task correctness, that the agent inspected all output, or that every required public check ran. No-job sessions can settle without any verification having occurred.

The deadline bounds local pipe reads/writes and isolated process-group cleanup. The caller's record reader must also be bounded. The CLI's turn cap remains in force; the controller additionally limits continuation messages. Production integration must preserve one campaign budget across the entire live process.

Run offline tests:

```sh
python3 -B -m unittest discover -s tools/agent_lifecycle -v
```

The environment-specific `qualify.py <fresh-scratch-path>` exercises the pinned CLI 2.1.309 and native Docker Codescout against scripted HTTP responses. It reuses frozen project onboarding and CLAUDE.md inputs. Provider forwarding and worker credential access raise immediately. Controls cover shutdown before completion, a successful job, a failing job, reading the original handle and subsequent tool execution. This verifies transport/context retention, not model recall or repair ability. Each attempt has an exclusive fresh root; previous failed qualifications remain evidence.

## Verified worker composition

`hint_authority_pilot.run.one(..., workflow=config)` opts into the live-session adapter. Default legacy calls retain their historical behavior. `config.checks` is a nonempty list of unique `{id, command}` records; optional `timeout_s`, `check_timeout_s` and `max_continuations` bound the composition. The Rust task's public manifest is `tools/hint_authority_workflow/public-checks.json`; it runs the four commands in the frozen task CLAUDE.md, in order.

After agent jobs settle and their results are delivered, the adapter executes every configured public command in the same native worker. A nonzero exit produces public feedback and a fresh complete verification round after the agent's next turn. Unknown results and timeouts abort. Every round and full command log remain durable. `workflow_completed` requires settled lifecycle, a complete passing final round, reconciled terminal cost, valid transport/campaign state and successful exact-worker cleanup. Worker name and container ID are pinned. Terminal snapshots also record the forwarded-generation count; a later provider request without a covering terminal sets `unknown_provider_cost=true` while preserving the last known amount.

The adapter reuses one proxy and one campaign Budget across all turns. `qualify_workflow.py <fresh-scratch-path>` exercises the actual worker setup, frozen context, hint delivery, native background wake, all-pass checks, fail/repair/full-rerun, and unknown-check timeout at zero provider cost. These use short public probe commands; they are not Rust repair or model-quality results. Before spending, a new campaign must freeze and review the whole composition, manifest and runtime; legacy qualification fingerprints do not cover the new modules/configuration.


Verified mode places each candidate and its build target at `<out>/project`. Before copying source or accessing credentials, it probes the launch filesystem, admits only the supported local disk types (`ext2/ext3`, `xfs`, `btrfs`, `zfs`) and rejects unsupported or failed probes, and requires at least 30 GiB free. `runtime-preflight.json` records the observed filesystem, available bytes and actor path; it does not reserve that disk space. Use a disk-backed launch root outside the repository. Native argv adds `--init --cpus 4` and normalizes `/tmp` to a private executable tmpfs (`rw,exec,size=4g,uid=1000,gid=1000`), retaining the existing image, PID limit and isolation. Internal verified calls keep the 12 GiB memory default; the external entry now requires 32 GiB RAM and the exact temporary policy before credential access. Inherited `/tmp` tmpfs options are replaced, duplicate `/tmp` definitions are rejected, and unrelated tmpfs mounts are preserved. Conflicting resource flags, unsupported Docker options and a missing image are rejected before credential access. Historical frozen manifests must use their archived source; they are not silently upgraded. The init process reaps orphaned descendants, while the CPU quota bounds default test/runtime concurrency. Legacy calls keep their prior actor and native argv behavior.
