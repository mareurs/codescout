"""Exact native-startup metadata allowance; never changes the measured tree."""
import hashlib
import subprocess

def check_source(prefix, expected_head):
    def checked(args):
        p = subprocess.run(prefix + args, capture_output=True)
        if p.returncode:
            raise RuntimeError("source inspection failed: " + repr(args) + ": " + p.stderr.decode(errors="replace"))
        return p.stdout

    git = ["git", "-C", "/testbed"]
    head = checked(git + ["rev-parse", "HEAD"]).decode().strip()
    if head != expected_head:
        raise RuntimeError("baseline HEAD changed")
    if checked(git + ["diff", "--cached", "--name-only", "-z", "HEAD"]):
        raise RuntimeError("staged tracked changes")
    if checked(git + ["diff", "HEAD", "--summary"]):
        raise RuntimeError("tracked mode/type changes")
    names = checked(git + ["diff", "HEAD", "--name-only", "-z"])
    changed = [s.decode() for s in names.split(b"\0") if s]
    allowed = False
    before_hash = after_hash = None
    if changed:
        if changed != [".gitignore"]:
            raise RuntimeError("unexpected tracked paths: " + repr(changed))
        before = checked(git + ["show", "HEAD:.gitignore"])
        after = checked(["cat", "/testbed/.gitignore"])
        if not before.endswith(b"\n") or after != before + b".codescout/private-memories/\n":
            raise RuntimeError("gitignore delta differs from exact native-startup append")
        allowed = True
        before_hash = hashlib.sha256(before).hexdigest()
        after_hash = hashlib.sha256(after).hexdigest()
    return {
        "accepted": True, "head": head, "changed_paths": changed,
        "exact_startup_append": allowed,
        "baseline_gitignore_sha256": before_hash,
        "current_gitignore_sha256": after_hash,
    }
