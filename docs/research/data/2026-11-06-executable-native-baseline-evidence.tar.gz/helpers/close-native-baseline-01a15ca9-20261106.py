import datetime
import hashlib
import io
import json
import pathlib
import subprocess
import tarfile

BASE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
ROOT=BASE/"external-exec-baseline-20261106-v3"
MAIN=pathlib.Path("/home/marius/work/claude/codescout")
V=pathlib.Path("/tmp/codescout-tmp-exec-01a15ca9")
JOB=pathlib.Path("/tmp/codescout-bg/455879-a720241d-bg_000000fd.json")
DEST=MAIN/"docs/research/data/2026-11-06-executable-native-baseline-evidence.tar.gz"
job=json.loads(JOB.read_text())
assert job["command"]=="python3 -B /tmp/qualify-executable-tmp-v3-01a15ca9-20261106.py"
assert job["state"]=="exited" and job["exit_code"]==0,job
result=json.loads((ROOT/"results.json").read_text())
registration=json.loads((ROOT/"registration.json").read_text())
for name,digest in registration["source_hashes"].items():
    assert hashlib.sha256((V/"tools/agent_lifecycle"/name).read_bytes()).hexdigest()==digest,name
for name,digest in registration["helper_hashes"].items():
    assert hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==digest,name
assert [row["id"] for row in result["cases"]]==registration["cases"],"qualification case population mismatch"
cases=[]
for row in result["cases"]:
    effort="low" if row["id"].startswith("nushell") else "xhigh"
    original_cfg=json.loads((BASE/"external-matched-repairs-20261105"/(row["id"]+"--"+effort)/"prepared.json").read_text())
    assert [(c["id"],c["command"]) for c in row["checks"]]==[(c["id"],c["command"]) for c in original_cfg["checks"]],"public command population changed"
    d=ROOT/row["id"]
    pre=json.loads((d/"pre-source-check.json").read_text())
    post=json.loads((d/"post-source-check.json").read_text())
    assert pre==post,(row["id"],pre,post)
    cleanup=json.loads((d/"cleanup.json").read_text())
    p=subprocess.run(["docker","inspect",cleanup["id"]],capture_output=True,text=True,timeout=10)
    absent=p.returncode!=0 and "no such" in p.stderr.lower()
    assert absent and cleanup["absent"] and cleanup["remove_exit_code"]==0
    for check in row["checks"]:
        assert hashlib.sha256(pathlib.Path(check["log"]).read_bytes()).hexdigest()==check["log_sha256"]
    cases.append({"id":row["id"],"passed":row["passed"],"checks":row["checks"],"pre_equals_post_source_guard":True,"independently_absent_at_closure":absent,"container_id":cleanup["id"]})
probes=json.loads((ROOT/"runtime-probes.json").read_text())
assert all(p["exit_code"]==0 and p["container_absent"] for p in probes)
closure={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"provider_calls":0,"job":job,"all_public_passed":result["all_public_passed"],"cases":cases,"source_and_helpers_match_registration":True,"scope":"Exact original public commands/no new skip on unchanged image baselines with32GiBRAM/exec4GiBtmpfs. Qualification of new environment profile, not a model outcome or disk-only mechanism isolation."}
(ROOT/"verified-closure.json").write_text(json.dumps(closure,indent=2)+"\n")
items={}
def add(p,arc):
    assert p.is_file() and not p.is_symlink(),str(p)
    assert arc not in items,arc
    items[arc]=p
for p in sorted(ROOT.iterdir()):
    if p.is_file():add(p,"qualification/"+p.name)
    elif p.is_dir():
        for f in sorted(p.iterdir()):
            if f.is_file():add(f,"qualification/"+p.name+"/"+f.name)
for name in ["workflow.py","external.py","test_external_entry.py","test_external_runtime.py","README.md"]:
    add(V/"tools/agent_lifecycle"/name,"source/"+name)
for name in ["qualify-executable-tmp-v3-01a15ca9-20261106.py","qualification-source-guard-01a15ca9.py","test-qualification-source-guard-01a15ca9.py","close-native-baseline-01a15ca9-20261106.py"]:
    add(pathlib.Path("/tmp")/name,"helpers/"+name)
add(JOB,"job.json")
add(pathlib.Path(job["log_path"]),"job.log")
manifest=[{"name":arc,"source":str(p),"size":p.stat().st_size,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()} for arc,p in sorted(items.items())]
with tarfile.open(DEST,"x:gz",dereference=False) as tf:
    for row in manifest:tf.add(items[row["name"]],arcname=row["name"],recursive=False)
    data=(json.dumps({"scope":closure["scope"],"files":manifest},indent=2)+"\n").encode()
    info=tarfile.TarInfo("MANIFEST.json");info.size=len(data);tf.addfile(info,io.BytesIO(data))
with tarfile.open(DEST,"r:gz") as tf:
    assert set(tf.getnames())=={row["name"] for row in manifest}|{"MANIFEST.json"}
    for row in manifest:
        data=tf.extractfile(row["name"]).read()
        assert len(data)==row["size"] and hashlib.sha256(data).hexdigest()==row["sha256"],row["name"]
out={"archive":str(DEST),"sha256":hashlib.sha256(DEST.read_bytes()).hexdigest(),"bytes":DEST.stat().st_size,"payload_files":len(manifest),"all_reopened_and_hash_verified":True,"all_public_passed":result["all_public_passed"],"cases":cases,"provider_calls":0}
(DEST.with_suffix(DEST.suffix+".receipt.json")).write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps(out,indent=2))
