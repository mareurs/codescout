#!/usr/bin/env python3
"""Zero-provider resource probes and sequential isolated public baseline checks."""
import datetime
import importlib.util
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys
import time

V = pathlib.Path('/tmp/codescout-tmp-exec-01a15ca9')
BASE = pathlib.Path('/home/marius/.cache/codescout-resident/codescout')
OLD = BASE / 'external-matched-repairs-20261105'
ROOT = BASE / 'external-exec-baseline-20261106-v3'
GATE = pathlib.Path('/tmp/codescout-bg/455879-a720241d-bg_000000ed.json')
REPLAY = pathlib.Path('/tmp/codescout-bg/455879-a720241d-bg_000000f7.json')
guard_spec = importlib.util.spec_from_file_location('source_guard', '/tmp/qualification-source-guard-01a15ca9.py')
source_guard = importlib.util.module_from_spec(guard_spec)
guard_spec.loader.exec_module(source_guard)
sys.path.insert(0, str(V / 'tools/agent_lifecycle'))
import workflow

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def run(argv, timeout=30, **kwargs):
    return subprocess.run(argv, capture_output=True, text=True, timeout=timeout, **kwargs)

PROBE = """import os,json,pathlib,shutil,subprocess
s=os.statvfs('/tmp')
r={'mount':[l.strip() for l in open('/proc/self/mountinfo') if l.split()[4]=='/tmp'],'tmp_total_bytes':s.f_blocks*s.f_frsize,'tmp_available_bytes':s.f_bavail*s.f_frsize,'memory_max':pathlib.Path('/sys/fs/cgroup/memory.max').read_text().strip()}
shutil.copyfile('/bin/true','/tmp/executable');os.chmod('/tmp/executable',0o755)
r['executable_exit']=subprocess.run(['/tmp/executable']).returncode
pathlib.Path('/tmp/doc.rs').write_text('/// ```\\n/// assert_eq!(2 + 2, 4);\\n/// ```\\npub fn example() {}\\n')
p=subprocess.run(['rustdoc','--test','/tmp/doc.rs'],capture_output=True,text=True)
r['doctest']={'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
print(json.dumps(r));assert r['executable_exit']==0 and p.returncode==0
assert r['memory_max']==str(32*1024**3) and r['tmp_total_bytes']==4*1024**3
assert all('noexec' not in line.split()[5].split(',') for line in r['mount'])
"""

def probes():
    result=[]
    for ident in ['nushell__nushell-18863', 'rust-lang__rust-analyzer-22992']:
        cfg=json.loads((OLD/(ident+'--'+('low' if ident.startswith('nushell') else 'xhigh'))/'prepared.json').read_text())
        name='cs-exec32-probe-01a15ca9-'+('nu' if ident.startswith('nushell') else 'ra')
        argv=workflow.verified_native_argv(['docker','run','--rm','--name',name,'--network','none','--user','1000:1000','--read-only','--entrypoint','python3',cfg['image'],'-c',PROBE],memory_gib=32)
        p=run(argv,timeout=45)
        absent=run(['docker','inspect',name]).returncode!=0
        row={'id':ident,'argv':argv,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'container_absent':absent}
        result.append(row);save(ROOT/'runtime-probes.json',result)
        assert p.returncode==0 and absent,row
        print(json.dumps({'probe':ident,'exit_code':p.returncode,'absent':absent}),flush=True)

def qualified_baseline(ident, effort):
    original=OLD/(ident+'--'+effort)
    cfg=json.loads((original/'prepared.json').read_text())
    raw=json.loads((original/'mcp-native-argv.json').read_text())
    out=ROOT/ident;out.mkdir()
    native=['docker','run'];i=2
    while i<len(raw)-4:
        token=raw[i]
        if token=='--init':i+=1;continue
        if token in ['--cpus','--name','--label']:
            i+=2;continue
        if token=='--mount':
            value=raw[i+1];parts=value.split(',');fields=dict(p.split('=',1) for p in parts if '=' in p)
            if 'readonly' not in parts:
                src=pathlib.Path(fields['src']);relative=src.relative_to(original)
                dst=out/'state'/relative;dst.parent.mkdir(parents=True,exist_ok=True)
                copied=run(['cp','--archive','--reflink=auto',str(src),str(dst)],timeout=300)
                assert copied.returncode==0,copied.stderr
                value=','.join('src='+str(dst) if p.startswith('src=') else p for p in parts)
            native+=['--mount',value];i+=2;continue
        native.append(token);i+=1
    name='cs-exec32-baseline-v3-01a15ca9-'+('nu' if ident.startswith('nushell') else 'ra')
    native+=['--name',name,'--label','codescout.hfa='+name]+raw[-4:]
    native=workflow.verified_native_argv(native,memory_gib=32)
    launch=native[:2]+['-d']+native[2:]
    save(out/'native-argv.json',native)
    save(out/('mcp-launch-'+name+'.json'),{'name':name,'argv':launch})
    before=run(['docker','run','--rm','--network','none','--entrypoint','git',cfg['image'],'-C','/testbed','rev-parse','HEAD'])
    save(out/'image-baseline.json',{'exit_code':before.returncode,'head':before.stdout.strip(),'expected':cfg['baseline_commit']})
    assert before.returncode==0 and before.stdout.strip()==cfg['baseline_commit']
    launched=run(launch,timeout=45);assert launched.returncode==0,launched.stderr
    cid=launched.stdout.strip()
    rows=[]
    try:
        state=run(['docker','inspect',cid]);d=json.loads(state.stdout)[0]
        assert d['Image']==cfg['image'] and d['Config']['User']=='1000:1000'
        assert d['HostConfig']['Memory']==32*1024**3
        save(out/'container-resource-inspect.json',{'id':cid,'image':d['Image'],'user':d['Config']['User'],'memory':d['HostConfig']['Memory'],'nano_cpus':d['HostConfig']['NanoCpus'],'tmpfs':d['HostConfig']['Tmpfs']})
        pre=source_guard.check_source(['docker','exec',cid],cfg['baseline_commit'])
        save(out/'pre-source-check.json',pre)
        for index,check in enumerate(cfg['checks']):
            log=out/(str(index)+'.log');start=time.monotonic()
            try:
                code=workflow.native_check(out,cfg['image'],check['command'],log,1800)
                error=None
            except subprocess.TimeoutExpired as exc:
                code=None;error=str(exc)
            row={'id':check['id'],'command':check['command'],'exit_code':code,'error':error,'wall_s':time.monotonic()-start,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
            rows.append(row);save(out/'public-results.json',rows)
            print(json.dumps({'baseline':ident,**row}),flush=True)
            if code is None:break
        post=source_guard.check_source(['docker','exec',cid],cfg['baseline_commit'])
        save(out/'post-source-check.json',post)
        state=run(['docker','inspect',cid]);d=json.loads(state.stdout)[0]
        save(out/'terminal-state.json',d['State'])
    finally:
        p=run(['docker','rm','-f',cid],timeout=60)
        absent=run(['docker','inspect',cid]).returncode!=0
        save(out/'cleanup.json',{'id':cid,'remove_exit_code':p.returncode,'absent':absent});assert absent
    return {'id':ident,'checks':rows,'passed':len(rows)==len(cfg['checks']) and all(x['exit_code']==0 for x in rows)}

def main():
    ROOT.mkdir(exist_ok=False)
    helpers = [pathlib.Path(__file__), pathlib.Path('/tmp/qualification-source-guard-01a15ca9.py')]
    save(ROOT/'registration.json',{
        'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'provider_calls':0,
        'memory_gib':32,'tmpfs_gib':4,'tmpfs_exec':True,'cpus':4,
        'cases':['nushell__nushell-18863','rust-lang__rust-analyzer-22992'],
        'checks':'exact previously registered public commands, no new skip',
        'knowledge':'isolated copies; source from original unchanged image; no new onboarding',
        'source_guard':'HEAD exact, no staged/mode/other tracked changes; sole exact startup ignore append accepted',
        'old_cohort_unchanged':True,
        'helper_hashes':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in helpers},
        'source_hashes':{name:hashlib.sha256((V/'tools/agent_lifecycle'/name).read_bytes()).hexdigest() for name in ['workflow.py','external.py']}
    })
    gate=json.loads(GATE.read_text())
    assert gate['state']=='exited' and gate['exit_code']==0,'project gate not green'
    assert (OLD/'repairs-closed.json').exists(),'old repair cohort not closed'
    replay=json.loads(REPLAY.read_text())
    assert replay['state']=='exited' and replay['exit_code']==0,'diagnostic replay must close before heavy qualification'
    replay_root=BASE/'external-grade-audit-20261106'/'nu-low-original-profile-replay'
    replay_summary=json.loads((replay_root/'summary.json').read_text())
    assert replay_summary['result']['independently_absent'],'diagnostic container still exists'
    save(ROOT/'predecessors.json',{'gate':gate,'diagnostic_replay':replay,'replay_summary_sha256':hashlib.sha256((replay_root/'summary.json').read_bytes()).hexdigest()})
    test=run(['python3','-B','/tmp/test-qualification-source-guard-01a15ca9.py'])
    save(ROOT/'source-guard-tests.json',{'exit_code':test.returncode,'stdout':test.stdout,'stderr':test.stderr})
    assert test.returncode==0
    probes()
    results=[]
    for ident,effort in [('nushell__nushell-18863','low'),('rust-lang__rust-analyzer-22992','xhigh')]:
        space=os.statvfs(str(ROOT));assert space.f_bavail*space.f_frsize>=80*1024**3,'insufficient host space for full baseline qualification'
        results.append(qualified_baseline(ident,effort));save(ROOT/'progress.json',results)
    save(ROOT/'results.json',{'provider_calls':0,'cases':results,'all_public_passed':all(x['passed'] for x in results)})

if __name__=='__main__':main()
