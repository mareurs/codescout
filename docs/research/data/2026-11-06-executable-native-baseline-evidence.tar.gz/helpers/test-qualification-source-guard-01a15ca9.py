import importlib.util
import json
import pathlib
import subprocess
import tempfile
import unittest

spec = importlib.util.spec_from_file_location("guard", "/tmp/qualification-source-guard-01a15ca9.py")
guard = importlib.util.module_from_spec(spec)
spec.loader.exec_module(guard)

class SourceGuardTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="cs-guard-")
        self.addCleanup(self.temp.cleanup)
        self.root = pathlib.Path(self.temp.name)
        for argv in [
            ["git", "init", "-q", str(self.root)],
            ["git", "-C", str(self.root), "config", "user.name", "Guard Control"],
            ["git", "-C", str(self.root), "config", "user.email", "guard@invalid"],
        ]:
            subprocess.run(argv, check=True, capture_output=True)
        (self.root / ".gitignore").write_bytes(b"target/\n.splashboard.toml\n")
        (self.root / "source.rs").write_text("fn main() {}\n")
        self.git("add", ".")
        self.git("commit", "-qm", "control")
        self.head = self.git("rev-parse", "HEAD").stdout.decode().strip()
        # Same actual git calls as Docker, redirect only the testbed path.
        self.original_run = guard.subprocess.run
        def redirected(argv, **kwargs):
            argv = [str(self.root) + a[len("/testbed"):] if a == "/testbed" or a.startswith("/testbed/") else a for a in argv]
            return self.original_run(argv, **kwargs)
        guard.subprocess.run = redirected
        self.addCleanup(setattr, guard.subprocess, "run", self.original_run)

    def git(self, *args):
        return subprocess.run(["git", "-C", str(self.root), *args], check=True, capture_output=True)

    def append(self, extra=b".codescout/private-memories/\n"):
        p = self.root / ".gitignore"
        p.write_bytes(p.read_bytes() + extra)

    def test_clean_accepted(self):
        self.assertTrue(guard.check_source([], self.head)["accepted"])

    def test_exact_append_accepted(self):
        self.append()
        self.assertTrue(guard.check_source([], self.head)["accepted"])

    def test_extra_ignore_rejected(self):
        self.append(b".codescout/private-memories/\nsecret-extra/\n")
        with self.assertRaises(RuntimeError):
            guard.check_source([], self.head)

    def test_duplicate_append_rejected(self):
        self.append()
        self.append()
        with self.assertRaises(RuntimeError):
            guard.check_source([], self.head)

    def test_source_edit_rejected_even_with_allowed_ignore(self):
        self.append()
        (self.root / "source.rs").write_text("fn changed() {}\n")
        with self.assertRaises(RuntimeError):
            guard.check_source([], self.head)

    def test_staged_change_rejected(self):
        self.append()
        self.git("add", ".gitignore")
        with self.assertRaises(RuntimeError):
            guard.check_source([], self.head)

    def test_wrong_head_rejected(self):
        with self.assertRaises(RuntimeError):
            guard.check_source([], "0" * 40)

    def test_permission_change_rejected(self):
        self.append()
        (self.root / ".gitignore").chmod(0o755)
        with self.assertRaises(RuntimeError):
            guard.check_source([], self.head)
    def test_prefix_is_used_for_git_and_content_reads(self):
        self.append()
        wrapper = self.root / "forward.py"
        trace = self.root / "calls.jsonl"
        wrapper.write_text(
            "import json,os,sys\n"
            "with open(" + repr(str(trace)) + ", 'a') as f: f.write(json.dumps(sys.argv[1:])+'\\n')\n"
            "os.execvp(sys.argv[1],sys.argv[1:])\n"
        )
        import sys
        self.assertTrue(guard.check_source([sys.executable, str(wrapper)], self.head)["accepted"])
        calls = [json.loads(line) for line in trace.read_text().splitlines()]
        self.assertTrue(any(argv[0] == "git" and "show" in argv for argv in calls))
        self.assertTrue(any(argv[0] == "cat" for argv in calls))

if __name__ == "__main__":
    unittest.main(verbosity=2)
