import contextlib,fcntl,gzip,hashlib,json,os,pathlib,shutil,subprocess,sys,time
B=pathlib.Path('/home/marius/.cache/codescout-resident/codescout')
OUT=B/'disk-cleanup-followup-20261106'
V=pathlib.Path('/home/marius/.codex/worktrees/615e/codescout')
ROOTS=[B/'public-profile-reference-20261105-v2',B/'public-profile-cold-20261105-v1',B/'hint-authority-effort-20261104',V]
TARGETS=[ROOTS[0]/'project/target',ROOTS[1]/'project/target',ROOTS[2]/'launch-v1/grader-target',ROOTS[2]/'launch-budget-requalification-20261104/grader-target',V/'target']
CACHES=[t/'debug'/leaf for t in TARGETS for leaf in ['.fingerprint','deps','build','incremental'] if (t/'debug'/leaf).is_dir()]
APPLY='--apply' in sys.argv

def save(path,d):path.write_text(json.dumps(d,indent=2)+'\n')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def inventory():
 rows={}
 for root in ROOTS:
  for folder,dirs,files in os.walk(root,followlinks=False):
   here=pathlib.Path(folder)
   for name in list(dirs):
    p=here/name
    if p in CACHES:dirs.remove(name);continue
    if p.is_symlink():rows[str(p)]={'link':os.readlink(p)};dirs.remove(name)
   for name in files:
    p=here/name
    if p.is_symlink():rows[str(p)]={'link':os.readlink(p)}
    elif p.is_file():rows[str(p)]={'bytes':p.stat().st_size,'sha256':sha(p)}
 return rows
def references():
 users=[]
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit() or int(p.name)==os.getpid():continue
  try:
   values=[(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace'),(p/'maps').read_text(errors='replace')]
   try:values.append(os.readlink(p/'cwd'))
   except OSError:pass
   for fd in (p/'fd').iterdir():
    try:values.append(os.readlink(fd))
    except OSError:pass
   if any(str(t) in value for t in TARGETS for value in values):users.append({'pid':int(p.name),'command':values[0][:300]})
  except (OSError,UnicodeError):pass
 p=subprocess.run(['docker','ps','-aq','--no-trunc'],capture_output=True,text=True,timeout=20);assert p.returncode==0,p.stderr
 ids=p.stdout.split();containers=[]
 if ids:
  p=subprocess.run(['docker','inspect',*ids],capture_output=True,text=True,timeout=30);assert p.returncode==0,p.stderr
  for d in json.loads(p.stdout):
   for m in d.get('Mounts',[]):
    source=m.get('Source','')
    if source and any(str(t)==source or str(t).startswith(source.rstrip('/')+'/') or source.startswith(str(t)+'/') for t in TARGETS):containers.append({'id':d['Id'],'name':d['Name'],'mount':m})
 return {'processes':users,'containers':containers}
def protections():
 old=B/'external-matched-repairs-20261105';admission=json.loads((old/'repair-admission.json').read_text());reg=json.loads((old/'registration.json').read_text());files=dict(admission['proof_sha256'])
 files.update({str(V/name):digest for name,digest in reg['source_hashes'].items()})
 new=B/'external-exec-baseline-20261106-v2/registration.json'
 for name,digest in json.loads(new.read_text())['source_hashes'].items():files['/tmp/codescout-tmp-exec-01a15ca9/tools/agent_lifecycle/'+name]=digest
 for name,digest in files.items():
  p=pathlib.Path(name)
  assert not any(p==c or c in p.parents for c in CACHES),'protected input inside removal scope'
  assert p.is_file() and sha(p)==digest,('protected input drift before cleanup',name)
 images=['sha256:3767f31b9b1a3288ad7132740dcff712737d5e855029079a4171a8065a2040ef','sha256:0d74e4f14c68a438dce6cf9e4a02c626432ce12b866f55ac69c6cc687f7fff7a','sha256:e317a8e791bfa1f546ab9b58af244ba0844311fef0019306042522d5f68d81b2','sha256:b3df4c943af162ec27e038ed6b80557ae8764e869e43402ea96c477d876066c9']
 for image in images:assert subprocess.run(['docker','image','inspect',image],capture_output=True,timeout=15).returncode==0
 return {'files':files,'images':images}

assert OUT.is_dir()
for t in TARGETS:
 assert not t.is_symlink() and not (t/'debug').is_symlink()
 assert all((t/'debug'/leaf).is_dir() for leaf in ['.fingerprint','deps','build'])
for name in ['public-profile-reference-20261105-v2','public-profile-cold-20261105-v1']:
 d=json.loads((B/name/'result.json').read_text());assert d['public_verification']['status']=='completed' and d['cleanup']['absent']
protected=protections();refs=references();assert not refs['processes'] and not refs['containers'],refs
sizes={str(p):int(subprocess.run(['du','-s','-B1',str(p)],capture_output=True,text=True,check=True).stdout.split()[0]) for p in CACHES}
preview={'cache_directories':sizes,'du_allocated_sum_bytes':sum(sizes.values()),'references':refs,'protected_file_count':len(protected['files']),'protected_image_ids':protected['images'],'preserves':'all source, git metadata, research receipts/logs/costs, top-level binaries, cache tags, models, active roots and active gate caches'}
save(OUT/('apply-preview.json' if APPLY else 'preview.json'),preview);print(json.dumps({k:v for k,v in preview.items() if k!='cache_directories'}),flush=True)
if not APPLY:raise SystemExit(0)
assert not (OUT/'result.json').exists()
with contextlib.ExitStack() as stack:
 for t in TARGETS:
  lock=t/'debug/.cargo-lock'
  if lock.is_file():
   lease=stack.enter_context(lock.open('r+'));fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 before=inventory()
 with gzip.open(OUT/'preserved-records-before.json.gz','wt') as f:json.dump(before,f)
 assert not any(references().values()),'references appeared during manifest'
 space=os.statvfs('/');free_before=space.f_bavail*space.f_frsize
 removed=[]
 for p in CACHES:
  assert p.is_dir() and not p.is_symlink();shutil.rmtree(p);removed.append(str(p));save(OUT/'removal-progress.json',removed)
 after=inventory();delta=[p for p in set(before)|set(after) if before.get(p)!=after.get(p)]
 save(OUT/'preservation-delta.json',delta)
 protected_after=protections();assert protected==protected_after
 assert not delta,('non-target record change',delta[:10])
 assert all(not p.exists() for p in CACHES)
 space=os.statvfs('/');result={**preview,'removed_directory_count':len(removed),'preserved_regular_file_or_link_records':len(before),'preservation_delta_count':len(delta),'all_protected_inputs_and_images_unchanged':True,'root_available_before':free_before,'root_available_after':space.f_bavail*space.f_frsize,'exclusive_physical_reclaimed_bytes':None,'verified':True}
 save(OUT/'result.json',result);print(json.dumps(result),flush=True)
