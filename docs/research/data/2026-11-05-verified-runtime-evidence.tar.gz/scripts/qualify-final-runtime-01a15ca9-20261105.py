#!/usr/bin/env python3
"""Run the established zero-provider four-cell qualification on final runtime bytes."""
import importlib.util
import pathlib
spec = importlib.util.spec_from_file_location("integrated_qualification", "/tmp/qualify-integrated-runtime-01a15ca9-20261105.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.BASE = pathlib.Path("/home/marius/.cache/codescout-resident/codescout/verified-worker-runtime-20261105-final")
module.ROOT = module.BASE/"qualification"
module.BASE.mkdir()
module.main()
