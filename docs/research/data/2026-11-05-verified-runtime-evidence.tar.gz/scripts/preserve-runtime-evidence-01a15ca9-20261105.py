#!/usr/bin/env python3
"""Preserve bounded, hash-verified runtime evidence; exclude actors and homes."""
import gzip, hashlib, io, json, os, pathlib, re, tarfile
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
BASE=ROOT/"verified-worker-runtime-20261105-final"
REVIEW=ROOT/"runtime-profile-review-20261105"
MAIN=pathlib.Path("/home/marius/work/claude/codescout")
DATA=MAIN/"docs/research/data"
def sha(data):return hashlib.sha256(data).hexdigest()
def main():
    record=json.loads(pathlib.Path("/tmp/codescout-bg/455879-a720241d-bg_00000055.json").read_text())
    assert record["state"]=="exited" and record["exit_code"]==0
    gate=pathlib.Path(record["log_path"]).read_bytes()
    review=json.loads((REVIEW/"followup-results.json").read_text())
    assert len(review["mutants"])==review["applied"]==8
    assert sum(r["exit_code"]!=0 for r in review["mutants"])==review["killed"]==5
    assert sum(r["exit_code"]==0 for r in review["mutants"])==review["survived"]==3
    assert all(r["tests"]==42 for r in review["mutants"])
    assert len(review["controls"])==3 and all(r["exit_code"]==0 and r["tests"]==42 for r in review["controls"])
    for path,want in json.loads((REVIEW/"followup-source-hashes.json").read_text()).items():
        assert sha((pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")/path).read_bytes())==want,path
    payload={}
    skip={"project","source","skill-only-plugin","client-home","native-home","__pycache__",".git","private"}
    for label,root in (("final",BASE),("review",REVIEW)):
        for current,dirs,files in os.walk(root,followlinks=False):
            dirs[:]=[d for d in dirs if d not in skip]
            for name in files:
                p=pathlib.Path(current)/name
                if p.is_symlink() or p.suffix in {".pyc",".tar",".gz"}:continue
                payload[label+"/"+str(p.relative_to(root))]=p.read_bytes()
    original=ROOT/"verified-worker-runtime-20261105"
    for name in ("red.log","green.log","suite-before-fixture-update.log","suite.log","pilot-tests.log","completion-tests.log","resume-tests.log","progress.md"):
        payload["implementation/"+name]=(original/name).read_bytes()
    for name in ("qualify-integrated-runtime-01a15ca9-20261105.py","qualify-final-runtime-01a15ca9-20261105.py","readback-runtime-01a15ca9-20261105.py","prepare-runtime-inventory-01a15ca9-20261105.py","preserve-runtime-evidence-01a15ca9-20261105.py"):
        payload["scripts/"+name]=(pathlib.Path("/tmp")/name).read_bytes()
    for name in ("runtime-review-red-01a15ca9.log","runtime-review-green-01a15ca9.log","runtime-final-suite-01a15ca9.log","codescout-bg-OshMpk.log"):
        payload["implementation/"+name]=(pathlib.Path("/tmp")/name).read_bytes()
    payload["gate/job-record.json"]=json.dumps(record,indent=2).encode()
    payload["gate/full.log"]=gate
    manifest={name:{"sha256":sha(content),"bytes":len(content)} for name,content in sorted(payload.items())}
    archive=DATA/"2026-11-05-verified-runtime-evidence.tar.gz"
    with tarfile.open(archive,"w:gz") as tar:
        for name,content in payload.items():
            info=tarfile.TarInfo(name);info.size=len(content);tar.addfile(info,io.BytesIO(content))
        content=(json.dumps(manifest,indent=2)+"\n").encode()
        info=tarfile.TarInfo("manifest.json");info.size=len(content);tar.addfile(info,io.BytesIO(content))
    with tarfile.open(archive,"r:gz") as tar:
        recovered=json.load(tar.extractfile("manifest.json"))
        assert recovered==manifest
        assert set(tar.getnames())==set(manifest)|{"manifest.json"}
        for name,metadata in manifest.items():
            content=tar.extractfile(name).read()
            assert sha(content)==metadata["sha256"] and len(content)==metadata["bytes"]
    verification=json.loads((BASE/"independent-readback.json").read_text())
    inventory=json.loads((BASE/"preparation-inventory.json").read_text())
    verification["archive"]={"path":str(archive.relative_to(MAIN)),"sha256":sha(archive.read_bytes()),"payload_files":len(payload),"all_payload_hashes_verified":True}
    verification["gate"]={"record":record,"raw_log_sha256":sha(gate),"coverage":"V gate's configured five lanes; normal documented exclusions; tools lifecycle suite run separately."}
    verification["review"]={"initial_applied":12,"initial_killed":11,"initial_survived":1,"followup_applied":8,"followup_killed":5,"followup_survived":3,"followup_survivors":"Redundant guards; 3 additional paired green controls establish actual conflicting-option admission is caught."}
    (DATA/"2026-11-05-verified-runtime-verification.json").write_text(json.dumps(verification,indent=2)+"\n")
    (DATA/"2026-11-05-workflow-calibration-runtime-inventory.json").write_text(json.dumps(inventory,indent=2)+"\n")
    with gzip.open(DATA/"2026-11-05-verified-runtime-gate.log.gz","wb") as out:out.write(gate)
    print(json.dumps({"preserved":True,"archive_sha256":verification["archive"]["sha256"],"payload_files":len(payload)}))
if __name__=="__main__":main()
