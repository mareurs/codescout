#!/usr/bin/env python3
"""Preparation only: legacy frozen inputs plus all composed runtime modules/profile."""
import hashlib, json, pathlib, subprocess, sys
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
BASE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/verified-worker-runtime-20261105-final")
sys.path.insert(0,str(V/"tools/hint_authority_pilot"))
import audit
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    audit.L=audit.P/"launch-budget-requalification-20261104"
    source={}
    for name in ("agent_lifecycle","hint_authority_pilot","hint_authority_completion","hint_authority_resume","hint_authority_workflow"):
        for p in sorted((V/"tools"/name).rglob("*")):
            if p.is_file() and (p.suffix in {".py",".json",".md"}):
                source[str(p.relative_to(V))]=digest(p)
    runtime={"legacy_frozen_input_fingerprint":audit.fingerprint(),"composed_files_sha256":source}
    composition=hashlib.sha256(json.dumps(runtime,sort_keys=True).encode()).hexdigest()
    row={"schema":1,"preparation_only":True,"paid_admitted":False,"composition_digest":composition,
        "inventory":runtime,"source_head":subprocess.check_output(["git","rev-parse","HEAD"],cwd=V,text=True).strip(),
        "intended_cells":[["low",False],["xhigh",False]],
        "qualification_readback_sha256":digest(BASE/"independent-readback.json"),
        "original_pilot_spent_usd":"2.57626490000000013","original_pilot_cap_usd":"4",
        "thread_spent_usd":"31.797419199999999964","thread_cap_usd":"40",
        "thread_remaining_usd":"8.202580800000000036","new_provider_cost_usd":"0",
        "missing_before_paid_admission":["Fresh exclusive campaign root, driver and registered allocation",
            "Complete fingerprint including final driver, launch inputs, CLI limits and budget plan",
            "Reviewed preflight with fail-closed pair reserve, persistent complete cost ledger, and old cohorts remaining closed",
            "Final acceptance controls and comparison-specific context/isolation witnesses",
            "No transfer claim from this exposed diagnostic task; fresh external tasks required afterwards"]}
    (BASE/"preparation-inventory.json").write_text(json.dumps(row,indent=2)+"\n")
    print(json.dumps({"preparation_only":True,"paid_admitted":False,"composition_digest":composition,"files_measured":len(source)}))
if __name__=="__main__":main()
