# Verified worker runtime review — original submitted snapshot

Verdict: **With fixes**. No Critical findings. Three Important findings below must be addressed before this composition admits paid work.

Scope: BASE/HEAD 0998c3b64f81c13331db26e0091ff25404272c66 plus the five uncommitted submitted files. Includes untracked tools/agent_lifecycle/test_runtime.py. source-hashes.json records the exact reviewed bytes. Parent reported a subsequent whitespace-only continuation alignment in test_workflow.py; this review's captured tests use the original submitted bytes. No target/index/HEAD/branch changes, subagents, native qualification, real credential access or paid helper calls were made.

## Strengths

- Worker.one consumes storage/resource helpers only in workflow mode, retains exclusive out.mkdir and copies source after storage admission.
- prepare_actor records filesystem, free bytes, threshold and resolved actor path, with equality admitted.
- Resource helper creates a separate argv list and preserves existing launch entries by concatenation.
- Through-worker tests reach actual preparation, Git initialization, native argv persistence and the credential boundary. Existing lifecycle tests also pass in the isolated copy.

## Important findings

1. **Unknown nonempty filesystem output passes the storage guard.** workflow.py:19 only rejects empty output, tmpfs and ramfs. A fixture returning UNKNOWN (0x12345678) with 40 GiB free created the actor/preflight and reached ForbiddenCredential.stat. Unknown type must fail before source copying/credentials; otherwise the non-RAM premise has not been established. Reject unknown/unsupported probe results explicitly and add a through-worker regression using a nonempty unknown marker. Observed original-code evidence: functional-probes.json, label unknown_type.

2. **Malformed Docker run argv can reach credentials.** workflow.py:34-41 checks list shape/prefix and resource collisions, but accepts no-image argv [docker, run, --network, none] and empty-image argv [docker, run, empty-string]. Both persisted invalid native argv and reached ForbiddenCredential.stat in the real worker setup. A production malformed launch can start the provider-capable CLI before its native server inevitably fails. Validate the frozen native launch shape/image or parse supported Docker option/value positions before proceeding; add through-worker no-image/empty-image cases. Evidence: functional-probes.json, labels no_image and empty_image. No actual provider/CLI invocation was used in these probes.

3. **CPU quota conflict guard has no regression coverage.** test_runtime.py:136-142 tests --cpus and --init=false but not each additional independent resource guard. Removing only --cpu-quota from the production conflicts set survived the complete 42-test lifecycle suite. This is an observed test gap on the resource envelope that qualified the full public profile. Expand through-worker conflict inputs to quota/period/cpuset forms, then reapply each independent mutation. Evidence: logs/m08_allow_cpu_quota_conflict.log, results/m08_allow_cpu_quota_conflict.json. This is a guard-coverage finding, not an existing absence of the guard.

## Applied mutation evidence

The baseline suite ran 42 tests and passed. Twelve candidates were applied separately through edit_code in the exclusive private copy, each followed by python3 -B -m unittest discover -s tools/agent_lifecycle -p 'test_*.py', then restored. **11 killed, 1 survived; every mutant run executed 42 tests.** Counts are derived from per-run exit status and the unittest summary, not from test method/grep counts.

| ID | Mutation | Observed outcome |
| --- | --- | --- |
| m01 | Remove --init insertion | Killed |
| m02 | Deliver --cpus 4 | Killed |
| m03 | Bypass verified preparation for legacy /tmp actor | Killed |
| m04 | Admit ramfs | Killed |
| m05 | Reject free-space equality | Killed |
| m06 | Lower reserve to 29 GiB | Killed |
| m07 | Admit empty filesystem probe | Killed |
| m08 | Remove --cpu-quota conflict guard | Survived |
| m09 | Insert resource flags in caller's argv list | Killed |
| m10 | Insert verified flags in legacy argv | Killed |
| m11 | Move legacy actor under output | Killed |
| m12 | Stop normalizing --flag=value conflicts | Killed |

Exact replacements: mutations.json. Full logs: logs/*.log. Observed exit/test counts and mutated source hashes: mutation-results.json and results/*.json. Original snapshots: originals/. workflow.py and run.py were independently hash-compared with originals after restoration; both are byte-identical.

## Declined to judge

- Actual native Docker/init/CPU delivery and actual CLI success/repair/incomplete controls: parent is independently running them, and this review was explicitly prohibited from duplicating qualification.
- Fresh full Rust gate: parent owns the development gate; isolated Python tests do not replace it.
- Low-versus-xhigh model quality, external-population generalization and paid campaign admission: this is runtime infrastructure; supplied reference-control evidence explicitly does not establish those claims.
- Capacity reservation/concurrent future disk exhaustion: specification explicitly defines a preflight observation, not a reservation.
- Arbitrary bind/overlay filesystem backing-device attestation: this change uses the launch filesystem type, not a complete mount-topology proof. Ordinary disk-backed host roots are the qualified deployment path; any broader guarantee would require explicit mount/backing-device policy.

No Critical or Minor findings. Recommended completion: fix the two functional boundaries, close the observed guard-coverage gap, rerun independent mutations against final bytes, and combine with parent's actual qualification/gate evidence before paid admission.
