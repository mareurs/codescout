"""Native Docker boundary tests; replace only the external Docker invocation."""
import json
import pathlib
import subprocess
import tempfile
import unittest
from unittest.mock import patch
import qualify


class OwnerTests(unittest.TestCase):
    def test_probe_connection_is_not_assumed_to_own_the_job(self):
        with tempfile.TemporaryDirectory() as temp:
            out=pathlib.Path(temp)
            for name in ("probe","owner"):
                (out/("mcp-launch-"+name+".json")).write_text(json.dumps({"name":name}))
            path="/tmp/codescout-bg/1-abcd-bg_00000001.json"
            record={"schema":1,"handle":"@bg_00000001","state":"running","exit_code":None}
            def docker(argv,**kwargs):
                name=argv[2]
                if argv[1]=="inspect":
                    return subprocess.CompletedProcess(argv,0,json.dumps([{"Image":qualify.worker.IMAGE,
                        "Config":{"Labels":{"codescout.hfa":name}}}]),"")
                if name=="owner":
                    return subprocess.CompletedProcess(argv,0,json.dumps(record),"")
                return subprocess.CompletedProcess(argv,1,"","not found")
            with patch.object(qualify.subprocess,"run",side_effect=docker):
                self.assertEqual(qualify.native_record(out,path),record)
                self.assertEqual(json.loads((out/"record-owner.json").read_text())["name"],"owner")
                record["state"]="exited";record["exit_code"]=0
                self.assertEqual(qualify.native_record(out,path)["exit_code"],0)
            rows=[json.loads(line) for line in (out/"record-observations.jsonl").read_text().splitlines()]
            self.assertEqual([r["container"] for r in rows],["owner","owner"])
class CleanupTests(unittest.TestCase):
    def test_failed_remove_is_ok_only_when_exact_owned_container_is_absent(self):
        with tempfile.TemporaryDirectory() as temp:
            out=pathlib.Path(temp)
            (out/"mcp-launch-owned.json").write_text(json.dumps({"name":"owned"}))
            for absent in (True,False):
                calls=0
                def docker(argv,**kwargs):
                    nonlocal calls
                    if argv[1]=="rm":
                        return subprocess.CompletedProcess(argv,1,"","already removing")
                    calls+=1
                    if calls>1 and absent:
                        return subprocess.CompletedProcess(argv,1,"","Error: No such object: owned")
                    return subprocess.CompletedProcess(argv,0,json.dumps([{
                        "Id":"exact-id","Image":qualify.worker.IMAGE,"Config":{"Labels":{"codescout.hfa":"owned"}}}]),"")
                with self.subTest(absent=absent),patch.object(qualify.subprocess,"run",side_effect=docker):
                    if absent:
                        self.assertEqual(qualify.cleanup_owned(out,timeout_s=.02),[{"name":"owned","absent":True,"remove_exit_code":1}])
                    else:
                        with self.assertRaisesRegex(ValueError,"container remains"):
                            qualify.cleanup_owned(out,timeout_s=.02)


if __name__=="__main__":unittest.main()
