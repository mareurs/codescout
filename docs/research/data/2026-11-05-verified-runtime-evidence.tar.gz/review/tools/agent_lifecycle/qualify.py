"""Zero-provider actual-client lifecycle controls. No paid entry point."""
import hashlib
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import uuid

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent/"hint_authority_pilot"))
import run as worker
import transport
from session import run_session, background_launches


class NoCredential:
    def __getattr__(self, name):
        raise AssertionError("credential access forbidden in lifecycle qualification")


def no_upstream(*args, **kwargs):
    raise AssertionError("provider forwarding forbidden in lifecycle qualification")


def native_record(out, path):
    if not re.fullmatch(r"/tmp/codescout-bg/[0-9]+-[0-9a-f]+-bg_[0-9a-f]+\.json",path):
        raise ValueError("unexpected native job record path")
    owner_file = out/"record-owner.json"
    pinned = json.loads(owner_file.read_text()) if owner_file.exists() else None
    names = [pinned["name"]] if pinned else [
        json.loads(p.read_text())["name"] for p in out.glob("mcp-launch-*.json")]
    matches = []
    for name in names:
        inspected = subprocess.run(["docker","inspect",name],capture_output=True,text=True,timeout=5)
        if inspected.returncode:
            continue
        identity = json.loads(inspected.stdout)[0]
        if identity["Image"] != worker.IMAGE or identity["Config"]["Labels"].get("codescout.hfa") != name:
            raise ValueError("native job owner identity mismatch")
        result = subprocess.run(["docker","exec",name,"cat",path],text=True,
                                capture_output=True,timeout=5)
        if result.returncode == 0:
            matches.append((name,json.loads(result.stdout)))
    if len(matches) != 1:
        raise ValueError("native job record has no unique live owner")
    name,record = matches[0]
    if not pinned:
        owner_file.write_text(json.dumps({"name":name}))
    with (out/"record-observations.jsonl").open("a") as f:
        f.write(json.dumps({"container":name,"record":record})+"\n")
    return record
def cleanup_owned(out, timeout_s=30):
    import time
    records = []
    for launch in out.glob("mcp-launch-*.json"):
        name = json.loads(launch.read_text())["name"]
        inspected = subprocess.run(["docker","inspect",name],capture_output=True,text=True,timeout=5)
        removed = None
        if inspected.returncode == 0:
            row = json.loads(inspected.stdout)[0]
            if row["Image"] != worker.IMAGE or row["Config"]["Labels"].get("codescout.hfa") != name:
                raise ValueError("container cleanup identity mismatch")
            removed = subprocess.run(["docker","rm","-f",row["Id"]],capture_output=True,text=True,timeout=10)
        deadline = time.monotonic()+timeout_s
        while True:
            result = subprocess.run(["docker","inspect",name],capture_output=True,text=True,timeout=5)
            with (out/"cleanup-observations.jsonl").open("a") as trace:
                trace.write(json.dumps({"name":name,"inspect_exit_code":result.returncode,
                    "stderr":result.stderr,"remaining_s":deadline-time.monotonic()})+"\n")
            absent = result.returncode != 0 and "no such" in result.stderr.lower()
            if absent or time.monotonic()>=deadline:
                break
            time.sleep(min(.05,max(0,deadline-time.monotonic())))
        records.append({"name":name,"absent":absent,"remove_exit_code":removed.returncode if removed else None})
        worker.save(out/"cleanup.json",records)
        if not absent:
            raise ValueError("owned container remains after cleanup")
    return records


def cell(root, frozen, mode):
    out = root/mode; out.mkdir()
    actor = out/"project"
    shutil.copytree(frozen/"source",actor)
    nativehome = out/"native-home"; nativehome.mkdir()
    home = out/"client-home"; config = home/".claude"; config.mkdir(parents=True)
    global_md = (worker.P/"inputs/global-CLAUDE.md").read_text()
    (config/"CLAUDE.md").write_text(global_md)
    expected = {"effort":"low", "declaration":False, "clause":worker.CLAUSE,
                "global_visible":worker.visible(global_md),
                "project_visible":worker.visible((actor/"CLAUDE.md").read_text())}
    worker.save(out/"mcp-native-argv.json",worker.native_argv(actor,nativehome))
    worker.save(out/"mcp.json",{"mcpServers":{"codescout":{"command":"/usr/bin/python3",
        "args":["-B",str(worker.HERE/"stdio.py"),str(out)]}}})
    observations = out/"observations"; observations.mkdir()
    hook = "AGENT_LIFECYCLE_OBSERVATIONS="+str(observations)+" /usr/bin/python3 -B "+str(HERE/"observer.py")
    allowed = ["ToolSearch","mcp__codescout__run_command","mcp__codescout__create_file"]
    worker.save(out/"settings.json",{"permissions":{"allow":allowed},"hooks":{
        "PostToolUse":[{"matcher":"mcp__codescout__run_command","hooks":[{"type":"command","command":hook,"timeout":10}]}]}})
    sid = str(uuid.uuid4())
    marker = "LIFECYCLE_NATIVE_"+uuid.uuid4().hex
    exit_code = 7 if mode=="failed" else 0
    plan = [("mcp__codescout__run_command",{"command":"sleep 8; printf '"+marker+
        "\\n'; touch lifecycle-job-finished.txt; exit "+str(exit_code),"run_in_background":True})]
    original = transport.Proxy.scripted

    def scripted(self, body):
        if self.server.stage==1 and "[harness background completion]" in json.dumps(body):
            launches = []
            for p in observations.glob("*.json"):
                launches.extend(background_launches(json.loads(p.read_text()).get("tool_response")))
            if len(launches)!=1:
                raise ValueError("native launch not captured")
            handle = launches[0][0]
            self.server.plan = plan+[
                ("mcp__codescout__run_command",{"command":"tail -50 "+handle}),
                ("mcp__codescout__create_file",{"path":"lifecycle-agent-continued.txt",
                 "content":"same session retained task nonce "+sid+"\n"})]
        return original(self,body)

    transport.Proxy.scripted = scripted
    worker.TOKEN = NoCredential()
    transport.Proxy.upstream = no_upstream
    s = transport.server(out,expected,True,plan,campaign_remaining=0)
    argv = [str(worker.CLI),"-p","--model","claude-sonnet-5-5","--effort","low",
        "--session-id",sid,"--setting-sources","user,project,local","--settings",str(out/"settings.json"),
        "--strict-mcp-config","--mcp-config",str(out/"mcp.json"),"--permission-mode","acceptEdits",
        "--tools","ToolSearch","--allowedTools",",".join(allowed),"--input-format","stream-json",
        "--output-format","stream-json","--verbose","--max-turns","32","--max-budget-usd","0.65",
        "--plugin-dir",str(frozen/"skill-only-plugin")]
    env = {"HOME":str(home),"USER":"marius","LANG":"C.UTF-8","PATH":"/usr/local/bin:/usr/bin:/bin",
        "CLAUDE_CONFIG_DIR":str(config),"ANTHROPIC_BASE_URL":"http://127.0.0.1:"+str(s.server_port),
        "ANTHROPIC_API_KEY":"scripted-no-real-credential","DISABLE_AUTOUPDATER":"1",
        "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC":"1","CLAUDE_CODE_MAX_OUTPUT_TOKENS":"8192",
        "PYTHONDONTWRITEBYTECODE":"1"}
    worker.save(out/"launch.json",{"argv":argv,"session_id":sid,"real_credentials_read":False})
    try:
        receipt = run_session(argv,cwd=actor,env=env,prompt="Offline lifecycle probe; retain task nonce "+sid+
            ". Follow the scripted tool sequence; do not change source or onboard.",session_id=sid,
            out=out,read_record=lambda path:native_record(out,path),timeout_s=120,
            max_continuations=0 if mode=="negative" else 2)
    finally:
        s.shutdown();s.server_close();transport.Proxy.scripted = original
        cleanup_owned(out)
    launches = list(out.glob("mcp-launch-*.json"))
    results = [json.loads(p.read_text()) for p in out.glob("request-*.json")]
    tool_results = [b for request in results for msg in request.get("messages",[])
                    if msg.get("role")=="user" for b in msg.get("content",[])
                    if isinstance(b,dict) and b.get("type")=="tool_result"]
    original_handle_read = any(marker in json.dumps(b.get("content")) for b in tool_results)
    summary = {"mode":mode,"lifecycle":receipt,"forwarded":s.forwarded,"transport_errors":s.errors,
        "native_connections":len(launches),"native_original_handle_read":original_handle_read,
        "job_owner":json.loads((out/"record-owner.json").read_text()) if (out/"record-owner.json").exists() else None,
        "job_marker_exists":(actor/"lifecycle-job-finished.txt").exists(),
        "agent_continuation_marker_exists":(actor/"lifecycle-agent-continued.txt").exists(),
        "cleanup":json.loads((out/"cleanup.json").read_text())}
    worker.save(out/"summary.json",summary)
    if s.forwarded or s.errors or not launches or not all(r["absent"] for r in summary["cleanup"]):
        raise ValueError("transport or cleanup qualification failed")
    if mode=="negative":
        if receipt["status"]!="incomplete" or summary["job_marker_exists"] or summary["agent_continuation_marker_exists"]:
            raise ValueError("negative lifecycle control failed")
    elif receipt["status"]!="settled" or receipt["continuations"]!=1 or not original_handle_read or not summary["job_marker_exists"] or not summary["agent_continuation_marker_exists"] or receipt["all_jobs_succeeded"]!=(exit_code==0):
        raise ValueError("positive lifecycle control failed")
    return summary


def main():
    root = pathlib.Path(sys.argv[1]).resolve();root.mkdir()
    frozen = worker.P/"launch-budget-requalification-20261104"
    worker.save(root/"inputs.json",{"frozen":str(frozen),"provider_forwarding":"forbidden",
        "source_hashes":{p.name:hashlib.sha256(p.read_bytes()).hexdigest()
          for p in [HERE/"session.py",HERE/"observer.py",HERE/"qualify.py"]}})
    summaries = []
    for mode in ("negative","success","failed"):
        summaries.append(cell(root,frozen,mode))
        worker.save(root/"results.json",summaries)
    print(json.dumps({"qualified":True,"cells":len(summaries),"cost_usd":"0","root":str(root)}))


if __name__=="__main__":
    main()
