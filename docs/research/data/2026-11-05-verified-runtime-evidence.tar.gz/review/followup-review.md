# Focused final-runtime verification

Verdict: **The three original review findings are resolved in the captured final runtime.** No remaining blocker from this focused verification. Parent still owns final-byte native qualification and the full development gate; this result does not substitute for those.

Final workflow.py SHA256: 8ed3e89ca1f14ccda8294e509b2c9bd51ac4dfed188f395f1573391e807be48a.
Final test_runtime.py SHA256: bb761f378770c924a915a8db66650b713c9811d1ec348968804d2f8afc55bab5.
All five captured file hashes: followup-source-hashes.json. Exact captured bytes: followup-originals/.

## Observations

Final lifecycle baseline and post-restoration suite each passed 42 tests. All followup mutation/control suites also executed 42 tests each.

- Restoring the original unknown-filesystem predicate was killed: 2 failing subtests (GNU UNKNOWN marker and unqualified nonempty type).
- Restoring the original argv helper without supported-option/image validation was killed: 5 failing malformed-input subtests, including no image and empty image.
- Final functional probes all reject before ForbiddenCredential.stat. Unknown storage rejects before actor/preflight creation; malformed argv rejects before native argv persistence and credentials. See followup-functional-probes.json.
- Quota/period/cpuset conflict-set removals each survived. These are redundant-guard survivors on the tested pre-image option paths: the supported-option parser independently rejects those options.
- For each of those three flags, admitting just that flag to the parser's values set while retaining its conflict guard passed all 42 tests. Removing its conflict guard from that same control then failed both split and equals-form subtests. This observed green-control/red-mutation pair confirms the new tests detect actual admission of each conflicting flag.

## Counts and artifacts

**8 applied followup mutation variants: 5 killed, 3 survived.** The 5 killed include the 3 conditional, paired conflict mutations. **3 additional parser-relaxed control runs passed.** Do not describe this as 8 independent first-order mutants or zero survivors.

One initial f05 edit was refused by the tool's shrink guard, so its unchanged-source run is explicitly marked mutation_applied=false and excluded from counts. The intentional replacement was then applied with force=true as f05b, observed failing, and restored.

Exact mutant bodies: followup-mutations.json and followup-paired-mutations.json. Per-run hashes, full logs, test counts and exit status: results/f*.json and logs/f*.log. Aggregated counts, controls and final restoration hashes: followup-results.json.

Both private restored files and the current V files were hash-compared against the captured final snapshot. All five files match. No V source/index/HEAD/branch write, native run, paid helper or real credential access occurred.

Evidence housekeeping: functional-probes.json was reproduced on the original workflow snapshot during followup; its temporary actor paths therefore belong to that fresh original-code reproduction. followup-functional-probes.json contains the final fixed-code probe results. Original mutation-results.json and m*.logs remain unchanged.

## Declined to judge

- Actual final-byte Docker/CLI qualification and full repository gate: assigned to parent, not duplicated.
- Broader parser redesign, additional option populations or a second broad review: explicitly outside this finite followup.
- Model-quality equivalence or paid admission: runtime regression verification establishes neither.
