"""Compose the actual worker/proxy with a local stream client, no paid provider."""
import io
import json
import pathlib
import subprocess
import sys
import tempfile
import unittest
from decimal import Decimal
from unittest.mock import patch

sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/"hint_authority_pilot"))
import run as worker
import transport

FIXTURE=r'''#!/usr/bin/python3
import http.client,json,os,sys
sid=sys.argv[sys.argv.index("--session-id")+1]
for line in sys.stdin:
    msg=json.loads(line)
    conn=http.client.HTTPConnection(os.environ["ANTHROPIC_BASE_URL"].removeprefix("http://"))
    body={"model":"claude-sonnet-5-5","output_config":{"effort":"low"},"messages":[{"role":"user","content":"GLOBAL\nPROJECT"}],
      "max_tokens":8192,"stream":True}
    conn.request("POST","/v1/messages",json.dumps(body),{"Content-Type":"application/json"})
    res=conn.getresponse();res.read();conn.close()
    ok=res.status==200
    print(json.dumps({"type":"result","subtype":"success" if ok else "error_max_budget_usd","is_error":not ok,
      "session_id":sid,"total_cost_usd":.08,"result":"candidate"}),flush=True)
'''

class Reply(io.BytesIO):
    status=200
    def getheader(self,*args):return "text/event-stream"

class Connection:
    def close(self):pass

class WorkflowTests(unittest.TestCase):
    def exercise_worker(self, *, balance=".4", check_code=0, cleanup_fails=False,
                        program=FIXTURE, unknown_usage=False, transport_error=False):
        import workflow
        with tempfile.TemporaryDirectory() as temp:
            root=pathlib.Path(temp);(root/"source").mkdir();(root/"inputs").mkdir()
            (root/"source/CLAUDE.md").write_text("PROJECT")
            (root/"inputs/global-CLAUDE.md").write_text("GLOBAL")
            cli=root/"client";cli.write_text(program);cli.chmod(0o700)
            token=root/"dummy-token";token.write_text("LOCAL-NONCREDENTIAL");token.chmod(0o600)
            calls=[];budget_ids=[]
            def provider(proxy,path,body):
                calls.append(path);budget_ids.append(id(proxy.server.budget))
                if "count_tokens" in path:
                    return Connection(),Reply(b'{"input_tokens":1000}')
                if transport_error:
                    proxy.server.errors.append("fixture: observed transport error")
                count=20000 if unknown_usage else 7000
                raw=('data: {"type":"message_start","message":{"usage":{"input_tokens":10,"output_tokens":0}}}\n\n'
                    +'data: '+json.dumps({"type":"message_delta","usage":{"output_tokens":count}})+'\n\n'
                    +'data: {"type":"message_stop"}\n\n').encode()
                return Connection(),Reply(raw)
            def check(out,image,command,log,timeout_s):
                log.write_text("public output")
                return check_code
            def cleanup(out):
                if cleanup_fails:
                    raise ValueError("fixture: owned container remains")
                return []
            with patch.multiple(worker,L=root,P=root,CLI=cli,TOKEN=token),\
                 patch.object(worker,"native_argv",return_value=["docker","run","fixture-image"]),\
         patch.object(workflow,"prepare_actor",return_value=root/"attempt/project"),\
                 patch.object(worker,"plugin_copy",return_value=root/"plugin"),\
                 patch.object(transport.Proxy,"upstream",provider),\
                 patch.object(workflow,"native_check",side_effect=check),\
                 patch.object(workflow,"cleanup_native",side_effect=cleanup):
                result=worker.one("attempt","low",False,False,campaign_remaining=Decimal(balance),
                    workflow={"checks":[{"id":"compile","command":"public-check"}],"timeout_s":10})
            self.assertEqual(json.loads((root/"attempt/receipt.json").read_text()),result)
            return result,calls,budget_ids

    def test_invalid_manifest_blocks_before_any_credential_access(self):
        class Forbidden:
            def __getattr__(self,name):raise AssertionError("real credential access")
        with tempfile.TemporaryDirectory() as temp:
            root=pathlib.Path(temp);(root/"source").mkdir();(root/"inputs").mkdir()
            (root/"source/CLAUDE.md").write_text("PROJECT")
            (root/"inputs/global-CLAUDE.md").write_text("GLOBAL")
            with patch.multiple(worker,L=root,P=root,TOKEN=Forbidden()),patch.object(worker,"native_argv",return_value=[]):
                with self.assertRaisesRegex(ValueError,"manifest"):
                    worker.one("unused","low",False,False,campaign_remaining=Decimal(".15"),workflow={"checks":[]})

    def test_continuation_uses_same_real_proxy_budget_and_keeps_known_stop_cost(self):
        import workflow
        with tempfile.TemporaryDirectory() as temp:
            root=pathlib.Path(temp);(root/"source").mkdir();(root/"inputs").mkdir()
            (root/"source/CLAUDE.md").write_text("PROJECT")
            (root/"inputs/global-CLAUDE.md").write_text("GLOBAL")
            cli=root/"client";cli.write_text(FIXTURE);cli.chmod(0o700)
            token=root/"dummy-token";token.write_text("LOCAL-NONCREDENTIAL");token.chmod(0o600)
            calls=[];server_ids=[]
            def provider(proxy,path,body):
                calls.append(path);server_ids.append(id(proxy.server.budget))
                if "count_tokens" in path:return Connection(),Reply(b'{"input_tokens":1000}')
                return Connection(),Reply(
                    b'data: {"type":"message_start","message":{"usage":{"input_tokens":10,"output_tokens":0}}}\n\n'
                    b'data: {"type":"message_delta","usage":{"output_tokens":7000}}\n\n'
                    b'data: {"type":"message_stop"}\n\n')
            def check(out,image,command,log,timeout_s):
                log.write_text("compile failed")
                return 1
            with patch.multiple(worker,L=root,P=root,CLI=cli,TOKEN=token),\
                 patch.object(worker,"native_argv",return_value=["docker","run","fixture-image"]),\
         patch.object(workflow,"prepare_actor",return_value=root/"attempt/project"),\
                 patch.object(worker,"plugin_copy",return_value=root/"plugin"),\
                 patch.object(transport.Proxy,"upstream",provider),\
                 patch.object(workflow,"native_check",side_effect=check),\
                 patch.object(workflow,"cleanup_native",return_value=[]):
                result=worker.one("attempt","low",False,False,campaign_remaining=Decimal(".15"),
                    workflow={"checks":[{"id":"compile","command":"public-check"}],"timeout_s":10})
            self.assertFalse(result["workflow_completed"])
            self.assertIsNotNone(result["budget_stop"])
            self.assertEqual(result["cost_usd"],"0.08")
            self.assertFalse(result["unknown_provider_cost"])
            self.assertEqual(result["forwarded"],1)
            self.assertEqual(len(set(server_ids)),1)
            self.assertEqual(calls.count("/v1/messages"),1) # second generation denied before forwarding
            self.assertEqual(result["lifecycle"]["continuations"],1)
            self.assertFalse(result["public_verification"]["passed"])
            self.assertEqual(json.loads((root/"attempt/receipt.json").read_text()),result)
class WorkflowFailureTests(unittest.TestCase):
    exercise_worker=WorkflowTests.exercise_worker

    def test_cli_dies_after_second_billed_request_marks_cost_unknown(self):
        program=FIXTURE.replace("for line in sys.stdin:","turn=0\nfor line in sys.stdin:\n    turn+=1")
        program=program.replace("    ok=res.status==200","    if turn==2:sys.exit(0)\n    ok=res.status==200")
        result,_,_=self.exercise_worker(program=program,check_code=1)
        self.assertEqual(result["forwarded"],2)
        self.assertEqual(result["cost_usd"],"0.08")  # last known cumulative amount, not final bill
        self.assertTrue(result["unknown_provider_cost"])
        self.assertFalse(result["workflow_completed"])

    def test_cleanup_failure_keeps_cost_and_prevents_workflow_success(self):
        result,_,_=self.exercise_worker(cleanup_fails=True)
        self.assertEqual(result["cost_usd"],"0.08")
        self.assertFalse(result["unknown_provider_cost"])
        self.assertIn("owned container remains",result["cleanup_error"])
        self.assertFalse(result["workflow_completed"])

    def test_unreconciled_provider_usage_prevents_validation_and_is_unknown(self):
        result,_,_=self.exercise_worker(unknown_usage=True)
        self.assertTrue(result["unknown_provider_cost"])
        self.assertIsNone(result["public_verification"])
        self.assertFalse(result["workflow_completed"])

    def test_known_transport_failure_does_not_execute_validator(self):
        result,_,_=self.exercise_worker(transport_error=True)
        self.assertIsNone(result["public_verification"])
        self.assertFalse(result["workflow_completed"])

    def test_terminal_cost_above_campaign_balance_cannot_complete(self):
        program=FIXTURE.replace('"total_cost_usd":.08','"total_cost_usd":.2')
        result,_,_=self.exercise_worker(balance=".15",program=program)
        self.assertEqual(result["cost_usd"],"0.2")
        self.assertFalse(result["workflow_completed"])


class NativeIdentityTests(unittest.TestCase):
    def native_fixture(self,out,ids,*,image="expected",label=None,names=("owned",)):
        import workflow
        for name in names:
            (out/("mcp-launch-"+name+".json")).write_text(json.dumps({"name":name}))
        def docker(argv,**kwargs):
            if argv[1]=="inspect":
                name=argv[2]
                row={"Id":ids[0],"Image":image,"State":{"Running":True},
                     "Config":{"Labels":{"codescout.hfa":label if label is not None else name}}}
                return subprocess.CompletedProcess(argv,0,json.dumps([row]),"")
            kwargs["stdout"].write(b"PUBLIC_OK")
            return subprocess.CompletedProcess(argv,0)
        return patch.object(workflow.subprocess,"run",side_effect=docker)

    def test_replaced_container_id_is_rejected_between_checks(self):
        import workflow
        with tempfile.TemporaryDirectory() as temp:
            root=pathlib.Path(temp);ids=["container-A"]
            with self.native_fixture(root,ids):
                self.assertEqual(workflow.native_check(root,"expected","first",root/"a.log",10),0)
                ids[0]="container-B"
                with self.assertRaisesRegex(ValueError,"identity"):
                    workflow.native_check(root,"expected","second",root/"b.log",10)

    def test_image_label_mismatch_and_ambiguous_workers_are_rejected(self):
        import workflow
        for kwargs in ({"image":"foreign"},{"label":"foreign"},{"names":("one","two")}):
            with self.subTest(kwargs=kwargs),tempfile.TemporaryDirectory() as temp:
                root=pathlib.Path(temp)
                with self.native_fixture(root,["container"],**kwargs),self.assertRaises(ValueError):
                    workflow.native_check(root,"expected","check",root/"log",10)

if __name__=="__main__":unittest.main()
