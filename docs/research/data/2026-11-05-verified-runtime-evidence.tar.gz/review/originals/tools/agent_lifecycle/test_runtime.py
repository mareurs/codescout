"""Verified runtime boundaries exercised through the real worker setup."""
import json
import pathlib
import shutil
import subprocess
import sys
import tempfile
import unittest
import uuid
from decimal import Decimal
from types import SimpleNamespace
from unittest.mock import patch

sys.path[:0] = [str(pathlib.Path(__file__).resolve().parent),
               str(pathlib.Path(__file__).resolve().parents[1]/"hint_authority_pilot")]
import run as worker
import workflow

GIB = 1024**3
BASE = ["docker", "run", "-i", "--pids-limit", "512", "--network", "none",
        "fixture-image", "start", "--project", "/testbed"]


class RuntimeTests(unittest.TestCase):
    def exercise(self, *, filesystem="ext2/ext3", free=40*GIB, trap_credentials=False,
                 stat_error=False, legacy=False, native=None):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root = pathlib.Path(temporary.name)
        (root/"source").mkdir()
        (root/"inputs").mkdir()
        (root/"source/CLAUDE.md").write_text("PROJECT")
        (root/"inputs/global-CLAUDE.md").write_text("GLOBAL")
        cli = root/"client"
        cli.write_text("#!/usr/bin/python3\nimport json,sys\nsid=sys.argv[sys.argv.index('--session-id')+1]\n"
                       "print(json.dumps(dict(type='result',subtype='success',is_error=False,session_id=sid,total_cost_usd=0)))\n")
        cli.chmod(0o700)
        token = root/"dummy-token"
        token.write_text("LOCAL-NONCREDENTIAL")
        token.chmod(0o600)
        touches = []

        class ForbiddenCredential:
            def stat(self):
                touches.append("stat")
                raise AssertionError("credential boundary crossed")

        server = SimpleNamespace(server_port=1, shutdown=lambda: None, server_close=lambda: None,
            requests=[], errors=[], forwarded=0, scripted=False, stage=0, budget_stop=None,
            budget=SimpleNamespace(spent=Decimal(0), pending=None))
        original_run = subprocess.run
        def filesystem_probe(argv, *args, **kwargs):
            if list(argv[:4]) == ["stat", "-f", "-c", "%T"]:
                if stat_error:
                    raise subprocess.CalledProcessError(1, argv, stderr="fixture stat refused")
                return subprocess.CompletedProcess(argv, 0, filesystem+"\n", "")
            return original_run(argv, *args, **kwargs)

        native_input = list(BASE if native is None else native)
        def execute(runtime, config, out, actor, *args):
            return {"actor": str(actor)}
        identity = uuid.uuid4()
        legacy_parent = pathlib.Path("/tmp")/("hfa-"+identity.hex)
        self.assertFalse(legacy_parent.exists())
        self.addCleanup(shutil.rmtree, legacy_parent, ignore_errors=True)
        error = None
        result = None
        with patch.multiple(worker, L=root, P=root, CLI=cli,
                            TOKEN=ForbiddenCredential() if trap_credentials else token), \
             patch.object(worker.uuid, "uuid4", return_value=identity), \
             patch.object(worker, "native_argv", return_value=native_input), \
             patch.object(worker, "plugin_copy", return_value=root/"plugin"), \
             patch.object(worker, "server", return_value=server), \
             patch.object(worker, "cleanup", return_value=[]), \
             patch.object(workflow, "execute", side_effect=execute), \
             patch.object(subprocess, "run", side_effect=filesystem_probe), \
             patch.object(shutil, "disk_usage", return_value=shutil._ntuple_diskusage(200*GIB, 200*GIB-free, free)):
            try:
                result = worker.one("attempt", "low", False, False, campaign_remaining=Decimal(1),
                    workflow=None if legacy else {"checks":[{"id":"compile","command":"public-check"}]})
            except Exception as exc:
                error = exc
        out = root/"attempt"
        preflight = out/"runtime-preflight.json"
        argv_path = out/"mcp-native-argv.json"
        return dict(result=result, error=error, touches=touches, out=out, native_input=native_input,
            native=json.loads(argv_path.read_text()) if argv_path.exists() else None,
            preflight=json.loads(preflight.read_text()) if preflight.exists() else None)

    def test_verified_candidate_is_inside_its_exclusive_output(self):
        case = self.exercise()
        self.assertIsNone(case["error"])
        actor = pathlib.Path(case["result"]["actor"])
        self.assertEqual(actor, case["out"].resolve()/"project")
        self.assertTrue((actor/".git/HEAD").is_file())

    def test_native_consumer_gets_cpu_quota_and_init_without_mutating_legacy_argv(self):
        case = self.exercise()
        self.assertIsNone(case["error"])
        argv = case["native"]
        self.assertIn("--init", argv)
        self.assertEqual(argv[argv.index("--cpus")+1], "2")
        self.assertEqual(argv[argv.index("--pids-limit")+1], "512")
        self.assertEqual(case["native_input"], BASE)

    def test_ram_filesystems_reject_before_credentials(self):
        for kind in ("tmpfs", "ramfs"):
            with self.subTest(kind=kind):
                case = self.exercise(filesystem=kind, free=100*GIB, trap_credentials=True)
                self.assertEqual(case["touches"], [])
                self.assertIsInstance(case["error"], ValueError)
                self.assertFalse((case["out"]/"project").exists())

    def test_one_byte_below_reserve_rejects_before_credentials(self):
        case = self.exercise(free=30*GIB-1, trap_credentials=True)
        self.assertEqual(case["touches"], [])
        self.assertIsInstance(case["error"], ValueError)
        self.assertFalse((case["out"]/"project").exists())

    def test_exact_reserve_is_admitted_and_capacity_witness_is_saved(self):
        case = self.exercise(free=30*GIB)
        self.assertIsNone(case["error"])
        self.assertIsNotNone(case["preflight"])
        self.assertEqual(case["preflight"]["free_bytes"], 30*GIB)
        self.assertEqual(case["preflight"]["minimum_free_bytes"], 30*GIB)
        self.assertEqual(case["preflight"]["filesystem"], "ext2/ext3")
        self.assertEqual(case["preflight"]["actor"], case["result"]["actor"])

    def test_unknown_or_failed_filesystem_probe_rejects_before_credentials(self):
        for options in ({"filesystem":""}, {"stat_error":True}):
            with self.subTest(options=options):
                case = self.exercise(trap_credentials=True, **options)
                self.assertEqual(case["touches"], [])
                self.assertIsNotNone(case["error"])

    def test_conflicting_or_malformed_native_argv_rejects_before_credentials(self):
        for argv in (["native"], ["docker","run","--cpus","4"]+BASE[2:],
                     ["docker","run","--init=false"]+BASE[2:]):
            with self.subTest(argv=argv):
                case = self.exercise(native=argv, trap_credentials=True)
                self.assertEqual(case["touches"], [])
                self.assertIsInstance(case["error"], ValueError)

    def test_legacy_ignores_verified_storage_and_resource_policy(self):
        case = self.exercise(legacy=True, filesystem="tmpfs", free=0)
        self.assertIsNone(case["error"])
        self.assertEqual(case["native"], BASE)
        self.assertIsNone(case["preflight"])
        self.assertEqual(pathlib.Path(case["result"]["actor"]).parent.parent, pathlib.Path("/tmp"))
