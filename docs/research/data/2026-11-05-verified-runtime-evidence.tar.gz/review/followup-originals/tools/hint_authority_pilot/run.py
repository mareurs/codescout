"""Four-cell diagnostic. Scripted qualification never reads real credentials."""
import hashlib
import json
import os
import pathlib
import shutil
import signal
import subprocess
import sys
import threading
import time
import uuid
from decimal import Decimal
from core import admit, audit_hooks, extract_result
from prepare import L,P,IMAGE,CLAUSE,PROMPT,grade,save
from transport import server

HERE=pathlib.Path(__file__).resolve().parent
ROOT=pathlib.Path('/home/marius/.cache/codescout-resident/codescout')
W=ROOT/'worker-context-verification-20261104'
E=ROOT/'native-env-admission-20261104'
Q=E/'qualification-20261104'
R=ROOT/'native-build-provenance-20261104'
CLI=ROOT/'behavior-transfer-20261029/claude-2.1.309'
CELLS=[('low',False),('xhigh',True),('low',True),('xhigh',False)]
TOKEN=pathlib.Path('/home/marius/.config/s5/token-claude-stef')

def visible(text):
    # Claude's CLAUDE.md renderer removes HTML comments and blank lines.
    import re
    text=re.sub(r'<!--.*?-->','',text,flags=re.S)
    return [line.strip() for line in text.splitlines() if line.strip()]

def cleanup(out):
    records=[]
    for p in out.glob('mcp-launch-*.json'):
        name=json.loads(p.read_text())['name']
        inspected=subprocess.run(['docker','inspect',name],capture_output=True,text=True)
        if inspected.returncode==0:
            row=json.loads(inspected.stdout)[0]
            if row['Image']!=IMAGE or row['Config']['Labels'].get('codescout.hfa')!=name:
                raise ValueError('Container cleanup identity mismatch')
            subprocess.run(['docker','rm','-f',row['Id']],capture_output=True,check=True)
        result=subprocess.run(['docker','inspect',name],capture_output=True,text=True)
        absent=result.returncode!=0 and 'no such' in result.stderr.lower()
        records.append({'name':name,'absent':absent})
        if not absent:raise ValueError('Owned container remains')
    save(out/'cleanup.json',records)

def native_argv(actor,home):
    base=json.loads((E/'semantic-minimal-20261104/cli-launch.json').read_text())['argv']
    base[1]='run';base[2:2]=['-i']
    base[-4:]=[IMAGE,'start','--project','/testbed']
    for i,value in enumerate(base):
        if value.startswith('type=bind,'):
            if 'dst=/testbed' in value.split(','):base[i]=f'type=bind,src={actor},dst=/testbed'
            if 'dst=/bench-home' in value.split(','):base[i]=f'type=bind,src={home},dst=/bench-home'
            if 'dst=/bench/bin' in value.split(','):base[i]=f'type=bind,src={R}/bin,dst=/bench/bin,readonly'
        if value.startswith('PATH='):base[i]='PATH=/bench/lsp/bin:/opt/sab/bin:/usr/local/cargo/bin:/usr/local/bin:/usr/bin:/bin'
        if value=='CARGO_HOME=/bench-home/.cargo':base[i]='CARGO_HOME=/cargo'
    extra=['--mount','type=bind,src=/home/marius/work/claude/hce-data/cargo-home,dst=/cargo,readonly',
           '-e','RUSTUP_HOME=/usr/local/rustup','-e','RUSTUP_TOOLCHAIN=1.97.1-x86_64-unknown-linux-gnu','-e','RUSTC_WRAPPER=',
           '-e','CARGO_TARGET_DIR=/testbed/target','-e','CARGO_PROFILE_DEV_DEBUG=0','-e','CARGO_PROFILE_TEST_DEBUG=0']
    base[-4:-4]=extra
    return base

def plugin_copy():
    target=L/'skill-only-plugin'
    if not target.exists():
        source=pathlib.Path('/home/marius/.codex/plugins/cache/sdd-misc-plugins/codescout-companion/1.20.29')
        shutil.copytree(source,target,ignore=shutil.ignore_patterns('hooks','__pycache__','.git'))
        manifest={str(p.relative_to(target)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(target.rglob('*')) if p.is_file()}
        save(L/'plugin-manifest.json',{'version':'1.20.29','reason':'Prior 1.20.26 cache removed; all current cells use this same frozen copy','files':manifest})
    return target

def one(label,effort,declaration,scripted,*,campaign_remaining=None,workflow=None):
    if workflow is not None:
        sys.path.insert(0,str(HERE.parent/"agent_lifecycle"))
        import workflow as workflow_adapter
        workflow_adapter.validate_config(workflow)
    from core import amount
    available=Decimal('0') if scripted else amount(campaign_remaining)
    if not scripted and not 0<available<=4:raise ValueError('Invalid campaign balance')
    out=L/label;out.mkdir()  # Exclusive attempt directory, never silently retry.
    actor=(workflow_adapter.prepare_actor(out) if workflow is not None else
           pathlib.Path('/tmp')/('hfa-'+uuid.uuid4().hex)/'project')
    shutil.copytree(L/'source',actor)
    nativehome=out/'native-home';nativehome.mkdir()
    home=out/'client-home';config=home/'.claude';config.mkdir(parents=True)
    glob=(P/'inputs/global-CLAUDE.md').read_text()
    project=(actor/'CLAUDE.md').read_text()
    if CLAUSE in project:raise ValueError('Baseline already declares authority')
    if declaration:project+='\n'+CLAUSE+'\n'
    (actor/'CLAUDE.md').write_text(project);(config/'CLAUDE.md').write_text(glob)
    subprocess.run(['git','init','-q'],cwd=actor,check=True)
    subprocess.run(['git','add','.'],cwd=actor,check=True)
    subprocess.run(['git','-c','user.name=HFA fixture','-c','user.email=hfa@invalid','commit','-qm','Frozen diagnostic baseline'],cwd=actor,check=True)
    expected={'effort':effort,'declaration':declaration,'clause':CLAUSE,'global_visible':visible(glob),'project_visible':visible(project)}
    save(out/'expected.json',expected);save(out/'actor.json',{'path':str(actor)})
    native=native_argv(actor,nativehome)
    if workflow is not None:
        native=workflow_adapter.verified_native_argv(native)
    save(out/'mcp-native-argv.json',native)
    save(out/'mcp.json',{'mcpServers':{'codescout':{'command':'/usr/bin/python3','args':['-B',str(HERE/'stdio.py'),str(out)]}}})
    tools=['index','read_file','memory','symbols','workspace','references','edit_code','edit_file','create_file','run_command','list_files','grep','get_guide']
    allowed=['Skill','ToolSearch']+['mcp__codescout__'+n for n in tools]
    state=out/'hook';state.mkdir()
    hookcmd=f'HFA_STATE={state} HFA_FN=build_chunks HFA_PATH=src/librarian/catalog/chunk.rs /usr/bin/python3 -B {HERE}/pilot_hook.py'
    settings={'permissions':{'allow':allowed},'hooks':{'PostToolUse':[{'matcher':'mcp__codescout__.*','hooks':[{'type':'command','command':hookcmd,'timeout':10}]}]}}
    save(out/'settings.json',settings)
    plan=[('Skill',{'skill':'codescout-companion:reconnaissance'}),
          ('mcp__codescout__index',{'action':'status'}),
          ('mcp__codescout__read_file',{'path':'.codescout/system-prompt.md','start_line':1,'end_line':100,'force':True}),
          ('mcp__codescout__read_file',{'path':str(W/'outside-host-canary.txt'),'force':True}),
          ('mcp__codescout__memory',{'action':'read','topic':'architecture'}),
          ('mcp__codescout__symbols',{'path':'src/librarian/catalog/chunk.rs','name':'build_chunks','include_body':True}),
          ('mcp__codescout__references',{'path':'src/librarian/catalog/chunk.rs','symbol':'build_chunks'}),
          ('mcp__codescout__create_file',{'path':'hfa-transport-probe.txt','content':'scripted native edit after hint\n'})]
    s=server(out,expected,scripted,plan,campaign_remaining=available)
    sid=str(uuid.uuid4())
    prompt=PROMPT if not scripted else 'Scripted transport diagnostic, no paid model. Execute the requested tool sequence and create only hfa-transport-probe.txt. Do not change source or onboard.'
    argv=[str(CLI),'-p','--model','claude-sonnet-5-5','--effort',effort,'--session-id',sid,
          '--setting-sources','user,project,local','--settings',str(out/'settings.json'),
          '--strict-mcp-config','--mcp-config',str(out/'mcp.json'),'--permission-mode','acceptEdits',
          '--tools','Skill,ToolSearch','--allowedTools',','.join(allowed),'--output-format','json',
          '--max-turns','32','--max-budget-usd','0.65','--plugin-dir',str(plugin_copy()),'--',prompt]
    env={'HOME':str(home),'USER':'marius','LANG':'C.UTF-8','PATH':'/usr/local/bin:/usr/bin:/bin',
         'CLAUDE_CONFIG_DIR':str(config),'ANTHROPIC_BASE_URL':'http://127.0.0.1:'+str(s.server_port),
         'DISABLE_AUTOUPDATER':'1','CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC':'1','CLAUDE_CODE_MAX_OUTPUT_TOKENS':'8192',
         'PYTHONDONTWRITEBYTECODE':'1'}
    if scripted:env['ANTHROPIC_API_KEY']='scripted-no-real-credential'
    else:
        st=TOKEN.stat()
        if not TOKEN.is_file() or st.st_mode&0o077:raise ValueError('Credential permissions invalid')
        env['CLAUDE_CODE_OAUTH_TOKEN']=TOKEN.read_text().strip()
    save(out/'launch.json',dict(argv=argv,session_id=sid,scripted=scripted,real_credentials_read=not scripted,
      hook_set='Research hint only; pinned companion skills, production hooks removed identically in all cells'))
    if workflow is not None:
        return workflow_adapter.execute(sys.modules[__name__],workflow,out,actor,argv,env,s,sid,state,available)
    started=time.monotonic()
    with (out/'stdout.json').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
        p=subprocess.Popen(argv,cwd=actor,env=env,stdout=stdout,stderr=stderr,stdin=subprocess.DEVNULL,start_new_session=True)
        try:p.wait(timeout=900 if not scripted else 240)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGTERM)
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    s.shutdown();s.server_close();cleanup(out)
    records=json.loads((out/'stdout.json').read_text())
    if not isinstance(records,list):records=[records]
    terminal=extract_result(records,sid)
    events=[json.loads(l) for l in (state/'events.jsonl').read_text().splitlines()] if (state/'events.jsonl').exists() else []
    receipt={'session_id':sid,'scripted':scripted,'cost_usd':str(terminal['cost']),'exit_code':p.returncode,
      'terminal':{k:v for k,v in terminal.items() if k!='cost'},'wall_s':time.monotonic()-started,
      'requests':len(s.requests),'forwarded':s.forwarded,'transport_errors':s.errors,
      'campaign_available_usd':str(available),'budget_stop':s.budget_stop,
      'workflow_completed':p.returncode==0 and terminal['is_error'] is False and s.budget_stop is None and not s.errors,
      'upper_usage_cost':str(s.budget.spent),'unknown_provider_cost':s.budget.pending is not None,
      'hint_then_edit':audit_hooks(events),'scripted_steps':s.stage,'actor':str(actor)}
    save(out/'receipt.json',receipt)
    if scripted:
        if s.errors or s.stage!=len(plan) or not receipt['hint_then_edit'] or not (actor/'hfa-transport-probe.txt').exists():
            raise ValueError('Functional transport qualification failed')
    elif terminal['cost']>available or s.budget.pending is not None:
        raise ValueError('Unknown or excessive model cost: stop campaign')
    return receipt

def prior_spend():
    path=L/'prior-attempts.json'
    if not path.exists():return Decimal('0')
    seen=set();total=Decimal('0')
    for attempt in json.loads(path.read_text())['attempts']:
        sid=attempt['session_id']
        if sid in seen:raise ValueError('Duplicate prior attempt')
        seen.add(sid)
        receipt=json.loads(pathlib.Path(attempt['receipt_path']).read_text())
        if receipt.get('unknown_provider_cost') or receipt.get('session_id')!=sid:raise ValueError('Unknown prior cost')
        raw=json.loads(pathlib.Path(attempt['stdout_path']).read_text())
        result=extract_result(raw if isinstance(raw,list) else [raw],sid)
        if result['cost']!=Decimal(receipt['cost_usd']):raise ValueError('Prior cost mismatch')
        total+=result['cost']
    return total

def main():
    from audit import fingerprint,validate_preflight
    mode=sys.argv[1]
    if mode not in {'qualify','paid'}:raise ValueError('Choose qualify or paid')
    scripted=mode=='qualify'
    current=fingerprint()
    if not scripted:
        controls=json.loads((L/'functional-controls-v2.json').read_text())
        qualifications=[json.loads((L/f'qualify-{i}'/'receipt.json').read_text()) for i in range(4)]
        review=json.loads((L/'review-accepted.json').read_text())
        validate_preflight(controls,qualifications,review,current)
    prior=Decimal('0') if scripted else prior_spend()
    results=[];spent=prior
    prefix=mode+'-v2' if not scripted and (L/'prior-attempts.json').exists() else mode
    for i,(effort,declaration) in enumerate(CELLS):
        if not admit(spent,Decimal('1'),Decimal('4')):break
        if fingerprint()!=current:raise ValueError('Inputs/controller changed during campaign')
        label=f'{prefix}-{i}'
        try:r=one(label,effort,declaration,scripted,campaign_remaining=Decimal('4')-spent)
        except Exception as e:
            save(L/(prefix+'-halt.json'),{'attempt':label,'cost_usd':'unknown until terminal recovery','reason':type(e).__name__+': '+str(e),'no_later_cell_started':True})
            raise
        r['fingerprint']=current;save(L/label/'receipt.json',r)
        spent+=Decimal(r['cost_usd'])
        results.append(dict(cell=i,effort=effort,declaration=declaration,**r))
        save(L/(prefix+'-results.json'),{'cost_usd':str(spent),'prior_cost_usd':str(prior),'results':results})
        print(json.dumps(results[-1]),flush=True)
        if not scripted:
            dst=L/(label+'-grader')
            shutil.copytree(pathlib.Path(r['actor']),dst,ignore=shutil.ignore_patterns('.git','target'))
            g=grade(dst,label);results[-1]['grade_exit_code']=g['exit_code']
            save(L/(prefix+'-results.json'),{'cost_usd':str(spent),'prior_cost_usd':str(prior),'results':results})
            if r['transport_errors']:break

if __name__=='__main__':main()
