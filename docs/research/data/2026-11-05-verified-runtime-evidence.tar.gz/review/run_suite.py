import hashlib,json,pathlib,re,subprocess,sys,time
root=pathlib.Path(__file__).resolve().parent
name=sys.argv[1]
command=[sys.executable,'-B','-m','unittest','discover','-s','tools/agent_lifecycle','-p','test_*.py']
started=time.monotonic()
run=subprocess.run(command,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(root/'logs').mkdir(exist_ok=True)
log=root/'logs'/(name+'.log')
log.write_text(run.stdout)
counts=re.findall(r'^Ran (\d+) tests? in ',run.stdout,re.M)
record=dict(id=name,command=command,exit_code=run.returncode,tests=int(counts[-1]) if counts else None,wall_s=time.monotonic()-started,log=str(log),source_sha256={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'tools/agent_lifecycle/workflow.py',root/'tools/hint_authority_pilot/run.py']})
(root/'results').mkdir(exist_ok=True)
(root/'results'/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
print(run.stdout[-2500:])
