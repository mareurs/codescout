import json,pathlib,sys
root=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools/agent_lifecycle'))
from test_runtime import RuntimeTests
rows=[]
for label,kwargs in [('unknown_type',dict(filesystem='UNKNOWN (0x12345678)')),('no_image',dict(native=['docker','run','--network','none'])),('empty_image',dict(native=['docker','run','']))]:
    case=RuntimeTests()
    try:
        result=case.exercise(trap_credentials=True,**kwargs)
        rows.append(dict(label=label,kwargs=kwargs,touches=result['touches'],error=repr(result['error']),preflight=result['preflight'],actor_exists=(result['out']/'project').exists(),native=result['native']))
    finally:case.doCleanups()
(root/'functional-probes.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
