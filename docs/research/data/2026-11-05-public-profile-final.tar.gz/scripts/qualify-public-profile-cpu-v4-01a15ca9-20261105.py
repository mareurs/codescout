"""Known-reference control with two CPUs; probe executable lives on the owned build volume."""
import hashlib
import importlib.util
import json
import pathlib
import shutil
import subprocess
import sys
import traceback

ORIGINAL = pathlib.Path("/tmp/verified-public-profile-01a15ca9-20261105.py")
ROOT = pathlib.Path("/home/marius/.cache/codescout-resident/codescout/public-profile-reference-20261105-v4")
CACHE = ROOT.with_name("public-profile-reference-20261105-v2")/"project/target"

def main():
    expected = "3369ee8d629ff14155deccc96a5021d2b3a1d3a641bc483c8cf29f830d65b7f4"
    if hashlib.sha256(ORIGINAL.read_bytes()).hexdigest() != expected:
        raise ValueError("Original control changed")
    if ROOT.exists() or not CACHE.is_dir() or CACHE.is_symlink():
        raise ValueError("Exclusive root/cache precondition failed")
    if subprocess.run(["docker", "inspect", "hfa-public-profile-01a15ca9-20261105"],
                      stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0:
        raise ValueError("Previous exact control name remains live/present")
    capacity = shutil.disk_usage(ROOT.parent)
    if capacity.free < 30*1024**3:
        raise ValueError("Less than 30 GiB free")
    spec = importlib.util.spec_from_file_location("public_profile_cpu_control", ORIGINAL)
    control = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(control)
    control.ROOT = ROOT
    original_argv = control.worker.native_argv
    def native_argv(actor, home):
        argv = original_argv(actor, home)
        argv[-4:-4] = ["--cpus", "2", "--mount", "type=bind,src="+str(CACHE)+",dst=/testbed/target"]
        return argv
    control.worker.native_argv = native_argv
    original_check = control.native_check
    probe_done = False
    def native_check(out, image, command, log, timeout_s):
        nonlocal probe_done
        if not probe_done:
            probe = "printf '%s' 'fn main(){println!(\"{}\",std::thread::available_parallelism().unwrap());}' > /testbed/target/cpu-probe.rs && rustc /testbed/target/cpu-probe.rs -o /testbed/target/cpu-probe && /testbed/target/cpu-probe && cat /sys/fs/cgroup/cpu.max && cat /sys/fs/cgroup/pids.max"
            code = original_check(out, image, probe, out/"cpu-probe.log", min(30, timeout_s))
            if code != 0 or (out/"cpu-probe.log").read_text().splitlines()[0] != "2":
                raise ValueError("Two-CPU Rust parallelism probe failed")
            probe_done = True
        return original_check(out, image, command, log, timeout_s)
    control.native_check = native_check
    record = {"script_sha256":hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
              "root":str(ROOT),"owned_build_cache":str(CACHE),"cpu_quota":2,
              "public_commands_changed":False,"test_filters_added":False,
              "disk_available_bytes_before":capacity.free,"provider_calls":0}
    exit_code = 1
    try:
        exit_code = control.main()
    except BaseException:
        record["outer_error"] = traceback.format_exc()
        raise
    finally:
        if ROOT.exists():
            record["control_exit_code"] = exit_code
            (ROOT/"retry-preflight.json").write_text(json.dumps(record,indent=2)+"\n")
    return exit_code

if __name__ == "__main__":
    sys.exit(main())
