import json,os,pathlib,signal,subprocess,time
child=subprocess.Popen(["sh","-c","sleep 60 & echo $! ; wait"],stdout=subprocess.PIPE,text=True,start_new_session=True)
pid=int(child.stdout.readline().strip())
os.killpg(child.pid,signal.SIGTERM);time.sleep(.5)
try:os.killpg(child.pid,signal.SIGKILL)
except ProcessLookupError:pass
child.wait(timeout=5);time.sleep(.2)
path=pathlib.Path("/proc")/str(pid)/"stat"
fields=path.read_text().split() if path.exists() else None
print(json.dumps({"parent_pid":os.getpid(),"grandchild_pid":pid,"state":fields[2] if fields else "absent","ppid":int(fields[3]) if fields else None}),flush=True)
