"""Independent readback of the completed known-reference public profile."""
import hashlib
import json
import pathlib
import re
import subprocess

root = pathlib.Path("/home/marius/.cache/codescout-resident/codescout/public-profile-reference-20261105-v6")
receipt = json.loads((root/"result.json").read_text())
public = receipt["public_verification"]
assert public["status"] == "completed" and public["passed"]
assert [q["exit_code"] for q in public["checks"]] == [0,0,0,0]
assert receipt["provider_calls"] == 0 and receipt["model_cost_usd"] == "0" and not receipt["error"]
preflight = json.loads((root/"retry-preflight.json").read_text())
script = pathlib.Path("/tmp/qualify-public-profile-git-v6-01a15ca9-20261105.py")
assert hashlib.sha256(script.read_bytes()).hexdigest() == preflight["script_sha256"]
assert preflight["cpu_quota"] == 2 and preflight["init_reaper"] and preflight["git_baseline"]
argv = json.loads((root/"launch.json").read_text())["argv"]
assert "--init" in argv and argv[argv.index("--cpus")+1] == "2"
assert (root/"cpu-probe.log").read_text().splitlines() == ["2","200000 100000","512"]
owner = json.loads((root/"record-owner.json").read_text())
identities = [json.loads(line) for line in (root/"public-worker-identities.jsonl").read_text().splitlines()]
assert all(q["container_id"] == owner["container_id"] and q["name"] == owner["name"] for q in identities)
for identity in [receipt["cleanup"]["id"], owner["name"]]:
    assert subprocess.run(["docker","inspect",identity], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode != 0
before = json.loads((root/"candidate-before.json").read_text())
after = json.loads((root/"candidate-after.json").read_text())
changes = [p for p in sorted(before.keys()|after.keys()) if before.get(p) != after.get(p)]
runtime_paths = {".codescout/embeddings/.gitignore", ".codescout/embeddings/hint-authority-diagnostic.db", ".codescout/write.lock"}
runtime_created = [p for p in changes if p in runtime_paths and p not in before]
git_changes = [p for p in changes if p.startswith(".git/")]
unexpected = [p for p in changes if p not in runtime_created and p not in git_changes]
assert not unexpected, unexpected
summaries = {}
for check in public["checks"]:
    text = pathlib.Path(check["log"]).read_text()
    summaries[check["id"]] = re.findall(r"^test result: (?:ok|FAILED)\. [^\n]+", text, re.M)
    assert not any(q.startswith("test result: FAILED") for q in summaries[check["id"]])
result = {
    "verified": True, "scope": "Known-reference full Rust public profile; not model-quality evidence",
    "public_exits": [q["exit_code"] for q in public["checks"]], "public_wall_s": receipt["public_wall_s"],
    "unexpected_source_or_knowledge_changes": unexpected, "new_runtime_paths": runtime_created,
    "runtime_sha256": {p:after[p] for p in runtime_created}, "git_metadata_changes": git_changes,
    "same_container_id": owner["container_id"], "exact_container_independently_absent": True,
    "cpu_probe": [2,"200000 100000",512], "init_flag": True, "git_baseline": True,
    "script_sha256": preflight["script_sha256"], "model_cost_usd": "0",
    "test_summary_lines_by_invocation": summaries,
}
dest = pathlib.Path("/home/marius/work/claude/codescout/docs/research/data/2026-11-05-public-profile-final-verification.json")
with dest.open("x") as output:
    json.dump(result, output, indent=2)
    output.write("\n")
print(json.dumps({k:v for k,v in result.items() if k != "test_summary_lines_by_invocation"}))
