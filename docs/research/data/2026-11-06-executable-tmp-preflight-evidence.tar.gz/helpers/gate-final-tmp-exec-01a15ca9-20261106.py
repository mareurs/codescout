import json,pathlib,subprocess,time
prior=pathlib.Path('/tmp/codescout-bg/455879-a720241d-bg_000000e8.json')
while json.loads(prior.read_text())['state']=='running':
    time.sleep(15)
result=subprocess.run(['./scripts/gate.sh','--check'],cwd='/tmp/codescout-tmp-exec-01a15ca9')
raise SystemExit(result.returncode)
