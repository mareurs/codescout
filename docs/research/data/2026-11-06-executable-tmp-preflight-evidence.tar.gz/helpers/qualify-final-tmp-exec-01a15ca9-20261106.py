import importlib.util,pathlib
p='/tmp/qualify-executable-tmp-01a15ca9-20261106.py'
s=importlib.util.spec_from_file_location('tmp_qualification',p)
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
m.ROOT=m.BASE/'external-exec-baseline-20261106-v2'
m.GATE=pathlib.Path('/tmp/codescout-bg/455879-a720241d-bg_000000ea.json')
m.main()
