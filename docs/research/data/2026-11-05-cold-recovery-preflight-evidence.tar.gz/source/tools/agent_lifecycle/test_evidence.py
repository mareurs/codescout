"""Evidence retention at the real lifecycle deadline; only Docker/cleanup are external doubles."""
import json
import pathlib
import subprocess
import sys
import tempfile
import unittest
from decimal import Decimal
from types import SimpleNamespace
from unittest.mock import patch
import qualify
import workflow

class EvidenceTests(unittest.TestCase):
    def exercise_deadline(self, *, copy_fails=False, settled=False):
        with tempfile.TemporaryDirectory() as temp:
            out=pathlib.Path(temp)
            (out/"observations").mkdir();(out/"hook").mkdir()
            record_path="/tmp/codescout-bg/7-abcd-bg_00000001.json"
            (out/"observations/job.json").write_text(json.dumps({
                "tool_name":"mcp__codescout__run_command",
                "tool_response":{"output_id":"@bg_00000001","record":record_path}}))
            (out/"mcp-launch-worker.json").write_text(json.dumps({"name":"worker"}))
            (out/"settings.json").write_text("{}");(out/"launch.json").write_text("{}")
            client=out/"client.py"
            client.write_text("import json,sys\nsys.stdin.readline()\nprint(json.dumps(dict(type='result',subtype='success',is_error=False,session_id='sid',total_cost_usd=0)),flush=True)\nfor line in sys.stdin: pass\n")
            job=dict(schema=1,handle="@bg_00000001",state="running",exit_code=None,
                     log_path="/tmp/codescout-bg-ABC123.log")
            if settled:
                (out/"observations/job.json").unlink()
                (out/"record-owner.json").write_text(json.dumps({"name":"worker","container_id":"immutable-id"}))
                (out/"record-observations.jsonl").write_text(json.dumps({"container":"worker","container_id":"immutable-id","record":job})+"\n")
            def docker(argv,**kwargs):
                if argv[:2]==["docker","inspect"]:
                    return subprocess.CompletedProcess(argv,0,json.dumps([{"Id":"immutable-id",
                        "State":{"Running":True},"Image":qualify.worker.IMAGE,"Config":{"Labels":{"codescout.hfa":"worker"}}}]),"")
                if argv[:4]==["docker","exec","-w","/testbed"]:
                    self.assertEqual(argv[4],"immutable-id")
                    return subprocess.CompletedProcess(argv,0,"","")
                self.assertEqual(argv[:3],["docker","exec","immutable-id"])
                if argv[3]=="cat":
                    self.assertEqual(argv[4],record_path)
                    return subprocess.CompletedProcess(argv,0,json.dumps(job),"")
                self.assertEqual(argv[3:5],["head","-c"])
                self.assertEqual(argv[-1],job["log_path"])
                return subprocess.CompletedProcess(argv,1,b"",b"copy failed") if copy_fails else subprocess.CompletedProcess(argv,0,b"cold compiler still running\n",b"")
            cleanup=[]
            def remove_native(root):
                # A no-op preservation call cannot satisfy this boundary.
                proof=json.loads((root/"background-evidence.json").read_text())
                cleanup.append(proof)
                if not copy_fails:
                    self.assertEqual(pathlib.Path(proof["logs"][0]["saved_path"]).read_bytes(),b"cold compiler still running\n")
                return []
            server=SimpleNamespace(budget=SimpleNamespace(pending=None,spent=Decimal(0)),
                errors=[],budget_stop=None,forwarded=0,requests=[],scripted=True,stage=0,
                shutdown=lambda:None,server_close=lambda:None)
            worker=qualify.worker
            argv=[sys.executable,str(client),"--session-id","sid","--output-format","json","--","task"]
            with patch.object(qualify.subprocess,"run",side_effect=docker),patch.object(workflow,"cleanup_native",side_effect=remove_native):
                receipt=workflow.execute(worker,{"checks":[{"id":"compile","command":"unused"}],"timeout_s":.3},
                    out,out,argv,{},server,"sid",out/"hook",Decimal(4))
            if settled:
                self.assertEqual(receipt["lifecycle"]["status"],"settled")
                self.assertTrue(receipt["public_verification"]["passed"])
            else:
                self.assertEqual(receipt["lifecycle"]["status"],"incomplete")
                self.assertIn("deadline",receipt["lifecycle"]["error"])
            self.assertFalse(receipt["workflow_completed"])
            self.assertEqual(receipt["cost_usd"],"0")
            self.assertFalse(receipt["unknown_provider_cost"])
            self.assertEqual(len(cleanup),1)
            self.assertIsNone(receipt["cleanup_error"])
            return receipt,cleanup[0]

    def test_deadline_copies_native_log_before_cleanup(self):
        receipt,proof=self.exercise_deadline()
        self.assertTrue(proof["complete"])
        self.assertTrue(receipt["background_evidence"]["complete"])
        self.assertEqual(proof["logs"][0]["bytes_saved"],28)
        self.assertEqual(proof["logs"][0]["container_id"],"immutable-id")
        self.assertFalse(proof["logs"][0]["truncated"])

    def test_capture_error_is_explicit_and_cleanup_still_runs(self):
        receipt,proof=self.exercise_deadline(copy_fails=True)
        self.assertFalse(proof["complete"])
        self.assertFalse(receipt["background_evidence"]["complete"])
        self.assertTrue(proof["errors"])

    def test_settled_session_with_missing_background_evidence_is_not_completed(self):
        receipt,proof=self.exercise_deadline(copy_fails=True,settled=True)
        self.assertFalse(proof["complete"])
        self.assertFalse(receipt["workflow_completed"])

    def test_no_jobs_is_complete_without_contacting_docker(self):
        with tempfile.TemporaryDirectory() as temp:
            out=pathlib.Path(temp)
            with patch.object(qualify.subprocess,"run",side_effect=AssertionError("no Docker needed")):
                proof=qualify.preserve_background_logs(out)
            self.assertEqual(proof,{"complete":True,"logs":[],"errors":[]})


class EvidenceGuardTests(unittest.TestCase):
    def exercise(self, *, replaced=False, native_path="/tmp/codescout-bg-ABC123.log", max_bytes=64):
        with tempfile.TemporaryDirectory() as temp:
            out=pathlib.Path(temp)
            (out/"record-owner.json").write_text(json.dumps({"name":"worker","container_id":"original-id"}))
            row=dict(container="worker",container_id="original-id",record=dict(state="running",log_path=native_path))
            (out/"record-observations.jsonl").write_text(json.dumps(row)+"\n")
            calls=[]
            def docker(argv,**kwargs):
                calls.append(argv)
                if argv[1]=="inspect":
                    return subprocess.CompletedProcess(argv,0,json.dumps([{"Id":"replacement-id" if replaced else "original-id",
                        "Image":qualify.worker.IMAGE,"Config":{"Labels":{"codescout.hfa":"worker"}}}]),"")
                self.assertEqual(argv,["docker","exec","original-id","head","-c",str(max_bytes+1),native_path])
                return subprocess.CompletedProcess(argv,0,b"abcdefgh",b"")
            with patch.object(qualify.subprocess,"run",side_effect=docker):
                proof=qualify.preserve_background_logs(out,max_bytes=max_bytes)
            content=[pathlib.Path(row["saved_path"]).read_bytes() for row in proof["logs"]]
            return proof,calls,content

    def test_replacement_is_never_read(self):
        proof,calls,_=self.exercise(replaced=True)
        self.assertFalse(proof["complete"])
        self.assertFalse(any(argv[1]=="exec" for argv in calls))

    def test_arbitrary_log_paths_are_rejected_before_copy(self):
        for path in ("/etc/passwd","/tmp/codescout-bg-../../secret.log",None):
            with self.subTest(path=path):
                proof,calls,_=self.exercise(native_path=path)
                self.assertFalse(proof["complete"])
                self.assertFalse(any(argv[1]=="exec" for argv in calls))

    def test_oversized_capture_is_preserved_as_explicitly_partial(self):
        proof,_,content=self.exercise(max_bytes=4)
        self.assertEqual(content,[b"abcd"])
        self.assertTrue(proof["logs"][0]["truncated"])
        self.assertEqual(proof["logs"][0]["bytes_saved"],4)
        self.assertFalse(proof["complete"])
