import unittest
from prepare import acceptance_executed
class GraderTests(unittest.TestCase):
    def test_zero_tests_and_one_missing_assertion_are_rejected(self):
        good='test librarian::catalog::chunk::hfa_acceptance::offset_and_chunk_metadata ... ok\ntest librarian::catalog::chunk::hfa_acceptance_callers::initial_and_forced_reindex_publish_file_coordinates ... ok\ntest result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 4995 filtered out; finished in 0.00s'
        self.assertTrue(acceptance_executed(good))
        self.assertFalse(acceptance_executed('test result: ok. 0 passed; 0 failed'))
        self.assertFalse(acceptance_executed(good.replace('hfa_acceptance_callers::','other::')))
        self.assertFalse(acceptance_executed(good.replace('2 passed; 0 failed','1 passed; 1 failed')))
