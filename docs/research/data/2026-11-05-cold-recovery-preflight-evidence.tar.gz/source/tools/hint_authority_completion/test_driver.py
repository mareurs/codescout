import importlib.util
import json
import pathlib
import tempfile
import unittest
from decimal import Decimal
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('completion', pathlib.Path(__file__).with_name('driver.py'))
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)


class CompletionTests(unittest.TestCase):
    def worker(self, root, seen, *, unknown=False, wrong_cost=False):
        actor = root / 'actor'
        actor.mkdir()
        def one(label, effort, declaration, scripted, **kwargs):
            seen.append((effort, declaration, scripted, kwargs['campaign_remaining']))
            out = root / label
            out.mkdir()
            (out / 'stdout.json').write_text(json.dumps({
                'type': 'result', 'session_id': label, 'total_cost_usd': '.2',
                'is_error': False, 'subtype': 'success'}))
            return {'session_id': label, 'cost_usd': '.3' if wrong_cost else '.2',
                    'unknown_provider_cost': unknown, 'transport_errors': [],
                    'budget_stop': None, 'workflow_completed': True,
                    'terminal': {'is_error': False, 'subtype': 'success'}, 'actor': str(actor)}
        return one

    def test_actual_pair_carries_prior_cost_and_decreases_balance_independent_of_grade(self):
        with tempfile.TemporaryDirectory() as d:
            root = pathlib.Path(d)
            seen = []
            with patch.object(driver.worker, 'one', self.worker(root, seen)), \
                 patch.object(driver.prepare, 'grade', return_value={'exit_code': 101}):
                result = driver.execute_pair(root, Decimal('1.6'), lambda: 'fp')
            self.assertEqual(seen, [('low', False, False, Decimal('2.4')),
                                    ('xhigh', False, False, Decimal('2.2'))])
            self.assertEqual(Decimal(result['pilot_cost_usd']), Decimal('2.0'))
            self.assertEqual(len(result['results']), 2)

    def test_unknown_cost_and_terminal_mismatch_each_block_the_second_run(self):
        for flags in ({'unknown': True}, {'wrong_cost': True}):
            with self.subTest(flags=flags), tempfile.TemporaryDirectory() as d:
                root = pathlib.Path(d)
                seen = []
                with patch.object(driver.worker, 'one', self.worker(root, seen, **flags)):
                    with self.assertRaises(ValueError):
                        driver.execute_pair(root, Decimal('1.6'), lambda: 'fp')
                self.assertEqual(len(seen), 1)
                self.assertTrue((root / 'completion-halt.json').exists())

    def test_before_start_reserve_blocks_without_a_paid_call(self):
        with tempfile.TemporaryDirectory() as d:
            root = pathlib.Path(d)
            with patch.object(driver.worker, 'one') as one:
                result = driver.execute_pair(root, Decimal('3.1'), lambda: 'fp')
            one.assert_not_called()
            self.assertEqual(result['results'], [])

    def test_grade_failure_keeps_known_cost_and_exclusive_marker_blocks_reentry(self):
        with tempfile.TemporaryDirectory() as d:
            root = pathlib.Path(d)
            seen = []
            with patch.object(driver.worker, 'one', self.worker(root, seen)), \
                 patch.object(driver.prepare, 'grade', side_effect=RuntimeError('grader failed')):
                with self.assertRaises(RuntimeError):
                    driver.execute_pair(root, Decimal('1.6'), lambda: 'fp')
                ledger = json.loads((root / 'completion-results.json').read_text())
                self.assertEqual(Decimal(ledger['pilot_cost_usd']), Decimal('1.8'))
                with self.assertRaises(FileExistsError):
                    driver.execute_pair(root, Decimal('1.6'), lambda: 'fp')
            self.assertEqual(len(seen), 1)

    def test_failed_preflight_blocks_before_any_model_call(self):
        with tempfile.TemporaryDirectory() as d:
            root = pathlib.Path(d)
            with patch.object(driver.worker, 'one') as one:
                with self.assertRaisesRegex(ValueError, 'stale'):
                    driver.execute_pair(root, Decimal('1.6'),
                                        lambda: (_ for _ in ()).throw(ValueError('stale')))
            one.assert_not_called()


class GuardCoverageTests(unittest.TestCase):
    def fixture(self, root):
        import hashlib
        host = root / 'host'
        host.mkdir()
        canary = host / 'outside-host-canary.txt'
        canary.write_text('fixture canary')
        digest = hashlib.sha256(canary.read_bytes()).hexdigest()
        plan = {'cells': [['low', False], ['xhigh', False]], 'pilot_cap_usd': '4',
                'prior_pilot_cost_usd': '1.6', 'prior_thread_cost_usd': '29.221154299999999834',
                'host_canary_sha256': digest}
        plan_bytes = json.dumps(plan).encode()
        (root / 'completion-plan.json').write_bytes(plan_bytes)
        review = {'accepted': True, 'fingerprint': 'fp',
                  'driver_sha256': hashlib.sha256(pathlib.Path(driver.__file__).read_bytes()).hexdigest(),
                  'plan_sha256': hashlib.sha256(plan_bytes).hexdigest()}
        (root / 'completion-review.json').write_text(json.dumps(review))
        (root / 'verification-summary.json').write_text(json.dumps({
            'fingerprint': 'fp', 'host_canary_presence_at_audit': {'path': str(canary), 'sha256': digest}}))
        (root / 'functional-controls-v2.json').write_text(json.dumps({
            'oracle_version': 2, 'fingerprint': 'fp', 'results': [{'exit_code': 101}, {'exit_code': 0}]}))
        for i in range(4):
            out = root / f'qualify-{i}'
            out.mkdir()
            (out / 'receipt.json').write_text(json.dumps({
                'fingerprint': 'fp', 'transport_errors': [], 'hint_then_edit': True,
                'scripted_steps': 8, 'unknown_provider_cost': False, 'exit_code': 0,
                'terminal': {'is_error': False}, 'boundary_denied': True, 'hint_visible_on_wire': True}))
        return host, canary

    def test_real_preflight_rejects_individual_bad_bindings_witnesses_and_qualifications(self):
        variants = ('valid', 'driver_hash', 'plan_hash', 'review_fingerprint', 'missing_canary',
                    'changed_canary', 'stale_qualification', 'missing_hint', 'bad_control', 'changed_history')
        for variant in variants:
            with self.subTest(variant=variant), tempfile.TemporaryDirectory() as d:
                root = pathlib.Path(d)
                host, canary = self.fixture(root)
                if variant in ('driver_hash', 'plan_hash', 'review_fingerprint'):
                    path = root / 'completion-review.json'
                    data = json.loads(path.read_text())
                    key = {'driver_hash': 'driver_sha256', 'plan_hash': 'plan_sha256',
                           'review_fingerprint': 'fingerprint'}[variant]
                    data[key] = 'wrong'
                    path.write_text(json.dumps(data))
                elif variant == 'missing_canary':
                    canary.unlink()
                elif variant == 'changed_canary':
                    canary.write_text('changed')
                elif variant in ('stale_qualification', 'missing_hint'):
                    path = root / 'qualify-2/receipt.json'
                    data = json.loads(path.read_text())
                    data['fingerprint' if variant == 'stale_qualification' else 'hint_then_edit'] = (
                        'stale' if variant == 'stale_qualification' else False)
                    path.write_text(json.dumps(data))
                elif variant == 'bad_control':
                    path = root / 'functional-controls-v2.json'
                    data = json.loads(path.read_text())
                    data['results'][1]['exit_code'] = 101
                    path.write_text(json.dumps(data))
                with patch.object(driver.worker, 'L', root), patch.object(driver.prepare, 'L', root), \
                     patch.object(driver.audit, 'L', root), patch.object(driver.worker, 'W', host), \
                     patch.object(driver.audit, 'fingerprint', return_value='fp'), \
                     patch.object(driver, 'historical_spend', return_value=Decimal('1.7') if variant == 'changed_history' else Decimal('1.6')):
                    if variant == 'valid':
                        self.assertEqual(driver.check_preflight(root, root / 'old', Decimal('1.6')), 'fp')
                    else:
                        with self.assertRaises(ValueError):
                            driver.check_preflight(root, root / 'old', Decimal('1.6'))

    def test_wrong_terminal_identity_blocks_second_call(self):
        with tempfile.TemporaryDirectory() as d:
            root = pathlib.Path(d)
            seen = []
            original = CompletionTests().worker(root, seen)
            def wrong_identity(*args, **kwargs):
                receipt = original(*args, **kwargs)
                path = root / args[0] / 'stdout.json'
                data = json.loads(path.read_text())
                data['session_id'] = 'foreign-session'
                path.write_text(json.dumps(data))
                return receipt
            with patch.object(driver.worker, 'one', wrong_identity):
                with self.assertRaisesRegex(ValueError, 'Wrong session'):
                    driver.execute_pair(root, Decimal('1.6'), lambda: 'fp')
            self.assertEqual(len(seen), 1)

    def test_transport_and_campaign_exhaustion_each_stop_after_known_cost(self):
        for kind in ('transport', 'budget'):
            with self.subTest(kind=kind), tempfile.TemporaryDirectory() as d:
                root = pathlib.Path(d)
                seen = []
                original = CompletionTests().worker(root, seen)
                def stopped(*args, **kwargs):
                    receipt = original(*args, **kwargs)
                    receipt['workflow_completed'] = False
                    receipt['terminal'] = {'is_error': True, 'subtype': 'error_max_budget_usd'}
                    path = root / args[0] / 'stdout.json'
                    data = json.loads(path.read_text())
                    data.update(receipt['terminal'])
                    path.write_text(json.dumps(data))
                    if kind == 'transport':
                        receipt['transport_errors'] = ['fixture transport failure']
                    else:
                        receipt['budget_stop'] = {'reason': 'fixture campaign exhausted'}
                    return receipt
                with patch.object(driver.worker, 'one', stopped), \
                     patch.object(driver.prepare, 'grade', return_value={'exit_code': 101}):
                    result = driver.execute_pair(root, Decimal('1.6'), lambda: 'fp')
                self.assertEqual(len(seen), 1)
                self.assertEqual(Decimal(result['pilot_cost_usd']), Decimal('1.8'))

    def test_historical_loader_verifies_all_terminal_costs_and_restores_worker_root(self):
        with tempfile.TemporaryDirectory() as d:
            old = pathlib.Path(d)
            prior_sid = 'prior'
            prior_receipt = old / 'prior-receipt.json'
            prior_stdout = old / 'prior-stdout.json'
            prior_receipt.write_text(json.dumps({'session_id': prior_sid, 'unknown_provider_cost': False, 'cost_usd': '.1'}))
            prior_stdout.write_text(json.dumps({'type': 'result', 'session_id': prior_sid, 'total_cost_usd': '.1'}))
            (old / 'prior-attempts.json').write_text(json.dumps({'attempts': [{
                'session_id': prior_sid, 'receipt_path': str(prior_receipt), 'stdout_path': str(prior_stdout)}]}))
            rows = []
            for i, (effort, declaration) in enumerate(driver.worker.CELLS):
                out = old / f'paid-v2-{i}'
                out.mkdir()
                sid = f'old-{i}'
                (out / 'stdout.json').write_text(json.dumps({
                    'type': 'result', 'session_id': sid, 'total_cost_usd': '.3'}))
                rows.append({'cell': i, 'effort': effort, 'declaration': declaration, 'fingerprint': 'old-fp',
                             'unknown_provider_cost': False, 'transport_errors': [], 'session_id': sid, 'cost_usd': '.3'})
            (old / 'paid-v2-results.json').write_text(json.dumps({'cost_usd': '1.3', 'results': rows}))
            previous = driver.worker.L
            self.assertEqual(driver.historical_spend(old), Decimal('1.3'))
            self.assertEqual(driver.worker.L, previous)
            path = old / 'paid-v2-2/stdout.json'
            data = json.loads(path.read_text())
            data['total_cost_usd'] = '.4'
            path.write_text(json.dumps(data))
            with self.assertRaisesRegex(ValueError, 'cost mismatch'):
                driver.historical_spend(old)
            self.assertEqual(driver.worker.L, previous)


if __name__ == '__main__':
    unittest.main()
