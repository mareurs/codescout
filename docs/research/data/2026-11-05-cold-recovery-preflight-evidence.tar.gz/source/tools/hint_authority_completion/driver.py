"""Bounded matched completion check; frozen qualified worker remains unchanged."""
import json
import pathlib
import sys
from decimal import Decimal
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent / 'hint_authority_pilot'))
import run as worker
import prepare
import audit

def historical_spend(old):
    import importlib.util
    from core import amount
    previous = worker.L
    try:
        worker.L = old
        prior = worker.prior_spend()
    finally:
        worker.L = previous
    saved = json.loads((old / 'paid-v2-results.json').read_text())
    rows = saved['results']
    if len(rows) != 4:
        raise ValueError('Incomplete or expanded historical cohort')
    location = pathlib.Path(__file__).resolve().parent.parent / 'hint_authority_resume/driver.py'
    spec = importlib.util.spec_from_file_location('historical_resume', location)
    history = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(history)
    def terminal(row):
        raw = json.loads((old / f"paid-v2-{row['cell']}" / 'stdout.json').read_text())
        return raw if isinstance(raw, list) else [raw]
    total = history.validate_existing(rows, prior, terminal, rows[0]['fingerprint'])
    if total != amount(saved['cost_usd']):
        raise ValueError('Historical campaign total mismatch')
    return total

def execute_pair(root, prior, check):
    import shutil
    from core import admit, amount, extract_result
    spent = amount(prior)
    if spent > 4:
        raise ValueError('Historical cost exceeds pilot cap')
    with (root / 'completion-started.json').open('x') as marker:
        json.dump({'prior_pilot_cost_usd': str(spent), 'cells': [['low', False], ['xhigh', False]]}, marker)
    results = []
    def ledger():
        return {'prior_pilot_cost_usd': str(prior), 'new_cost_usd': str(spent - amount(prior)),
                'pilot_cost_usd': str(spent), 'results': results}
    prepare.save(root / 'completion-results.json', ledger())
    for i, effort in enumerate(('low', 'xhigh')):
        if not admit(spent, Decimal('1'), Decimal('4')):
            break
        current = check()
        label = f'completion-{i}'
        prepare.save(root / 'completion-inflight.json',
                     {'attempt': label, 'prior_pilot_cost_usd': str(spent),
                      'campaign_remaining_usd': str(Decimal('4') - spent), 'state': 'awaiting_terminal'})
        try:
            receipt = worker.one(label, effort, False, False,
                                 campaign_remaining=Decimal('4') - spent)
            raw = json.loads((root / label / 'stdout.json').read_text())
            terminal = extract_result(raw if isinstance(raw, list) else [raw], receipt['session_id'])
            if receipt.get('unknown_provider_cost') is not False:
                raise ValueError('Unknown provider cost')
            if terminal['cost'] != amount(receipt['cost_usd']):
                raise ValueError('Terminal/receipt cost mismatch')
            if spent + terminal['cost'] > 4:
                raise ValueError('Pilot cap exceeded')
        except Exception as error:
            prepare.save(root / 'completion-halt.json', {
                'attempt': label, 'cost': 'unknown pending terminal recovery',
                'reason': type(error).__name__ + ': ' + str(error)[:300]})
            raise
        spent += terminal['cost']
        row = dict(cell=i, effort=effort, declaration=False, fingerprint=current, **receipt)
        results.append(row)
        prepare.save(root / label / 'receipt.json', row)
        prepare.save(root / 'completion-results.json', ledger())
        prepare.save(root / 'completion-inflight.json',
                     {'attempt': label, 'state': 'terminal_verified', 'pilot_cost_usd': str(spent)})
        try:
            destination = root / (label + '-grader')
            shutil.copytree(pathlib.Path(receipt['actor']), destination,
                            ignore=shutil.ignore_patterns('.git', 'target'))
            row['grade_exit_code'] = prepare.grade(destination, label)['exit_code']
        except Exception as error:
            prepare.save(root / 'completion-halt.json', {
                'attempt': label, 'cost': 'known; retained in completion-results.json',
                'reason': type(error).__name__ + ': ' + str(error)[:300]})
            raise
        prepare.save(root / 'completion-results.json', ledger())
        print(json.dumps(row), flush=True)
        if receipt['transport_errors'] or receipt['budget_stop']:
            break
        if not receipt['workflow_completed'] and terminal['subtype'] not in {
                'error_max_budget_usd', 'error_max_turns'}:
            break
    return ledger()


def check_preflight(root, old, prior):
    import hashlib
    from core import amount
    if any(module.L != root for module in (prepare, worker, audit)):
        raise ValueError('Mixed launch roots')
    current = audit.fingerprint()
    review = json.loads((root / 'completion-review.json').read_text())
    plan_bytes = (root / 'completion-plan.json').read_bytes()
    plan = json.loads(plan_bytes)
    if (review.get('accepted') is not True or review.get('fingerprint') != current
            or review.get('driver_sha256') != hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
            or review.get('plan_sha256') != hashlib.sha256(plan_bytes).hexdigest()):
        raise ValueError('Unreviewed completion driver or plan')
    if (plan['cells'] != [['low', False], ['xhigh', False]] or amount(plan['pilot_cap_usd']) != 4
            or amount(plan['prior_pilot_cost_usd']) != prior
            or amount(plan['prior_thread_cost_usd']) != Decimal('29.221154299999999834')):
        raise ValueError('Changed registered experiment')
    if historical_spend(old) != prior:
        raise ValueError('Historical ledger changed')
    if prior + Decimal('29.221154299999999834') > 40:
        raise ValueError('Thread cap exceeded')
    summary = json.loads((root / 'verification-summary.json').read_text())
    witness = summary['host_canary_presence_at_audit']
    canary = worker.W / 'outside-host-canary.txt'
    if (summary['fingerprint'] != current or witness['path'] != str(canary)
            or not canary.is_file()
            or hashlib.sha256(canary.read_bytes()).hexdigest() != witness['sha256']
            or witness['sha256'] != plan['host_canary_sha256']):
        raise ValueError('Missing or changed real host canary witness')
    controls = json.loads((root / 'functional-controls-v2.json').read_text())
    qualifications = [json.loads((root / f'qualify-{i}' / 'receipt.json').read_text()) for i in range(4)]
    audit.validate_preflight(controls, qualifications, review, current)
    return current


def main():
    root = prepare.P / 'launch-budget-requalification-20261104'
    old = prepare.P / 'launch-v1'
    prior = historical_spend(old)
    for module in (prepare, worker, audit):
        module.L = root
    check = lambda: check_preflight(root, old, prior)
    current = check()
    if sys.argv[1:] == ['--check']:
        print(json.dumps({'fingerprint': current, 'prior_pilot_cost_usd': str(prior),
                          'remaining_pilot_usd': str(Decimal('4') - prior), 'provider_calls': 0}))
        return
    if sys.argv[1:] != ['--paid']:
        raise ValueError('Choose --check or --paid')
    execute_pair(root, prior, check)


if __name__ == '__main__':
    main()
