import pathlib,sys,unittest
from decimal import Decimal
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent.parent/'hint_authority_pilot'))
from driver import validate_existing
class ResumeTests(unittest.TestCase):
    def fixture(self):
        row={'cell':0,'effort':'low','declaration':False,'session_id':'s','cost_usd':'.36','unknown_provider_cost':False,'fingerprint':'fp','transport_errors':['ValueError: Request exceeds remaining reserve','ValueError: Earlier transport failure']}
        terminal={'type':'result','session_id':'s','total_cost_usd':'.36'}
        return row,terminal
    def test_known_budget_stop_carries_all_cost_without_using_grade(self):
        row,terminal=self.fixture()
        for grade in [0,101,None]:
            row['grade_exit_code']=grade
            spent=validate_existing([row],Decimal('.17'),lambda r:[terminal],'fp')
            self.assertEqual(spent,Decimal('.53'))
    def test_unknown_cost_or_nonbudget_failure_or_wrong_identity_blocks(self):
        row,terminal=self.fixture()
        for field,value in [('unknown_provider_cost',True),('transport_errors',['network failed']),('fingerprint','old'),('cell',1),('effort','xhigh'),('cost_usd','.4')]:
            with self.assertRaises(ValueError,msg=field):validate_existing([dict(row,**{field:value})],Decimal('.17'),lambda r:[terminal],'fp')
        with self.assertRaises(ValueError):validate_existing([row],Decimal('.17'),lambda r:[dict(terminal,session_id='other')],'fp')
    def test_duplicate_or_skipped_cell_and_overspend_are_rejected(self):
        row,terminal=self.fixture()
        with self.assertRaises(ValueError):validate_existing([row,row],Decimal('.17'),lambda r:[terminal],'fp')
        with self.assertRaises(ValueError):validate_existing([row],Decimal('3.9'),lambda r:[terminal],'fp')
