"""Resume a cost-known censored block without resampling or changing any worker input."""
import hashlib
import json
import pathlib
import shutil
import sys
from decimal import Decimal
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent.parent/'hint_authority_pilot'))
from core import amount,admit,extract_result
from audit import fingerprint,validate_preflight
from prepare import L,grade,save
from run import CELLS,one,prior_spend

def validate_existing(rows,prior,load_terminal,current):
    spent=amount(prior)
    for i,row in enumerate(rows):
        if row.get('cell')!=i or i>=len(CELLS):raise ValueError('Duplicate/skipped cell')
        if (row.get('effort'),row.get('declaration'))!=CELLS[i]:raise ValueError('Wrong cell treatment')
        if row.get('fingerprint')!=current:raise ValueError('Changed worker inputs')
        if row.get('unknown_provider_cost') is not False:raise ValueError('Unknown provider cost')
        errors=row.get('transport_errors',[])
        allowed={'ValueError: Request exceeds remaining reserve','ValueError: Earlier transport failure'}
        if errors and (not set(errors)<=allowed or 'ValueError: Request exceeds remaining reserve' not in errors):raise ValueError('Nonbudget transport failure')
        terminal=extract_result(load_terminal(row),row['session_id'])
        cost=amount(row['cost_usd'])
        if terminal['cost']!=cost:raise ValueError('Receipt cost mismatch')
        spent+=cost
    if spent>4:raise ValueError('Pilot already over cap')
    return spent

def terminal_records(row):
    raw=json.loads((L/f"paid-v2-{row['cell']}"/'stdout.json').read_text())
    return raw if isinstance(raw,list) else [raw]

def main():
    current=fingerprint()
    own_hash=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
    review=json.loads((L/'resume-review.json').read_text())
    if review.get('accepted') is not True or review.get('driver_sha256')!=own_hash or review.get('worker_fingerprint')!=current:raise ValueError('Resume driver not reviewed')
    validate_preflight(json.loads((L/'functional-controls-v2.json').read_text()),
      [json.loads((L/f'qualify-{i}'/'receipt.json').read_text()) for i in range(4)],
      json.loads((L/'review-accepted.json').read_text()),current)
    path=L/'paid-v2-results.json'
    saved=json.loads(path.read_text());rows=saved['results']
    prior=prior_spend()
    spent=validate_existing(rows,prior,terminal_records,current)
    if spent!=amount(saved['cost_usd']):raise ValueError('Campaign total mismatch')
    save(L/'resume-ruling.json',{'worker_fingerprint':current,'driver_sha256':own_hash,
      'rule':'Only completed cost-known reserve stops can advance; no grade-dependent continuation; never resample completed cells',
      'scope':'Same per-cell CLI cap, cost guard, task, instruction, native runtime and order; full workflow completion remains separate from patch acceptance'})
    for i in range(len(rows),len(CELLS)):
        if not admit(spent,Decimal('1'),Decimal('4')):break
        if fingerprint()!=current or hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()!=own_hash:raise ValueError('Changed reviewed source')
        effort,declaration=CELLS[i];label=f'paid-v2-{i}'
        try:r=one(label,effort,declaration,False,campaign_remaining=Decimal('4')-spent)
        except Exception as e:
            save(L/'resume-halt.json',{'attempt':label,'cost':'unknown pending terminal recovery','reason':type(e).__name__+': '+str(e)})
            raise
        r['fingerprint']=current
        row=dict(cell=i,effort=effort,declaration=declaration,**r)
        rows.append(row)
        # Validate identity and known cost before allowing any subsequent paid attempt.
        spent=validate_existing(rows,prior,terminal_records,current)
        save(L/label/'receipt.json',r)
        save(path,{'cost_usd':str(spent),'prior_cost_usd':str(prior),'results':rows,'resume_driver_sha256':own_hash})
        dst=L/(label+'-grader');shutil.copytree(pathlib.Path(r['actor']),dst,ignore=shutil.ignore_patterns('.git','target'))
        row['grade_exit_code']=grade(dst,label)['exit_code']
        save(path,{'cost_usd':str(spent),'prior_cost_usd':str(prior),'results':rows,'resume_driver_sha256':own_hash})
        print(json.dumps(row),flush=True)
if __name__=='__main__':main()
