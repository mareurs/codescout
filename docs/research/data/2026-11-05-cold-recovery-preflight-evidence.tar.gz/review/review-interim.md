# Recovery review — interim, awaiting lifecycle revision

Reviewed base c278effb9b36259480e079051d16238d66314e8e plus the nine-file recovery snapshot from promoted-source-hashes.json. Review source was copied into pristine/ and work/. No source in V was edited.

Observed baseline: 55 lifecycle tests and 19 driver tests pass. Thirteen distinct mutations were applied to the private copy; eleven were killed by assertion failures and two survived. Each has an exact patch, full unittest log, result JSON, and hash-verified restoration.

Important findings:
1. tools/hint_authority_workflow/driver.py:227; test_driver.py:262. Cold proof/public command equality has no effective regression witness. m11_cold_commands removes only that equality and all 19 driver tests pass. Add a mismatching command proof and recompute the review binding before checking admission.
2. tools/hint_authority_workflow/driver.py:176; test_driver.py:297. The aborted-history call site can replace raw-terminal reconciliation with receipt cost plus unknown-cost refusal and all 19 tests pass (m13_aborted_skip_raw). The simpler omission m09 was killed only by unknown-cost handling. Add independent stream/stdout terminal disagreement cases while receipt and aggregate ledger remain unchanged.

Known pending implementation finding reported by executor: the actual native qualification auto-removes the native owner when the client exits before execute's finally capture. Its planned fix moves capture before client cleanup. I have not independently run Docker and do not claim that live observation as my own.

Strengths supported by mutations: immutable identity checks for read, capture and cleanup; settled incomplete-evidence refusal; truncation refusal; cold memory/deadline/log-hash checks; native resource normalization all have observed killing witnesses.

Declined to judge:
- Provider efficacy, paid task quality, and generic effort superiority: this review is an exposed-task offline diagnostic.
- Live Docker behavior and full Rust gate: executor owns those runs, expressly excluded from this review.
- CPU versus memory causality: bundled cold-control qualification does not isolate them.

Verdict: with fixes; do not bind final admission until lifecycle revision and two surviving test mutations are rechecked.

Ledger checked: 39785443931155d4, 7aa44115b3456514, 68180be293c5d09a, f458f9840337469e.
