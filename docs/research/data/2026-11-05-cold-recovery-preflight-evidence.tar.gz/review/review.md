# Recovery delta review

Assessment: accepted for the scoped recovery implementation, subject to the executor's independent native qualification and full gate. No unresolved Critical or Important finding remains in this finite offline review. This acceptance is not a paid-cohort admission receipt.

Reviewed base: c278effb9b36259480e079051d16238d66314e8e. Final source is the exact eleven-path manifest in reviewed-source-hashes-final.json. The source checkout V remained read-only; all mutations ran in this directory's private work/ copy. The original nine-path source snapshot remains in pristine/. Final changed paths remain in pristine-final/.

## Evidence and scope

Initial baseline: 55 lifecycle tests and 19 driver tests passed. Revised implementation baseline: 56 lifecycle tests and 21 driver tests passed. After the final test-only ordering revision, the focused PreCleanupTests test passed, exercising success and timeout subtests with real subprocesses and delegating close/kill witnesses. The unchanged broad suite was not rerun after that test-only revision.

There were 23 mutation executions across the review iterations: 19 returned failing tests and four historically survived. All four observed survivors were later re-applied exactly and killed by added or strengthened tests. These are execution counts, not a count of unique mutations or a coverage percentage. Every execution has an exact .patch, full .log and .json result; restoration hashes were checked. No kill was counted from a syntax/import failure. aggregate.json records the complete ledger and closure mapping.

No provider calls, credential access, Docker operations, onboarding, or independent Rust gate were performed by this reviewer. Full native qualifications and the gate belong to the executor.

## Strengths

- tools/agent_lifecycle/qualify.py:28,62,122: native record reads, log export and destructive cleanup independently reject changed immutable IDs. Applied omissions at each call site were killed.
- tools/agent_lifecycle/workflow.py:147,157,197: missing or truncated evidence cannot produce workflow completion. Callback unwiring and missing-evidence completion-guard omission were killed.
- tools/agent_lifecycle/session.py:82,184,192: snapshot runs once, before successful stdin closure and before error-path process-group cleanup. Real-subprocess ordering tests now kill both close-first and SIGTERM-first mutations.
- tools/hint_authority_workflow/driver.py:165,199: aborted cost is reconstructed at its call site and cold admission binds resources, deadlines, command population and raw log hashes. Relevant applied omissions were killed after the findings below were closed.

## Findings resolved during review

1. Important — cold public command population was not discriminated by tests. At driver.py:227, m11 removed only the public_checks equality guard and all 19 driver tests passed. Added ColdCommandTests at test_driver.py:279 changes a command while recomputing the review hash. Exact reapplication m19 fails that test. Ledger: 14857abc06b11138.
2. Important — aborted-history raw terminal corroboration was not pinned at the new call site. At driver.py:176, m13 replaced reconcile with receipt cost plus unknown-cost rejection and all 19 tests passed. New test_driver.py:324 independently changes stream and stdout costs with receipt/ledger fixed. Exact reapplication m20 fails both subtests. Ledger: 4e852bbfb60ff0f7.
3. Important — the first ordering test relied on scheduling. At session.py:184, m16 moved snapshot immediately after stdin.close; at session.py:192, m21 moved the finally snapshot immediately after SIGTERM. Each passed all 56 lifecycle tests. test_session.py:187 now records actual close and kill calls through delegating wrappers while retaining the real subprocess. Exact patches m22 and m23 fail the focused no-job and timeout subtests, respectively. Ledger: 7aa44115b3456514.

The executor separately observed native auto-removal before the earlier late capture. I read the corrected callback implementation and verified its offline ordering witnesses; I did not independently reproduce that Docker observation. The original late-only capture is not part of the accepted source.

## Declined to judge

- Paid model quality, effort superiority or transfer: this is one exposed-task diagnostic and no paid cohort was run by this reviewer.
- Live Docker/native integration and full Rust gate: expressly assigned to the executor; no claim of independent live verification.
- Individual CPU versus memory causality: the cold control qualifies the combined bundle.
- Broader pre-existing lifecycle behavior outside this recovery delta: no broad redesign or full-system correctness claim.

Final verdict: accepted for this exact recovery delta with no unresolved findings from the finite review. Use the final eleven-path hash manifest when binding the review; changed source requires a scoped recheck.

Ledger checked: 39785443931155d4, 7aa44115b3456514, 68180be293c5d09a, f458f9840337469e, 14857abc06b11138, 4e852bbfb60ff0f7.
