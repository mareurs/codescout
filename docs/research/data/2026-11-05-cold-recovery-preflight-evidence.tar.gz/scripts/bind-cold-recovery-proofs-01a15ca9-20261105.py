"""Reuse immutable onboarding/private controls; verify actual new transport wire and cold proof."""
import hashlib,json,pathlib,shutil,sys
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
BASE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
ROOT=BASE/"complete-workflow-cold-recovery-20261105"
OLD=BASE/"complete-workflow-calibration-20261105"
sys.path[:0]=[str(V/"tools/hint_authority_pilot")]
import audit
from core import audit_request
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inventory(root):
    result={}
    for p in root.rglob("*"):
        rel=str(p.relative_to(root))
        if p.is_symlink():result[rel+"#link"]=str(p.readlink())
        if p.is_file():result[rel]=digest(p)
    return result
def main():
    assert inventory(ROOT/"source")==inventory(OLD/"source")
    assert inventory(ROOT/"skill-only-plugin")==inventory(OLD/"skill-only-plugin")
    assert digest(ROOT/"reference.patch")==digest(OLD/"reference.patch")
    for src,dst in ((OLD/"acceptance-controls.json",ROOT/"acceptance-controls.json"),
                    (BASE/"public-profile-cold-20261105-v1/independent-readback.json",ROOT/"cold-public-control.json")):
        assert not dst.exists()
        shutil.copyfile(src,dst)
    proof=json.loads((ROOT/"qualification.json").read_text())
    qbase=pathlib.Path(proof["readback"]).parent
    wire=[]
    for effort,mode in (("low","success"),("low","repair"),("low","unknown"),("xhigh","success")):
        out=qbase/("qualification" if effort=="low" else "qualification-xhigh")/mode
        inspected=audit.inspect_cell(out)
        assert inspected["hint_visible_on_wire"] and inspected["boundary_denied"]
        expected=json.loads((out/"expected.json").read_text())
        requests=list(out.glob("request-*.json"))
        for p in requests:audit_request(json.loads(p.read_text()),expected)
        wire.append(dict(effort=effort,mode=mode,requests=len(requests),**inspected))
    for path,want in proof["runtime_hashes"].items():assert digest(pathlib.Path(path))==want
    proof["wire_controls"]=wire
    proof["reused_onboarding_source_files"]=len(inventory(ROOT/"source"))
    proof["runtime_scope"]="Executed transport/native dependencies only; campaign driver separately tested/reviewed, cold full Rust proof separate."
    (ROOT/"qualification-as-produced.json").write_bytes((ROOT/"qualification.json").read_bytes())
    (ROOT/"qualification.json").write_text(json.dumps(proof,indent=2)+"\n")
    print(json.dumps(dict(wire_cells=len(wire),runtime_hashes=len(proof["runtime_hashes"]),reused_onboarding=True,provider_cost_usd="0")))
if __name__=="__main__":main()
