"""Zero-provider cold reference: fixed checks, prospective CPU4/memory12GiB/time3600."""
import hashlib
import importlib.util
import json
import pathlib
import shutil
import subprocess
import sys
import traceback

ORIGINAL = pathlib.Path("/tmp/verified-public-profile-01a15ca9-20261105.py")
ROOT = pathlib.Path("/home/marius/.cache/codescout-resident/codescout/public-profile-cold-20261105-v1")

def main():
    assert hashlib.sha256(ORIGINAL.read_bytes()).hexdigest() == "3369ee8d629ff14155deccc96a5021d2b3a1d3a641bc483c8cf29f830d65b7f4"
    assert not ROOT.exists()
    name = "hfa-public-profile-01a15ca9-20261105"
    assert subprocess.run(["docker","inspect",name], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode != 0
    capacity = shutil.disk_usage(ROOT.parent)
    assert capacity.free >= 30*1024**3
    spec = importlib.util.spec_from_file_location("cold_public_control", ORIGINAL)
    control = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(control)
    control.ROOT = ROOT
    original_run = control.subprocess.run
    def initialized_run(argv, *args, **kwargs):
        if (isinstance(argv, (list, tuple)) and list(argv[:3]) == ["git","apply","--unsafe-paths"]
                and pathlib.Path(kwargs.get("cwd",".")) == ROOT/"project"):
            actor = ROOT/"project"
            assert not (actor/"target").exists()
            original_run(["git","init","-q"],cwd=actor,check=True)
            original_run(["git","add","."],cwd=actor,check=True)
            original_run(["git","-c","user.name=HFA fixture","-c","user.email=hfa@invalid",
                          "commit","-qm","Frozen diagnostic baseline"],cwd=actor,check=True)
        return original_run(argv,*args,**kwargs)
    control.subprocess.run = initialized_run
    original_validate = control.validate_config
    def configured(raw):
        return original_validate(dict(raw,timeout_s=3600,check_timeout_s=1800))
    control.validate_config = configured
    original_argv = control.worker.native_argv
    def native_argv(actor,home):
        assert not (actor/"target").exists()
        argv = original_argv(actor,home)
        argv[argv.index("--memory")+1] = "12g"
        argv[-4:-4] = ["--init","--cpus","4"]
        assert not any("dst=/testbed/target" in arg for arg in argv)
        return argv
    control.worker.native_argv = native_argv
    original_check = control.native_check
    probe_done = False
    def native_check(out,image,command,log,timeout_s):
        nonlocal probe_done
        if not probe_done:
            owner = json.loads((out/"record-owner.json").read_text())
            inspected = original_run(["docker","inspect",owner["container_id"]],
                capture_output=True,text=True,check=True,timeout=10)
            row = json.loads(inspected.stdout)[0]
            host = row["HostConfig"]
            assert row["Id"] == owner["container_id"] and row["Image"] == image
            assert host["NanoCpus"] == 4000000000 and host["Memory"] == 12*1024**3
            assert host["Init"] is True and host["PidsLimit"] == 512
            assert not (ROOT/"project/target").exists()
            (out/"cold-resource-witness.json").write_text(json.dumps(dict(
                container_id=row["Id"],host_config=host,mounts=row["Mounts"],
                target_absent_before_first_command=True,provider_calls=0),indent=2)+"\n")
            probe = "mkdir -p /testbed/target && printf '%s' 'fn main(){println!(\"{}\",std::thread::available_parallelism().unwrap());}' > /testbed/target/cpu-probe.rs && rustc /testbed/target/cpu-probe.rs -o /testbed/target/cpu-probe && /testbed/target/cpu-probe && cat /sys/fs/cgroup/cpu.max && cat /sys/fs/cgroup/pids.max"
            code = original_check(out,image,probe,out/"cpu-probe.log",min(30,timeout_s))
            assert code == 0 and (out/"cpu-probe.log").read_text().splitlines()[0] == "4"
            probe_done = True
        return original_check(out,image,command,log,timeout_s)
    control.native_check = native_check
    record = dict(script_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
        root=str(ROOT),cpu_quota=4,memory_bytes=12*1024**3,init_reaper=True,git_baseline=True,
        cold_target=True,build_cache_mounts=[],workflow_timeout_s=3600,check_timeout_s=1800,
        public_commands_changed=False,test_filters_added=False,provider_calls=0,
        disk_available_bytes_before=capacity.free,
        scope="Combined resource/deadline control; no independent CPU-vs-memory causal attribution")
    exit_code = 1
    try:
        exit_code = control.main()
    except BaseException:
        record["outer_error"] = traceback.format_exc()
        raise
    finally:
        if ROOT.exists():
            record["control_exit_code"] = exit_code
            (ROOT/"cold-control-preflight.json").write_text(json.dumps(record,indent=2)+"\n")
    return exit_code

if __name__ == "__main__":
    sys.exit(main())
