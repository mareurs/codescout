"""Final no-provider admission: exact reviewed source commit, completed gate and proof hashes."""
import hashlib,importlib.util,json,pathlib,subprocess
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/complete-workflow-cold-recovery-20261105")
REVIEW=pathlib.Path("/tmp/workflow-cold-review-01a15ca9-20261105")
SID="01a15ca9-f939-7603-acb5-01c6b02f68e2"
def load(p):return json.loads(p.read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(["git","-C",str(V),*args],text=True).strip()
def main():
    binding=load(REVIEW/"review-binding.json")
    for path,want in binding["source_hashes"].items():assert digest(V/path)==want,path
    assert digest(REVIEW/"review.md")==binding["review_report_sha256"]
    aggregate=load(REVIEW/"aggregate.json")
    assert aggregate["accepted"] is True and aggregate["unresolved_observed_survivors"]==0
    gate=load(pathlib.Path("/tmp/codescout-bg/455879-a720241d-bg_0000006d.json"))
    assert gate["state"]=="exited" and gate["exit_code"]==0
    assert not git("status","--porcelain")
    commit=git("rev-parse","HEAD")
    assert commit!="c278effb9b36259480e079051d16238d66314e8e"
    assert "Session-Id: codex:"+SID in git("show","-s","--format=%B","HEAD")
    committed=set(git("diff-tree","--no-commit-id","--name-only","-r","HEAD").splitlines())
    assert committed==set(binding["source_hashes"]),committed
    assert not (ROOT/"started.json").exists() and not (ROOT/"review.json").exists()
    spec=importlib.util.spec_from_file_location("admitted_cold_workflow",V/"tools/hint_authority_workflow/driver.py")
    driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
    assert driver.registration()==load(ROOT/"plan.json")
    assert driver.composition(ROOT)==binding["fingerprint"]
    for key,name in (("qualification_sha256","qualification.json"),("acceptance_sha256","acceptance-controls.json"),
                     ("cold_control_sha256","cold-public-control.json"),("plan_sha256","plan.json")):
        assert digest(ROOT/name)==binding[key],name
    with (ROOT/"review.json").open("x") as f:json.dump(binding,f,indent=2);f.write("\n")
    fingerprint=driver.check(ROOT)
    result=dict(admitted=True,paid_started=False,provider_calls=0,source_commit=commit,session_id=SID,
        fingerprint=fingerprint,thread_prior_usd=str(driver.THREAD_PRIOR),thread_cap_usd=str(driver.THREAD_CAP),
        allocation_usd=str(driver.ALLOCATION),arm_cap_usd=str(driver.ARM_CAP),gate=gate,
        code_review_sha256=digest(REVIEW/"review.md"),scope="Actual no-provider preflight after reviewed exact-source commit; model outcomes not measured.")
    (ROOT/"preflight.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))
if __name__=="__main__":main()
