"""Independent cold-control readback and bounded evidence archive; no model calls."""
import gzip,hashlib,io,json,pathlib,subprocess,tarfile
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/public-profile-cold-20261105-v1")
DATA=pathlib.Path("/home/marius/work/claude/codescout/docs/research/data")
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    job=load(pathlib.Path("/tmp/codescout-bg/455879-a720241d-bg_00000069.json"))
    assert job["state"]=="exited" and job["exit_code"]==0
    result=load(ROOT/"result.json");manifest=load(ROOT/"preparation-manifest.json")
    preflight=load(ROOT/"cold-control-preflight.json");witness=load(ROOT/"cold-resource-witness.json")
    original=load(V/"tools/hint_authority_workflow/public-checks.json")
    public=result["public_verification"];profile=manifest["profile"]
    assert public["status"]=="completed" and public["passed"] is True and result["error"] is None
    assert result["model_cost_usd"]=="0" and result["provider_calls"]==0
    assert public["checks"] and len(public["checks"])==4
    assert [(c["id"],c["command"]) for c in public["checks"]]==[(c["id"],c["command"]) for c in original["checks"]]
    assert all(c["exit_code"]==0 for c in public["checks"])
    assert profile["timeout_s"]==3600 and profile["check_timeout_s"]==1800 and profile["checks"]==original["checks"]
    assert preflight["cold_target"] and preflight["build_cache_mounts"]==[] and witness["target_absent_before_first_command"]
    assert witness["host_config"]["NanoCpus"]==4000000000 and witness["host_config"]["Memory"]==12*1024**3
    assert witness["host_config"]["Init"] and witness["host_config"]["PidsLimit"]==512
    launch=load(ROOT/"launch.json")
    assert launch["real_credentials_read"] is False and "--network" in launch["argv"]
    assert launch["argv"][launch["argv"].index("--network")+1]=="none"
    assert not any("dst=/testbed/target" in x for x in launch["argv"])
    assert (ROOT/"cpu-probe.log").read_text().splitlines()[0]=="4"
    for path,want in manifest["additional_files"].items():assert sha(pathlib.Path(path))==want
    before=load(ROOT/"candidate-before.json");after=load(ROOT/"candidate-after.json")
    changed={key for key in before.keys()|after.keys() if before.get(key)!=after.get(key)}
    allowed_runtime={".codescout/embeddings/.gitignore",".codescout/embeddings/hint-authority-diagnostic.db",".codescout/write.lock"}
    assert changed==allowed_runtime and all(key not in before for key in changed)
    assert all(after[key]==want for key,want in before.items())
    assert result["cleanup"]["absent"] and result["cleanup"]["remove_exit"]==0
    for identity in {witness["container_id"],launch["name"]}:
        p=subprocess.run(["docker","inspect",identity],capture_output=True,text=True,timeout=5)
        assert p.returncode and "no such" in p.stderr.lower()
    proof=dict(qualified=True,cold_target=True,cpu_quota=4,memory_bytes=12*1024**3,
        workflow_timeout_s=3600,check_timeout_s=1800,provider_cost_usd="0",public_checks=original["checks"],
        public_passed=True,public_wall_s=result["public_wall_s"],cleanup_absent=True,
        generated_artifacts={key:after[key] for key in sorted(changed)},source_files_unchanged=True,
        source_commit=manifest["source_commit"],resource_witness_sha256=sha(ROOT/"cold-resource-witness.json"),
        target_witness="Absent before first command; CPU probe creates only standalone probe files, no Cargo dependency cache.",
        actual_logs={c["id"]:dict(path=c["log"],sha256=sha(pathlib.Path(c["log"]))) for c in public["checks"]},
        limits="Known reference only; combined resource/deadline bundle; not paid model quality or independent CPU/memory causality.")
    (ROOT/"independent-readback.json").write_text(json.dumps(proof,indent=2)+"\n")
    payload={}
    for p in ROOT.iterdir():
        if p.is_file() and not p.is_symlink():payload["control/"+p.name]=p.read_bytes()
    for p in (ROOT/"verification-0").iterdir():
        if p.is_file():payload["control/verification-0/"+p.name]=p.read_bytes()
    for name in ("qualify-public-profile-cold-01a15ca9-20261105.py","verified-public-profile-01a15ca9-20261105.py","verify-cold-public-profile-01a15ca9-20261105.py"):
        payload["scripts/"+name]=(pathlib.Path("/tmp")/name).read_bytes()
    payload["job.json"]=json.dumps(job,indent=2).encode()
    hashes={key:hashlib.sha256(value).hexdigest() for key,value in payload.items()}
    archive=DATA/"2026-11-05-cold-public-profile-evidence.tar.gz"
    with tarfile.open(archive,"w:gz") as tar:
        for name,content in payload.items():
            info=tarfile.TarInfo(name);info.size=len(content);tar.addfile(info,io.BytesIO(content))
    with tarfile.open(archive,"r:gz") as tar:
        assert set(tar.getnames())==set(payload)
        for name,want in hashes.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==want
    (DATA/"2026-11-05-cold-public-profile-verification.json").write_text(json.dumps(proof,indent=2)+"\n")
    (DATA/"2026-11-05-cold-public-profile-archive.json").write_text(json.dumps(dict(
        path=str(archive),sha256=sha(archive),payload_sha256=hashes,every_payload_verified=True),indent=2)+"\n")
    print(json.dumps(proof,indent=2))
if __name__=="__main__":main()
