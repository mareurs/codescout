"""Promote exactly reviewed recovery candidates after byte-checking the frozen baseline."""
import hashlib,json,pathlib
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
STAGE=pathlib.Path("/tmp/workflow-recovery-01a15ca9-20261105")
FILES=("tools/agent_lifecycle/qualify.py","tools/agent_lifecycle/workflow.py",
       "tools/agent_lifecycle/test_qualify.py","tools/agent_lifecycle/test_evidence.py",
       "tools/agent_lifecycle/test_runtime.py","tools/hint_authority_workflow/driver.py",
       "tools/hint_authority_workflow/test_driver.py","tools/hint_authority_workflow/public-checks.json",
       "tools/hint_authority_workflow/README.md")
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    baseline=json.loads((STAGE/"baseline-source-hashes.json").read_text())
    for path in FILES:
        target=V/path
        if path in baseline:assert sha(target)==baseline[path],path
        else:assert not target.exists(),path
    hashes={}
    for path in FILES:
        (V/path).write_bytes((STAGE/path).read_bytes());hashes[path]=sha(V/path)
    (STAGE/"promoted-source-hashes.json").write_text(json.dumps(hashes,indent=2)+"\n")
    print(json.dumps(hashes,indent=2))
if __name__=="__main__":main()
