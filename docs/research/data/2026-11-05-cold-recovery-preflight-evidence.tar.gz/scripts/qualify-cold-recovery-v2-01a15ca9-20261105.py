"""Fresh qualification after pre-client-teardown fix; preserves failed v1 directory."""
import hashlib,importlib.util,json,pathlib,subprocess
ROOT=pathlib.Path("/home/marius/.cache/codescout-resident/codescout/complete-workflow-cold-recovery-20261105")
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    obj=importlib.util.module_from_spec(spec);spec.loader.exec_module(obj);return obj
def main():
    q=module("cold_integrated","/tmp/qualify-integrated-runtime-01a15ca9-20261105.py")
    q.BASE=ROOT/"qualification-budget4-v2";q.ROOT=q.BASE/"qualification";q.BASE.mkdir()
    original=q.worker.one
    def one(*args,**kwargs):
        kwargs["client_budget_usd"]="4"
        return original(*args,**kwargs)
    q.worker.one=one
    original_check=q.original_check
    def observed_check(out,image,command,log,timeout_s):
        code=original_check(out,image,command,log,timeout_s)
        owner=json.loads((out/"record-owner.json").read_text())
        inspected=subprocess.run(["docker","inspect",owner["container_id"]],check=True,capture_output=True,text=True,timeout=5)
        row=json.loads(inspected.stdout)[0];host=row["HostConfig"]
        actor=next(m for m in row["Mounts"] if m["Destination"]=="/testbed")
        env=dict(item.split("=",1) for item in row["Config"]["Env"] if "=" in item)
        witness=dict(container_id=row["Id"],image=row["Image"],init=host["Init"],nano_cpus=host["NanoCpus"],
            pids_limit=host["PidsLimit"],memory_bytes=host["Memory"],actor_source=actor["Source"],
            actor_read_write=actor["RW"],cargo_target_dir=env["CARGO_TARGET_DIR"],command=command,exit_code=code)
        assert witness["init"] and witness["nano_cpus"]==4000000000 and witness["pids_limit"]==512
        assert witness["memory_bytes"]==12*1024**3 and witness["container_id"]==owner["container_id"] and witness["image"]==image
        assert pathlib.Path(actor["Source"])==(out/"project").resolve() and actor["RW"] and env["CARGO_TARGET_DIR"]=="/testbed/target"
        with (out/"native-runtime-observations.jsonl").open("a") as f:f.write(json.dumps(witness)+"\n")
        return code
    q.observed_check=observed_check
    q.main()
    readback=module("cold_runtime_readback","/tmp/readback-cold-runtime-01a15ca9-20261105.py")
    readback.BASE=q.BASE;readback.main()
    for effort,mode in (("low","success"),("low","repair"),("low","unknown"),("xhigh","success")):
        out=q.BASE/("qualification" if effort=="low" else "qualification-xhigh")/mode
        launch=json.loads((out/"launch.json").read_text());argv=launch["argv"]
        assert argv[argv.index("--max-budget-usd")+1]=="4"
    hashes=json.loads((q.BASE/"qualification-summary.json").read_text())["runtime_source_hashes"]
    proof=dict(qualified=True,cli_budget_usd="4",provider_cost_usd="0",runtime_hashes=hashes,
        cells=["low:success","low:repair","low:unknown","xhigh:success"],
        readback=str(q.BASE/"independent-readback.json"),
        readback_sha256=hashlib.sha256((q.BASE/"independent-readback.json").read_bytes()).hexdigest(),
        script_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
        scope="Actual scripted CLI/native/background/public transport. Campaign driver/tests separately reviewed; cold Rust public proof separate.")
    (ROOT/"qualification.json").write_text(json.dumps(proof,indent=2)+"\n")
    print(json.dumps(dict(qualified=True,provider_cost_usd="0",cli_budget_usd="4")),flush=True)
if __name__=="__main__":main()
