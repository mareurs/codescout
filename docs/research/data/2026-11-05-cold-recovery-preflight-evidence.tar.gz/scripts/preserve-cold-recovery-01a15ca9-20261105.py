"""Preserve exact code, proof, review and jobs separately for preflight and final cohorts."""
import hashlib,io,json,os,pathlib,subprocess,sys,tarfile
MAIN=pathlib.Path("/home/marius/work/claude/codescout")
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
BASE=pathlib.Path("/home/marius/.cache/codescout-resident/codescout")
ROOT=BASE/"complete-workflow-cold-recovery-20261105"
REVIEW=pathlib.Path("/tmp/workflow-cold-review-01a15ca9-20261105")
def sha(content):return hashlib.sha256(content).hexdigest()
def load(p):return json.loads(p.read_text())
def main():
    phase=sys.argv[1]
    assert phase in {"preflight","final"}
    payload={}
    skip={"source","skill-only-plugin","project","native-home","client-home","target","grader-target",".git","__pycache__",
          "pristine","pristine-final","work"}
    for label,root in (("campaign",ROOT),("review",REVIEW)):
        for directory,dirs,files in os.walk(root,followlinks=False):
            dirs[:]=[d for d in dirs if d not in skip and not d.endswith("-grader")]
            for name in files:
                p=pathlib.Path(directory)/name
                if not p.is_symlink() and p.suffix not in {".pyc",".tar",".gz"}:
                    payload[label+"/"+str(p.relative_to(root))]=p.read_bytes()
    binding=load(ROOT/"review.json")
    for path,want in binding["source_hashes"].items():
        content=(V/path).read_bytes();assert sha(content)==want
    for directory in ("agent_lifecycle","hint_authority_pilot","hint_authority_completion","hint_authority_resume","hint_authority_workflow"):
        for p in (V/"tools"/directory).iterdir():
            if p.is_file() and p.suffix in {".py",".json",".md"}:
                payload["source/"+str(p.relative_to(V))]=p.read_bytes()
    scripts=("stage-workflow-recovery","promote-workflow-recovery","qualify-public-profile-cold","verify-cold-public-profile",
             "qualify-cold-recovery","qualify-cold-recovery-v2","readback-cold-runtime","bind-cold-recovery-proofs",
             "preserve-cold-recovery","bind-cold-recovery-admission","verify-cold-recovery-pair")
    for name in scripts:
        p=pathlib.Path("/tmp")/(name+"-01a15ca9-20261105.py")
        if p.exists():payload["scripts/"+p.name]=p.read_bytes()
    for p in pathlib.Path("/tmp").glob("workflow-*-01a15ca9.log"):
        payload["test-logs/"+p.name]=p.read_bytes()
    for handle in ("00000069","0000006d","0000006e","0000006f","00000072"):
        p=pathlib.Path("/tmp/codescout-bg")/("455879-a720241d-bg_"+handle+".json")
        row=load(p);assert row["state"]=="exited"
        payload["jobs/"+handle+".json"]=p.read_bytes()
        payload["jobs/"+handle+".log"]=pathlib.Path(row["log_path"]).read_bytes()
    for name in ("2026-11-05-complete-workflow-archive.json","2026-11-05-cold-public-profile-archive.json"):
        payload["prior-archives/"+name]=(MAIN/"docs/research/data"/name).read_bytes()
    manifest={key:dict(sha256=sha(content),bytes=len(content)) for key,content in sorted(payload.items())}
    archive=MAIN/"docs/research/data"/("2026-11-05-cold-recovery-"+phase+"-evidence.tar.gz")
    assert not archive.exists()
    with tarfile.open(archive,"w:gz") as tar:
        for name,content in payload.items():
            info=tarfile.TarInfo(name);info.size=len(content);tar.addfile(info,io.BytesIO(content))
        content=(json.dumps(manifest,indent=2)+"\n").encode()
        info=tarfile.TarInfo("manifest.json");info.size=len(content);tar.addfile(info,io.BytesIO(content))
    with tarfile.open(archive,"r:gz") as tar:
        assert set(tar.getnames())==set(payload)|{"manifest.json"}
        assert json.load(tar.extractfile("manifest.json"))==manifest
        for name,want in manifest.items():
            content=tar.extractfile(name).read()
            assert len(content)==want["bytes"] and sha(content)==want["sha256"]
    result=dict(phase=phase,archive=str(archive),sha256=sha(archive.read_bytes()),payload_files=len(payload),every_payload_hash_verified=True)
    (MAIN/"docs/research/data"/("2026-11-05-cold-recovery-"+phase+"-archive.json")).write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result))
if __name__=="__main__":main()
