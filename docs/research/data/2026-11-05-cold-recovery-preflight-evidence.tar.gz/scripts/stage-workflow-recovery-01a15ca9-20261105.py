"""Private source staging; leaves the frozen worktree/public cold control unchanged."""
import hashlib,json,pathlib,shutil
V=pathlib.Path("/home/marius/.codex/worktrees/615e/codescout")
ROOT=pathlib.Path("/tmp/workflow-recovery-01a15ca9-20261105")
assert not ROOT.exists()
ROOT.mkdir()
manifest={}
for directory in ("agent_lifecycle","hint_authority_pilot","hint_authority_completion","hint_authority_resume","hint_authority_workflow"):
    for path in (V/"tools"/directory).iterdir():
        if path.is_file() and path.suffix in {".py",".json",".md"}:
            rel=path.relative_to(V);dst=ROOT/rel;dst.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(path,dst)
            manifest[str(rel)]=hashlib.sha256(path.read_bytes()).hexdigest()
(ROOT/"baseline-source-hashes.json").write_text(json.dumps(manifest,indent=2)+"\n")
print(json.dumps(dict(root=str(ROOT),copied_source_files=len(manifest),frozen_worktree_changed=False)))
